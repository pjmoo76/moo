/**
 * Copyright (c) 2018 SK Broadband. All right reserved.
 *
 * This software is the confidential and proprietary information of SK
 * Broadband. You shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement you entered
 * into with SK Broadband.
 */
package com.skb.adams.cm.d2f.model;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.skb.adams.core.model.BaseAudit;

@SuppressWarnings("serial")
public class AllTabColumnsVO extends BaseAudit {

    @Override
    public String toString() {
      return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
    }

    private int dbParallelSize;
    private String tableName;
    private String dateTypeFormat;
    private String fromDate;
    private String toDate;

    private String fullSelect;            /* 전체 자료 SELECT 구문 */
    private String chngSelect;            /* 변경 자료 SELeCT 구분 */

    /**
     * getter method for dbParallelSize
     * @return the dbParallelSize
     */
    public int getDbParallelSize() {
        return dbParallelSize;
    }
    /**
     * setter method for dbParallelSize
     * @param dbParallelSize the dbParallelSize to set
     */
    public void setDbParallelSize(int dbParallelSize) {
        this.dbParallelSize = dbParallelSize;
    }
    /**
     * getter method for tableName
     * @return the tableName
     */
    public String getTableName() {
        return tableName;
    }
    /**
     * setter method for tableName
     * @param tableName the tableName to set
     */
    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
    /**
     * getter method for dateTypeFormat
     * @return the dateTypeFormat
     */
    public String getDateTypeFormat() {
        return dateTypeFormat;
    }
    /**
     * setter method for dateTypeFormat
     * @param dateTypeFormat the dateTypeFormat to set
     */
    public void setDateTypeFormat(String dateTypeFormat) {
        this.dateTypeFormat = dateTypeFormat;
    }
    /**
     * getter method for fromDate
     * @return the fromDate
     */
    public String getFromDate() {
        return fromDate;
    }
    /**
     * setter method for fromDate
     * @param fromDate the fromDate to set
     */
    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }
    /**
     * getter method for toDate
     * @return the toDate
     */
    public String getToDate() {
        return toDate;
    }
    /**
     * setter method for toDate
     * @param toDate the toDate to set
     */
    public void setToDate(String toDate) {
        this.toDate = toDate;
    }
    /**
     * getter method for fullSelect
     * @return the fullSelect
     */
    public String getFullSelect() {
        return fullSelect;
    }
    /**
     * setter method for fullSelect
     * @param fullSelect the fullSelect to set
     */
    public void setFullSelect(String fullSelect) {
        this.fullSelect = fullSelect;
    }
    /**
     * getter method for chngSelect
     * @return the chngSelect
     */
    public String getChngSelect() {
        return chngSelect;
    }
    /**
     * setter method for chngSelect
     * @param chngSelect the chngSelect to set
     */
    public void setChngSelect(String chngSelect) {
        this.chngSelect = chngSelect;
    }

}
