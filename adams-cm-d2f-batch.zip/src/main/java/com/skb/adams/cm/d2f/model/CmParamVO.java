/**
 * Copyright (c) 2016 SK Broadband.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with SK Broadband.
 */
package com.skb.adams.cm.d2f.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.univocity.parsers.csv.CsvWriterSettings;

@JsonInclude(Include.ALWAYS)
public class CmParamVO {

    private String sysIfName      = null;
    private String mdcKey         = null;
    private String targetSysId    = null;
    private String logFileName    = null;

    private String selectSql = null;

    private int dbParallelSize = 0;       /* Table Parallel Size */
    private int dbFetchSize    = 0;       /* Select Fetch Size */
    private int dbCommitSize   = 0;       /* Table Commit Size */

    private String spoolDatetime  = null;
	private String expTableName   = null;       /* 추출 대상테이블명 */
	private String dateTypeFormat = null;       /* Date Type Select Format */

	private String fileWriteHome  = null;       /* 파일 출력 Home Directory */
	private String fileNameCsv    = null;       /* CSV 파일명 */
	private String fileNameChk    = null;       /* 파일 출력 건수 */
	private String colSeparator   = null;       /* 파일 출력 구분자 */

    private CsvWriterSettings csvSettings = null;
    private String charSet = null;
    private String queryParam = null;

    /**
     * getter method for sysIfName
     * @return the sysIfName
     */
    public String getSysIfName() {
        return sysIfName;
    }
    /**
     * setter method for sysIfName
     * @param sysIfName the sysIfName to set
     */
    public void setSysIfName(String sysIfName) {
        this.sysIfName = sysIfName;
    }
    /**
     * getter method for mdcKey
     * @return the mdcKey
     */
    public String getMdcKey() {
        return mdcKey;
    }
    /**
     * setter method for mdcKey
     * @param mdcKey the mdcKey to set
     */
    public void setMdcKey(String mdcKey) {
        this.mdcKey = mdcKey;
    }
    /**
     * getter method for logFileName
     * @return the logFileName
     */
    public String getLogFileName() {
        return logFileName;
    }
    /**
     * setter method for logFileName
     * @param logFileName the logFileName to set
     */
    public void setLogFileName(String logFileName) {
        this.logFileName = logFileName;
    }
    /**
     * getter method for selectSql
     * @return the selectSql
     */
    public String getSelectSql() {
        return selectSql;
    }
    /**
     * setter method for selectSql
     * @param selectSql the selectSql to set
     */
    public void setSelectSql(String selectSql) {
        this.selectSql = selectSql;
    }
    /**
     * getter method for dbParallelSize
     * @return the dbParallelSize
     */
    public int getDbParallelSize() {
        return dbParallelSize;
    }
    /**
     * setter method for dbParallelSize
     * @param dbParallelSize the dbParallelSize to set
     */
    public void setDbParallelSize(int dbParallelSize) {
        this.dbParallelSize = dbParallelSize;
    }
    /**
     * getter method for dbFetchSize
     * @return the dbFetchSize
     */
    public int getDbFetchSize() {
        return dbFetchSize;
    }
    /**
     * setter method for dbFetchSize
     * @param dbFetchSize the dbFetchSize to set
     */
    public void setDbFetchSize(int dbFetchSize) {
        this.dbFetchSize = dbFetchSize;
    }
    /**
     * getter method for dbCommitSize
     * @return the dbCommitSize
     */
    public int getDbCommitSize() {
        return dbCommitSize;
    }
    /**
     * setter method for dbCommitSize
     * @param dbCommitSize the dbCommitSize to set
     */
    public void setDbCommitSize(int dbCommitSize) {
        this.dbCommitSize = dbCommitSize;
    }
    /**
     * getter method for spoolDatetime
     * @return the spoolDatetime
     */
    public String getSpoolDatetime() {
        return spoolDatetime;
    }
    /**
     * setter method for spoolDatetime
     * @param spoolDatetime the spoolDatetime to set
     */
    public void setSpoolDatetime(String spoolDatetime) {
        this.spoolDatetime = spoolDatetime;
    }
    /**
     * getter method for expTableName
     * @return the expTableName
     */
    public String getExpTableName() {
        return expTableName;
    }
    /**
     * setter method for expTableName
     * @param expTableName the expTableName to set
     */
    public void setExpTableName(String expTableName) {
        this.expTableName = expTableName;
    }
    /**
     * getter method for dateTypeFormat
     * @return the dateTypeFormat
     */
    public String getDateTypeFormat() {
        return dateTypeFormat;
    }
    /**
     * setter method for dateTypeFormat
     * @param dateTypeFormat the dateTypeFormat to set
     */
    public void setDateTypeFormat(String dateTypeFormat) {
        this.dateTypeFormat = dateTypeFormat;
    }
    /**
     * getter method for fileWriteHome
     * @return the fileWriteHome
     */
    public String getFileWriteHome() {
        return fileWriteHome;
    }
    /**
     * setter method for fileWriteHome
     * @param fileWriteHome the fileWriteHome to set
     */
    public void setFileWriteHome(String fileWriteHome) {
        this.fileWriteHome = fileWriteHome;
    }
    /**
     * getter method for fileNameCsv
     * @return the fileNameCsv
     */
    public String getFileNameCsv() {
        return fileNameCsv;
    }
    /**
     * setter method for fileNameCsv
     * @param fileNameCsv the fileNameCsv to set
     */
    public void setFileNameCsv(String fileNameCsv) {
        this.fileNameCsv = fileNameCsv;
    }
    /**
     * getter method for fileNameChk
     * @return the fileNameChk
     */
    public String getFileNameChk() {
        return fileNameChk;
    }
    /**
     * setter method for fileNameChk
     * @param fileNameChk the fileNameChk to set
     */
    public void setFileNameChk(String fileNameChk) {
        this.fileNameChk = fileNameChk;
    }
    /**
     * getter method for colSeparator
     * @return the colSeparator
     */
    public String getColSeparator() {
        return colSeparator;
    }
    /**
     * setter method for colSeparator
     * @param colSeparator the colSeparator to set
     */
    public void setColSeparator(String colSeparator) {
        this.colSeparator = colSeparator;
    }
    /**
     * getter method for csvSettings
     * @return the csvSettings
     */
    public CsvWriterSettings getCsvSettings() {
        return csvSettings;
    }
    /**
     * setter method for csvSettings
     * @param csvSettings the csvSettings to set
     */
    public void setCsvSettings(CsvWriterSettings csvSettings) {
        this.csvSettings = csvSettings;
    }
    /**
     * getter method for charSet
     * @return the charSet
     */
    public String getCharSet() {
        return charSet;
    }
    /**
     * setter method for charSet
     * @param charSet the charSet to set
     */
    public void setCharSet(String charSet) {
        this.charSet = charSet;
    }
    /**
     * getter method for targetSysId
     * @return the targetSysId
     */
    public String getTargetSysId() {
        return targetSysId;
    }
    /**
     * setter method for targetSysId
     * @param targetSysId the targetSysId to set
     */
    public void setTargetSysId(String targetSysId) {
        this.targetSysId = targetSysId;
    }
	public String getQueryParam() {
		return queryParam;
	}
	public void setQueryParam(String queryParam) {
		this.queryParam = queryParam;
	}
    

}
