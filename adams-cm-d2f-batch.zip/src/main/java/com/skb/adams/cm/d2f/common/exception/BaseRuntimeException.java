/*
 * Copyright (c) 2016 SK Broadband. All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with SK
 * Telecom.
 */
package com.skb.adams.cm.d2f.common.exception;

import java.util.Locale;

import org.springframework.context.MessageSource;

public class BaseRuntimeException extends RuntimeException {

    /**
     * MessageSource 변수 선언
     */
    protected MessageSource messageSource = null;

    /**
     * Use serialVersionUID science TANGO
     */
    private static final long serialVersionUID = -1326809446139644286L;

    /**
     * Message code 변수 선언
     */
    protected String messageCode = null;

    /**
     * message 변수 선언
     */
    protected String message = null;

    /**
     * status 변수 선언
     */
    protected int status = 0;

    /**
     * BaseRuntimeException
     * @param message
     */
    public BaseRuntimeException(String message) {
        super(message);
    }

    /**
     *
     * BaseRuntimeException 생성자
     *
     * @param messageSource
     * @param messageCode
     * @param status
     * @param messageParameters
     * @param defaultMessage
     * @param cause
     */
    public BaseRuntimeException(MessageSource messageSource, String messageCode, int status,
    Object[] messageParameters, String defaultMessage, Throwable cause) {
        super(cause);
        Locale locale = Locale.getDefault();
        this.message = messageSource.getMessage(messageCode, messageParameters, defaultMessage, locale);
    }

    /**
     *
     * BaseRuntimeException 생성자
     *
     * @param messageSource
     * @param messageCode
     * @param status
     * @param messageParameters
     * @param defaultMessage
     */
    public BaseRuntimeException(MessageSource messageSource, String messageCode, int status,
    Object[] messageParameters, String defaultMessage) {
        super(defaultMessage);
        Locale locale = Locale.getDefault();
        this.message = messageSource.getMessage(messageCode, messageParameters, defaultMessage, locale);
    }

    /**
     *
     * BaseRuntimeException 생성자
     *
     * @param messageSource
     * @param messageCode
     * @param status
     * @param messageParameters
     * @param cause
     */
    public BaseRuntimeException(MessageSource messageSource, String messageCode, int status,
    Object[] messageParameters, Throwable cause) {
        this(messageSource, messageCode, status, messageParameters, null, cause);
    }

    /**
     *
     * BaseRuntimeException 생성자
     *
     * @param messageSource
     * @param messageCode
     * @param status
     * @param messageParameters
     */
    public BaseRuntimeException(MessageSource messageSource, String messageCode, int status,
    Object[] messageParameters) {
        this(messageSource, messageCode, status, messageParameters, null, null);
    }

    /**
     *
     * BaseRuntimeException 생성자
     *
     * @param defaultCode
     * @param defaultMessage
     * @param status
     * @param cause
     */
    public BaseRuntimeException(String defaultCode, String defaultMessage, int status, Throwable cause) {
        super(cause);
        this.messageCode = defaultCode;
        this.message = defaultMessage;
        this.status = status;
    }

    /**
     *
     * BaseRuntimeException 생성자
     *
     * @param defaultCode
     * @param defaultMessage
     * @param status
     */
    public BaseRuntimeException(String defaultCode, String defaultMessage, int status) {
        super();
        this.messageCode = defaultCode;
        this.message = defaultMessage;
        this.status = status;
    }

    /**
     *
     * BaseRuntimeException 생성자
     *
     * @param defaultCode
     * @param status
     */
    public BaseRuntimeException(String defaultCode, int status) {
        super();
        this.messageCode = defaultCode;
        this.status = status;
    }

    /**
     *
     * BaseRuntimeException 생성자
     */
    public BaseRuntimeException() {
        super();
    }

    @Override
    public String getMessage() {
        return this.message;
    }

    /**
     * messageCode를 읽어오는 메소드
     *
     * @return String
     */
    public String getMessageCode() {
        return this.messageCode;
    }

    /**
     * HTTP Status Code를 읽어오는 메소드
     *
     * @return HttpStatus
     */
    public int getStatus() {
        return this.status;
    }

}
