package com.skb.adams.cm.d2f.common.exception;

import com.skb.adams.core.batch.exception.BatchException;
import com.skb.adams.cm.d2f.common.constant.AppConstants.COMMON_EXCEPTION;

public class CmBatchException extends BatchException {
	/**
     * serialVersionUID
     */
    private static final long serialVersionUID = 8008934887155054748L;


    /**
     * MODULE 정의
     */
    private static final String MODULE = "cmBatchTaskJob";


    /**
     * CmBatchException
     * @param cause
     */
    public CmBatchException(Throwable cause) {
        super(MODULE, cause);
    }


    /**
     * CmBatchException
     * @param sampleException
     * @param cause
     */
    public CmBatchException(COMMON_EXCEPTION commonException, Throwable cause) {
        super(MODULE, commonException.getExceptionCode(), commonException.getExceptionMessage(), cause);
    }

}
