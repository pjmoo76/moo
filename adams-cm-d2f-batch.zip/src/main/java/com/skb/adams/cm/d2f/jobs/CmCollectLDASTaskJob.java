/*
 * Copyright (c) 2016 SK Broadband.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with SK Broadband.
 */
package com.skb.adams.cm.d2f.jobs;

import java.nio.channels.CompletionHandler;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.skb.adams.cm.d2f.common.ConfigManager;
import com.skb.adams.cm.d2f.common.constant.AppConstants;
import com.skb.adams.cm.d2f.common.constant.NbsConstants;
import com.skb.adams.cm.d2f.common.exception.AdamsBizException;
import com.skb.adams.cm.d2f.common.proxy.AdamsProxy;
import com.skb.adams.cm.d2f.dao.AllTabColumnsDao;
import com.skb.adams.cm.d2f.dao.OCO30320Dao;
import com.skb.adams.cm.d2f.dao.OIV10671Dao;
import com.skb.adams.cm.d2f.model.AllTabColumnsVO;
import com.skb.adams.cm.d2f.model.CmParamVO;
import com.skb.adams.cm.d2f.model.CmResultVO;
import com.skb.adams.cm.d2f.model.DbServiceNodeVO;
import com.skb.adams.cm.d2f.model.OCO30320VO;
import com.skb.adams.cm.d2f.service.CmCollectBatchService;
import com.skb.adams.core.batch.common.constants.BatchConstants;
import com.skb.adams.core.batch.jobs.BaseJob;
import com.skb.adams.core.batch.model.JobExecutionResult;
import com.skb.adams.core.constant.CharsetConstants;
import com.skb.adams.core.constant.DateFormatConstants;
import com.skb.adams.core.constant.LineConstants;
import com.skb.adams.core.utils.CoreCommUtils;
import com.skb.adams.core.utils.CoreErrorUtils;
import com.skb.adams.core.utils.CoreTimeUtils;
import com.univocity.parsers.csv.CsvFormat;
import com.univocity.parsers.csv.CsvWriterSettings;

@Component
@PropertySources({
    @PropertySource("classpath:/properties/mdc.properties")
   })
public class CmCollectLDASTaskJob extends BaseJob {

    protected static final Logger LOGGER = LoggerFactory.getLogger(CmCollectLDASTaskJob.class);

    @Autowired
    private AdamsProxy adamsProxy = null;

    @Autowired
    BasicDataSource dataSource = null;

    @Autowired
    private OCO30320Dao oco30320Dao = null;
    
    @Autowired
    private OIV10671Dao oiv10671Dao = null;

    @Autowired
    private AllTabColumnsDao allTabColumnsDao = null;

    @Autowired
    private CmCollectBatchService cmBatchService = null;

    @Value("${fileProcessor.mdc.key.name:fileName}")
    private String mdcKey = null;
    
    String fileNameCsv   = "";
    String fileNameChk   = "";

    /**
     * callBack - 테이블별 파일 생성 완료후, CallBack Method 호출
     */
    private CompletionHandler<CmResultVO, Map<String, Object>> writeCallBack = new CompletionHandler<CmResultVO, Map<String, Object>>() {
        @Override
        @SuppressWarnings("unchecked")
        public void completed(CmResultVO cmResult, Map<String, Object> map) {

            // 오류 테이블 목록 및 Flag 설정
            List<String> errTables = (List<String>) map.get("errTables");

            try {
                 // 처리결과 검사
                 if (cmResult.procRtnCode == AppConstants.RETURN_CODE_OK) {
                     // 파일 출력건수 .chk 파일 생성
                	 /*
                     File file = new File(cmResult.fileNameChk);
                     file.createNewFile();
                     try (FileWriter writer = new FileWriter(file);) {
                          writer.write(String.valueOf(cmResult.writeCnt));
                          writer.flush();
                     }
                     */
                     LOGGER.info("■ [CM-COLLECT-TASK][{}] Dat file[{}]", cmResult.sysIfName, cmResult.fileNameCsv);
                     LOGGER.info("■ [CM-COLLECT-TASK][{}] Chk file[{}]", cmResult.sysIfName, cmResult.fileNameChk);
                     LOGGER.info("■ [CM-COLLECT-TASK][{}] Both DB select and File write are completed OK !", cmResult.sysIfName);
                 } else {
                     // 오류 테이블명 보관(오류 SMS 전송 목적)
                     errTables.add(cmResult.tableName);

                     // 오류 Flag 설정
                     map.put("errFlag", true);

                     LOGGER.error("■ [CM-COLLECT-TASK][{}] 파일 생성 오류가 발생하였습니다. - [selectRtnCode : {}][writeRtnCode : {}]",
                                  cmResult.sysIfName,
                                  cmResult.selectRtnCode.getValue(),
                                  cmResult.writeRtnCode .getValue());
                 }
            } catch(Throwable e) {
                LOGGER.error(CoreErrorUtils.getStackTrace(e));
            } finally {
                errTables = null;
            }
        }
        @Override
        public void failed(Throwable e, Map<String, Object> map) {
            // 오류 Flag 설정
            map.put("errFlag", true);
            LOGGER.error("■ [CM-COLLECT-TASK] writeCallBack failed method is called ! {}", CoreErrorUtils.getStackTrace(e));
        }
    };

	/**
	 * 실제, Batch 업무처리 수행
	 * @see com.skb.adams.core.batch.job.BaseJob#doProcess()
	 */
	@Override
	public JobExecutionResult doProcess(String jobName) throws Exception {
		
		// 추출 대상 테이블
	    String expTableName = nbsArgumentMap.get(NbsConstants.EXP_TABLE_NAME);
	    
	    // E2E 완료 체크 후 수행
        //String  resultString = oiv10671Dao.getOIV10660();
        
        String  batchResultString = oiv10671Dao.getE2ePostworkCheck(); 
       
        if(!"1".equals(batchResultString))
        {            	
        	LOGGER.info("■ [EAI-TASK]  OIV10683 연동파일 미생성. OIV10671로 강제생성 ]");            	 
          
        }else{
        	
        	LOGGER.info("■ [EAI-TASK]  OIV10683 연동파일 생성완료. 정상종료 확인 ]");
            
        	// 성공
            super.jobExecutionResult.setReturnCode   (Integer.toString(AppConstants.NBS_RETURN_CODE_OK.getKey()));
            super.jobExecutionResult.setReturnMessage(AppConstants.NBS_RETURN_CODE_OK.getValue());
            
            
            // 전체 Step 종료 상태 전송
            sendBatchStatus(1);            
            dataSource.close();
            
            return jobExecutionResult;
        }
        

        super.jobExecutionResult.setExecutedJob(jobName);
        super.jobExecutionResult.setModule(AppConstants.NBS_COLLECT_MODULE);
	    super.jobExecutionResult.setReturnCode(AppConstants.NBS_RETURN_CODE_INIT.getValue());

        boolean errFlag = false;

	    String runJobId    = super.jobId;
	    String runJobExeId = super.jobExecutionId;

	    

	    // 자료제공 대상시스템명 + "-" + 추출 대상 테이블
	    String targetSysId = nbsArgumentMap.get(NbsConstants.TARGET_SYS_ID);
	    String jobGroupId = nbsArgumentMap.get(NbsConstants.JOBGROUP_ID);
	    String sysIfName = targetSysId + LineConstants.HYPHEN + expTableName;

	    LOGGER.info("■ [CM-COLLECT-TASK][{}] Table 자료 추출 시작합니다. - JOB_ID[{}], JOB_EXE_ID[{}], JOB_DESC[{}]",
	                expTableName,
	                runJobId,
	                runJobExeId,
	                nbsArgumentMap.get(BatchConstants.BATCH_PARAM_JOB_DESC));

	    // NBS 파라미터 설정값 추출
        int dbParallelSize = Integer.parseInt(CoreCommUtils.getSystemProperty(NbsConstants.DB_PARALLEL_SIZE, "1"));
        int dbFetchSize    = Integer.parseInt(CoreCommUtils.getSystemProperty(NbsConstants.DB_FETCH_SIZE,    "10000"));

        String dateTypeFormat = CoreCommUtils.getSystemProperty(NbsConstants.DATE_TYPE_FORMAT, "YYYY/MM/DD HH24:MI:SS");
        String colSeparator   = CoreCommUtils.getSystemProperty(NbsConstants.COL_SEPARATOR,    LineConstants.STX);

        // 추출요청일시(년월일시분초) : 2019.01.26 토요일 ETL_OIV10802_TO_FILE Job 실행 오류로 인해 재실행을 고려하여 NBS 파라미터 일시를 사용하도록 변경
        // String reqStartTime  = CoreTimeUtils.getDateTime(CoreTimeUtils.FMT_YMDHMS);
        String reqStartTime  = nbsArgumentMap.get(NbsConstants.PROC_DATE) + CoreTimeUtils.getDateTime(CoreTimeUtils.FMT_HHMMSS);

        // 데이타 파일 출력시, 라인 앞 및 뒤에 Spool DateTime 출력
        String spoolDateTime = reqStartTime;

        // 전일자 기준으로 파일 생성 폴더 및 파일명 생성 요청(2018.09.07 금요일 오현경S) : 재실행 관련 변경
        // String yesterdayYmd = CoreTimeUtils.getCurrentDateWithPlusDays(-1);
        String yesterdayYmd = CoreTimeUtils.getDateWithPlusDays(reqStartTime.substring(0, 8), CoreTimeUtils.FMT_YYYYMMDD, -1, CoreTimeUtils.FMT_YYYYMMDD);
        String todayYmd = reqStartTime.substring(0, 8);
        String fileDateYmd = yesterdayYmd.substring(0, 8);
        String fileDateYm  = yesterdayYmd.substring(0, 6);

        // 파일 출력 경로 설정
        // ENV_DIR_CREATE_YN 파라미터를 받아서 기본적으로는 생성, N 선택시 해당 경로에 디렉토리를 생성하지 않고 파일생성(2019.09.25)
        String dirCreateYN = nbsArgumentMap.get(NbsConstants.DIR_PATH_YN);
        String filePath = "";
        if(dirCreateYN != null && dirCreateYN.equals("N")) {
        	filePath = nbsArgumentMap.get(NbsConstants.FILE_WRITE_PATH);
        } else {
        	filePath = nbsArgumentMap.get(NbsConstants.FILE_WRITE_PATH) + LineConstants.SLASH + fileDateYm;
        }
        String fileWritePath = filePath;

        // 파일명 생성 규칙(CSV 파일 : 테이블명_년월일.dat, CHK 파일 : 테이블명_년월일.chk)
        String baseFileName = "";
        String nbsFileName = nbsArgumentMap.get(NbsConstants.FILE_NAME);
        // ENV_FILE_NAME 파라미터 여부에 따라 파라미터 존재시 해당 이름으로 파일생성(2019.09.10)
        if(nbsFileName == null) {
        	baseFileName  = fileWritePath + LineConstants.SLASH + expTableName + LineConstants.UNDERBAR;
        } else {
        	baseFileName  = fileWritePath + LineConstants.SLASH + nbsFileName + LineConstants.UNDERBAR;
        }

        fileNameCsv   = baseFileName  + todayYmd + AppConstants.EXT_CSV;
        fileNameChk   = baseFileName  + todayYmd + AppConstants.EXT_CHK;
        
        /*
        if("DAPS".equals(targetSysId))
        {
        	// 전일 날짜 데이터파일명 생성.
        	fileNameCsv   = baseFileName  + todayYmd + AppConstants.EXT_DAT;
            fileNameChk   = baseFileName  + todayYmd + AppConstants.EXT_CHK;
        }else{
        	// 당일 날짜 데이터파일명 생성.
        	fileNameCsv   = baseFileName  + fileDateYmd + AppConstants.EXT_DAT;
            fileNameChk   = baseFileName  + fileDateYmd + AppConstants.EXT_CHK;
        }
        */

        // 파일 출력 Character Set
        String charSet = CoreCommUtils.getSystemProperty(NbsConstants.FILE_WRITE_CHARSET, CharsetConstants.UTF_8);
        
        // 쿼리에서 사용할 파라미터        QUERY_PARAM
        String queryParam = nbsArgumentMap.get(NbsConstants.QUERY_PARAM);
        
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();

        try {
            // 전체 Step 1 : NBS 상태정보 전송
            sendBatchStatus(1, 0);

            // 대상 테이블 추출범위 조회(F:전체, C:변경분)
            OCO30320VO oco30320Srch = new OCO30320VO();
            oco30320Srch.setTblNm(expTableName);

            OCO30320VO oco30320Rtn = oco30320Dao.selectOne(oco30320Srch);

            // 자료 추출범위
            String dataExtrtScopeClCd = oco30320Rtn.getDataExtrtScopeClCd();

            LOGGER.info("■■ [CM-COLLECT-TASK][{}] Table 자료 추출범위[{}](F:전체, C:변경분)", expTableName, dataExtrtScopeClCd);

            // Dynamic 전체 자료 SELECT, 변경 자료 SELECT SQL 구문 조회
            AllTabColumnsVO atcSrch = new AllTabColumnsVO();

            atcSrch.setTableName     (expTableName);
            atcSrch.setDbParallelSize(dbParallelSize);
            atcSrch.setDateTypeFormat(dateTypeFormat);

            // 변경분 자료 조회범위 설정(00:00:00 ~ 23:59:59)
            atcSrch.setFromDate(fileDateYmd + "000000");
            atcSrch.setToDate  (fileDateYmd + "235959");

            AllTabColumnsVO atcRtn = allTabColumnsDao.selectOne(atcSrch);

            LOGGER.info("■ [CM-COLLECT-TASK][{}] 전체자료 추출 SQL\n{}", expTableName, atcRtn.getFullSelect());
            LOGGER.info("■ [CM-COLLECT-TASK][{}] 변경자료 추출 SQL\n{}", expTableName, atcRtn.getChngSelect());
            
            // 실행할 SELECT 문장 설정
            String sql = null;
            switch (dataExtrtScopeClCd) {
              case "F": sql = atcRtn.getFullSelect(); break;   // 전체
              case "C": sql = atcRtn.getChngSelect(); break;   // 변경
              case "Q":
            	  String serviceName = nbsArgumentMap.get(NbsConstants.SERVICE_NAME);
            	  sql = getServiceNameToQuery(serviceName);
            	  LOGGER.info("[QUERY]"+sql);
            	  
            	  if("DAPS".equals(targetSysId))
                  {
                  	// USER_ID list 를 받아서 WHERE절 파라미터로 넣어준다 2019-12-09
                  	// USER_ID_LIST
                  	String userIdListStr = nbsArgumentMap.get(NbsConstants.USER_ID_LIST);
                  	String[] userIdList = userIdListStr.split(";");
                  	
                  	if(userIdListStr != null && userIdList.length > 0) {
                  		sql += " WHERE USER_ID IN (";
                  		for(int i = 0; i < userIdList.length; i++) {
                  			if(i > 0) {
                  				sql += ",";
                  			}
                  			sql += "\'" + userIdList[i] + "\'";
                  		}
                  		sql += ")";
                  	}
                  	
                  	LOGGER.info("[WHERE QUERY]"+sql);
                  }
            	  break;
              default : break;
            }

            // 파일 출력 속성 설정
            CsvFormat format = new CsvFormat();
            format.setLineSeparator(LineConstants.LF);
            format.setDelimiter    (colSeparator.charAt(0));

            CsvWriterSettings csvSettings = new CsvWriterSettings();
            csvSettings.setFormat(format);
            csvSettings.setIgnoreLeadingWhitespaces (false);
            csvSettings.setIgnoreTrailingWhitespaces(false);
            csvSettings.setNullValue(LineConstants.EMPTY);

            CountDownLatch latch = new CountDownLatch(1);

            ThreadFactory namedThreadFactory = new ThreadFactoryBuilder().setNameFormat("CmCollectTaskJob-%d").build();
            ExecutorService executorService = Executors.newFixedThreadPool(1, namedThreadFactory);

            int submitCnt = 0;
            List<String> errTables = new ArrayList<>();

            Map<String, Object> map = new HashMap<>();
            map.put("errTables", errTables);
            map.put("errFlag",   false);

            try {
                // MDC 경로 포함 파일명 생성
                String logFileName = CoreCommUtils.getMdcFileName(targetSysId, expTableName);

                String selectSql = sql;

                Runnable cmTask = new Runnable() {
                    @Override
                    public void run() {
                        try {
                            CmParamVO cmParam = new CmParamVO();

                            cmParam.setMdcKey        (mdcKey);
                            cmParam.setTargetSysId   (targetSysId);
                            cmParam.setLogFileName   (logFileName);
                            cmParam.setSelectSql     (selectSql);
                            cmParam.setDbParallelSize(dbParallelSize);
                            cmParam.setDbFetchSize   (dbFetchSize);
                            cmParam.setSysIfName     (sysIfName);
                            cmParam.setSpoolDatetime (spoolDateTime);
                            cmParam.setExpTableName  (expTableName);
                            cmParam.setDateTypeFormat(dateTypeFormat);
                            cmParam.setFileWriteHome (fileWritePath);
                            cmParam.setFileNameCsv   (fileNameCsv);
                            cmParam.setFileNameChk   (fileNameChk);
                            cmParam.setColSeparator  (colSeparator);
                            cmParam.setCsvSettings   (csvSettings);
                            cmParam.setCharSet       (charSet);
                            cmParam.setQueryParam    (queryParam);

                            // 파일 출력 처리
                            CmResultVO cmResult = cmBatchService.write(latch, cmParam);

                            writeCallBack.completed(cmResult, map);
                        } catch (Throwable t) {
                            writeCallBack.failed(t, map);
                        }
                    }
                };

                // 입수파일별 개별 Thread task 처리
                executorService.submit(cmTask);
                submitCnt++;
           } finally {
                LOGGER.info("■ [CM-COLLECT-TASK][{}] 전체 Submit된 Thread task 건수[{}]", sysIfName, submitCnt);
                executorService.shutdown();
                latch.await();
           }

           executorService.awaitTermination(24, TimeUnit.HOURS);
           executorService.shutdownNow();

           // 종료일시(년월일시분초)
           String reqEndTime = CoreTimeUtils.getDateTime(CoreTimeUtils.FMT_YMDHMS);

           int errTableSize = errTables.size();
           errFlag = (boolean) map.get("errFlag");

           // 오류 처리
           if ((errTableSize > 0) || errFlag) {
               StringBuffer errMsg = new StringBuffer(AppConstants.LF);
               errMsg.append(String.format("■ [CM-COLLECT-TASK][{}] Table 자료 추출 오류 발생 - 추출시작일시[%s], 추출종료일시[%s]",
                                           sysIfName,
                                           CoreTimeUtils.format(reqStartTime, DateFormatConstants.DATE_FMT_1, DateFormatConstants.DATE_FMT_2),
                                           CoreTimeUtils.format(reqEndTime,   DateFormatConstants.DATE_FMT_1, DateFormatConstants.DATE_FMT_2)));

               LOGGER.error(errMsg.toString());

               throw new AdamsBizException(errMsg.toString());
           } else {
               // 성공
               super.jobExecutionResult.setReturnCode   (Integer.toString(AppConstants.NBS_RETURN_CODE_OK.getKey()));
               super.jobExecutionResult.setReturnMessage(AppConstants.NBS_RETURN_CODE_OK.getValue());
           }
        } catch(Throwable t) {
            // 실패
            super.jobExecutionResult.setReturnCode   (Integer.toString(AppConstants.NBS_RETURN_CODE_ERROR.getKey()));
            super.jobExecutionResult.setReturnMessage(AppConstants.NBS_RETURN_CODE_ERROR.getValue());
            super.jobExecutionResult.setCause(t.getMessage());

            LOGGER.error(CoreErrorUtils.getStackTrace(t));

            // 전송 메시지 수정 요청(2019.02.22 금요일 정연식S 구두 요청)
            adamsProxy.sendErrorSms(jobGroupId, targetSysId + AppConstants.SPACE + AppConstants.APP_TITLE);
        }

        // 전체 Step 종료 상태 전송
        sendBatchStatus(1);

        stopWatch.stop();
        long term = stopWatch.getTotalTimeMillis();

        // DataSource DB Connection 종료 처리
        dataSource.close();

        LOGGER.info("■ [CM-COLLECT-TASK][{}] Table 자료 추출 종료합니다.[총 소요시간 : {}][errFlag : {}][NBS_RETURN_MESSAGE : {}]",
                    sysIfName,
                    CoreTimeUtils.getElapsedTime(term),
                    errFlag,
                    super.jobExecutionResult.getReturnMessage());

		return jobExecutionResult;
	}
	
	private String getServiceNameToQuery (String serviceName) {
		String query = "";
		
		List<DbServiceNodeVO>	nodeList = null;
  	  
		ConfigManager configManager = new ConfigManager(AppConstants.SERVICE_FILE_NAME);
		HashMap<String,HashMap<String,String>> serviceMap = configManager.getServiceMap();
		for (Map.Entry me : serviceMap.entrySet()) {
			DbServiceNodeVO node = new DbServiceNodeVO();
        	node.setServiceName((String) me.getKey());
        	HashMap<String,String> itemMap = (HashMap<String,String>) me.getValue();
        	for (Map.Entry me2 : itemMap.entrySet()) {
        		if(AppConstants.QUERY.equals(me2.getKey())) {
        			node.setQuery((String) me2.getValue());
        		}
        	
        	if (nodeList == null) {
    			nodeList = new ArrayList<DbServiceNodeVO>();
    		}
            nodeList.add(node);
            }
        }
  	  
		DbServiceNodeVO reqService = null;
  	  
		for(DbServiceNodeVO node : nodeList) {
			if(node.getServiceName().equals(serviceName)) {
				reqService = node;
			}
		}
  	  
		if(reqService == null) {
        	LOGGER.info("[SERVICE_NAME][{}] 일치하는 서비스가 없습니다.", serviceName);
        } else {
        	LOGGER.info("[SERVICE_NAME][{}] 일치하는 서비스가 있습니다.", reqService.getServiceName());
        	
        	query = reqService.getQuery();
        }
		
		return query;
	}

}
