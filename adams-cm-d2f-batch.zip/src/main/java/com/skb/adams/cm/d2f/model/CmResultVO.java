/**
 * Copyright (c) 2018 SK Broadband. All right reserved.
 *
 * This software is the confidential and proprietary information of SK
 * Broadband. You shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement you entered
 * into with SK Broadband.
 */
package com.skb.adams.cm.d2f.model;

import com.skb.adams.core.batch.common.constants.BatchConstants.ReturnEnum;

public class CmResultVO {

    public String targetSysId =  null;
    public String sysIfName = null;
    public String tableName = null;

    public String fileNameCsv = null;
    public String fileNameChk = null;

    public ReturnEnum procRtnCode = null;
    public ReturnEnum selectRtnCode = null;
    public ReturnEnum writeRtnCode = null;

    public String errMessage = null;
    public Throwable errException = null;

    public int selectCnt = 0;
    public int writeCnt = 0;

    public int putCnt = 0;
    public int getCnt = 0;
}
