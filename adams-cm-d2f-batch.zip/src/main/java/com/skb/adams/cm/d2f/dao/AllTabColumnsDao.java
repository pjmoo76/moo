/*
 * Copyright (c) 2018 SK Broadband.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with SK Broadband.
 */
package com.skb.adams.cm.d2f.dao;

import org.springframework.stereotype.Repository;

import com.skb.adams.core.exception.FtpException;
import com.skb.adams.core.batch.common.annotation.TX_DB_ADAMS_READONLY;
import com.skb.adams.core.batch.dao.BaseDao;
import com.skb.adams.core.batch.exception.BatchException;
import com.skb.adams.cm.d2f.model.AllTabColumnsVO;

@Repository
public class AllTabColumnsDao extends BaseDao {
	/**
	 * SQL_NAMESPACE
	 */
	private static final String SQL_NAMESPACE = "com.skb.adams.cm.d2f.dao.AllTabColumnsDao.";

	/**
	 * selectSQL
	 *
	 * @param vo
	 * @return
	 * @throws FtpException String
	 */
	@TX_DB_ADAMS_READONLY
    public AllTabColumnsVO selectOne(AllTabColumnsVO vo) throws BatchException {
        return sqlSessionTemplate.selectOne(SQL_NAMESPACE + "selectAllTabColumnsOne", vo);
    }

}
