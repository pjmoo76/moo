/*
 * Copyright (c) 2018 SK Broadband.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with SK Broadband.
 */
package com.skb.adams.cm.d2f.common.constant;

import com.skb.adams.core.batch.common.constants.BatchConstants;

public class AppConstants extends BatchConstants {

    public static final String AUDIT_ID_COLLECT   = "CM-D2F-COLLECT";
    public static final String NBS_COLLECT_MODULE = "CmCollectTaskJob";
    
    public static final String SERVICE_FILE_NAME 	= "classpath:/persistence/batch_services.xml";
    public static final String MAPPER = "mapper";
    public static final String QID = "qid";
    public static final String QUERY = "query";

    public static final String THE_END = "The End";

    public static final String EXT_DAT = ".dat";
    public static final String EXT_CHK = ".chk";
    public static final String EXT_CSV = ".csv";

    public static final String APP_TITLE = "자료제공 CM 프로그램";

    public static enum COMMON_EXCEPTION {

        FILE_NOT_FOUND_SCHEDULE_IN(1000, "Nexcore scheduler argument file not found."),
        FILE_NOT_FOUND            (1002, "Target file not found."),
        CANT_ACCESS_SCHEDULE_IN   (1100, "Can't access to nexcore scheduler argument file."),
        CANT_ACCESS_SCHEDULE_OUT  (1101, "Can't access to nexcore scheduler result file."),
        UNDEFINED                 (9999, "Undefined exception: should set exception code.");

        /**
         * exceptionCode
         */
        private int exceptionCode = 0;

        /**
         * exceptionMessage
         */
        private String exceptionMessage = "";

        /**
         * COMMON_EXCEPTION
         *
         * @param exceptionCode
         * @param exceptionMessage
         */
        private COMMON_EXCEPTION(int exceptionCode, String exceptionMessage) {
            this.exceptionCode = exceptionCode;
            this.exceptionMessage = exceptionMessage;
        }

        /**
         * getExceptionCode
         *
         * @return int
         */
        public int getExceptionCode() {
            return exceptionCode;
        }

        /**
         * getExceptionMessage
         *
         * @return String
         */
        public String getExceptionMessage() {
            return exceptionMessage;
        }
    }

}
