/*
 * Copyright (c) 2016 SK Broadband.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with SK Broadband.
 */
package com.skb.adams.cm.d2f.common.constant;

public class NbsConstants {

    // NBS Parameters
    public static final String PARENT           = "PARENT.";
    public static final String TARGET_SYS_ID    = "ENV_TARGET_SYS_ID";
    public static final String FILE_WRITE_PATH  = "ENV_FILE_WRITE_PATH";
    public static final String EXP_TABLE_NAME   = "ENV_EXP_TABLE_NAME";
    public static final String QUERY_PARAM      = "ENV_QUERY_PARAM";
    public static final String DATETIME         = "DATETIME";
    public static final String PROC_DATE        = "PROC_DATE";
    public static final String SERVICE_NAME		= "SERVICE_NAME";
    public static final String FILE_NAME		= "ENV_FILE_NAME";
    public static final String DIR_PATH_YN 		= "ENV_DIR_CREATE_YN";
    public static final String USER_ID_LIST		= "ENV_USER_ID_LIST";
    public static final String JOBGROUP_ID		= "JOBGROUP_ID";
    public static final String TRANSACTION_TIMEOUT = "ENV_TRANSACTION_TIMEOUT";

    // JVM -D Options
    public static final String DB_PARALLEL_SIZE   = "db.parallel.size";
    public static final String DB_FETCH_SIZE      = "db.fetch.size";
    public static final String COL_SEPARATOR      = "col.separator";
    public static final String DATE_TYPE_FORMAT   = "date.type.format";
    public static final String FILE_WRITE_CHARSET = "file.write.charset";

    public static final String RUN_DATE_TIME    = "run.date.time";
    public static final String RUN_DATE_YM      = "run.date.ym";
    public static final String RUN_DATE_YMD     = "run.date.ymd";
    
    

}
