/*
 * Copyright (c) 2016 SK Broadband. All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with SK
 * Telecom.
 */
package com.skb.adams.cm.d2f.common.exception;

import java.util.Locale;

import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;

public class AdamsBizException extends BaseRuntimeException {

    private static final long serialVersionUID = -8034897190745766939L;

    public AdamsBizException(String message) {
        super(message);

        this.message = message;
    }

    /**
     * 직접 code와 message를 입력하는 생성자 (다국어 지원 하지 않음)
     *
     * @param messageCode
     * @param message
     * @param status
     * @param cause
     */
    public AdamsBizException(String messageCode, String message, int status, Throwable cause) {
        super(messageCode, message, status, cause);
    }

    /**
     * Message Bundle의 메세지를 이용한 Exception 처리 생성자
     *
     * @param messageSource
     * @param messageCode
     * @param status
     */
    public AdamsBizException(MessageSource messageSource, String messageCode, int status) {
        super(null, 0);
        super.messageSource = messageSource;
        String message = this.getMessage(messageCode);
        this.messageCode = messageCode;
        this.message = message;
        this.status = status;
    }

    /**
     * Message Bundle과 Message Parameter를 이용한 Exception 처리 생성자
     *
     * @param messageSource
     * @param messageCode
     * @param status
     * @param messageParameters
     */
    public AdamsBizException(MessageSource messageSource, String messageCode, int status,
    Object[] messageParameters) {
        super(null, 0);
        super.messageSource = messageSource;
        String message = this.getMessage(messageCode, messageParameters);

        this.messageCode = messageCode;
        this.message = message;
        this.status = status;
    }

    /**
     * Message Bundle의 메세지를 이용한 Exception 처리 생성자 with Locale
     *
     * @param messageSource
     * @param messageCode
     * @param status
     * @param locale
     */
    public AdamsBizException(MessageSource messageSource, String messageCode, int status, Locale locale) {
        super(null, 0);
        super.messageSource = messageSource;
        String message = this.getMessage(messageCode, locale);

        this.messageCode = messageCode;
        this.message = message;
        this.status = status;
    }

    /**
     *
     * meesage Bundle에서 key에 해당하는 메시지를 전달
     *
     * @param messageCode
     * @param messageParameters
     * @return String
     */
    private String getMessage(String messageCode, Object[] messageParameters) {
        Locale locale = Locale.getDefault();

        String message = null;

        try {
            message = super.messageSource.getMessage(messageCode, messageParameters, locale);
        } catch (NoSuchMessageException ex) {
            throw new RuntimeException(ex);
        }

        return message;
    }

    /**
     *
     * Message Bundle에서 key와 Locale에 해당하는 메시지를 전 달
     *
     * @param messageCode
     * @param locale
     * @return String
     */
    private String getMessage(String messageCode, Locale locale) {
        String message = null;

        try {
            message = super.messageSource.getMessage(messageCode, null, locale);
        } catch (NoSuchMessageException ex) {
            throw new RuntimeException(ex);
        }
        return message;
    }

    /**
     *
     * Message Bundle에서 key에 해당하는 메시지를 전달
     *
     * @param messageCode
     * @return String
     */
    private String getMessage(String messageCode) {
        Locale locale = Locale.getDefault();
        String message = getMessage(messageCode, locale);
        return message;
    }
}
