package com.skb.adams.cm.d2f.model;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.skb.adams.core.model.BaseAudit;

@SuppressWarnings("serial")
public class OCO30320VO extends BaseAudit {

    @Override
    public String toString() {
      return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
    }

    private String tblNm;                 /* 테이블명 */
    private String auditId;               /* 최종변경자ID */
    private String auditDtm;              /* 최종변경일시 */
    private String dataExtrtScopeClCd;    /* 데이터추출범위구분코드 */
    private String useYn;                 /* 사용여부 */
    private String aplyStaDt;             /* 적용시작일자 */
    private String aplyEndDt;             /* 적용종료일자 */
    /**
     * getter method for tblNm
     * @return the tblNm
     */
    public String getTblNm() {
        return tblNm;
    }
    /**
     * setter method for tblNm
     * @param tblNm the tblNm to set
     */
    public void setTblNm(String tblNm) {
        this.tblNm = tblNm;
    }
    /**
     * getter method for auditId
     * @return the auditId
     */
    public String getAuditId() {
        return auditId;
    }
    /**
     * setter method for auditId
     * @param auditId the auditId to set
     */
    public void setAuditId(String auditId) {
        this.auditId = auditId;
    }
    /**
     * getter method for auditDtm
     * @return the auditDtm
     */
    public String getAuditDtm() {
        return auditDtm;
    }
    /**
     * setter method for auditDtm
     * @param auditDtm the auditDtm to set
     */
    public void setAuditDtm(String auditDtm) {
        this.auditDtm = auditDtm;
    }
    /**
     * getter method for dataExtrtScopeClCd
     * @return the dataExtrtScopeClCd
     */
    public String getDataExtrtScopeClCd() {
        return dataExtrtScopeClCd;
    }
    /**
     * setter method for dataExtrtScopeClCd
     * @param dataExtrtScopeClCd the dataExtrtScopeClCd to set
     */
    public void setDataExtrtScopeClCd(String dataExtrtScopeClCd) {
        this.dataExtrtScopeClCd = dataExtrtScopeClCd;
    }
    /**
     * getter method for useYn
     * @return the useYn
     */
    public String getUseYn() {
        return useYn;
    }
    /**
     * setter method for useYn
     * @param useYn the useYn to set
     */
    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }
    /**
     * getter method for aplyStaDt
     * @return the aplyStaDt
     */
    public String getAplyStaDt() {
        return aplyStaDt;
    }
    /**
     * setter method for aplyStaDt
     * @param aplyStaDt the aplyStaDt to set
     */
    public void setAplyStaDt(String aplyStaDt) {
        this.aplyStaDt = aplyStaDt;
    }
    /**
     * getter method for aplyEndDt
     * @return the aplyEndDt
     */
    public String getAplyEndDt() {
        return aplyEndDt;
    }
    /**
     * setter method for aplyEndDt
     * @param aplyEndDt the aplyEndDt to set
     */
    public void setAplyEndDt(String aplyEndDt) {
        this.aplyEndDt = aplyEndDt;
    }

}
