/**
 * Copyright (c) 2018 SK Broadband. All right reserved.
 *
 * This software is the confidential and proprietary information of SK
 * Broadband. You shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement you entered
 * into with SK Broadband.
 */
package com.skb.adams.cm.d2f.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;

import org.apache.commons.io.output.FileWriterWithEncoding;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.google.common.primitives.Ints;
import com.skb.adams.cm.d2f.common.constant.AppConstants;
import com.skb.adams.cm.d2f.common.constant.Systems;
import com.skb.adams.cm.d2f.config.AdamsDBConfig;
import com.skb.adams.cm.d2f.model.CmParamVO;
import com.skb.adams.cm.d2f.model.CmResultVO;
import com.skb.adams.common.batch.dao.BatchJobLogDao;
import com.skb.adams.common.batch.model.BatchJobExecutionVO;
import com.skb.adams.core.batch.common.constants.BatchConstants;
import com.skb.adams.core.constant.LineConstants;
import com.skb.adams.core.exception.DbException;
import com.skb.adams.core.utils.CoreCommUtils;
import com.skb.adams.core.utils.CoreErrorUtils;
import com.skb.adams.core.utils.CoreFileUtils;
import com.skb.adams.core.utils.CoreTimeUtils;
import com.univocity.parsers.csv.CsvWriter;

@Service
@Scope(value=ConfigurableBeanFactory.SCOPE_PROTOTYPE, proxyMode=ScopedProxyMode.TARGET_CLASS)
public class CmCollecVoctBatchService {

    public final static Logger LOGGER = LoggerFactory.getLogger(CmCollecVoctBatchService.class);

    @Autowired
    private AdamsDBConfig adamsDBConfig = null;
    
    @Autowired
    BatchJobLogDao batchJobLogDao;

    private int fetchSize = 0;

    private Thread[] allThreads = new Thread[2];

    private Thread readerThread = null;
    private Thread writerThread = null;

    private BlockingQueue<Object> queue = null;

    private CmResultVO cmResult = new CmResultVO();
    
    private final static String programName = CmCollecVoctBatchService.class.getName();

    /**
     * write
     *
     * @param latch
     * @param cmParam
     * @return CmResultVO
     */
    public CmResultVO write(CountDownLatch latch, CmParamVO cmParam) {

        String sysIfName = cmParam.getSysIfName();

        LOGGER.info("■ [CM-BATCH][{}] MDC 파일명[{}]", sysIfName, cmParam.getLogFileName());

        MDC.put(cmParam.getMdcKey(), cmParam.getLogFileName());

        cmResult.targetSysId = cmParam.getTargetSysId();
        cmResult.sysIfName   = cmParam.getSysIfName();
        cmResult.fileNameCsv = cmParam.getFileNameCsv();
        cmResult.fileNameChk = cmParam.getFileNameChk();

        cmResult.procRtnCode = AppConstants.RETURN_CODE_INIT;

        cmResult.tableName = cmParam.getExpTableName();

        LOGGER.info("■");
        LOGGER.info("================================================================");
        LOGGER.info("■ [CM-BATCH][{}][{}] Data File 출력 수행합니다. [DB Fetch Size : {}]", sysIfName, cmParam.getFileNameCsv(), CoreCommUtils.formatComma(cmParam.getDbFetchSize()));
        LOGGER.info("================================================================");

        StopWatch stopWatch = new StopWatch();
        stopWatch.start();

        try {
            try {
                // Queue 생성
                createQueue(cmParam.getDbFetchSize());

                // DB 자료 Read Thread 실행
                startDbRead(cmParam);

                // File 생성 Write Thread 실행
                startFileWrite(cmParam);

            } catch (Throwable e) {
                stopThread();

                LOGGER.error(CoreErrorUtils.getStackTrace(e));

                cmResult.errException = e;
                cmResult.errMessage = e.getMessage();
           }

           // 전체 Thread 수행 완료 대기
           for (Thread thread : allThreads) {
                try {
                    thread.join();
                } catch (InterruptedException e) {
                    stopThread();
                }
           }

           // 완료 상태 설정
           if (cmResult.selectRtnCode == AppConstants.RETURN_CODE_OK && cmResult.writeRtnCode == AppConstants.RETURN_CODE_OK) {
               cmResult.procRtnCode = AppConstants.RETURN_CODE_OK;
           } else {
               cmResult.procRtnCode = AppConstants.RETURN_CODE_ERROR;
               throw new CmResultVO().errException;
           }
        } catch(Throwable e){
            LOGGER.error(CoreErrorUtils.getStackTrace(e));
            cmResult.procRtnCode = AppConstants.RETURN_CODE_ERROR;
        } finally {
            if (latch != null) {
                latch.countDown();
            }
        }

        stopWatch.stop();
        long term = stopWatch.getTotalTimeMillis();

        long seconds = term / 1000L;
        double loadTps = 0;
        if (seconds > 0) {
            loadTps = cmResult.writeCnt / seconds;
            loadTps = CoreTimeUtils.roundScale2(loadTps);
        }
        
        BatchJobExecutionVO batchJob = new BatchJobExecutionVO();
        
        String mergeStartTime = CoreTimeUtils.getDateTime("YYYYMMddHHmmss");
        
        batchJob.setOperExecDt (mergeStartTime);
		batchJob.setAuditId    ("D2F");		
        batchJob.setLogPrtPgmNm(programName);
    	batchJob.setClctFileNm(cmParam.getExpTableName());
    	batchJob.setStatus(BatchConstants.STARTED);
    	batchJob.setStatus     (BatchConstants.COMPLETED);
        batchJob.setCommitCount(cmResult.writeCnt);
          
        
    	// Merge 수행 이력 생성
    	try {
			batchJobLogDao.insertBatchJobExecution(batchJob);
		} catch (DbException e) {
			LOGGER.error("BATCH_LOG 기록중 오류 ");
		}
    	
    	
        LOGGER.info("■ [CM-BATCH][{}] Data File 출력 종료합니다.[총 소요시간 : {}][출력건수 : {}][TPS : {}][ProcRtnCode : {}][SelectRtnCode : {}][WriteRtnCode : {}]",
                    sysIfName,
                    CoreTimeUtils.getElapsedTime(term),
                    CoreCommUtils.formatComma(cmResult.writeCnt),
                    loadTps,
                    cmResult.procRtnCode,
                    cmResult.selectRtnCode,
                    cmResult.writeRtnCode);

        MDC.remove(cmParam.getMdcKey());

        return this.cmResult;
    }

    /**
     * startDbRead : DB Table Read
     *
     * @param cmParam
     * @param batchJob void
     */
    private void startDbRead(CmParamVO cmParam) {
        this.readerThread = new Thread("DB-READER") {
                                public void run() {
                                    MDC.put(cmParam.getMdcKey(), cmParam.getLogFileName());
                                    doDbRead(cmParam);
                                }
        };
        this.readerThread.setDaemon(false);
        this.readerThread.start();

        allThreads[0] = this.readerThread;
    }

    /**
     * startFileWrite : File Write
     *
     * @param cmParam void
     */
    private void startFileWrite(CmParamVO cmParam) {
        this.writerThread = new Thread("FILE-WRITER") {
                                public void run() {
                                    MDC.put(cmParam.getMdcKey(), cmParam.getLogFileName());
                                    doFileWrite(cmParam);
                                }
        };
        this.writerThread.setDaemon(false);
        this.writerThread.start();

        allThreads[1] = this.writerThread;
    }

    /**
     * createQueue
     *
     * @param commitInterval void
     */
    private void createQueue(int dbFetchSize) {
        // Blocking Queue 생성
        this.fetchSize = dbFetchSize;
        this.queue = new LinkedBlockingQueue<Object>(this.fetchSize + 100);
    }

    /**
     * connectDB : DB 연결(Pool 방식)
     *
     * @param commitInterval
     * @throws Exception void
     */
    private Connection connectDB() throws Exception {

        Class.forName(adamsDBConfig.getDriverClassName());

        Connection connection = DriverManager.getConnection(adamsDBConfig.getUrl(), adamsDBConfig.getUserName(), adamsDBConfig.getPassword());

        connection.setAutoCommit(true);
        connection.setReadOnly  (true);

        return connection;
    }

    /**
     * setupPrepareStmt
     *
     * @param con
     * @param cmParam
     * @return
     * @throws Exception PreparedStatement
     */
    public PreparedStatement setupPrepareStmt(Connection con, CmParamVO cmParam) throws Exception {

        int setReadCnt = 64;
        int fetchSize = cmParam.getDbFetchSize();

        // DB_FILE_MULTIBLOCK_READ_COUNT 변경(기본 : 16)
        Statement st = con.createStatement();
        st.execute("ALTER SESSION SET DB_FILE_MULTIBLOCK_READ_COUNT=" + setReadCnt);

        LOGGER.info("■ [CM-BATCH][{}] DB_FILE_MULTIBLOCK_READ_COUNT is changed ![16 -> {}]", cmParam.getSysIfName(), setReadCnt);
        LOGGER.info("■ [CM-BATCH][{}] DB_FETCH_SIZE[{}]",                                    cmParam.getSysIfName(), fetchSize);

        PreparedStatement ps = con.prepareStatement(cmParam.getSelectSql());
        ps.setFetchSize(fetchSize);
        String queryParam = cmParam.getQueryParam();
        LOGGER.info("queryParam : {}",queryParam);
        if(queryParam!=null)
        {
        	String[] arrQueryParam = queryParam.split(",");
        	for(int i=0;arrQueryParam.length>i;i++)
        	{
        		ps.setString(i+1, arrQueryParam[i]);
        	}
        }
        
        return ps;
    }

    /**
     * doDbRead : DB Read
     *   void
     */
    private void doDbRead(CmParamVO cmParam) {

        StopWatch stopWatch = new StopWatch();
        stopWatch.start();

        String sysIfName = cmParam.getSysIfName();

        cmResult.selectCnt = 0;
        cmResult.selectRtnCode = AppConstants.RETURN_CODE_INIT;

        LOGGER.info("■ [DB-READ][{}] DB select is started !", sysIfName);

        boolean isInterrupted = false;
        try (Connection con = connectDB();
             PreparedStatement ps = setupPrepareStmt(con, cmParam);
             ResultSet rs = ps.executeQuery();) {

             ResultSetMetaData rsmd = rs.getMetaData();
             int colCount = rsmd.getColumnCount();

             int idx = 0;
             int repPosition[] = new int[colCount];

             LOGGER.info("■ [DB-READ][{}] Table column count[{}]", sysIfName, colCount);

             // 문자형 컬럼인 경우에만 변환처리 수행을 위해 해당 위치를 보관(성능 고려)
             for (int i = 1; i <= colCount; i++) {
                 switch (rsmd.getColumnType(i)) {
                   case java.sql.Types.CHAR        :
                   case java.sql.Types.VARCHAR     :
                   case java.sql.Types.LONGVARCHAR :
                   case java.sql.Types.BLOB        :
                   case java.sql.Types.CLOB        : repPosition[idx] = i;
                                                     idx++;
                                                     break;
                   default : break;
                 }
             }

             // 처리할 Row 단위 정보 설정 및 Queue 추가
             if (Systems.DW_OCEAN.equals(cmParam.getTargetSysId())) {
                 while (rs.next() && !isInterrupted) {

                     String[] row = new String[colCount+3];

                     int rowLength = row.length;
                     for (int i = 0; i < rowLength; i++) {
                         row[i] = new String();
                     }

                     // 출력 라인 앞에 실행 년월일시분초 추가
                     row[0] = cmParam.getSpoolDatetime();

                     // DB 컬럼값 설정 : 컬럼 값에 Line 및 Column Separator 존재시, SPACE로 변환
                     int loopMax = row.length - 2;
                     for (int i = 1; i < loopMax; i++) {

                         Object obj = rs.getObject(i);
                         row[i] = String.valueOf(obj == null ? LineConstants.EMPTY : obj);

                         // 컬럼 값이 존재하는 경우에만 수행
                         if (CoreCommUtils.isNotEmpty(row[i])) {
                             // 문자형 컬럼인 경우에만 변환처리 수행
                             if (Ints.contains(repPosition, i)) {
                                 row[i] = row[i].replaceAll(AppConstants.CRLF + AppConstants.PIPELINE
                                                          + AppConstants.CR   + AppConstants.PIPELINE
                                                          + AppConstants.LF   + AppConstants.PIPELINE + AppConstants.STX, AppConstants.SPACE);
                             }
                         }
                     }

                     // DATA_CD 구분 값 설정(U : Update)
                     row[loopMax] = AppConstants.UPDATE;

                     // 출력 라인 뒤에 실행 년월일시분초 추가
                     row[loopMax + 1] = cmParam.getSpoolDatetime();

                     // Queue 전송
                     this.queue.put(row);
                    
                     cmResult.putCnt++;
                     cmResult.selectCnt ++;

                     if (Thread.currentThread().isInterrupted()) {
                         isInterrupted = true;
                         break;
                     }
                 }
             } else {
                 while (rs.next() && !isInterrupted) {

                     String[] row = new String[colCount];

                     // DB 컬럼값 설정 : 컬럼 값에 Line 및 Column Separator 존재시, SPACE로 변환
                     int rowLength = row.length;
                     for (int i = 0; i < rowLength; i++) {

                         Object obj = rs.getObject(i+1);
                         String replaceStr="";
                         row[i] = new String();
                         if(obj == null ){
                        	 replaceStr=LineConstants.EMPTY;
                         }else{
                        	 if(obj instanceof Clob){
                            	 replaceStr=  clobToString((Clob)obj);
                             }else{
                            	 replaceStr= String.valueOf(obj);
                             }
                         }
                         row[i] =replaceStr;

                         // 컬럼 값이 존재하는 경우에만 수행
                         if (CoreCommUtils.isNotEmpty(row[i])) {
                             // 문자형 컬럼인 경우에만 변환처리 수행
                             if (Ints.contains(repPosition, i)) {
                                 row[i] = row[i].replaceAll(AppConstants.LF + AppConstants.PIPELINE + AppConstants.STX, AppConstants.SPACE);
                             }
                         }
                     }

                     // Queue 전송
                     this.queue.put(row);

                     cmResult.putCnt++;
                     cmResult.selectCnt ++;

                     if (Thread.currentThread().isInterrupted()) {
                         isInterrupted = true;
                         break;
                     }
                 }
             }
             cmResult.selectRtnCode = AppConstants.RETURN_CODE_OK;
        } catch (Exception e) {
            cmResult.selectRtnCode = AppConstants.RETURN_CODE_ERROR;
            setErrorToLoadResult(String.format("[DB-READ][%s] Exception is occurred !", sysIfName), e);
        } finally {
            try {
                // 최종 File read 종료 Flag 전송
                this.queue.put(AppConstants.THE_END);
            } catch (Exception e) {
                cmResult.selectRtnCode = AppConstants.RETURN_CODE_ERROR;
                setErrorToLoadResult(String.format("[DB-READ][%s] Exception is occurred on putting The End flag !", sysIfName), e);
            }

            LOGGER.info("■ [DB-READ][{}] DB select is finished - Select[{}], Q Put[{}], selectRtnCode[{}], isInterrupted[{}]",
                    sysIfName,
                    CoreCommUtils.formatComma(cmResult.selectCnt),
                    CoreCommUtils.formatComma(cmResult.putCnt),
                    cmResult.selectRtnCode.getValue(),
                    isInterrupted);

            stopWatch.stop();
            long term = stopWatch.getTotalTimeMillis();

            long seconds = term / 1000L;
            double loadTps = 0;
            if (seconds > 0) {
                loadTps = cmResult.selectCnt / seconds;
                loadTps = CoreTimeUtils.roundScale2(loadTps);
            }

            LOGGER.info("■ [DB-READ][{}] DB Read 종료합니다.[조회 소요시간 : {}][조회건수 : {}][TPS : {}][SelectRtnCode : {}][isInterrupted : {}]",
                    sysIfName,
                    CoreTimeUtils.getElapsedTime(term),
                    CoreCommUtils.formatComma(cmResult.selectCnt),
                    loadTps,
                    cmResult.selectRtnCode.getValue(),
                    isInterrupted);

            if (cmResult.selectRtnCode != AppConstants.RETURN_CODE_OK) {
                // 전체 Thread 강제 종료처리 수행
                stopThread();
            }
        }
    }


    /**
     * doFileWrite - File Write
     *   void
     */
    private void doFileWrite(CmParamVO cmParam) {

        StopWatch stopWatch = new StopWatch();
        stopWatch.start();

        String sysIfName = cmParam.getSysIfName();

        LOGGER.info("[FILE-WRITE][{}] File write is started !", sysIfName);

        cmResult.writeCnt = 0;
        cmResult.writeRtnCode = AppConstants.RETURN_CODE_INIT;

        CsvWriter csvWriter = null;
        Object endFlag = new String(AppConstants.THE_END);

        boolean isInterrupted = false;
        List<Object> queueObjects = new ArrayList<>(this.fetchSize);

        try (Writer outputWriter = getWriter(cmParam);) {
             csvWriter = new CsvWriter(outputWriter, cmParam.getCsvSettings());

             boolean finished = false;
             while (!finished && !isInterrupted) {

                 if (Thread.currentThread().isInterrupted()) {
                     isInterrupted = true;
                     break;
                 }

                 // Queue Row 자료를 fetchSize만큼 Bulk 방식으로 추출
                 this.queue.drainTo(queueObjects, this.fetchSize);

                 LOGGER.info("doFileWrite	queueObjects:{}] !", queueObjects.toString());
                 for (Object row : queueObjects) {
                     // Queue 추출 값이 "The End"이면 Loop 종료
                     if (endFlag.equals(row)) {

                         LOGGER.info("■ [FILE-WRITE][{}][{}] File write is finished[endFlag:{}] !", sysIfName, cmParam.getFileNameCsv(), endFlag);
                         finished = true;
                     } else {
                         // File 출력
                         csvWriter.writeRow((String[]) row);
                         cmResult.writeCnt++;
                         if (Thread.currentThread().isInterrupted()) {
                             isInterrupted = true;
                             break;
                         }
                     }
                 }
                 if (queueObjects.size() > 0) queueObjects.clear();
             }
             cmResult.writeRtnCode = AppConstants.RETURN_CODE_OK;
        } catch (Exception e) {
            cmResult.writeRtnCode = AppConstants.RETURN_CODE_ERROR;
            setErrorToLoadResult(String.format("[FILE-WRITE][%s] Exception is occurred and rollbacked !", sysIfName), e);

        } finally {
            csvWriter.close();

            if (queueObjects.size() > 0) queueObjects.clear();

            LOGGER.info("■ [FILE-WRITE][{}] File write is finished - File[{}], Q Get[{}], Write[{}], WriteRtnCode[{}], isInterrupted[{}]",
                    sysIfName,
                    cmParam.getFileNameCsv(),
                    CoreCommUtils.formatComma(cmResult.selectCnt),
                    CoreCommUtils.formatComma(cmResult.writeCnt),
                    cmResult.writeRtnCode.getValue(),
                    isInterrupted);

            stopWatch.stop();
            long term = stopWatch.getTotalTimeMillis();

            long seconds = term / 1000L;
            double loadTps = 0;
            if (seconds > 0) {
                loadTps = cmResult.selectCnt / seconds;
                loadTps = CoreTimeUtils.roundScale2(loadTps);
            }

            LOGGER.info("■ [FILE-WRITE][{}] File 출력 종료합니다.[출력 소요시간 : {}][출력건수 : {}][TPS : {}][WriteRtnCode : {}][isInterrupted : {}]",
                    sysIfName,
                    CoreTimeUtils.getElapsedTime(term),
                    CoreCommUtils.formatComma(cmResult.writeCnt),
                    loadTps,
                    cmResult.writeRtnCode.getValue(),
                    isInterrupted);

            if (cmResult.writeRtnCode != AppConstants.RETURN_CODE_OK) {
                // 전체 Thread 강제 종료처리 수행
                stopThread();
            }
        }
    }

    public Writer getWriter(CmParamVO cmParam) throws IOException {

        String fileName = cmParam.getFileNameCsv();
        LOGGER.info("■ [FILE-WRITE] 출력 파일명 : {}", fileName);

        // File 출력 폴더 생성
        Files.createDirectories(Paths.get(CoreFileUtils.getFilePath(fileName)));

        Writer outputWriter = new BufferedWriter(new FileWriterWithEncoding(fileName, Charset.forName(cmParam.getCharSet())), 50 * 1024 * 1024);
        return outputWriter;
    }

    /**
     * setErrorToLoadResult : 오류 정보 설정
     *
     * @param message
     * @param e void
     */
    private void setErrorToLoadResult(String message, Exception e) {

        cmResult.errMessage   = message;
        cmResult.errException = e;

        LOGGER.error(message, e);
    }
    

    /**
     * stopThread - 전체 Thread 종료
     *   void
     */
    public void stopThread() {
        LOGGER.error("■ stopThread() - Exception 발생으로 인해 강제로 Thread 종료합니다. !");
        for (Thread thread : allThreads) {
             if (thread != null) thread.interrupt();
        }
    }
    private String clobToString(Clob clob) throws SQLException, IOException  {
    	StringBuilder resultBuilder = new StringBuilder();
    	Reader reader = null;
    	BufferedReader br = null;
    	try{
    		reader = clob.getCharacterStream();
    		br = new BufferedReader(reader);
    		String buffer=null;
    		
    		while(true){
    			buffer = br.readLine();
    			if(buffer ==null){
    				break;
    			}
    			resultBuilder.append(buffer);
    		}
    		
    	}catch(IOException e){
    		e.printStackTrace();
    		LOGGER.info("clobToString error : {}",e);
    	}finally{
    		if(reader != null){
    			reader.close();
    		}
    		if(br!=null){
    			br.close();
    		}
    	}
    	return resultBuilder.toString();
    }
   

}
