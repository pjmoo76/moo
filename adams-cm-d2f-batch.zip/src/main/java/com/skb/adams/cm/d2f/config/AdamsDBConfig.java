/*
 * Copyright (c) 2016 SK Broadband.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with SK Broadband.
 */
package com.skb.adams.cm.d2f.config;

import java.io.IOException;

import javax.sql.DataSource;

import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import com.skb.adams.core.utils.CoreErrorUtils;
import com.skb.adams.cm.d2f.common.constant.AppConstants;

@Configuration
@PropertySources({@PropertySource("classpath:/properties/dbms.properties")})
public class AdamsDBConfig {
    /**
     * logger
     */
    protected static final Logger LOGGER = LoggerFactory.getLogger(AdamsDBConfig.class);

    /**
     * userName
     */
    @Value("${adams.jdbc.username}")
    private String userName = "";

    /**
     * password
     */
    @Value("${adams.jdbc.password}")
    private String password = "";

    /**
     * url
     */
    @Value("${adams.jdbc.url}")
    private String url = "";

    /**
     * driverClassName
     */
    @Value("${adams.jdbc.driverClassName}")
    private String driverClassName= "";

    /**
     * testQuery
     */
    @Value("${adams.jdbc.validationQuery}")
    private String validationQuery = "";

    /**
     * timeBetweenEvictionRunsMillis
     */
    @Value("${adams.jdbc.timeBetweenEvictionRunsMillis}")
    private long timeBetweenEvictionRunsMillis = 300000;

    /**
     * numTestsPerEvictionRun
     */
    @Value("${adams.jdbc.numTestsPerEvictionRun}")
    private int numTestsPerEvictionRun = 3;

    /**
     * initialSize
     */
    @Value("${adams.jdbc.initial.size}")
    private int initialSize = 1;

    /**
     * minIdle
     */
    @Value("${adams.jdbc.minIdle}")
    private int minIdle = 1;

    /**
     * maxIdle
     */
    @Value("${adams.jdbc.maxIdle}")
    private int maxIdle = 1;

    /**
     * maxActive
     */
    @Value("${adams.jdbc.maxActive}")
    private int maxActive = 1;

    /**
     * defaultTransactionTimeout
     */
    @Value("${adams.transaction.default.timeout}")
    private Integer defaultTransactionTimeout = 0;

    /**
     * sqlMapperLocation
     */
    @Value("${adams.mybatis.sql.mapper.location}")
    private String sqlMapperLocation = "";

    /**
     * sqlConfigLocation
     */
    @Value("${adams.mybatis.sql.config.location}")
    private String sqlConfigLocation = "";

    /**
     * defaultFetchSize
     */
    @Value("${adams.default.fetch.size}")
    private int defaultFetchSize = 50000;

    /**
     * defaultBatchSize
     */
    @Value("${adams.default.batch.size}")
    private int defaultBatchSize = 50000;

    /**
     * defaultAutoCommit
     */
    @Value("${adams.default.auto.commit}")
    private boolean defaultAutoCommit = false;

    @Value("${app.module.type}")
    private String appModuleType = null;

    /**
     * getter method for defaultFetchSize
     * @return the defaultFetchSize
     */
    public int getDefaultFetchSize() {
        return defaultFetchSize;
    }

    /**
     * setter method for defaultFetchSize
     * @param defaultFetchSize the defaultFetchSize to set
     */
    public void setDefaultFetchSize(int defaultFetchSize) {
        this.defaultFetchSize = defaultFetchSize;
    }

    /**
     * getter method for defaultBatchSize
     * @return the defaultBatchSize
     */
    public int getDefaultBatchSize() {
        return defaultBatchSize;
    }

    /**
     * setter method for defaultBatchSize
     * @param defaultBatchSize the defaultBatchSize to set
     */
    public void setDefaultBatchSize(int defaultBatchSize) {
        this.defaultBatchSize = defaultBatchSize;
    }

    /**
     * getter method for defaultAutoCommit
     * @return the defaultAutoCommit
     */
    public boolean isDefaultAutoCommit() {
        return defaultAutoCommit;
    }

    /**
     * setter method for defaultAutoCommit
     * @param defaultAutoCommit the defaultAutoCommit to set
     */
    public void setDefaultAutoCommit(boolean defaultAutoCommit) {
        this.defaultAutoCommit = defaultAutoCommit;
    }

    /**
     * getter method for userName
     * @return the userName
     */
    public String getUserName() {
        return userName;
    }

    /**
     * setter method for userName
     * @param userName the userName to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * getter method for password
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * setter method for password
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * getter method for url
     * @return the url
     */
    public String getUrl() {
        return url;
    }

    /**
     * setter method for url
     * @param url the url to set
     */
    public void setUrl(String url) {
        this.url = url;
    }

    /**
     * getter method for driverClassName
     * @return the driverClassName
     */
    public String getDriverClassName() {
        return driverClassName;
    }

    /**
     * setter method for driverClassName
     * @param driverClassName the driverClassName to set
     */
    public void setDriverClassName(String driverClassName) {
        this.driverClassName = driverClassName;
    }

    /**
     * getter method for validationQuery
     * @return the validationQuery
     */
    public String getValidationQuery() {
        return validationQuery;
    }

    /**
     * setter method for validationQuery
     * @param validationQuery the validationQuery to set
     */
    public void setValidationQuery(String validationQuery) {
        this.validationQuery = validationQuery;
    }

    /**
     * getter method for maxActive
     * @return the maxActive
     */
    public int getMaxActive() {
        return maxActive;
    }

    /**
     * setter method for maxActive
     * @param maxActive the maxActive to set
     */
    public void setMaxActive(int maxActive) {
        this.maxActive = maxActive;
    }

    /**
     * getter method for initialSize
     * @return the initialSize
     */
    public int getInitialSize() {
        return initialSize;
    }

    /**
     * setter method for initialSize
     * @param initialSize the initialSize to set
     */
    public void setInitialSize(int initialSize) {
        this.initialSize = initialSize;
    }

    /**
     * getter method for minIdle
     * @return the minIdle
     */
    public int getMinIdle() {
        return minIdle;
    }

    /**
     * setter method for minIdle
     * @param minIdle the minIdle to set
     */
    public void setMinIdle(int minIdle) {
        this.minIdle = minIdle;
    }

    /**
     * getter method for defaultTransactionTimeout
     * @return the defaultTransactionTimeout
     */
    public Integer getDefaultTransactionTimeout() {
        return defaultTransactionTimeout;
    }

    /**
     * setter method for defaultTransactionTimeout
     * @param defaultTransactionTimeout the defaultTransactionTimeout to set
     */
    public void setDefaultTransactionTimeout(Integer defaultTransactionTimeout) {
        this.defaultTransactionTimeout = defaultTransactionTimeout;
    }

    /**
     * getter method for sqlMapperLocation
     * @return the sqlMapperLocation
     */
    public String getSqlMapperLocation() {
        return sqlMapperLocation;
    }

    /**
     * setter method for sqlMapperLocation
     * @param sqlMapperLocation the sqlMapperLocation to set
     */
    public void setSqlMapperLocation(String sqlMapperLocation) {
        this.sqlMapperLocation = sqlMapperLocation;
    }

    /**
     * getter method for sqlConfigLocation
     * @return the sqlConfigLocation
     */
    public String getSqlConfigLocation() {
        return sqlConfigLocation;
    }

    /**
     * setter method for sqlConfigLocation
     * @param sqlConfigLocation the sqlConfigLocation to set
     */
    public void setSqlConfigLocation(String sqlConfigLocation) {
        this.sqlConfigLocation = sqlConfigLocation;
    }

    /**
     * dataSource - DataSource 연결정보 설정
     * 참고 : (('IDC 정책에서 허용하는 최대 유휴 Connection 유지시간' / timeBetweenEvictionRunsMillis 속성값) * numTestsPerEvictionRun 속성값) > 전체 Connection 개수)
     *
     * @return DataSource
     * @throws ClassNotFoundException
     */
    @Bean(destroyMethod = "close")
    public BasicDataSource dataSource() throws ClassNotFoundException {

        BasicDataSource dataSource = new BasicDataSource();

        dataSource.setDriverClassName(this.driverClassName);
        dataSource.setUrl            (this.url);
        dataSource.setUsername       (this.userName);
        dataSource.setPassword       (this.password);

        dataSource.setValidationQuery(this.validationQuery);

        dataSource.setTestOnBorrow (false);
        dataSource.setTestOnReturn (false);

        // 일정 시간 간격으로 DB Connection Test 수행(select 1 from dual 문장 수행)
        dataSource.setTestWhileIdle(true);
        dataSource.setTimeBetweenEvictionRunsMillis(timeBetweenEvictionRunsMillis);

        // DB Connection Test 수행 Connection 수
        dataSource.setNumTestsPerEvictionRun(numTestsPerEvictionRun);

        // Evictor 스레드 동작시, Connection의 유휴 시간을 확인하여 설정 값이상인 경우, Connection을 제거(-1 : 기능 제외)
        dataSource.setMinEvictableIdleTimeMillis(-1);

        LOGGER.info("■ Application module type : {}", appModuleType);

        // Daemon 형태로 수행되는 경우에만 DB Pool 방식 사용
        if (AppConstants.DAEMON.equalsIgnoreCase(appModuleType)) {
            dataSource.setInitialSize(this.initialSize);
            dataSource.setMinIdle    (this.minIdle);
            dataSource.setMaxIdle    (this.maxIdle);
            dataSource.setMaxTotal   (this.maxActive);
        }

        return dataSource;
    }

    /**
    *
    * transactionManager(Default 트랜잭션 매니저 설정)
    *
    * @param dataSource
    * @return DataSourceTransactionManager
    */
   @Primary
   @Bean(name = "transactionManager")
   public DataSourceTransactionManager transactionManager(DataSource dataSource) {
       DataSourceTransactionManager dataSourceTransactionManager = new DataSourceTransactionManager(dataSource);
       if(defaultTransactionTimeout > 0) {
           dataSourceTransactionManager.setDefaultTimeout(defaultTransactionTimeout);
       }
       return dataSourceTransactionManager;
   }

   /**
    * sqlSessionTemplate
    *
    * @return
    * @throws Exception SqlSessionTemplate
    */
   @Bean(destroyMethod = "clearCache")
   public SqlSessionTemplate sqlSessionTemplate() throws Exception {
       return new SqlSessionTemplate(this.sqlSessionFactory(), ExecutorType.SIMPLE);
   }

   /**
    * sqlSessionFactory - Mybatis 연결 설정
    *
    * @return
    * @throws Exception SqlSessionFactory
    */
   @Bean
   public SqlSessionFactory sqlSessionFactory() throws Exception {

       SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();
       sessionFactory.setDataSource(this.dataSource());

       try {
            LOGGER.info("■ sqlSessionFactory() : sqlMapperLocation : {}", this.sqlMapperLocation);
            LOGGER.info("■ sqlSessionFactory() : sqlConfigLocation : {}", this.sqlConfigLocation);

            // Mybatis 구성 설정
            sessionFactory.setMapperLocations(new PathMatchingResourcePatternResolver().getResources(this.sqlMapperLocation));
            sessionFactory.setConfigLocation (new PathMatchingResourcePatternResolver().getResource (this.sqlConfigLocation));

            return sessionFactory.getObject();
       } catch (Exception e) {
            LOGGER.error(CoreErrorUtils.getStackTrace(e));
            throw new IOException(e);
       }
   }

}
