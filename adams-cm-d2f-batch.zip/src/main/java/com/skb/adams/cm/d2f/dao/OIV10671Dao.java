/*
 * Copyright (c) 2018 SK Broadband.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with SK Broadband.
 */
package com.skb.adams.cm.d2f.dao;

import org.springframework.stereotype.Repository;

import com.skb.adams.core.batch.dao.BaseDao;

@Repository
public class OIV10671Dao extends BaseDao {
	/**
	 * SQL_NAMESPACE
	 */
	private static final String SQL_NAMESPACE = "com.skb.adams.cm.d2f.dao.OIV10671Dao.";

	public String getOIV10660(){
    	
    	
    	String  result = sqlSessionTemplate.selectOne(SQL_NAMESPACE+"SELECT_OIV10660");
    	
		return result;
    	
    }
    

    
    public String getBatchJob(String jobId){
        
    	String  result = sqlSessionTemplate.selectOne(SQL_NAMESPACE+"SELECT_BATCH_JOB_EXECUTION_PARAM",jobId);
    	
    	
		return result;
    	
    }
    
    public String getE2ePostworkCheck(){
        
    	String  result = sqlSessionTemplate.selectOne(SQL_NAMESPACE+"SELECT_OCO30341_E2EPOSTWORK", null);
    	
    	
		return result;
    	
    }
	
	

}
