/*
 * Copyright (c) 2018 SK Broadband.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with SK Broadband.
 */
package com.skb.adams.cm.d2f.common.constant;

public class NotifyCodeConstants {

    // OCO40290 Table 참고
    public static final String DEFAULT  = "DEFTL001";   // Default Code

}
