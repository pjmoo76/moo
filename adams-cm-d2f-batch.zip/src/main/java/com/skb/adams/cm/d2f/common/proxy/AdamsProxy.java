/*
 * Copyright (c) 2018 SK Broadband.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with SK Broadband.
 */
package com.skb.adams.cm.d2f.common.proxy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.skb.adams.common.notify.model.SystemNotifyVO;
import com.skb.adams.common.proxy.rest.RestProxy;
import com.skb.adams.core.model.ResultObject;
import com.skb.adams.core.utils.CoreCommUtils;
import com.skb.adams.core.utils.CoreErrorUtils;
import com.skb.adams.core.utils.CoreNetUtils;
import com.skb.adams.core.utils.CoreTimeUtils;
import com.skb.adams.cm.d2f.common.constant.AppConstants;
import com.skb.adams.micro.rest.http.HttpResponse;
import com.skb.adams.micro.rest.http.JsonNode;

@Component
public class AdamsProxy {

    protected final Logger LOGGER = LoggerFactory.getLogger(getClass());

    private static final String ERROR_OCCURRED = "오류 발생";

    @Value("${project.module}")
    private String projectModule = null;

    // SMS 전송 IP
    @Value("#{'${biz.service.sms.ip}'.split(',')}")
    private String[] bizServiceSmsIp = null;

    // SMS 전송 URL
    @Value("${biz.service.sms.url}")
    private String bizServiceSmsUrl = null;

    @Autowired
    private RestProxy restProxy = null;

    /**
     * sendErrorSms : 오류 메시지 SMS 전송
     *
     * @param msg
     * @return ResultObject
     */
    @Async
    public ResultObject sendErrorSms(String jobGroupId, String msg) {
        msg = CoreNetUtils.getLocalHostName() + AppConstants.SPACE + projectModule
                                              + AppConstants.SPACE + msg + AppConstants.SPACE + ERROR_OCCURRED
                                              + AppConstants.SPACE + CoreTimeUtils.getDateTime("(MM/dd HH:mm)");
        return sendSms(jobGroupId, msg);
    }

    /**
     * sendSms : 비동기 SMS 전송
     *
     * @param obj
     * @return ResultObject
     */
    @Async
    public ResultObject sendSms(String jobGroupId, String msg) {
        ResultObject result = new ResultObject();
        
        LOGGER.info("■ SMS 전송내용 : " + msg);
        
        SystemNotifyVO systemNotifyVO = new SystemNotifyVO();
        systemNotifyVO.setMsgCttAppendText(msg);
        
        if(jobGroupId.contains("sysinfo")) {
        	systemNotifyVO.setMsgTrmsId("DEFTL012");
        }

        for(String smsIp : bizServiceSmsIp) {
            try {
                // SMS 전송 API 호출
                HttpResponse<JsonNode> httpRes = restProxy.send(String.format(bizServiceSmsUrl, smsIp.trim()), systemNotifyVO);

                LOGGER.info("■ SMS 전송결과 : " + httpRes.getBody());
                result = (ResultObject) CoreCommUtils.toObj(httpRes.getBody().toString(), ResultObject.class);
                if (result.getReturnCode() == AppConstants.SERVICE_SUCCESS) {
                    break;
                }
            } catch (Exception e) {
                LOGGER.error(CoreErrorUtils.getStackTrace(e));
                LOGGER.error("■ SMS 전송 Exception 발생 : 업무처리 계속 진행합니다. !");
            }
        }
        return result;
    }
}
