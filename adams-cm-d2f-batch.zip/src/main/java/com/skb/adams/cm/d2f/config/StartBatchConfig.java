/*
 * Copyright (c) 2016 SK Broadband.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with SK Broadband.
 */
package com.skb.adams.cm.d2f.config;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.skb.adams.core.batch.config.AspectConfig;
import com.skb.adams.core.batch.config.BatchConfig;
import com.skb.adams.core.utils.CoreCommUtils;

@EnableTransactionManagement
@Configuration
@Import({
         AspectConfig.class,               // adams-core-framework-batch
         BatchConfig.class,                // adams-core-framework-batch
         AdamsDBConfig.class,
         MessageConfig.class
        })
@ComponentScan(
               basePackages={"com.skb.adams.core.batch", "com.skb.adams.common", "com.skb.adams.cm"}
              )
@PropertySources({
                  @PropertySource("classpath:/properties/application.properties"),
                  @PropertySource("classpath:/properties/nexcore.properties"),
                  @PropertySource("classpath:/properties/project.properties"),
                  @PropertySource("classpath:/properties/adamsproxy.properties")
                 })
public class StartBatchConfig {

    // 시스템 속성 출력 여부(application.properties 참고)
    @Value("${app.print.system.properties.enabled}")
    private boolean appPrintSystemPropertiesEnabled = false;

    @Bean
    public static PropertySourcesPlaceholderConfigurer properties() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    /**
     * printSystemProperties : 시스템 속성 값 출력
     *   void
     */
    @PostConstruct
    public void printSystemProperties() {
        if (appPrintSystemPropertiesEnabled) {
            CoreCommUtils.printSystemProperties();
        }
    }

    /**
     * getter method for appPrintSystemPropertiesEnabled
     * @return the appPrintSystemPropertiesEnabled
     */
    public boolean isAppPrintSystemPropertiesEnabled() {
        return appPrintSystemPropertiesEnabled;
    }

    /**
     * setter method for appPrintSystemPropertiesEnabled
     * @param appPrintSystemPropertiesEnabled the appPrintSystemPropertiesEnabled to set
     */
    public void setAppPrintSystemPropertiesEnabled(
            boolean appPrintSystemPropertiesEnabled) {
        this.appPrintSystemPropertiesEnabled = appPrintSystemPropertiesEnabled;
    }

}
