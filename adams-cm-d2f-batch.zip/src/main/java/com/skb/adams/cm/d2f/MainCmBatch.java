/*
 * Copyright (c) 2016 SK Broadband.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with SK Broadband.
 */
package com.skb.adams.cm.d2f;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import com.skb.adams.cm.d2f.common.constant.NbsConstants;
import com.skb.adams.cm.d2f.config.StartBatchConfig;
import com.skb.adams.core.batch.BaseBatchMain;
import com.skb.adams.core.batch.common.utils.NexcoreSupport;
import com.skb.adams.core.batch.config.BatchConfig;

public class MainCmBatch extends BaseBatchMain {

	/**
	 * main : 일반 Java main() 함수
	 *
	 * @param args
	 * @throws Exception void
	 */
	public static void main(String[] args) throws Exception {

		BatchConfig batchConfig = null;
		int transactionTimeout = 0;
		
		context = new AnnotationConfigApplicationContext(StartBatchConfig.class);
		
		batchConfig = (BatchConfig) context.getBean("batchConfig");
		batchConfig.loadConfig();
		String time = NexcoreSupport.readJobArguments(batchConfig).get(NbsConstants.TRANSACTION_TIMEOUT);
		System.out.println(time);
		System.out.println(time==null);
		System.out.println("".equals(time));
		LOGGER.info("[main] ARGUMENT로 입력된 ENV_TRANSACTION_TIMEOUT값 : [{}]", NexcoreSupport.readJobArguments(batchConfig).get(NbsConstants.TRANSACTION_TIMEOUT));
		
		try {
			transactionTimeout = Integer.parseInt(NexcoreSupport.readJobArguments(batchConfig).get(NbsConstants.TRANSACTION_TIMEOUT));
		} catch(Exception e) {
			transactionTimeout = ((DataSourceTransactionManager)context.getBean("transactionManager")).getDefaultTimeout();
		}

		if(transactionTimeout > 0) {
			((DataSourceTransactionManager)context.getBean("transactionManager")).setDefaultTimeout(transactionTimeout);
		}
		
		LOGGER.info("[main] 실제 적용되는 TRANSACTION_TIMEOUT값 : [{}]", ((DataSourceTransactionManager)context.getBean("transactionManager")).getDefaultTimeout());
		
		/**
		 * NBS UI 화면에서 사용자가 Job 파라미터인 EXEC_JOB_NAME에 설정한 명칭에 해당하는 Spring Bean을 조회하여 서비스를 수행
		 * - Input Parameter File을 읽어 Framework이 알아서 처리함
		 */
		if (System.getProperty("os.name").indexOf("nux") >= 0) {
		    // Server 환경 수행
		    runBatchJob(context);
		} else {
            // Local 환경 수행 : job.general 폴더의 TaskJob.java 파일명 지정(Jar 파일을 PC Client에서 직접 수행은 불가)
		    runBatchJob(context, "CmCollectE2ETaskJob", false, "src/main/resources/parameter/NBS_PIN_FILE.in", "src/main/resources/parameter/NBS_POUT_FILE.out");
		}
	}
}
