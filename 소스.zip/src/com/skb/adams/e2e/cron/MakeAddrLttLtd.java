package com.skb.adams.e2e.cron;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import subkjh.bas.dao.control.DaoListener;

import com.skb.adams.e2e.dao.AddrDao;
import com.skb.adams.e2e.function.GoogleMap;
import com.skb.adams.e2e.model.AddrVo;
import com.skb.adams.e2e.model.FX_TMP_LTT_LTD;

import fxms.bas.cron.Crontab;

/**
 * 주소 기준으로 위도 경도를 구하는 CRON
 * 
 * @author SUBKJH-DEV
 *
 */
public class MakeAddrLttLtd extends Crontab {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8888971852415685469L;

	public static void main(String[] args) {
		MakeAddrLttLtd maker = new MakeAddrLttLtd();
		try {
			maker.cron();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void cron() throws Exception {

		List<FX_TMP_LTT_LTD> valList = new ArrayList<FX_TMP_LTT_LTD>();
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		AddrDao dao = new AddrDao();
		GoogleMap api = new GoogleMap();

		DaoListener listener = new DaoListener() {

			@Override
			public void onExecuted(Object arg0, Exception arg1)
					throws Exception {

			}

			@Override
			public void onFinish(Exception arg0) throws Exception {
				if (valList.size() > 0) {
					dao.insert(valList);
				}

			}

			@Override
			public void onSelected(int arg0, Object arg1) throws Exception {
				AddrVo vo = (AddrVo) arg1;

				FX_TMP_LTT_LTD val = api.callNaver(vo.getAddress());
				if (val == null) {
					val = api.callGoogle(vo.getAddress());
				}

				if (val == null) {
					val = new FX_TMP_LTT_LTD();
					val.setRsltVal("0");
				} else {
					val.setRsltVal("1");
				}

				val.setAuditId("SKAdams_subkjh");
				val.setAuditDtm(timestamp);
				val.setAddrId(vo.getAddrId());
				val.setBldblkNum(0);

				valList.add(val);

				if (valList.size() > 20) {
					dao.insert(valList);
					valList.clear();
				}
			}

			@Override
			public void onStart(String[] arg0) throws Exception {

			}

		};

		dao.delete();
		dao.getAddrList(listener);
		dao.merge();

	}

	@Override
	public String getGroup() {
		return null;
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}

}
