package com.skb.adams.e2e.dao;

/**
* File : e2e/e2e.xml<br>
* @since 20190319111843
* @author subkjh 
*
*/


public class E2eQid { 

/** 쿼리 모임 화일명. e2e/e2e.xml*/
public static final String QUERY_XML_FILE = "e2e/e2e.xml";

public E2eQid() { 
} 
/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * delete <br>		from 	FX_TMP_LTT_LTD <br>		where 	RSLT_VAL = '0' <br>
*/
public final String DELETE_FX_TMP_LTT_LTD__BY_ERR = "DELETE_FX_TMP_LTT_LTD__BY_ERR";

/**
* para : $getAddrId(), $getBldblkNum(), $getLttVal(), $getLtdVal(), $getRsltVal(), $getAuditId(), $getAuditDtm()<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into FX_TMP_LTT_LTD (<br>			ADDR_ID<br>			, BLDBLK_NUM<br>			, LTT_VAL<br>			, LTD_VAL<br>			, RSLT_VAL<br>			, AUDIT_ID<br>			, AUDIT_DTM<br>		) values (<br>			$getAddrId()<br>			, $getBldblkNum()<br>			, $getLttVal()<br>			, $getLtdVal()<br>			, $getRsltVal()<br>			, $getAuditId()<br>			, $getAuditDtm()<br>		) <br>
*/
public final String INSERT_FX_TMP_LTT_LTD = "INSERT_FX_TMP_LTT_LTD";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * merge into <br>			OIV10641 a<br>  			using ( <br>    				select 	s3.equip_id<br>    						, s1.ltt_val<br>    						, s1.ltd_val<br>    						, s4.ldong_cd<br>    				from 	fx_tmp_ltt_ltd s1<br>        					, oiv10300 s2<br>							, oiv10100 s3<br>        					, oes30100 s4<br>    				where 	s1.rslt_val = '1'<br>    				and 	s1.addr_id = s2.addr_id<br>    				and 	s2.tpo_cd = s3.tpo_cd<br>    				and 	s4.addr_id = s2.addr_id<br>    				-- and 	s3.equip_usg_cd in ( 'H001', 'H002')<br>    				and		s3.equip_nm like '%OLT%'<br>  			) b<br>  		on ( a.equip_id = b.equip_id )<br>  		when matched then<br>      			update set <br>						ltt_val = b.ltt_val<br>						, ltd_val = b.ltd_val<br>						, ldong_cd = b.ldong_cd<br>						, audit_id = 'SKAdams_subkjh'<br>						, audit_dtm = sysdate<br>  		when not matched then<br>				insert ( <br>						equip_id<br>						, audit_id<br>						, audit_dtm<br>						, ltt_val<br>						, ltd_val<br>						, ldong_cd<br>				) values (<br>						b.equip_id<br>						, 'SKAdams_subkjh'<br>						, sysdate<br>						, b.ltt_val<br>						, b.ltd_val<br>						, b.ldong_cd<br>          		) <br>
*/
public final String MERGE_OIV10641 = "MERGE_OIV10641";

/**
* para : $getEquipId(), $getEquipNm(), $getEquipSysNm(), $getEquipTidVal(), $getEquipIpAddr(), $getIfId(), $getIfNm(), $getIfIpAddr(), $getIfDesc(), $getEquipId2(), $getEquipNm2(), $getEquipSysNm2(), $getEquipTidVal2(), $getEquipIpAddr2(), $getIfId2(), $getIfNm2(), $getIfIpAddr2(), $getIfDesc2(), $getDetectType()<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into FX_TMP_E2E (<br>			EQUIP_ID<br>			, EQUIP_NM<br>			, EQUIP_SYS_NM<br>			, EQUIP_TID_VAL<br>			, EQUIP_IP_ADDR<br>			, IF_ID<br>			, IF_NM<br>			, IF_IP_ADDR<br>			, IF_DESC<br>			, EQUIP_ID2<br>			, EQUIP_NM2<br>			, EQUIP_SYS_NM2<br>			, EQUIP_TID_VAL2<br>			, EQUIP_IP_ADDR2<br>			, IF_ID2<br>			, IF_NM2<br>			, IF_IP_ADDR2<br>			, IF_DESC2<br>			, DETECT_TYPE<br>		) values (<br>			$getEquipId()<br>			, $getEquipNm()<br>			, $getEquipSysNm()<br>			, $getEquipTidVal()<br>			, $getEquipIpAddr()<br>			, $getIfId()<br>			, $getIfNm()<br>			, $getIfIpAddr()<br>			, $getIfDesc()<br>			, $getEquipId2()<br>			, $getEquipNm2()<br>			, $getEquipSysNm2()<br>			, $getEquipTidVal2()<br>			, $getEquipIpAddr2()<br>			, $getIfId2()<br>			, $getIfNm2()<br>			, $getIfIpAddr2()<br>			, $getIfDesc2()<br>			, $getDetectType()<br>		) <br>
*/
public final String QID_INSERT_E2E = "QID_INSERT_E2E";

/**
* para : <br>
* result : RESULT_ADDRVO=com.skb.adams.e2e.model.AddrVo<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * select 	b.addr_id<br>      			, c.Ct_Pvc_Nm || ' ' || c.Ct_Gun_Gu_Nm || ' ' || c.Up_Myun_Dong_Nm <br>        			|| decode( C.Ri_Nm, ' ', '', '', '', ' ' || C.Ri_Nm )<br>        			|| ' ' || decode(B.Main_House_Num_Ctt, '0', '', '99999', '',  B.Main_House_Num_Ctt || decode(B.Sub_House_Num_Ctt, '0', '', '99999', '', '-' || B.Sub_House_Num_Ctt))<br>        			as "ADDRESS"<br>		from 	OES30100 b ' 주소기본 '<br>				, OES30300 c ' 법정동 기본 '<br>		where exists ( 	select 1 <br>						from 	oiv10100 eqp<br>								, oiv10300 tpo <br>						where 	eqp.del_yn = 'N' <br>						and 	eqp.tpo_cd = tpo.tpo_cd <br>						and 	tpo.addr_id = b.addr_id <br>						-- and 	eqp.equip_usg_cd in ( 'H001', 'H002') <br>						and 	eqp.equip_nm like '%OLT%'<br>					)<br>		and not exists ( select 1 <br>						from 	FX_TMP_LTT_LTD ar <br>						where 	ar.addr_id = b.addr_id <br>						and 	ar.rslt_val = '1' <br>					)<br>		and b.eff_end_dt > '20190319'<br>		and c.ldong_cd = b.ldong_cd <br>
*/
public final String QID_SELECT_ADDRESS = "QID_SELECT_ADDRESS";

/**
* para : <br>
* result : RESULT_IFVO=com.skb.adams.e2e.model.IfVo<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * select 	a.equip_id<br>				, a.equip_port_id<br>				, a.if_id<br>				, a.if_nm<br>				, a.ip_addr<br>				, a.if_desc<br>				, a.rep_port_nw_addr<br>				, a.rep_port_sbnt_msk_addr <br>				, b.equip_nm<br>				, b.equip_tid_val<br>		from 	oiv10500 a<br>				, oiv10100 b<br>		where 	a.rep_port_nw_addr is not null<br>		and 	b.equip_id = a.equip_id<br>		order by <br>				a.rep_port_nw_addr<br>				, a.ip_addr <br>
*/
public final String QID_SELECT_IF_NETWORK__MSKADDR = "QID_SELECT_IF_NETWORK__MSKADDR";

/**
* para : <br>
* result : RESULT_IFVO=com.skb.adams.e2e.model.IfVo<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * select 	a.equip_id<br>				, a.equip_port_id<br>				, a.if_id<br>				, a.if_nm<br>				, a.ip_addr<br>				, a.if_desc<br>				, a.rep_port_nw_addr<br>				, a.rep_port_sbnt_msk_addr <br>				, b.equip_nm <br>				, b.equip_tid_val<br>				, b.equip_ip_addr<br>		from 	oiv10500 a<br>				, oiv10100 b<br>		where 	a.ip_addr is not null<br>		and		a.equip_if_typ_cd = '6'<br>		and 	b.equip_id = a.equip_id<br>		order by ip_addr <br>
*/
public final String QID_SELECT_IF_NETWORK__MSKADDR2 = "QID_SELECT_IF_NETWORK__MSKADDR2";

}