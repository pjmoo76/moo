package com.skb.adams.e2e.dao;

import java.util.List;

import subkjh.bas.dao.control.DaoListener;
import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.log.Logger;

import com.skb.adams.e2e.model.AddrVo;
import com.skb.adams.e2e.model.FX_TMP_LTT_LTD;

public class AddrDao {

	// String db = "ADAMS_MICM";
	private String db = "ADAMS_2018_DEV_MICL";

	public List<AddrVo> getAddrList(DaoListener listener) throws Exception {

		DbTrans tran = DBManager.getMgr().getDataBase(db)
				.createDbTrans("deploy/conf/sql/" + E2eQid.QUERY_XML_FILE);

		E2eQid QID = new E2eQid();

		try {
			tran.start();
			tran.setDaoListener(listener);

			List<AddrVo> list = tran
					.selectQid2Res(QID.QID_SELECT_ADDRESS, null);
			return list;
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		} finally {
			try {
				tran.stop();
			} catch (Exception e) {
				Logger.logger.error(e);
			}
		}
	}

	public void insert(List<FX_TMP_LTT_LTD> list) throws Exception {
		DbTrans tran = DBManager.getMgr().getDataBase(db)
				.createDbTrans("deploy/conf/sql/" + E2eQid.QUERY_XML_FILE);

		E2eQid QID = new E2eQid();

		try {
			tran.start();
			if (list.size() > 0) {
				tran.execute(QID.INSERT_FX_TMP_LTT_LTD, list);
				tran.commit();
			}

		} catch (Exception e) {
			Logger.logger.error(e);
			tran.rollback();
			throw e;
		} finally {
			try {
				tran.stop();
			} catch (Exception e) {
				Logger.logger.error(e);
			}
		}
	}

	public void delete() throws Exception {
		DbTrans tran = DBManager.getMgr().getDataBase(db)
				.createDbTrans("deploy/conf/sql/" + E2eQid.QUERY_XML_FILE);

		E2eQid QID = new E2eQid();

		try {
			tran.start();
			tran.execute(QID.DELETE_FX_TMP_LTT_LTD__BY_ERR, null);
			tran.commit();
		} catch (Exception e) {
			Logger.logger.error(e);
			tran.rollback();
			throw e;
		} finally {
			try {
				tran.stop();
			} catch (Exception e) {
				Logger.logger.error(e);
			}
		}
	}

	public void merge() throws Exception {
		DbTrans tran = DBManager.getMgr().getDataBase(db)
				.createDbTrans("deploy/conf/sql/" + E2eQid.QUERY_XML_FILE);

		E2eQid QID = new E2eQid();

		try {
			tran.start();

			tran.execute(QID.MERGE_OIV10641, null);
			tran.commit();

		} catch (Exception e) {
			Logger.logger.error(e);
			tran.rollback();
			throw e;
		} finally {
			try {
				tran.stop();
			} catch (Exception e) {
				Logger.logger.error(e);
			}
		}
	}

}
