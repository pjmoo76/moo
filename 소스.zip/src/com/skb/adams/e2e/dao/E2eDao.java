package com.skb.adams.e2e.dao;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import subkjh.bas.dao.control.DaoListener;
import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.log.Logger;

import com.skb.adams.e2e.model.E2eVo;
import com.skb.adams.e2e.model.IfVo;

public class E2eDao implements DaoListener {

	public static void main(String[] args) {
		E2eDao dao = new E2eDao();
		try {
			dao.analyze();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private DbTrans tran;
	private IfVo prevIf;
	private List<E2eVo> e2eList = new ArrayList<E2eVo>();

	public E2eDao() {

	}

	public void analyze() throws Exception {

		// String db = "ADAMS_2018_DEV_MIAPP";
		String db = "ADAMS_MICM";

		tran = DBManager.getMgr().getDataBase(db)
				.createDbTrans("deploy/conf/sql/" + E2eQid.QUERY_XML_FILE);

		E2eQid QID = new E2eQid();

		try {
			tran.start();
		} catch (Exception e) {
			throw e;
		}

		tran.setDaoListener(this);

		try {
			tran.selectQid2Res(QID.QID_SELECT_IF_NETWORK__MSKADDR2, null);
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		} finally {
			try {
				tran.stop();
			} catch (Exception e) {
				Logger.logger.error(e);
			}
		}

	}

	@Override
	public void onExecuted(Object arg0, Exception arg1) throws Exception {
	}

	@Override
	public void onFinish(Exception arg0) throws Exception {
		if (e2eList.size() > 0) {
			insert(e2eList);
			e2eList.clear();
		}
	}

	@Override
	public void onSelected(int arg0, Object data) throws Exception {
		IfVo vo = (IfVo) data;
		if (prevIf == null) {
			prevIf = vo;
			return;
		}

		if (prevIf.getRepPortNwAddr() != null) {
			if (vo.getRepPortNwAddr() == null
					|| vo.getRepPortNwAddr().equals(prevIf.getRepPortNwAddr())) {
				if (isSameNetwork(prevIf, vo)) {
					System.out.println(prevIf + " <-> " + vo);
					e2eList.add(new E2eVo(prevIf, vo));
					// writeToFile(
					// filename,
					// prevIf.getString() + "\t\t" + vo.getString() + "\n",
					// true);

				}
			}
		}

		if (e2eList.size() > 1000) {
			insert(e2eList);
			e2eList.clear();
		}

		prevIf = vo;
	}

	private String filename;

	@Override
	public void onStart(String[] columns) throws Exception {
		Logger.logger.trace(Arrays.toString(columns));

		filename = "tmp/link.data_" + System.currentTimeMillis();
		writeToFile(filename, "", false);
	}

	private boolean isSameNetwork(IfVo if1, IfVo if2) {
		String ip1[] = if1.getIpAddr().split("\\.");
		String ip2[] = if2.getIpAddr().split("\\.");

		int ipn1 = Integer.parseInt(ip1[ip1.length - 1]);
		int ipn2 = Integer.parseInt(ip2[ip2.length - 1]);

		if (ipn1 + 1 == ipn2) {
			return true;
		}
		return false;
	}

	private boolean writeToFile(String filename, String datas, boolean append) {

		File file = new File(filename);

		FileOutputStream outStream = null;
		try {
			outStream = new FileOutputStream(file, append);
			outStream.write(datas.getBytes());
			return true;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		} finally {
			if (outStream != null)
				try {
					outStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}

	}

	private void insert(List<E2eVo> list) throws Exception {

		String db = "ADAMS_MICM";
		// String db = "ADAMS_2018_DEV_MICL";

		DbTrans tran = DBManager.getMgr().getDataBase(db)
				.createDbTrans("deploy/conf/sql/" + E2eQid.QUERY_XML_FILE);

		E2eQid QID = new E2eQid();

		try {
			tran.start();
			tran.execute(QID.QID_INSERT_E2E, list);
			tran.commit();
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				tran.stop();
			} catch (Exception e) {
				Logger.logger.error(e);
			}
		}
	}
}
