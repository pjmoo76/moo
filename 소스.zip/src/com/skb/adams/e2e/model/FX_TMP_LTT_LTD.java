package com.skb.adams.e2e.model;

import java.io.Serializable;
import java.sql.Timestamp;

import subkjh.bas.dao.define.INDEX_TYPE;
import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxIndex;
import subkjh.bas.fxdao.define.FxTable;

/**
 * @since 2019.03.19 09:28
 * @author subkjh autometic create by subkjh.dao
 *
 */

@FxTable(name = "FX_TMP_LTT_LTD", comment = "코드테이블")
@FxIndex(name = "FX_TMP_LTT_LTD__PK", type = INDEX_TYPE.PK, columns = {
		"ADDR_ID", "BLDBLK_NUM" })
public class FX_TMP_LTT_LTD {

	public FX_TMP_LTT_LTD() {
	}

	@FxColumn(name = "ADDR_ID", size = 30, comment = "주소ID")
	private String addrId;

	@FxColumn(name = "BLDBLK_NUM", size = 15, comment = "건물동번호", defValue = "0")
	private long bldblkNum = 0;

	@FxColumn(name = "LTT_VAL", size = 15, comment = "위도값")
	private double lttVal;

	@FxColumn(name = "LTD_VAL", size = 15, comment = "경도값")
	private double ltdVal;

	@FxColumn(name = "RSLT_VAL", size = 1, nullable = true, comment = "결과값")
	private String rsltVal;

	@FxColumn(name = "AUDIT_ID", size = 15, comment = "최종변경자ID")
	private String auditId;

	@FxColumn(name = "AUDIT_DTM", size = 0, comment = "최종변경일시")
	private Timestamp auditDtm;

	/**
	 * 주소ID
	 * 
	 * @return 주소ID
	 */
	public String getAddrId() {
		return addrId;
	}

	/**
	 * 주소ID
	 *
	 * @param addrId
	 *            주소ID
	 */
	public void setAddrId(String addrId) {
		this.addrId = addrId;
	}

	/**
	 * 건물동번호
	 * 
	 * @return 건물동번호
	 */
	public long getBldblkNum() {
		return bldblkNum;
	}

	/**
	 * 건물동번호
	 *
	 * @param bldblkNum
	 *            건물동번호
	 */
	public void setBldblkNum(long bldblkNum) {
		this.bldblkNum = bldblkNum;
	}

	/**
	 * 위도값
	 * 
	 * @return 위도값
	 */
	public double getLttVal() {
		return lttVal;
	}

	/**
	 * 위도값
	 *
	 * @param lttVal
	 *            위도값
	 */
	public void setLttVal(double lttVal) {
		this.lttVal = lttVal;
	}

	/**
	 * 경도값
	 * 
	 * @return 경도값
	 */
	public double getLtdVal() {
		return ltdVal;
	}

	/**
	 * 경도값
	 *
	 * @param ltdVal
	 *            경도값
	 */
	public void setLtdVal(double ltdVal) {
		this.ltdVal = ltdVal;
	}

	/**
	 * 결과값
	 * 
	 * @return 결과값
	 */
	public String getRsltVal() {
		return rsltVal;
	}

	/**
	 * 결과값
	 *
	 * @param rsltVal
	 *            결과값
	 */
	public void setRsltVal(String rsltVal) {
		this.rsltVal = rsltVal;
	}

	/**
	 * 최종변경자ID
	 * 
	 * @return 최종변경자ID
	 */
	public String getAuditId() {
		return auditId;
	}

	/**
	 * 최종변경자ID
	 *
	 * @param auditId
	 *            최종변경자ID
	 */
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	/**
	 * 최종변경일시
	 * 
	 * @return 최종변경일시
	 */
	public Timestamp getAuditDtm() {
		return auditDtm;
	}

	/**
	 * 최종변경일시
	 *
	 * @param auditDtm
	 *            최종변경일시
	 */
	public void setAuditDtm(Timestamp auditDtm) {
		this.auditDtm = auditDtm;
	}
}
