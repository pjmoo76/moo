package com.skb.adams.e2e.model;

import java.io.Serializable;

import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;

/**
 * @since 2019.01.28 13:23
 * @author subkjh autometic create by subkjh.dao
 *
 */

@FxTable(name = "E2E", comment = "유선단말기본")
public class E2eVo implements Serializable {

	public E2eVo() {
	}

	public E2eVo(IfVo e1, IfVo e2) {
		equipId = e1.getEquipId();
		equipNm = e1.getEquipNm();
		equipSysNm = e1.getEquipNm();
		equipTidVal = e1.getEquipTidVal();
		equipIpAddr = e1.getEquipIpAddr();
		ifId = e1.getIfId();
		ifNm = e1.getIfNm();
		ifIpAddr = e1.getIpAddr();
		ifDesc = e1.getIfDesc();

		equipId2 = e2.getEquipId();
		equipNm2 = e2.getEquipNm();
		equipSysNm2 = e2.getEquipNm();
		equipTidVal2 = e2.getEquipTidVal();
		equipIpAddr2 = e2.getEquipIpAddr();
		ifId2 = e2.getIfId();
		ifNm2 = e2.getIfNm();
		ifIpAddr2 = e2.getIpAddr();
		ifDesc2 = e2.getIfDesc();

		detectType = "network";
	}

	@FxColumn(name = "EQUIP_ID", size = 12, nullable = true, comment = "EQUIP_ID")
	private String equipId;

	@FxColumn(name = "EQUIP_NM", size = 300, nullable = true, comment = "EQUIP_NM")
	private String equipNm;

	@FxColumn(name = "EQUIP_SYS_NM", size = 300, nullable = true, comment = "EQUIP_SYS_NM")
	private String equipSysNm;

	@FxColumn(name = "EQUIP_TID_VAL", size = 50, nullable = true, comment = "EQUIP_TID_VAL")
	private String equipTidVal;

	@FxColumn(name = "EQUIP_IP_ADDR", size = 23, nullable = true, comment = "EQUIP_IP_ADDR")
	private String equipIpAddr;

	@FxColumn(name = "IF_ID", size = 40, nullable = true, comment = "IF_ID")
	private String ifId;

	@FxColumn(name = "IF_NM", size = 300, nullable = true, comment = "IF_NM")
	private String ifNm;

	@FxColumn(name = "IF_IP_ADDR", size = 23, nullable = true, comment = "IF_IP_ADDR")
	private String ifIpAddr;

	@FxColumn(name = "IF_DESC", size = 500, nullable = true, comment = "IF_DESC")
	private String ifDesc;

	@FxColumn(name = "EQUIP_ID2", size = 12, nullable = true, comment = "EQUIP_ID2")
	private String equipId2;

	@FxColumn(name = "EQUIP_NM2", size = 300, nullable = true, comment = "EQUIP_NM2")
	private String equipNm2;

	@FxColumn(name = "EQUIP_SYS_NM2", size = 300, nullable = true, comment = "EQUIP_SYS_NM2")
	private String equipSysNm2;

	@FxColumn(name = "EQUIP_TID_VAL2", size = 50, nullable = true, comment = "EQUIP_TID_VAL2")
	private String equipTidVal2;

	@FxColumn(name = "EQUIP_IP_ADDR2", size = 23, nullable = true, comment = "EQUIP_IP_ADDR2")
	private String equipIpAddr2;

	@FxColumn(name = "IF_ID2", size = 40, nullable = true, comment = "IF_ID2")
	private String ifId2;

	@FxColumn(name = "IF_NM2", size = 300, nullable = true, comment = "IF_NM2")
	private String ifNm2;

	@FxColumn(name = "IF_IP_ADDR2", size = 23, nullable = true, comment = "IF_IP_ADDR2")
	private String ifIpAddr2;

	@FxColumn(name = "IF_DESC2", size = 500, nullable = true, comment = "IF_DESC2")
	private String ifDesc2;

	@FxColumn(name = "DETECT_TYPE", size = 10, nullable = true, comment = "DETECT_TYPE")
	private String detectType;

	/**
	 * EQUIP_ID
	 * 
	 * @return EQUIP_ID
	 */
	public String getEquipId() {
		return equipId;
	}

	/**
	 * EQUIP_ID
	 *
	 * @param equipId
	 *            EQUIP_ID
	 */
	public void setEquipId(String equipId) {
		this.equipId = equipId;
	}

	/**
	 * EQUIP_NM
	 * 
	 * @return EQUIP_NM
	 */
	public String getEquipNm() {
		return equipNm;
	}

	/**
	 * EQUIP_NM
	 *
	 * @param equipNm
	 *            EQUIP_NM
	 */
	public void setEquipNm(String equipNm) {
		this.equipNm = equipNm;
	}

	/**
	 * EQUIP_SYS_NM
	 * 
	 * @return EQUIP_SYS_NM
	 */
	public String getEquipSysNm() {
		return equipSysNm;
	}

	/**
	 * EQUIP_SYS_NM
	 *
	 * @param equipSysNm
	 *            EQUIP_SYS_NM
	 */
	public void setEquipSysNm(String equipSysNm) {
		this.equipSysNm = equipSysNm;
	}

	/**
	 * EQUIP_TID_VAL
	 * 
	 * @return EQUIP_TID_VAL
	 */
	public String getEquipTidVal() {
		return equipTidVal;
	}

	/**
	 * EQUIP_TID_VAL
	 *
	 * @param equipTidVal
	 *            EQUIP_TID_VAL
	 */
	public void setEquipTidVal(String equipTidVal) {
		this.equipTidVal = equipTidVal;
	}

	/**
	 * EQUIP_IP_ADDR
	 * 
	 * @return EQUIP_IP_ADDR
	 */
	public String getEquipIpAddr() {
		return equipIpAddr;
	}

	/**
	 * EQUIP_IP_ADDR
	 *
	 * @param equipIpAddr
	 *            EQUIP_IP_ADDR
	 */
	public void setEquipIpAddr(String equipIpAddr) {
		this.equipIpAddr = equipIpAddr;
	}

	/**
	 * IF_ID
	 * 
	 * @return IF_ID
	 */
	public String getIfId() {
		return ifId;
	}

	/**
	 * IF_ID
	 *
	 * @param ifId
	 *            IF_ID
	 */
	public void setIfId(String ifId) {
		this.ifId = ifId;
	}

	/**
	 * IF_NM
	 * 
	 * @return IF_NM
	 */
	public String getIfNm() {
		return ifNm;
	}

	/**
	 * IF_NM
	 *
	 * @param ifNm
	 *            IF_NM
	 */
	public void setIfNm(String ifNm) {
		this.ifNm = ifNm;
	}

	/**
	 * IF_IP_ADDR
	 * 
	 * @return IF_IP_ADDR
	 */
	public String getIfIpAddr() {
		return ifIpAddr;
	}

	/**
	 * IF_IP_ADDR
	 *
	 * @param ifIpAddr
	 *            IF_IP_ADDR
	 */
	public void setIfIpAddr(String ifIpAddr) {
		this.ifIpAddr = ifIpAddr;
	}

	/**
	 * IF_DESC
	 * 
	 * @return IF_DESC
	 */
	public String getIfDesc() {
		return ifDesc;
	}

	/**
	 * IF_DESC
	 *
	 * @param ifDesc
	 *            IF_DESC
	 */
	public void setIfDesc(String ifDesc) {
		this.ifDesc = ifDesc;
	}

	/**
	 * EQUIP_ID2
	 * 
	 * @return EQUIP_ID2
	 */
	public String getEquipId2() {
		return equipId2;
	}

	/**
	 * EQUIP_ID2
	 *
	 * @param equipId2
	 *            EQUIP_ID2
	 */
	public void setEquipId2(String equipId2) {
		this.equipId2 = equipId2;
	}

	/**
	 * EQUIP_NM2
	 * 
	 * @return EQUIP_NM2
	 */
	public String getEquipNm2() {
		return equipNm2;
	}

	/**
	 * EQUIP_NM2
	 *
	 * @param equipNm2
	 *            EQUIP_NM2
	 */
	public void setEquipNm2(String equipNm2) {
		this.equipNm2 = equipNm2;
	}

	/**
	 * EQUIP_SYS_NM2
	 * 
	 * @return EQUIP_SYS_NM2
	 */
	public String getEquipSysNm2() {
		return equipSysNm2;
	}

	/**
	 * EQUIP_SYS_NM2
	 *
	 * @param equipSysNm2
	 *            EQUIP_SYS_NM2
	 */
	public void setEquipSysNm2(String equipSysNm2) {
		this.equipSysNm2 = equipSysNm2;
	}

	/**
	 * EQUIP_TID_VAL2
	 * 
	 * @return EQUIP_TID_VAL2
	 */
	public String getEquipTidVal2() {
		return equipTidVal2;
	}

	/**
	 * EQUIP_TID_VAL2
	 *
	 * @param equipTidVal2
	 *            EQUIP_TID_VAL2
	 */
	public void setEquipTidVal2(String equipTidVal2) {
		this.equipTidVal2 = equipTidVal2;
	}

	/**
	 * EQUIP_IP_ADDR2
	 * 
	 * @return EQUIP_IP_ADDR2
	 */
	public String getEquipIpAddr2() {
		return equipIpAddr2;
	}

	/**
	 * EQUIP_IP_ADDR2
	 *
	 * @param equipIpAddr2
	 *            EQUIP_IP_ADDR2
	 */
	public void setEquipIpAddr2(String equipIpAddr2) {
		this.equipIpAddr2 = equipIpAddr2;
	}

	/**
	 * IF_ID2
	 * 
	 * @return IF_ID2
	 */
	public String getIfId2() {
		return ifId2;
	}

	/**
	 * IF_ID2
	 *
	 * @param ifId2
	 *            IF_ID2
	 */
	public void setIfId2(String ifId2) {
		this.ifId2 = ifId2;
	}

	/**
	 * IF_NM2
	 * 
	 * @return IF_NM2
	 */
	public String getIfNm2() {
		return ifNm2;
	}

	/**
	 * IF_NM2
	 *
	 * @param ifNm2
	 *            IF_NM2
	 */
	public void setIfNm2(String ifNm2) {
		this.ifNm2 = ifNm2;
	}

	/**
	 * IF_IP_ADDR2
	 * 
	 * @return IF_IP_ADDR2
	 */
	public String getIfIpAddr2() {
		return ifIpAddr2;
	}

	/**
	 * IF_IP_ADDR2
	 *
	 * @param ifIpAddr2
	 *            IF_IP_ADDR2
	 */
	public void setIfIpAddr2(String ifIpAddr2) {
		this.ifIpAddr2 = ifIpAddr2;
	}

	/**
	 * IF_DESC2
	 * 
	 * @return IF_DESC2
	 */
	public String getIfDesc2() {
		return ifDesc2;
	}

	/**
	 * IF_DESC2
	 *
	 * @param ifDesc2
	 *            IF_DESC2
	 */
	public void setIfDesc2(String ifDesc2) {
		this.ifDesc2 = ifDesc2;
	}

	/**
	 * DETECT_TYPE
	 * 
	 * @return DETECT_TYPE
	 */
	public String getDetectType() {
		return detectType;
	}

	/**
	 * DETECT_TYPE
	 *
	 * @param detectType
	 *            DETECT_TYPE
	 */
	public void setDetectType(String detectType) {
		this.detectType = detectType;
	}
}
