package com.skb.adams.e2e.model;

import subkjh.bas.fxdao.define.FxColumn;

public class IfVo {

	@FxColumn(name = "EQUIP_ID", size = 12, comment = "장비ID")
	private String equipId;

	@FxColumn(name = "IF_ID", size = 40, comment = "인터페이스ID")
	private String ifId;

	@FxColumn(name = "EQUIP_PORT_ID", size = 15, comment = "장비포트ID")
	private String equipPortId;

	@FxColumn(name = "IF_NM", size = 300, nullable = true, comment = "인터페이스명")
	private String ifNm;

	@FxColumn(name = "IP_ADDR", size = 23, nullable = true, comment = "IP주소")
	private String ipAddr;

	@FxColumn(name = "IF_DESC", size = 500, nullable = true, comment = "인터페이스설명")
	private String ifDesc;

	@FxColumn(name = "REP_PORT_NW_ADDR", size = 23, nullable = true, comment = "대표포트NETWORK주소")
	private String repPortNwAddr;

	@FxColumn(name = "REP_PORT_SBNT_MSK_ADDR", size = 23, nullable = true, comment = "대표포트서브넷마스크주소")
	private String repPortSbntMskAddr;

	private String equipTidVal;
	private String equipIpAddr;

	private String equipNm;

	/**
	 * 장비ID
	 * 
	 * @return 장비ID
	 */
	public String getEquipId() {
		return equipId;
	}

	public String getEquipIpAddr() {
		return equipIpAddr;
	}

	public String getEquipNm() {
		return equipNm;
	}

	/**
	 * 장비포트ID
	 * 
	 * @return 장비포트ID
	 */
	public String getEquipPortId() {
		return equipPortId;
	}

	public String getEquipTidVal() {
		return equipTidVal;
	}

	/**
	 * 인터페이스설명
	 * 
	 * @return 인터페이스설명
	 */
	public String getIfDesc() {
		return ifDesc;
	}

	/**
	 * 인터페이스ID
	 * 
	 * @return 인터페이스ID
	 */
	public String getIfId() {
		return ifId;
	}

	/**
	 * 인터페이스명
	 * 
	 * @return 인터페이스명
	 */
	public String getIfNm() {
		return ifNm;
	}

	/**
	 * IP주소
	 * 
	 * @return IP주소
	 */
	public String getIpAddr() {
		return ipAddr;
	}

	/**
	 * 대표포트NETWORK주소
	 * 
	 * @return 대표포트NETWORK주소
	 */
	public String getRepPortNwAddr() {
		return repPortNwAddr;
	}

	/**
	 * 대표포트서브넷마스크주소
	 * 
	 * @return 대표포트서브넷마스크주소
	 */
	public String getRepPortSbntMskAddr() {
		return repPortSbntMskAddr;
	}

	public String getString() {
		return equipId + "\t" + equipIpAddr + "\t" + equipTidVal + "\t"
				+ equipNm + "\t" + ipAddr + "\t" + ifDesc;
	}

	/**
	 * 장비ID
	 *
	 * @param equipId
	 *            장비ID
	 */
	public void setEquipId(String equipId) {
		this.equipId = equipId;
	}

	public void setEquipIpAddr(String equipIpAddr) {
		this.equipIpAddr = equipIpAddr;
	}

	public void setEquipNm(String equipNm) {
		this.equipNm = equipNm;
	}

	/**
	 * 장비포트ID
	 *
	 * @param equipPortId
	 *            장비포트ID
	 */
	public void setEquipPortId(String equipPortId) {
		this.equipPortId = equipPortId;
	}

	public void setEquipTidVal(String equipTidVal) {
		this.equipTidVal = equipTidVal;
	}

	/**
	 * 인터페이스설명
	 *
	 * @param ifDesc
	 *            인터페이스설명
	 */
	public void setIfDesc(String ifDesc) {
		this.ifDesc = ifDesc;
	}

	/**
	 * 인터페이스ID
	 *
	 * @param ifId
	 *            인터페이스ID
	 */
	public void setIfId(String ifId) {
		this.ifId = ifId;
	}

	/**
	 * 인터페이스명
	 *
	 * @param ifNm
	 *            인터페이스명
	 */
	public void setIfNm(String ifNm) {
		this.ifNm = ifNm;
	}

	/**
	 * IP주소
	 *
	 * @param ipAddr
	 *            IP주소
	 */
	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}

	/**
	 * 대표포트NETWORK주소
	 *
	 * @param repPortNwAddr
	 *            대표포트NETWORK주소
	 */
	public void setRepPortNwAddr(String repPortNwAddr) {
		this.repPortNwAddr = repPortNwAddr;
	}

	/**
	 * 대표포트서브넷마스크주소
	 *
	 * @param repPortSbntMskAddr
	 *            대표포트서브넷마스크주소
	 */
	public void setRepPortSbntMskAddr(String repPortSbntMskAddr) {
		this.repPortSbntMskAddr = repPortSbntMskAddr;
	}

	public String toString() {
		return equipIpAddr + "::" + equipNm + "::" + ipAddr + "::" + ifDesc;
	}
}
