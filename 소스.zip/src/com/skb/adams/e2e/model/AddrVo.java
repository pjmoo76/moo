package com.skb.adams.e2e.model;

public class AddrVo {

	private String addrId;

	private String address;

	public static void main(String[] args) {
		AddrVo vo = new AddrVo();
		vo.setAddress("세종 . 다정동 363-78");
		System.out.println(vo.getAddress());
	}

	public String getAddress() {
		String ret = address.replaceAll("\\. ", "");
		if ( ret.startsWith("세종 ")) {
			ret = ret.replaceAll("세종 ", "세종시 ");
		}
		return ret;
	}

	public String getAddrId() {
		return addrId;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setAddrId(String addrId) {
		this.addrId = addrId;
	}

	public String toString() {
		return addrId + " " + address;
	}

}
