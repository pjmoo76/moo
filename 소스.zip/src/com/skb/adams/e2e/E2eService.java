package com.skb.adams.e2e;

import fxms.bas.fxo.service.FxService;

public interface E2eService  extends FxService {

}

