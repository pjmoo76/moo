package com.skb.adams.e2e.function;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;

import subkjh.bas.log.Logger;

import com.google.gson.Gson;
import com.skb.adams.e2e.model.FX_TMP_LTT_LTD;

public class GoogleMap {

	public static void main(String[] args) {
		try {
			new GoogleMap().callNaver("인천 남동구 구월동 505");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public FX_TMP_LTT_LTD callGoogle(String address) throws IOException {

		String s = URLEncoder.encode(address, "utf-8");
		String site = "https://maps.googleapis.com/maps/api/geocode/json?address="
				+ s + "&key=AIzaSyAMVLJi3YvEW3TaqdLja0fQrc-f3KB29ro";

		URL url = new URL(site);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setDoOutput(true);
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Content-Type", "application/json");
		conn.setRequestProperty("Data-Type", "json");

		// OutputStream os = conn.getOutputStream();
		// // os.write(input.getBytes());
		// os.flush();

		// if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
		// throw new RuntimeException("Failed : HTTP error code : " +
		// conn.getResponseCode());
		// }

		BufferedReader br = new BufferedReader(new InputStreamReader(
				(conn.getInputStream())));

		String output;
		StringBuffer sb = new StringBuffer();
		while ((output = br.readLine()) != null) {
			sb.append(output);
		}

		conn.disconnect();

		Map<String, Object> map = new Gson().fromJson(sb.toString(),
				HashMap.class);

		Logger.logger.debug(map);

		String status = (String) map.get("status");

		if ("ok".equalsIgnoreCase(status)) {
			try {
				List<Map<?, ?>> results = (List) map.get("results");
				if (results != null && results.size() > 0) {
					Map<?, ?> geometry = (Map) results.get(0).get("geometry");
					Map<?, ?> location = (Map) geometry.get("location");

					Object lat = location.get("lat");
					Object lng = location.get("lng");

					FX_TMP_LTT_LTD ret = new FX_TMP_LTT_LTD();
					ret.setLttVal(Double.valueOf(lat.toString()));
					ret.setLtdVal(Double.valueOf(lng.toString()));

					System.out.println(lat + "," + lng);
					return ret;
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

		} else {

		}

		return null;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public FX_TMP_LTT_LTD callNaver(String address) throws IOException {

		String s = URLEncoder.encode(address, "utf-8");
		String site = "https://naveropenapi.apigw.ntruss.com/map-geocode/v2/geocode?query="
				+ s;

		URL url = new URL(site);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setDoOutput(true);
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Content-Type", "application/json");
		conn.setRequestProperty("Data-Type", "json");

		conn.setRequestProperty("X-NCP-APIGW-API-KEY-ID", "sk0kz94mq2");
		conn.setRequestProperty("X-NCP-APIGW-API-KEY",
				"yKfKv1iMVxIh9bO1f2KWDPZLgyTEdoflnmjPIzBD");

		// OutputStream os = conn.getOutputStream();
		// // os.write(input.getBytes());
		// os.flush();

		// if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
		// throw new RuntimeException("Failed : HTTP error code : " +
		// conn.getResponseCode());
		// }

		BufferedReader br = new BufferedReader(new InputStreamReader(
				(conn.getInputStream())));

		String output;
		StringBuffer sb = new StringBuffer();
		while ((output = br.readLine()) != null) {
			sb.append(output);
		}

		conn.disconnect();

		System.out.println(address + ":" + sb.toString());

		Map<String, Object> map = new Gson().fromJson(sb.toString(),
				HashMap.class);

		Logger.logger.debug(map);

		String status = (String) map.get("status");
		//
		if ("ok".equalsIgnoreCase(status)) {
			try {

				List<Map<?, ?>> addresses = (List) map.get("addresses");
				if (addresses != null && addresses.size() > 0) {

					Object lat = addresses.get(0).get("y");
					Object lng = addresses.get(0).get("x");

					FX_TMP_LTT_LTD ret = new FX_TMP_LTT_LTD();
					ret.setLttVal(Double.valueOf(lat.toString()));
					ret.setLtdVal(Double.valueOf(lng.toString()));

					System.out.println(lat + "," + lng);
					return ret;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else {

		}

		return null;
	}

}
