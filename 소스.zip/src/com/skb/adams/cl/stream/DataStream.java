package com.skb.adams.cl.stream;

import java.io.Closeable;
import java.io.IOException;

public abstract class DataStream {
	public abstract boolean open(String fileName, String charsetName);
	public abstract boolean close();
	public abstract String readLine() throws Exception;
	
	
	private String			errMsg = "";
	
	public String getErrMsg() {
		return errMsg;
	}
	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}
	
	public static void closeSafely(Closeable closeable) {
		if (closeable != null) {
		  try {
			  closeable.close();
		  } catch (IOException e) {
		  }
		}
	}
}
