package com.skb.adams.cl.stream;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.util.zip.GZIPInputStream;

import com.skb.adams.cm.util.MiscUtils;

public class DataStreamGzText extends DataStream {
	
	InputStream fileIs = null;
    BufferedInputStream bufferedIs = null;
    GZIPInputStream gzipIs = null;
    BufferedReader br = null;
	
	public boolean open(String fileName, String charsetName) {
		try {
			Path path = FileSystems.getDefault().getPath(fileName);
			fileIs = Files.newInputStream(path);
			
		  // Even though GZIPInputStream has a buffer it reads individual bytes
		  // when processing the header, better add a buffer in-between
		  
			bufferedIs = new BufferedInputStream(fileIs, 65535);
			gzipIs = new GZIPInputStream(bufferedIs);
			br = new BufferedReader(new InputStreamReader(gzipIs, charsetName));
		} catch (NoSuchFileException ne) {
			setErrMsg(String.format("## Fail to open [NoSuchFileException][%s][%s]", fileName, MiscUtils.RemoveLineFeed(ne.getMessage())));
			return false;
		} catch (Exception e) {
			closeSafely(gzipIs);
			closeSafely(bufferedIs);
			closeSafely(fileIs);
			setErrMsg(String.format("Fail to open [%s][%s]", fileName, MiscUtils.RemoveLineFeed(e.getMessage())));
			return false;
		}
		return true;
	};
	
	public boolean close() {	
		closeSafely(gzipIs);
		closeSafely(bufferedIs);
		closeSafely(fileIs);
		closeSafely(br);
		return true;
	};
	
	public String readLine() throws Exception {
		if(br != null) {
			return br.readLine();
		}
		return null;
	};
}
