package com.skb.adams.cl.stream;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.util.MiscUtils;

public class DataStreamText extends DataStream {
	
	FileInputStream fr = null;
	BufferedReader br = null;
	
	public boolean open(String fileName, String charsetName) {
		try {
			fr = new FileInputStream(fileName);
			br = new BufferedReader(new InputStreamReader(fr, charsetName));
		} catch (Exception e) {
			setErrMsg(String.format("exception[%s][%s]", fileName, e.getMessage().replace("\r", "").replace("\n", "")));
			Logger.logger.error(String.format("exception[%s][%s],[%s]", fileName, e.getMessage(), MiscUtils.getStackTraceStringFromException(e)));
		}
		
		if(fr == null || br == null) {
			try {
				if(br != null) {
					br.close();
				}
				
				if(fr != null) {
					fr.close();
				}
			} catch (Exception e) {
			}
			return false;
		}
		return true;
	};
	
	public boolean close() {	
		if(fr != null || br != null) {
			try {
				if(br != null) {
					br.close();
				}
				
				if(fr != null) {
					fr.close();
				}
			} catch (Exception e) {
				Logger.logger.error(String.format("exception[%s],[%s]", e.getMessage(), MiscUtils.getStackTraceStringFromException(e)));
			}
			fr = null;
			br = null;
			return false;
		}
		return true;
	};
	
	public String readLine() throws Exception{
		if(br != null) {
			return br.readLine();
		}
		return null;
	};
}
