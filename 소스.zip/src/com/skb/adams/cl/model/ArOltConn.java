package com.skb.adams.cl.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.log.Logger;

import com.skb.adams.cl.dao.ClCmServiceQid;
import com.skb.adams.cl.service.DataHandler;
import com.skb.adams.cm.util.StringUtils;

public class ArOltConn extends OMNBaseHandler {
	
	private JSONParser 		parser = null;
	private	String			auditId = "AR_OLT_CONN";

	public ArOltConn() {
		parser = new JSONParser();
	}

	@Override
	public List<String> parse(String line, DbTrans dbTrans) {
		_parse(line, dbTrans);
		return super.parse(line, dbTrans);
	}
	
	private List<String> _parse(String line, DbTrans dbTrans) {
		try {
			JSONObject obj = (JSONObject) parser.parse(line);
			String arIp = (String) obj.get("ARIP");
			String oltIp = (String) obj.get("OLTIP");
			if (StringUtils.isEmpty(arIp) || StringUtils.isEmpty(oltIp)) {
				return null;
			}
			// check OIV10100
			String arEquipId = dbTrans.selectQidStr(ClCmServiceQid.SELECT_EQUIP_ID__BY_EQUIP_IP_ADDR, arIp);
			if (StringUtils.isEmpty(arEquipId)) {
				Logger.logger.error("failed to get EQUIP_ID for AR(" + arIp + ")");
				return null;
			}
			String oltEquipId = dbTrans.selectQidStr(ClCmServiceQid.SELECT_EQUIP_ID__BY_EQUIP_IP_ADDR, oltIp);
			if (StringUtils.isEmpty(oltEquipId)) {
				Logger.logger.error("failed to get EQUIP_ID for OLT(" + oltIp + ")");
				return null;
			}
				
			HashMap<String,String> hmap = new HashMap<String,String>();
			hmap.put("adrcEquipId", arEquipId);
			hmap.put("zdrcEquipId", oltEquipId);
			String linkId = dbTrans.selectQidStr(ClCmServiceQid.SELECT_LINK_ID__BY_EQUIP_ID, hmap);
			// LINK가 이미 존재한다면 return
			if (StringUtils.isEmpty(linkId) == false) {
				return null;
			}
			// check OIV10400
			// AR
			hmap = new HashMap<String,String>();
			hmap.put("equipId", arEquipId);
			String adrcEquipPortId = dbTrans.selectQidStr(ClCmServiceQid.SELECT_EQUIP_PORT_ID__BY_EQUIP_ID, hmap);
			if (StringUtils.isEmpty(adrcEquipPortId)) {
				// create OIV10400
				adrcEquipPortId = dbTrans.selectQidStr(ClCmServiceQid.SELECT_NEW_EQUIP_PORT_ID, "");
				hmap = new HashMap<String, String>();
				hmap.put("equipId", arEquipId);
				hmap.put("equipPortId", adrcEquipPortId);
				hmap.put("auditId", auditId);
				hmap.put("mounLocNum", null);
				hmap.put("portNum", null);
				hmap.put("portTypCd", "0");
				hmap.put("portSpeedCd", "0");
				hmap.put("pollingMObjYn", "N");
				hmap.put("pingMObjYn", "Y");
				hmap.put("rgstCycl", "0");
				dbTrans.create(ClCmServiceQid.INSERT_OIV10400, hmap);

				Logger.logger.info("create (EQUIP_ID=" + arEquipId + "),(EQUIP_PORT_ID=" + adrcEquipPortId + ")");
			}

			// OLT
			hmap.put("equipId", oltEquipId);
			String zdrcEquipPortId = dbTrans.selectQidStr(ClCmServiceQid.SELECT_EQUIP_PORT_ID__BY_EQUIP_ID, hmap);
			if (StringUtils.isEmpty(zdrcEquipPortId)) {
				// create OIV10400
				zdrcEquipPortId = dbTrans.selectQidStr(ClCmServiceQid.SELECT_NEW_EQUIP_PORT_ID, "");
				hmap = new HashMap<String, String>();
				hmap.put("equipId", oltEquipId);
				hmap.put("equipPortId", zdrcEquipPortId);
				hmap.put("auditId", auditId);
				hmap.put("mounLocNum", null);
				hmap.put("portNum", null);
				hmap.put("portTypCd", "0");
				hmap.put("portSpeedCd", "0");
				hmap.put("pollingMObjYn", "N");
				hmap.put("pingMObjYn", "Y");
				hmap.put("rgstCycl", "0");
				dbTrans.create(ClCmServiceQid.INSERT_OIV10400, hmap);

				Logger.logger.info("create (EQUIP_ID=" + oltEquipId + "),(EQUIP_PORT_ID=" + zdrcEquipPortId + ")");
			}
			
			// create OIV10401
			String newLinkId = dbTrans.selectQidStr(ClCmServiceQid.SELECT_NEW_LINK_ID, "");
			hmap.put("linkId", newLinkId);
			hmap.put("auditId", auditId);
			hmap.put("adrcEquipId", arEquipId);
			hmap.put("adrcEquipPortId", adrcEquipPortId);
			hmap.put("zdrcEquipId", oltEquipId);
			hmap.put("zdrcEquipPortId", zdrcEquipPortId);
			hmap.put("linkTypCd", "01");
			hmap.put("linkUsgCd", "WEQP");
			hmap.put("linkRngCd", "000");
			dbTrans.create(ClCmServiceQid.INSERT_OIV10401, hmap);

			Logger.logger.info("create (LINK_ID=" + newLinkId + "),(ADRC_EQUIP_ID=" + arEquipId + "),(ZDRC_EQUIP_ID=" + oltEquipId + ")");
			
		} catch (Exception e) {
			Logger.logger.error(e);
		}
		return null;
	}
}
