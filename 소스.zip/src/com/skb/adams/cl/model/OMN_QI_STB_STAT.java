package com.skb.adams.cl.model;

import java.util.HashMap;
import java.util.List;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.log.Logger;

public class OMN_QI_STB_STAT extends OMNBaseHandler {

	@Override
	public List<String> parse(String line, DbTrans dbTrans) {

		HashMap<String, String> hmap = new HashMap<String, String>();
		StringBuffer sResult = new StringBuffer();
		String[] sColIdx = {"_GOOD", "_WARN", "_CRIT"};

		try {

			String sAreaInfo;
			String sMsrtInfo;
			String sColumnTemp = null;
            String sDataTemp = null;
			
			// 맨 앞의 (('fttx', 'T105', 'A40100', 'A40405', 'NR016481', 'FS094345') 부분
			sAreaInfo = line.substring(line.indexOf("((") + 2, line.indexOf("), "));
			sAreaInfo = sAreaInfo.replace("'", ""); // Remove SingleQuote
            sAreaInfo = sAreaInfo.replace(" ", ""); // Remove Blank
            
            //망;팀;정보센터;국소;UDEV1;UDEV2
            String[] sRecHeader = sAreaInfo.split(",");
           
            hmap.put("NET", sRecHeader[0]);
            hmap.put("TEAM", sRecHeader[1]);
            hmap.put("INFO_CNTR", sRecHeader[2]);
            hmap.put("DISTB_CNTR", sRecHeader[3]);
            hmap.put("UDEV1", sRecHeader[4]);
            hmap.put("UDEV2", sRecHeader[5]);
            
            // (('fttx', 'T105', 'A40100', 'A40405', 'NR016481', 'FS094345') 이후의 데이터
            sMsrtInfo = line.substring(line.indexOf("{") + 1, line.length() - 2);
            
            String sTemp = sMsrtInfo;

			while(sTemp.length() > 0) {
				
				int iColSttPos = 0, iColEndPos = 0, iDataSttPos = 0, iDataEndPos = 0;
                // Column Header open
                iColSttPos = sTemp.indexOf("'");
                
                if (iColSttPos == -1) break;

                sTemp = sTemp.substring(iColSttPos + 1);

                // Column Header close
                iColEndPos = sTemp.indexOf("'");
                sColumnTemp = sTemp.substring(0, iColEndPos);
                
                sTemp = sTemp.substring(iColEndPos + 1);

                // Data open
                iDataSttPos = sTemp.indexOf("{");

                sTemp = sTemp.substring(iDataSttPos + 1);

                // Data close
                iDataEndPos = sTemp.indexOf("}");

                if (iDataEndPos == -1) break;

                sDataTemp = sTemp.substring(0, iDataEndPos);

                sTemp = sTemp.substring(iDataEndPos + 1);

                String[] sValArr = sDataTemp.split(",");
                
                for (int i = 0; i < sValArr.length; i++)
                {
                    String[] strKeyValue = sValArr[i].split(":");
                    String sKey = sColumnTemp.concat(sColIdx[i]);

                    hmap.put(sKey, strKeyValue[1].trim());
                }
			}
			
		} catch (Exception e) {
			Logger.logger.error(e);
		}

		String[] columns = getColumns();
		
		for(int i=0; i<columns.length; i++) {
			if(hmap.get(columns[i]) == null) {
				sResult.append(String.format("|", hmap.get(columns[i])));
			} else {
				sResult.append(String.format("%s|", hmap.get(columns[i])));
			}
		}
		
		return super.parse(sResult.toString(), dbTrans);
	}

	@Override
	public String[] getColumns() {
		return getConfigedColumns();
	}

}
