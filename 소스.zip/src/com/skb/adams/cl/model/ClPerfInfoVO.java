package com.skb.adams.cl.model;

public class ClPerfInfoVO {
	private	String	fTable;
	private	String	clctNmsClCd;
	private	String	mntrCyclCd;

	public String getfTable() {
		return fTable;
	}
	public void setfTable(String fTable) {
		this.fTable = fTable;
	}
	public String getClctNmsClCd() {
		return clctNmsClCd;
	}
	public void setClctNmsClCd(String clctNmsClCd) {
		this.clctNmsClCd = clctNmsClCd;
	}
	public String getMntrCyclCd() {
		return mntrCyclCd;
	}
	public void setMntrCyclCd(String mntrCyclCd) {
		this.mntrCyclCd = mntrCyclCd;
	}
}
