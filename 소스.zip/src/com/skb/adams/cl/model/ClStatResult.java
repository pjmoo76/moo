package com.skb.adams.cl.model;

public class ClStatResult {
	private	String	statId;
	private	String	baseTime;
	private	String	startTime;
	private	String	endTime;
	private	String	execSec;
	private	boolean	succYn;
	private	long	affectRowCnt;
	private	String	errMsg;
	private	String	reqNum;

	public String getStatId() {
		return statId;
	}
	public void setStatId(String statId) {
		this.statId = statId;
	}
	public String getBaseTime() {
		return baseTime;
	}
	public void setBaseTime(String baseTime) {
		this.baseTime = baseTime;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getExecSec() {
		return execSec;
	}
	public void setExecSec(String execSec) {
		this.execSec = execSec;
	}
	public boolean isSuccYn() {
		return succYn;
	}
	public void setSuccYn(boolean succYn) {
		this.succYn = succYn;
	}
	public long getAffectRowCnt() {
		return affectRowCnt;
	}
	public void setAffectRowCnt(long affectRowCnt) {
		this.affectRowCnt = affectRowCnt;
	}
	public String getErrMsg() {
		return errMsg;
	}
	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}
	public String getReqNum() {
		return reqNum;
	}
	public void setReqNum(String reqNum) {
		this.reqNum = reqNum;
	}
}
