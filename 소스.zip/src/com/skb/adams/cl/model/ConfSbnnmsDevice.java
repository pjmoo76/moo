package com.skb.adams.cl.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.log.Logger;

import com.skb.adams.cl.dao.ClCmServiceQid;
import com.skb.adams.cl.service.DataHandler;
import com.skb.adams.cm.util.MiscUtils;
import com.skb.adams.cm.util.StringUtils;

public class ConfSbnnmsDevice extends DataHandler {
	
	static final int	ITEM_CMTSID			= 0;
	static final int	ITEM_CMTSNAME		= 1;
	static final int	ITEM_AR_IP			= 2;
	static final int	ITEM_AR_NAME		= 3;
	static final int	ITEM_AR_IF_PORT		= 4;
	static final int	ITEM_AR_IF_ARLIAS	= 5;
	static final int	ITEM_GENDATETIME	= 6;
	static final int	ITEM_AR_IF_IP		= 7;
	static final int	ITEM_TOTAL_NO		= 8;

	private	String			auditId = "RMS_CSD";

	public ConfSbnnmsDevice() {
	}

	@Override
	public List<String> parse(String line, DbTrans dbTrans) {
		StringBuffer sb = new StringBuffer();
		List<String> list = new ArrayList<String>();
		char chs[] = line.toCharArray();
		for (int i = 0; i < chs.length; i++) {
			if (i+1 < chs.length && chs[i] == '\\' && chs[i+1] == '|') {
				continue;
			} else if (i > 0 && chs[i] == '|' && chs[i - 1] == '\\') {
				sb.append(chs[i]);
			} else if (chs[i] == '|') {
				list.add(sb.toString());
				sb = new StringBuffer();
			} else {
				sb.append(chs[i]);
			}
		}
		// CMTSID, CMTSNAME, AR_IP, AR_NAME, AR_IF_PORT, AR_IF_ALIAS, GENDATETIME, AR_IF_IP
		/*
			CMTSID       : 172.23.60.17
			CMTSNAME     : CM300011
			AR_IP        : 121.124.244.14|121.124.244.14|121.124.244.14
			AR_NAME      : DG_3750_SW3|DG_3750_SW3|DG_3750_SW3
			AR_IF_PORT   : Fa1/0/3|Fa1/0/2|Fa1/0/1
			AR_IF_ARLIAS : HFC_cmts1_G0/3|HFC_cmts1_G0/2|HFC_cmts1_G0/1
			GENDATETIME  : 20170718063007
			AR_IF_IP     : 123.212.153.9|123.212.153.5|123.212.153.1
		 */
		if (list.size() < ITEM_TOTAL_NO) {
			return null;
		}
		try {
			String cmtsId = list.get(ITEM_CMTSID);
			EquipInfoVO cmtsInfo = (EquipInfoVO) dbTrans.selectQidObj(ClCmServiceQid.SELECT_EQUIP_INFO__BY_EQUIP_IP_ADDR, cmtsId);
			if (cmtsInfo == null) {
				Logger.logger.error("failed to get EQUIP_INFO for CMTS(" + cmtsId + ")");
				return null;
			}
			String[] arIpList = list.get(ITEM_AR_IP).split("\\|"); 
			String[] arIpPortList = list.get(ITEM_AR_IF_PORT).split("\\|"); 
			if (arIpList.length != arIpPortList.length) {
				Logger.logger.error("invalid data (" + list.get(ITEM_AR_IP) + "),(" + list.get(ITEM_AR_IF_PORT) + ")");
				return null;
			}
			Map<String, EquipInfoVO> arInfoMap = new HashMap<String, EquipInfoVO>(); 
			for (int i = 0; i < arIpList.length; i ++) {
				// check AR
				String arIp = arIpList[i];
				EquipInfoVO arInfo = arInfoMap.get(arIp);
				if (arInfo == null) {					
					arInfo = (EquipInfoVO) dbTrans.selectQidObj(ClCmServiceQid.SELECT_EQUIP_INFO__BY_EQUIP_IP_ADDR, arIp);
					if (arInfo == null) {
						Logger.logger.error("failed to get EQUIP_INFO for AR(" + arIp + ")");
						continue;
					}
					arInfoMap.put(arIp, arInfo);
				}
				String arIpPort = arIpPortList[i];
				String portLoc = MiscUtils.getPortLoc(arIpPort);
				String portNo = MiscUtils.getPortNo(arIpPort);
				// check AR Port (OIV10400)
				HashMap<String,String> hmap = new HashMap<String,String>();
				hmap.put("equipId", arInfo.getEquipId());
				hmap.put("mounLocNum", portLoc);
				hmap.put("portNum", portNo);
				String arEquipPortId = dbTrans.selectQidStr(ClCmServiceQid.SELECT_EQUIP_PORT_ID, hmap);
				if (arEquipPortId == null) {
					// create AR Port (OIV10400)
					arEquipPortId = dbTrans.selectQidStr(ClCmServiceQid.SELECT_NEW_EQUIP_PORT_ID, "");
					hmap.put("equipPortId", arEquipPortId);
					hmap.put("auditId", auditId);
					hmap.put("portTypCd", "0");
					hmap.put("portSpeedCd", "0");
					hmap.put("pollingMObjYn", "N");
					hmap.put("pingMObjYn", "Y");
					hmap.put("rgstCycl", "0");
					dbTrans.create(ClCmServiceQid.INSERT_OIV10400, hmap);

					Logger.logger.info("create (EQUIP_ID=" + arInfo.getEquipId() + "),(EQUIP_PORT_ID=" + arEquipPortId + ")");
				} else {
					// check OIV10401
					hmap = new HashMap<String,String>();
					hmap.put("adrcEquipId", arInfo.getEquipId());
					hmap.put("adrcEquipPortId", arEquipPortId);
					hmap.put("zdrcEquipId", cmtsInfo.getEquipId());
					String linkId = dbTrans.selectQidStr(ClCmServiceQid.SELECT_LINK_ID__BY_ADRC_EQUIP_PORT_ID, hmap);
					if (StringUtils.isEmpty(linkId) == false) {
						continue;
					}
				}
				// create OIV10401
				String newLinkId = dbTrans.selectQidStr(ClCmServiceQid.SELECT_NEW_LINK_ID, "");
				hmap = new HashMap<String,String>();
				hmap.put("linkId", newLinkId);
				hmap.put("auditId", auditId);
				hmap.put("adrcEquipId", arInfo.getEquipId());
				hmap.put("adrcEquipPortId", arEquipPortId);
				hmap.put("zdrcEquipId", cmtsInfo.getEquipId());
				hmap.put("zdrcEquipPortId", "0");
				hmap.put("linkTypCd", "01");
				hmap.put("linkUsgCd", "WEQP");
				hmap.put("linkRngCd", "000");
				dbTrans.create(ClCmServiceQid.INSERT_OIV10401, hmap);

				Logger.logger.info("create (LINK_ID=" + newLinkId + "),(ADRC_EQUIP_ID=" + arInfo.getEquipId()
						+ "),(ADRC_EQUIP_PORT_ID=" + arEquipPortId + "),(ZDRC_EQUIP_ID=" + cmtsInfo.getEquipId() + ")");
			}
		} catch (Exception e) {
			Logger.logger.error(line);
			Logger.logger.error(e);
		}

		return null;
	}

	@Override
	public String[] getColumns() {
		// TODO Auto-generated method stub
		return new String[] {};
	}

	@Override
	public Map<Integer, String> getDefColumnValues() {
		return null;
	}

	@Override
	public boolean onInit(DbTrans dbTrans, String fileName) {
		return true;
		
	}

	@Override
	public boolean onClosed(DbTrans dbTrans) {
		return true;
	}

}
