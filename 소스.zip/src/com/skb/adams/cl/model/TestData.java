package com.skb.adams.cl.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import subkjh.bas.dao.control.DaoListener;
import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.log.Logger;

import com.skb.adams.cl.service.DataHandler;

public class TestData extends DataHandler implements DaoListener{


	public TestData() {
		
	}

	public List<String> parse(String line, DbTrans dbTrans) {
		ArrayList<String> result = new ArrayList<String>();
		
		Logger.logger.debug(line);
		
		result.add("1"); // MNTR_DT
		//result.add("OMN60523_S1.NEXTVAL"); // MNTR_NUM
		result.add("MICL"); // AUDIT_ID
		//result.add("SYSDATE"); // AUDIT_DTM
		result.add("2018010514"); // MNTR_DTM

		int j = 0;
		for (int i = 0; i < getColumns().length; i ++) {
			if(getDefColumnValues().containsKey(i)) {
				if (getDefColumnValues().get(i).contains("?")) {
					Logger.logger.debug("(" + getColumns()[i] + "=" + result.get(j) + ")");
					j ++;
				}
			} else{
				Logger.logger.debug("(" + getColumns()[i] + "=" + result.get(j) + ")");
				j ++;
			}
			
		}
		
		return result;
	}

	public String[] getColumns() {
		return new String[] {
				"MNTR_DT", "MNTR_NUM", "AUDIT_ID", "AUDIT_DTM", "MNTR_DTM"};
	}

	public Map<Integer, String> getDefColumnValues() {
		Map<Integer, String> defVal = new HashMap<Integer, String>();
		
		defVal.put(1, "OMN60523_S1.NEXTVAL");
		defVal.put(3, "SYSDATE");
		defVal.put(4, "RPAD(?, 16, '0')");
		
		return defVal;
	}
	
	@Override
	public boolean onInit(DbTrans dbTrans, String fileName) {
		return true;
		
	}

	@Override
	public boolean onClosed(DbTrans dbTrans) {
		return true;
	}

	/*--- DaoListener interface ---*/

	@Override
	public void onStart(String[] arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onExecuted(Object arg0, Exception arg1) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onFinish(Exception arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onSelected(int arg0, Object data) throws Exception {
		// TODO Auto-generated method stub
	}

}
