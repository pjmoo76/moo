package com.skb.adams.cl.model;

import java.util.List;

import fxms.bas.cron.Cron;

public class ClStatSchInfo {
	private ClStatInfoVO		clStatInfo;
	private Cron				cron;
	private List<ClPerfInfoVO>	clPerfInfoList;

	public ClStatInfoVO getClStatInfo() {
		return clStatInfo;
	}
	public void setClStatInfo(ClStatInfoVO clStatInfo) {
		this.clStatInfo = clStatInfo;
	}
	public Cron getCron() {
		return cron;
	}
	public void setCron(Cron cron) {
		this.cron = cron;
	}
	public List<ClPerfInfoVO> getClPerfInfoList() {
		return clPerfInfoList;
	}
	public void setClPerfInfoList(List<ClPerfInfoVO> clPerfInfoList) {
		this.clPerfInfoList = clPerfInfoList;
	}
}
