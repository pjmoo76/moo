package com.skb.adams.cl.model;

public class ClStatExecReqVO {
	private	String	reqNum;
	private	String	statId;
	private	String	reqDtm;
	private	String	baseDt;
	private	String	reqStCd;
	private	String	sussYn;
	private	String	strtDtm;
	private	String	endDtm;
	private	String	execSec;
	private	int		afctRowCnt;
	private	String	errMsg;
	private	String	condChkYn;

	public String getReqNum() {
		return reqNum;
	}
	public void setReqNum(String reqNum) {
		this.reqNum = reqNum;
	}
	public String getStatId() {
		return statId;
	}
	public void setStatId(String statId) {
		this.statId = statId;
	}
	public String getReqDtm() {
		return reqDtm;
	}
	public void setReqDtm(String reqDtm) {
		this.reqDtm = reqDtm;
	}
	public String getBaseDt() {
		return baseDt;
	}
	public void setBaseDt(String baseDt) {
		this.baseDt = baseDt;
	}
	public String getReqStCd() {
		return reqStCd;
	}
	public void setReqStCd(String reqStCd) {
		this.reqStCd = reqStCd;
	}
	public String getSussYn() {
		return sussYn;
	}
	public void setSussYn(String sussYn) {
		this.sussYn = sussYn;
	}
	public void setSussYn(boolean sussYn) {
		this.sussYn = sussYn ? "Y" : "N";
	}
	public String getStrtDtm() {
		return strtDtm;
	}
	public void setStrtDtm(String strtDtm) {
		this.strtDtm = strtDtm;
	}
	public String getEndDtm() {
		return endDtm;
	}
	public void setEndDtm(String endDtm) {
		this.endDtm = endDtm;
	}
	public String getExecSec() {
		return execSec;
	}
	public void setExecSec(String execSec) {
		this.execSec = execSec;
	}
	public int getAfctRowCnt() {
		return afctRowCnt;
	}
	public void setAfctRowCnt(int afctRowCnt) {
		this.afctRowCnt = afctRowCnt;
	}
	public String getErrMsg() {
		return errMsg;
	}
	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}
	public String getCondChkYn() {
		return condChkYn;
	}
	public void setCondChkYn(String condChkYn) {
		this.condChkYn = condChkYn;
	}
}
