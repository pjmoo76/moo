package com.skb.adams.cl.model;

import java.net.InetAddress;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.Logger;

import com.skb.adams.cl.dao.ClSmsInfoQid;
import com.skb.adams.cl.service.DataHandler;
import com.skb.adams.cm.util.ElaspedTime;
import com.skb.adams.cm.util.MiscUtils;

public class OMNBaseHandler extends DataHandler {
	
	private boolean 		bVaildFile = false;
	private int				dataTokenCount = 0;
	private JSONParser 		jsonParser = null;
	
	private String			userDataTimeStr = null;
	
	private ElaspedTime		eltTime = new ElaspedTime();
	private int				validDataCount = 0;
	private int				inValidDataCount = 0;
	
	private ArrayList<String> reUseTempList = new ArrayList<String>();
	
	public OMNBaseHandler() {
		jsonParser = new JSONParser();
	}

	public List<String> parse(String line, DbTrans dbTrans) {
		
		if(!bVaildFile) {
			inValidDataCount++;
			return null;
		}
		
		String[] columns = null;
		if (isJsonData()) {
			columns = getDataItems();
			if (columns == null) {
				columns = getColumns();
			}
		} else {
			columns = getColumns();
		}
		
		if(columns == null) {
			inValidDataCount++;
			return null;
		}
		
		ArrayList<String> result = new ArrayList<String>();
		
		if(isJsonData()) {
			
			JSONObject obj;
			try {
				obj = (JSONObject) jsonParser.parse(line);
			} catch (ParseException e) {
				Logger.logger.error(String.format("exception[%s][%s],[%s]", getName(), e.getMessage(), MiscUtils.getStackTraceStringFromException(e)));
				inValidDataCount++;
				return null;
			}
			
			try {
				String userDate = "";
				if(getUserDateRegEx() != null) {
					// json 형식이면서 userdate를 사용하는 경우 상정 20180321(OMN20518)
					userDate = getDateColumn();
				}
				for(String key : columns) {
					if(key.equals(userDate)) {
						// json 형식이면서 userdate를 사용하는 경우 상정 20180321(OMN20518)
						result.add(userDataTimeStr);
						continue;
					}
					if(obj.containsKey(key)) {
						String val;
						if(obj.get(key) == null) {
							val = "";
						} else {
							val = (String) obj.get(key).toString();
						}
						result.add(val.trim());
					} else {
						result.add("");
						// JSON 방식 중 DataItems등을 사용한 형태일 때, 상당한 로그가 발생해 주석 처리했습니다. 20180219
						// Logger.logger.error(String.format("can't find json item : [%s][%s]", getName(), key));
					}
				}
			} catch (Exception e) {
				Logger.logger.error(e.getMessage());
				Logger.logger.error(String.format("exception[%s][%s],[%s]", getName(), e.getMessage(), MiscUtils.getStackTraceStringFromException(e)));
				inValidDataCount++;
				return null;
			}
		} else {
			String[] sRecHeader = MiscUtils.split(line, getDataDelimiter(), reUseTempList);
			if(sRecHeader == null || sRecHeader.length < dataTokenCount) {
				inValidDataCount++;
				return null;
			}
			
			for (int i = 0; i < dataTokenCount; i++) {
				if(sRecHeader[i].trim() == null) {
					result.add("");
				} else {
					result.add(sRecHeader[i].trim());
				}
			}
		}
		
		if(result.size() > 0 ) {
			if(userDataTimeStr != null && !isJsonData()) {
				result.add(userDataTimeStr);
			}
			validDataCount++;
			
			return result;
		} else {
			inValidDataCount++;
			return null;
		}
	}
	
	public String[] getColumns() {
		return getConfigedColumns();
	}
	
	public String getUserDataTimeStr() {
		return userDataTimeStr;
	}
	
	@Override
	public Map<Integer, String> getDefColumnValues() {
		return null;
	}
	
	@Override
	public boolean onInit(DbTrans dbTrans, String fileName) {
		Logger.logger.info(String.format("onInit : [%s]", getName()));
		
		userDataTimeStr = null;
		bVaildFile = true;
		dataTokenCount = 0;
		
		eltTime.start();
		validDataCount = 0;
		inValidDataCount = 0;
		
		if(getColumns() != null) {
			dataTokenCount = getColumns().length;
		}
		
		if(getUserDateRegEx() != null) {
			
			bVaildFile = false;
			
			Pattern p = Pattern.compile(getUserDateRegEx());
			Matcher m = p.matcher(fileName);
			
			if(m.find()) {
				userDataTimeStr = m.group();
				
				userDataTimeStr = userDataTimeStr.trim();
				userDataTimeStr = userDataTimeStr.replace(" ", "");
				userDataTimeStr = userDataTimeStr.replace("_", "");
				userDataTimeStr = userDataTimeStr.replace("-", "");
				
				if(MiscUtils.isDigit(userDataTimeStr)) {
					bVaildFile = true;
					
					//padding 16byte
					while(userDataTimeStr.length() < 16) {
						userDataTimeStr += "0";
					}
					
					dataTokenCount--;
				} else {
					Logger.logger.error(String.format("file naming is invalid !!! : [%s]", fileName));
					bVaildFile = false;
				}
			}
		}
		
		String[] preQidList = getPreQidList();
		if (null != preQidList && preQidList.length > 0) {
			ElaspedTime ept = new ElaspedTime();
			for(String preQid : getPreQidList()) {
				Logger.logger.info(String.format(" -- execute preQid: [%s][%s]", getName(), preQid));
				
				try {
					ept.start();
					int rowCnt = dbTrans.create(preQid, null);
					setAffectedRow(rowCnt);
					ept.end();
					Logger.logger.info(String.format("preQid affected row : [%s][%d ea][%s sec][%s]", getName(), rowCnt, ept.getElaspedSecString(), preQid));
				} catch (Exception e) {
					setErrMsg(String.format("exception[%s][%s]]", getName(), e.getMessage()));
					Logger.logger.error(String.format("exception[%s][%s],[%s]", getName(), e.getMessage(), MiscUtils.getStackTraceStringFromException(e)));
					return false;
				}
			}
		}

		return bVaildFile;
	}

	/* (non-Javadoc)
	 * @see com.skb.adams.cl.service.DataHandler#onClosed(subkjh.bas.dao.control.DbTrans)
	 */
	@Override
	public boolean onClosed(DbTrans dbTrans) {
		
		Logger.logger.info(String.format("onClosed : [%s][rowcnt : %d ea]", getName(), getDataLoder().getTotalInsertCount()));
		
		if(getQidList() == null) {
			Logger.logger.info(String.format("[%s] nothing qid....", getName()));
			return true;
		}
		
		ElaspedTime ept = new ElaspedTime();
		
		if(this.isDebugMode()) {
			Logger.logger.error(String.format("$$$ Entered DebugMode[%s]", getName()));
			try {
				String debugQuery = String.format("insert into %s_D select * from %s", getTableName(), getTableName());
				dbTrans.executeSql(debugQuery, null);
			} catch (Exception e) {
				setErrMsg(String.format("exception[%s][%s]]", getName(), e.getMessage()));
				Logger.logger.error(String.format("exception[%s][%s],[%s]", getName(), e.getMessage(), MiscUtils.getStackTraceStringFromException(e)));
				return false;
			}
		} else {			
			for(String qid : getQidList()) {
				Logger.logger.info(String.format(" -- execute qid: [%s][%s]", getName(), qid));
				try {
						ept.start();
						int rowCnt = dbTrans.create(qid, null);
						setAffectedRow(rowCnt);
						ept.end();
						Logger.logger.info(String.format("qid affected row : [%s][%d ea][%s sec][%s]", getName(), rowCnt, ept.getElaspedSecString(), qid));
					
				}catch (SQLException sqe){ //SQL Exception 발생시 ErrorCode 표시 
					setErrMsg(String.format("exception[%s][%s]]", getName(), sqe.getMessage()));
					Logger.logger.error(String.format("exception[%s][%s],[%s]", getName(), sqe.getMessage(), MiscUtils.getStackTraceStringFromException(sqe)));
					
					String smsMsg = String.format("%s연동실패-%s[ORA-%s]발생",getName(),sqe.getClass().getSimpleName(),sqe.getErrorCode());
					sendSms(smsMsg);
					
					return false;
				}catch (Exception e) {  
					setErrMsg(String.format("exception[%s][%s]]", getName(), e.getMessage()));
					Logger.logger.error(String.format("exception[%s][%s],[%s]", getName(), e.getMessage(), MiscUtils.getStackTraceStringFromException(e)));
					
					String smsMsg = String.format("%s연동실패-%s",getName(),e.getClass().getSimpleName()); //Exception 클래스만 표시
					sendSms(smsMsg);
					
					return false;
				}
			}
		}
		
		eltTime.end();
		Logger.logger.info(String.format("overall stat.. : [%s][%s sec][affectedRow:%d ea][vaild:%d ea][invalid:%d ea]",
					getName(), eltTime.getElaspedSecString(), getAffectedRow(), validDataCount, inValidDataCount));
		return true;
	}
	
	//exception 발생시 SYSINFO 그룹에 SMS 발송(2021-02-19)
	private void sendSms(String msg) {
		HashMap<String, String> hmap = new HashMap<String, String>();
		
		try {
			DataBase database = DBManager.getMgr().getDataBase("ADAMS_MIAPP");
			
			DbTrans smsTran = database.createDbTrans(ClSmsInfoQid.QUERY_XML_FILE);
			
			String sTodate = new SimpleDateFormat("YYYY/MM/dd HH:mm").format(Calendar.getInstance().getTime());
			String msgStr = "[ADAMS][W]\n"
						  + "[발생시각] "+sTodate+"\n"
						  + "[장애내용] ["+InetAddress.getLocalHost().getHostName() + "]" + msg + "\n"
						  + "[장애조치] 연동파일 확인 및 로그 확인\n"
						  + "※관련 운용자는 확인 후 신속한 대응(필요시 장애대응 단톡방 오픈) 바랍니다.";

			hmap.put("hostNm", String.format("%s", InetAddress.getLocalHost().getHostName()));
			hmap.put("smsMsg", String.format("%s", msgStr));
			Logger.logger.info("hostname : " + hmap.get("hostNm"));
			Logger.logger.info("msg : " + hmap.get("smsMsg"));
			
			smsTran.start();
			int totCnt = smsTran.execute(ClSmsInfoQid.INSERT_TBL_SUBMIT_QUEUE_EXCEPTION, hmap);
			Logger.logger.info("totCnt : " + totCnt);
			smsTran.stop();
		} catch (Exception e) {
			Logger.logger.error("SMS Send Exception : " + e.getMessage());
		}
	}
}
