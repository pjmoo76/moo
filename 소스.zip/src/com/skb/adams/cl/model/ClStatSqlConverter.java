package com.skb.adams.cl.model;

import com.skb.adams.cm.util.MiscUtils;

import subkjh.bas.log.Logger;

public class ClStatSqlConverter {
	protected	String	baseDt = null;
	protected	String	baseDt_1d = null;
	
	public ClStatSqlConverter() {
	}
	
	public void setBaseDt(String baseDt) throws Exception {
		this.baseDt = baseDt;
		this.baseDt_1d = MiscUtils.addDays(baseDt, "yyyyMMdd", 1);
	}

	public String convert(String qid, String sql) {
		if (baseDt != null) {
			sql = sql.replace("$_BASE_DT_", baseDt);
			sql = sql.replace("$_BASE_DT_1D_", baseDt_1d);
			Logger.logger.info(sql);
		}
		return sql;
	}

}
