package com.skb.adams.cl.model;

public class EquipInfoVO {
	private String	equipId;
	private	String	equipMgmtNum;
	private	String	tpoCd;
	private	String	mgmtTpoCd;
	private	String	equipIpAddr;
	private	String	equipUsgCd;
	
	public EquipInfoVO() {
		
	}

	public String getEquipId() {
		return equipId;
	}
	public void setEquipId(String equipId) {
		this.equipId = equipId;
	}
	public String getEquipMgmtNum() {
		return equipMgmtNum;
	}
	public void setEquipMgmtNum(String equipMgmtNum) {
		this.equipMgmtNum = equipMgmtNum;
	}
	public String getTpoCd() {
		return tpoCd;
	}
	public void setTpoCd(String tpoCd) {
		this.tpoCd = tpoCd;
	}
	public String getMgmtTpoCd() {
		return mgmtTpoCd;
	}
	public void setMgmtTpoCd(String mgmtTpoCd) {
		this.mgmtTpoCd = mgmtTpoCd;
	}
	public String getEquipIpAddr() {
		return equipIpAddr;
	}
	public void setEquipIpAddr(String equipIpAddr) {
		this.equipIpAddr = equipIpAddr;
	}
	public String getEquipUsgCd() {
		return equipUsgCd;
	}
	public void setEquipUsgCd(String equipUsgCd) {
		this.equipUsgCd = equipUsgCd;
	}
	public String getEquipMdlTypCd() {
		return equipMdlTypCd;
	}
	public void setEquipMdlTypCd(String equipMdlTypCd) {
		this.equipMdlTypCd = equipMdlTypCd;
	}
	private	String	equipMdlTypCd;
}
