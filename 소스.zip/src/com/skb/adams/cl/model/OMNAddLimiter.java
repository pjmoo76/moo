package com.skb.adams.cl.model;

import java.util.List;

import subkjh.bas.dao.control.DbTrans;

public class OMNAddLimiter extends OMNBaseHandler {
	
	public List<String> parse(String line, DbTrans dbTrans) {
	
		char limiter = getDataDelimiter();
		if (line.contains(String.valueOf(limiter))) {
			
			String tempStr = line + limiter;
			
			return super.parse(tempStr, dbTrans);
		}
		
		return null;
	}
	
}
