package com.skb.adams.cl.model;

import java.util.ArrayList;
import java.util.List;

import com.skb.adams.cm.util.MiscUtils;

import subkjh.bas.dao.control.DbTrans;

public class SwingOntPortHandler extends OMNBaseHandler {
	private ArrayList<String> reUseTempList = new ArrayList<String>();

	@Override
	public List<String> parse(String line, DbTrans dbTrans) {

		String[] tokens = MiscUtils.split(line, getDataDelimiter(), reUseTempList);
		// 10 : TV회선수 (VOD:IPTV:VOD+IPTV)
		// 11 : 서비스기술방식 (net:phone:vod:iptv)
		// 13 : 서비스번호 (net:phone:vod:iptv)
		// 14 : 가입자원부상태 (net:phone:vod:iptv)
		if (tokens.length >= 10) {
			tokens[9] = tokens[9].replace(':', getDataDelimiter());
		}
		if (tokens.length >= 11) {
			tokens[10] = tokens[10].replace(':', getDataDelimiter());
		}
		if (tokens.length >= 13) {
			tokens[12] = tokens[12].replace(':', getDataDelimiter());
		}
		if (tokens.length >= 14) {
			tokens[13] = tokens[13].replace(':', getDataDelimiter());
		}
		StringBuffer sb = new StringBuffer();
		for(String tok : tokens) {
			sb.append(tok);
			sb.append(getDataDelimiter());
		}
		
		return super.parse(sb.toString(), dbTrans);
	}

}
