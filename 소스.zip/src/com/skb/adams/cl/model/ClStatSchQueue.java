package com.skb.adams.cl.model;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;

import subkjh.bas.log.Logger;

import com.skb.adams.cm.util.MutexLock;

public class ClStatSchQueue {
	static final int	WAIT_10_MINUTE	= (10 * 60 *1000);
	static final int	MAX_RETRY_CNT	= 3;
	
	class TaskStatus {
		public String	baseTime;
		public int		retryCnt;
		public long		nextExecTime;
		public String	reqNum;
		public boolean	isCondChk;
	}
	class ClStatSchObj {
		ClStatSchInfo		schInfo;
		List<TaskStatus>	taskStatusList;
		int					threadIdx;
	}
	
	public class ClStatTask {
		public ClStatSchInfo	schInfo;
		public String			baseTime;
		public String			reqNum;
		public boolean			isCondChk;
	}
	
	Map<String, ClStatSchObj>	clStatSchObjMap = null;
	MutexLock	queueLock;
	
	public ClStatSchQueue() {
		clStatSchObjMap = new HashMap<String, ClStatSchObj>();
		queueLock = new MutexLock();
	}
	
	public void add(ClStatSchInfo schInfo, long mstime) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(mstime);
		calendar.add(Calendar.HOUR, schInfo.getClStatInfo().getBasHourDiffNum());
		
		String baseTime = String.format("%04d%02d%02d", calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH)+1, calendar.get(Calendar.DAY_OF_MONTH));
		add(schInfo, baseTime, null, schInfo.getClStatInfo().isCondChk());
	}
	
	public void add(ClStatSchInfo schInfo, String baseTime, String reqNum, boolean isCondChk) {
		synchronized(queueLock) {
			ClStatSchObj statSchObj = clStatSchObjMap.get(schInfo.getClStatInfo().getStatNm());
			if (statSchObj == null) {
				statSchObj = new ClStatSchObj();
				statSchObj.schInfo = schInfo;
				statSchObj.taskStatusList = new ArrayList<TaskStatus>();
				statSchObj.threadIdx = -1;
				clStatSchObjMap.put(schInfo.getClStatInfo().getStatNm(), statSchObj);
			}
			for (TaskStatus taskStatus : statSchObj.taskStatusList) {
				if (taskStatus.baseTime.equals(baseTime)) {
					return;
				}
			}
			TaskStatus taskStatus = new TaskStatus();
			taskStatus.baseTime = baseTime;
			taskStatus.retryCnt = 1;
			taskStatus.nextExecTime = 0;
			taskStatus.reqNum = reqNum;
			taskStatus.isCondChk = isCondChk;
			statSchObj.taskStatusList.add(taskStatus);
	
			Logger.logger.info("insert (baseTime:" + baseTime + ") to " + statSchObj.schInfo.getClStatInfo().getStatNm());
		}		
	}

	public void update(int threadIdx, ClStatResult statResult) {
		synchronized(queueLock) {
			ClStatSchObj statSchObj = clStatSchObjMap.get(statResult.getStatId());
			for (int i = 0; i < statSchObj.taskStatusList.size(); i ++) {
				if (statSchObj.taskStatusList.get(i).baseTime.equals(statResult.getBaseTime())) {
					if (statResult.isSuccYn() || statSchObj.taskStatusList.get(i).retryCnt == MAX_RETRY_CNT) {
						statSchObj.taskStatusList.remove(i);
					} else {
						statSchObj.taskStatusList.get(i).retryCnt ++;
						statSchObj.taskStatusList.get(i).nextExecTime = System.currentTimeMillis() + WAIT_10_MINUTE;
					}
					break;
				}
			}
			if (statSchObj.taskStatusList.size() == 0) {
				statSchObj.threadIdx = -1;
			}
		}
		return;
	}

	public ClStatTask get(int threadIdx) {
		synchronized(queueLock) {
			// 수행했던 동일한 task가 존재하는지 체크
			//Logger.logger.debug(threadIdx + " : (mapSize=" + clStatSchObjMap.size() + ")");
			long mstime = System.currentTimeMillis();
			for(Map.Entry<String, ClStatSchObj> entry : clStatSchObjMap.entrySet()) {
				ClStatSchObj statSchObj = entry.getValue();
				if (statSchObj.threadIdx == threadIdx) {
					for (TaskStatus taskStatus : statSchObj.taskStatusList) {
						if (taskStatus.nextExecTime < mstime) {
							ClStatTask statTask = new ClStatTask();
							statTask.schInfo = statSchObj.schInfo;
							statTask.baseTime = statSchObj.taskStatusList.get(0).baseTime;
							statTask.reqNum = statSchObj.taskStatusList.get(0).reqNum;
							statTask.isCondChk = statSchObj.taskStatusList.get(0).isCondChk;
							return statTask;
						}
					}
				}
			}
			// 없다면 새로운 task 조회
			for(Map.Entry<String, ClStatSchObj> entry : clStatSchObjMap.entrySet()) {
				ClStatSchObj statSchObj = entry.getValue();
				if (statSchObj.threadIdx == -1 && statSchObj.taskStatusList.size() > 0) {
					statSchObj.threadIdx = threadIdx;
					ClStatTask statTask = new ClStatTask();
					statTask.schInfo = statSchObj.schInfo;
					statTask.baseTime = statSchObj.taskStatusList.get(0).baseTime;
					statTask.reqNum = statSchObj.taskStatusList.get(0).reqNum;
					statTask.isCondChk = statSchObj.taskStatusList.get(0).isCondChk;
					return statTask;				
				}
			}
		}
		return null;
	}
}
