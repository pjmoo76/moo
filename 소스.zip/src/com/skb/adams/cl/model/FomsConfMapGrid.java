package com.skb.adams.cl.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.skb.adams.cl.dao.ClFomsServiceQid;
import com.skb.adams.cm.dao.OIV1040xQid;
import com.skb.adams.cm.model.OIV10100;
import com.skb.adams.cm.util.MiscUtils;
import com.skb.adams.cm.util.StringUtils;

import subkjh.bas.dao.control.DaoListener;
import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.log.Logger;

public class FomsConfMapGrid extends OMNBaseHandler implements DaoListener {

	Map<String,OIV10100>	o100Map		= new HashMap<String, OIV10100>();
	Map<String,String>		arEquipMap	= new HashMap<String,String>();
	Map<String,String>		linkIdMap	= new HashMap<String,String>();

	ClFomsServiceQid	qFoms = new ClFomsServiceQid();
	OIV1040xQid			q40x = new OIV1040xQid();
	String				auditId = "CM_FCMG";

	public FomsConfMapGrid() {
		
	}

	@Override
	public boolean onInit(DbTrans dbTrans, String fileName) {
		try {
			dbTrans.setDaoListener(this);
			dbTrans.selectQid2Res(q40x.SELECT_OIV10100, null);
			dbTrans.setDaoListener(null);
			Logger.logger.info(String.format("the size of o100Map : %d)", o100Map.size()));
		} catch (Exception e) {
			
		}
		return super.onInit(dbTrans, fileName);
	}

	@Override
	public List<String> parse(String line, DbTrans dbTrans) {
		_parse(line, dbTrans);
		//return super.parse(line, dbTrans);
		return null;
	}
	
	/*
	 * 00 : TEAMNAME
	 * 01 : TEAMCODE
	 * 02 : K_TPO_NM
	 * 03 : K_TPO_CD
	 * 04 : AR_TID
	 * 05 : AR_DOWN_IFNAME
	 * 06 : AR_DOWN_LINK_STAT
	 * 07 : DEVICENUM1
	 * 08 : TID1
	 * 09 : TPO_NM1
	 * 10 : UP_IFNAME1
	 * 11 : DOWN_IFNAME1
	 * 12 : DOWN_LINK_STAT1
	 * 13 : ...
	 */
	static final int	IDX_AR_TID				= 4;
	static final int	IDX_AR_DOWN_IFNAME		= 5;
	static final int	IDX_DEVICENUM1			= 7;
	static final int	DEVICE_INFO_CNT			= 6;
	static final int	DEVICE_NUM_IDX			= 0;
	static final int	DEVICE_UP_IFNAME_IDX	= 3;
	static final int	DEVICE_DOWN_IFNAME_IDX	= 4;
	static final int	DEVICE_MAX_NUM			= 20;

	private void _parse(String line, DbTrans dbTrans) {
		try {
			String[] tokens = MiscUtils.split(line, '|');

			// AR
			String fromEquipId = arEquipMap.get(tokens[IDX_AR_TID]);
			if (StringUtils.isEmpty(fromEquipId)) {
				fromEquipId = dbTrans.selectQidStr(qFoms.SELECT_EQUIP_ID__BY_FOMS_CONF_ARINFO, tokens[IDX_AR_TID]);
				if (StringUtils.isEmpty(fromEquipId)) {
					return;
				}
				arEquipMap.put(tokens[IDX_AR_TID], fromEquipId);
			}
			String fromMounLocNum = MiscUtils.getPortLoc(tokens[IDX_AR_DOWN_IFNAME]);
			String fromPortNum = MiscUtils.getPortNo(tokens[IDX_AR_DOWN_IFNAME]);
			String fromEquipPortId = getEquipPortId(dbTrans, fromEquipId, fromMounLocNum, fromPortNum);

			// DEVICENUM1
			OIV10100 o100 = o100Map.get(tokens[IDX_DEVICENUM1]);
			if (o100 == null) {
				return;
			}
			String toEquipId = o100.getEquipId();
			String toMounLocNum = MiscUtils.getPortLoc(tokens[IDX_DEVICENUM1+DEVICE_UP_IFNAME_IDX]);
			String toPortNum = MiscUtils.getPortNo(tokens[IDX_DEVICENUM1+DEVICE_UP_IFNAME_IDX]);
			String toEquipPortId = getEquipPortId(dbTrans, toEquipId, toMounLocNum, toPortNum);
			
			makeOIV10401(dbTrans, fromEquipId, fromEquipPortId, toEquipId, toEquipPortId);
			
			for (int i = 1; i < DEVICE_MAX_NUM-1; i ++) {
				fromEquipId = toEquipId;
				fromEquipPortId = toEquipPortId;

				int tokenNo = IDX_DEVICENUM1 + (DEVICE_INFO_CNT * i);
				if (StringUtils.isEmpty(tokens[tokenNo])) {
					break;
				}
				o100 = o100Map.get(tokens[tokenNo]);
				if (o100 == null) {
					break;
				}
				toEquipId = o100.getEquipId();
				toMounLocNum = MiscUtils.getPortLoc(tokens[tokenNo + DEVICE_UP_IFNAME_IDX]);
				toPortNum = MiscUtils.getPortNo(tokens[tokenNo + DEVICE_UP_IFNAME_IDX]);
				toEquipPortId = getEquipPortId(dbTrans, toEquipId, toMounLocNum, toPortNum);
				
				makeOIV10401(dbTrans, fromEquipId, fromEquipPortId, toEquipId, toEquipPortId);
			}

		} catch (Exception e) {
			Logger.logger.error(e);
		}
		return;
	}
	
	protected String getEquipPortId(DbTrans dbTrans, String equipId, String mounLocNum, String portNum) throws Exception {
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("equipId", equipId);
		hmap.put("mounLocNum", mounLocNum);
		hmap.put("portNum", portNum);
		String equipPortId = dbTrans.selectQidStr(q40x.SELECT_EQUIP_PORT_ID, hmap);
		if (StringUtils.isEmpty(equipPortId)) {
			// create OIV10400
			equipPortId = makeOIV10400(dbTrans, equipId, mounLocNum, portNum);
		}
		return equipPortId;
	}

	protected String makeOIV10400(DbTrans dbTrans, String equipId, String mounLocNum, String portNum) throws Exception {
		String newEquipPortId = dbTrans.selectQidStr(q40x.SELECT_NEW_EQUIP_PORT_ID, "");
		Logger.logger.debug("newEquipPortId:" + newEquipPortId);

		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("equipId", equipId);
		hmap.put("equipPortId", newEquipPortId);
		hmap.put("auditId", auditId);
		hmap.put("mounLocNum", mounLocNum);
		hmap.put("portNum", portNum);
		hmap.put("portTypCd", "0");
		hmap.put("portSpeedCd", "0");
		hmap.put("pollingMObjYn", "N");
		hmap.put("pingMObjYn", "Y");
		hmap.put("rgstCycl", "0");
		
		dbTrans.create(q40x.INSERT_OIV10400, hmap);

		return newEquipPortId;
	}
	
	protected void makeOIV10401(DbTrans dbTrans, String adrcEquipId, String adrcEquipPortId, String zdrcEquipId, String zdrcEquipPortId) throws Exception {
		String key = adrcEquipId + "|" + adrcEquipPortId + "|" + zdrcEquipId + "|" + zdrcEquipPortId;
		String linkId = linkIdMap.get(key);
		if (linkId != null) return;

		// OIV10401
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("adrcEquipId", adrcEquipId);
		hmap.put("adrcEquipPortId", adrcEquipPortId);
		hmap.put("zdrcEquipId", zdrcEquipId);
		hmap.put("zdrcEquipPortId", zdrcEquipPortId);
		linkId = dbTrans.selectQidStr(q40x.SELECT_LINK_ID__FOR_FTTX, hmap);
		if (linkId != null) {
			linkIdMap.put(key, linkId);
		} else {
			linkId = makeOIV10401(dbTrans, hmap);
			if (linkId != null) {
				linkIdMap.put(key, linkId);
			}
		}

	}

	protected String makeOIV10401(DbTrans dbTrans, HashMap<String, String> hmap) throws Exception {
		String newLinkId = dbTrans.selectQidStr(q40x.SELECT_NEW_LINK_ID, "");
		Logger.logger.debug("newLinkId:" + newLinkId);

		hmap.put("linkId", newLinkId);
		hmap.put("auditId", auditId);
		hmap.put("linkTypCd", "01");
		hmap.put("linkUsgCd", "0");
		hmap.put("linkRngCd", "000");
		
		dbTrans.create(q40x.INSERT_OIV10401, hmap);

		return newLinkId;
	}

	@Override
	public void onExecuted(Object arg0, Exception arg1) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onFinish(Exception arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onSelected(int arg0, Object data) throws Exception {
		// TODO Auto-generated method stub
		OIV10100 o100 = (OIV10100) data;
		if (StringUtils.isEmpty(o100.getEquipMgmtNum())) return;
		o100Map.put(o100.getEquipMgmtNum(), o100);				
	}

	@Override
	public void onStart(String[] arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}
}
