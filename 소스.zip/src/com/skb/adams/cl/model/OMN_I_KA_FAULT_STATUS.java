package com.skb.adams.cl.model;

import java.util.HashMap;
import java.util.List;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.log.Logger;

public class OMN_I_KA_FAULT_STATUS extends OMNBaseHandler {

	@Override
	public List<String> parse(String line, DbTrans dbTrans) {

		HashMap<String, String> hmap = new HashMap<String, String>();
		StringBuffer sResult = new StringBuffer();

		try {

			String[] txtArr = line.split("\t");
			
			hmap.put("EVT_KEY2", txtArr[0]);

			for (int i = 1; i < txtArr.length; i++) {

				String[] strKeyValue = txtArr[i].split("=");

				hmap.put(strKeyValue[0], strKeyValue[1]);
			}
			
		} catch (Exception e) {
			Logger.logger.error(e);
		}
		
		String[] columns = getColumns();
		
		for(int i=0; i<columns.length; i++) {
			if(hmap.get(columns[i]) == null) {
				sResult.append(String.format("|", hmap.get(columns[i])));
			} else {
				sResult.append(String.format("%s|", hmap.get(columns[i])));
			}
		}

		return super.parse(sResult.toString(), dbTrans);
	}

	@Override
	public String[] getColumns() {
		return getConfigedColumns();
	}

}
