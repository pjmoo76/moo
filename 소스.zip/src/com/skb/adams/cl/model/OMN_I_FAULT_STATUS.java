package com.skb.adams.cl.model;

import java.util.HashMap;
import java.util.List;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.log.Logger;

public class OMN_I_FAULT_STATUS extends OMNBaseHandler {
	
	@Override
	public List<String> parse(String line, DbTrans dbTrans) {

		HashMap<String, String> hmap = new HashMap<String, String>();
		StringBuffer sResult = new StringBuffer();

		try {

			String[] txtArr = line.split("\t");
			String[] sAreaInfo = txtArr[0].split("|");

			hmap.put("NET2", sAreaInfo[0]);
			hmap.put("TEAM", sAreaInfo[1]);
			hmap.put("INFO_CNTR", sAreaInfo[2]);
			hmap.put("DISTB_CNTR", sAreaInfo[3]);
			hmap.put("UDEV1", sAreaInfo[4]);
			hmap.put("UDEV2", sAreaInfo[5]);

			for (int i = 1; i < txtArr.length; i++) {

				String[] strKeyValue = txtArr[i].split("=");

				if(strKeyValue.length == 1) {
					hmap.put(strKeyValue[0], null);
				} else {
					hmap.put(strKeyValue[0], strKeyValue[1]);
				}
			}
		} catch (Exception e) {
			System.out.println(line);
			Logger.logger.error(e);
		}
		
		String[] columns = getColumns();
		
		for(int i=0; i<columns.length; i++) {
			if(hmap.get(columns[i]) == null) {
				sResult.append(String.format(";", hmap.get(columns[i])));
			} else {
				sResult.append(String.format("%s;", hmap.get(columns[i])));
			}
		}

		return super.parse(sResult.toString(), dbTrans);
	}

	@Override
	public String[] getColumns() {
		return getConfigedColumns();
	}
}
