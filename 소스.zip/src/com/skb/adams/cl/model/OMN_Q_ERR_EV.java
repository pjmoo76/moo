package com.skb.adams.cl.model;

import java.util.HashMap;
import java.util.List;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.log.Logger;

public class OMN_Q_ERR_EV extends OMNBaseHandler {

	@Override
	public List<String> parse(String line, DbTrans dbTrans) {

		HashMap<String, String> hmap = new HashMap<String, String>();
		StringBuffer sResult = new StringBuffer();

		try {
			
			String sAreaInfo = line;
			// Logger.logger.info("sAreaInfo : " + sAreaInfo);
			
			String[] sRecHeader = sAreaInfo.split("\",");
			// Logger.logger.info("sRecHeader_LENGTH : " + sRecHeader.length);
			
			for(int i=0; i<sRecHeader.length; i++) {
				
				// Logger.logger.info("sRecHeader[i] : " + sRecHeader[i]);
				// 마지막에 값이 없어서 ="" 로 끝나는 데이터를 위해 끝에 "를 더한다.
				sRecHeader[i] = sRecHeader[i] + "\"";
				String[] sTemp = sRecHeader[i].split("=\"");

				// split 후 " 제거
				sTemp[1] = sTemp[1].replace("\"", "");
				// Logger.logger.info("sTemp[0] : " + sTemp[0] + "  sTemp[1] : " + sTemp[1]);
				hmap.put(sTemp[0], sTemp[1]);
			}
			
		} catch (Exception e) {
			Logger.logger.error(e);
		}

		String[] columns = getDataItems();
		
		for(int i=0; i<columns.length; i++) {
			if(hmap.get(columns[i]) == null) {
				sResult.append(String.format(";", hmap.get(columns[i])));
			} else {
				sResult.append(String.format("%s;", hmap.get(columns[i])));
			}
		}
		
		return super.parse(sResult.toString(), dbTrans);
	}

}
