package com.skb.adams.cl.model;

import java.util.List;

import subkjh.bas.dao.control.DbTrans;

public class OMNBatchSts extends OMNBaseHandler {
	
	public List<String> parse(String line, DbTrans dbTrans) {
	
		if (line.contains("STATISTICS")) {
			
			String tempStr = line.substring(line.indexOf("|") + 1);
			
			return super.parse(tempStr, dbTrans);
		}
		
		return null;
	}
	
}
