package com.skb.adams.cl.model;

public class ClStatInfoVO {
	private	String	statId;
	private	String	statNm;
	private	String	statTblNm;
	private	String	cronSchVal;
	private	int		basHourDiffNum;
	private	String	qidFileNm;
	private	String	qidLstVal;
	private	String	srcPerfLstVal;
	private boolean isCondChk = false;

	public String getStatId() {
		return statId;
	}
	public void setStatId(String statId) {
		this.statId = statId;
	}
	public String getStatNm() {
		return statNm;
	}
	public void setStatNm(String statNm) {
		this.statNm = statNm;
	}
	public String getStatTblNm() {
		return statTblNm;
	}
	public void setStatTblNm(String statTblNm) {
		this.statTblNm = statTblNm;
	}
	public String getCronSchVal() {
		return cronSchVal;
	}
	public void setCronSchVal(String cronSchVal) {
		this.cronSchVal = cronSchVal;
	}
	public int getBasHourDiffNum() {
		return basHourDiffNum;
	}
	public void setBasHourDiffNum(int basHourDiffNum) {
		this.basHourDiffNum = basHourDiffNum;
	}
	public String getQidFileNm() {
		return qidFileNm;
	}
	public void setQidFileNm(String qidFileNm) {
		this.qidFileNm = qidFileNm;
	}
	public String getQidLstVal() {
		return qidLstVal;
	}
	public void setQidLstVal(String qidLstVal) {
		this.qidLstVal = qidLstVal;
	}
	public String getSrcPerfLstVal() {
		return srcPerfLstVal;
	}
	public void setSrcPerfLstVal(String srcPerfLstVal) {
		this.srcPerfLstVal = srcPerfLstVal;
	}
	public boolean isCondChk() {
		return isCondChk;
	}
	public void setCondChk(String isCondChk) {
		if(isCondChk.equalsIgnoreCase("Y"))
			this.isCondChk = true;
	}
}
