package com.skb.adams.cl.dao;

public class ClStatServiceQid {
	public static final String	SELECT_CL_PERF_INFO			= "SELECT_CL_PERF_INFO";
	public static final String	SELECT_CL_STAT_INFO			= "SELECT_CL_STAT_INFO";
	public static final String	INSERT_CL_STAT_EXEC_RSLT	= "INSERT_CL_STAT_EXEC_RSLT";
	public static final String	SELECT_CL_STAT_EXEC_REQ		= "SELECT_CL_STAT_EXEC_REQ";
	public static final String	UPDATE_CL_STAT_EXEC_REQ__START		= "UPDATE_CL_STAT_EXEC_REQ__START";
	public static final String	UPDATE_CL_STAT_EXEC_REQ__END		= "UPDATE_CL_STAT_EXEC_REQ__END";
}
