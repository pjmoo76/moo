package com.skb.adams.cl.dao;

public class ClCmServiceQid {
	public static final String	SELECT_EQUIP_ID__BY_EQUIP_IP_ADDR	= "SELECT_EQUIP_ID__BY_EQUIP_IP_ADDR";
	public static final String	SELECT_EQUIP_INFO__BY_EQUIP_IP_ADDR = "SELECT_EQUIP_INFO__BY_EQUIP_IP_ADDR";

	public static final String SELECT_EQUIP_PORT_ID = "SELECT_EQUIP_PORT_ID";
	public static final String	SELECT_EQUIP_PORT_ID__BY_EQUIP_ID = "SELECT_EQUIP_PORT_ID__BY_EQUIP_ID";
	public static final String SELECT_NEW_EQUIP_PORT_ID = "SELECT_NEW_EQUIP_PORT_ID";
	public static final String INSERT_OIV10400 = "INSERT_OIV10400";

	public static final String	SELECT_LINK_ID__BY_EQUIP_ID = "SELECT_LINK_ID__BY_EQUIP_ID";
	public static final String	SELECT_LINK_ID__BY_ADRC_EQUIP_PORT_ID = "SELECT_LINK_ID__BY_ADRC_EQUIP_PORT_ID";
	public static final String	SELECT_NEW_LINK_ID = "SELECT_NEW_LINK_ID";
	public static final String	INSERT_OIV10401 = "INSERT_OIV10401";
	
	public static final String	INSERT_OMN60208_STAT_PROLITE_NUM = "INSERT_OMN60208_STAT_PROLITE_NUM";
	
	public static final String	INSERT_OMN20208_PERF_CMTS_FEC_CISCO = "INSERT_OMN20208_PERF_CMTS_FEC_CISCO";
	public static final String	INSERT_OMN20208_PERF_CMTS_FEC_ARRIS = "INSERT_OMN20208_PERF_CMTS_FEC_ARRIS";
	
}
