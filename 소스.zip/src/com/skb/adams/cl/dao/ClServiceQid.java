package com.skb.adams.cl.dao;

public class ClServiceQid {
	public static final String	INSERT_OMN20520_I_FAULT_STATUS = "INSERT_OMN20520_I_FAULT_STATUS";
}
