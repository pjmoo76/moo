package com.skb.adams.cl.dao;

public class ClSmsInfoQid {
	public static final String QUERY_XML_FILE = "deploy/conf/sql/clSmsInfo.xml";
	
	public static final String	INSERT_TBL_SUBMIT_QUEUE_EXCEPTION = "INSERT_TBL_SUBMIT_QUEUE_EXCEPTION";
}
