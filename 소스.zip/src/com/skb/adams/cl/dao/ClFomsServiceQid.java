package com.skb.adams.cl.dao;

public class ClFomsServiceQid {
	public final String	SELECT_EQUIP_ID__BY_FOMS_CONF_ARINFO	= "SELECT_EQUIP_ID__BY_FOMS_CONF_ARINFO";
	public final String	SELECT_EQUIP_ID__BY_EQUIP_IP_ADDR	= "SELECT_EQUIP_ID__BY_EQUIP_IP_ADDR";
}
