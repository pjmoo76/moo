package com.skb.adams.cl.service;

import java.util.List;
import java.util.Map;

import com.skb.adams.cl.model.ClPerfInfoVO;
import com.skb.adams.cl.model.ClStatResult;
import com.skb.adams.cl.model.ClStatSchQueue;
import com.skb.adams.cl.model.ClStatSchQueue.ClStatTask;
import com.skb.adams.cl.model.ClStatSqlConverter;
import com.skb.adams.cm.util.ElaspedTime;
import com.skb.adams.cm.util.MiscUtils;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.Logger;

public class ClStatTaskThread extends Thread {

	static final int		WAIT_TWO_SECOND			= (2*1000);
	
	int				threadIdx	= 0;
	ClStatSchQueue	clStatSchQueue;
	String			databaseName;
	boolean			runStatus = true;
	long			affectRow;
	String			errMsg;
	ClStatManager	statMgr;
	
	public ClStatTaskThread(int threadIdx, ClStatSchQueue clStatSchQueue, String databaseName, ClStatManager statMgr) {
		this.threadIdx = threadIdx;
		this.clStatSchQueue = clStatSchQueue;
		this.databaseName = databaseName;
		this.statMgr = statMgr;
	}
	
	@Override
	public void run() {
		Logger.logger.info(String.format("-- Stat Thread[%d] running", threadIdx));
		
		while (runStatus) {
			if (true) {
				ClStatTask statTask = clStatSchQueue.get(threadIdx);
				if (statTask != null) {

					ClStatResult statResult = doTask(statTask);

					statResult.setErrMsg(errMsg);

					clStatSchQueue.update(threadIdx, statResult);
					statMgr.addStatResult(statResult);
				}
				MiscUtils.Sleep(WAIT_TWO_SECOND);
			}

			if (runStatus == false) {
				break;
			}
		}
		Logger.logger.info(String.format("!!! Exit Stat Thread : [%d]", threadIdx));
	}
	
	public boolean isRunStatus() {
		return runStatus;
	}

	public void setRunStatus(boolean runStatus) {
		this.runStatus = runStatus;
	}
	
	private ClStatResult doTask(ClStatTask statTask) {
		Logger.logger.info(String.format("running (statId=%s),(baseTime=%s) for thread[%d]",
				statTask.schInfo.getClStatInfo().getStatId(), statTask.baseTime, threadIdx));

		ClStatResult statResult = new ClStatResult();
		statResult.setStatId(statTask.schInfo.getClStatInfo().getStatId());
		statResult.setBaseTime(statTask.baseTime);
		statResult.setSuccYn(false);
		statResult.setReqNum(statTask.reqNum);

		ElaspedTime	eltTime = new ElaspedTime();
		eltTime.start();
		
		DataBase database = null;
		ClDbTrans clDbTrans = null;
		long affectRow = 0;
		errMsg = "";

		try {
			Logger.logger.info(String.format("(databaseName=%s),(qidFileName=%s)", databaseName, statTask.schInfo.getClStatInfo().getQidFileNm()));
			database = DBManager.getMgr().getDataBase(databaseName);
			clDbTrans = new ClDbTrans(database, statTask.schInfo.getClStatInfo().getQidFileNm());
			ClStatSqlConverter sqlConverter = new ClStatSqlConverter();
			sqlConverter.setBaseDt(statTask.baseTime);
			clDbTrans.setSqlConverter(sqlConverter);
			clDbTrans.start();
			
			if (checkSrcData(statTask, clDbTrans)) {
				String[] qids = statTask.schInfo.getClStatInfo().getQidLstVal().split(";");
				for (String qid : qids) {
					ElaspedTime ept = new ElaspedTime();
					ept.start();
					int rowCnt = clDbTrans.create(qid, null);
					affectRow += rowCnt;
					ept.end();
					Logger.logger.info(String.format("qid affected row : [thread=%d][%d ea][%s sec][%s]", threadIdx, rowCnt, ept.getElaspedSecString(), qid));
				}
				clDbTrans.commit();
				statResult.setAffectRowCnt(affectRow);
				statResult.setSuccYn(true);
			} else {
				Logger.logger.error(errMsg);
			}
		} catch (Exception e) {
			if (clDbTrans != null) {
				clDbTrans.rollback();
			}
			statResult.setErrMsg(e.getMessage());
			Logger.logger.error(String.format("exception[thread=%d][%s],[%s]", threadIdx, e.getMessage(), MiscUtils.getStackTraceStringFromException(e)));
		}
		eltTime.end();
		if (clDbTrans != null) clDbTrans.stop();
		
		statResult.setStartTime(MiscUtils.getTimeStrFromTime2(eltTime.getStartTime()));
		statResult.setEndTime(MiscUtils.getTimeStrFromTime2(eltTime.getEndTime()));
		statResult.setExecSec(eltTime.getElaspedSecString());
		statResult.setErrMsg(errMsg);

		Logger.logger.info(String.format("overall stat.. : [thread=%d][%s sec][affectedRow:%d ea]", threadIdx, eltTime.getElaspedSecString(), affectRow));
		return statResult;
	}
	
	private boolean checkSrcData(ClStatTask statTask, ClDbTrans clDbTrans) throws Exception {
		if (statTask.isCondChk == false) return true;
		for (ClPerfInfoVO clPerfInfo : statTask.schInfo.getClPerfInfoList()) {
			Logger.logger.info(String.format("[thread=%d](fTable=%s),(mntrCyclCd=%s),(baseTime=%s)",
					threadIdx, clPerfInfo.getfTable(), clPerfInfo.getMntrCyclCd(), statTask.baseTime));
			String qry = makeSelectQuery(clPerfInfo.getfTable(), clPerfInfo.getMntrCyclCd(), statTask.baseTime);
			if (qry == null) {
				errMsg = "checkSrcData query is null";
				return false;
			}
			List<Map<String, Object>> retObjs = clDbTrans.selectSql2Map(qry, null);
			if (retObjs.size() == 0) {
				errMsg = String.format("failed to get DATA_DATE_CNT [%s]", qry);
				return false;
			}
			Map<String, Object> retObj = retObjs.get(0);
			int dataDateCnt = Double.valueOf(retObj.get("DATA_DATE_CNT").toString()).intValue();
			int targetCnt = getDataDateCnt(clPerfInfo.getMntrCyclCd());
			if (dataDateCnt < targetCnt) {
				errMsg = String.format("invalid dataDateCnt (%d),(mntCyclCd=%s),(targetCnt=%d)", dataDateCnt, clPerfInfo.getMntrCyclCd(), targetCnt);
				return false;
			}
		}
		return true;
	}
	
	static final String	CYCL_5MIN	= "02";
	static final String	CYCL_10MIN	= "03";
	static final String	CYCL_30MIN	= "04";
	static final String	CYCL_1HOUR	= "05";
	static final String CYCL_2HOUR  = "06";
	static final String	CYCL_15MIN	= "07";
	static final String	CYCL_1DAY	= "10";
	
	private String makeSelectQuery(String fTable, String mntrCyclCd, String baseTime) {
		if (CYCL_5MIN.equals(mntrCyclCd)) {
			return String.format("select count(distinct substr(DATA_DATE,1,12)) AS DATA_DATE_CNT from CL_SVC_PERF_LOG where F_TABLE = '%s' and DATA_DATE between '%s' and '%s99' AND STATE = 'SUCCESS'", fTable, baseTime, baseTime);
		} else if (CYCL_10MIN.equals(mntrCyclCd)) {
			return String.format("select count(distinct substr(DATA_DATE,1,11)) AS DATA_DATE_CNT from CL_SVC_PERF_LOG where F_TABLE = '%s' and DATA_DATE between '%s' and '%s99' AND STATE = 'SUCCESS'", fTable, baseTime, baseTime);
		} else if (CYCL_30MIN.equals(mntrCyclCd)) {
			return String.format("select count(distinct substr(DATA_DATE,1,11)) AS DATA_DATE_CNT from CL_SVC_PERF_LOG where F_TABLE = '%s' and DATA_DATE between '%s' and '%s99' AND STATE = 'SUCCESS'", fTable, baseTime, baseTime);
		} else if (CYCL_1HOUR.equals(mntrCyclCd)) {
			return String.format("select count(distinct substr(DATA_DATE,1,10)) AS DATA_DATE_CNT from CL_SVC_PERF_LOG where F_TABLE = '%s' and DATA_DATE between '%s' and '%s99' AND STATE = 'SUCCESS'", fTable, baseTime, baseTime);
		} else if (CYCL_2HOUR.equals(mntrCyclCd)) {
			return String.format("select count(distinct substr(DATA_DATE,1,12)) AS DATA_DATE_CNT from CL_SVC_PERF_LOG where F_TABLE = '%s' and DATA_DATE between '%s' and '%s99' AND STATE = 'SUCCESS'", fTable, baseTime, baseTime);
		} else if (CYCL_15MIN.equals(mntrCyclCd)) {
			return String.format("select count(distinct substr(DATA_DATE,1,12)) AS DATA_DATE_CNT from CL_SVC_PERF_LOG where F_TABLE = '%s' and DATA_DATE between '%s' and '%s99' AND STATE = 'SUCCESS'", fTable, baseTime, baseTime);
		} else if (CYCL_1DAY.equals(mntrCyclCd)) {
			return String.format("select count(*) AS DATA_DATE_CNT from CL_SVC_PERF_LOG where F_TABLE = '%s' and DATA_DATE between '%s' and '%s99' AND STATE = 'SUCCESS' and rownum = 1", fTable, baseTime, baseTime);
		}
		return null;
	}
	
	private int getDataDateCnt(String mntrCyclCd) {
		if (CYCL_5MIN.equals(mntrCyclCd)) {
			return 12 * 24;
		} else if (CYCL_10MIN.equals(mntrCyclCd)) {
			return 6 * 24;
		} else if (CYCL_30MIN.equals(mntrCyclCd)) {
			return 2 * 24;
		} else if (CYCL_1HOUR.equals(mntrCyclCd)) {
			return 24;
		} else if (CYCL_2HOUR.equals(mntrCyclCd)) {
			return 12;
		}else if (CYCL_15MIN.equals(mntrCyclCd)) {
			return 4 * 24;
		} else if (CYCL_1DAY.equals(mntrCyclCd)) {
			return 1;
		}
		return 0;
	}
}
