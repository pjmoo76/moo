package com.skb.adams.cl.service;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.skb.adams.cl.stream.DataStream;
import com.skb.adams.cl.stream.DataStreamGzText;
import com.skb.adams.cl.stream.DataStreamText;
import com.skb.adams.cm.util.ElaspedTime;
import com.skb.adams.cm.util.FileUtils;
import com.skb.adams.cm.util.MiscUtils;
import com.skb.adams.cm.util.MutexLock;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.dao.exception.DBObjectDupException;
import subkjh.bas.dao.exception.TableNotFoundException;
import subkjh.bas.log.Logger;

public class DataLoader {
	private	String				prefix;
	private	String				targetTableName;
	private	int					valueLen = 0;
	private	String				curLoadFileName;
	private List<Object[]>		valueList;
	protected DbTrans			dstTran;
	private StringBuffer		insertSql;
	private int					totalInsertCount = 0;
	private int					curLineCount = 0;
	private int					curParsedCount = 0;
	private boolean				initSessionTable = false;
	private String				workingDir = null;
	
	private List<String>		dataDateList = new ArrayList<String>();

	private	DataHandler			dataHandler = null;

	private static MutexLock 	getDataBaseLock = new MutexLock();
	public MutexLock			dirReadLock = new MutexLock();
	
	public long					nextWorkTime = 0;
	public long					searchFileInterval = 5000; //5 sec
	
	class WorkFileInfo {
		public String		fileName;
		public String		fullFileName;
		public long			fileCreateTime = 0;
		public long			fileModifiedTime = 0;
		public long			fileSize = -1;
	}
	
	List<WorkFileInfo>			workFileInfoList = new ArrayList<WorkFileInfo>();
	
	public static DataBase getDataBase(String databaseName, String callerId, int retryCount) {
		DataBase database = null;
		
		int tryCount = 0;
		
		while(true) {
			synchronized(getDataBaseLock) {
				database = DBManager.getMgr().getDataBase(databaseName);
			}
			
			if(database == null) {
				Logger.logger.error(String.format("### Fail to getDataBase[%s][%s]", databaseName, callerId));
			} else {
				break;
			}
			tryCount++;
			Logger.logger.info(String.format("Retry[%d/%d] getDataBase[%s][%s]", tryCount, retryCount, callerId, databaseName));
			
			if(tryCount > retryCount) {
				break;
			}
			
			MiscUtils.Sleep(1000);
		}
		
		if(database == null) {
			Logger.logger.error(String.format("!!!!!! Can't getDataBase[%s][%s]", databaseName, callerId));
		}
		return database;
	}

	public DataLoader() {		
	}

	public String getPrefix() {
		return prefix;
	}

	public DataLoader setPrefix(String prefix) {
		this.prefix = prefix;
		return this;
	}


	public DataLoader setDstTran(DbTrans dstTran) {
		this.dstTran = dstTran;
		return this;
	}
	
	public DataLoader setDataHandler(DataHandler dataHandler) {
		this.dataHandler = dataHandler;
		return this;
	}
	
	public DataHandler getDataHandler() {
		return dataHandler;
	}
	
	public boolean doLoader(String fileName) {
		
		boolean ret = false;
		
		curLoadFileName = fileName;
		totalInsertCount = 0;
		curLineCount = 0;
		curParsedCount = 0;
		dataHandler.setAffectedRow(0);
		dataHandler.setErrMsg("");
		dataHandler.setAbsolutePath(fileName);
		dataDateList.clear();
		
		DataStream dataStream = null;
		
		File tmpFile = new File(fileName);
		
		if(tmpFile.length() == 0) {
			return true;
		}
		
		if(dataHandler.isUseGzFile() && tmpFile.getName().toUpperCase().contains(".GZ")) {
			dataStream = new DataStreamGzText();
		} else {
			dataStream = new DataStreamText();
		}
		
		// ret = dataStream.open(fileName, "eucKR");
		ret = dataStream.open(fileName, dataHandler.getDataFormat());
		
		if(ret == false) {
			Logger.logger.error(String.format("### Fail to open file : [%s][%s][%s]", dataHandler.getName(), fileName, dataStream.getErrMsg()));
			dataHandler.setErrMsg(dataStream.getErrMsg());
			return ret;
		}
		
		ret = onStart();
		
		if(ret == false) {
			dataStream.close();
			return false;
		}
		
		try {
			String strLine;
			while ((strLine = dataStream.readLine()) != null) {
				curLineCount++;
				if(curLineCount > dataHandler.getSkipLineCount()) {
					ret = onRead(strLine);
					if(ret == false) {
						break;
					}
				}
			}
		} catch (Exception e) {
			ret = false;
			Logger.logger.error(String.format("exception[%s][%s],[%s]", dataHandler.getName(), e.getMessage(), MiscUtils.getStackTraceStringFromException(e)));
		} finally {
			dataStream.close();
			
			if(ret) {
				ret = onFinished();
			}
		}
		return ret;
	}
	
	protected boolean onStart() {
		
		if(dataHandler == null) {
			Logger.logger.error("********* DataHandler is null.....");
			return false;
		}
		
		StringBuffer names = new StringBuffer();
		StringBuffer value = new StringBuffer();

		valueLen = 0;
		targetTableName = dataHandler.getTableName();
		
		if(dataHandler.isUseSessionTable()) {
			targetTableName = dataHandler.getTableName();
		}
		
		String[] columnNames = dataHandler.getColumns();
		Map<Integer, String> defValues = dataHandler.getDefColumnValues();
		
		if (targetTableName != null && columnNames != null && columnNames.length > 0) {

			for (int i = 0; i < columnNames.length; i ++) {
				if (names.length() > 0) {
					names.append(", ");
					value.append(", ");
				}
				names.append(columnNames[i]);
				if (defValues == null) {
					value.append("?");
					valueLen ++;
				} else {
					if (defValues.containsKey((i))) {
						value.append(defValues.get(i).trim());
						if (defValues.get(i).contains("?")) {
							valueLen ++;
						}
					} else {
						value.append("?");
						valueLen ++;
					}
				}
			}
			
			insertSql = new StringBuffer();
			insertSql.append("insert into ");
			insertSql.append(targetTableName);
			insertSql.append(" ( ");
			insertSql.append(names);
			insertSql.append(" ) values ( ");
			insertSql.append(value);
			insertSql.append(" )");
		}
		valueList = new ArrayList<Object[]>();
		
		if (dstTran == null) {
			try {
				DataBase database = getDataBase(dataHandler.getDatabaseName(), dataHandler.getName(), 999999);
				
				if(database != null) {
					//Logger.logger.info(String.format("try get dstTran[%s][%s]", dataHandler.getName(), dataHandler.getQidFileName()));
					if(dataHandler.getQidFileName() != null) {
						String[] qidFileNames = dataHandler.getQidFileName().split(";");
						//dstTran = database.createDbTrans(dataHandler.getQidFileName());
						dstTran = database.createDbTrans(qidFileNames);
					} else {
						dstTran = database.createDbTrans();
					}
					
					if(dstTran == null) {
						Logger.logger.error(String.format("fail to get dstTran[%s][%s]", dataHandler.getName(), dataHandler.getQidFileName()));
					} else {
						//Logger.logger.info(String.format("succeed get dstTran[%s][%s]", dataHandler.getName(), dataHandler.getQidFileName()));
					}
				}
			} catch (Exception e) {
				Logger.logger.error(String.format("Fail to get dstTran[%s][%s][%s]", dataHandler.getName(), dataHandler.getQidFileName(), e.getMessage()));
				dataHandler.setErrMsg(String.format("Fail to get dstTran[%s][%s][%s]", dataHandler.getName(), dataHandler.getQidFileName(), MiscUtils.RemoveLineFeed(e.getMessage())));
				return false;
			}
		}
		
		if(dataHandler.isUseSessionTable()) {
			if(initSessionTable == false) {
				try {
					dstTran.executeSql("drop table " + targetTableName, null);
				} catch (TableNotFoundException e) {
				} catch (Exception e) {
					Logger.logger.error(MiscUtils.getStackTraceStringFromException(e));    
				}
				
				StringBuffer createTempTableSql = new StringBuffer();
				
				createTempTableSql.append("CREATE GLOBAL TEMPORARY TABLE ");
				
				createTempTableSql.append(targetTableName);
				createTempTableSql.append(" ( ");
				
				boolean bFirst = true;
				
				for (String col : columnNames) {
					if(bFirst) {
						bFirst = false;
					} else {
						createTempTableSql.append(", ");
					}
					createTempTableSql.append(col + " varchar2(2000)");
				}
				createTempTableSql.append(") on commit delete rows");
				
				try {
					//Logger.logger.info(String.format("try create table [%s][%s]", dataHandler.getName(), targetTableName));
					dstTran.executeSql(createTempTableSql.toString(), null);
				} catch (DBObjectDupException e) {
				} catch (Exception e) {
					dataHandler.setErrMsg(String.format("fail to create table [%s][%s][%s][%s]", dataHandler.getName(), targetTableName, e.getMessage(), createTempTableSql));
					Logger.logger.error(dataHandler.getErrMsg());
					Logger.logger.error(MiscUtils.getStackTraceStringFromException(e));
					return false;
				}
				//Logger.logger.info(String.format("succeed to create table [%s][%s]", dataHandler.getName(), targetTableName));
				initSessionTable = true;
			}
			
			if(dataHandler.isDebugMode()) {
				String query = String.format("create table %s_D as select * from %s", targetTableName, targetTableName);
				
				try {
					Logger.logger.info(String.format("try create debug table [%s][%s_D]", dataHandler.getName(), targetTableName));
					dstTran.executeSql(query.toString(), null);
				} catch (DBObjectDupException e) {
				} catch (Exception e) {
					Logger.logger.error(String.format("fail to create debug table [%s][%s_D][%s][%s]", dataHandler.getName(), targetTableName, e.getMessage(), query));
					Logger.logger.error(MiscUtils.getStackTraceStringFromException(e));
					return false;
				}
			}
		}
		
		try {
			dstTran.start();
		} catch (Exception e) {
			dataHandler.setErrMsg(String.format("Fail to dstTran.start : [%s][%s]", dataHandler.getName(), MiscUtils.RemoveLineFeed(e.getMessage())));
			Logger.logger.error(dataHandler.getErrMsg());
			Logger.logger.error(MiscUtils.getStackTraceStringFromException(e));
			return false;
		}
		
		if (dataHandler != null) {
			return dataHandler.onInit(this.dstTran, curLoadFileName);
		}
		return false;
	}

	private boolean onRead(String line) {
		List<String> list = parse(line);
		// parse() 내에서 별도의 db 처리를 하고 null 리턴한 경우를 고려
		if (list == null) {
			return true;
		}
		
		if (list.size() == valueLen) {
			curParsedCount++;
			return onData(curParsedCount, list);
		} else {
			Logger.logger.error(String.format("invalid data : [%s][cnt:%d][%s]", dataHandler.getName(), list.size(), line));
		}	
		return true;
	}

	protected List<String> parse(String line) {
		
		if (dataHandler != null) {
			return dataHandler.parse(line, this.dstTran);
		}

		StringBuffer sb = new StringBuffer();
		List<String> list = new ArrayList<String>();
		char chs[] = line.toCharArray();
		for (int i = 0; i < chs.length; i++) {
			if (i > 0 && chs[i] == '|' && chs[i - 1] == '\\') {
				sb.append(chs[i]);
			} else if (chs[i] == '|') {
				list.add(sb.toString());
				sb = new StringBuffer();
			} else {
				sb.append(chs[i]);
			}
		}

		list.add(sb.toString());

		return list;
	}

	private boolean insert(List<Object[]> insertValueList) {
		
		Logger.logger.info(String.format("insert count : [%d][%s]", insertValueList.size(), dataHandler.getName()));
		
		if (insertValueList.size() == 0) {
			return true;
		}
		
		try {
			int rows = dstTran.executeSql(insertSql.toString(), insertValueList);
			totalInsertCount += rows;
			Logger.logger.info(String.format("insert complete : %d ea/%d ea[%s]", rows, totalInsertCount, dataHandler.getName()));
		} catch (Exception e) {
			Logger.logger.error(String.format("insert exception[%s][%s][%s]", dataHandler.getName(), e.getMessage(), MiscUtils.getStackTraceStringFromException(e)));
			dataHandler.setErrMsg(String.format("insert exception[%s][%s]", dataHandler.getName(), MiscUtils.RemoveLineFeed(e.getMessage())));
			return false;
		}
		return true;
	}

	protected boolean onData(int index, List<String> dataList) {

		boolean ret = true;
		
		valueList.add(dataList.toArray(new Object[dataList.size()]));

		if (index % 50000 == 0) {
			ret = insert(valueList);
			valueList.clear();
		}
		return ret;
	}

	private boolean onFinished() {
		boolean ret = false;
			
		ret = insert(valueList);
		valueList.clear();
		
		if (ret) {
			ret = dataHandler.onClosed(this.dstTran);
			
			String dateSql = "";
			try {
				if(dataHandler.getDateColumn() != null) {
					
					if(dataHandler.isConvertTime()) {
						dateSql = String.format("select TO_CHAR(TO_DATE('19700101', 'YYYYMMDD') + (MAX(%s) / 86400) + (1 / 24 * 9), 'YYYYMMDDHH24MI') as DATA_DATE from %s", dataHandler.getDateColumn(), targetTableName);
					} else {
						dateSql = String.format("select MAX(%s) as DATA_DATE from %s", dataHandler.getDateColumn(), targetTableName);
					}
					
					dataDateList.clear();
					List<Map<String, Object>> dateList = dstTran.selectSql2Map(dateSql, null);
					
					for(Map<String, Object> rowData : dateList) {
						String dateStr = rowData.get("DATA_DATE").toString();
						dataDateList.add(dateStr.trim());
					}
				}
			} catch (Exception e) {
				Logger.logger.error(String.format("exception[%s][%s][%s][%s]", dataHandler.getName(), e.getMessage(), dateSql, MiscUtils.getStackTraceStringFromException(e)));
			}
			
			if(ret == false) {
				dstTran.rollback();
			} else {
				dstTran.commit();
			}
		} else {
			dstTran.rollback();
		}
		dstTran.stop();
		return ret;
	}
	
	public String getCurLoadFileName() {
		return curLoadFileName;
	}

	public void setCurLoadFileName(String curLoadFileName) {
		this.curLoadFileName = curLoadFileName;
	}

	public int getTotalInsertCount() {
		return totalInsertCount;
	}

	public void setTotalInsertCount(int totalInsertCount) {
		this.totalInsertCount = totalInsertCount;
	}
	
	public int getCurLineCount() {
		return curLineCount;
	}

	public void setCurLineCount(int curLineCount) {
		this.curLineCount = curLineCount;
	}

	public int getCurParsedCount() {
		return curParsedCount;
	}

	public void setCurParsedCount(int curParsedCount) {
		this.curParsedCount = curParsedCount;
	}
	
	public List<String> getDataDateList() {
		return dataDateList;
	}
	public void setDataDateList(List<String> dataDateList) {
		this.dataDateList = dataDateList;
	}

	public String getWorkingDir() {
		if(workingDir == null) {
			workingDir = String.format("%s/%s/working", dataHandler.getDirName(), dataHandler.getName());
		}
		return workingDir;
	}
	
	public int getWorkFileCount() {
		return workFileInfoList.size();
	}
	
	public void setWorkFiles() {
		if(workFileInfoList.size() == 0) {
			Pattern pattern = Pattern.compile(dataHandler.getFileName());
			
			File folder = new File(getWorkingDir());
			File[] files = null;
			
			synchronized(dirReadLock) {
				files = folder.listFiles();
			}
			
			if (files == null) {
				//Logger.logger.debug(workingDir + " is empty...");
				nextWorkTime = System.currentTimeMillis() + searchFileInterval;
				return;
			}
			
			for (File file : files) {
				if (file.isFile()) {
					String fName = file.getName();
					Matcher matcher =  pattern.matcher(fName);
					if (matcher.find()) {
						WorkFileInfo wf = new WorkFileInfo();
						wf.fullFileName = file.getAbsolutePath();
						wf.fileName = file.getName();
						wf.fileSize = file.length();
						
						
						BasicFileAttributes attr;
						try {
							attr = Files.readAttributes(file.toPath(), BasicFileAttributes.class);
							wf.fileCreateTime = attr.creationTime().toMillis();
							wf.fileModifiedTime = attr.lastModifiedTime().toMillis();
						} catch (Exception e) {
							Logger.logger.error(String.format("exception[%s],[%s]", e.getMessage(), MiscUtils.getStackTraceStringFromException(e)));
						}
						
						workFileInfoList.add(wf);
					}
				}
			}
			
			if(workFileInfoList.size() > 0) {
				nextWorkTime = 0;
			} else {
				nextWorkTime = System.currentTimeMillis() + searchFileInterval;
			}
		}
	}
	
	public void LoadData(DataHandleThread handleRunner) {
		ElaspedTime ept = new ElaspedTime();
		
		int totCnt = workFileInfoList.size();
		
		if(workFileInfoList.size() > 0) {
			nextWorkTime = 0;
			WorkFileInfo wkInf = workFileInfoList.get(0);
			workFileInfoList.remove(0);
			
			Logger.logger.info(String.format("*** Start HandleData : [queued:%d][%s][%s]", totCnt, dataHandler.getName(), wkInf.fileName));
			ept.start();
			
			boolean handleRet = handleData(wkInf.fullFileName);
			
			ept.end();
			
			if(handleRet) {
				Logger.logger.info(String.format("*** End HandleData : [%s][queued:%d][%s][%s]", handleRet ? "SUCCESS" : "FAIL", totCnt, dataHandler.getName(), wkInf.fileName));
			} else {
				Logger.logger.error(String.format("### End HandleData : [%s][queued:%d][%s][%s]", handleRet ? "SUCCESS" : "FAIL", totCnt, dataHandler.getName(), wkInf.fileName));
			}
			
			String curTimeStr = MiscUtils.getCurrentTimeStr2();
			
			if(dataDateList == null || dataDateList.size() == 0) {
				Logger.logger.info(String.format("--> %s", getDataHandleResultStr(true, dataHandler, wkInf, handleRet, curTimeStr, "NONE", ept)));
			} else {
				for(String date : dataDateList) {
					Logger.logger.info(String.format("--> %s", getDataHandleResultStr(true, dataHandler, wkInf, handleRet, curTimeStr, date, ept)));
				}
			}
		}
	}
	
	public static String getDataHandleResultStr(boolean saveFile, DataHandler dataHandler, WorkFileInfo fileInf, boolean handleRet, String timeStamp, String dataDate, ElaspedTime ept) {
		String retStr = String.format("STATISTICS|%s|%s|%s|%s|%s|%s|%s|%s|%d|%d|%d|%d|%d|%s|",
				handleRet ? "SUCCESS" : "FAIL",
				timeStamp,
				dataDate,
				ept.getElaspedSecString(),
				dataHandler.getName(),
				fileInf.fileName,
				MiscUtils.getTimeStrFromTime2(fileInf.fileCreateTime),
				MiscUtils.getTimeStrFromTime2(fileInf.fileModifiedTime),
				fileInf.fileSize,
				dataHandler.getAffectedRow(),
				dataHandler.getDataLoder().getTotalInsertCount(),
				dataHandler.getDataLoder().getCurParsedCount(),
				dataHandler.getDataLoder().getCurLineCount(),
				dataHandler.getErrMsg());
		
		if(saveFile) {
			ClServiceManager.putResultLog(retStr);
		}
		
		return retStr;
	}
	
	public boolean handleData(String fileName) {
		
		boolean openRet = doLoader(fileName);

		String finalfName = null;
		
		File workFile = new File(fileName);
		
		if(openRet) {
			finalfName = String.format("%s/%s/success/%s", dataHandler.getDirName(), dataHandler.getName(), workFile.getName());
		} else {
			finalfName = String.format("%s/%s/error/%s", dataHandler.getDirName(), dataHandler.getName(), workFile.getName());
		}

		// 완료된 파일은 별도의 backup 디렉토리 move
		boolean mvRet = FileUtils.rename(fileName, finalfName);
		
		if(mvRet == false) {
			Logger.logger.info(String.format("[%s][%s] --> [%s]", mvRet ? "OK" : "FAIL", fileName, finalfName));
		}
		return openRet;
	}
}
