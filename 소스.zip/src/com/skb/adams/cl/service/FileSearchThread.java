package com.skb.adams.cl.service;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.skb.adams.cm.util.ElaspedTime;
import com.skb.adams.cm.util.FileUtils;
import com.skb.adams.cm.util.MiscUtils;

import subkjh.bas.log.Logger;
	
/* 주기적으로 처리해야 할 file search 하는 thread */
class FileSearchThread extends Thread {
	
	static private final int	WAIT_ONE_MINUTE			= (10*1000);
	
	boolean							runStatus = true;
	private	List<DataHandler>		dataHandlerInfoList;
	
	ElaspedTime ept = new ElaspedTime();
	
	public FileSearchThread(List<DataHandler> infoList) {
		this.dataHandlerInfoList = infoList;
	}

	@Override
	public void run() {
		Logger.logger.info("FileSearcher is running...");
		
		while (runStatus) {
			search();
			MiscUtils.Sleep(WAIT_ONE_MINUTE);
			// 1분 간격으로 search() 메소드를 수행한다.
		}
		
		Logger.logger.info("!!! exit data FileSearcher thread");
	}
	
	class FileInfo {
		public String 	fileName = null;
		public boolean 	used = false;
		public String 	usedBy = null;
		public long     size = 0;
		public long		checkMstime;
	}
	
	Map<String, List<FileInfo>> fileSizeCheckMap = new HashMap<String, List<FileInfo>>();
	
	private void search() {
		
		//동일 위치 검색 성능 향상 및 파일명 중복 검색 점검
		Map<String, List<FileInfo>> filInfoMap = new HashMap<String, List<FileInfo>>();
		
		ept.start();
		Logger.logger.info("## Start search....");
		
		for (DataHandler handler : dataHandlerInfoList) {
			Logger.logger.debug(String.format("searching [%s][%s][%s]", handler.getName(), handler.getDirName(), handler.getFileName()));
			
			List<FileInfo> fileInfoList = filInfoMap.get(handler.getDirName());
			
			if(fileInfoList == null) {
				
				if(fileInfoList == null) {
					fileInfoList = new ArrayList<FileInfo>();
					filInfoMap.put(handler.getDirName(), fileInfoList);
				}
				
				File folder = new File(handler.getDirName());

				File[] files = folder.listFiles();
				
				if (files == null) {
					Logger.logger.debug(String.format("empty [%s][%s][%s]", handler.getName(), handler.getDirName(), handler.getFileName()));
					continue;
				}
				
				for (File file : files) {
					if (file.isFile()) {
						
						FileInfo fi = new FileInfo();
						fi.fileName = file.getName();
						fi.size = file.length();
						fileInfoList.add(fi);
					}
				}
				Logger.logger.info(String.format("cache search....[%s][%d]", handler.getDirName(), fileInfoList == null ? 0 : fileInfoList.size()));
			}
						
			if(fileInfoList != null) {
			
				Pattern pattern = Pattern.compile(handler.getFileName());
				
				String workingDir = String.format("%s/%s/working", handler.getDirName(), handler.getName());
					
				for (FileInfo fi : fileInfoList) {
					Matcher matcher =  pattern.matcher(fi.fileName);
					if (matcher.find()) {
						// 대상 파일 찾음
						Logger.logger.debug("found " + fi.fileName);
						
						// file size check 해야 하는 경우
						if (handler.getFileSizeCheck()) {
							long mstime = System.currentTimeMillis();

							List<FileInfo> fileSizeCheckList = fileSizeCheckMap.get(handler.getDirName());
							if (fileSizeCheckList == null) {
								fileSizeCheckList = new ArrayList<FileInfo>();
								fi.checkMstime = mstime; 
								fileSizeCheckList.add(fi);
								fileSizeCheckMap.put(handler.getDirName(), fileSizeCheckList);
								Logger.logger.info(String.format("file size check : first input %s/%s (size:%d),(time:%d)", handler.getDirName(), fi.fileName, fi.size, fi.checkMstime));
								continue;
							} else {
								if (fileSizeCheckList.size() == 0) {
									fi.checkMstime = mstime; 
									fileSizeCheckList.add(fi);
									fileSizeCheckMap.put(handler.getDirName(), fileSizeCheckList);
									Logger.logger.info(String.format("file size check : first input %s/%s (size:%d),(time:%d)", handler.getDirName(), fi.fileName, fi.size, fi.checkMstime));
									continue;									
								}
								boolean equalFileSize = false;
								Iterator<FileInfo> iter = fileSizeCheckList.iterator();
								while (iter.hasNext()) {
									FileInfo oldFi = iter.next();
									if (fi.fileName.equals(oldFi.fileName)) {
										if ((oldFi.checkMstime + 60000) < mstime) {
											// 1분이 지난 후
											if (fi.size == oldFi.size) {
												// 1분 동안 file size가 변하지 않음. 최종 file로 판단
												Logger.logger.info(String.format("file size not changed : %s/%s (%d)", handler.getDirName(), fi.fileName, fi.size));
												equalFileSize = true;
												iter.remove();
											} else {
												Logger.logger.info(String.format("file size changed : %s/%s (%d -> %d)", handler.getDirName(), fi.fileName, oldFi.size, fi.size));
												oldFi.size = fi.size;
												oldFi.checkMstime = mstime;
											}
										}
										break;
									}
								}
								if (equalFileSize == false) {
									continue;
								}
							}
						}
						
						String fullPath = handler.getDirName() + "/" + fi.fileName;
						
						String newFName = workingDir + "/" + fi.fileName;
						
						if(fi.used) {
							Logger.logger.error(String.format("########### Maybe defined pattern is duplicated ... [%s][%s][%s]", fi.fileName, fi.usedBy, handler.getName()));
							continue;
						}
						
						synchronized(handler.getDataLoder().dirReadLock) {
							fi.used = true;
							fi.usedBy = handler.getName();
							boolean mvRet = FileUtils.rename(fullPath, newFName);
							Logger.logger.info(String.format("[%s][%s] --> [%s]", mvRet ? "OK" : "FAIL", fullPath, newFName));
						}
					}
				}
			}
		}
		ept.end();
		Logger.logger.info(String.format("## End search....[%s sec]", ept.getElaspedSecString()));
	}
	
	public boolean isRunStatus() {
		return runStatus;
	}

	public void setRunStatus(boolean runStatus) {
		this.runStatus = runStatus;
	}
}

