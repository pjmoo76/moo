package com.skb.adams.cl.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;

import com.skb.adams.cl.dao.ClStatServiceQid;
import com.skb.adams.cl.model.ClPerfInfoVO;
import com.skb.adams.cl.model.ClStatExecReqVO;
import com.skb.adams.cl.model.ClStatInfoVO;
import com.skb.adams.cl.model.ClStatResult;
import com.skb.adams.cl.model.ClStatSchInfo;
import com.skb.adams.cl.model.ClStatSchQueue;
import com.skb.adams.cm.util.FileUtils;
import com.skb.adams.cm.util.MiscUtils;
import com.skb.adams.cm.util.MutexLock;
import com.skb.adams.cm.util.StringUtils;

import subkjh.bas.BasCfg;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.LOG_LEVEL;
import subkjh.bas.log.Logger;
import fxms.bas.cron.Cron;

public class ClStatManager {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String	logDir = null;
		String	logId = null;
		String	debugMode = "INFO";
		for (int i = 0; i < args.length; i ++) {
			String[] tokens = args[i].split("=");
			if ("LOGDIR".equals(tokens[0].toUpperCase())) {
				logDir = tokens[1];
			} else if ("LOGID".equals(tokens[0].toUpperCase())) {
				logId = tokens[1];
			} else if ("DEBUGMODE".equals(tokens[0].toUpperCase())) {
				if ("DEBUG".equals(tokens[1].toUpperCase())) {
					debugMode = "DEBUG";
				}
			}
		}
		Logger.logger = Logger.logger.createLogger(logDir, logId);
		if ("DEBUG".equals(debugMode)) {
			Logger.logger.setLevel(LOG_LEVEL.debug);
		} else {
			Logger.logger.setLevel(LOG_LEVEL.info);
		}
		
		ClStatManager mgr = new ClStatManager();
		mgr.run();
	}
	
	private int				taskCount = 5;
	private	String			databaseName;
	private ClStatSchQueue	clStatSchQueue;
	private	ClDbTrans		clDbTrans;
	private	MutexLock		statResultLock;
	private	List<ClStatResult>				clStatResultList;
	private	Map<String, ClStatExecReqVO>	clStatExecReqMap;
	private	ClStatSchThread schThread;
	
	public void run() {
		try {
			init();

			statResultLock = new MutexLock();
			clStatSchQueue = new ClStatSchQueue();
			clStatResultList = new ArrayList<ClStatResult>();
			clStatExecReqMap = new HashMap<String, ClStatExecReqVO>();

			DataBase database = DBManager.getMgr().getDataBase("ADAMS");
			clDbTrans = new ClDbTrans(database, "deploy/conf/sql/clStatService.xml");
			clDbTrans.start();
			List<ClPerfInfoVO> clPerfInfoList = clDbTrans.selectQid2Res(ClStatServiceQid.SELECT_CL_PERF_INFO, null);
			if (clPerfInfoList == null) {
				Logger.logger.error("failed to get CL_PERF_INFO");
			}
			List<ClStatInfoVO> clStatInfoList = clDbTrans.selectQid2Res(ClStatServiceQid.SELECT_CL_STAT_INFO, null);
			if (clStatInfoList == null) {
				Logger.logger.error("failed to get CL_STAT_INFO");
			}

			schThread = new ClStatSchThread(clStatSchQueue);
			if (schThread.init(clPerfInfoList, clStatInfoList) == false) {
				Logger.logger.error("failed to schThread.init()");
				return;
			}
			schThread.start();

			ArrayList<ClStatTaskThread> taskThreads = new ArrayList<ClStatTaskThread>();
			
			for (int i = 0; i < taskCount; i ++) {
				ClStatTaskThread taskThread = new ClStatTaskThread(i+1, clStatSchQueue, databaseName, this);
				taskThread.start();
				taskThreads.add(taskThread);
			}

			runManager();

			schThread.setRunStatus(false);
			for (int i = 0; i < taskThreads.size(); i ++) {
				taskThreads.get(i).setRunStatus(false);
			}

			schThread.join();

			for (int i = 0; i < taskThreads.size(); i ++) {
				taskThreads.get(i).join();
			}
			
			insertStatResult();
			clDbTrans.stop();

		} catch (Exception e) {
			Logger.logger.error(e);
		}
	}

	public void test() {
		try {
			DataBase database = DBManager.getMgr().getDataBase("ADAMS");
			ClDbTrans tran = new ClDbTrans(database, "deploy/conf/sql/test.xml");
			tran.start();
			tran.create("INSERT_TEST", null);
			tran.stop();
		} catch (Exception e) {
			Logger.logger.error(e);
		}
	}

	public void runManager() {
		
		Logger.logger.info("-- runManager.");
		
		long nextStatExecReqTime = 0;
		
		while (true) {
			
			insertStatResult();
			
			if(checkIsFinish()) {
				break;
			}
			
			if (System.currentTimeMillis() > nextStatExecReqTime) {
				getStatExecReq();
				nextStatExecReqTime = System.currentTimeMillis() + (60*1000);
			}
			
			//for log change
			MiscUtils.Sleep(1000);
		}
		
		Logger.logger.info("!!! Exit WatchStopStatus");
	}

	boolean checkIsFinish() {
		File fileStop = new File("statStop.sts") ;
		
		if(fileStop.exists()) {
			FileUtils.rename(fileStop.getName(),"statStop.sts.waiting");
			return true;
		}
		
		File fileRun = new File("statRunning.sts") ;
		
		if(fileRun.exists() == false) {
			try {
				fileRun.createNewFile();
			} catch (IOException e) {
				Logger.logger.error(String.format("exception[%s],[%s]", e.getMessage(), MiscUtils.getStackTraceStringFromException(e)));
			}
		}
		return false;
	}
	
	boolean init() throws Exception {
		FileUtils.deleteFile("statRunning.sts");
		FileUtils.deleteFile("statStop.sts");
		FileUtils.deleteFile("statStop.sts.waiting");
		FileUtils.deleteFile("statStop.sts.ok");

		String configStage = System.getProperty("OP_STAGE", "jang2");
		
		if(configStage == null) {
			Logger.logger.error(String.format("########## Can't find define : -DOP_STAGE"));
			return false;
		}
		
		Logger.logger.info(String.format("########## selected op stage : [%s]", configStage));

		String cfgFileName = BasCfg.getHomeDeployConf() + "/cl-stat-service.xml";
		if(loadConfigData(cfgFileName, configStage) == false) {
			Logger.logger.error(String.format("### Fail to load config[cl-stat-service.xml]"));
			return false;
		}
		
		return true;
	}
	
	private boolean loadConfigData(String cfgFileName, String opStage) throws Exception {
		SAXBuilder builder = new SAXBuilder();
		Document document = builder.build(new FileInputStream(cfgFileName));
		
		if (document != null) {
			Element root = document.getRootElement();
			return configParse(root, opStage);
		}
		return false;
	}
	
	private boolean configParse(Element parent, String opStage) throws Exception {
		List<DataHandler> handlerList = new ArrayList<DataHandler>();
		
		List nodes = parent.getChildren();
		if (nodes != null) {
			Iterator arg8 = nodes.iterator();

			while (arg8.hasNext()) {
				Element node = (Element) arg8.next();
				String stage = node.getAttributeValue("stage", "jang2");
				
				if(!stage.equalsIgnoreCase(opStage)) {
					continue;
				}

				List children = node.getChildren();
				Iterator arg10 = children.iterator();
				
				while (arg10.hasNext()) {
					Element child = (Element) arg10.next();
					if (child.getName().equalsIgnoreCase("taskCount")) {
						taskCount = MiscUtils.stringToint(child.getTextTrim(), -1, null);
					} else if (child.getName().equalsIgnoreCase("database")) {
						databaseName = child.getTextTrim();
					}
				}
				Logger.logger.info(String.format("(taskCount=%d)", taskCount));
				Logger.logger.info(String.format("(databaseName=%s)", databaseName));
				return true;
			}
		}
		return false;
	}

	public void addStatResult(ClStatResult statResult) {
		synchronized(statResultLock) {
			clStatResultList.add(statResult);
		}
	}
	
	public void insertStatResult() {
		synchronized(statResultLock) {

			while (true) {
				if (clStatResultList.size() == 0) break;
				ClStatResult statResult = clStatResultList.remove(0);
				if (statResult ==  null) break;
				
				try {
					HashMap<String, String> hmap = new HashMap<String, String>();
					hmap.put("sussYn", statResult.isSuccYn() ? "Y" : "N");
					hmap.put("statId", statResult.getStatId());
					hmap.put("baseDt", statResult.getBaseTime());
					hmap.put("strtDtm", statResult.getStartTime());
					hmap.put("endDtm", statResult.getEndTime());
					hmap.put("execSec", statResult.getExecSec());
					hmap.put("afctRowCnt", ""+statResult.getAffectRowCnt());
					hmap.put("errMsg", statResult.getErrMsg());

					clDbTrans.create(ClStatServiceQid.INSERT_CL_STAT_EXEC_RSLT, hmap);
					
					if (StringUtils.isEmpty(statResult.getReqNum()) == false) {
						ClStatExecReqVO execReq = (ClStatExecReqVO) clStatExecReqMap.get(statResult.getReqNum());
						hmap.put("reqNum", statResult.getReqNum());
						clDbTrans.update(ClStatServiceQid.UPDATE_CL_STAT_EXEC_REQ__END, hmap);
					}
				} catch (Exception e) {
					Logger.logger.error(e);
				}
				
			}
			clDbTrans.commit();
		}
	}
	
	public void getStatExecReq() {
		synchronized(statResultLock) {
			Logger.logger.info("-- getStatExecReq()");
			try {
				List<ClStatExecReqVO> clStatExecReqList = clDbTrans.selectQid2Res(ClStatServiceQid.SELECT_CL_STAT_EXEC_REQ, null);
				for (ClStatExecReqVO clStatExecReq : clStatExecReqList) {
					Logger.logger.info(String.format("CL_STAT_EXEC_REQ (%s),(%s),(%s)", clStatExecReq.getReqNum(), clStatExecReq.getStatId(), clStatExecReq.getCondChkYn()));
					ClStatExecReqVO execReq = (ClStatExecReqVO) clStatExecReqMap.get(clStatExecReq.getReqNum());
					if (execReq == null) {
						clStatExecReqMap.put(clStatExecReq.getReqNum(), clStatExecReq);
						ClStatSchInfo statSchInfo = schThread.getStatSchInfo(clStatExecReq.getStatId());
						if (statSchInfo != null) {
							boolean isCondChk = clStatExecReq.getCondChkYn().equalsIgnoreCase("Y") ? true : false;
							clStatSchQueue.add(statSchInfo, clStatExecReq.getBaseDt(), clStatExecReq.getReqNum(), isCondChk);
							HashMap<String, String> hmap = new HashMap<String, String>();
							hmap.put("reqNum", clStatExecReq.getReqNum());
							clDbTrans.update(ClStatServiceQid.UPDATE_CL_STAT_EXEC_REQ__START, hmap);
						} else {
							Logger.logger.error(String.format("failed to get %s in statSchThread", clStatExecReq.getStatId()));
						}
					}
				}
			} catch (Exception e) {
				Logger.logger.error(e);
			}
			clDbTrans.commit();
		}
	}
}
