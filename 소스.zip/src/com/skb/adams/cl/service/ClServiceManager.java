package com.skb.adams.cl.service;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;

import com.skb.adams.cm.util.FileUtils;
import com.skb.adams.cm.util.MiscUtils;
import com.skb.adams.cm.util.MutexLock;

import subkjh.bas.BasCfg;
import subkjh.bas.log.LOG_LEVEL;
import subkjh.bas.log.Logger;

public class ClServiceManager {
	
	public static void main(String[] args) {
		String	logDir = null;
		String	logId = null;
		String	debugMode = "INFO";
		for (int i = 0; i < args.length; i ++) {
			String[] tokens = args[i].split("=");
			if ("LOGDIR".equals(tokens[0].toUpperCase())) {
				logDir = tokens[1];
			} else if ("LOGID".equals(tokens[0].toUpperCase())) {
				logId = tokens[1];
			} else if ("DEBUGMODE".equals(tokens[0].toUpperCase())) {
				if ("DEBUG".equals(tokens[1].toUpperCase())) {
					debugMode = "DEBUG";
				}
			}
		}
		Logger.logger = Logger.logger.createLogger(logDir, logId);
		if ("DEBUG".equals(debugMode)) {
			Logger.logger.setLevel(LOG_LEVEL.debug);
		} else {
			Logger.logger.setLevel(LOG_LEVEL.info);
			Logger.logger.info("ClServiceManager 2021-03-10 commit ver");
		}

		ClServiceManager mgr = new ClServiceManager();
		mgr.run();
	}
	
	List<DataHandler>				dataHandlerInfoList = new ArrayList<DataHandler>() ;
	FileSearchThread				fileSearchThread = null;
	List<DataHandleThread>			dataHandleThreadList = new ArrayList<DataHandleThread>() ;
	
	DataHandlerSch					dataHandlerSch = new DataHandlerSch();
	
	public static MutexLock			resultLogLock = new MutexLock();
	public static BufferedWriter	resultWriter = null;
	public static String			lastResultLogFileName = null;
	static long 					nextChangeTimeResultLogFile		= 0;
	
	//config block
	static int 						taskCount = -1;
	static String 					resultLogDir = null;
	
	public void run() {
		String configStage = System.getProperty("OP_STAGE");
		
		if(configStage == null) {
			Logger.logger.error(String.format("########## Can't find define : -DOP_STAGE"));
			return;
		}
		
		Logger.logger.info(String.format("########## selected op stage : [%s]", configStage));
		
		try {
			String cfgFileName = BasCfg.getHomeDeployConf() + "/cl-service.xml";
			if(loadConfigData(cfgFileName, configStage) == false) {
				Logger.logger.error(String.format("### Fail to load config[cl-service.xml]"));
				return;
			}
		} catch (Exception e) {
			Logger.logger.error(String.format("Fail to load config exception[%s],[%s]", e.getMessage(), MiscUtils.getStackTraceStringFromException(e)));
			return;
		}
		
		if(taskCount <= 0) {
			Logger.logger.error(String.format("taskCount is invalid [%s]", taskCount));
			return;
		}
		
		if(resultLogDir == null) {
			Logger.logger.error(String.format("resultLogDir is invalid"));
			return;
		} else {
			File logDir = new File(resultLogDir);
			if(logDir.exists()) {
				if(logDir.isFile()) {
					Logger.logger.error(String.format("resultLogDir is invalid : [%s]", resultLogDir));
					return;
				} else if(logDir.isDirectory()) {
					
				}
			} else {
				if(logDir.mkdirs() == false) {
					Logger.logger.error(String.format("Fail to create logdir : [%s]", resultLogDir));
					Logger.logger.error(String.format("resultLogDir is invalid : [%s]", resultLogDir));
					return;
				}
			}
		}
		
		try {
			if(getInterfaceInfo() == false) {
				Logger.logger.error("### fail to getInterfaceInfo...");
				return;
			}
		} catch (Exception e) {
			Logger.logger.error(String.format("exception[%s],[%s]", e.getMessage(), MiscUtils.getStackTraceStringFromException(e)));
			return;
		}
		
		if(init() == false) {
			Logger.logger.error(String.format("Fail to init"));
			return;
		}
		
		if(dataHandlerInfoList.size() == 0) {
			Logger.logger.error("### dataHandlerInfoList is empty...");
			return;
		}
		
		for (int i = 0; i < dataHandlerInfoList.size(); i ++) {
			dataHandlerSch.putDataLoader(dataHandlerInfoList.get(i).getDataLoder());
		}
		
		// taskCount 수 만큼 스레드 생성
		for (int i = 0; i < taskCount; i ++) {
			DataHandleThread dThread = new DataHandleThread(i+1, dataHandlerSch);
			Logger.logger.info(String.format("Create Thread - [%d] ", i+1));
			dThread.start();
			dataHandleThreadList.add(dThread);
		}
		
		// 파일을 찾는 스레드 생성
		fileSearchThread = new FileSearchThread(dataHandlerInfoList);
		fileSearchThread.start();
		
		MiscUtils.Sleep(1000);
		
		runManager();
		
		fileSearchThread.setRunStatus(false);
		
		for (int i = 0; i < dataHandleThreadList.size(); i ++) {
			dataHandleThreadList.get(i).setRunStatus(false);
		}
		
		fileSearchThread.setRunStatus(false);
		Logger.logger.info(String.format("--- Waiting join fileSearchThread"));
		try {
			fileSearchThread.join();
		} catch (Exception e) {
			Logger.logger.error(String.format("exception[%s],[%s]", e.getMessage(), MiscUtils.getStackTraceStringFromException(e)));
		}
		Logger.logger.info(String.format("--- OK join fileSearchThread"));
		
		for (int i =0; i < dataHandleThreadList.size(); i ++) {
			try {
				Logger.logger.info(String.format("--- Waiting join thread %d/%d", i+1, dataHandleThreadList.size()));
				dataHandleThreadList.get(i).join();
				Logger.logger.info(String.format("--- OK join thread %d/%d", i+1, dataHandleThreadList.size()));
			} catch (Exception e) {
				Logger.logger.error(String.format("exception[%s],[%s]", e.getMessage(), MiscUtils.getStackTraceStringFromException(e)));
			}
		}
		
		if(resultWriter != null) {
			try {
				resultWriter.close();
			} catch (Exception e) {
				Logger.logger.error(String.format("exception[%s],[%s]", e.getMessage(), MiscUtils.getStackTraceStringFromException(e)));
			}
		}
		
		renameResultLog();
		
		FileUtils.rename("stop.sts.waiting","stop.sts.ok");
		Logger.logger.info(String.format("************ Exit process ok.."));
	}
	
	private boolean getInterfaceInfo() throws Exception {
		String interfaceFolder = BasCfg.getHomeDeployConf() + "/clInterfaceDef";
		
		File folder = new File(interfaceFolder);
		
		if(!folder.isDirectory()) {
			return false;
		}
		
		File[] files = folder.listFiles();
		if (files == null) {
			Logger.logger.error(interfaceFolder + " is empty...");
			return false;
		}
		
		Pattern pattern = Pattern.compile(".*xml");
			
		for (File file : files) {
			if (file.isFile()) {
				String fName = file.getName();
				Matcher matcher =  pattern.matcher(fName);
				if (matcher.find()) {
					
					List<DataHandler> handlerList = loadDataHandlerInfo(file.getAbsolutePath());
					
					if(handlerList != null) {
						Logger.logger.info(String.format("succeed cl interface info : [%s]", file.getName()));
						dataHandlerInfoList.addAll(handlerList);
					} else {
						Logger.logger.error(String.format("### fail to load cl interface info : [%s]", file.getName()));
					}
				}
			}
		}
		return true;
	}
	
	private boolean loadConfigData(String cfgFileName, String opStage) throws Exception {
		SAXBuilder builder = new SAXBuilder();
		Document document = builder.build(new FileInputStream(cfgFileName));
		
		if (document != null) {
			Element root = document.getRootElement();
			return configParse(root, opStage);
		}
		return false;
	}
	
	private boolean configParse(Element parent, String opStage) throws Exception {
		List<DataHandler> handlerList = new ArrayList<DataHandler>();
		
		List nodes = parent.getChildren();
		if (nodes != null) {
			Iterator arg8 = nodes.iterator();

			while (arg8.hasNext()) {
				Element node = (Element) arg8.next();
				String stage = node.getAttributeValue("stage");
				
				if(!stage.equalsIgnoreCase(opStage)) {
					continue;
				}

				List children = node.getChildren();
				Iterator arg10 = children.iterator();
				
				while (arg10.hasNext()) {
					Element child = (Element) arg10.next();
					if (child.getName().equalsIgnoreCase("taskCount")) {
						taskCount = MiscUtils.stringToint(child.getTextTrim(), -1, null);
					} else if (child.getName().equalsIgnoreCase("resultLogDir")) {
						resultLogDir = child.getTextTrim();
					}
				}
				return true;
			}
		}
		return false;
	}
	
	private List<DataHandler> loadDataHandlerInfo(String fileName) throws Exception {
		try {
			SAXBuilder builder = new SAXBuilder();
			Document document = builder.build(new FileInputStream(fileName));
			
			if (document != null) {
				Element root = document.getRootElement();
				return dataHandleParse(root);
			}
		} catch (Exception e) {
			Logger.logger.error("failed to load : " + fileName);
			throw e;
		}
		return null;
	}
	
	private List<DataHandler> dataHandleParse(Element parent) throws Exception {
		List<DataHandler> handlerList = new ArrayList<DataHandler>();
		
		List nodes = parent.getChildren();
		if (nodes != null) {
			Iterator arg8 = nodes.iterator();

			while (arg8.hasNext()) {
				Element node = (Element) arg8.next();
				String name = node.getAttributeValue("name");

				List children = node.getChildren();
				Iterator arg10 = children.iterator();
				
				DataHandler dataHandler = null;
				
				while (arg10.hasNext()) {
					Element child = (Element) arg10.next();
					if(child.getName().equalsIgnoreCase("dataHandler")) {
						if(MiscUtils.isValidClass(child.getTextTrim())) {
							dataHandler = (DataHandler) Class.forName(child.getTextTrim()).newInstance();
							dataHandler.setName(name);
						}
					}
				}
				
				if(dataHandler == null) {
					Logger.logger.error(String.format("### fail to init datahandler[%s]", name));
					return null;
				}
				
				arg10 = children.iterator();
				
				boolean ifRet = true;

				while (arg10.hasNext()) {
					Element child = (Element) arg10.next();
					if (child.getName().equalsIgnoreCase("dir")) {
						dataHandler.setDirName(child.getTextTrim());
					} else if (child.getName().equalsIgnoreCase("file")) {
						dataHandler.setFileName(child.getTextTrim());
					} else if (child.getName().equalsIgnoreCase("table")) {
						dataHandler.setTableName(child.getTextTrim());
					} else if (child.getName().equalsIgnoreCase("database")) {
						dataHandler.setDatabaseName(child.getTextTrim());
					} else if (child.getName().equalsIgnoreCase("qidFile")) {
						dataHandler.setQidFileName(child.getTextTrim());
					} else if (child.getName().equalsIgnoreCase("sessionTable")) {
						dataHandler.setUseSessionTable(child.getTextTrim().equalsIgnoreCase("use"));
					} else if (child.getName().equalsIgnoreCase("columns")) {
						String colsStr = child.getTextTrim();
						colsStr = colsStr.replace("\n", "");
						colsStr = colsStr.replace("\r", "");
						colsStr = colsStr.replace(" ", "");
						colsStr = colsStr.trim();
						String[] cols = colsStr.split(";");
						
						ArrayList<String> colTmp = new ArrayList<String>();
						
						for(String colName : cols) {
							if(colName.trim().length() > 0) {
								colTmp.add(colName.trim());
							}
						}
						dataHandler.setConfigedColumns(colTmp.toArray(new String[colTmp.size()]));
					} else if (child.getName().equalsIgnoreCase("dataItems")) {
						String colsStr = child.getTextTrim();
						colsStr = colsStr.replace("\n", "");
						colsStr = colsStr.replace("\r", "");
						colsStr = colsStr.replace(" ", "");
						colsStr = colsStr.trim();
						String[] cols = colsStr.split(";");
						
						ArrayList<String> colTmp = new ArrayList<String>();
						
						for(String colName : cols) {
							if(colName.trim().length() > 0) {
								colTmp.add(colName.trim());
							}
						}
						dataHandler.setDataItems(colTmp.toArray(new String[colTmp.size()]));
					} else if (child.getName().equalsIgnoreCase("dateColumn")) {
						dataHandler.setDateColumn(child.getTextTrim());
					} else if (child.getName().equalsIgnoreCase("preQidList")) {
						String colsStr = child.getTextTrim();
						String[] preQids = colsStr.split(";");
						dataHandler.setPreQidList(preQids);
					} else if (child.getName().equalsIgnoreCase("qidList")) {
						String colsStr = child.getTextTrim();
						String[] qids = colsStr.split(";");
						dataHandler.setQidList(qids);
					} else if (child.getName().equalsIgnoreCase("userDate")) {
						dataHandler.setUserDateRegEx(child.getTextTrim());
					} else if (child.getName().equalsIgnoreCase("dataDelimiter")) {
						if(child.getTextTrim().length() == 1) {
							dataHandler.setDataDelimiter(child.getTextTrim().charAt(0));
						} else if(child.getTextTrim().length() == 2) {
							if(child.getTextTrim().equals("\\t")) {
								dataHandler.setDataDelimiter('\t');
							} else {
								ifRet = false;
								Logger.logger.error(String.format("******** Interface config dataDelimiter allow only 1 char : [%s]", child.getTextTrim()));
								break;
							}
						} else {
							ifRet = false;
							Logger.logger.error(String.format("******** Interface config dataDelimiter allow only 1 char : [%s]", child.getTextTrim()));
							break;
						}
					} else if (child.getName().equalsIgnoreCase("jsonFormat")) {
						dataHandler.setJsonData(child.getTextTrim().equalsIgnoreCase("use"));
					} else if (child.getName().equalsIgnoreCase("debugmode")) {
						dataHandler.setDebugMode(child.getTextTrim().equalsIgnoreCase("use"));
					} else if (child.getName().equalsIgnoreCase("skipLineCount")) {
						int skipLineCount = MiscUtils.stringToint(child.getTextTrim(), 0, "");
						if(skipLineCount > 0) {
							dataHandler.setSkipLineCount(skipLineCount);	
						}
					} else if (child.getName().equalsIgnoreCase("gzip")) {
						dataHandler.setUseGzFile(child.getTextTrim().equalsIgnoreCase("use"));
					} else if (child.getName().equalsIgnoreCase("dataformat")) {
						dataHandler.setDataFormat(child.getTextTrim());
					} else if (child.getName().equalsIgnoreCase("convertTime")) {
						dataHandler.setConvertTime(child.getTextTrim().equalsIgnoreCase("use"));
					} else if (child.getName().equalsIgnoreCase("checkFileSize")) {
						dataHandler.setFileSizeCheck(child.getTextTrim().equalsIgnoreCase("use"));
					}
				}
				
				if(ifRet) {
					dataHandler.setDataLoder(new DataLoader().setDataHandler(dataHandler));
					handlerList.add(dataHandler);
				} else {
					Logger.logger.error(String.format("******** Interface config error : [%s]", dataHandler.getName()));
				}
			}
		}
		return handlerList;
	}
	
	public void runManager() {
		
		long checkHandleThreadWorkStsTime = System.currentTimeMillis() + 3000; //5sec
		
		while (true) {
			
			if(System.currentTimeMillis() > checkHandleThreadWorkStsTime) {
				int cnt = dataHandlerSch.getKeepDataLoaderCount();
				Logger.logger.info(String.format("*** Current Thread Working Status : [%d/%d]", dataHandlerInfoList.size()-cnt, taskCount));
				checkHandleThreadWorkStsTime = System.currentTimeMillis() + 3000;
			}
			
			if(checkIsFinish()) {
				break;
			}
			//for log change
			putResultLog("");
			MiscUtils.Sleep(1000);
		}
		
		Logger.logger.info("!!! Exit WatchStopStatus");
	}
	
	boolean checkIsFinish() {
		File fileStop = new File("stop.sts") ;
		
		if(fileStop.exists()) {
			FileUtils.rename(fileStop.getName(),"stop.sts.waiting");
			return true;
		}
		
		File fileRun = new File("running.sts") ;
		
		if(fileRun.exists() == false) {
			try {
				fileRun.createNewFile();
			} catch (IOException e) {
				Logger.logger.error(String.format("exception[%s],[%s]", e.getMessage(), MiscUtils.getStackTraceStringFromException(e)));
			}
		}
		return false;
	}
	
	boolean init() {
		FileUtils.deleteFile("running.sts");
		FileUtils.deleteFile("stop.sts");
		FileUtils.deleteFile("stop.sts.waiting");
		FileUtils.deleteFile("stop.sts.ok");
		
		renameResultLog();
		
		nextChangeTimeResultLogFile = System.currentTimeMillis() + (300-((System.currentTimeMillis()/1000)%300))*1000;
		
		return true;
	}
	
	static void renameResultLog() {
		File folder = new File(resultLogDir);

		File[] files = folder.listFiles();
		
		if (files != null) {
			for (File file : files) {
				if (file.isFile()) {
					if(file.getName().endsWith("#WRITE")) {
						String newFileName = file.getAbsolutePath().replace("#WRITE", "#FIN");
						boolean mvRet = FileUtils.rename(file.getAbsolutePath(), newFileName);
						Logger.logger.info(String.format("[%s][%s] --> [%s]", mvRet ? "OK" : "FAIL", file.getAbsolutePath(), newFileName));
					}
				}
			}
		}
	}
	
	public static void putResultLog(String resLog) {
		
		if(resLog == null) {
			Logger.logger.error(String.format("something wrong....putResultLog is null"));
			return;
		}
		
		synchronized(resultLogLock) {
			if(resultWriter == null || System.currentTimeMillis() > nextChangeTimeResultLogFile) {
				lastResultLogFileName = String.format("%s/RESULT_%s#WRITE", resultLogDir, MiscUtils.getTimeStrFromTime2(System.currentTimeMillis()));
				File fl = new File(lastResultLogFileName);
				if(fl.exists()) {
					lastResultLogFileName += "_1";
				}
				try {
					if(resultWriter != null) {
						resultWriter.close();
						renameResultLog();
					}
					resultWriter = new BufferedWriter(new FileWriter(lastResultLogFileName));
				} catch (Exception e) {
					resultWriter = null;
					Logger.logger.error(String.format("Fail to open resultWriter[%s][%s][%s]", lastResultLogFileName, e.getMessage(), MiscUtils.getStackTraceStringFromException(e)));
				}
				nextChangeTimeResultLogFile = System.currentTimeMillis() + (300-((System.currentTimeMillis()/1000)%300))*1000;
			}
			
			if(resLog == null || resLog.length() == 0) {
				return;
			}
			
			if(resultWriter == null) {
				Logger.logger.error(String.format("### Can't save the log[%s]", resLog));
			} else {
				try {
					// resLog = new String(resLog.getBytes("utf-8"), "euc-kr");
					resultWriter.write(resLog);
					resultWriter.newLine();
					resultWriter.flush();
				} catch (Exception e) {
					Logger.logger.error(String.format("Fail to write resultLog[%s][%s]", e.getMessage(), MiscUtils.getStackTraceStringFromException(e)));
				}
			}
		}
	}
}
