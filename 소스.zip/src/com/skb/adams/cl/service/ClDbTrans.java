package com.skb.adams.cl.service;

import com.skb.adams.cl.model.ClStatSqlConverter;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.control.QidPool;
import subkjh.bas.dao.database.DataBase;

public class ClDbTrans extends DbTrans {
	
	ClStatSqlConverter	sqlConverter = null;

	public ClDbTrans() {
		
	}
	
	public ClDbTrans(DataBase database, String... sqlXmlFiles) throws Exception {
		super(database, sqlXmlFiles);
	}

	public ClDbTrans(QidPool sqlPool) {
		super(sqlPool);
	}

	public void setSqlConverter(ClStatSqlConverter sqlConverter) {
		this.sqlConverter = sqlConverter;
	}

	@Override
	public int executeQidSql(String qid, String sql, Object obj) throws Exception {
		if (sqlConverter != null) {
			sql = sqlConverter.convert(qid, sql);
		}
		return super.executeQidSql(qid, sql, obj);
	}
}
