package com.skb.adams.cl.service;

import java.util.ArrayList;
import java.util.List;

import com.skb.adams.cm.util.MutexLock;

public class DataHandlerSch {
	
	public MutexLock		handlerListLock = new MutexLock();
	
	List<DataLoader>		handlerList = new ArrayList<DataLoader>();

	public void putDataLoader(DataLoader Loader) {
		synchronized(handlerListLock) {
			handlerList.add(Loader);
		}
	}
	
	public DataLoader getDataLoader() {
		
		DataLoader loader = null;
		
		synchronized(handlerListLock) {
			if(handlerList.size() > 0) {
				long curTime = System.currentTimeMillis();
				for(int i = 0 ; i < handlerList.size() ; i++) {
					DataLoader tmpLoader = handlerList.get(i);
					if(tmpLoader.nextWorkTime == 0 || curTime > tmpLoader.nextWorkTime) {
						loader = tmpLoader;
						handlerList.remove(i);
						break;
					}
				}
			}
		}
		return loader;
	}
	
	public int getKeepDataLoaderCount() {
		int cnt = 0;
		synchronized(handlerListLock) {
			cnt = handlerList.size();
		}
		return cnt;
	}
}
