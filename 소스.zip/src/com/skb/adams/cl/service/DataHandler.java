package com.skb.adams.cl.service;

import java.util.List;
import java.util.Map;

import subkjh.bas.dao.control.DbTrans;

public abstract class DataHandler {
	
	public abstract List<String> parse(String line, DbTrans dbTrans);
	public abstract Map<Integer, String> getDefColumnValues();
	public abstract String[] getColumns();
	public abstract boolean onInit(DbTrans dbTrans, String fileName);
	public abstract boolean onClosed(DbTrans dbTrans) ;
	
	private	String					name;
	private String					dirName;
	private String					fileName; // regexp
	private	String					tableName;
	private	String					databaseName;
	private String					qidFileName;
	private DataLoader				dataLoder;
	private	boolean 				useSessionTable = false;
	private String[]				configedColumns = null;
	private String[]				dataItems = null;
	private String					dateColumn = null;
	private String[]				preQidList;
	private String[]				qidList;
	private String					userDateRegEx;
	private char 					dataDelimiter = '|';
	private boolean					jsonData = false;
	private boolean					debugMode = false;
	private int						skipLineCount = 0;
	private int						affectedRow = 0;
	private boolean					useGzFile = false;
	private String					errMsg = "";
	private String					dataFormat = "eucKr";
	private boolean					convertTime = false;
	private String					absolutePath = "";
	private	boolean					fileSizeCheck = false;
	
	public DataHandler() {
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDirName() {
		return dirName;
	}
	public void setDirName(String dirName) {
		this.dirName = dirName;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getDatabaseName() {
		return databaseName;
	}
	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}
	public String getQidFileName() {
		return qidFileName;
	}
	public void setQidFileName(String qidFileName) {
		this.qidFileName = qidFileName;
	}
	public DataLoader getDataLoder() {
		return dataLoder;
	}
	public void setDataLoder(DataLoader dataLoder) {
		this.dataLoder = dataLoder;
	}
	
	public boolean isUseSessionTable() {
		return useSessionTable;
	}

	public void setUseSessionTable(boolean useSessionTable) {
		this.useSessionTable = useSessionTable;
	}
	
	public String getDateColumn() {
		return dateColumn;
	}

	public void setDateColumn(String dateColumn) {
		this.dateColumn = dateColumn;
	}

	public String[] getPreQidList() {
		return preQidList;
	}

	public void setPreQidList(String[] preQidList) {
		this.preQidList = preQidList;
	}

	public String[] getQidList() {
		return qidList;
	}

	public void setQidList(String[] qidList) {
		this.qidList = qidList;
	}

	public String getUserDateRegEx() {
		return userDateRegEx;
	}

	public void setUserDateRegEx(String userDateRegEx) {
		this.userDateRegEx = userDateRegEx;
	}

	public char getDataDelimiter() {
		return dataDelimiter;
	}

	public void setDataDelimiter(char dataDelimiter) {
		this.dataDelimiter = dataDelimiter;
	}

	public boolean isJsonData() {
		return jsonData;
	}

	public void setJsonData(boolean jsonData) {
		this.jsonData = jsonData;
	}
	public String[] getConfigedColumns() {
		return configedColumns;
	}
	public void setConfigedColumns(String[] configedColumns) {
		this.configedColumns = configedColumns;
	}
	public String[] getDataItems() {
		return dataItems;
	}
	public void setDataItems(String[] dataItems) {
		this.dataItems = dataItems;
	}
	public boolean isDebugMode() {
		return debugMode;
	}
	public void setDebugMode(boolean debugMode) {
		this.debugMode = debugMode;
	}
	public int getSkipLineCount() {
		return skipLineCount;
	}
	public void setSkipLineCount(int skipLineCount) {
		this.skipLineCount = skipLineCount;
	}
	public int getAffectedRow() {
		return affectedRow;
	}
	public void setAffectedRow(int affectedRow) {
		//pbs 추후 array로 변경필요
		this.affectedRow = affectedRow;
	}

	public boolean isUseGzFile() {
		return useGzFile;
	}
	public void setUseGzFile(boolean useGzFile) {
		this.useGzFile = useGzFile;
	}
	public String getErrMsg() {
		return errMsg;
	}
	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}
	public String getDataFormat() {
		return dataFormat;
	}
	public void setDataFormat(String dataFormat) {
		this.dataFormat = dataFormat;
	}
	public boolean isConvertTime() {
		return convertTime;
	}
	public void setConvertTime(boolean convertTime) {
		this.convertTime = convertTime;
	}
	public String getAbsolutePath() {
		return absolutePath;
	}
	public void setAbsolutePath(String absolutePath) {
		this.absolutePath = absolutePath;
	}
	public boolean getFileSizeCheck() {
		return fileSizeCheck;
	}
	public void setFileSizeCheck(boolean fileSizeCheck) {
		this.fileSizeCheck = fileSizeCheck;
	}
}
