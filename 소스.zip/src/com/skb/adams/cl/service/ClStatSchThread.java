package com.skb.adams.cl.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import subkjh.bas.log.Logger;

import com.skb.adams.cl.model.ClPerfInfoVO;
import com.skb.adams.cl.model.ClStatInfoVO;
import com.skb.adams.cl.model.ClStatSchInfo;
import com.skb.adams.cl.model.ClStatSchQueue;
import com.skb.adams.cm.util.MiscUtils;
import com.skb.adams.cm.util.MutexLock;

import fxms.bas.cron.Cron;

public class ClStatSchThread extends Thread {

	static final int	WAIT_30_SECOND			= (30*1000);
	
	ClStatSchQueue		clStatSchQueue;
	boolean				runStatus = true;
	List<ClStatSchInfo>	clStatSchInfoList = null;
	private	MutexLock	schLock;
	
	public ClStatSchThread(ClStatSchQueue clStatSchQueue) {
		this.clStatSchQueue = clStatSchQueue;
		schLock = new MutexLock();
	}
	
	public boolean init(List<ClPerfInfoVO> clPerfInfoList, List<ClStatInfoVO> clStatInfoList) throws Exception {
		synchronized(schLock) {
			HashMap<String, ClPerfInfoVO> clPerfInfoMap = new HashMap<String, ClPerfInfoVO>();
			for (ClPerfInfoVO clPerfInfo : clPerfInfoList) {
				Logger.logger.debug(String.format("(%s),(%s),(%s)", clPerfInfo.getfTable(), clPerfInfo.getClctNmsClCd(), clPerfInfo.getMntrCyclCd()));
				clPerfInfoMap.put(clPerfInfo.getfTable(), clPerfInfo);
			}
			clStatSchInfoList = new ArrayList<ClStatSchInfo>();
			for (ClStatInfoVO clStatInfo : clStatInfoList) {
				Logger.logger.debug(String.format("(%s),(%s),(%s),(%s),(%s),(%s),(%s)"
						, clStatInfo.getStatId(), clStatInfo.getCronSchVal(), clStatInfo.getBasHourDiffNum()
						, clStatInfo.getQidFileNm(), clStatInfo.getQidLstVal(), clStatInfo.getSrcPerfLstVal()
						, clStatInfo.isCondChk()));
	
				ClStatSchInfo clStatSchInfo = new ClStatSchInfo();
				clStatSchInfo.setClStatInfo(clStatInfo);
				clStatSchInfo.setCron(new Cron());
				clStatSchInfo.getCron().setCron(clStatInfo.getCronSchVal());
				clStatSchInfo.setClPerfInfoList(new ArrayList<ClPerfInfoVO>());
				String[] srcPerfs = clStatInfo.getSrcPerfLstVal().split(";");
				for (String srcPerf : srcPerfs) {
					ClPerfInfoVO clPerfInfo = clPerfInfoMap.get(srcPerf);
					if (clPerfInfo == null) {
						Logger.logger.error(String.format("failed to find ClPerfInfo(%s) in %s", srcPerf, clStatInfo.getStatId()));
						return false;
					}
					clStatSchInfo.getClPerfInfoList().add(clPerfInfo);
				}
				clStatSchInfoList.add(clStatSchInfo);
			}
		}
		return true;
	}

	@Override
	public void run() {
		Logger.logger.info("-- Schedule Thread running");
		
		while (runStatus) {
			if(true) {
				long mstime = System.currentTimeMillis();
				synchronized(schLock) {
					for (ClStatSchInfo clStatSchInfo : clStatSchInfoList) {
						Logger.logger.info(clStatSchInfo.getClStatInfo().getStatId() + " : " + clStatSchInfo.getCron().toString());
						if (clStatSchInfo.getCron().isOnTime(mstime)) {
							Logger.logger.info("-- time to start " + clStatSchInfo.getClStatInfo().getStatId());
							clStatSchQueue.add(clStatSchInfo, mstime);
						}
					}
				}
				MiscUtils.Sleep(WAIT_30_SECOND);
			}

			if(runStatus == false) {
				break;
			}
		}
		Logger.logger.info("!!! Exit Schedule Thread");
	}
	
	public boolean isRunStatus() {
		return runStatus;
	}

	public void setRunStatus(boolean runStatus) {
		this.runStatus = runStatus;
	}
	
	public ClStatSchInfo getStatSchInfo(String statId) {
		ClStatSchInfo retObj = null;
		synchronized(schLock) {
			for (ClStatSchInfo clStatSchInfo : clStatSchInfoList) {
				if (clStatSchInfo.getClStatInfo().getStatId().equals(statId)) {
					retObj = clStatSchInfo;
					break;
				}
			}
		}
		return retObj;
	}
}
