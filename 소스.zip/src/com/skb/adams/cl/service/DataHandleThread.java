package com.skb.adams.cl.service;

import com.skb.adams.cm.util.MiscUtils;

import subkjh.bas.log.Logger;
	
/* dataLoader scheduler */ 
class DataHandleThread extends Thread {

	static final int		WAIT_TWO_SECOND			= (2*1000);
	
	int						threadIdx	= 0;
	boolean					runStatus = true;
	DataHandlerSch			dataHandlerSch = null;
	
	public DataHandleThread(int threadIdx, DataHandlerSch handlerSch) {
		this.threadIdx = threadIdx;
		dataHandlerSch = handlerSch;
	}

	@Override
	public void run() {
		Logger.logger.info(String.format("-- Data Handle Thread[%d] running", threadIdx));
		
		while (runStatus) {
			if(true) {
				DataLoader dataLoader = dataHandlerSch.getDataLoader();
				
				if(dataLoader == null) {
					MiscUtils.Sleep(WAIT_TWO_SECOND);
				} else {
					dataLoader.setWorkFiles();
					if(dataLoader.getWorkFileCount() > 0) {
						Logger.logger.info(String.format("getDataLoader [%s]", dataLoader.getDataHandler().getName()));
						dataLoader.LoadData(this);
						Logger.logger.info(String.format("putDataLoader [%s]", dataLoader.getDataHandler().getName()));
					}
					dataHandlerSch.putDataLoader(dataLoader);
				}
			}

			if(runStatus == false) {
				break;
			}
		}
		Logger.logger.info(String.format("!!! Exit Data Handle Thread : [%d]", threadIdx));
	}
	
	public boolean isRunStatus() {
		return runStatus;
	}

	public void setRunStatus(boolean runStatus) {
		this.runStatus = runStatus;
	}
}
