package com.skb.adams.gw.swms;

import java.net.InetSocketAddress;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import subkjh.bas.log.Logger;

import com.google.gson.Gson;

import fxms.bas.fxo.service.ext.handler.RestaHandler;
import fxms.bas.fxo.service.ext.resta.Resta;

public class SwmsRestaHandler extends RestaHandler {

	private String url;

	@SuppressWarnings("unchecked")
	private byte[] getResult(boolean result, Object obj) {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("result", result ? "ok" : "error");
		if (result) {
			jsonObj.put("result-value", obj);
		} else {
			jsonObj.put("errmsg", obj);
		}

		//String jsonSt = jsonObj.toJSONString();
		String jsonSt = new Gson().toJson(jsonObj);
		// System.out.println("AmiReqPdu >>> jsonSt: " + jsonSt);

		return jsonSt.getBytes();
	}

	@Override
	protected byte[] onProcess(InetSocketAddress client, Set<Entry<String, List<String>>> header, String body) throws Exception {
		try {
			return onProcess(header, body);
		}catch(Exception e) {
			Logger.logger.error(e);
			return getResult(false, e.getMessage());
		}
	}
	
	@Override
	protected byte[] onProcess(Set<Entry<String, List<String>>> header, String body) throws Exception {
		try {
			return process(header, body);
		}catch(Exception e) {
			Logger.logger.error(e);
			return getResult(false, e.getMessage());
		}
	}

	private byte[] process(Set<Entry<String, List<String>>> header, String body) throws Exception {
		if(body == null) {
			return getResult(false, "Check Usage");
		}

		JSONParser parser = new JSONParser();
		JSONObject obj = (JSONObject) parser.parse(body);

		String method = obj.get("method").toString();
		Map<String, Object> para = new HashMap<String, Object>();

		for (Object key : obj.keySet()) {
			para.put(key.toString(), obj.get(key));
		}

		Map<String, Object> result = callSwms(method, para);

		return getResult(true, result);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Map<String, Object> callSwms(String method, Map<String, Object> para) throws Exception {
		XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
		config.setServerURL(new URL(url));
		XmlRpcClient client = new XmlRpcClient();

		client.setConfig(config);

		Object[] params = new Object[] { para };
		Object resultObj = client.execute(method, params);
		Map<String, Object> retMap = (Map) resultObj;
		return retMap;
	}

	@Override
	public void setResta(Resta resta) throws Exception {
		super.setResta(resta);

		Object ip = getResta().get("swms.server.ip");
		Object port = getResta().get("swms.server.port");
		// "http://219.248.49.66:7777"
		url = "http://" + ip + ":" + port;
	}
}
