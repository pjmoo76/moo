package com.skb.adams.gw.rms;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AmiResPdu implements IResPdu {

	private List<List<String>> dataList = new ArrayList<List<String>>();
	private byte recvBytes[] = new byte[0];
	private boolean toFinish = false;
	private int totalLength = 0;

	@Override
	public List<List<String>> getDataList() {
		return dataList;
	}

	private void addData(List<String> data) {
		dataList.add(data);
		toFinish = true;
	}

	@Override
	public int addByte(byte body[]) {

		totalLength += body.length;

		int totalSize = recvBytes.length + body.length;
		byte allBytes[] = new byte[totalSize];

		System.arraycopy(recvBytes, 0, allBytes, 0, recvBytes.length);
		System.arraycopy(body, 0, allBytes, recvBytes.length, body.length);

		int parsedCount = parse(allBytes);

		if (parsedCount > 0) {
			recvBytes = new byte[allBytes.length - parsedCount];
			System.arraycopy(allBytes, parsedCount, recvBytes, 0, recvBytes.length);
		} else {
			recvBytes = allBytes;
		}

		return totalLength;
	}

	private int parse(byte bytes[]) {
		if (bytes.length < 4) {
			return 0;
		}
		byte pdu[];
		int index = 0;
		int count = 0;
		List<String> entry;

		try {
			A: while (index < bytes.length) {
				if (bytes[index] == AmiReqPdu.HEADER[0]) {
					for (int i = index+1; i < bytes.length; i++) {
						if (bytes[i] == AmiReqPdu.FOOTER[0] ) {
							pdu = new byte[i - index];
							System.arraycopy(bytes, index, pdu, 0, pdu.length);
							entry = new ArrayList<String>();
							parse(entry, pdu);
							addData(entry);
							index = i + 1;
							count = index;
							continue A;
						}
					}
					break;
				} else {
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return count;
	}

	public boolean isToFinish() {
		return toFinish;
	}

	public void parse(List<String> list, byte body[]) {

		int s = AmiReqPdu.HEADER.length;
		int e = s;
		while (s < body.length - AmiReqPdu.FOOTER.length && e < body.length - AmiReqPdu.FOOTER.length) {
			if (body[e] == AmiReqPdu.DELIM) {
				if (body[s] == AmiReqPdu.DELIM) {
					list.add(new String());
				} else {
					byte[] subbody = Arrays.copyOfRange(body, s, e);
					list.add(new String(subbody, Charset.forName("euc-kr")));
				}

				s = e + 1;
				e = s;
			} else {
				e++;

				if (e == body.length - AmiReqPdu.FOOTER.length) {
					byte[] subbody = Arrays.copyOfRange(body, s, e);
					list.add(new String(subbody, Charset.forName("euc-kr")));
					break;
				}
			}
		}

	}

}
