package com.skb.adams.gw.rms;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import subkjh.bas.log.Logger;

public class RmsClient {

	public static void main(String[] args) {
		try {
			// cm.server.ip=210.220.163.178
			// cm.server.port=30012
			CmReqPdu pdu = new CmReqPdu();
			pdu.open();
			pdu.append("1");
			pdu.append("CM411001");
			// para.put("reqType", "1");
			// para.put("cmtsName", "WB133011");
			// para.put("cmtsName", "CM411001");
			//
			CmResPdu resPdu = new CmResPdu(0, "1");

			RmsClient client = new RmsClient();
			client.call("210.220.163.178", 30012, pdu.getBytes(), resPdu);

			List<List<String>> list = resPdu.getDataList();
			if (list != null) {
				for (List<String> entry : list) {
					System.out.println(entry);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void call(String rmsIp, int rmsPort, byte bytes[], IResPdu resPdu) throws Exception {

		long ptime = System.currentTimeMillis();
		int readLength = 0;
		
		try {
			Socket socket = new Socket(rmsIp, rmsPort);

			Logger.logger.debug("CONNECT " + rmsIp + ":" + rmsPort);

			// 입력 스트림
			// 서버에서 보낸 데이터를 받음
			InputStream in = socket.getInputStream();

			// 출력 스트림
			// 서버에 데이터를 송신
			OutputStream out = socket.getOutputStream();

			// 서버에 데이터 송신
			out.write(bytes);
			out.flush();

			Logger.logger.debug("WROTE " + bytes.length);

			byte tmp[];
			int len;
			while (true) {
				len = in.available();
				Logger.logger.debug("READ = " + len);
				if (len == 0) {
					Thread.sleep(500);
					if (System.currentTimeMillis() > ptime + 120000) {
						break;
					}
					continue;
				}
				if (len < 0) {
					break;
				}
				tmp = new byte[len];
				len = in.read(tmp);
				readLength = resPdu.addByte(tmp);
				if (resPdu.isToFinish())
					break;
			}

			// 서버 접속 끊기
			in.close();
			out.close();
			socket.close();
			
			Logger.logger.debug("READ " + readLength);


		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}
	}
}
