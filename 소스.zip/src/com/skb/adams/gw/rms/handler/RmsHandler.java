package com.skb.adams.gw.rms.handler;

import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import subkjh.bas.log.Logger;
import fxms.bas.fxo.service.ext.handler.RestaHandler;

public class RmsHandler extends RestaHandler {

	@Override
	protected byte[] onProcess(Set<Entry<String, List<String>>> arg0, String arg1) throws Exception {

		StringBuffer sb = new StringBuffer();

		sb.append(Logger.fill("/rms/cmlist", 40, ' '));
		sb.append("v1, v2\n");

		return sb.toString().getBytes();
	}

}
