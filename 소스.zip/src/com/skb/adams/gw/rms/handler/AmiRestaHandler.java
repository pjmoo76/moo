package com.skb.adams.gw.rms.handler;

import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import subkjh.bas.log.Logger;

import com.google.gson.Gson;
import com.skb.adams.gw.rms.RmsClient;
import com.skb.adams.gw.rms.AmiReqPdu;
import com.skb.adams.gw.rms.AmiResPdu;

import fxms.bas.fxo.service.ext.handler.RestaHandler;
import fxms.bas.fxo.service.ext.resta.Resta;

public class AmiRestaHandler  extends RestaHandler {

	private String amiIp;
	private int amiPort;
	
	//{"reqType":"SysInfo","reqFunc":"view","userId":"1002424","modemKey1":"00300D65B5D3","modemKey2":"N/A","modemIp":"10.100.111.228"}?
	//v0=SysInfo&v1=view&v2=1002424&v3=00300D65B5D3&v4=N/A&v5=10.100.111.228
	
	//{"reqType":"LanPort","reqFunc":"view","userId":"1002424","modemKey1":"00300D65B5D3","modemKey2":"N/A","modemIp":"10.100.111.228"}?
	//v0=LanPort&v1=view&v2=1002424&v3=00300D65B5D3&v4=N/A&v5=10.100.111.228

	private AmiReqPdu getReqPdu(String body) throws Exception {
		AmiReqPdu pdu = new AmiReqPdu();

		String interfaceNm;
		String resType;
		int reqCnt;
		String[] field;
		
		if(getMethod().equals("GET")) {
			Map<String, Object> map = new HashMap<String, Object>();
			this.parseBody(body, map);

			interfaceNm = map.get("interfaceNm").toString();
			resType = map.get("resType").toString();
			field = map.get("field").toString().split(",");
			reqCnt = Integer.parseInt(map.get("reqCnt").toString());

			pdu.open();

			for(int i=0; i<reqCnt; i++) {
				pdu.append(map.get(field[i]).toString());
			}
		}else {
			JSONParser parser = new JSONParser();
			JSONObject obj = (JSONObject) parser.parse(body);

			interfaceNm = obj.get("interfaceNm").toString();
			resType = obj.get("resType").toString();
			field = obj.get("field").toString().split(",");
			reqCnt = Integer.parseInt(obj.get("reqCnt").toString());

			pdu.open();

			for(int i=0; i<reqCnt; i++) {
				pdu.append(obj.get(field[i]).toString());
			}
		}

		pdu.setInterfaceNm(interfaceNm);
		pdu.setResType(resType);
		pdu.setReqCnt(reqCnt);
		pdu.setField(field);

		return pdu;
	}

	@SuppressWarnings("unchecked")
	private byte[] getResult(boolean result, Object obj) {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("result", result ? "ok" : "error");
		if(result) {
			jsonObj.put("result-value", obj);
		}else {
			jsonObj.put("errmsg", obj);
		}

		//String jsonSt = jsonObj.toJSONString();
		String jsonSt = new Gson().toJson(jsonObj);
		//System.out.println("AmiReqPdu >>> jsonSt: " + jsonSt); 

		return jsonSt.getBytes();
	}

	@Override
	protected byte[] onProcess(InetSocketAddress client, Set<Entry<String, List<String>>> header, String body) throws Exception {
		try {
			return onProcess(header, body);
		}catch(Exception e) {
			Logger.logger.error(e);
			return getResult(false, e.getMessage());
		}
	}
	
	@Override
	protected byte[] onProcess(Set<Entry<String, List<String>>> header, String body) throws Exception {
		try {
			return process(header, body);
		}catch(Exception e) {
			Logger.logger.error(e);
			return getResult(false, e.getMessage());
		}
	}

	@SuppressWarnings("unchecked")
	private byte[] process(Set<Entry<String, List<String>>> header, String body) throws Exception {
		if(body == null) {
			return getResult(false, "Check Usage");
		}

		AmiReqPdu pdu = getReqPdu(body);
		byte sendBytes[] = pdu.getBytes();
		if(sendBytes.length < 5) {
			return getResult(false, "Check Data");
		}

		AmiResPdu resPdu = new AmiResPdu();

		new RmsClient().call(this.amiIp, this.amiPort, sendBytes, resPdu);

		JSONObject jsonObj;
		JSONArray jArray = new JSONArray();
		
		for(List<String> list : resPdu.getDataList()) {
			jsonObj = new JSONObject();
			if("ARRAY".equals(pdu.getResType())) {
				JSONArray jSubArray = new JSONArray();
				JSONObject jSubObj = null;
				int size = pdu.getField().length-(pdu.getReqCnt()+1);
				for(int i=0; i<list.size(); i++) {
					if(i<=pdu.getReqCnt()) jsonObj.put(pdu.getField()[i], list.get(i));
					if("1".equals(list.get(pdu.getReqCnt())) && i>pdu.getReqCnt()) {
						if((i-(pdu.getReqCnt()+1))%size == 0) {
							if(jSubObj != null) jSubArray.add(jSubObj);
							jSubObj = new JSONObject();
						}
						jSubObj.put(pdu.getField()[(pdu.getReqCnt()+1)+(i%size)], list.get(i));
						if(i==(list.size()-1)) jSubArray.add(jSubObj);
					}
				}
				jsonObj.put("list",jSubArray);
				jArray.add(jsonObj);
			}else if("SINGLE".equals(pdu.getResType())) {
				for(int i=0; i<list.size(); i++) {
				    jsonObj.put(pdu.getField()[i], list.get(i));
				}
				jArray.add(jsonObj);
			}
		}

		return getResult(true, jArray);
	}

	@Override
	public void setResta(Resta resta) throws Exception {
		super.setResta(resta);

		Object ip = getResta().get("ami.server.ip");
		Object port = getResta().get("ami.server.port");

		this.amiIp = ip.toString();
		this.amiPort = Integer.parseInt(port.toString());
	}

}