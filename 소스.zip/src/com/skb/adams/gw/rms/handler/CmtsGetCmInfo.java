package com.skb.adams.gw.rms.handler;

import com.skb.adams.gw.rms.RmsBasRestaHandler;

public class CmtsGetCmInfo extends RmsBasRestaHandler {

	@Override
	public String getUsage() {
		return null;
	}
}
