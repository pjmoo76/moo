package com.skb.adams.gw.rms;

import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.google.gson.Gson;

import subkjh.bas.log.Logger;
import fxms.bas.fxo.service.ext.handler.RestaHandler;
import fxms.bas.fxo.service.ext.resta.Resta;

public class RmsBasRestaHandler extends RestaHandler {

	private String rmsIp;
	private int rmsPort;

	private CmReqPdu getReqPdu(String body) throws Exception {
		CmReqPdu pdu = new CmReqPdu();

		String interfaceNm;
		String resType;
		int reqCnt;
		String[] field;
		
		if(getMethod().equals("GET")) {
			Map<String, Object> map = new HashMap<String, Object>();
			this.parseBody(body, map);

			interfaceNm = map.get("interfaceNm").toString();
			resType = map.get("resType").toString();
			field = map.get("field").toString().split(",");
			reqCnt = Integer.parseInt(map.get("reqCnt").toString());

			pdu.open();

			for(int i=0; i<reqCnt; i++) {
				pdu.append(map.get(field[i]).toString());
			}
		}else {
			JSONParser parser = new JSONParser();
			JSONObject obj = (JSONObject) parser.parse(body);

			interfaceNm = obj.get("interfaceNm").toString();
			resType = obj.get("resType").toString();
			field = obj.get("field").toString().split(",");
			reqCnt = Integer.parseInt(obj.get("reqCnt").toString());

			pdu.open();

			for(int i=0; i<reqCnt; i++) {
				pdu.append(obj.get(field[i]).toString());
			}
		}

		pdu.setInterfaceNm(interfaceNm);
		pdu.setResType(resType);
		pdu.setReqCnt(reqCnt);
		pdu.setField(field);
		
		return pdu;
	}

	@SuppressWarnings("unchecked")
	private byte[] getResult(boolean result, Object obj) {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("result", result ? "ok" : "error");
		if(result) {
			jsonObj.put("result-value", obj);
		}else {
			jsonObj.put("errmsg", obj);
		}

		//String jsonSt = jsonObj.toJSONString();
		String jsonSt = new Gson().toJson(jsonObj);
		System.out.println("AmiReqPdu >>> jsonSt: " + jsonSt); 

		return jsonSt.getBytes();
	}

	@Override
	protected byte[] onProcess(InetSocketAddress client, Set<Entry<String, List<String>>> header, String body) throws Exception {
		try {
			return onProcess(header, body);
		}catch(Exception e) {
			Logger.logger.error(e);
			return getResult(false, e.getMessage());
		}
	}
	
	@Override
	protected byte[] onProcess(Set<Entry<String, List<String>>> header, String body) throws Exception {
		try {
			return process(header, body);
		}catch(Exception e) {
			Logger.logger.error(e);
			return getResult(false, e.getMessage());
		}
	}

	@SuppressWarnings("unchecked")
	private byte[] process(Set<Entry<String, List<String>>> header, String body) throws Exception {
		if(body == null) {
			return getResult(false, "Check Usage");
		}

		CmReqPdu pdu = getReqPdu(body);
		byte sendBytes[] = pdu.getBytes();
		if(sendBytes.length < 5) {
			return getResult(false, "Check Data");
		}

		CmResPdu resPdu = new CmResPdu(0, "1");

		new RmsClient().call(this.rmsIp, this.rmsPort, sendBytes, resPdu);

		JSONObject jsonObj;
		JSONArray jArray = new JSONArray();
		for(List<String> list : resPdu.getDataList()) {
			jsonObj = new JSONObject();
			for(int i=0; i<list.size(); i++) {
			    jsonObj.put(pdu.getField()[i+pdu.getReqCnt()], list.get(i));
			}
			jArray.add(jsonObj);
		}
		
		return getResult(true, jArray);
	}

	@Override
	public void setResta(Resta resta) throws Exception {
		super.setResta(resta);

		Object rmsIp = getResta().get("rms-ip");
		Object rmsPort = getResta().get("rms-port");

		this.rmsIp = rmsIp.toString();
		this.rmsPort = Integer.parseInt(rmsPort.toString());
	}

}