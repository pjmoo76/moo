package com.skb.adams.gw.rms;

import java.util.List;

public interface IResPdu {

	public int addByte(byte body[]);

	public List<List<String>> getDataList();

	public boolean isToFinish();
	
}
