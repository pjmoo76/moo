package com.skb.adams.gw.rms;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class AmiReqPdu {

	public final static byte[] HEADER = new byte[] { 0x02 };
	public final static byte[] FOOTER = new byte[] { 0x03 };
	public final static byte DELIM = (byte) '|';

	private ByteBuffer data = ByteBuffer.allocate(1024);
	private boolean appendDelimeter = false;

	private String interfaceNm;
	private String resType;
	private int reqCnt;
	private String[] field;
	
	public String getInterfaceNm() {
		return interfaceNm;
	}

	public void setInterfaceNm(String interfaceNm) {
		this.interfaceNm = interfaceNm;
	}

	public String getResType() {
		return resType;
	}

	public void setResType(String resType) {
		this.resType = resType;
	}

	public int getReqCnt() {
		return reqCnt;
	}

	public void setReqCnt(int reqCnt) {
		this.reqCnt = reqCnt;
	}

	public String[] getField() {
		return field;
	}

	public void setField(String[] field) {
		this.field = field;
	}

	public static void main(String[] args) throws Exception {
		CmReqPdu pdu = new CmReqPdu();
		pdu.open();
		pdu.append("1");
		pdu.append("CM411001");
		System.out.println(pdu.getBytes().length);
	}

	public void open(int size) {
		data = ByteBuffer.allocate(size);
		data.order(ByteOrder.BIG_ENDIAN);
		data.clear();
		data.put(HEADER);
	}

	public void open() {
		open(1024);
	}

	public void append(String value) throws Exception {

		if (appendDelimeter) {
			data.put(DELIM);
		}

		data.put(value.getBytes());
		appendDelimeter = true;
	}

	public byte[] getBytes() {
		data.put(FOOTER);
		byte bytes[] = new byte[data.position()];
		data.rewind();
		data.get(bytes);
		return bytes;
	}
}
