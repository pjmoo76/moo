package com.skb.adams.co.service;

import java.net.ServerSocket;
import java.net.Socket;

import fxms.bas.fxo.thread.FxThread;
import subkjh.bas.log.Logger;

public class CommandService extends FxThread {

	private	int				portNo = 0;
	private	CommandReceiver	receiver;
	private	ServerSocket	serverSocket;
	
	public CommandService(String name, int portNo) {
		super(name);
		this.portNo = portNo;
	}
	
	public void setReceiver(CommandReceiver receiver) {
		this.receiver = receiver;
	}
	
	@Override
	protected void doInit() {
		// TODO Auto-generated method stub
		try {
			serverSocket = new ServerSocket(portNo);
		} catch (Exception e) {
			Logger.logger.error(e);
			this.stop("INIT_FAILED");
		}
	}

	@Override
	protected void doWork() {
		while (isContinue()) {
			try {
				Socket socket = serverSocket.accept();
				String sessionName = String.format("%s:%d", socket.getInetAddress().toString(), socket.getLocalPort());
				CommandSession session = new CommandSession(sessionName, socket, receiver);
				Logger.logger.info("connected " + sessionName);
				session.start();
			} catch (Exception e) {
				Logger.logger.error(e);
				//this.stop("WORK_FAILED");
			}
		}
	}

	@Override
	protected void onStopped() {
		try {
			if (serverSocket != null) serverSocket.close();
		} catch (Exception e) {
			
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CommandService commandService = new CommandService("CommandService", 5001);
		commandService.start();
	}

}
