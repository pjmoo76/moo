package com.skb.adams.co.service;

import java.io.InputStream;
import java.io.OutputStream;

public class Command {
	/*
	 * packet structure
	 * - type : 2 byte
	 * - size : 4 byte
	 * - body : n byte
	 */
	private	byte[] buf;
	private	String	type;
	private	String	body;

	public Command() {
		buf = new byte[6]; // type + size;
	}
	
	public String getType() {
		return this.type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String getBody() {
		return this.body;
	}
	
	public void setBody(String body) {
		this.body = body;
	}
	
	public boolean read(InputStream	is) throws Exception {
		type = null;
		body = null;
		int len = is.read(buf);
		if (len == -1) return false;
		type = new String(buf, 0, 2);
		int dataLen = Integer.parseInt(new String(buf, 2, 4));
		if (dataLen > 0) {
			byte[] dataBuf = new byte[dataLen];
			len = is.read(dataBuf);
			if (len == -1) return false;
			body = new String(dataBuf);
		}
		
		return true;
	}

	public void write(OutputStream os) throws Exception {
		System.arraycopy(type.getBytes(), 0, buf, 0, 2);
		String bodySizeStr = String.format("%04d", body.length());
		System.arraycopy(bodySizeStr.getBytes(), 0, buf, 2, 4);
		os.write(buf);
		os.write(body.getBytes());
		os.flush();
		return;
	}
}
