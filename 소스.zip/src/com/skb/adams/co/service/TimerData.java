package com.skb.adams.co.service;

import fxms.bas.cron.Cron;

public class TimerData {
	public	String	name;
	public	Cron	cron;
	public	TimeEventReceiver	receiver;
}
