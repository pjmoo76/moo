package com.skb.adams.co.service;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.HashMap;

import subkjh.bas.BasCfg;
import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.util.MiscUtils;
import com.skb.mi.common.DBController;

import fxms.bas.cron.Cron;

public class DbBatchService {
	
	static private String	CONF_FILE		= "CONF_FILE";
	static private String	SERVICE_NAME	= "SERVICE_NAME";
	static private String	DATABASE_NAME	= "databaseName";
	static private String	SCHEDULE		= "schedule";
	static private String	SERVICE_LIST	= "serviceList";
	static private String	QID_FILE		= "qidFile";
	static private String	QUERY_LIST		= "queryList";
	static private String	DELIMETER		= ";";
	static private int		WAIT_30_SECOND	= (30*1000);
	
	
	public DbBatchService(String confFile, String serviceName) {
		
		int smsCnt = 0;
		Date startDate = new Date();
		Logger.logger = Logger.logger.createLogger(BasCfg.getHomeLogs(), "DbBatchService");
		String fileName = BasCfg.getHomeDeployConf() + File.separator + confFile;
		ConfigService configService = new ConfigService(fileName);
		//String[] serviceList = configService.getConfig(serviceName, SERVICE_LIST).split(DELIMETER);
		HashMap<String,String> itemMap = configService.getConfigMap(serviceName);
		if (itemMap == null) {
			return;
		}
		String serviceListName = itemMap.get(SERVICE_LIST);
		String[] serviceList = null;
		if (serviceListName == null) {
			serviceList = new String[1];
			serviceList[0] = serviceName;
		} else {
			serviceList = serviceListName.split(DELIMETER);
		}
		String databaseName = itemMap.get(DATABASE_NAME);
		if (databaseName == null) {
			databaseName = "ADAMS";
		}
		String schedule = itemMap.get(SCHEDULE);
		HashMap<String,String> qidMap = new HashMap<String,String>();
		HashMap<String,String[]> serviceQueryMap = new HashMap<String,String[]>();
		for (int i = 0; i < serviceList.length; i ++) {
			serviceList[i] = serviceList[i].trim();
			String qidFile = configService.getConfig(serviceList[i], QID_FILE);
			String val = qidMap.get((String)qidFile);
			if (val == null) {
				qidMap.put(qidFile, qidFile);
			}
			String[] queryList = configService.getConfig(serviceList[i], QUERY_LIST).split(DELIMETER);
			for (int j = 0; j < queryList.length; j ++) {
				queryList[j] = queryList[j].trim();
				//Logger.logger.debug(String.format("%s[%d] %s", serviceList[i], j, queryList[j]));
			}
			serviceQueryMap.put(serviceList[i], queryList);
		}
		
		String[] qidList = new String[qidMap.size()];
		int i = 0;
		for (String key : qidMap.keySet()) {
			qidList[i] = key;
			Logger.logger.info("qidFile : " + key);
		}
		
		for (i = 0; i < serviceList.length; i ++) {
			Logger.logger.info(String.format("Service[%d] : %s", i, serviceList[i]));
			String[] queryList = serviceQueryMap.get(serviceList[i]);
			String tmp = "";
			for (int j = 0; j < queryList.length; j ++) {
				if (j == 0) {
					tmp = queryList[j];
				} else {
					tmp = tmp + "," + queryList[j];
				}
			}
			Logger.logger.info(" -- " + tmp);
		}
		
		try {
			DataBase database = DBManager.getMgr().getDataBase(databaseName);
			DbTrans tran = database.createDbTrans(qidList);
			if (schedule == null) {
				for (i = 0; i < serviceList.length; i ++) {
					String[] queryList = serviceQueryMap.get(serviceList[i]);
					for (int j = 0; j < queryList.length; j ++) {
						Logger.logger.info("do " + queryList[j]);
						tran.execute(queryList[j], null);
					}
				}
				tran.commit();				
			} else {
				Cron cron = new Cron();
				cron.setCron(schedule);
				while (true) {
					long mstime = System.currentTimeMillis();
					if (cron.isOnTime(mstime)) {
						Logger.logger.info("onTime: " + schedule);
						for (i = 0; i < serviceList.length; i ++) {
							String[] queryList = serviceQueryMap.get(serviceList[i]);
							for (int j = 0; j < queryList.length; j ++) {
								Logger.logger.info("do " + queryList[j]);
								tran.execute(queryList[j], null);
								tran.commit();
							}
						}
						tran.commit();
					}
					MiscUtils.Sleep(WAIT_30_SECOND);
				}
			}			
		Date endDate = new Date();
		long diff = endDate.getTime() - startDate.getTime();		
		Logger.logger.info("end"+ diff);
		//90초 초과시 경고 SMS 전송	2023-04-14 제거 강대윤
		if("INTEG_QLTY_DMG".equals(serviceName) && diff > 90000)
		{
			// 제거 
			//sendSms("[ADAMS_batch01] DB_BATCH_SERVICE_장애LC 데이터생성배치  90초 초과");
		}
		} catch (Exception e) {
			Logger.logger.error(e);
			//1회만 전송되도록 변경 
			if(smsCnt==0)
			{
				
				sendSms("[ADAMS_batch01] DB_BATCH_SERVICE_" + serviceName+ " 오류발생");
			}
			smsCnt++;
			
		}

	}
	public static void sendSms(String sendMsg){
		
		DataBase database = DBManager.getMgr().getDataBase("ADAMS");
		
				
		String	query;
    	query = "merge into TBL_SUBMIT_QUEUE t "
    			+ "using ( "
 		       + "SELECT	TBL.* "
 		       + "	,	(CASE WHEN LENGTHB(TBL.SND_MSG)<80 THEN '00' ELSE '10'  END) as USED_CD "
 		       + "	,	(CASE WHEN LENGTHB(TBL.SND_MSG)<80 THEN 0 ELSE 1  END) as CONTENT_CNT "
 		       + "FROM ( "
		       + "select null as CMP_MSG_ID "
		       + "  ,  'CO' as CMP_MSG_GROUP_ID "
		       + "  , '5464' as USR_ID "
		       + "  , '1' as SMS_GB "
//		       + "  , '00' as USED_CD "
		       + "  , 'I' as RESERVED_FG "
		       + "  , to_char(sysdate,'YYYYMMDDHH24MISS') as RESERVED_DTTM "
		       + "  , '0' as SAVED_FG "
		       + "  , replace(a.PHON_NUM,'-','') as RCV_PHN_ID "
		       + "  , '07078051228' as SND_PHN_ID "
		       + "  , '82' as NAT_CD "
		       + "  , '00000' as ASSIGN_CD "
		       + "  , '[ADAMS][W]' || CHR(10)	||"
		       + "    '[발생시각] ' || TO_CHAR(SYSDATE, 'YYYY/MM/DD HH24:MI') || CHR(10) ||"
		       + "    '[장애내용] ' || ? || CHR(10) ||"
		       + "    '[장애조치] 3회 연속 발생시 Process 확인 후 조치 '  || CHR(10)	||"
		       + "    '※관련 운용자는 확인 후 신속한 대응(필요시 장애대응 단톡방 오픈) 바랍니다.' as SND_MSG "
		       + "from ( "
		       + "     SELECT USER_NM AS NM, USER_PHON_NUM AS PHON_NUM	FROM OCO40291 "
		       + "     WHERE MSG_TRMS_ID IN ('DEFTL001') AND USER_TYP_CD = 'RCV' "		       
		       + "   ) a "
		       + "   ) TBL "
		       + ") s "
		       + "on (t.CMP_MSG_ID = s.CMP_MSG_ID) "
		       + "when not matched then "
		       + "insert (CMP_MSG_ID, CMP_MSG_GROUP_ID, USR_ID, SMS_GB, USED_CD, RESERVED_FG, RESERVED_DTTM, SAVED_FG, RCV_PHN_ID, SND_PHN_ID, NAT_CD, ASSIGN_CD, SND_MSG) "
		       + "values (MI_APP.TBL_SUBMIT_QUEUE_SEQ.NEXTVAL, s.CMP_MSG_GROUP_ID, s.USR_ID, s.SMS_GB, s.USED_CD, s.RESERVED_FG, s.RESERVED_DTTM, s.SAVED_FG, s.RCV_PHN_ID, s.SND_PHN_ID, s.NAT_CD, s.ASSIGN_CD, s.SND_MSG) "
         ;
    	
		try {			
			//String className = "oracle.jdbc.driver.OracleDriver";			
			Connection connection = DriverManager.getConnection(database.getUrl(), database.getUser(), database.getPassword());
			
			PreparedStatement stmt = connection.prepareStatement(query);
	    	stmt.setString(1, sendMsg);		
			
			stmt.executeQuery();
			stmt.close();			
			connection.close ();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.logger.error(e);			
		}
	}
	public static void main(String[] args) {
		
		// confFile=
		String confFile = null;
		String serviceName = null;
		for (int i = 0; i < args.length; i ++) {
			String[] tokens = args[i].split("=");
			if (CONF_FILE.equals(tokens[0].toUpperCase())) {
				confFile = tokens[1];
			} else if (SERVICE_NAME.equals(tokens[0].toUpperCase())) {
				serviceName = tokens[1];
			}
		}
		
		
		
		new DbBatchService(confFile, serviceName);
	}

}
