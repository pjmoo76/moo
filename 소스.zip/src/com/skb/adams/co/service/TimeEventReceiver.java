package com.skb.adams.co.service;

public interface TimeEventReceiver {
	public void onTimeEvent(String name);
}
