package com.skb.adams.co.service;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

import subkjh.bas.log.Logger;

public class CommandClient {
	private	String			ipAddress;
	private	int				portNo;
	private	OutputStream	os;
	private InputStream		is;


	public CommandClient(String ipAddress, int portNo) {
		this.ipAddress = ipAddress;
		this.portNo = portNo;
	}
	
	public void run() {
		try {
			Socket socket = new Socket(ipAddress, portNo);
			os = socket.getOutputStream();
			is = socket.getInputStream();
			Command command = new Command();
			command.setType("12");
			command.setBody("test");
			command.write(os);
			Thread.sleep(1*1000);
		} catch (Exception e) {
			Logger.logger.error(e);
		}
	}

	public static void main(String[] args) {
		// args[0] : ipAddress
		// args[1] : portNo
		String ipAddress = args[0];
		int portNo = Integer.parseInt(args[1]);
		CommandClient client = new CommandClient(ipAddress, portNo);
		client.run();
	}

}
