package com.skb.adams.co.service;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

import fxms.bas.fxo.thread.FxThread;
import subkjh.bas.log.Logger;

public class CommandSession extends FxThread {
	private	Socket			socket;
	private	CommandReceiver	receiver;
	private	InputStream		is;
	private	OutputStream	os;

	public CommandSession(String name, Socket socket, CommandReceiver receiver) {
		super(name);
		this.socket = socket;
		this.receiver = receiver;
	}

	@Override
	protected void doInit() {
		// TODO Auto-generated method stub
		try {
			is = socket.getInputStream();
			os = socket.getOutputStream();
		} catch (Exception e) {
			Logger.logger.error(e);
			this.stop("INIT_FAILED");
		}
	}

	@Override
	protected void doWork() {
		// TODO Auto-generated method stub
		try {
			Command command = new Command();
			if (command.read(is)) {
				Logger.logger.debug(String.format("(%s),(%s)", command.getType(), command.getBody()));
				if (receiver != null) {
					receiver.onCommand(command);
				}
			}
		} catch (Exception e) {
			Logger.logger.error(e);
			this.stop("WORK_FAILED");
		}
	}

	@Override
	protected void onStopped() {
		try {
			if (is != null) is.close();
			if (os != null) os.close();
			if (socket != null) socket.close();
		} catch (Exception e) {
			
		}
	}
}
