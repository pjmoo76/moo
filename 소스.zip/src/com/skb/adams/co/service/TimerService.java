package com.skb.adams.co.service;

import java.util.ArrayList;

import subkjh.bas.log.Logger;
import fxms.bas.cron.Cron;
import fxms.bas.fxo.thread.CycleFxThread;

public class TimerService extends CycleFxThread {
	
	private	ArrayList<TimerData> timerDataList = null;
	
	public TimerService(String name, String line) throws Exception {
		super(name, line);
		// TODO Auto-generated constructor stub
		timerDataList = new ArrayList<TimerData>();
	}

	@Override
	protected void doCycle(long mstime) {
		// TODO Auto-generated method stub
		Logger.logger.debug("doCycle");
		long unixtime = System.currentTimeMillis() / 1000L;
		synchronized (timerDataList) {
			for (TimerData timerData : timerDataList) {
				if (timerData.cron.isOnTime(mstime * 1000L)) {
					timerData.receiver.onTimeEvent(timerData.name);
				}
			}
		}
	}
	
	public void set(String name, String line, TimeEventReceiver receiver) throws Exception {
		TimerData timerData = new TimerData();
		timerData.name = name;
		timerData.cron = new Cron();
		timerData.cron.setCron(line);
		timerData.receiver = receiver;
		synchronized (timerDataList) {
			timerDataList.add(timerData);
		}
	}

	public static void main(String[] args) {
		try {
			TimerService timer = new TimerService("test", Cron.EVERY_MINUTES);
			timer.start();
		} catch (Exception e) {
			
		}
	}

}
