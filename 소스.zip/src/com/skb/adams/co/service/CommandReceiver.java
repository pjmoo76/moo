package com.skb.adams.co.service;

public interface CommandReceiver {
	public void onCommand(Command command);
}
