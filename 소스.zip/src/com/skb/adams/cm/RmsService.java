package com.skb.adams.cm;

import fxms.bas.fxo.service.FxService;

public interface RmsService extends FxService {

}
