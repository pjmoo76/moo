package com.skb.adams.cm.dao;

public class OES30300Qid {
	public static final String QUERY_XML_FILE = "oiv10641.xml";
	
	public OES30300Qid(){
	}
	public final String SELECT_OES30300_BY_Address = "SELECT_OES30300_BY_Address";
	public final String select_address_list = "select_address_list";
	public final String select_ldongcd_address_list = "select_ldongcd_address_list";
	public final String update_ldongcd_OIV10641 ="update_ldongcd_OIV10641";

}