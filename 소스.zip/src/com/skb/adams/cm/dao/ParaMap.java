package com.skb.adams.cm.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.model.ParaVO;

public class ParaMap {

	private Map<String, String> nameKey = new HashMap<String, String>();
	private Map<String, String> codeKey = new HashMap<String, String>();

	public String getParaName(String paraCode) {
		return codeKey.get(paraCode);
	}

	public String getParaCode(String paraName) {
		return nameKey.get(paraName);
	}

	@SuppressWarnings("unchecked")
	public ParaMap(String qid) throws Exception {

		DataBase database = DBManager.getMgr().getDataBase(CmDao.ADAMS);
		DbTrans tran = database.createDbTrans("deploy/conf/sql/" + ParaQid.QUERY_XML_FILE);

		try {
			tran.start();
			List<ParaVO> list = tran.selectQid2Res(qid, null);
			for (ParaVO vo : list) {
				nameKey.put(vo.getParaName(), vo.getParaCode());
				codeKey.put(vo.getParaCode(), vo.getParaName());
			}

		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		} finally {
			tran.stop();
		}
	}
}
