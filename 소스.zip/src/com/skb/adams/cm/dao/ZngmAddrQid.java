package com.skb.adams.cm.dao;

public class ZngmAddrQid {
	public static final String QUERY_XML_FILE = "zngm_addr.xml";
	
	public ZngmAddrQid() {
		
	}
	
	public final String DROP_TABLE_FX_TMP_OES30100 = "DROP_TABLE_FX_TMP_OES30100";
	public final String CREATE_TABLE_FX_TMP_OES30100 = "CREATE_TABLE_FX_TMP_OES30100";
	public final String INSERT_FX_TMP_OES30100 = "INSERT_FX_TMP_OES30100";
	public final String SELECT_ZNGM_ADDR = "SELECT_ZNGM_ADDR";
	public final String MERGE_OES30100__BY_FX_TMP_OES30100 = "MERGE_OES30100__BY_FX_TMP_OES30100";
	public final String DELETE_OES30100__BY_FX_TMP_OES30100 = "DELETE_OES30100__BY_FX_TMP_OES30100";

}
