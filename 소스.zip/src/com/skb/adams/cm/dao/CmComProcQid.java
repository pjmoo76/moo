package com.skb.adams.cm.dao;

/**
* File : cmComProc.xml<br>
* @since 20191227
* @author 
*
*/


public class CmComProcQid { 

/** 쿼리 모임 화일명. cmComProc.xml*/
public static final String QUERY_XML_FILE = "deploy/conf/sql/cmComProc.xml";

public CmComProcQid() { 
} 
/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
*/
public final String INSERT_TBL_SUBMIT_QUEUE_CUSTINFO = "INSERT_TBL_SUBMIT_QUEUE_CUSTINFO";
}