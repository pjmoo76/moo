package com.skb.adams.cm.dao;

/**
* File : oiv10191.xml<br>
* @since 20180104124601
* @author subkjh 
*
*/


public class OIV10191Qid { 

/** 쿼리 모임 화일명. oiv10191.xml*/
public static final String QUERY_XML_FILE = "oiv10191.xml";

public OIV10191Qid() { 
} 
/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * delete <br>		from OIV10113 <br>		where RGST_DT = to_char(sysdate, 'YYYYMMDD') <br>
*/
public final String DELETE_OIV10191 = "DELETE_OIV10191";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * INSERT<br>		  INTO OIV10191<br>		      ( RGST_DT            ' 등록일자 ' 	<br>		      , TPO_CD             ' 국사코드 ' 	<br>		      , EQUIP_ID           ' 장비ID ' 	<br>		      , CCELL_NUM          ' 커버리지셀번호 ' 	<br>		      , UPS_MGMT_MODULE_CD ' UPS관리모듈코드 ' 	<br>		      , UPS_MFACT_CD       ' UPS제조사코드 ' 	<br>		      , POLLING_M_OBJ_YN   ' POLLING감시대상여부 ' 	<br>		      , UPS_QTY            ' UPS수량 ' <br>		      , AUDIT_ID           ' 최종변경자ID ' 	<br>		)	<br>		select<br>		      to_char(sysdate, 'YYYYMMDD') as RGST_DT	<br>		      , nvl(C.TPO_CD, '-')      as TPO_CD<br>		      ,	nvl(B.EQUIP_ID, '-')    as EQUIP_ID<br>		      , nvl(B.CCELL_NUM, '-')   as CCELL_NUM<br>		      , A.UPS_MGMT_MODULE_CD    as UPS_MGMT_MODULE_CD <br>		      , A.UPS_MFACT_CD          as UPS_MFACT_CD<br>		      , A.POLLING_M_OBJ_YN      as POLLING_M_OBJ_YN<br>		      , count(1)                as UPS_QTY<br>		      , 'CM-BATCH'              as AUDIT_ID<br>		from  OIV10162 A ' UPS기본 '<br>		      left join OIV10170 B ' 커버리지셀기본 ' <br>		              on B.CCELL_ID = A.CCELL_ID<br>		      left join OIV10100 C <br>		              on C.EQUIP_ID = B.EQUIP_ID<br>		group by   <br>		      C.TPO_CD <br>		      , B.EQUIP_ID<br>		      , B.CCELL_NUM<br>		      , A.UPS_MGMT_MODULE_CD<br>		      , A.UPS_MFACT_CD<br>		      , A.POLLING_M_OBJ_YN <br>
*/
public final String INSERT_OIV10191 = "INSERT_OIV10191";

}