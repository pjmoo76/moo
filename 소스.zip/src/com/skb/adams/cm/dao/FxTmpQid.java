package com.skb.adams.cm.dao;

/**
* File : fx_tmp.xml<br>
* @since 20171228093955
* @author subkjh 
*
*/


public class FxTmpQid { 

/** 쿼리 모임 화일명. fx_tmp.xml*/
public static final String QUERY_XML_FILE = "fx_tmp.xml";

public FxTmpQid() { 
} 
/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * delete <br>		from FX_TMP_OIV10801 <br>
*/
public final String DELETE_FX_TMP_OIV10801 = "DELETE_FX_TMP_OIV10801";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * delete <br>		from FX_TMP_OIV10802 <br>
*/
public final String DELETE_FX_TMP_OIV10802 = "DELETE_FX_TMP_OIV10802";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * delete <br>		from FX_TMP_OIV10803 <br>
*/
public final String DELETE_FX_TMP_OIV10803 = "DELETE_FX_TMP_OIV10803";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * delete <br>		from FX_TMP_OIV10821 <br>
*/
public final String DELETE_FX_TMP_OIV10821 = "DELETE_FX_TMP_OIV10821";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * create table FX_TMP_OIV10801 (<br>		  MAC_ADDR_VAL 				varchar2(15) NOT NULL <br>		, IP_ADDR 					varchar2(23) <br>		, PING_ST_VAL 				varchar2(8) <br>		, PING_ST_CHG_DTM 			date <br>		, LAST_PING_ST_CHECK_DTM 	varchar2(14) <br>	) <br>
*/
public final String FX_TMP_OIV10801 = "FX_TMP_OIV10801";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * create table FX_TMP_OIV10802 (<br>		 MAC_ADDR_VAL 			VARCHAR2(15 ) NOT NULL <br>		, IP_ADDR 				VARCHAR2(23 ) <br>		, OUT_LNKG_IP_ADDR 		VARCHAR2(23 ) <br>		, WEQP_MDL_NM 			VARCHAR2(40 ) <br>		, EQP_UPTIME_CNT 		NUMBER(11, 0) <br>		, EQP_VER_INFO 			VARCHAR2(100 ) <br>		, IPTV_SVC_MODE_VAL 	VARCHAR2(20 ) <br>		, PATCH_GRP_CTT 		VARCHAR2(50 ) <br>		, TRAP_RCV_DTM 			DATE DEFAULT SYSDATE NOT NULL <br>	) <br>
*/
public final String FX_TMP_OIV10802 = "FX_TMP_OIV10802";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * create table FX_TMP_OIV10802_CM (<br>		 MAC_ADDR_VAL 			VARCHAR2(15 ) NOT NULL <br>		, IP_ADDR 				VARCHAR2(23 ) <br>		, OUT_LNKG_IP_ADDR 		VARCHAR2(23 ) <br>		, WEQP_MDL_NM 			VARCHAR2(40 ) <br>		, EQP_UPTIME_CNT 		NUMBER(11, 0) <br>		, EQP_VER_INFO 			VARCHAR2(100 ) <br>		, IPTV_SVC_MODE_VAL 	VARCHAR2(20 ) <br>		, PATCH_GRP_CTT 		VARCHAR2(50 ) <br>		, TRAP_RCV_DTM 			DATE DEFAULT SYSDATE NOT NULL <br>	) <br>
*/
public final String FX_TMP_OIV10802_CM = "FX_TMP_OIV10802_CM";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * create table FX_TMP_OIV10803 (<br>			MAC_ADDR_VAL VARCHAR2(15) NOT NULL<br>		, VER_INFO VARCHAR2(150) NOT NULL<br>		, TPO_CD VARCHAR2(6)<br>		, IPTV_SVC_MGMT_NUM NUMBER(10, 0)<br>		, HOME_CNTR_CD VARCHAR2(10)<br>		, STB_MAC_ADDR_VAL VARCHAR2(15)<br>		, STB_MDL_NM VARCHAR2(40)<br>		, STB_VER_INFO VARCHAR2(100)<br>		, EQP_MDL_CD VARCHAR2(10)<br>		, ETC_CTT VARCHAR2(2000)<br>		, FW_VER_NUM VARCHAR2(150)<br>		, MFACT_NM VARCHAR2(30)<br>		, RGST_DTM VARCHAR2(14)<br>		, TEAM_ORG_ID VARCHAR2(10)<br>	) <br>
*/
public final String FX_TMP_OIV10803 = "FX_TMP_OIV10803";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * create table FX_TMP_OIV10821 (<br>		  RGST_DT VARCHAR2(8)<br>		, WEQP_MAC_ADDR VARCHAR2(15) NOT NULL <br>		, WEQP_IP_ADDR VARCHAR2(23) <br>		, PRV_SHRR_LINK_CL_CD VARCHAR2(1) <br>		, PRV_SHRR_MAC_ADDR VARCHAR2(15) <br>		, PRV_SHRR_MFACT_NM VARCHAR2(100) <br>		, PRV_SHRR_IP_ADDR VARCHAR2(23) <br>	) <br>
*/
public final String FX_TMP_OIV10821 = "FX_TMP_OIV10821";

/**
* para : $getMacAddrVal(), $getIpAddr(), $getPingStVal(), $getPingStChgDtm(), $getLastPingStCheckDtm()<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert  '+APPEND NOLOGGING FX_TMP_OIV10801 '  into FX_TMP_OIV10801 (<br>			MAC_ADDR_VAL<br>			, IP_ADDR<br>			, PING_ST_VAL<br>			, PING_ST_CHG_DTM<br>			, LAST_PING_ST_CHECK_DTM<br>		) values (<br>			$getMacAddrVal()<br>			, $getIpAddr()<br>			, $getPingStVal()<br>			, $getPingStChgDtm()<br>			, $getLastPingStCheckDtm()<br>		) <br>
*/
public final String INSERT_FX_TMP_OIV10801 = "INSERT_FX_TMP_OIV10801";

/**
* para : $getMacAddrVal(), $getIpAddr(), $getOutLnkgIpAddr(), $getWeqpMdlNm(), $getEqpUptimeCnt(), $getEqpVerInfo(), $getIptvSvcModeVal(), $getPatchGrpCtt(), $getTrapRcvDtm()<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert  '+APPEND NOLOGGING FX_TMP_OIV10802 '  into FX_TMP_OIV10802 (<br>			MAC_ADDR_VAL<br>			, IP_ADDR<br>			, OUT_LNKG_IP_ADDR<br>			, WEQP_MDL_NM<br>			, EQP_UPTIME_CNT<br>			, EQP_VER_INFO<br>			, IPTV_SVC_MODE_VAL<br>			, PATCH_GRP_CTT<br>			, TRAP_RCV_DTM<br>		) values (<br>			$getMacAddrVal()<br>			, $getIpAddr()<br>			, $getOutLnkgIpAddr()<br>			, $getWeqpMdlNm()<br>			, $getEqpUptimeCnt()<br>			, $getEqpVerInfo()<br>			, $getIptvSvcModeVal()<br>			, $getPatchGrpCtt()<br>			, $getTrapRcvDtm()<br>		) <br>
*/
public final String INSERT_FX_TMP_OIV10802 = "INSERT_FX_TMP_OIV10802";

/**
* para : $getMacAddrVal(), $getIpAddr(), $getOutLnkgIpAddr(), $getWeqpMdlNm(), $getEqpUptimeCnt(), $getEqpVerInfo(), $getIptvSvcModeVal(), $getPatchGrpCtt(), $getTrapRcvDtm()<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert  '+APPEND NOLOGGING FX_TMP_OIV10802_CM '  into FX_TMP_OIV10802_CM (<br>			MAC_ADDR_VAL<br>			, IP_ADDR<br>			, OUT_LNKG_IP_ADDR<br>			, WEQP_MDL_NM<br>			, EQP_UPTIME_CNT<br>			, EQP_VER_INFO<br>			, IPTV_SVC_MODE_VAL<br>			, PATCH_GRP_CTT<br>			, TRAP_RCV_DTM<br>		) values (<br>			$getMacAddrVal()<br>			, $getIpAddr()<br>			, $getOutLnkgIpAddr()<br>			, $getWeqpMdlNm()<br>			, $getEqpUptimeCnt()<br>			, $getEqpVerInfo()<br>			, $getIptvSvcModeVal()<br>			, $getPatchGrpCtt()<br>			, $getTrapRcvDtm()<br>		) <br>
*/
public final String INSERT_FX_TMP_OIV10802_CM = "INSERT_FX_TMP_OIV10802_CM";

/**
* para : $getMacAddrVal(), $getVerInfo(), $getTpoCd(), $getIptvSvcMgmtNum(), $getHomeCntrCd(), $getStbMacAddrVal(), $getStbMdlNm(), $getStbVerInfo(), $getEqpMdlCd(), $getEtcCtt(), $getFwVerNum(), $getMfactNm(), $getRgstDtm(), $getTeamOrgId()<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert  '+APPEND NOLOGGING FX_TMP_OIV10803 '  into FX_TMP_OIV10803 (<br>			MAC_ADDR_VAL<br>			, VER_INFO<br>			, TPO_CD<br>			, IPTV_SVC_MGMT_NUM<br>			, HOME_CNTR_CD<br>			, STB_MAC_ADDR_VAL<br>			, STB_MDL_NM<br>			, STB_VER_INFO<br>			, EQP_MDL_CD<br>			, ETC_CTT<br>			, FW_VER_NUM<br>			, MFACT_NM<br>			, RGST_DTM<br>			, TEAM_ORG_ID<br>		) values (<br>			$getMacAddrVal()<br>			, $getVerInfo()<br>			, $getTpoCd()<br>			, $getIptvSvcMgmtNum()<br>			, $getHomeCntrCd()<br>			, $getStbMacAddrVal()<br>			, $getStbMdlNm()<br>			, $getStbVerInfo()<br>			, $getEqpMdlCd()<br>			, $getEtcCtt()<br>			, $getFwVerNum()<br>			, $getMfactNm()<br>			, $getRgstDtm()<br>			, $getTeamOrgId()<br>		) <br>
*/
public final String INSERT_FX_TMP_OIV10803 = "INSERT_FX_TMP_OIV10803";

/**
* para : $getRgstDt(), $getWeqpMacAddr(), $getWeqpIpAddr(), $getPrvShrrLinkClCd(), $getPrvShrrMacAddr(), $getPrvShrrMfactNm(), $getPrvShrrIpAddr()<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert  '+APPEND NOLOGGING FX_TMP_OIV10821 '  into FX_TMP_OIV10821 (<br>			RGST_DT<br>			, WEQP_MAC_ADDR<br>			, WEQP_IP_ADDR<br>			, PRV_SHRR_LINK_CL_CD<br>			, PRV_SHRR_MAC_ADDR<br>			, PRV_SHRR_MFACT_NM<br>			, PRV_SHRR_IP_ADDR<br>		) values (<br>			$getRgstDt()<br>			, $getWeqpMacAddr()<br>			, $getWeqpIpAddr()<br>			, $getPrvShrrLinkClCd()<br>			, $getPrvShrrMacAddr()<br>			, $getPrvShrrMfactNm()<br>			, $getPrvShrrIpAddr()<br>		) <br>
*/
public final String INSERT_FX_TMP_OIV10821 = "INSERT_FX_TMP_OIV10821";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * merge into OIV10801 A<br>			using FX_TMP_OIV10801 B<br>			on ( B.MAC_ADDR_VAL = A.MAC_ADDR_VAL )<br>			when matched then<br>				update set <br>					A.IP_ADDR					= B.IP_ADDR<br>					, A.PING_ST_VAL				= B.PING_ST_VAL<br>					, A.PING_ST_CHG_DTM			= B.PING_ST_CHG_DTM<br>					, A.LAST_PING_ST_CHECK_DTM	= B.LAST_PING_ST_CHECK_DTM<br>					, A.AUDIT_ID				= 'MICM'<br>					, A.AUDIT_DTM				= sysdate<br>			when not matched then<br>				insert ( <br>					A.MAC_ADDR_VAL<br>					, A.AUDIT_ID<br>					, A.IP_ADDR<br>					, A.PING_ST_VAL<br>					, A.PING_ST_CHG_DTM<br>					, A.LAST_PING_ST_CHECK_DTM<br>				) values (<br>					B.MAC_ADDR_VAL<br>					, 'MICM'<br>					, B.IP_ADDR<br>					, B.PING_ST_VAL<br>					, B.PING_ST_CHG_DTM<br>					, B.LAST_PING_ST_CHECK_DTM<br>				) <br>
*/
public final String MERGE_OIV10801 = "MERGE_OIV10801";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * merge into OIV10802 A<br>			using FX_TMP_OIV10802 B<br>			on ( B.MAC_ADDR_VAL = A.MAC_ADDR_VAL )<br>			when not matched then<br>				insert ( <br>					A.MAC_ADDR_VAL<br>					, A.IP_ADDR<br>					, A.OUT_LNKG_IP_ADDR<br>					, A.WEQP_MDL_NM<br>					, A.EQP_UPTIME_CNT<br>					, A.EQP_VER_INFO<br>					, A.IPTV_SVC_MODE_VAL<br>					, A.PATCH_GRP_CTT<br>					, A.TRAP_RCV_DTM<br>					, A.AUDIT_ID<br>				) values (<br>					B.MAC_ADDR_VAL<br>					, B.IP_ADDR<br>					, B.OUT_LNKG_IP_ADDR<br>					, B.WEQP_MDL_NM<br>					, B.EQP_UPTIME_CNT<br>					, B.EQP_VER_INFO<br>					, B.IPTV_SVC_MODE_VAL<br>					, B.PATCH_GRP_CTT<br>					, B.TRAP_RCV_DTM<br>					, 'MICM'					<br>				) <br>
*/
public final String MERGE_OIV10802_INSERT__BY_SDS_STB_INFO = "MERGE_OIV10802_INSERT__BY_SDS_STB_INFO";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * merge into OIV10802 A<br>			using FX_TMP_OIV10802 B<br>			on ( B.MAC_ADDR_VAL = A.MAC_ADDR_VAL )<br>			when matched then<br>				update set <br>					A.PATCH_GRP_CTT 			= B.PATCH_GRP_CTT<br>					, A.AUDIT_ID				= 'MICM'<br>					, A.AUDIT_DTM				= sysdate <br>
*/
public final String MERGE_OIV10802_UPDATE__BY_SDS_STB_INFO = "MERGE_OIV10802_UPDATE__BY_SDS_STB_INFO";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * merge into OIV10802 A<br>			using FX_TMP_OIV10802 B<br>			on ( B.MAC_ADDR_VAL = A.MAC_ADDR_VAL )<br>			when matched then<br>				update set <br>					A.IP_ADDR 					= B.IP_ADDR<br>					, A.OUT_LNKG_IP_ADDR 		= B.OUT_LNKG_IP_ADDR<br>					, A.WEQP_MDL_NM 			= B.WEQP_MDL_NM<br>					, A.EQP_UPTIME_CNT			= B.EQP_UPTIME_CNT<br>					, A.EQP_VER_INFO 			= B.EQP_VER_INFO<br>					, A.TRAP_RCV_DTM 			= B.TRAP_RCV_DTM<br>					, A.AUDIT_ID				= 'MICM'<br>					, A.AUDIT_DTM				= sysdate<br>			when not matched then<br>				insert ( <br>					A.MAC_ADDR_VAL<br>					, A.IP_ADDR<br>					, A.OUT_LNKG_IP_ADDR<br>					, A.WEQP_MDL_NM<br>					, A.EQP_UPTIME_CNT<br>					, A.EQP_VER_INFO<br>					, A.IPTV_SVC_MODE_VAL<br>					, A.PATCH_GRP_CTT<br>					, A.TRAP_RCV_DTM<br>					, A.AUDIT_ID<br>				) values (<br>					B.MAC_ADDR_VAL<br>					, B.IP_ADDR<br>					, B.OUT_LNKG_IP_ADDR<br>					, B.WEQP_MDL_NM<br>					, B.EQP_UPTIME_CNT<br>					, B.EQP_VER_INFO<br>					, B.IPTV_SVC_MODE_VAL<br>					, B.PATCH_GRP_CTT<br>					, B.TRAP_RCV_DTM<br>					, 'MICM'					<br>				) <br>
*/
public final String MERGE_OIV10802__BY_AP = "MERGE_OIV10802__BY_AP";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * merge into OIV10802 A<br>			using FX_TMP_OIV10802_CM B<br>			on ( B.MAC_ADDR_VAL = A.MAC_ADDR_VAL )<br>			when matched then<br>				update set <br>					A.IP_ADDR 					= B.IP_ADDR<br>					, A.WEQP_MDL_NM 			= B.WEQP_MDL_NM<br>					, A.EQP_UPTIME_CNT			= B.EQP_UPTIME_CNT<br>					, A.EQP_VER_INFO 			= B.EQP_VER_INFO<br>					, A.TRAP_RCV_DTM 			= B.TRAP_RCV_DTM<br>					, A.AUDIT_ID				= 'MICM'<br>					, A.AUDIT_DTM				= sysdate<br>			when not matched then<br>				insert ( <br>					A.MAC_ADDR_VAL<br>					, A.IP_ADDR<br>					, A.OUT_LNKG_IP_ADDR<br>					, A.WEQP_MDL_NM<br>					, A.EQP_UPTIME_CNT<br>					, A.EQP_VER_INFO<br>					, A.IPTV_SVC_MODE_VAL<br>					, A.PATCH_GRP_CTT<br>					, A.TRAP_RCV_DTM<br>					, A.AUDIT_ID<br>				) values (<br>					B.MAC_ADDR_VAL<br>					, B.IP_ADDR<br>					, B.OUT_LNKG_IP_ADDR<br>					, B.WEQP_MDL_NM<br>					, B.EQP_UPTIME_CNT<br>					, B.EQP_VER_INFO<br>					, B.IPTV_SVC_MODE_VAL<br>					, B.PATCH_GRP_CTT<br>					, B.TRAP_RCV_DTM<br>					, 'MICM'					<br>				) <br>
*/
public final String MERGE_OIV10802__BY_CM = "MERGE_OIV10802__BY_CM";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * merge into OIV10802 A<br>			using FX_TMP_OIV10802 B<br>			on ( B.MAC_ADDR_VAL = A.MAC_ADDR_VAL )<br>			when matched then<br>				update set <br>					A.IP_ADDR 					= B.IP_ADDR<br>					, A.OUT_LNKG_IP_ADDR 		= B.OUT_LNKG_IP_ADDR<br>					, A.WEQP_MDL_NM 			= B.WEQP_MDL_NM<br>					, A.EQP_UPTIME_CNT			= B.EQP_UPTIME_CNT<br>					, A.EQP_VER_INFO 			= B.EQP_VER_INFO<br>					, A.IPTV_SVC_MODE_VAL 		= B.IPTV_SVC_MODE_VAL<br>					, A.TRAP_RCV_DTM 			= B.TRAP_RCV_DTM<br>					, A.AUDIT_ID				= 'MICM'<br>					, A.AUDIT_DTM				= sysdate<br>			when not matched then<br>				insert ( <br>					A.MAC_ADDR_VAL<br>					, A.IP_ADDR<br>					, A.OUT_LNKG_IP_ADDR<br>					, A.WEQP_MDL_NM<br>					, A.EQP_UPTIME_CNT<br>					, A.EQP_VER_INFO<br>					, A.IPTV_SVC_MODE_VAL<br>					, A.PATCH_GRP_CTT<br>					, A.TRAP_RCV_DTM<br>					, A.AUDIT_ID<br>				) values (<br>					B.MAC_ADDR_VAL<br>					, B.IP_ADDR<br>					, B.OUT_LNKG_IP_ADDR<br>					, B.WEQP_MDL_NM<br>					, B.EQP_UPTIME_CNT<br>					, B.EQP_VER_INFO<br>					, B.IPTV_SVC_MODE_VAL<br>					, B.PATCH_GRP_CTT<br>					, B.TRAP_RCV_DTM<br>					, 'MICM'					<br>				) <br>
*/
public final String MERGE_OIV10802__BY_STB = "MERGE_OIV10802__BY_STB";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * merge into OIV10803 A<br>			using FX_TMP_OIV10803 B<br>			on ( B.MAC_ADDR_VAL = A.MAC_ADDR_VAL )<br>			when matched then<br>				update set <br>					A.VER_INFO					= B.VER_INFO<br>					, A.TPO_CD					= B.TPO_CD<br>					, A.IPTV_SVC_MGMT_NUM		= B.IPTV_SVC_MGMT_NUM<br>					, A.HOME_CNTR_CD			= B.HOME_CNTR_CD<br>					, A.STB_MAC_ADDR_VAL		= B.STB_MAC_ADDR_VAL<br>					, A.STB_MDL_NM				= B.STB_MDL_NM<br>					, A.STB_VER_INFO			= B.STB_VER_INFO<br>					, A.EQP_MDL_CD				= B.EQP_MDL_CD<br>					, A.ETC_CTT					= B.ETC_CTT<br>					, A.FW_VER_NUM				= B.FW_VER_NUM<br>					, A.MFACT_NM				= B.MFACT_NM<br>					, A.RGST_DTM				= B.RGST_DTM<br>					, A.TEAM_ORG_ID				= B.TEAM_ORG_ID<br>					, A.AUDIT_ID				= 'MICM'<br>					, A.AUDIT_DTM				= sysdate<br>			when not matched then<br>				insert ( <br>					A.MAC_ADDR_VAL<br>					, A.VER_INFO<br>					, A.TPO_CD<br>					, A.IPTV_SVC_MGMT_NUM<br>					, A.HOME_CNTR_CD<br>					, A.STB_MAC_ADDR_VAL<br>					, A.STB_MDL_NM<br>					, A.STB_VER_INFO<br>					, A.EQP_MDL_CD<br>					, A.ETC_CTT<br>					, A.FW_VER_NUM<br>					, A.MFACT_NM<br>					, A.RGST_DTM<br>					, A.TEAM_ORG_ID<br>					, A.AUDIT_ID<br>				) values (<br>					B.MAC_ADDR_VAL<br>					, B.VER_INFO<br>					, B.TPO_CD<br>					, B.IPTV_SVC_MGMT_NUM<br>					, B.HOME_CNTR_CD<br>					, B.STB_MAC_ADDR_VAL<br>					, B.STB_MDL_NM<br>					, B.STB_VER_INFO<br>					, B.EQP_MDL_CD<br>					, B.ETC_CTT<br>					, B.FW_VER_NUM<br>					, B.MFACT_NM<br>					, B.RGST_DTM<br>					, B.TEAM_ORG_ID<br>					, 'MICM'					<br>				) <br>
*/
public final String MERGE_OIV10803 = "MERGE_OIV10803";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * merge into OIV10821 A<br>			using FX_TMP_OIV10821 B<br>			on ( B.WEQP_MAC_ADDR = A.WEQP_MAC_ADDR )<br>			when matched then<br>				update set <br>					A.RGST_DT					= B.RGST_DT<br>					, A.WEQP_IP_ADDR			= B.WEQP_IP_ADDR<br>					, A.PRV_SHRR_LINK_CL_CD		= B.PRV_SHRR_LINK_CL_CD<br>					, A.PRV_SHRR_MAC_ADDR		= B.PRV_SHRR_MAC_ADDR<br>					, A.PRV_SHRR_MFACT_NM		= B.PRV_SHRR_MFACT_NM<br>					, A.PRV_SHRR_IP_ADDR		= B.PRV_SHRR_IP_ADDR<br>					, A.AUDIT_ID				= 'MICM'<br>					, A.AUDIT_DTM				= sysdate<br>			when not matched then<br>				insert ( <br>					A.RGST_DT<br>					, A.WEQP_MAC_ADDR<br>					, A.WEQP_IP_ADDR<br>					, A.PRV_SHRR_LINK_CL_CD<br>					, A.PRV_SHRR_MAC_ADDR<br>					, A.PRV_SHRR_MFACT_NM<br>					, A.PRV_SHRR_IP_ADDR<br>					, A.AUDIT_ID<br>				) values (<br>					B.RGST_DT<br>					, B.WEQP_MAC_ADDR<br>					, B.WEQP_IP_ADDR<br>					, B.PRV_SHRR_LINK_CL_CD<br>					, B.PRV_SHRR_MAC_ADDR<br>					, B.PRV_SHRR_MFACT_NM<br>					, B.PRV_SHRR_IP_ADDR<br>					, 'MICM'					<br>				) <br>
*/
public final String MERGE_OIV10821 = "MERGE_OIV10821";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * truncate table FX_TMP_OIV10801 reuse storage <br>
*/
public final String TRUNCATE_FX_TMP_OIV10801 = "TRUNCATE_FX_TMP_OIV10801";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * truncate table FX_TMP_OIV10802 reuse storage <br>
*/
public final String TRUNCATE_FX_TMP_OIV10802 = "TRUNCATE_FX_TMP_OIV10802";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * truncate table FX_TMP_OIV10802_CM reuse storage <br>
*/
public final String TRUNCATE_FX_TMP_OIV10802_CM = "TRUNCATE_FX_TMP_OIV10802_CM";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * truncate table FX_TMP_OIV10803 reuse storage <br>
*/
public final String TRUNCATE_FX_TMP_OIV10803 = "TRUNCATE_FX_TMP_OIV10803";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * truncate table FX_TMP_OIV10821 reuse storage <br>
*/
public final String TRUNCATE_FX_TMP_OIV10821 = "TRUNCATE_FX_TMP_OIV10821";

}