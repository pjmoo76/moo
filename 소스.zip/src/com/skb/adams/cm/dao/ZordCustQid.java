package com.skb.adams.cm.dao;

public class ZordCustQid {
	public static final String QUERY_XML_FILE = "zord_cust.xml";
	
	public ZordCustQid() {
		
	}
	
	public final String DROP_TABLE_FX_TMP_ZORD_CUST = "DROP_TABLE_FX_TMP_ZORD_CUST";
	public final String CREATE_TABLE_FX_TMP_ZORD_CUST = "CREATE_TABLE_FX_TMP_ZORD_CUST";
	public final String INSERT_FX_TMP_ZORD_CUST = "INSERT_FX_TMP_ZORD_CUST";
	public final String SELECT_ZORD_CUST = "SELECT_ZORD_CUST";
	public final String MERGE_OES10100__BY_FX_TMP_ZORD_CUST = "MERGE_OES10100__BY_FX_TMP_ZORD_CUST";
	public final String DELETE_OES10100__BY_FX_TMP_ZORD_CUST = "DELETE_OES10100__BY_FX_TMP_ZORD_CUST";

}
