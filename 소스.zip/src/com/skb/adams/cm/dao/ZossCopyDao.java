package com.skb.adams.cm.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.skb.adams.cm.CmMsg;

import subkjh.bas.dao.control.DaoListener;
import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.log.Logger;

public class ZossCopyDao {

	private DbTrans srcTran;
	private DbTrans dstTran;
	private List<Object> oList;
	private int count = 0;
	private String deleteQid;
	private String writeQid;

	public void copy(String name, String readQid, String writeQid, String deleteQid) throws Exception {

		this.writeQid = writeQid;
		this.deleteQid = deleteQid;

		srcTran = DBManager.getMgr().getDataBase(CmDao.NEIFDB).createDbTrans("deploy/conf/sql/" + NeifdbQid.QUERY_XML_FILE);
		dstTran = DBManager.getMgr().getDataBase(CmDao.ADAMS).createDbTrans("deploy/conf/sql/" + NeifdbQid.QUERY_XML_FILE);

		try {
			srcTran.start();
		} catch (Exception e) {
			throw e;
		}

		try {
			dstTran.start();
		} catch (Exception e) {
			srcTran.stop();
			throw e;
		}

		ZossEqiupMdl daoListener = new ZossEqiupMdl();
		srcTran.setDaoListener(daoListener);

		try {
			srcTran.selectQid2Res(readQid, null);
			dstTran.commit();
			Logger.logger.info(CmMsg.makeCmInfo(name, -1, count, -1));
		} catch (Exception e) {
			dstTran.rollback();
			Logger.logger.error(e);
			Logger.logger.fail(CmMsg.makeCmInfo(name + "(ERROR)", -1, count, -1));
			throw e;
		} finally {
			try {
				srcTran.stop();
			} catch (Exception e) {
				Logger.logger.error(e);
			}
			try {
				dstTran.stop();
			} catch (Exception e) {
				Logger.logger.error(e);
			}
		}

	}

	class ZossEqiupMdl implements DaoListener {

		@Override
		public void onFinish(Exception ex) throws Exception {
			if (oList.size() > 0) {
				dstTran.execute(writeQid, oList);
				count += oList.size();
				oList.clear();
			}
		}

		public void onExecuted(Object data, Exception ex) throws Exception {

		}

		@Override
		public void onSelected(int rowNo, Object data) throws Exception {
			oList.add(data);

			if (oList.size() >= 50000) {
				dstTran.execute(writeQid, oList);
				count += oList.size();
				oList.clear();
			}
		}

		@Override
		public void onStart(String[] colNames) throws Exception {
			Logger.logger.debug(Arrays.toString(colNames));
			oList = new ArrayList<Object>();
			dstTran.execute(deleteQid, null);
		}
	}
}
