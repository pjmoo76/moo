package com.skb.adams.cm.dao;

/**
* File : oiv10970.xml<br>
* @since 20171229165619
* @author subkjh 
*
*/


public class OIV10970Qid { 

/** 쿼리 모임 화일명. oiv10970.xml*/
public static final String QUERY_XML_FILE = "oiv10970.xml";

public OIV10970Qid() { 
} 
/**
* para : $getCreTblId(), $getCreDtm()<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * delete<br>		from 	OIV10970<br>		where	CRE_TBL_ID = $getCreTblId()<br>		and		CRE_DTM = $getCreDtm() <br>
*/
public final String DELETE_OIV10970 = "DELETE_OIV10970";

/**
* para : $getCreTblId(), $getCreDtm(), $getCreStaDtm(), $getCreEndDtm(), $getCreCnt()<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into OIV10970 (<br>			CRE_TBL_ID<br>			, CRE_DTM<br>			, AUDIT_ID<br>			, CRE_STA_DTM<br>			, CRE_END_DTM<br>			, CRE_CNT<br>		) values (<br>			$getCreTblId()<br>			, $getCreDtm()<br>			, 'MICM'<br>			, $getCreStaDtm()<br>			, $getCreEndDtm()<br>			, $getCreCnt()<br>		) <br>
*/
public final String INSERT_OIV10970 = "INSERT_OIV10970";

}