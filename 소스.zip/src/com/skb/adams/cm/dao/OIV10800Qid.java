package com.skb.adams.cm.dao;

/**
* File : oiv10800.xml<br>
* @since 20171226114329
* @author subkjh 
*
*/


public class OIV10800Qid { 

/** 쿼리 모임 화일명. oiv10800.xml*/
public static final String QUERY_XML_FILE = "oiv10800.xml";

public OIV10800Qid() { 
} 
/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * delete	<br>		from	OIV10800 WEQP<br>		where	exists (<br>					select	SWEQP.WEQP_MGMT_NUM<br>					from	OIV10809 SWEQP<br>					where	WEQP.WEQP_MGMT_NUM  = SWEQP.WEQP_MGMT_NUM <br>					and		WEQP.MAC_ADDR_VAL  != SWEQP.MAC_ADDR_VAL<br>					and 	length(SWEQP.MAC_ADDR_VAL) = 12		 <br>				) <br>
*/
public final String DELETE_OIV10800__MAC_CHANGED = "DELETE_OIV10800__MAC_CHANGED";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * delete	<br>		from	OIV10800 WEQP<br>		where	exists  (<br>					select	SWEQP.WEQP_MGMT_NUM<br>					from	OIV10809 SWEQP<br>					where	WEQP.WEQP_MGMT_NUM  = SWEQP.WEQP_MGMT_NUM <br>					and		SWEQP.WEQP_ST_CD != '40'<br>				) <br>
*/
public final String DELETE_OIV10800__ST_CD_NOT_40 = "DELETE_OIV10800__ST_CD_NOT_40";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * delete	<br>		from	OIV10800 WEQP<br>		where	WEQP_MGMT_NUM in (<br>					select	SWEQP.WEQP_MGMT_NUM<br>					from	OIV10809 SWEQP<br>					where	WEQP.WEQP_MGMT_NUM  = SWEQP.WEQP_MGMT_NUM <br>					and		SWEQP.WEQP_ST_CD != '40'<br>				) <br>
*/
public final String DELETE_OIV10800__ST_CD_NOT_40_OLD = "DELETE_OIV10800__ST_CD_NOT_40_OLD";

/**
* para : $getWeqpMgmtNum(), $getWeqpGrpCd(), $getEqpMdlCd(), $getMacAddrVal(), $getMfactSerNum(), $getWeqpClCd(), $getRepSvcMgmtNum(), $getWeqpLocClCd(), $getWeqpLocId(), $getDsnetOrgId()<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert  '+APPEND ' into OIV10800 (<br>			WEQP_MGMT_NUM<br>			, AUDIT_ID<br>			, WEQP_GRP_CD<br>			, EQP_MDL_CD<br>			, MAC_ADDR_VAL<br>			, MFACT_SER_NUM<br>			, WEQP_CL_CD<br>			, REP_SVC_MGMT_NUM<br>			, WEQP_LOC_CL_CD<br>			, WEQP_LOC_ID<br>			, DSNET_ORG_ID<br>			, VIP_EQP_YN<br>		) values (<br>			$getWeqpMgmtNum()<br>			, 'SWG-BATCH'<br>			, $getWeqpGrpCd()<br>			, $getEqpMdlCd()<br>			, $getMacAddrVal()<br>			, $getMfactSerNum()<br>			, $getWeqpClCd()<br>			, $getRepSvcMgmtNum()<br>			, $getWeqpLocClCd()<br>			, $getWeqpLocId()<br>			, $getDsnetOrgId()<br>			, 'N'<br>		) <br>
*/
public final String INSERT_OIV10800 = "INSERT_OIV10800";

/**
* para : <br>
* result : RESULT_OIV10800=com.skb.adams.cm.model.OIV10800<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * select *<br>		from (<br>				select<br>				          SWEQP.WEQP_MGMT_NUM        		as WEQP_MGMT_NUM<br>				        , SWEQP.WEQP_GRP_CD             	as WEQP_GRP_CD<br>				        , SWEQP.WEQP_MDL_CD             	as EQP_MDL_CD<br>				        , upper(SWEQP.MAC_ADDR_VAL)        	as MAC_ADDR_VAL<br>				        , SWEQP.MFACT_SER_NUM           	as MFACT_SER_NUM<br>				        , nvl(SWEQP.WEQP_CL_CD, '0')        as WEQP_CL_CD ' 단말분코드가 NULL인 값이 있어 임의로 '0로 설정하였음 '<br>				        , SWEQP.REP_SVC_MGMT_NUM        	as REP_SVC_MGMT_NUM<br>				        , nvl(SWEQP.WEQP_LOC_CL_CD, 'XX')   as WEQP_LOC_CL_CD	' 단말설치구분코드가 NULL인 값이 있어 임의로 XX로 설정하였음 '<br>				        , SWEQP.WEQP_LOC_ID             	as WEQP_LOC_ID<br>				        , SWEQP.DSNET_ORG_ID            	as DSNET_ORG_ID<br>				        <br>				        , SWEQP.ST_FLU_DT<br>				        <br>				from 	OIV10809 SWEQP<br>							left join OIV10800 WEQP on WEQP.MAC_ADDR_VAL  = upper(SWEQP.MAC_ADDR_VAL)<br>				where	WEQP.WEQP_MGMT_NUM is null<br>				and 	SWEQP.WEQP_ST_CD = '40' <br>				and 	length(SWEQP.MAC_ADDR_VAL) = 12		<br>				<br>				union <br>				<br>				select<br>				          SWEQP.WEQP_MGMT_NUM        		as WEQP_MGMT_NUM<br>				        , SWEQP.WEQP_GRP_CD             	as WEQP_GRP_CD<br>				        , SWEQP.WEQP_MDL_CD            	 	as EQP_MDL_CD<br>				        , upper(SWEQP.MFACT_SER_NUM)      	as MAC_ADDR_VAL  ' ONT인 경우 시리얼번호를 MAC으로 넣음 '<br>				        , SWEQP.MFACT_SER_NUM           	as MFACT_SER_NUM<br>				        , nvl(SWEQP.WEQP_CL_CD, '0')        as WEQP_CL_CD ' 단말분코드가 NULL인 값이 있어 임의로 '0로 설정하였음 '<br>				        , SWEQP.REP_SVC_MGMT_NUM       		as REP_SVC_MGMT_NUM<br>				        , nvl(SWEQP.WEQP_LOC_CL_CD, 'XX')   as WEQP_LOC_CL_CD	' 단말설치구분코드가 NULL인 값이 있어 임의로 XX로 설정하였음 '<br>				        , SWEQP.WEQP_LOC_ID             	as WEQP_LOC_ID<br>				        , SWEQP.DSNET_ORG_ID            	as DSNET_ORG_ID<br>				        <br>				        , SWEQP.ST_FLU_DT<br>				        <br>				        <br>				from 	OIV10809 SWEQP<br>							left join OIV10800 WEQP on WEQP.MAC_ADDR_VAL  = upper(SWEQP.MFACT_SER_NUM)<br>						, OIV10700 WMDL<br>				where	WEQP.WEQP_MGMT_NUM is null<br>				and		SWEQP.WEQP_MDL_CD = WMDL.WEQP_MDL_CD<br>				and 	WMDL.WEQP_MDL_TYP_CD in ( '40', '50' ) -- ONT, VDSL<br>				and 	SWEQP.WEQP_ST_CD = '40'<br>				and 	( SWEQP.MAC_ADDR_VAL is null or SWEQP.MAC_ADDR_VAL = ' ' )<br>				and 	length(SWEQP.MFACT_SER_NUM) BETWEEN 12 AND 15<br>		) T<br>		order by T.MAC_ADDR_VAL<br>				, T.ST_FLU_DT desc <br>
*/
public final String SELECT_OIV10800 = "SELECT_OIV10800";

/**
* para : <br>
* result : RESULT_OIV10800=com.skb.adams.cm.model.OIV10800<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * select<br>		          SWEQP.WEQP_MGMT_NUM        		as WEQP_MGMT_NUM<br>		        , SWEQP.WEQP_GRP_CD             	as WEQP_GRP_CD<br>		        , SWEQP.WEQP_MDL_CD             	as EQP_MDL_CD<br>		        , upper(SWEQP.MAC_ADDR_VAL)        	as MAC_ADDR_VAL<br>		        , SWEQP.MFACT_SER_NUM           	as MFACT_SER_NUM<br>		        , nvl(SWEQP.WEQP_CL_CD, '0')        as WEQP_CL_CD ' 단말분코드가 NULL인 값이 있어 임의로 '0로 설정하였음 '<br>		        , SWEQP.REP_SVC_MGMT_NUM        	as REP_SVC_MGMT_NUM<br>		        , nvl(SWEQP.WEQP_LOC_CL_CD, 'XX')   as WEQP_LOC_CL_CD	' 단말설치구분코드가 NULL인 값이 있어 임의로 XX로 설정하였음 '<br>		        , SWEQP.WEQP_LOC_ID             	as WEQP_LOC_ID<br>		        , SWEQP.DSNET_ORG_ID            	as DSNET_ORG_ID<br>		        <br>		        , SWEQP.ST_FLU_DT<br>		        <br>		from 	OIV10402 WLK  <br>					left join OIV10800 WEQP on WEQP.WEQP_MGMT_NUM = WLK.WEQP_MGMT_NUM<br>				, OIV10809 SWEQP<br>		where	WEQP.WEQP_MGMT_NUM is null<br>		and		WLK.WEQP_MGMT_NUM = SWEQP.WEQP_MGMT_NUM <br>
*/
public final String SELECT_OIV10800__BY_402 = "SELECT_OIV10800__BY_402";

/**
* para : <br>
* result : RESULT_OIV10800=com.skb.adams.cm.model.OIV10800<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * select<br>		          SWEQP.WEQP_MGMT_NUM        		as WEQP_MGMT_NUM<br>		        , SWEQP.WEQP_GRP_CD             	as WEQP_GRP_CD<br>		        , SWEQP.WEQP_MDL_CD             	as EQP_MDL_CD<br>		        , upper(SWEQP.MAC_ADDR_VAL)        	as MAC_ADDR_VAL<br>		        , SWEQP.MFACT_SER_NUM           	as MFACT_SER_NUM<br>		        , nvl(SWEQP.WEQP_CL_CD, '0')        as WEQP_CL_CD ' 단말분코드가 NULL인 값이 있어 임의로 '0로 설정하였음 '<br>		        , SWEQP.REP_SVC_MGMT_NUM        	as REP_SVC_MGMT_NUM<br>		        , nvl(SWEQP.WEQP_LOC_CL_CD, 'XX')   as WEQP_LOC_CL_CD	' 단말설치구분코드가 NULL인 값이 있어 임의로 XX로 설정하였음 '<br>		        , SWEQP.WEQP_LOC_ID             	as WEQP_LOC_ID<br>		        , SWEQP.DSNET_ORG_ID            	as DSNET_ORG_ID<br>		        <br>		        , SWEQP.ST_FLU_DT<br>		        <br>		from 	OIV10164 AMI  <br>				, OIV10809 SWEQP<br>					left join OIV10800 WEQP on WEQP.MAC_ADDR_VAL = upper(SWEQP.MAC_ADDR_VAL)<br>		where	AMI.MAC_ADDR  = upper(SWEQP.MAC_ADDR_VAL)<br>		and 	length(AMI.MAC_ADDR) = 12	<br>		and		WEQP.MAC_ADDR_VAL is null <br>
*/
public final String SELECT_OIV10800__BY_AMI = "SELECT_OIV10800__BY_AMI";

/**
* para : <br>
* result : RESULT_OIV10800=com.skb.adams.cm.model.OIV10800<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
*/
public final String UPDATE_OIV10800__MAC_NULL = "UPDATE_OIV10800__MAC_NULL";

/**
* para : <br>
* result : RESULT_OIV10800=com.skb.adams.cm.model.OIV10800<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
*/
public final String UPDATE_OIV10800__MAC_NULL_BY_MFACT = "UPDATE_OIV10800__MAC_NULL_BY_MFACT";

/**
* para : <br>
* result : RESULT_OIV10800=com.skb.adams.cm.model.OIV10800<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
*/
public final String UPDATE_OIV10800__MAC_NULL_BY_DUP = "UPDATE_OIV10800__MAC_NULL_BY_DUP";

/**
* para : <br>
* result : RESULT_OIV10800=com.skb.adams.cm.model.OIV10800<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
*/
public final String MERGE_OIV10800__BY_OIV10809 = "MERGE_OIV10800__BY_OIV10809";

/**
* para : <br>
* result : RESULT_OIV10800=com.skb.adams.cm.model.OIV10800<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
*/
public final String MERGE_OIV10800__BY_OIV10809_BY_DUP = "MERGE_OIV10800__BY_OIV10809_BY_DUP";
}