package com.skb.adams.cm.dao;

/**
 * File : oiv10808.xml<br>
 * 
 * @since 20180328094316
 * @author subkjh
 *
 */

public class OIV10808Qid {

	/** 쿼리 모임 화일명. oiv10808.xml */
	public static final String QUERY_XML_FILE = "oiv10808.xml";

	public OIV10808Qid() {
	}

	/**
	 * para : <br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * delete <br>
	 * from OIV10808<br>
	 * where RGST_DT = to_char(sysdate, 'YYYYMMDD') <br>
	 */
	public final String DELETE_OIV10808 = "DELETE_OIV10808";

	/**
	 * para : <br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * delete <br>
	 * from OIV10813<br>
	 * where RGST_DT = to_char(sysdate, 'YYYYMMDD') <br>
	 */
	public final String DELETE_OIV10813 = "DELETE_OIV10813";

	/**
	 * para : <br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * delete <br>
	 * from OIV10814<br>
	 * where RGST_DT = to_char(sysdate, 'YYYYMMDD') <br>
	 */
	public final String DELETE_OIV10814 = "DELETE_OIV10814";

	/**
	 * para : <br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * INSERT<br>
	 * INTO OIV10808<br>
	 * ( RGST_DT ' 등록일자 ' <br>
	 * , TPO_CD ' 국사코드 ' <br>
	 * , EQP_MDL_CD ' 단말모델코드 ' <br>
	 * , L3_EQUIP_ID ' L3장비ID ' <br>
	 * , EQP_VER_INFO ' 단말버전정보 ' <br>
	 * , STRD_VER_YN ' 표준버전여부 ' <br>
	 * , WEQP_QTY ' 유선단말수량 ' <br>
	 * , AUDIT_ID ' 최종변경자ID ' )<br>
	 * select <br>
	 * to_char(sysdate, 'YYYYMMDD') as RGST_DT ' 등록일자 ' <br>
	 * , T.TPO_CD as TPO_CD ' 국사코드 ' <br>
	 * , T.EQP_MDL_CD as EQP_MDL_CD ' 단말모델코드 ' <br>
	 * , T.L3_EQUIP_ID as L3_EQUIP_ID ' L3장비ID ' <br>
	 * , T.EQP_VER_INFO as EQP_VER_INFO ' 단말버전정보 ' <br>
	 * , T.STRD_VER_YN as STRD_VER_YN ' 표준버전여부 ' <br>
	 * , count(1) as WEQP_QTY ' 유선단말수량 '<br>
	 * , 'WEQP' as AUDIT_ID ' 최종변경자ID '<br>
	 * from ( <br>
	 * select nvl(LW.TPO_CD, 'NULL') as TPO_CD<br>
	 * , WEQP.EQP_MDL_CD<br>
	 * , nvl(LK.ADRC_EQUIP_ID, 'NULL') as L3_EQUIP_ID<br>
	 * , nvl(TRAP.EQP_VER_INFO, 'NULL') as EQP_VER_INFO<br>
	 * , decode(VER.EQP_MDL_CD, null, 'N', 'Y') <br>
	 * as STRD_VER_YN<br>
	 * from OIV10800 WEQP ' 유선단말기본 '<br>
	 * left join OIV10402 LW on LW.WEQP_MGMT_NUM = WEQP.WEQP_MGMT_NUM<br>
	 * left join OIV10401 LK on LK.LINK_ID = LW.LINK_ID<br>
	 * left join OIV10802 TRAP on TRAP.MAC_ADDR_VAL = WEQP.MAC_ADDR_VAL<br>
	 * left join OIV10702 VER on VER.EQP_MDL_CD = WEQP.EQP_MDL_CD and
	 * VER.WEQP_VER_STRD_INFO = TRAP.EQP_VER_INFO<br>
	 * ) T<br>
	 * group by T.TPO_CD<br>
	 * , T.EQP_MDL_CD<br>
	 * , T.EQP_VER_INFO<br>
	 * , T.L3_EQUIP_ID<br>
	 * , T.STRD_VER_YN <br>
	 */
	public final String INSERT_OIV10808 = "INSERT_OIV10808";

	/**
	 * para : <br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * INSERT<br>
	 * INTO OIV10813<br>
	 * ( RGST_DT ' 등록일자 ' <br>
	 * , TPO_CD ' 국사코드 ' <br>
	 * , L3_EQUIP_ID ' L3장비ID ' <br>
	 * , L2_EQUIP_ID ' L2장비ID ' <br>
	 * , EQP_MDL_CD ' 단말모델코드 ' <br>
	 * , WEQP_QTY ' 유선단말수량 ' <br>
	 * , AUDIT_ID ' 최종변경자ID ' <br>
	 * )<br>
	 * select <br>
	 * to_char(sysdate, 'YYYYMMDD') as RGST_DT ' 등록일자 ' <br>
	 * , T.TPO_CD as TPO_CD ' 국사코드 ' <br>
	 * , T.L3_EQUIP_ID as L3_EQUIP_ID ' L3장비ID ' <br>
	 * , T.L2_EQUIP_ID as L2_EQUIP_ID ' L2장비ID ' <br>
	 * , T.EQP_MDL_CD as EQP_MDL_CD ' 단말모델코드 ' <br>
	 * , count(1) as WEQP_QTY ' 유선단말수량 '<br>
	 * , 'WEQP' as AUDIT_ID ' 최종변경자ID '<br>
	 * from ( <br>
	 * select nvl(LW.TPO_CD, 'NULL') as TPO_CD<br>
	 * , nvl(LK.ADRC_EQUIP_ID, 'NULL') as L3_EQUIP_ID<br>
	 * , nvl(LK.ZDRC_EQUIP_ID, 'NULL') as L2_EQUIP_ID<br>
	 * , WEQP.EQP_MDL_CD<br>
	 * from OIV10800 WEQP ' 유선단말기본 '<br>
	 * left join OIV10402 LW on LW.WEQP_MGMT_NUM = WEQP.WEQP_MGMT_NUM<br>
	 * left join OIV10401 LK on LK.LINK_ID = LW.LINK_ID<br>
	 * where LK.ADRC_EQUIP_ID != LK.ZDRC_EQUIP_ID<br>
	 * and LK.ZDRC_EQUIP_ID is not null<br>
	 * ) T<br>
	 * group by T.TPO_CD<br>
	 * , T.L3_EQUIP_ID<br>
	 * , T.L2_EQUIP_ID<br>
	 * , T.EQP_MDL_CD <br>
	 */
	public final String INSERT_OIV10813 = "INSERT_OIV10813";

	/**
	 * para : <br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * INSERT<br>
	 * INTO OIV10814<br>
	 * ( RGST_DT ' 등록일자 ' <br>
	 * , TPO_CD ' 국사코드 ' <br>
	 * , L3_EQUIP_ID ' L3장비ID ' <br>
	 * , CCELL_NUM ' 셀번호 ' <br>
	 * , EQP_MDL_CD ' 단말모델코드 ' <br>
	 * , WEQP_QTY ' 유선단말수량 ' <br>
	 * , AUDIT_ID ' 최종변경자ID ' )<br>
	 * select <br>
	 * to_char(sysdate, 'YYYYMMDD') as RGST_DT ' 등록일자 ' <br>
	 * , T.TPO_CD as TPO_CD ' 국사코드 ' <br>
	 * , T.L3_EQUIP_ID as L3_EQUIP_ID ' L3장비ID ' <br>
	 * , T.CCELL_NUM as CCELL_NUM ' 셀번호 ' <br>
	 * , T.EQP_MDL_CD as EQP_MDL_CD ' 단말모델코드 ' <br>
	 * , count(1) as WEQP_QTY ' 유선단말수량 '<br>
	 * , 'WEQP' as AUDIT_ID ' 최종변경자ID '<br>
	 * from ( <br>
	 * select nvl(LW.TPO_CD, 'NULL') as TPO_CD<br>
	 * , nvl(LK.ADRC_EQUIP_ID, 'NULL') as L3_EQUIP_ID<br>
	 * , nvl(LK.ADRC_CCELL_NUM, 'NULL') as CCELL_NUM<br>
	 * , WEQP.EQP_MDL_CD<br>
	 * from OIV10800 WEQP ' 유선단말기본 '<br>
	 * left join OIV10402 LW on LW.WEQP_MGMT_NUM = WEQP.WEQP_MGMT_NUM<br>
	 * left join OIV10401 LK on LK.LINK_ID = LW.LINK_ID<br>
	 * where LK.ADRC_CCELL_NUM is not null<br>
	 * ) T<br>
	 * group by T.TPO_CD<br>
	 * , T.L3_EQUIP_ID<br>
	 * , T.CCELL_NUM<br>
	 * , T.EQP_MDL_CD <br>
	 */
	public final String INSERT_OIV10814 = "INSERT_OIV10814";

	/**
	 * para : $rgst_dt<br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * merge into OIV10702 A<br>
	 * using ( <br>
	 * select * <br>
	 * from (<br>
	 * select distinct <br>
	 * eqp_mdl_cd<br>
	 * , eqp_ver_info <br>
	 * from OIV10808 <br>
	 * where rgst_dt = $rgst_dt<br>
	 * ) <br>
	 * where eqp_ver_info not in ('NULL', 'null', '\ ') <br>
	 * and length(eqp_ver_info) < 50<br>
	 * ) B<br>
	 * on ( B.eqp_mdl_cd = A.eqp_mdl_cd <br>
	 * and B.eqp_ver_info = A.WEQP_VER_STRD_INFO <br>
	 * )<br>
	 * when not matched then<br>
	 * insert ( <br>
	 * eqp_mdl_cd<br>
	 * , WEQP_VER_STRD_INFO<br>
	 * , AUDIT_ID<br>
	 * , AUDIT_DTM<br>
	 * , RGST_RSN_CTT<br>
	 * ) values (<br>
	 * B.eqp_mdl_cd<br>
	 * , B.eqp_ver_info<br>
	 * , 'MICM'<br>
	 * , sysdate<br>
	 * , '집계에 포함된 버전 추가'<br>
	 * ) <br>
	 */
	public final String MERGE_OIV10702 = "MERGE_OIV10702";

}