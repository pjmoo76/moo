package com.skb.adams.cm.dao;

/**
* File : oes.xml<br>
* @since 20171226192839
* @author subkjh 
*
*/


public class ParaQid { 

/** 쿼리 모임 화일명. oes.xml*/
public static final String QUERY_XML_FILE = "para.xml";

public ParaQid() { 
} 
/**
* para : <br>
* result : RESULT_PARA=com.skb.adams.cm.model.ParaVO<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * select	distinct <br>				TEAM_ORG_ID			as PARA_CODE<br>				, TEAM_ORG_NM		as PARA_NAME<br>		from	OIV10301 <br>
*/
public final String SELECT_TEAM = "SELECT_TEAM";
public final String SELECT_STB_MDL = "SELECT_STB_MDL";

}