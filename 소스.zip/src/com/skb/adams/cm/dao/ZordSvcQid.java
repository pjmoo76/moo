package com.skb.adams.cm.dao;

public class ZordSvcQid {
	public static final String QUERY_XML_FILE = "zord_svc.xml";
	
	public ZordSvcQid() {
		
	}
	
	public final String DROP_TABLE_FX_TMP_OES10200 = "DROP_TABLE_FX_TMP_OES10200";
	public final String CREATE_TABLE_FX_TMP_OES10200 = "CREATE_TABLE_FX_TMP_OES10200";
	public final String INSERT_FX_TMP_OES10200 = "INSERT_FX_TMP_OES10200";
	public final String SELECT_ZORD_SVC = "SELECT_ZORD_SVC";
	public final String MERGE_OES10200__BY_FX_TMP_OES10200 = "MERGE_OES10200__BY_FX_TMP_OES10200";
	public final String DELETE_OES10200__BY_FX_TMP_OES10200 = "DELETE_OES10200__BY_FX_TMP_OES10200";
}
