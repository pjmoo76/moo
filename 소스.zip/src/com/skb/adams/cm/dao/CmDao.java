package com.skb.adams.cm.dao;

import java.text.SimpleDateFormat;
import java.util.Date;

import fxms.bas.fxo.FxCfg;

public class CmDao {
	public static final String NEIFDB = "NEIFDB";
	public static final String ADAMS = "ADAMS_MICM";
	public static final String ADAMS_MIAPP = "ADAMS_MIAPP";
	public static final String ADAMS_MICM = "ADAMS_MICM";
	public static final String ADAMS_MICL = "ADAMS_MICL";
	// public static final String DEV = "ADAMS_DJ";
	// public static final String MGMTQ = "MGMTQ";

	public static final String DATA_FOLDER = "datas";
	public static final String DATA_SWINGDB_FOLDER = "swing-db";

	private static final SimpleDateFormat YYYYMMDD = new SimpleDateFormat("yyyyMMdd");

	private static final SimpleDateFormat YYYYMMDDHHMMSS = new SimpleDateFormat("yyyyMMddHHmmss");
	private static final SimpleDateFormat YYYYMMDDHHMM = new SimpleDateFormat("yyyyMMddHHmm");

	/**
	 * 눈으로 확인할 수 있는 시간 형식으로 넘긴다.
	 * 
	 * @return yyyyMMddHHmmss의 값
	 */
	public static synchronized String getDate(long mstime) {
		if (mstime <= 0) {
			return YYYYMMDDHHMMSS.format(new Date(System.currentTimeMillis()));
		} else {
			return YYYYMMDDHHMMSS.format(new Date(mstime));
		}
	}

	public static String getSwingDataFile(String name) {
		return FxCfg.getFile(DATA_FOLDER, DATA_SWINGDB_FOLDER, name);
	}

	public static synchronized String getYYYYMMDD(long mstime) {
		if (mstime <= 0) {
			return YYYYMMDD.format(new Date(System.currentTimeMillis()));
		} else {
			return YYYYMMDD.format(new Date(mstime));
		}
	}
	public static synchronized String YYYYMMDDHHMM(long mstime) {
		if (mstime <= 0) {
			return YYYYMMDDHHMM.format(new Date(System.currentTimeMillis()));
		} else {
			return YYYYMMDDHHMM.format(new Date(mstime));
		}
	}
}
