package com.skb.adams.cm.dao;

/**
* File : zoss_weqp.xml<br>
* @since 20171220160802
* @author subkjh 
*
*/


public class ZossWeqpQid { 

/** 쿼리 모임 화일명. zoss_weqp.xml*/
public static final String QUERY_XML_FILE = "zoss_weqp.xml";

public ZossWeqpQid() { 
} 
/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * alter table MIIV_OWN.OIV10809 drop constraint OIV10809_PK <br>
*/
public final String COPY_FX_TMP_OIV10809_01__DROP_PK = "COPY_FX_TMP_OIV10809_01__DROP_PK";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * drop index MIIV_OWN.OIV10809_PK <br>
*/
public final String COPY_FX_TMP_OIV10809_02__DROP_INDEX = "COPY_FX_TMP_OIV10809_02__DROP_INDEX";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * drop index MIIV_OWN.OIV10809_N1 <br>
*/
public final String COPY_FX_TMP_OIV10809_03__DROP_INDEX = "COPY_FX_TMP_OIV10809_03__DROP_INDEX";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * drop index MIIV_OWN.OIV10809_N2 <br>
*/
public final String COPY_FX_TMP_OIV10809_04__DROP_INDEX = "COPY_FX_TMP_OIV10809_04__DROP_INDEX";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * truncate table MIIV_OWN.OIV10809 reuse storage <br>
*/
public final String COPY_FX_TMP_OIV10809_05__TRUNCATE = "COPY_FX_TMP_OIV10809_05__TRUNCATE";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into '+APPEND NOLOGGING OIV10809 ' OIV10809 (<br>			AGRMT_ID<br>			, ASSET_MGMT_CL_CD<br>			, ASSET_NUM<br>			, AUDIT_DTM<br>			, AUDIT_ID<br>			, BF_WEQP_MGMT_NUM<br>			, CRE_DTM<br>			, CRTR_ID<br>			, DSNET_ORG_ID<br>			, IWEI_NUM<br>			, MAC_ADDR_VAL<br>			, MFACT_SER_NUM<br>			, QLTY_GRT_TRM_EXPIR_DT<br>			, REP_SVC_MGMT_NUM<br>			, SALE_CHRGR_ID<br>			, SALE_DSNET_ORG_ID<br>			, SALE_DT<br>			, SALE_PSBL_YN<br>			, SALE_RCP_NUM<br>			, ST_FLU_DT<br>			, VOICE_MAC_ADDR_VAL<br>			, WEQP_CL_CD<br>			, WEQP_GR<br>			, WEQP_GRP_CD<br>			, WEQP_HST_CL_CD<br>			, WEQP_HST_NUM<br>			, WEQP_LOC_CL_CD<br>			, WEQP_LOC_ID<br>			, WEQP_MDL_CD<br>			, WEQP_MGMT_NUM<br>			, WEQP_ORD_NUM<br>			, WEQP_SET_LOC_CD<br>			, WEQP_SET_LOC_CTT<br>			, WEQP_ST_CD<br>			, WEQP_USE_PERM_YN<br>		) <br>		select<br>				AGRMT_ID<br>				, ASSET_MGMT_CL_CD<br>				, ASSET_NUM<br>				, AUDIT_DTM<br>				, AUDIT_ID<br>				, BF_WEQP_MGMT_NUM<br>				, CRE_DTM<br>				, CRTR_ID<br>				, DSNET_ORG_ID<br>				, IWEI_NUM<br>				, MAC_ADDR_VAL<br>				, MFACT_SER_NUM<br>				, QLTY_GRT_TRM_EXPIR_DT<br>				, REP_SVC_MGMT_NUM<br>				, SALE_CHRGR_ID<br>				, SALE_DSNET_ORG_ID<br>				, SALE_DT<br>				, SALE_PSBL_YN<br>				, SALE_RCP_NUM<br>				, ST_FLU_DT<br>				, VOICE_MAC_ADDR_VAL<br>				, WEQP_CL_CD<br>				, WEQP_GR<br>				, WEQP_GRP_CD<br>				, WEQP_HST_CL_CD<br>				, WEQP_HST_NUM<br>				, WEQP_LOC_CL_CD<br>				, WEQP_LOC_ID<br>				, WEQP_MDL_CD<br>				, WEQP_MGMT_NUM<br>				, WEQP_ORD_NUM<br>				, WEQP_SET_LOC_CD<br>				, WEQP_SET_LOC_CTT<br>				, WEQP_ST_CD<br>				, WEQP_USE_PERM_YN<br>		from 	FX_TMP_OIV10809 <br>
*/
public final String COPY_FX_TMP_OIV10809_06__INSERT = "COPY_FX_TMP_OIV10809_06__INSERT";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * create unique index MIIV_OWN.OIV10809_PK on MIIV_OWN.OIV10809 ( WEQP_MGMT_NUM ) <br>
*/
public final String COPY_FX_TMP_OIV10809_07__CREATE_INDEX = "COPY_FX_TMP_OIV10809_07__CREATE_INDEX";

public final String COPY_FX_TMP_OIV10809_07__ALTER_INDEX = "COPY_FX_TMP_OIV10809_07__ALTER_INDEX";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * alter table MIIV_OWN.OIV10809 add constraint OIV10809_PK primary key ( WEQP_MGMT_NUM ) USING INDEX MIIV_OWN.OIV10809_PK <br>
*/
public final String COPY_FX_TMP_OIV10809_08__CREATE_PK = "COPY_FX_TMP_OIV10809_08__CREATE_PK";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * CREATE INDEX MIIV_OWN.OIV10809_N1 ON MIIV_OWN.OIV10809 (MAC_ADDR_VAL) <br>
*/
public final String COPY_FX_TMP_OIV10809_09__CREATE_INDEX = "COPY_FX_TMP_OIV10809_09__CREATE_INDEX";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * CREATE INDEX MIIV_OWN.OIV10809_N2 ON MIIV_OWN.OIV10809 (MFACT_SER_NUM) <br>
*/
public final String COPY_FX_TMP_OIV10809_10__CREATE_INDEX = "COPY_FX_TMP_OIV10809_10__CREATE_INDEX";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * CREATE TABLE FX_TMP_OIV10809 (<br>			  WEQP_MGMT_NUM VARCHAR2(22 BYTE) NOT NULL <br>			, AUDIT_ID VARCHAR2(15 BYTE) NOT NULL <br>			, AUDIT_DTM DATE DEFAULT SYSDATE NOT NULL <br>			, WEQP_GRP_CD VARCHAR2(4 BYTE) <br>			, WEQP_MDL_CD VARCHAR2(10 BYTE) NOT NULL <br>			, WEQP_ST_CD VARCHAR2(2 BYTE) <br>			, ST_FLU_DT VARCHAR2(8 BYTE) <br>			, IWEI_NUM VARCHAR2(18 BYTE) <br>			, MAC_ADDR_VAL VARCHAR2(15 BYTE) <br>			, WEQP_USE_PERM_YN VARCHAR2(1 BYTE) <br>			, WEQP_ORD_NUM VARCHAR2(20 BYTE) NOT NULL <br>			, MFACT_SER_NUM VARCHAR2(15 BYTE) <br>			, ASSET_MGMT_CL_CD VARCHAR2(1 BYTE) <br>			, SALE_PSBL_YN VARCHAR2(1 BYTE) <br>			, WEQP_CL_CD VARCHAR2(1 BYTE) <br>			, VOICE_MAC_ADDR_VAL VARCHAR2(15 BYTE) <br>			, ASSET_NUM VARCHAR2(22 BYTE) <br>			, DSNET_ORG_ID VARCHAR2(10 BYTE) <br>			, REP_SVC_MGMT_NUM NUMBER(10, 0) <br>			, SALE_DT VARCHAR2(8 BYTE) <br>			, WEQP_HST_NUM NUMBER(15, 0) <br>			, WEQP_HST_CL_CD VARCHAR2(5 BYTE) <br>			, QLTY_GRT_TRM_EXPIR_DT VARCHAR2(8 BYTE) <br>			, WEQP_LOC_CL_CD VARCHAR2(2 BYTE) <br>			, WEQP_LOC_ID VARCHAR2(10 BYTE) <br>			, BF_WEQP_MGMT_NUM VARCHAR2(22 BYTE) <br>			, SALE_CHRGR_ID VARCHAR2(15 BYTE) <br>			, SALE_RCP_NUM VARCHAR2(20 BYTE) <br>			, SALE_DSNET_ORG_ID VARCHAR2(10 BYTE) <br>			, AGRMT_ID VARCHAR2(15 BYTE) <br>			, CRE_DTM VARCHAR2(14 BYTE)<br>			, CRTR_ID VARCHAR2(10 BYTE) <br>			, WEQP_SET_LOC_CD VARCHAR2(3 BYTE) <br>			, WEQP_SET_LOC_CTT VARCHAR2(20 BYTE) <br>			, WEQP_GR VARCHAR2(1 BYTE) <br>		) <br>
*/
public final String CREATE_TABLE_FX_TMP_OIV10809 = "CREATE_TABLE_FX_TMP_OIV10809";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * DROP TABLE FX_TMP_OIV10809 <br>
*/
public final String DROP_TABLE_FX_TMP_OIV10809 = "DROP_TABLE_FX_TMP_OIV10809";

/**
* para : $getAgrmtId(), $getAssetMgmtClCd(), $getAssetNum(), $getAuditDtm(), $getAuditId(), $getBfWeqpMgmtNum(), $getCreDtm(), $getCrtrId(), $getDsnetOrgId(), $getIweiNum(), $getMacAddrVal(), $getMfactSerNum(), $getQltyGrtTrmExpirDt(), $getRepSvcMgmtNum(), $getSaleChrgrId(), $getSaleDsnetOrgId(), $getSaleDt(), $isSalePsblYn(), $getSaleRcpNum(), $getStFluDt(), $getVoiceMacAddrVal(), $getWeqpClCd(), $getWeqpGr(), $getWeqpGrpCd(), $getWeqpHstClCd(), $getWeqpHstNum(), $getWeqpLocClCd(), $getWeqpLocId(), $getWeqpMdlCd(), $getWeqpMgmtNum(), $getWeqpOrdNum(), $getWeqpSetLocCd(), $getWeqpSetLocCtt(), $getWeqpStCd(), $isWeqpUsePermYn()<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into '+APPEND NOLOGGING FX_TMP_OIV10809 ' FX_TMP_OIV10809 (<br>			AGRMT_ID<br>			, ASSET_MGMT_CL_CD<br>			, ASSET_NUM<br>			, AUDIT_DTM<br>			, AUDIT_ID<br>			, BF_WEQP_MGMT_NUM<br>			, CRE_DTM<br>			, CRTR_ID<br>			, DSNET_ORG_ID<br>			, IWEI_NUM<br>			, MAC_ADDR_VAL<br>			, MFACT_SER_NUM<br>			, QLTY_GRT_TRM_EXPIR_DT<br>			, REP_SVC_MGMT_NUM<br>			, SALE_CHRGR_ID<br>			, SALE_DSNET_ORG_ID<br>			, SALE_DT<br>			, SALE_PSBL_YN<br>			, SALE_RCP_NUM<br>			, ST_FLU_DT<br>			, VOICE_MAC_ADDR_VAL<br>			, WEQP_CL_CD<br>			, WEQP_GR<br>			, WEQP_GRP_CD<br>			, WEQP_HST_CL_CD<br>			, WEQP_HST_NUM<br>			, WEQP_LOC_CL_CD<br>			, WEQP_LOC_ID<br>			, WEQP_MDL_CD<br>			, WEQP_MGMT_NUM<br>			, WEQP_ORD_NUM<br>			, WEQP_SET_LOC_CD<br>			, WEQP_SET_LOC_CTT<br>			, WEQP_ST_CD<br>			, WEQP_USE_PERM_YN<br>		) values (<br>			$getAgrmtId()<br>			, $getAssetMgmtClCd()<br>			, $getAssetNum()<br>			, $getAuditDtm()<br>			, $getAuditId()<br>			, $getBfWeqpMgmtNum()<br>			, $getCreDtm()<br>			, $getCrtrId()<br>			, $getDsnetOrgId()<br>			, $getIweiNum()<br>			, $getMacAddrVal()<br>			, $getMfactSerNum()<br>			, $getQltyGrtTrmExpirDt()<br>			, $getRepSvcMgmtNum()<br>			, $getSaleChrgrId()<br>			, $getSaleDsnetOrgId()<br>			, $getSaleDt()<br>			, $isSalePsblYn()<br>			, $getSaleRcpNum()<br>			, $getStFluDt()<br>			, $getVoiceMacAddrVal()<br>			, $getWeqpClCd()<br>			, $getWeqpGr()<br>			, $getWeqpGrpCd()<br>			, $getWeqpHstClCd()<br>			, $getWeqpHstNum()<br>			, $getWeqpLocClCd()<br>			, $getWeqpLocId()<br>			, $getWeqpMdlCd()<br>			, $getWeqpMgmtNum()<br>			, $getWeqpOrdNum()<br>			, $getWeqpSetLocCd()<br>			, $getWeqpSetLocCtt()<br>			, $getWeqpStCd()<br>			, $isWeqpUsePermYn()<br>		) <br>
*/
public final String INSERT_FX_TMP_OIV10809 = "INSERT_FX_TMP_OIV10809";

/**
* para : <br>
* result : RESULT_OIV10809=com.skb.adams.cm.model.OIV10809<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * select	AGRMT_ID<br>			, ASSET_MGMT_CL_CD<br>			, ASSET_NUM<br>			, AUDIT_DTM<br>			, AUDIT_ID<br>			, BF_WEQP_MGMT_NUM<br>			, CRE_DTM<br>			, CRTR_ID<br>			, DSNET_ORG_ID<br>			, IWEI_NUM<br>			, MAC_ADDR_VAL<br>			, MFACT_SER_NUM<br>			, QLTY_GRT_TRM_EXPIR_DT<br>			, REP_SVC_MGMT_NUM<br>			, SALE_CHRGR_ID<br>			, SALE_DSNET_ORG_ID<br>			, SALE_DT<br>			, SALE_PSBL_YN<br>			, SALE_RCP_NUM<br>			, ST_FLU_DT<br>			, VOICE_MAC_ADDR_VAL<br>			, WEQP_CL_CD<br>			, WEQP_GR<br>			, WEQP_GRP_CD<br>			, WEQP_HST_CL_CD<br>			, WEQP_HST_NUM<br>			, WEQP_LOC_CL_CD<br>			, WEQP_LOC_ID<br>			, WEQP_MDL_CD<br>			, WEQP_MGMT_NUM<br>			, WEQP_ORD_NUM<br>			, WEQP_SET_LOC_CD<br>			, WEQP_SET_LOC_CTT<br>			, WEQP_ST_CD<br>			, WEQP_USE_PERM_YN<br>		from	ZOSS_WEQP <br>
*/
public final String SELECT_ZOSS_WEQP = "SELECT_ZOSS_WEQP";

}