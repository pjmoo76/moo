package com.skb.adams.cm.dao;

public class ZossBldQid {
	public static final String QUERY_XML_FILE = "zoss_bld.xml";
	
	public ZossBldQid() {
		
	}
	
	public final String DROP_TABLE_FX_TMP_OES30200 = "DROP_TABLE_FX_TMP_OES30200";
	public final String CREATE_TABLE_FX_TMP_OES30200 = "CREATE_TABLE_FX_TMP_OES30200";
	public final String INSERT_FX_TMP_OES30200 = "INSERT_FX_TMP_OES30200";
	public final String SELECT_ZOSS_BLD = "SELECT_ZOSS_BLD";
	public final String MERGE_OES30200__BY_FX_TMP_OES30200 = "MERGE_OES30200__BY_FX_TMP_OES30200";
	public final String DELETE_OES30200__BY_FX_TMP_OES30200 = "DELETE_OES30200__BY_FX_TMP_OES30200";

}
