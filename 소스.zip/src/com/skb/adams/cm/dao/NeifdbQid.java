package com.skb.adams.cm.dao;

/**
 * File : neifdb.xml<br>
 * 
 * @since 20180329094411
 * @author subkjh
 *
 */

public class NeifdbQid {

	/** 쿼리 모임 화일명. neifdb.xml */
	public static final String QUERY_XML_FILE = "neifdb.xml";

	public NeifdbQid() {
	}

	/**
	 * para : <br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * delete<br>
	 * from OIV10112 <br>
	 */
	public final String DELETE_OIV10112 = "DELETE_OIV10112";

	/**
	 * para : <br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * delete<br>
	 * from OIV10208 <br>
	 */
	public final String DELETE_OIV10208 = "DELETE_OIV10208";

	/**
	 * para : <br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * delete<br>
	 * from OIV10709 <br>
	 */
	public final String DELETE_OIV10709 = "DELETE_OIV10709";

	/**
	 * para : $isAutoActvnYn(), $getDtlWireMediaClCd(), $getEmsIpAddr(),
	 * $getEmsLinkTypCtt(), $getEquipCd(), $getEquipMgmtDeptOrgId(),
	 * $getEquipMgmtNum(), $isEquipOwnYn(), $getEquipSetLocDesc(),
	 * $getEquipSysNm(), $getEquipSysSetDt(), $getEquipTidVal(),
	 * $getEquipTypClCd(), $getEquipVerNum(), $getExchgTpoCd(),
	 * $getIequipNetClCd(), $getIpAddr(), $getIpAddrClCd(), $getJurisTpoCd(),
	 * $getKeyRcvLocDesc(), $getLineNum(), $getLinkEquipMgmtNum(), $getMemo(),
	 * $getMgmtDeptClCd(), $getMgmtTpoCd(), $isNetChgYn(), $getNmsEquipCd(),
	 * $getOperCoId(), $getOperGrpId(), $isShrEquipYn(), $getSpclInspClCd(),
	 * $getTpoCd(), $getTpoEquipSerNum(), $getTpoSerNum(), $isUpsLinkYn(),
	 * $getWireMediaClCd()<br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * insert into '+APPEND ' OIV10112 (<br>
	 * AUDIT_ID<br>
	 * , AUTO_ACTVN_YN<br>
	 * , DTL_WIRE_MEDIA_CL_CD<br>
	 * , EMS_IP_ADDR<br>
	 * , EMS_LINK_TYP_CTT<br>
	 * , EQUIP_CD<br>
	 * , EQUIP_MGMT_DEPT_ORG_ID<br>
	 * , EQUIP_MGMT_NUM<br>
	 * , EQUIP_OWN_YN<br>
	 * , EQUIP_SET_LOC_DESC<br>
	 * , EQUIP_SYS_NM<br>
	 * , EQUIP_SYS_SET_DT<br>
	 * , EQUIP_TID_VAL<br>
	 * , EQUIP_TYP_CL_CD<br>
	 * , EQUIP_VER_NUM<br>
	 * , EXCHG_TPO_CD<br>
	 * , IEQUIP_NET_CL_CD<br>
	 * , IP_ADDR<br>
	 * , IP_ADDR_CL_CD<br>
	 * , JURIS_TPO_CD<br>
	 * , KEY_RCV_LOC_DESC<br>
	 * , LINE_NUM<br>
	 * , LINK_EQUIP_MGMT_NUM<br>
	 * , MEMO<br>
	 * , MGMT_DEPT_CL_CD<br>
	 * , MGMT_TPO_CD<br>
	 * , NET_CHG_YN<br>
	 * , NMS_EQUIP_CD<br>
	 * , OPER_CO_ID<br>
	 * , OPER_GRP_ID<br>
	 * , SHR_EQUIP_YN<br>
	 * , SPCL_INSP_CL_CD<br>
	 * , TPO_CD<br>
	 * , TPO_EQUIP_SER_NUM<br>
	 * , TPO_SER_NUM<br>
	 * , UPS_LINK_YN<br>
	 * , WIRE_MEDIA_CL_CD<br>
	 * ) values (<br>
	 * 'MICM'<br>
	 * , $isAutoActvnYn()<br>
	 * , $getDtlWireMediaClCd()<br>
	 * , $getEmsIpAddr()<br>
	 * , $getEmsLinkTypCtt()<br>
	 * , $getEquipCd()<br>
	 * , $getEquipMgmtDeptOrgId()<br>
	 * , $getEquipMgmtNum()<br>
	 * , $isEquipOwnYn()<br>
	 * , $getEquipSetLocDesc()<br>
	 * , $getEquipSysNm()<br>
	 * , $getEquipSysSetDt()<br>
	 * , $getEquipTidVal()<br>
	 * , $getEquipTypClCd()<br>
	 * , $getEquipVerNum()<br>
	 * , $getExchgTpoCd()<br>
	 * , $getIequipNetClCd()<br>
	 * , $getIpAddr()<br>
	 * , $getIpAddrClCd()<br>
	 * , $getJurisTpoCd()<br>
	 * , $getKeyRcvLocDesc()<br>
	 * , $getLineNum()<br>
	 * , $getLinkEquipMgmtNum()<br>
	 * , $getMemo()<br>
	 * , $getMgmtDeptClCd()<br>
	 * , $getMgmtTpoCd()<br>
	 * , $isNetChgYn()<br>
	 * , $getNmsEquipCd()<br>
	 * , $getOperCoId()<br>
	 * , $getOperGrpId()<br>
	 * , $isShrEquipYn()<br>
	 * , $getSpclInspClCd()<br>
	 * , $getTpoCd()<br>
	 * , $getTpoEquipSerNum()<br>
	 * , $getTpoSerNum()<br>
	 * , $isUpsLinkYn()<br>
	 * , $getWireMediaClCd()<br>
	 * ) <br>
	 */
	public final String INSERT_OIV10112 = "INSERT_OIV10112";

	/**
	 * para : $isAltItmAplyObjYn(), $getAuditDtm(), $getAuditId(),
	 * $getConsItmTypCd(), $getEquipCd(), $isEquipDplxgYn(),
	 * $getEquipDtlsDesc(), $getEquipIntdcYm(), $getEquipMdlNm(),
	 * $getEquipMfactCd(), $getEquipNm(), $getEquipRprPrd(), $getEquipTypCd(),
	 * $getEquipUnitCd(), $getEquipUnitPrc(), $getFcltDlvedGdsCoCd(),
	 * $getFinAssetCd(), $getIniAltItmAplyRt(), $getScardUseUsgCd(),
	 * $getSrgtScardEquipCd(), $isSvcInfluYn()<br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * insert into '+APPEND ' OIV10208 (<br>
	 * ALT_ITM_APLY_OBJ_YN<br>
	 * , AUDIT_DTM<br>
	 * , AUDIT_ID<br>
	 * , CONS_ITM_TYP_CD<br>
	 * , EQUIP_CD<br>
	 * , EQUIP_DPLXG_YN<br>
	 * , EQUIP_DTLS_DESC<br>
	 * , EQUIP_INTDC_YM<br>
	 * , EQUIP_MDL_NM<br>
	 * , EQUIP_MFACT_CD<br>
	 * , EQUIP_NM<br>
	 * , EQUIP_RPR_PRD<br>
	 * , EQUIP_TYP_CD<br>
	 * , EQUIP_UNIT_CD<br>
	 * , EQUIP_UNIT_PRC<br>
	 * , FCLT_DLVED_GDS_CO_CD<br>
	 * , FIN_ASSET_CD<br>
	 * , INI_ALT_ITM_APLY_RT<br>
	 * , SCARD_USE_USG_CD<br>
	 * , SRGT_SCARD_EQUIP_CD<br>
	 * , SVC_INFLU_YN<br>
	 * ) values (<br>
	 * $isAltItmAplyObjYn()<br>
	 * , $getAuditDtm()<br>
	 * , $getAuditId()<br>
	 * , $getConsItmTypCd()<br>
	 * , $getEquipCd()<br>
	 * , $isEquipDplxgYn()<br>
	 * , $getEquipDtlsDesc()<br>
	 * , $getEquipIntdcYm()<br>
	 * , $getEquipMdlNm()<br>
	 * , $getEquipMfactCd()<br>
	 * , $getEquipNm()<br>
	 * , $getEquipRprPrd()<br>
	 * , $getEquipTypCd()<br>
	 * , $getEquipUnitCd()<br>
	 * , $getEquipUnitPrc()<br>
	 * , $getFcltDlvedGdsCoCd()<br>
	 * , $getFinAssetCd()<br>
	 * , $getIniAltItmAplyRt()<br>
	 * , $getScardUseUsgCd()<br>
	 * , $getSrgtScardEquipCd()<br>
	 * , $isSvcInfluYn()<br>
	 * ) <br>
	 */
	public final String INSERT_OIV10208 = "INSERT_OIV10208";

	/**
	 * para : $getAddrId(), $getExlineChrgrNm(), $getExlineChrgrPhonNum(),
	 * $getForgnAddr(), $getForgnCntcNum(), $getJurisInfoCntrClNum(),
	 * $getKtOperGrpCd(), $getKtTpoCd(), $getMgmtTpoCd(), $getNmsId(),
	 * $getOperGrpId(), $isRentTpoYn(), $getTpoCd(), $getTpoCntcNum(),
	 * $getTpoDsrctAreaClCd(), $getTpoNm(), $getTpoTypCd(), $isTpoUseYn()<br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * insert into '+APPEND ' OIV10300 (<br>
	 * ADDR_ID<br>
	 * , AUDIT_DTM<br>
	 * , AUDIT_ID<br>
	 * , EXLINE_CHRGR_NM<br>
	 * , EXLINE_CHRGR_PHON_NUM<br>
	 * , FORGN_ADDR<br>
	 * , FORGN_CNTC_NUM<br>
	 * , JURIS_INFO_CNTR_CL_NUM<br>
	 * , KT_OPER_GRP_CD<br>
	 * , KT_TPO_CD<br>
	 * , MGMT_TPO_CD<br>
	 * , NMS_ID<br>
	 * , OPER_GRP_ID<br>
	 * , RENT_TPO_YN<br>
	 * , TPO_CD<br>
	 * , TPO_CNTC_NUM<br>
	 * , TPO_DSRCT_AREA_CL_CD<br>
	 * , TPO_NM<br>
	 * , TPO_TYP_CD<br>
	 * , TPO_USE_YN<br>
	 * , SWING_CRE_YN<br>
	 * ) values (<br>
	 * $getAddrId()<br>
	 * , sysdate<br>
	 * , 'MICM'<br>
	 * , $getExlineChrgrNm()<br>
	 * , $getExlineChrgrPhonNum()<br>
	 * , $getForgnAddr()<br>
	 * , $getForgnCntcNum()<br>
	 * , $getJurisInfoCntrClNum()<br>
	 * , $getKtOperGrpCd()<br>
	 * , $getKtTpoCd()<br>
	 * , $getMgmtTpoCd()<br>
	 * , $getNmsId()<br>
	 * , $getOperGrpId()<br>
	 * , $isRentTpoYn()<br>
	 * , $getTpoCd()<br>
	 * , $getTpoCntcNum()<br>
	 * , $getTpoDsrctAreaClCd()<br>
	 * , $getTpoNm()<br>
	 * , $getTpoTypCd()<br>
	 * , $isTpoUseYn()<br>
	 * , 'Y'<br>
	 * ) <br>
	 */
	public final String INSERT_OIV10300 = "INSERT_OIV10300";

	/**
	 * para : $getWeqpMnufactCoCd(), $getWeqpMnufactCoNm()<br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * insert into OIV10703 (<br>
	 * WEQP_MNUFACT_CO_CD<br>
	 * , AUDIT_ID<br>
	 * , WEQP_MNUFACT_CO_NM<br>
	 * ) values (<br>
	 * $getWeqpMnufactCoCd()<br>
	 * , 'MICM'<br>
	 * , $getWeqpMnufactCoNm()<br>
	 * ) <br>
	 */
	public final String INSERT_OIV10703 = "INSERT_OIV10703";

	/**
	 * para : $getAccsClCd(), $getApplWeqpCd(), $getAuditDtm(), $getAuditId(),
	 * $isBarcdChkYn(), $getCoWeqpGrpCd(), $getMfactMdlNm(),
	 * $getMnufactNatClCd(), $isPrferWeqpYn(), $getRmk(), $isSaleEqpYn(),
	 * $getTechMthdNm(), $getTotPortCnt(), $isUseYn(), $isWeqpAttchtExistYn(),
	 * $getWeqpChrticClCd(), $getWeqpDlvedGdsCoCd(), $getWeqpEngNm(),
	 * $getWeqpGrpCd(), $getWeqpMdlCd(), $getWeqpMdlNm(), $getWeqpMnufactCoCd(),
	 * $getWeqpRentClCd(), $getWeqpStcClCd(), $getWeqpUnitCd()<br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * insert into '+APPEND ' OIV10709 (<br>
	 * ACCS_CL_CD<br>
	 * , APPL_WEQP_CD<br>
	 * , AUDIT_DTM<br>
	 * , AUDIT_ID<br>
	 * , BARCD_CHK_YN<br>
	 * , CO_WEQP_GRP_CD<br>
	 * , MFACT_MDL_NM<br>
	 * , MNUFACT_NAT_CL_CD<br>
	 * , PRFER_WEQP_YN<br>
	 * , RMK<br>
	 * , SALE_EQP_YN<br>
	 * , TECH_MTHD_NM<br>
	 * , TOT_PORT_CNT<br>
	 * , USE_YN<br>
	 * , WEQP_ATTCHT_EXIST_YN<br>
	 * , WEQP_CHRTIC_CL_CD<br>
	 * , WEQP_DLVED_GDS_CO_CD<br>
	 * , WEQP_ENG_NM<br>
	 * , WEQP_GRP_CD<br>
	 * , WEQP_MDL_CD<br>
	 * , WEQP_MDL_NM<br>
	 * , WEQP_MNUFACT_CO_CD<br>
	 * , WEQP_RENT_CL_CD<br>
	 * , WEQP_STC_CL_CD<br>
	 * , WEQP_UNIT_CD<br>
	 * ) values (<br>
	 * $getAccsClCd()<br>
	 * , $getApplWeqpCd()<br>
	 * , $getAuditDtm()<br>
	 * , $getAuditId()<br>
	 * , $isBarcdChkYn()<br>
	 * , $getCoWeqpGrpCd()<br>
	 * , $getMfactMdlNm()<br>
	 * , $getMnufactNatClCd()<br>
	 * , $isPrferWeqpYn()<br>
	 * , $getRmk()<br>
	 * , $isSaleEqpYn()<br>
	 * , $getTechMthdNm()<br>
	 * , $getTotPortCnt()<br>
	 * , $isUseYn()<br>
	 * , $isWeqpAttchtExistYn()<br>
	 * , $getWeqpChrticClCd()<br>
	 * , $getWeqpDlvedGdsCoCd()<br>
	 * , $getWeqpEngNm()<br>
	 * , $getWeqpGrpCd()<br>
	 * , $getWeqpMdlCd()<br>
	 * , $getWeqpMdlNm()<br>
	 * , $getWeqpMnufactCoCd()<br>
	 * , $getWeqpRentClCd()<br>
	 * , $getWeqpStcClCd()<br>
	 * , $getWeqpUnitCd()<br>
	 * ) <br>
	 */
	public final String INSERT_OIV10709 = "INSERT_OIV10709";

	/**
	 * para : <br>
	 * result : RESULT_OIV10300=com.skb.adams.cm.model.OIV10300<br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * select ADDR_ID<br>
	 * , EXLINE_CHRGR_NM<br>
	 * , EXLINE_CHRGR_PHON_NUM<br>
	 * , FORGN_ADDR<br>
	 * , FORGN_CNTC_NUM<br>
	 * , JURIS_INFO_CNTR_CL_NUM<br>
	 * , KT_OPER_GRP_CD<br>
	 * , KT_TPO_CD<br>
	 * , MGMT_TPO_CD<br>
	 * , NMS_ID<br>
	 * , OPER_GRP_ID<br>
	 * , RENT_TPO_YN<br>
	 * , TPO_CD<br>
	 * , TPO_CNTC_NUM<br>
	 * , TPO_DSRCT_AREA_CL_CD<br>
	 * , TPO_NM<br>
	 * , TPO_TYP_CD<br>
	 * , TPO_USE_YN<br>
	 * from OIV10300 <br>
	 */
	public final String SELECT_OIV10300 = "SELECT_OIV10300";

	/**
	 * para : <br>
	 * result : RESULT_OIV10703=com.skb.adams.cm.model.OIV10703<br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * select WEQP_MNUFACT_CO_CD<br>
	 * , WEQP_MNUFACT_CO_NM<br>
	 * from OIV10703 <br>
	 */
	public final String SELECT_OIV10703 = "SELECT_OIV10703";

	/**
	 * para : <br>
	 * result : RESULT_OIV10208=com.skb.adams.cm.model.OIV10208<br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * select ALT_ITM_APLY_OBJ_YN<br>
	 * , AUDIT_DTM<br>
	 * , AUDIT_ID<br>
	 * , CONS_ITM_TYP_CD<br>
	 * , EQUIP_CD<br>
	 * , EQUIP_DPLXG_YN<br>
	 * , EQUIP_DTLS_DESC<br>
	 * , EQUIP_INTDC_YM<br>
	 * , EQUIP_MDL_NM<br>
	 * , EQUIP_MFACT_CD<br>
	 * , EQUIP_NM<br>
	 * , EQUIP_RPR_PRD<br>
	 * , EQUIP_TYP_CD<br>
	 * , EQUIP_UNIT_CD<br>
	 * , EQUIP_UNIT_PRC<br>
	 * , FCLT_DLVED_GDS_CO_CD<br>
	 * , FIN_ASSET_CD<br>
	 * , INI_ALT_ITM_APLY_RT<br>
	 * , SCARD_USE_USG_CD<br>
	 * , SRGT_SCARD_EQUIP_CD<br>
	 * , SVC_INFLU_YN<br>
	 * from ZOSS_EQUIP_MDL <br>
	 */
	public final String SELECT_ZOSS_EQUIP_MDL = "SELECT_ZOSS_EQUIP_MDL";

	/**
	 * para : <br>
	 * result : RESULT_OIV10112=com.skb.adams.cm.model.OIV10112<br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * select AUDIT_DTM<br>
	 * , AUDIT_ID<br>
	 * , AUTO_ACTVN_YN<br>
	 * , DTL_WIRE_MEDIA_CL_CD<br>
	 * , EMS_IP_ADDR<br>
	 * , EMS_LINK_TYP_CTT<br>
	 * , EQUIP_CD<br>
	 * , EQUIP_MGMT_DEPT_ORG_ID<br>
	 * , EQUIP_MGMT_NUM<br>
	 * , EQUIP_OWN_YN<br>
	 * , EQUIP_SET_LOC_DESC<br>
	 * , EQUIP_SYS_NM<br>
	 * , EQUIP_SYS_SET_DT<br>
	 * , EQUIP_TID_VAL<br>
	 * , EQUIP_TYP_CL_CD<br>
	 * , EQUIP_VER_NUM<br>
	 * , EXCHG_TPO_CD<br>
	 * , IEQUIP_NET_CL_CD<br>
	 * , IP_ADDR<br>
	 * , IP_ADDR_CL_CD<br>
	 * , JURIS_TPO_CD<br>
	 * , KEY_RCV_LOC_DESC<br>
	 * , LINE_NUM<br>
	 * , LINK_EQUIP_MGMT_NUM<br>
	 * , MEMO<br>
	 * , MGMT_DEPT_CL_CD<br>
	 * , MGMT_TPO_CD<br>
	 * , NET_CHG_YN<br>
	 * , NMS_EQUIP_CD<br>
	 * , OPER_CO_ID<br>
	 * , OPER_GRP_ID<br>
	 * , SHR_EQUIP_YN<br>
	 * , SPCL_INSP_CL_CD<br>
	 * , TPO_CD<br>
	 * , TPO_EQUIP_SER_NUM<br>
	 * , TPO_SER_NUM<br>
	 * , UPS_LINK_YN<br>
	 * , WIRE_MEDIA_CL_CD<br>
	 * from ZOSS_EQUIP_SYS <br>
	 */
	public final String SELECT_ZOSS_EQUIP_SYS = "SELECT_ZOSS_EQUIP_SYS";

	/**
	 * para : <br>
	 * result : RESULT_OIV10300=com.skb.adams.cm.model.OIV10300<br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * select ADDR_ID<br>
	 * , EXLINE_CHRGR_NM<br>
	 * , EXLINE_CHRGR_PHON_NUM<br>
	 * , FORGN_ADDR<br>
	 * , FORGN_CNTC_NUM<br>
	 * , JURIS_INFO_CNTR_CL_NUM<br>
	 * , KT_OPER_GRP_CD<br>
	 * , KT_TPO_CD<br>
	 * , MGMT_TPO_CD<br>
	 * , NMS_ID<br>
	 * , OPER_GRP_ID<br>
	 * , RENT_TPO_YN<br>
	 * , TPO_CD<br>
	 * , TPO_CNTC_NUM<br>
	 * , TPO_DSRCT_AREA_CL_CD<br>
	 * , TPO_NM<br>
	 * , TPO_TYP_CD<br>
	 * , TPO_USE_YN<br>
	 * from ZOSS_TPO <br>
	 */
	public final String SELECT_ZOSS_TPO = "SELECT_ZOSS_TPO";

	/**
	 * para : <br>
	 * result : RESULT_OIV10709=com.skb.adams.cm.model.OIV10709<br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * select ACCS_CL_CD<br>
	 * , APPL_WEQP_CD<br>
	 * , AUDIT_DTM<br>
	 * , AUDIT_ID<br>
	 * , BARCD_CHK_YN<br>
	 * , CO_WEQP_GRP_CD<br>
	 * , MFACT_MDL_NM<br>
	 * , MNUFACT_NAT_CL_CD<br>
	 * , PRFER_WEQP_YN<br>
	 * , RMK<br>
	 * , SALE_EQP_YN<br>
	 * , TECH_MTHD_NM<br>
	 * , TOT_PORT_CNT<br>
	 * , USE_YN<br>
	 * , WEQP_ATTCHT_EXIST_YN<br>
	 * , WEQP_CHRTIC_CL_CD<br>
	 * , WEQP_DLVED_GDS_CO_CD<br>
	 * , WEQP_ENG_NM<br>
	 * , WEQP_GRP_CD<br>
	 * , WEQP_MDL_CD<br>
	 * , WEQP_MDL_NM<br>
	 * , WEQP_MNUFACT_CO_CD<br>
	 * , WEQP_RENT_CL_CD<br>
	 * , WEQP_STC_CL_CD<br>
	 * , WEQP_UNIT_CD<br>
	 * from ZOSS_WEQP_MDL <br>
	 */
	public final String SELECT_ZOSS_WEQP_MDL = "SELECT_ZOSS_WEQP_MDL";

	/**
	 * para : <br>
	 * result : RESULT_OIV10703=com.skb.adams.cm.model.OIV10703<br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * select MFACT_CD as WEQP_MNUFACT_CO_CD<br>
	 * , BIZ_CO_HAN_NM as WEQP_MNUFACT_CO_NM<br>
	 * from ZOSS_WEQP_MFACT <br>
	 */
	public final String SELECT_ZOSS_WEQP_MFACT = "SELECT_ZOSS_WEQP_MFACT";

	/**
	 * para : $getAuditDtm(), $getAuditId(), $isAutoActvnYn(),
	 * $getDtlWireMediaClCd(), $getEmsIpAddr(), $getEmsLinkTypCtt(),
	 * $getEquipCd(), $getEquipMgmtDeptOrgId(), $getEquipMgmtNum(),
	 * $isEquipOwnYn(), $getEquipSetLocDesc(), $getEquipSysNm(),
	 * $getEquipSysSetDt(), $getEquipTidVal(), $getEquipTypClCd(),
	 * $getEquipVerNum(), $getExchgTpoCd(), $getIequipNetClCd(), $getIpAddr(),
	 * $getIpAddrClCd(), $getJurisTpoCd(), $getKeyRcvLocDesc(), $getLineNum(),
	 * $getLinkEquipMgmtNum(), $getMemo(), $getMgmtDeptClCd(), $getMgmtTpoCd(),
	 * $isNetChgYn(), $getNmsEquipCd(), $getOperCoId(), $getOperGrpId(),
	 * $isShrEquipYn(), $getSpclInspClCd(), $getTpoCd(), $getTpoEquipSerNum(),
	 * $getTpoSerNum(), $isUpsLinkYn(), $getWireMediaClCd()<br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * update OIV10112 set<br>
	 * AUDIT_DTM = $getAuditDtm()<br>
	 * , AUDIT_ID = $getAuditId()<br>
	 * , AUTO_ACTVN_YN = $isAutoActvnYn()<br>
	 * , DTL_WIRE_MEDIA_CL_CD = $getDtlWireMediaClCd()<br>
	 * , EMS_IP_ADDR = $getEmsIpAddr()<br>
	 * , EMS_LINK_TYP_CTT = $getEmsLinkTypCtt()<br>
	 * , EQUIP_CD = $getEquipCd()<br>
	 * , EQUIP_MGMT_DEPT_ORG_ID = $getEquipMgmtDeptOrgId()<br>
	 * , EQUIP_MGMT_NUM = $getEquipMgmtNum()<br>
	 * , EQUIP_OWN_YN = $isEquipOwnYn()<br>
	 * , EQUIP_SET_LOC_DESC = $getEquipSetLocDesc()<br>
	 * , EQUIP_SYS_NM = $getEquipSysNm()<br>
	 * , EQUIP_SYS_SET_DT = $getEquipSysSetDt()<br>
	 * , EQUIP_TID_VAL = $getEquipTidVal()<br>
	 * , EQUIP_TYP_CL_CD = $getEquipTypClCd()<br>
	 * , EQUIP_VER_NUM = $getEquipVerNum()<br>
	 * , EXCHG_TPO_CD = $getExchgTpoCd()<br>
	 * , IEQUIP_NET_CL_CD = $getIequipNetClCd()<br>
	 * , IP_ADDR = $getIpAddr()<br>
	 * , IP_ADDR_CL_CD = $getIpAddrClCd()<br>
	 * , JURIS_TPO_CD = $getJurisTpoCd()<br>
	 * , KEY_RCV_LOC_DESC = $getKeyRcvLocDesc()<br>
	 * , LINE_NUM = $getLineNum()<br>
	 * , LINK_EQUIP_MGMT_NUM = $getLinkEquipMgmtNum()<br>
	 * , MEMO = $getMemo()<br>
	 * , MGMT_DEPT_CL_CD = $getMgmtDeptClCd()<br>
	 * , MGMT_TPO_CD = $getMgmtTpoCd()<br>
	 * , NET_CHG_YN = $isNetChgYn()<br>
	 * , NMS_EQUIP_CD = $getNmsEquipCd()<br>
	 * , OPER_CO_ID = $getOperCoId()<br>
	 * , OPER_GRP_ID = $getOperGrpId()<br>
	 * , SHR_EQUIP_YN = $isShrEquipYn()<br>
	 * , SPCL_INSP_CL_CD = $getSpclInspClCd()<br>
	 * , TPO_CD = $getTpoCd()<br>
	 * , TPO_EQUIP_SER_NUM = $getTpoEquipSerNum()<br>
	 * , TPO_SER_NUM = $getTpoSerNum()<br>
	 * , UPS_LINK_YN = $isUpsLinkYn()<br>
	 * , WIRE_MEDIA_CL_CD = $getWireMediaClCd() <br>
	 */
	public final String UPDATE_OIV10112 = "UPDATE_OIV10112";

	/**
	 * para : $isAltItmAplyObjYn(), $getAuditDtm(), $getAuditId(),
	 * $getConsItmTypCd(), $getEquipCd(), $isEquipDplxgYn(),
	 * $getEquipDtlsDesc(), $getEquipIntdcYm(), $getEquipMdlNm(),
	 * $getEquipMfactCd(), $getEquipNm(), $getEquipRprPrd(), $getEquipTypCd(),
	 * $getEquipUnitCd(), $getEquipUnitPrc(), $getFcltDlvedGdsCoCd(),
	 * $getFinAssetCd(), $getIniAltItmAplyRt(), $getScardUseUsgCd(),
	 * $getSrgtScardEquipCd(), $isSvcInfluYn()<br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * update OIV10208 set<br>
	 * ALT_ITM_APLY_OBJ_YN = $isAltItmAplyObjYn()<br>
	 * , AUDIT_DTM = $getAuditDtm()<br>
	 * , AUDIT_ID = $getAuditId()<br>
	 * , CONS_ITM_TYP_CD = $getConsItmTypCd()<br>
	 * , EQUIP_CD = $getEquipCd()<br>
	 * , EQUIP_DPLXG_YN = $isEquipDplxgYn()<br>
	 * , EQUIP_DTLS_DESC = $getEquipDtlsDesc()<br>
	 * , EQUIP_INTDC_YM = $getEquipIntdcYm()<br>
	 * , EQUIP_MDL_NM = $getEquipMdlNm()<br>
	 * , EQUIP_MFACT_CD = $getEquipMfactCd()<br>
	 * , EQUIP_NM = $getEquipNm()<br>
	 * , EQUIP_RPR_PRD = $getEquipRprPrd()<br>
	 * , EQUIP_TYP_CD = $getEquipTypCd()<br>
	 * , EQUIP_UNIT_CD = $getEquipUnitCd()<br>
	 * , EQUIP_UNIT_PRC = $getEquipUnitPrc()<br>
	 * , FCLT_DLVED_GDS_CO_CD = $getFcltDlvedGdsCoCd()<br>
	 * , FIN_ASSET_CD = $getFinAssetCd()<br>
	 * , INI_ALT_ITM_APLY_RT = $getIniAltItmAplyRt()<br>
	 * , SCARD_USE_USG_CD = $getScardUseUsgCd()<br>
	 * , SRGT_SCARD_EQUIP_CD = $getSrgtScardEquipCd()<br>
	 * , SVC_INFLU_YN = $isSvcInfluYn() <br>
	 */
	public final String UPDATE_OIV10208 = "UPDATE_OIV10208";

	/**
	 * para : $getAddrId(), $getExlineChrgrNm(), $getExlineChrgrPhonNum(),
	 * $getForgnAddr(), $getForgnCntcNum(), $getJurisInfoCntrClNum(),
	 * $getKtOperGrpCd(), $getKtTpoCd(), $getMgmtTpoCd(), $getNmsId(),
	 * $getOperGrpId(), $isRentTpoYn(), $getTpoCntcNum(),
	 * $getTpoDsrctAreaClCd(), $getTpoNm(), $getTpoTypCd(), $isTpoUseYn(),
	 * $isTpoUseYn(), $getTpoCd()<br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * update OIV10300 set<br>
	 * ADDR_ID = $getAddrId()<br>
	 * , AUDIT_DTM = sysdate<br>
	 * , AUDIT_ID = 'MICM'<br>
	 * , EXLINE_CHRGR_NM = $getExlineChrgrNm()<br>
	 * , EXLINE_CHRGR_PHON_NUM = $getExlineChrgrPhonNum()<br>
	 * , FORGN_ADDR = $getForgnAddr()<br>
	 * , FORGN_CNTC_NUM = $getForgnCntcNum()<br>
	 * , JURIS_INFO_CNTR_CL_NUM = $getJurisInfoCntrClNum()<br>
	 * , KT_OPER_GRP_CD = $getKtOperGrpCd()<br>
	 * , KT_TPO_CD = $getKtTpoCd()<br>
	 * , MGMT_TPO_CD = $getMgmtTpoCd()<br>
	 * , NMS_ID = $getNmsId()<br>
	 * , OPER_GRP_ID = $getOperGrpId()<br>
	 * , RENT_TPO_YN = $isRentTpoYn()<br>
	 * , TPO_CNTC_NUM = $getTpoCntcNum()<br>
	 * , TPO_DSRCT_AREA_CL_CD = $getTpoDsrctAreaClCd()<br>
	 * , TPO_NM = $getTpoNm()<br>
	 * , TPO_TYP_CD = $getTpoTypCd()<br>
	 * , TPO_USE_YN = $isTpoUseYn()<br>
	 * , SWING_CRE_YN = $isTpoUseYn()<br>
	 * where TPO_CD = $getTpoCd() <br>
	 */
	public final String UPDATE_OIV10300 = "UPDATE_OIV10300";

	/**
	 * para : $getTpoCd()<br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * update OIV10300 set <br>
	 * SWING_CRE_YN = 'N'<br>
	 * , AUDIT_ID = 'MICM'<br>
	 * , AUDIT_DTM = sysdate<br>
	 * where TPO_CD = $getTpoCd()<br>
	 * and SWING_CRE_YN = 'Y' <br>
	 */
	public final String UPDATE_OIV10300_SWING_DELETED = "UPDATE_OIV10300_SWING_DELETED";

	/**
	 * para : <br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * update OIV10300 set <br>
	 * TPO_USE_YN = 'N'<br>
	 * , AUDIT_ID = 'MICM'<br>
	 * , AUDIT_DTM = sysdate<br>
	 * where TPO_USE_YN = 'Y'<br>
	 * and TPO_TYP_CD in ( '4', '7' )<br>
	 * and TPO_CD not in ( <br>
	 * select TPO_CD<br>
	 * from OIV10100<br>
	 * where DEL_YN = 'N'<br>
	 * group by TPO_CD<br>
	 * <br>
	 * union all<br>
	 * <br>
	 * select TPO_CD<br>
	 * from OIV10981<br>
	 * where TPO_CD is not null<br>
	 * group by TPO_CD<br>
	 * <br>
	 * ) <br>
	 */
	public final String UPDATE_OIV10300_USE_N = "UPDATE_OIV10300_USE_N";

	/**
	 * para : <br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * update OIV10300 set <br>
	 * TPO_USE_YN = 'Y'<br>
	 * , AUDIT_ID = 'MICM'<br>
	 * , AUDIT_DTM = sysdate<br>
	 * where TPO_USE_YN = 'N'<br>
	 * and TPO_TYP_CD in ( '4', '7' )<br>
	 * and TPO_CD in ( <br>
	 * select TPO_CD<br>
	 * from OIV10100<br>
	 * where DEL_YN = 'N'<br>
	 * group by TPO_CD<br>
	 * <br>
	 * union all<br>
	 * <br>
	 * select TPO_CD<br>
	 * from OIV10981<br>
	 * where TPO_CD is not null<br>
	 * group by TPO_CD<br>
	 * <br>
	 * ) <br>
	 */
	public final String UPDATE_OIV10300_USE_Y = "UPDATE_OIV10300_USE_Y";

	/**
	 * para : $getAccsClCd(), $getApplWeqpCd(), $getAuditDtm(), $getAuditId(),
	 * $isBarcdChkYn(), $getCoWeqpGrpCd(), $getMfactMdlNm(),
	 * $getMnufactNatClCd(), $isPrferWeqpYn(), $getRmk(), $isSaleEqpYn(),
	 * $getTechMthdNm(), $getTotPortCnt(), $isUseYn(), $isWeqpAttchtExistYn(),
	 * $getWeqpChrticClCd(), $getWeqpDlvedGdsCoCd(), $getWeqpEngNm(),
	 * $getWeqpGrpCd(), $getWeqpMdlCd(), $getWeqpMdlNm(), $getWeqpMnufactCoCd(),
	 * $getWeqpRentClCd(), $getWeqpStcClCd(), $getWeqpUnitCd()<br>
	 * ------------------------------------------------------------------------
	 * ---------- <br>
	 * database : null<br>
	 * sql <br>
	 * <br>
	 * update OIV10709 set<br>
	 * ACCS_CL_CD = $getAccsClCd()<br>
	 * , APPL_WEQP_CD = $getApplWeqpCd()<br>
	 * , AUDIT_DTM = $getAuditDtm()<br>
	 * , AUDIT_ID = $getAuditId()<br>
	 * , BARCD_CHK_YN = $isBarcdChkYn()<br>
	 * , CO_WEQP_GRP_CD = $getCoWeqpGrpCd()<br>
	 * , MFACT_MDL_NM = $getMfactMdlNm()<br>
	 * , MNUFACT_NAT_CL_CD = $getMnufactNatClCd()<br>
	 * , PRFER_WEQP_YN = $isPrferWeqpYn()<br>
	 * , RMK = $getRmk()<br>
	 * , SALE_EQP_YN = $isSaleEqpYn()<br>
	 * , TECH_MTHD_NM = $getTechMthdNm()<br>
	 * , TOT_PORT_CNT = $getTotPortCnt()<br>
	 * , USE_YN = $isUseYn()<br>
	 * , WEQP_ATTCHT_EXIST_YN = $isWeqpAttchtExistYn()<br>
	 * , WEQP_CHRTIC_CL_CD = $getWeqpChrticClCd()<br>
	 * , WEQP_DLVED_GDS_CO_CD = $getWeqpDlvedGdsCoCd()<br>
	 * , WEQP_ENG_NM = $getWeqpEngNm()<br>
	 * , WEQP_GRP_CD = $getWeqpGrpCd()<br>
	 * , WEQP_MDL_CD = $getWeqpMdlCd()<br>
	 * , WEQP_MDL_NM = $getWeqpMdlNm()<br>
	 * , WEQP_MNUFACT_CO_CD = $getWeqpMnufactCoCd()<br>
	 * , WEQP_RENT_CL_CD = $getWeqpRentClCd()<br>
	 * , WEQP_STC_CL_CD = $getWeqpStcClCd()<br>
	 * , WEQP_UNIT_CD = $getWeqpUnitCd() <br>
	 */
	public final String UPDATE_OIV10709 = "UPDATE_OIV10709";

	public final String UPDATE_OIV10300_OFFC_TYP_CD_RESET = "UPDATE_OIV10300_OFFC_TYP_CD_RESET";
	public final String UPDATE_OIV10300_OFFC_TYP_CD_02 = "UPDATE_OIV10300_OFFC_TYP_CD_02";
	public final String UPDATE_OIV10300_OFFC_TYP_CD_03_1 = "UPDATE_OIV10300_OFFC_TYP_CD_03_1";
	public final String UPDATE_OIV10300_OFFC_TYP_CD_03_2 = "UPDATE_OIV10300_OFFC_TYP_CD_03_2";
	public final String UPDATE_OIV10300_OFFC_TYP_CD_03_3 = "UPDATE_OIV10300_OFFC_TYP_CD_03_3";

}