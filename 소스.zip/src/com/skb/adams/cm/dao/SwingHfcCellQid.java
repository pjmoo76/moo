package com.skb.adams.cm.dao;

/**
* File : swing_hfc_cell.xml<br>
* @since 20180111110009
* @author subkjh 
*
*/


public class SwingHfcCellQid { 

/** 쿼리 모임 화일명. swing_hfc_cell.xml*/
public static final String QUERY_XML_FILE = "swing_hfc_cell.xml";

public SwingHfcCellQid() { 
} 
/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * delete <br>		from FX_TMP_OIV10170 <br>
*/
public final String DELETE_FX_TMP_OIV10170 = "DELETE_FX_TMP_OIV10170";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * delete <br>		from FX_TMP_OIV10171 <br>
*/
public final String DELETE_FX_TMP_OIV10171 = "DELETE_FX_TMP_OIV10171";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * create table FX_TMP_OIV10170 (<br>		CCELL_ID VARCHAR2(14) NOT NULL <br>		, EQUIP_ID VARCHAR2(12) <br>		, CCELL_NUM VARCHAR2(50) <br>		, OPER_TPO_CD VARCHAR2(6) NOT NULL <br>	) <br>
*/
public final String FX_TMP_OIV10170 = "FX_TMP_OIV10170";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * create table FX_TMP_OIV10171 (<br>		CCELL_ID VARCHAR2(14 ) NOT NULL <br>		, MOUN_LOC_NUM VARCHAR2(10 ) NOT NULL <br>		, PORT_NUM VARCHAR2(10 ) NOT NULL <br>		, EQUIP_PORT_ID VARCHAR2(15 ) NOT NULL <br>		, OTX_NUM VARCHAR2(15 ) <br>		, CRE_DTM VARCHAR2(14 ) <br>	) <br>
*/
public final String FX_TMP_OIV10171 = "FX_TMP_OIV10171";

/**
* para : $getCcellId(), $getEquipId(), $getCcellNum(), $getOperTpoCd()<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert  '+APPEND NOLOGGING FX_TMP_OIV10170 '  into FX_TMP_OIV10170 (<br>			CCELL_ID<br>			, EQUIP_ID<br>			, CCELL_NUM<br>			, OPER_TPO_CD<br>		) values (<br>			$getCcellId()<br>			, $getEquipId()<br>			, $getCcellNum()<br>			, $getOperTpoCd()<br>		) <br>
*/
public final String INSERT_FX_TMP_OIV10170 = "INSERT_FX_TMP_OIV10170";

/**
* para : $getCcellId(), $getEquipPortId(), $getMounLocNum(), $getPortNum(), $getOtxNum(), $getCreDtm()<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert  '+APPEND NOLOGGING FX_TMP_OIV10171 '  into FX_TMP_OIV10171 (<br>			CCELL_ID<br>			, EQUIP_PORT_ID<br>			, MOUN_LOC_NUM<br>			, PORT_NUM<br>			, OTX_NUM<br>			, CRE_DTM<br>		) values (<br>			$getCcellId()<br>			, $getEquipPortId()<br>			, $getMounLocNum()<br>			, $getPortNum()<br>			, $getOtxNum()<br>			, $getCreDtm() <br>
*/
public final String INSERT_FX_TMP_OIV10171 = "INSERT_FX_TMP_OIV10171";

/**
* para : $getCcellId(), $getEquipId(), $getCcellNum(), $getOperTpoCd()<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into OIV10170 (<br>			CCELL_ID<br>			, AUDIT_ID<br>			, EQUIP_ID<br>			, CCELL_NUM<br>			, OPER_TPO_CD<br>		) values (<br>			$getCcellId()<br>			, 'MICM'<br>			, $getEquipId()<br>			, $getCcellNum()<br>			, $getOperTpoCd()<br>		) <br>
*/
public final String INSERT_OIV10170 = "INSERT_OIV10170";

/**
* para : $getCcellId(), $getEquipPortId(), $getMounLocNum(), $getPortNum(), $getOtxNum(), $getCreDtm()<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into OIV10171 (<br>			CCELL_ID<br>			, EQUIP_PORT_ID<br>			, AUDIT_ID<br>			, MOUN_LOC_NUM<br>			, PORT_NUM<br>			, OTX_NUM<br>			, CRE_DTM<br>		) values (<br>			$getCcellId()<br>			, $getEquipPortId()<br>			, 'MICM'<br>			, $getMounLocNum()<br>			, $getPortNum()<br>			, $getOtxNum()<br>			, $getCreDtm()<br>		) <br>
*/
public final String INSERT_OIV10171 = "INSERT_OIV10171";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * merge into OIV10170 A<br>			using FX_TMP_OIV10170 B<br>			on ( B.CCELL_ID = A.CCELL_ID )<br>			when matched then<br>				update set <br>					A.EQUIP_ID				= B.EQUIP_ID<br>					, A.CCELL_NUM			= B.CCELL_NUM<br>					, A.OPER_TPO_CD			= B.OPER_TPO_CD<br>					, A.AUDIT_ID			= 'MICM'<br>					, A.AUDIT_DTM			= sysdate<br>			when not matched then<br>				insert ( <br>					CCELL_ID<br>					, EQUIP_ID<br>					, CCELL_NUM<br>					, OPER_TPO_CD<br>					, AUDIT_ID<br>				) values (<br>					B.CCELL_ID<br>					, B.EQUIP_ID<br>					, B.CCELL_NUM<br>					, B.OPER_TPO_CD<br>					, 'MICM'<br>				) <br>
*/
public final String MERGE_OIV10170 = "MERGE_OIV10170";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * merge into OIV10171 A<br>			using FX_TMP_OIV10171 B<br>			on ( B.CCELL_ID = A.CCELL_ID and B.MOUN_LOC_NUM = A.MOUN_LOC_NUM and B.PORT_NUM = A.PORT_NUM )<br>			when matched then<br>				update set <br>					A.EQUIP_PORT_ID		= B.EQUIP_PORT_ID<br>					, A.OTX_NUM			= B.OTX_NUM<br>					, A.CRE_DTM			= B.CRE_DTM<br>					, A.AUDIT_ID		= 'MICM'<br>					, A.AUDIT_DTM		= sysdate<br>			when not matched then<br>				insert ( <br>					CCELL_ID<br>					, EQUIP_PORT_ID<br>					, MOUN_LOC_NUM<br>					, PORT_NUM<br>					, OTX_NUM<br>					, CRE_DTM<br>					, AUDIT_ID<br>				) values (<br>					B.CCELL_ID<br>					, B.EQUIP_PORT_ID<br>					, B.MOUN_LOC_NUM<br>					, B.PORT_NUM<br>					, B.OTX_NUM<br>					, B.CRE_DTM<br>					, 'MICM'<br>				) <br>
*/
public final String MERGE_OIV10171 = "MERGE_OIV10171";

/**
* para : $equipMgmtNum<br>
* result : EQUIP_ID__EQUIP_MGMT_NUM=com.skb.adams.cm.model.EQUIP_ID<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * select 	EQUIP_ID<br>				, EQUIP_MGMT_NUM<br>		from	 OIV10100<br>		where 	EQUIP_MGMT_NUM = $equipMgmtNum <br>
*/
public final String SELECT_EQUIP_ID__BY_EQUIP_MGMT_NUM = "SELECT_EQUIP_ID__BY_EQUIP_MGMT_NUM";

/**
* para : <br>
* result : EQUIP_ID__EQUIP_MGMT_NUM=com.skb.adams.cm.model.EQUIP_ID<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * select 	EQUIP_ID<br>				, EQUIP_MGMT_NUM<br>		from	 OIV10100<br>		where 	equip_mgmt_num is not null<br>		and   	equip_typ_cl_cd = '50' <br>
*/
public final String SELECT_EQUIP_ID__EQUIP_MGMT_NUM = "SELECT_EQUIP_ID__EQUIP_MGMT_NUM";

/**
* para : <br>
* result : RESULT_MAX_CELLID=java.lang.Long<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * select to_number(max(substr(ccell_id, 3))) <br>		from OIV10170 <br>
*/
public final String SELECT_MAX_CELLID = "SELECT_MAX_CELLID";

/**
* para : <br>
* result : RESULT_OIV10170=com.skb.adams.cm.model.OIV10170<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * select	CCELL_ID<br>				, EQUIP_ID<br>				, CCELL_NUM<br>		from	OIV10170 <br>
*/
public final String SELECT_OIV10170 = "SELECT_OIV10170";

/**
* para : <br>
* result : RESULT_OIV10171=com.skb.adams.cm.model.OIV10171<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * select	P.CCELL_ID<br>			, P.EQUIP_PORT_ID<br>			, P.MOUN_LOC_NUM<br>			, P.PORT_NUM<br>			, C.EQUIP_ID<br>		from	OIV10171 P<br>				, OIV10170 C<br>		where	P.CCELL_ID = C.CCELL_ID <br>
*/
public final String SELECT_OIV10171 = "SELECT_OIV10171";

/**
* para : <br>
* result : RESULT_OIV10400=com.skb.adams.cm.model.OIV10400<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * select	A.EQUIP_ID<br>				, A.EQUIP_PORT_ID<br>				, A.MOUN_LOC_NUM<br>				, A.PORT_NUM<br>		from	OIV10400 A<br>				, OIV10100 B<br>		where 	A.equip_id = B.equip_id<br>		and		B.equip_mgmt_num is not null<br>		and   	B.equip_typ_cl_cd = '50' <br>
*/
public final String SELECT_OIV10400 = "SELECT_OIV10400";

/**
* para : <br>
* result : RESULT_ZOSS_HFC_CELL=com.skb.adams.cm.model.ZOSS_HFC_CELL<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * select	AUDIT_DTM<br>			, AUDIT_ID<br>			, CCELL_ID<br>			, CCELL_NUM<br>			, CMTS_SET_TPO_CD<br>			, EQUIP_MGMT_NUM<br>			, MEMO<br>			, OTX_NUM<br>			, REF_INFO<br>			, REP_SLOT_YN<br>			, SLOT_PORT_GRP_NUM<br>			, SLOT_REF_INFO<br>		from	ZOSS_HFC_CELL<br>		order by EQUIP_MGMT_NUM<br>				, CCELL_NUM<br>				, CCELL_ID <br>
*/
public final String SELECT_ZOSS_HFC_CELL = "SELECT_ZOSS_HFC_CELL";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * truncate table FX_TMP_OIV10170 reuse storage <br>
*/
public final String TRUNCATE_FX_TMP_OIV10170 = "TRUNCATE_FX_TMP_OIV10170";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * truncate table FX_TMP_OIV10171 reuse storage <br>
*/
public final String TRUNCATE_FX_TMP_OIV10171 = "TRUNCATE_FX_TMP_OIV10171";

public final String DELETE_OIV10171_REMOVED = "DELETE_OIV10171_REMOVED";
public final String DELETE_OIV10170_REMOVED = "DELETE_OIV10170_REMOVED";

}