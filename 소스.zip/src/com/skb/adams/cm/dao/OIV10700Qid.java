package com.skb.adams.cm.dao;

/**
* File : oiv10700.xml<br>
* @since 20171220173516
* @author subkjh 
*
*/


public class OIV10700Qid { 

/** 쿼리 모임 화일명. oiv10700.xml*/
public static final String QUERY_XML_FILE = "oiv10700.xml";

public OIV10700Qid() { 
} 
/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into OIV10700<br>				( EQP_MDL_CD         ' 단말모델코드 ' 	<br>				, AUDIT_ID           ' 최종변경자ID ' 	<br>				, WEQP_MDL_CD        ' 유선단말모델코드 ' 	<br>				, WEQP_MDL_NM        ' 유선단말모델명 ' 	<br>				, MFACT_MDL_NM       ' 제조사모델명 ' 	<br>				, WEQP_MNUFACT_CO_CD ' 유선단말제조업체코드 ' 	<br>				, WEQP_LCL_CD        ' 유선단말대분류코드 ' 	<br>				, WEQP_MCL_CD        ' 유선단말중분류코드 ' 	<br>				, WEQP_MDL_TYP_CD    ' 유선단말모델종류코드 ' 	<br>				, TOT_PORT_CNT       ' 총포트개수 ' 	<br>				, USE_YN             ' 사용여부 ' 	<br>				, SWING_CRE_YN       ' SWING생성여부 ' <br>		)	<br>		select	  <br>		  		SMDL.WEQP_MDL_CD            as EQP_MDL_CD<br>		        , SMDL.AUDIT_ID             as AUDIT_ID<br>		        , SMDL.WEQP_MDL_CD          as WEQP_MDL_CD<br>		        , SMDL.WEQP_MDL_NM          as WEQP_MDL_NM<br>		        , SMDL.MFACT_MDL_NM         as MFACT_MDL_NM<br>		        , SMDL.WEQP_MNUFACT_CO_CD	as WEQP_MNUFACT_CO_CD<br>		        , '0000'                    as WEQP_LCL_CD<br>		        , '0000'                    as WEQP_MCL_CD<br>		        , '00'                      as WEQP_MDL_TYP_CD<br>		        , SMDL.TOT_PORT_CNT         as TOT_PORT_CNT<br>		        , SMDL.USE_YN               as USE_YN<br>		        , 'Y'                       as SWING_CRE_YN<br>		from	OIV10709 SMDL<br>				left join OIV10700 MDL on MDL.WEQP_MDL_CD = SMDL.WEQP_MDL_CD<br>		where	MDL.WEQP_MDL_CD is null <br>
*/
public final String INSERT_OIV10700 = "INSERT_OIV10700";

public final String UPDATE_OIV10700 = "UPDATE_OIV10700";

}