package com.skb.adams.cm.dao;

/**
* File : oiv1010x.xml<br>
* @since 20180413141101
* @author subkjh 
*
*/


public class OIV1010xQid { 

/** 쿼리 모임 화일명. oiv1010x.xml*/
public static final String QUERY_XML_FILE = "oiv1010x.xml";

public OIV1010xQid() { 
} 
/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * delete<br>		from	OIV10115 A<br>		where	A.EQUIP_ID in (<br>					select	EQP.EQUIP_ID<br>					from	OIV10100 EQP<br>					where	A.EQUIP_ID = EQP.EQUIP_ID<br>					and		EQP.DEL_YN = 'Y'<br>		) <br>
*/
public final String DELETE_OIV10115__DEL_Y = "DELETE_OIV10115__DEL_Y";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into OIV10100 (<br>		          AUDIT_DTM<br>		        , AUDIT_ID<br>		        , DEL_YN<br>		        , EQUIP_ID<br>		        , EQUIP_IP_ADDR<br>		        , EQUIP_MDL_CD<br>		        , EQUIP_MGMT_NUM<br>		        , EQUIP_NM<br>		        , EQUIP_OWN_YN<br>		        , EQUIP_SET_LOC_DESC<br>		        , EQUIP_SYS_NM<br>		        , EQUIP_SYS_SET_DT<br>		        , EQUIP_TID_VAL<br>		        , EQUIP_TYP_CL_CD<br>		        , EQUIP_USG_CD<br>		        , EXCHG_TPO_CD<br>		        , JURIS_TPO_CD<br>		        , LINK_EQUIP_ID<br>		        , M_OBJ_YN<br>		        , MEMO<br>		        , MGMT_TPO_CD<br>		        , NMS_EQUIP_CD<br>		        , PING_M_OBJ_YN<br>		        , POLLING_M_OBJ_YN<br>		        , SW_VER_INFO<br>		        , TPO_CD<br> 		)<br>		select<br>		          T.AUDIT_DTM                               as AUDIT_DTM<br>		        , 'MICM'                              		as AUDIT_ID<br>		        , 'N'                                      	as DEL_YN<br>		        , C.EQUIP_ID 								as EQUIP_ID<br>		        , T.IP_ADDR                                 as EQUIP_IP_ADDR<br>		        , ( SELECT MAX(A.EQUIP_MDL_CD) FROM OIV10213 A WHERE A.CLCT_TBL_NM = 'ZOSS_EQUIP_MDL' AND A.CLCT_EQUIP_MDL_CD = T.EQUIP_CD ) as EQUIP_MDL_CD<br>		        , T.EQUIP_MGMT_NUM                          as EQUIP_MGMT_NUM<br>		        , T.EQUIP_SYS_NM                            as EQUIP_NM<br>		        , nvl(T.EQUIP_OWN_YN, 'Y')                  as EQUIP_OWN_YN<br>		        , T.EQUIP_SET_LOC_DESC                      as EQUIP_SET_LOC_DESC<br>		        , T.EQUIP_SYS_NM                            as EQUIP_SYS_NM<br>		        , T.EQUIP_SYS_SET_DT                        as EQUIP_SYS_SET_DT<br>		        , T.EQUIP_TID_VAL                           as EQUIP_TID_VAL<br>		        , T.EQUIP_TYP_CL_CD                         as EQUIP_TYP_CL_CD<br>		        , '0000'                                   	as EQUIP_USG_CD<br>		        , nvl(T.EXCHG_TPO_CD, 'NULL')				as EXCHG_TPO_CD<br>		        , nvl(T.JURIS_TPO_CD, 'NULL')				as JURIS_TPO_CD<br>		        , ( SELECT MAX(A.EQUIP_ID) FROM OIV10107 A WHERE A.CLCT_NMS_CL_CD = '000' AND A.EQUIP_MGMT_NUM = T.LINK_EQUIP_MGMT_NUM ) as LINK_EQUIP_ID<br>		        , 'N'                                      	as M_OBJ_YN<br>		        , T.MEMO                                    as MEMO<br>		        , nvl(T.MGMT_TPO_CD, T.TPO_CD)				as MGMT_TPO_CD<br>		        , nvl(T.NMS_EQUIP_CD, 'NULL')				as NMS_EQUIP_CD<br>		        , 'N'                                      	as PING_M_OBJ_YN<br>		        , 'N'                                      	as POLLING_M_OBJ_YN<br>		        , T.EQUIP_VER_NUM                           as SW_VER_INFO<br>		        , T.TPO_CD                              	as TPO_CD<br>		from 	<br>				OIV10112 T<br>				left join OIV10100 B<br>					on 	B.EQUIP_MGMT_NUM = T.EQUIP_MGMT_NUM<br>				left join OIV10107 C<br>					on 	C.CLCT_NMS_CL_CD = '000' <br>					and	C.EQUIP_MGMT_NUM = T.EQUIP_MGMT_NUM <br>		where	B.EQUIP_MGMT_NUM is null<br>		and		C.EQUIP_ID is not null <br>
*/
public final String INSERT_OIV10100 = "INSERT_OIV10100";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * INSERT<br>		  INTO OIV10107<br>		      ( EQUIP_MAPP_SER_NUM ' 장비매핑일련번호 ' 	<br>		      , AUDIT_ID           ' 최종변경자ID ' 	<br>		      , EQUIP_ID           ' 장비ID ' 	<br>		      , EQUIP_MGMT_NUM     ' 장비관리번호 ' 	<br>		      , EQUIP_TID_VAL      ' 장비TID값 ' 	<br>		      , CLCT_NMS_CL_CD     ' 수집NMS구분코드 ' 	<br>		      , CLCT_EQUIP_NUM     ' 수집장비번호 ' 	<br>		      , CLCT_TBL_NM        ' 수집테이블명 ' 	<br>		      , CLCT_EQUIP_IP_ADDR ' 수집장비IP주소 ' 	<br>		      , CLCT_EQUIP_NM      ' 수집장비명 ' 	<br>		)<br>		select<br>				 ( OIV10107_S1.nextval ) 	as EQUIP_MAPP_SER_NUM<br>				, 'MICM'					as AUDIT_ID<br>		        , ( 'S' || lpad(OIV10100_S1.nextval, 11, '0') ) <br>		        							as EQUIP_ID<br>		        , T.EQUIP_MGMT_NUM          as EQUIP_MGMT_NUM<br>		        , T.EQUIP_TID_VAL           as EQUIP_TID_VAL<br>		        , '000'                     as CLCT_NMS_CL_CD<br>		        , T.EQUIP_MGMT_NUM          as CLCT_EQUIP_NUM<br>		        , 'ZOSS_EQUIP_SYS'          as CLCT_TBL_NM<br>		        , T.IP_ADDR                 as CLCT_EQUIP_IP_ADDR<br>		        , T.EQUIP_SYS_NM            as CLCT_EQUIP_NM<br>		from	OIV10112 T<br>				, (<br>					select	A.EQUIP_MGMT_NUM<br>					from 	OIV10112 A<br>							left join OIV10107 B<br>									on 	B.CLCT_NMS_CL_CD = '000' <br>									and	B.EQUIP_MGMT_NUM = A.EQUIP_MGMT_NUM <br>					where	B.EQUIP_ID is null				<br>				) A<br>		where	T.EQUIP_MGMT_NUM = A.EQUIP_MGMT_NUM <br>
*/
public final String INSERT_OIV10107 = "INSERT_OIV10107";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * INSERT<br>		  INTO OIV10107<br>		      ( EQUIP_MAPP_SER_NUM ' 장비매핑일련번호 ' 	<br>		      , AUDIT_ID           ' 최종변경자ID ' 	<br>		      , EQUIP_ID           ' 장비ID ' 	<br>		      , EQUIP_MGMT_NUM     ' 장비관리번호 ' 	<br>		      , EQUIP_TID_VAL      ' 장비TID값 ' 	<br>		      , CLCT_NMS_CL_CD     ' 수집NMS구분코드 ' 	<br>		      , CLCT_EQUIP_NUM     ' 수집장비번호 ' 	<br>		      , CLCT_TBL_NM        ' 수집테이블명 ' 	<br>		      , CLCT_EQUIP_IP_ADDR ' 수집장비IP주소 ' 	<br>		      , CLCT_EQUIP_NM      ' 수집장비명 ' 	<br>		)<br>		select<br>				 ( OIV10107_S1.nextval ) 	as EQUIP_MAPP_SER_NUM<br>				, 'MICM'					as AUDIT_ID<br>		        , A.EQUIP_ID				as EQUIP_ID<br>		        , T.EQUIP_MGMT_NUM          as EQUIP_MGMT_NUM<br>		        , T.EQUIP_TID_VAL           as EQUIP_TID_VAL<br>		        , '000'                     as CLCT_NMS_CL_CD<br>		        , T.EQUIP_MGMT_NUM          as CLCT_EQUIP_NUM<br>		        , 'ZOSS_EQUIP_SYS'          as CLCT_TBL_NM<br>		        , T.IP_ADDR                 as CLCT_EQUIP_IP_ADDR<br>		        , T.EQUIP_SYS_NM            as CLCT_EQUIP_NM<br>		from	OIV10112 T<br>				, (<br>					select	EQUIP_MGMT_NUM<br>							, max(EQUIP_ID)		as EQUIP_ID<br>					from 	OIV10107<br>					where	EQUIP_MGMT_NUM in ( <br>								select	A.EQUIP_MGMT_NUM<br>								from 	OIV10112 A<br>											left join OIV10107 B on	B.CLCT_NMS_CL_CD = '000' and B.EQUIP_MGMT_NUM = A.EQUIP_MGMT_NUM <br>								where	B.EQUIP_ID is null<br>							)	<br>					group by EQUIP_MGMT_NUM		<br>				) A<br>		where	T.EQUIP_MGMT_NUM = A.EQUIP_MGMT_NUM <br>
*/
public final String INSERT_OIV10107_ASIS = "INSERT_OIV10107_ASIS";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into OIV10115 (<br>		      	EQUIP_ID<br>		      	, NET_CL_CD<br>		      	, AUDIT_ID<br>		)<br>		select	<br>				EQP.EQUIP_ID<br>				, CD.SUP_COMM_CD_VAL	as NET_CL_CD<br>				, 'MICM'				as AUDIT_ID<br>		from	<br>				OIV10100 EQP<br>					left join OIV10115 B on EQP.EQUIP_ID = B.EQUIP_ID<br>				, OCO20101 CD<br>		where	B.EQUIP_ID is null<br>		and		EQP.DEL_YN = 'N'<br>		and		CD.COMM_CD = 'EQUIP_USG_CD' <br>		and		EQP.EQUIP_USG_CD = CD.COMM_CD_VAL<br>		and		CD.SUP_COMM_CD_VAL in ( '01', '03', '04', '99' ) <br>
*/
public final String INSERT_OIV10115__EQUIP_USG = "INSERT_OIV10115__EQUIP_USG";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into OIV10115 (<br>		      	EQUIP_ID<br>		      	, NET_CL_CD<br>		      	, AUDIT_ID<br>		)<br>		select	<br>				EQP.EQUIP_ID<br>				, CD.SUP_COMM_CD_VAL	as NET_CL_CD<br>				, 'MICM'				as AUDIT_ID<br>		from	<br>				OIV10100 EQP<br>					left join OIV10115 B on EQP.EQUIP_ID = B.EQUIP_ID<br>				, OCO20101 CD<br>				, OIV10200 MODEL<br>		where	<br>				EQP.DEL_YN = 'N'<br>		and		EQP.EQUIP_MDL_CD = MODEL.EQUIP_MDL_CD<br>		and		CD.COMM_CD = 'EQUIP_MDL_TYP_CD' <br>		and		CD.COMM_CD_VAL = MODEL.EQUIP_MDL_TYP_CD<br>		and 	CD.SUP_COMM_CD_VAL in ( '01', '03', '04', '99' )<br>		and		B.EQUIP_ID is null <br>
*/
public final String INSERT_OIV10115__MODEL_TYPE = "INSERT_OIV10115__MODEL_TYPE";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * MERGE INTO OIV10115 A<br>	USING (	SELECT	EQUIP_ID<br>	FROM	OIV10100<br>	WHERE	1=1<br>	AND		EQUIP_TYP_CL_CD IN ('01','02','03','04','05','13','24','25','26','27','49','51','80','81','82','83','84','85','86','89','90','91','92','94','98')<br>	) B<br>	ON	(	A.EQUIP_ID = B.EQUIP_ID <br>	AND A.NET_CL_CD = '02'<br>	)<br>	WHEN NOT MATCHED THEN<br>	INSERT	( NET_CL_CD<br>	,EQUIP_ID<br>	,AUDIT_ID<br>	,AUDIT_DTM<br>	) <br>	VALUES	( '02'<br>	,B.EQUIP_ID<br>	,'MICM'<br>	,SYSDATE<br>	)
*/
public final String INSERT_OIV10115__EQUIP_TYP_CL_CD = "INSERT_OIV10115__EQUIP_TYP_CL_CD";

/**
* para : <br>
* 
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * update OIV10100 EQP set<br>				EQP.DEL_YN = 'N'<br>				, EQP.AUDIT_DTM = sysdate<br>				, EQP.AUDIT_ID = 'MICM'<br>		where 	EQP.DEL_YN = 'Y'<br>		and		exists ( 		<br>					select	1				<br>					from	OIV10112 SEQP<br>					where	EQP.EQUIP_MGMT_NUM = SEQP.EQUIP_MGMT_NUM<br>				) <br>
*/
public final String UPDATE_OIV10100_DELYN__BY_SWING_FOUND = "UPDATE_OIV10100_DELYN__BY_SWING_FOUND";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * update OIV10100 EQP set<br>				EQP.DEL_YN = 'Y'<br>				, EQP.AUDIT_DTM = sysdate<br>				, EQP.AUDIT_ID = 'MICM'<br>		where 	EQP.DEL_YN = 'N'<br>		and		EQP.EQUIP_MGMT_NUM is not null<br>		and		not exists ( 		<br>					select	1				<br>					from	OIV10112 SEQP<br>					where	EQP.EQUIP_MGMT_NUM = SEQP.EQUIP_MGMT_NUM<br>				) <br>
*/
public final String UPDATE_OIV10100_DELYN__BY_SWING_NOT_FOUND = "UPDATE_OIV10100_DELYN__BY_SWING_NOT_FOUND";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * update OIV10100 EQP set<br>				EQP.DEL_YN = 'N'<br>				, EQP.AUDIT_DTM = sysdate<br>				, EQP.AUDIT_ID = 'MICM'<br>		where 	EQP.DEL_YN = 'Y'<br>		and		exists ( <br>					select	1<br>					from	OIV10981 TEQP<br>					where	EQP.EQUIP_MGMT_NUM is null<br>					and		EQP.EQUIP_TID_VAL = TEQP.TEAMS_EQUIP_TID_VAL<br>				) <br>
*/
public final String UPDATE_OIV10100_DELYN__BY_TEAMS = "UPDATE_OIV10100_DELYN__BY_TEAMS";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * 
*/
public final String INSERT_TBL_SUBMIT_QUEUE = "INSERT_TBL_SUBMIT_QUEUE";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * 
*/
public final String MERGE_OIV10100_EQUIP_ADDR_IP_BY__OIV10112 = "MERGE_OIV10100_EQUIP_ADDR_IP_BY__OIV10112";


/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * 
*/
public final String MERGE_OIV10100_AGW_EQUIP_IP_ADDR_BY__OIV10112 = "MERGE_OIV10100_AGW_EQUIP_IP_ADDR_BY__OIV10112";


/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * 
*/
public final String MERGE_OIV10100_EQUIP_MDL_CD_BY__OIV10112 = "MERGE_OIV10100_EQUIP_MDL_CD_BY__OIV10112";


/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * 
*/
public final String MERGE_OIV10011_IEQUIP_NET_CL_CD_BY__OIV10112 = "MERGE_OIV10011_IEQUIP_NET_CL_CD_BY__OIV10112";

public final String DELETE_OIV10115_FOMS = "DELETE_OIV10115_FOMS";

}