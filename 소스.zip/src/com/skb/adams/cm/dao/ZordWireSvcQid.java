package com.skb.adams.cm.dao;

public class ZordWireSvcQid {
	public static final String QUERY_XML_FILE = "zord_wire_svc.xml";
	
	public ZordWireSvcQid() {
		
	}
	
	public final String DROP_TABLE_FX_TMP_OES10300 = "DROP_TABLE_FX_TMP_OES10300";
	public final String CREATE_TABLE_FX_TMP_OES10300 = "CREATE_TABLE_FX_TMP_OES10300";
	public final String INSERT_FX_TMP_OES10300 = "INSERT_FX_TMP_OES10300";
	public final String SELECT_ZORD_WIRE_SVC = "SELECT_ZORD_WIRE_SVC";
	public final String MERGE_OES10300__BY_FX_TMP_OES10300 = "MERGE_OES10300__BY_FX_TMP_OES10300";
	public final String DELETE_OES10300__BY_FX_TMP_OES10300 = "DELETE_OES10300__BY_FX_TMP_OES10300";
	public final String MERGE_OMN50201_SVC_TECH_MTHD_CD__BY_OES10300 = "MERGE_OMN50201_SVC_TECH_MTHD_CD__BY_OES10300";
	public final String MERGE_OMN50201_NET_CL_CD__BY_OES10300 = "MERGE_OMN50201_NET_CL_CD__BY_OES10300";

}
