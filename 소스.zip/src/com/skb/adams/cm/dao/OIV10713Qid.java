package com.skb.adams.cm.dao;

/**
* File : oiv1071x.xml<br>
* @since 20180104091003
* @author subkjh 
*
*/


public class OIV10713Qid { 

/** 쿼리 모임 화일명. oiv1071x.xml*/
public static final String QUERY_XML_FILE = "oiv10713.xml";

public OIV10713Qid() { 
} 
/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * delete from OIV10713 <br>
*/
public final String DELETE_OIV10713 = "DELETE_OIV10713";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * delete from OIV10714 <br>
*/
public final String DELETE_OIV10714 = "DELETE_OIV10714";


/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into OIV10713 (<br>				EQUIP_ID<br>				, EQUIP_PORT_ID<br>				, CUST_CNT<br>				, DATA_SRC_INFO<br>				, AUDIT_ID<br>		)<br>		select <br>				LINK.ADRC_EQUIP_ID					as EQUIP_ID<br>				, LINK.ADRC_EQUIP_PORT_ID			as EQUIP_PORT_ID<br>				, count(distinct WEQP.CUST_NUM )	as CUST_CNT<br>				, 'CMTS'							as DATA_SRC_INFO<br>				, 'MICM'							as AUDIT_ID<br>		from 	<br>				OIV10402 WEQP<br>				, OIV10401 LINK<br>		where <br>				WEQP.LINK_ID = LINK.LINK_ID<br>		and		LINK.ADRC_CCELL_NUM is not null<br>		and		LINK.ADRC_EQUIP_PORT_ID is not null<br>		and		LINK.ADRC_EQUIP_PORT_ID != '-'<br>		group by <br>				LINK.ADRC_EQUIP_ID<br>				, LINK.ADRC_EQUIP_PORT_ID <br>
*/
public final String INSERT_OIV10713_CMTS = "INSERT_OIV10713_CMTS";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into OIV10713 (<br>				EQUIP_ID<br>				, EQUIP_PORT_ID<br>				, CUST_CNT<br>				, DATA_SRC_INFO<br>				, AUDIT_ID<br>		)<br>		select 	<br>				LINK.ZDRC_EQUIP_ID					as EQUIP_ID<br>				, LINK.ZDRC_EQUIP_PORT_ID			as EQUIP_PORT_ID<br>				, count(distinct WEQP.CUST_NUM )	as CUST_CNT<br>				, 'L2'								as DATA_SRC_INFO<br>				, 'MICM'							as AUDIT_ID<br>		from <br>				OIV10402 WEQP<br>				, OIV10401 LINK<br>		where <br>				WEQP.LINK_ID = LINK.LINK_ID<br>		and		LINK.ZDRC_EQUIP_ID is not null<br>		and		LINK.ZDRC_EQUIP_ID != '-'<br>		and		LINK.ZDRC_EQUIP_PORT_ID is not null<br>		and		LINK.ZDRC_EQUIP_PORT_ID != '-'<br>		and		LINK.ZDRC_EQUIP_ID != LINK.ADRC_EQUIP_ID<br>		group by <br>				LINK.ZDRC_EQUIP_ID<br>				, LINK.ZDRC_EQUIP_PORT_ID <br>
*/
public final String INSERT_OIV10713_L2 = "INSERT_OIV10713_L2";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into OIV10713 (<br>				EQUIP_ID<br>				, EQUIP_PORT_ID<br>				, CUST_CNT<br>				, DATA_SRC_INFO<br>				, AUDIT_ID<br>		)<br>		select <br>				LINK.ADRC_EQUIP_ID					as EQUIP_ID<br>				, LINK.ADRC_EQUIP_PORT_ID			as EQUIP_PORT_ID<br>				, count(distinct WEQP.CUST_NUM )	as CUST_CNT<br>				, 'L3'								as DATA_SRC_INFO<br>				, 'MICM'							as AUDIT_ID<br>		from 	<br>				OIV10402 WEQP<br>				, OIV10401 LINK<br>		where <br>				WEQP.LINK_ID = LINK.LINK_ID<br>		and		LINK.ADRC_CCELL_NUM is null<br>		and		LINK.ADRC_EQUIP_PORT_ID is not null<br>		and		LINK.ADRC_EQUIP_PORT_ID != '-'<br>		group by <br>				LINK.ADRC_EQUIP_ID<br>				, LINK.ADRC_EQUIP_PORT_ID <br>
*/
public final String INSERT_OIV10713_L3 = "INSERT_OIV10713_L3";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into OIV10714 (<br>				EQUIP_ID<br>				, EQUIP_PORT_ID<br>				, SVC_CD<br>				, SVC_CNT<br>				, DATA_SRC_INFO<br>				, AUDIT_ID<br>		)<br>		select <br>				T.EQUIP_ID					as EQUIP_ID<br>				, T.EQUIP_PORT_ID			as EQUIP_PORT_ID<br>				, nvl(SB.SVC_CD, '-')		as SVC_CD<br>				, count(1)					as SVC_CNT<br>				, 'L3'						as DATA_SRC_INFO<br>				, 'MICM'					as AUDIT_ID<br>		from  <br>				(<br>					select  distinct	<br>							LINK.ADRC_EQUIP_ID				as EQUIP_ID<br>							, LINK.ADRC_EQUIP_PORT_ID		as EQUIP_PORT_ID	<br>          					, SVC.SVC_MGMT_NUM				as SVC_MGMT_NUM<br>					from  	OIV10401 LINK<br>							, OIV10404 SVC<br>					where 	LINK.LINK_ID = SVC.LINK_ID<br>					and		LINK.ADRC_CCELL_NUM is not null<br>					and		LINK.ADRC_EQUIP_PORT_ID is not null<br>					and		LINK.ADRC_EQUIP_PORT_ID != '-'<br>				) T<br>					left join OES10200 SB on SB.SVC_MGMT_NUM = T.SVC_MGMT_NUM<br>		group by <br>				T.EQUIP_ID<br>				, T.EQUIP_PORT_ID<br>				, SB.SVC_CD <br>
*/
public final String INSERT_OIV10714_CMTS = "INSERT_OIV10714_CMTS";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into OIV10714 (<br>				EQUIP_ID<br>				, EQUIP_PORT_ID<br>				, SVC_CD<br>				, SVC_CNT<br>				, DATA_SRC_INFO<br>				, AUDIT_ID<br>		)<br>		select <br>				T.EQUIP_ID					as EQUIP_ID<br>				, T.EQUIP_PORT_ID			as EQUIP_PORT_ID<br>				, nvl(SB.SVC_CD, '-')		as SVC_CD<br>				, count(1)					as SVC_CNT<br>				, 'L2'						as DATA_SRC_INFO<br>				, 'MICM'					as AUDIT_ID<br>		from  <br>				(<br>					select  distinct	<br>							LINK.ZDRC_EQUIP_ID				as EQUIP_ID<br>							, LINK.ZDRC_EQUIP_PORT_ID		as EQUIP_PORT_ID	<br>          					, SVC.SVC_MGMT_NUM				as SVC_MGMT_NUM<br>					from  	OIV10401 LINK<br>							, OIV10404 SVC<br>					where 	LINK.LINK_ID = SVC.LINK_ID<br>					and		LINK.ZDRC_EQUIP_ID != LINK.ADRC_EQUIP_ID<br>					and		LINK.ZDRC_EQUIP_ID is not null<br>					and		LINK.ZDRC_EQUIP_ID != '-'<br>					and		LINK.ZDRC_EQUIP_PORT_ID is not null<br>					and		LINK.ZDRC_EQUIP_PORT_ID != '-'<br>					<br>				) T<br>					left join OES10200 SB ' 서비스기본 ' <br>							on SB.SVC_MGMT_NUM = T.SVC_MGMT_NUM<br>		group by <br>				T.EQUIP_ID<br>				, T.EQUIP_PORT_ID<br>				, SB.SVC_CD <br>
*/
public final String INSERT_OIV10714_L2 = "INSERT_OIV10714_L2";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into OIV10714 (<br>				EQUIP_ID<br>				, EQUIP_PORT_ID<br>				, SVC_CD<br>				, SVC_CNT<br>				, DATA_SRC_INFO<br>				, AUDIT_ID<br>		)<br>		select <br>				T.EQUIP_ID					as EQUIP_ID<br>				, T.EQUIP_PORT_ID			as EQUIP_PORT_ID<br>				, nvl(SB.SVC_CD, '-')		as SVC_CD<br>				, count(1)					as SVC_CNT<br>				, 'L3'						as DATA_SRC_INFO<br>				, 'MICM'					as AUDIT_ID<br>		from  <br>				(<br>					select  distinct	<br>							LINK.ADRC_EQUIP_ID				as EQUIP_ID<br>							, LINK.ADRC_EQUIP_PORT_ID		as EQUIP_PORT_ID	<br>          					, SVC.SVC_MGMT_NUM				as SVC_MGMT_NUM<br>					from  	OIV10401 LINK<br>							, OIV10404 SVC<br>					where 	LINK.LINK_ID = SVC.LINK_ID<br>					and		LINK.ADRC_CCELL_NUM is null<br>					and		LINK.ADRC_EQUIP_PORT_ID is not null<br>					and		LINK.ADRC_EQUIP_PORT_ID != '-'<br>				) T<br>					left join OES10200 SB on SB.SVC_MGMT_NUM = T.SVC_MGMT_NUM<br>		group by <br>				T.EQUIP_ID<br>				, T.EQUIP_PORT_ID<br>				, SB.SVC_CD <br>
*/
public final String INSERT_OIV10714_L3 = "INSERT_OIV10714_L3";

public final String UPDATE_OCO30341 = "UPDATE_OCO30341";


}