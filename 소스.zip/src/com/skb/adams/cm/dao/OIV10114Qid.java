package com.skb.adams.cm.dao;

/**
* File : oiv10114.xml<br>
* @since 20171229163039
* @author subkjh 
*
*/


public class OIV10114Qid { 

/** 쿼리 모임 화일명. oiv10114.xml*/
public static final String QUERY_XML_FILE = "oiv10114.xml";

public OIV10114Qid() { 
} 
/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * delete <br>		from OIV10114<br>		where RGST_DT = to_char(sysdate, 'YYYYMMDD') <br>
*/
public final String DELETE_OIV10114 = "DELETE_OIV10114";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * delete <br>		from OIV10117<br>		where RGST_DT = to_char(sysdate, 'YYYYMMDD') <br>
*/
public final String DELETE_OIV10117 = "DELETE_OIV10117";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * INSERT<br>		  INTO OIV10114<br>		      ( RGST_DT           ' 등록일자 ' 	<br>		      , TPO_CD            ' 국사코드 ' 	<br>		      , PRV_SHRR_MFACT_NM ' 사설공유기제조사명 ' 	<br>		      , WEQP_QTY          ' 유선단말수량 ' <br>		      , EQP_MEDIA_CD      ' 단말매체코드 ' 	<br>		      , LINK_MTHD_CD      ' 연결방식코드 ' 	<br>		      , AUDIT_ID          ' 최종변경자ID ' 	<br>		)	<br>		select <br>				to_char(sysdate, 'YYYYMMDD')	as RGST_DT      	' 등록일자 ' 	<br>				, WL.TPO_CD		 				as TPO_CD      		' 국사코드 ' 	<br>				, nvl(T.PRV_SHRR_MFACT_NM, 'NULL')<br>												as PRV_SHRR_MFACT_NM	<br>				, count(1)						as WEQP_QTY<br>				, '03'							as EQP_MEDIA_CD<br>				, 'N'							as LINK_MTHD_CD<br>				, 'MICM'						as AUDIT_ID<br>		from 	OIV10821 T<br>				, OIV10800 W<br>				, OIV10402 WL<br>		where	T.PRV_SHRR_LINK_CL_CD = '1'<br>		and		W.MAC_ADDR_VAL = T.WEQP_MAC_ADDR<br>		and   	WL.WEQP_MGMT_NUM = W.WEQP_MGMT_NUM<br>		and 	exists ( select 1 from OIV10401 LK where LK.LINK_ID = WL.LINK_ID and LK.ADRC_CCELL_NUM is null)		<br>		group by WL.TPO_CD<br>				, T.PRV_SHRR_MFACT_NM <br>
*/
public final String INSERT_OIV10114__01_FTTX = "INSERT_OIV10114__01_FTTX";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * INSERT<br>		  INTO OIV10114<br>		      ( RGST_DT           ' 등록일자 ' 	<br>		      , TPO_CD            ' 국사코드 ' 	<br>		      , PRV_SHRR_MFACT_NM ' 사설공유기제조사명 ' 	<br>		      , WEQP_QTY          ' 유선단말수량 ' <br>		      , EQP_MEDIA_CD      ' 단말매체코드 ' 	<br>		      , LINK_MTHD_CD      ' 연결방식코드 ' 	<br>		      , AUDIT_ID          ' 최종변경자ID ' 	<br>		)	<br>		select <br>				to_char(sysdate, 'YYYYMMDD')	as RGST_DT      	' 등록일자 ' 	<br>				, WL.TPO_CD		 				as TPO_CD      		' 국사코드 ' 	<br>				, nvl(T.PRV_SHRR_MFACT_NM, 'NULL')<br>												as PRV_SHRR_MFACT_NM	<br>				, count(1)						as WEQP_QTY<br>				, '04'							as EQP_MEDIA_CD<br>				, 'N'							as LINK_MTHD_CD<br>				, 'MICM'						as AUDIT_ID<br>		from 	OIV10821 T<br>				, OIV10800 W<br>				, OIV10402 WL<br>		where	T.PRV_SHRR_LINK_CL_CD = '1'<br>		and		W.MAC_ADDR_VAL = T.WEQP_MAC_ADDR<br>		and   	WL.WEQP_MGMT_NUM = W.WEQP_MGMT_NUM<br>		and 	exists ( select 1 from OIV10401 LK where LK.LINK_ID = WL.LINK_ID and LK.ADRC_CCELL_NUM is not null)<br>		<br>		group by WL.TPO_CD<br>				, T.PRV_SHRR_MFACT_NM <br>
*/
public final String INSERT_OIV10114__01_HFC = "INSERT_OIV10114__01_HFC";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * INSERT<br>		  INTO OIV10114<br>		      ( RGST_DT           ' 등록일자 ' 	<br>		      , TPO_CD            ' 국사코드 ' 	<br>		      , PRV_SHRR_MFACT_NM ' 사설공유기제조사명 ' 	<br>		      , WEQP_QTY          ' 유선단말수량 ' <br>		      , EQP_MEDIA_CD      ' 단말매체코드 ' 	<br>		      , LINK_MTHD_CD      ' 연결방식코드 ' 	<br>		      , AUDIT_ID          ' 최종변경자ID ' 	<br>		)	<br>		select <br>				to_char(sysdate, 'YYYYMMDD')	as RGST_DT      	' 등록일자 ' 	<br>				, WL.TPO_CD		 				as TPO_CD      		' 국사코드 ' 	<br>				, nvl(T.PRV_SHRR_MFACT_NM, 'NULL')<br>												as PRV_SHRR_MFACT_NM	<br>				, count(1)						as WEQP_QTY<br>				, '03'							as EQP_MEDIA_CD<br>				, 'A'							as LINK_MTHD_CD<br>				, 'MICM'						as AUDIT_ID<br>		from 	OIV10821 T<br>				, OIV10800 W<br>				, OIV10402 WL<br>		where	T.PRV_SHRR_LINK_CL_CD = '2'<br>		and		W.MAC_ADDR_VAL = T.WEQP_MAC_ADDR<br>		and   	WL.WEQP_MGMT_NUM = W.WEQP_MGMT_NUM<br>		and 	exists ( select 1 from OIV10401 LK where LK.LINK_ID = WL.LINK_ID and LK.ADRC_CCELL_NUM is null)<br>		<br>		group by WL.TPO_CD<br>				, T.PRV_SHRR_MFACT_NM <br>
*/
public final String INSERT_OIV10114__02_FTTX = "INSERT_OIV10114__02_FTTX";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * INSERT<br>		  INTO OIV10114<br>		      ( RGST_DT           ' 등록일자 ' 	<br>		      , TPO_CD            ' 국사코드 ' 	<br>		      , PRV_SHRR_MFACT_NM ' 사설공유기제조사명 ' 	<br>		      , WEQP_QTY          ' 유선단말수량 ' <br>		      , EQP_MEDIA_CD      ' 단말매체코드 ' 	<br>		      , LINK_MTHD_CD      ' 연결방식코드 ' 	<br>		      , AUDIT_ID          ' 최종변경자ID ' 	<br>		)	<br>		select <br>				to_char(sysdate, 'YYYYMMDD')	as RGST_DT      	' 등록일자 ' 	<br>				, WL.TPO_CD		 				as TPO_CD      		' 국사코드 ' 	<br>				, nvl(T.PRV_SHRR_MFACT_NM, 'NULL')<br>												as PRV_SHRR_MFACT_NM	<br>				, count(1)						as WEQP_QTY<br>				, '04'							as EQP_MEDIA_CD<br>				, 'A'							as LINK_MTHD_CD<br>				, 'MICM'						as AUDIT_ID<br>		from 	OIV10821 T<br>				, OIV10800 W<br>				, OIV10402 WL<br>		where	T.PRV_SHRR_LINK_CL_CD = '2'<br>		and		W.MAC_ADDR_VAL = T.WEQP_MAC_ADDR<br>		and   	WL.WEQP_MGMT_NUM = W.WEQP_MGMT_NUM<br>		and 	exists ( select 1 from OIV10401 LK where LK.LINK_ID = WL.LINK_ID and LK.ADRC_CCELL_NUM is not null)<br>		group by WL.TPO_CD<br>				, T.PRV_SHRR_MFACT_NM <br>
*/
public final String INSERT_OIV10114__02_HFC = "INSERT_OIV10114__02_HFC";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * INSERT<br>		  INTO OIV10117<br>		      ( RGST_DT           ' 등록일자 ' 	<br>		      , ORG_ID            ' 국사코드 ' 	<br>		      , PRV_SHRR_MFACT_NM ' 사설공유기제조사명 ' 	<br>		      , WEQP_QTY          ' 유선단말수량 ' <br>		      , EQP_MEDIA_CD      ' 단말매체코드 ' 	<br>		      , LINK_MTHD_CD      ' 연결방식코드 ' 	<br>		      , AUDIT_ID          ' 최종변경자ID ' 	<br>		)	<br>		select <br>				to_char(sysdate, 'YYYYMMDD')	as RGST_DT      	' 등록일자 ' 	<br>				, WL.HPY_CNTR_ORG_ID			as ORG_ID      		' 국사코드 ' 	<br>				, nvl(T.PRV_SHRR_MFACT_NM, 'NULL')<br>												as PRV_SHRR_MFACT_NM	<br>				, count(1)						as WEQP_QTY<br>				, '03'							as EQP_MEDIA_CD<br>				, 'N'							as LINK_MTHD_CD<br>				, 'MICM'						as AUDIT_ID<br>		from 	OIV10821 T<br>				, OIV10800 W<br>				, OIV10402 WL<br>		where	T.PRV_SHRR_LINK_CL_CD = '1'<br>		and		W.MAC_ADDR_VAL = T.WEQP_MAC_ADDR<br>		and   	WL.WEQP_MGMT_NUM = W.WEQP_MGMT_NUM<br>		and 	exists ( select 1 from OIV10401 LK where LK.LINK_ID = WL.LINK_ID and LK.ADRC_CCELL_NUM is null)		<br>		group by WL.HPY_CNTR_ORG_ID<br>				, T.PRV_SHRR_MFACT_NM <br>
*/
public final String INSERT_OIV10117__01_FTTX = "INSERT_OIV10117__01_FTTX";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * INSERT<br>		  INTO OIV10117<br>		      ( RGST_DT           ' 등록일자 ' 	<br>		      , ORG_ID            ' 국사코드 ' 	<br>		      , PRV_SHRR_MFACT_NM ' 사설공유기제조사명 ' 	<br>		      , WEQP_QTY          ' 유선단말수량 ' <br>		      , EQP_MEDIA_CD      ' 단말매체코드 ' 	<br>		      , LINK_MTHD_CD      ' 연결방식코드 ' 	<br>		      , AUDIT_ID          ' 최종변경자ID ' 	<br>		)	<br>		select <br>				to_char(sysdate, 'YYYYMMDD')	as RGST_DT      	' 등록일자 ' 	<br>				, WL.HPY_CNTR_ORG_ID		 	as ORG_ID      		' 국사코드 ' 	<br>				, nvl(T.PRV_SHRR_MFACT_NM, 'NULL')<br>												as PRV_SHRR_MFACT_NM	<br>				, count(1)						as WEQP_QTY<br>				, '04'							as EQP_MEDIA_CD<br>				, 'N'							as LINK_MTHD_CD<br>				, 'MICM'						as AUDIT_ID<br>		from 	OIV10821 T<br>				, OIV10800 W<br>				, OIV10402 WL<br>		where	T.PRV_SHRR_LINK_CL_CD = '1'<br>		and		W.MAC_ADDR_VAL = T.WEQP_MAC_ADDR<br>		and   	WL.WEQP_MGMT_NUM = W.WEQP_MGMT_NUM<br>		and 	exists ( select 1 from OIV10401 LK where LK.LINK_ID = WL.LINK_ID and LK.ADRC_CCELL_NUM is not null)<br>		<br>		group by WL.HPY_CNTR_ORG_ID<br>				, T.PRV_SHRR_MFACT_NM <br>
*/
public final String INSERT_OIV10117__01_HFC = "INSERT_OIV10117__01_HFC";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * INSERT<br>		  INTO OIV10117<br>		      ( RGST_DT           ' 등록일자 ' 	<br>		      , ORG_ID            ' 국사코드 ' 	<br>		      , PRV_SHRR_MFACT_NM ' 사설공유기제조사명 ' 	<br>		      , WEQP_QTY          ' 유선단말수량 ' <br>		      , EQP_MEDIA_CD      ' 단말매체코드 ' 	<br>		      , LINK_MTHD_CD      ' 연결방식코드 ' 	<br>		      , AUDIT_ID          ' 최종변경자ID ' 	<br>		)	<br>		select <br>				to_char(sysdate, 'YYYYMMDD')	as RGST_DT      	' 등록일자 ' 	<br>				, WL.HPY_CNTR_ORG_ID		 	as ORG_ID<br>				, nvl(T.PRV_SHRR_MFACT_NM, 'NULL')<br>												as PRV_SHRR_MFACT_NM	<br>				, count(1)						as WEQP_QTY<br>				, '03'							as EQP_MEDIA_CD<br>				, 'A'							as LINK_MTHD_CD<br>				, 'MICM'						as AUDIT_ID<br>		from 	OIV10821 T<br>				, OIV10800 W<br>				, OIV10402 WL<br>		where	T.PRV_SHRR_LINK_CL_CD = '2'<br>		and		W.MAC_ADDR_VAL = T.WEQP_MAC_ADDR<br>		and   	WL.WEQP_MGMT_NUM = W.WEQP_MGMT_NUM<br>		and 	exists ( select 1 from OIV10401 LK where LK.LINK_ID = WL.LINK_ID and LK.ADRC_CCELL_NUM is null)<br>		<br>		group by WL.HPY_CNTR_ORG_ID<br>				, T.PRV_SHRR_MFACT_NM <br>
*/
public final String INSERT_OIV10117__02_FTTX = "INSERT_OIV10117__02_FTTX";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * INSERT<br>		  INTO OIV10117<br>		      ( RGST_DT           ' 등록일자 ' 	<br>		      , ORG_ID            ' 국사코드 ' 	<br>		      , PRV_SHRR_MFACT_NM ' 사설공유기제조사명 ' 	<br>		      , WEQP_QTY          ' 유선단말수량 ' <br>		      , EQP_MEDIA_CD      ' 단말매체코드 ' 	<br>		      , LINK_MTHD_CD      ' 연결방식코드 ' 	<br>		      , AUDIT_ID          ' 최종변경자ID ' 	<br>		)	<br>		select <br>				to_char(sysdate, 'YYYYMMDD')	as RGST_DT      	' 등록일자 ' 	<br>				, WL.HPY_CNTR_ORG_ID		 	as ORG_ID<br>				, nvl(T.PRV_SHRR_MFACT_NM, 'NULL')<br>												as PRV_SHRR_MFACT_NM	<br>				, count(1)						as WEQP_QTY<br>				, '04'							as EQP_MEDIA_CD<br>				, 'A'							as LINK_MTHD_CD<br>				, 'MICM'						as AUDIT_ID<br>		from 	OIV10821 T<br>				, OIV10800 W<br>				, OIV10402 WL<br>		where	T.PRV_SHRR_LINK_CL_CD = '2'<br>		and		W.MAC_ADDR_VAL = T.WEQP_MAC_ADDR<br>		and   	WL.WEQP_MGMT_NUM = W.WEQP_MGMT_NUM<br>		and 	exists ( select 1 from OIV10401 LK where LK.LINK_ID = WL.LINK_ID and LK.ADRC_CCELL_NUM is not null)<br>		group by WL.HPY_CNTR_ORG_ID<br>				, T.PRV_SHRR_MFACT_NM <br>
*/
public final String INSERT_OIV10117__02_HFC = "INSERT_OIV10117__02_HFC";

}