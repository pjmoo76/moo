package com.skb.adams.cm.dao;

/**
* File : oiv10100_update.xml<br>
* @since 20171219164911
* @author subkjh 
*
*/


public class OIV10100UpdateQid { 

/** 쿼리 모임 화일명. oiv10100_update.xml*/
public static final String QUERY_XML_FILE = "oiv10100_update.xml";

public OIV10100UpdateQid() { 
} 


/**
* para : <br>
* result : RESULT_OIV10100=com.skb.adams.cm.model.OIV10100<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * select	T.EQUIP_ID<br>				, T.EQUIP_MDL_CD<br>		        , T.EQUIP_MGMT_NUM<br>		        , T.EQUIP_NM<br>		        , T.EQUIP_OWN_YN<br>		        , T.EQUIP_SET_LOC_DESC<br>		        , T.EQUIP_SYS_SET_DT<br>		        , T.EQUIP_TID_VAL<br>		        , T.EQUIP_TYP_CL_CD<br>		        , T.EXCHG_TPO_CD<br>		        , T.JURIS_TPO_CD<br>		        , T.LINK_EQUIP_ID<br>		        , T.MEMO<br>		        , T.MGMT_TPO_CD<br>		        , T.TPO_CD<br>		from	OIV10100 T<br>				, ( select<br>					        ( SELECT MAX(A.EQUIP_MDL_CD) FROM OIV10213 A WHERE A.CLCT_TBL_NM = 'ZOSS_EQUIP_MDL' AND A.CLCT_EQUIP_MDL_CD = EQUIP_CD ) as EQUIP_MDL_CD<br>					        , EQUIP_MGMT_NUM                           as EQUIP_MGMT_NUM<br>					        , EQUIP_SYS_NM                             as EQUIP_NM<br>					        , nvl(EQUIP_OWN_YN, 'Y')                   as EQUIP_OWN_YN<br>					        , EQUIP_SET_LOC_DESC                       as EQUIP_SET_LOC_DESC<br>					        , EQUIP_SYS_SET_DT                         as EQUIP_SYS_SET_DT<br>					        , EQUIP_TID_VAL                            as EQUIP_TID_VAL<br>					        , EQUIP_TYP_CL_CD                          as EQUIP_TYP_CL_CD<br>					        , EXCHG_TPO_CD                             as EXCHG_TPO_CD<br>					        , JURIS_TPO_CD                             as JURIS_TPO_CD<br>					        , ( SELECT MAX(A.EQUIP_ID) FROM OIV10107 A WHERE A.CLCT_TBL_NM = 'ZOSS_EQUIP_SYS' AND A.EQUIP_MGMT_NUM = LINK_EQUIP_MGMT_NUM ) as LINK_EQUIP_ID<br>					        , MEMO                                     as MEMO<br>					        , nvl(MGMT_TPO_CD, ( select MGMT_TPO_CD from OIV10300 where TPO_CD = T.TPO_CD) )                            as MGMT_TPO_CD<br>					        , TPO_CD                                   as TPO_CD<br>					from 	OIV10112 T<br>			<br>					minus<br>					<br>					select<br>					        EQUIP_MDL_CD<br>					        , EQUIP_MGMT_NUM<br>					        , EQUIP_NM<br>					        , EQUIP_OWN_YN<br>					        , EQUIP_SET_LOC_DESC<br>					        , EQUIP_SYS_SET_DT<br>					        , EQUIP_TID_VAL<br>					        , EQUIP_TYP_CL_CD<br>					        , EXCHG_TPO_CD<br>					        , JURIS_TPO_CD<br>					        , LINK_EQUIP_ID<br>					        , MEMO<br>					        , MGMT_TPO_CD<br>					        , TPO_CD<br>					from	OIV10100<br>				) A<br>		where	T.EQUIP_MGMT_NUM = A.EQUIP_MGMT_NUM <br>
*/
public final String SELECT_OIV10100 = "SELECT_OIV10100";

/**
* para : <br>
* result : RESULT_OIV10100=com.skb.adams.cm.model.OIV10100<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * select *<br>		from ( <br>			select	0 as EQUIP_ID<br>					, ( SELECT MAX(A.EQUIP_MDL_CD) FROM OIV10213 A WHERE A.CLCT_TBL_NM = 'ZOSS_EQUIP_MDL' AND A.CLCT_EQUIP_MDL_CD = T.EQUIP_CD ) as EQUIP_MDL_CD<br>			        , T.EQUIP_MGMT_NUM                           as EQUIP_MGMT_NUM<br>			        , T.EQUIP_SYS_NM                             as EQUIP_NM<br>			        , nvl(T.EQUIP_OWN_YN, 'Y')                   as EQUIP_OWN_YN<br>			        , T.EQUIP_SET_LOC_DESC                       as EQUIP_SET_LOC_DESC<br>			        , T.EQUIP_SYS_SET_DT                         as EQUIP_SYS_SET_DT<br>			        , T.EQUIP_TID_VAL                            as EQUIP_TID_VAL<br>			        , T.EQUIP_TYP_CL_CD                          as EQUIP_TYP_CL_CD<br>			        , nvl(T.EXCHG_TPO_CD, 'NULL')                as EXCHG_TPO_CD<br>			        , nvl(T.JURIS_TPO_CD, 'NULL')                as JURIS_TPO_CD<br>			        , ( SELECT MAX(A.EQUIP_ID) FROM OIV10107 A WHERE A.CLCT_TBL_NM = 'ZOSS_EQUIP_SYS' AND A.EQUIP_MGMT_NUM = T.LINK_EQUIP_MGMT_NUM ) as LINK_EQUIP_ID<br>			        , T.MEMO                                     as MEMO<br>			        , nvl ( nvl(T.MGMT_TPO_CD, ( select TPO.MGMT_TPO_CD from OIV10300 TPO where TPO.TPO_CD = T.TPO_CD) ), 'NULL' )                            as MGMT_TPO_CD<br>			        , T.TPO_CD                                   as TPO_CD<br>			from 	OIV10112 T<br>					, ( select<br>						        ( SELECT MAX(A.EQUIP_MDL_CD) FROM OIV10213 A WHERE A.CLCT_TBL_NM = 'ZOSS_EQUIP_MDL' AND A.CLCT_EQUIP_MDL_CD = EQUIP_CD ) as EQUIP_MDL_CD<br>						        , EQUIP_MGMT_NUM                           as EQUIP_MGMT_NUM<br>						        , EQUIP_SYS_NM                             as EQUIP_NM<br>						        , nvl(EQUIP_OWN_YN, 'Y')                   as EQUIP_OWN_YN<br>						        , EQUIP_SET_LOC_DESC                       as EQUIP_SET_LOC_DESC<br>						        , EQUIP_SYS_SET_DT                         as EQUIP_SYS_SET_DT<br>						        , EQUIP_TID_VAL                            as EQUIP_TID_VAL<br>						        , EQUIP_TYP_CL_CD                          as EQUIP_TYP_CL_CD<br>						        , EXCHG_TPO_CD                             as EXCHG_TPO_CD<br>						        , JURIS_TPO_CD                             as JURIS_TPO_CD<br>						        , ( SELECT MAX(A.EQUIP_ID) FROM OIV10107 A WHERE A.CLCT_TBL_NM = 'ZOSS_EQUIP_SYS' AND A.EQUIP_MGMT_NUM = LINK_EQUIP_MGMT_NUM ) as LINK_EQUIP_ID<br>						        , MEMO                                     as MEMO<br>						        , nvl ( nvl(T.MGMT_TPO_CD, ( select TPO.MGMT_TPO_CD from OIV10300 TPO where TPO.TPO_CD = T.TPO_CD) ), T.TPO_CD )                            as MGMT_TPO_CD<br>						        , TPO_CD                                   as TPO_CD<br>						from 	OIV10112 T<br>				<br>						minus<br>						<br>						select<br>						        EQUIP_MDL_CD<br>						        , EQUIP_MGMT_NUM<br>						        , EQUIP_NM<br>						        , EQUIP_OWN_YN<br>						        , EQUIP_SET_LOC_DESC<br>						        , EQUIP_SYS_SET_DT<br>						        , EQUIP_TID_VAL<br>						        , EQUIP_TYP_CL_CD<br>						        , EXCHG_TPO_CD<br>						        , JURIS_TPO_CD<br>						        , LINK_EQUIP_ID<br>						        , MEMO<br>						        , MGMT_TPO_CD<br>						        , TPO_CD<br>						from	OIV10100<br>					) A<br>			where	T.EQUIP_MGMT_NUM = A.EQUIP_MGMT_NUM<br>		) C<br>		where C.EQUIP_MDL_CD is not null <br>
*/
public final String SELECT_OIV10112 = "SELECT_OIV10112";

/**
* para : $getEquipNm(), $isEquipOwnYn(), $getEquipSetLocDesc(), $getEquipSysSetDt(), $getEquipTidVal(), $getEquipTypClCd(), $getExchgTpoCd(), $getJurisTpoCd(), $getLinkEquipId(), $getMemo(), $getMgmtTpoCd(), $getTpoCd(), $getEquipId()<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * update OIV10100 set<br>			AUDIT_DTM = SYSDATE<br>			, AUDIT_ID = 'CM-BATCH'<br>			, EQUIP_NM = $getEquipNm()<br>			, EQUIP_OWN_YN = $isEquipOwnYn()<br>			, EQUIP_SET_LOC_DESC = $getEquipSetLocDesc()<br>			, EQUIP_SYS_SET_DT = $getEquipSysSetDt()<br>			, EQUIP_TID_VAL = $getEquipTidVal()<br>			, EQUIP_TYP_CL_CD = $getEquipTypClCd()<br>			, EXCHG_TPO_CD = $getExchgTpoCd()<br>			, JURIS_TPO_CD = $getJurisTpoCd()<br>			, LINK_EQUIP_ID = $getLinkEquipId()<br>			, MEMO = $getMemo()<br>			, MGMT_TPO_CD = $getMgmtTpoCd()<br>			, TPO_CD = $getTpoCd()<br>		where	EQUIP_ID = $getEquipId() <br>
*/
public final String UPDATE_OIV10100__BY_EQUIPID = "UPDATE_OIV10100__BY_EQUIPID";

}