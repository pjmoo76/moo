package com.skb.adams.cm.dao;

/**
* File : oiv10110.xml<br>
* @since 20171219164911
* @author subkjh 
*
*/


public class OIV10110Qid { 

/** 쿼리 모임 화일명. oiv10110.xml*/
public static final String QUERY_XML_FILE = "oiv10110.xml";

public OIV10110Qid() { 
} 
/**
* para : $getEquipId(), $getEquipAttrCd(), $getChgDtm(), $getAuditId(), $getAttrVal(), $getBfAttrVal(), $getEquipAttrBatHstSerNum(), $getEquipAttrChgClCd()<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into OIV10110 (<br>			EQUIP_ID<br>			, EQUIP_ATTR_CD<br>			, CHG_DTM<br>			, AUDIT_ID<br>			, ATTR_VAL<br>			, BF_ATTR_VAL<br>			, EQUIP_ATTR_BAT_HST_SER_NUM<br>			, EQUIP_ATTR_CHG_CL_CD<br>		) values (<br>			$getEquipId()<br>			, $getEquipAttrCd()<br>			, $getChgDtm()<br>			, $getAuditId()<br>			, $getAttrVal()<br>			, $getBfAttrVal()<br>			, $getEquipAttrBatHstSerNum()<br>			, $getEquipAttrChgClCd()<br>		) <br>
*/
public final String INSERT_OIV10110 = "INSERT_OIV10110";

/**
* para : $equipMdlCd<br>
* result : RESULT_STRING=java.lang.String<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * select	EQUIP_MDL_NM<br>		from 	OIV10200<br>		where	EQUIP_MDL_CD = $equipMdlCd <br>
*/
public final String SELECT_EQUIP_MDL_CD = "SELECT_EQUIP_MDL_CD";

/**
* para : <br>
* result : RESULT_OIV10901=com.skb.adams.cm.model.OIV10901<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * select	EQUIP_ATTR_CD<br>				, COL_NM<br>				, ATTR_NM<br>				, TBL_NM<br>				, ATTR_GRP_NM<br>		from	OIV10901 <br>
*/
public final String SELECT_OIV10901 = "SELECT_OIV10901";

/**
* para : $tpoCd<br>
* result : RESULT_STRING=java.lang.String<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * select	TPO_NM<br>		from 	OIV10300<br>		where	TPO_CD = $tpoCd <br>
*/
public final String SELECT_TPO_CD = "SELECT_TPO_CD";

}