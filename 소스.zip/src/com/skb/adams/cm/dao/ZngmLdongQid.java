package com.skb.adams.cm.dao;

public class ZngmLdongQid {
	public static final String QUERY_XML_FILE = "zngm_ldong.xml";
	
	public ZngmLdongQid() {
		
	}
	
	public final String DROP_TABLE_FX_TMP_OES30300 = "DROP_TABLE_FX_TMP_OES30300";
	public final String CREATE_TABLE_FX_TMP_OES30300 = "CREATE_TABLE_FX_TMP_OES30300";
	public final String INSERT_FX_TMP_OES30300 = "INSERT_FX_TMP_OES30300";
	public final String SELECT_ZNGM_LDONG = "SELECT_ZNGM_LDONG";
	public final String MERGE_OES30300__BY_FX_TMP_OES30300 = "MERGE_OES30300__BY_FX_TMP_OES30300";
	public final String DELETE_OES30300__BY_FX_TMP_OES30300 = "DELETE_OES30300__BY_FX_TMP_OES30300";

}
