package com.skb.adams.cm.dao;

/**
* File : oiv10113.xml<br>
* @since 20171121134019
* @author subkjh 
*
*/


public class OIV10113Qid { 

/** 쿼리 모임 화일명. oiv10113.xml*/
public static final String QUERY_XML_FILE = "oiv10113.xml";

public OIV10113Qid() { 
} 
/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * delete <br>		from OIV10113 <br>		where RGST_DT = to_char(sysdate, 'YYYYMMDD') <br>
*/
public final String DELETE_OIV10113 = "DELETE_OIV10113";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
*/
public final String INSERT_OIV10113 = "INSERT_OIV10113";

}