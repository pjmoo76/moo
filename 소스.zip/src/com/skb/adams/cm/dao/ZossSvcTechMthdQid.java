package com.skb.adams.cm.dao;

public class ZossSvcTechMthdQid {
	public static final String QUERY_XML_FILE = "zoss_svc_tech_mthd.xml";
	
	public ZossSvcTechMthdQid() {
		
	}
	
	public final String DROP_TABLE_FX_TMP_OES10400 = "DROP_TABLE_FX_TMP_OES10400";
	public final String CREATE_TABLE_FX_TMP_OES10400 = "CREATE_TABLE_FX_TMP_OES10400";
	public final String INSERT_FX_TMP_OES10400 = "INSERT_FX_TMP_OES10400";
	public final String SELECT_ZOSS_SVC_TECH_MTHD = "SELECT_ZOSS_SVC_TECH_MTHD";
	public final String MERGE_OES10400__BY_FX_TMP_OES10400 = "MERGE_OES10400__BY_FX_TMP_OES10400";
	public final String DELETE_OES10400__BY_FX_TMP_OES10400 = "DELETE_OES10400__BY_FX_TMP_OES10400";

}
