package com.skb.adams.cm.dao;

/**
* File : oiv1071x.xml<br>
* @since 20180104091003
* @author subkjh 
*
*/


public class OIV1071xQid { 

/** 쿼리 모임 화일명. oiv1071x.xml*/
public static final String QUERY_XML_FILE = "oiv1071x.xml";

public OIV1071xQid() { 
} 
/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * delete from OIV10711 <br>
*/
public final String DELETE_OIV10711 = "DELETE_OIV10711";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * delete from OIV10712 <br>
*/
public final String DELETE_OIV10712 = "DELETE_OIV10712";


/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * delete from OIV10715 <br>
*/
public final String DELETE_OIV10715 = "DELETE_OIV10715";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * delete from OIV10716 <br>
*/
public final String DELETE_OIV10716 = "DELETE_OIV10716";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into OIV10711 (<br>				EQUIP_ID<br>				, CUST_CNT<br>				, DATA_SRC_INFO<br>				, AUDIT_ID<br>		)<br>		select <br>				LINK.ADRC_EQUIP_ID						as EQUIP_ID<br>				, count(distinct WEQP.CUST_NUM )		as CUST_CNT<br>				, 'CMTS'								as DATA_SRC_INFO<br>				, 'MICM'								as AUDIT_ID<br>		from 	<br>				OIV10402 WEQP<br>				, OIV10401 LINK<br>		where 	LINK.ADRC_CCELL_NUM is not null<br>		and		WEQP.LINK_ID = LINK.LINK_ID<br>		group by <br>				LINK.ADRC_EQUIP_ID<br><br>		union<br>		<br>		select <br>				LINK.ADRC_EQUIP_ID						as EQUIP_ID<br>				, count(distinct WEQP.CUST_NUM )		as CUST_CNT<br>				, 'L3'									as DATA_SRC_INFO<br>				, 'MICM'								as AUDIT_ID<br>		from 	<br>				OIV10402 WEQP<br>				, OIV10401 LINK<br>		where 	LINK.ADRC_CCELL_NUM is null<br>		and		WEQP.LINK_ID = LINK.LINK_ID<br>		group by <br>				LINK.ADRC_EQUIP_ID<br><br>		union<br>		<br>		select <br>				LINK.ZDRC_EQUIP_ID						as EQUIP_ID<br>				, count(distinct WEQP.CUST_NUM )		as CUST_CNT<br>				, 'L2'									as DATA_SRC_INFO<br>				, 'MICM'								as AUDIT_ID<br>		from 	<br>				OIV10402 WEQP<br>				, OIV10401 LINK<br>		where 	<br>				WEQP.LINK_ID = LINK.LINK_ID<br>		and		LINK.ZDRC_EQUIP_ID is not null<br>		and		LINK.ZDRC_EQUIP_ID != '-'<br>		and		LINK.ZDRC_EQUIP_ID != LINK.ADRC_EQUIP_ID<br>		group by <br>				LINK.ZDRC_EQUIP_ID <br>
*/
public final String INSERT_OIV10711_CMTS = "INSERT_OIV10711_CMTS";
public final String INSERT_OIV10711_L3 = "INSERT_OIV10711_L3";
public final String INSERT_OIV10711_L2 = "INSERT_OIV10711_L2";
public final String INSERT_OIV10711_DHCP = "INSERT_OIV10711_DHCP";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into OIV10712 (<br>				EQUIP_ID<br>				, SVC_CD<br>				, SVC_CNT<br>				, DATA_SRC_INFO<br>				, AUDIT_ID<br>		)<br>		select 	T.EQUIP_ID			as EQUIP_ID<br>				, nvl(SB.SVC_CD, '-')		as SVC_CD<br>				, count(1)					as SVC_CNT<br>				, 'CMTS'					as DATA_SRC_INFO<br>				, 'MICM'					as AUDIT_ID<br>		from  	(<br>					select  distinct	LINK.ADRC_EQUIP_ID			as EQUIP_ID<br>          					, SVC.SVC_MGMT_NUM<br>					from  	OIV10401 LINK<br>							, OIV10404 SVC<br>					where 	LINK.LINK_ID = SVC.LINK_ID<br>					and		LINK.ADRC_CCELL_NUM is not null<br>				) T<br>					left join OES10200 SB on SB.SVC_MGMT_NUM = T.SVC_MGMT_NUM<br>		group by T.EQUIP_ID<br>				, SB.SVC_CD <br>
*/
public final String INSERT_OIV10712_CMTS = "INSERT_OIV10712_CMTS";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into OIV10712 (<br>				EQUIP_ID<br>				, SVC_CD<br>				, SVC_CNT<br>				, DATA_SRC_INFO<br>				, AUDIT_ID<br>		)<br>		select 	T.EQUIP_ID			as EQUIP_ID<br>				, nvl(SB.SVC_CD, '-')		as SVC_CD<br>				, count(1)					as SVC_CNT<br>				, 'L2'						as DATA_SRC_INFO<br>				, 'MICM'					as AUDIT_ID<br>		from  	(<br>					select  distinct	LINK.ZDRC_EQUIP_ID			as EQUIP_ID<br>          					, SVC.SVC_MGMT_NUM<br>					from  	OIV10401 LINK<br>							, OIV10404 SVC<br>					where 	LINK.LINK_ID = SVC.LINK_ID<br>					and		LINK.ZDRC_EQUIP_ID is not null<br>					and		LINK.ZDRC_EQUIP_ID != '-'<br>					and		LINK.ZDRC_EQUIP_ID != LINK.ADRC_EQUIP_ID<br>				) T<br>					left join OES10200 SB on SB.SVC_MGMT_NUM = T.SVC_MGMT_NUM<br>		group by T.EQUIP_ID<br>				, SB.SVC_CD <br>
*/
public final String INSERT_OIV10712_L2 = "INSERT_OIV10712_L2";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into OIV10712 (<br>				EQUIP_ID<br>				, SVC_CD<br>				, SVC_CNT<br>				, DATA_SRC_INFO<br>				, AUDIT_ID<br>		)<br>		select 	T.EQUIP_ID					as EQUIP_ID<br>				, nvl(SB.SVC_CD, '-')		as SVC_CD<br>				, count(1)					as SVC_CNT<br>				, 'L3'						as DATA_SRC_INFO<br>				, 'MICM'					as AUDIT_ID<br>		from  	(<br>					select  distinct	LINK.ADRC_EQUIP_ID			as EQUIP_ID<br>          					, SVC.SVC_MGMT_NUM<br>					from  	OIV10401 LINK<br>							, OIV10404 SVC<br>					where 	LINK.LINK_ID = SVC.LINK_ID<br>					and		LINK.ADRC_CCELL_NUM is null<br>				) T<br>					left join OES10200 SB on SB.SVC_MGMT_NUM = T.SVC_MGMT_NUM<br>		group by T.EQUIP_ID<br>				, SB.SVC_CD <br>
*/
public final String INSERT_OIV10712_L3 = "INSERT_OIV10712_L3";
public final String INSERT_OIV10712_DHCP = "INSERT_OIV10712_DHCP";


/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into OIV10715 (<br>				EQUIP_ID<br>				, CCELL_NUM<br>				, CUST_CNT<br>				, DATA_SRC_INFO<br>				, AUDIT_ID<br>		)<br>		select 	<br>				LINK.ADRC_EQUIP_ID					as EQUIP_ID<br>				, LINK.ADRC_CCELL_NUM				as CCELL_NUM<br>				, count(distinct WEQP.CUST_NUM )	as CUST_CNT<br>				, 'CMTS'							as DATA_SRC_INFO<br>				, 'MICM'							as AUDIT_ID<br>		from 	<br>				OIV10402 WEQP<br>				, OIV10401 LINK<br>		where <br>				WEQP.LINK_ID = LINK.LINK_ID<br>		and		LINK.ADRC_CCELL_NUM is not null<br>		group by <br>				LINK.ADRC_EQUIP_ID<br>				, LINK.ADRC_CCELL_NUM <br>
*/
public final String INSERT_OIV10715_CMTS = "INSERT_OIV10715_CMTS";
public final String INSERT_OIV10715_L3 = "INSERT_OIV10715_L3";


/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into OIV10716 (<br>				EQUIP_ID<br>				, CCELL_NUM<br>				, SVC_CD<br>				, SVC_CNT<br>				, DATA_SRC_INFO<br>				, AUDIT_ID<br>		)<br>		select <br>				T.EQUIP_ID					as EQUIP_ID<br>				, T.CCELL_NUM				as CCELL_NUM<br>				, nvl(SB.SVC_CD, '-')		as SVC_CD<br>				, count(1)					as SVC_CNT<br>				, 'CMTS'					as DATA_SRC_INFO<br>				, 'MICM'					as AUDIT_ID<br>		from  <br>				(<br>					select  distinct	<br>							LINK.ADRC_EQUIP_ID				as EQUIP_ID<br>							, LINK.ADRC_CCELL_NUM			as CCELL_NUM	<br>          					, SVC.SVC_MGMT_NUM				as SVC_MGMT_NUM<br>					from  	OIV10401 LINK<br>							, OIV10404 SVC<br>					where 	LINK.LINK_ID = SVC.LINK_ID<br>					and		LINK.ADRC_CCELL_NUM is not null<br>					<br>				) T<br>					left join OES10200 SB ' 서비스기본 ' <br>							on SB.SVC_MGMT_NUM = T.SVC_MGMT_NUM<br>		group by <br>				T.EQUIP_ID<br>				, T.CCELL_NUM<br>				, SB.SVC_CD <br>
*/
public final String INSERT_OIV10716_CMTS = "INSERT_OIV10716_CMTS";
public final String INSERT_OIV10716_L3 = "INSERT_OIV10716_L3";

public final String CHECK_E2E_COMPLETE = "CHECK_E2E_COMPLETE";

public final String SELECT_OCO30341 = "SELECT_OCO30341";

public final String INSERT_OCO30341 = "INSERT_OCO30341";

public final String UPDATE_OCO30341 = "UPDATE_OCO30341";

}