package com.skb.adams.cm.dao;

/**
* File : oiv1020x.xml<br>
* @since 20180104092241
* @author subkjh 
*
*/


public class OIV1020xQid { 

/** 쿼리 모임 화일명. oiv1020x.xml*/
public static final String QUERY_XML_FILE = "oiv1020x.xml";

public OIV1020xQid() { 
} 
/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into OIV10200 (<br>				  EQUIP_MDL_CD          ' 장비모델코드 ' 	<br>				, AUDIT_ID              ' 최종변경자ID ' 	<br>				, EQUIP_MFACT_CD        ' 장비제조사코드 ' 	<br>				, EQUIP_MDL_NM          ' 장비모델명 ' 	<br>				, EQUIP_MDL_TYP_CD      ' 장비모델종류코드 ' 	<br>				, EQUIP_TYP_CD          ' 장비종류코드 ' 	<br>				, EQUIP_MDL_DESC        ' 장비모델설명 ' 	<br>				, EQUIP_INTDC_YM        ' 장비도입년월 ' 	<br>				, CONS_ITM_MANL_RGST_YN ' 구성품수동등록여부 ' 	<br>				, SAME_CONN_ID_USE_YN   ' 동일접속ID사용여부 ' <br>		)<br>		select<br>		          MAP.EQUIP_MDL_CD			as EQUIP_MDL_CD<br>		        , 'MICM'					as AUDIT_ID<br>		        , SMDL.EQUIP_MFACT_CD       as EQUIP_MFACT_CD<br>		        , SMDL.EQUIP_MDL_NM         as EQUIP_MDL_NM<br>		        , '099'                 	as EQUIP_MDL_TYP_CD<br>		        , SMDL.EQUIP_TYP_CD         as EQUIP_TYP_CD<br>		        , SMDL.EQUIP_DTLS_DESC      as EQUIP_MDL_DESC<br>		        , SMDL.EQUIP_INTDC_YM       as EQUIP_INTDC_YM<br>		        , 'N'                   	as CONS_ITM_MANL_RGST_YN<br>		        , 'N'                   	as SAME_CONN_ID_USE_YN<br>        from	OIV10208 SMDL<br>        		, OIV10213 MAP<br>					left join OIV10200 MDL on MDL.EQUIP_MDL_CD = MAP.EQUIP_MDL_CD						<br>        where	MAP.CLCT_NMS_CL_CD = '000' <br>        and		SMDL.EQUIP_CD = MAP.CLCT_EQUIP_MDL_CD<br>        and		MDL.EQUIP_MDL_CD is null <br>
*/
public final String INSERT_OIV10200 = "INSERT_OIV10200";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into OIV10200 (<br>				  EQUIP_MDL_CD          ' 장비모델코드 ' 	<br>				, AUDIT_ID              ' 최종변경자ID ' 	<br>				, EQUIP_MFACT_CD        ' 장비제조사코드 ' 	<br>				, EQUIP_MDL_NM          ' 장비모델명 ' 	<br>				, EQUIP_MDL_TYP_CD      ' 장비모델종류코드 ' 	<br>				, EQUIP_TYP_CD          ' 장비종류코드 ' 	<br>				, EQUIP_MDL_DESC        ' 장비모델설명 ' 	<br>				, EQUIP_INTDC_YM        ' 장비도입년월 ' 	<br>				, CONS_ITM_MANL_RGST_YN ' 구성품수동등록여부 ' 	<br>				, SAME_CONN_ID_USE_YN   ' 동일접속ID사용여부 ' <br>		)<br>		select<br>		          MAP.EQUIP_MDL_CD			as EQUIP_MDL_CD<br>		        , 'MICM'					as AUDIT_ID<br>		        , SMDL.EQUIP_MFACT_CD       as EQUIP_MFACT_CD<br>		        , SMDL.EQUIP_MDL_NM         as EQUIP_MDL_NM<br>		        , M.EQUIP_MDL_TYP_CD       	as EQUIP_MDL_TYP_CD<br>		        , SMDL.EQUIP_TYP_CD         as EQUIP_TYP_CD<br>		        , SMDL.EQUIP_DTLS_DESC      as EQUIP_MDL_DESC<br>		        , SMDL.EQUIP_INTDC_YM       as EQUIP_INTDC_YM<br>		        , 'N'                   	as CONS_ITM_MANL_RGST_YN<br>		        , 'N'                   	as SAME_CONN_ID_USE_YN<br>        from	OIV10208 SMDL<br>        		, MICM_OIV10200 M<br>        		, OIV10213 MAP<br>					left join OIV10200 MDL on MDL.EQUIP_MDL_CD = MAP.EQUIP_MDL_CD						<br>        where	MAP.CLCT_NMS_CL_CD = '000' <br>        and		SMDL.EQUIP_CD = MAP.CLCT_EQUIP_MDL_CD<br>        and		M.EQUIP_CD = SMDL.EQUIP_CD <br>        and		MDL.EQUIP_MDL_CD is null <br>
*/
public final String INSERT_OIV10200__ADD = "INSERT_OIV10200__ADD";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * insert into OIV10200 (<br>				  EQUIP_MDL_CD          ' 장비모델코드 ' 	<br>				, AUDIT_ID              ' 최종변경자ID ' 	<br>				, EQUIP_MFACT_CD        ' 장비제조사코드 ' 	<br>				, EQUIP_MDL_NM          ' 장비모델명 ' 	<br>				, EQUIP_MDL_TYP_CD      ' 장비모델종류코드 ' 	<br>				, EQUIP_TYP_CD          ' 장비종류코드 ' 	<br>				, EQUIP_MDL_DESC        ' 장비모델설명 ' 	<br>				, EQUIP_INTDC_YM        ' 장비도입년월 ' 	<br>				, CONS_ITM_MANL_RGST_YN ' 구성품수동등록여부 ' 	<br>				, SAME_CONN_ID_USE_YN   ' 동일접속ID사용여부 ' <br>		)<br>		select<br>		          MAP.EQUIP_MDL_CD			as EQUIP_MDL_CD<br>		        , 'MICM'					as AUDIT_ID<br>		        , SMDL.EQUIP_MFACT_CD       as EQUIP_MFACT_CD<br>		        , SMDL.EQUIP_MDL_NM         as EQUIP_MDL_NM<br>		        , '099'                 	as EQUIP_MDL_TYP_CD<br>		        , SMDL.EQUIP_TYP_CD         as EQUIP_TYP_CD<br>		        , SMDL.EQUIP_DTLS_DESC      as EQUIP_MDL_DESC<br>		        , SMDL.EQUIP_INTDC_YM       as EQUIP_INTDC_YM<br>		        , 'N'                   	as CONS_ITM_MANL_RGST_YN<br>		        , 'N'                   	as SAME_CONN_ID_USE_YN<br>        from	OIV10208 SMDL<br>        		, OIV10213 MAP<br>					left join OIV10200 MDL on MDL.EQUIP_MDL_CD = MAP.EQUIP_MDL_CD						<br>        where	MAP.CLCT_NMS_CL_CD = '000' <br>        and		SMDL.EQUIP_CD = MAP.CLCT_EQUIP_MDL_CD<br>        and		MDL.EQUIP_MDL_CD is null <br>
*/
public final String INSERT_OIV10200__EXISTS_EQUIP = "INSERT_OIV10200__EXISTS_EQUIP";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * INSERT<br>		  INTO OIV10213<br>		      ( MDL_MAPP_SER_NUM  ' 모델매핑일련번호 ' 	<br>		      , AUDIT_ID          ' 최종변경자ID ' 	<br>		      , EQUIP_MDL_CD      ' 장비모델코드 ' 	<br>		      , CLCT_NMS_CL_CD    ' 수집NMS구분코드 ' 	<br>		      , CLCT_EQUIP_MDL_CD ' 수집장비모델코드 ' 	<br>		      , CLCT_EQUIP_MDL_NM ' 수집장비모델명 ' 	<br>		      , CLCT_EQUIP_TYP_CD ' 수집장비종류코드 ' 	<br>		      , CLCT_TBL_NM       ' 수집테이블명 '<br>		)<br>		select<br>          		OIV10213_S1.nextval 		as MDL_MAPP_SER_NUM<br>		        , 'MICM'   		            as AUDIT_ID<br>		        , MDL.EQUIP_CD              as EQUIP_MDL_CD<br>		        , '000'                     as CLCT_NMS_CL_CD<br>		        , MDL.EQUIP_CD              as CLCT_EQUIP_MDL_CD<br>		        , MDL.EQUIP_MDL_NM          as CLCT_EQUIP_MDL_NM<br>		        , MDL.EQUIP_TYP_CD          as CLCT_EQUIP_TYP_CD<br>		        , 'ZOSS_EQUIP_MDL'          as CLCT_TBL_NM<br>		from	OIV10208 MDL<br>					left join OIV10213 MM <br>						on MM.CLCT_NMS_CL_CD = '000' <br>						and CLCT_EQUIP_MDL_CD = MDL.EQUIP_CD<br>		where 	MDL.CONS_ITM_TYP_CD = '10'<br>		and 	MM.EQUIP_MDL_CD is null <br>
*/
public final String INSERT_OIV10213 = "INSERT_OIV10213";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * INSERT<br>		  INTO OIV10213<br>		      ( MDL_MAPP_SER_NUM  ' 모델매핑일련번호 ' 	<br>		      , AUDIT_ID          ' 최종변경자ID ' 	<br>		      , EQUIP_MDL_CD      ' 장비모델코드 ' 	<br>		      , CLCT_NMS_CL_CD    ' 수집NMS구분코드 ' 	<br>		      , CLCT_EQUIP_MDL_CD ' 수집장비모델코드 ' 	<br>		      , CLCT_EQUIP_MDL_NM ' 수집장비모델명 ' 	<br>		      , CLCT_EQUIP_TYP_CD ' 수집장비종류코드 ' 	<br>		      , CLCT_TBL_NM       ' 수집테이블명 '<br>		)<br>		select<br>          		OIV10213_S1.nextval 		as MDL_MAPP_SER_NUM<br>		        , 'MICM'   		            as AUDIT_ID<br>		        , MDL.EQUIP_CD              as EQUIP_MDL_CD<br>		        , '000'                     as CLCT_NMS_CL_CD<br>		        , MDL.EQUIP_CD              as CLCT_EQUIP_MDL_CD<br>		        , MDL.EQUIP_MDL_NM          as CLCT_EQUIP_MDL_NM<br>		        , MDL.EQUIP_TYP_CD          as CLCT_EQUIP_TYP_CD<br>		        , 'ZOSS_EQUIP_MDL'          as CLCT_TBL_NM<br>		from	MICM_OIV10200 M<br>				, OIV10208 MDL<br>					left join OIV10213 MM <br>						on MM.CLCT_NMS_CL_CD = '000' <br>						and CLCT_EQUIP_MDL_CD = MDL.EQUIP_CD<br>		where 	M.EQUIP_CD = MDL.EQUIP_CD<br>		and 	MM.EQUIP_MDL_CD is null <br>
*/
public final String INSERT_OIV10213__ADD = "INSERT_OIV10213__ADD";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * INSERT<br>		  INTO OIV10213<br>		      ( MDL_MAPP_SER_NUM  ' 모델매핑일련번호 ' 	<br>		      , AUDIT_ID          ' 최종변경자ID ' 	<br>		      , EQUIP_MDL_CD      ' 장비모델코드 ' 	<br>		      , CLCT_NMS_CL_CD    ' 수집NMS구분코드 ' 	<br>		      , CLCT_EQUIP_MDL_CD ' 수집장비모델코드 ' 	<br>		      , CLCT_EQUIP_MDL_NM ' 수집장비모델명 ' 	<br>		      , CLCT_EQUIP_TYP_CD ' 수집장비종류코드 ' 	<br>		      , CLCT_TBL_NM       ' 수집테이블명 '<br>		)<br>		select<br>          		OIV10213_S1.nextval 		as MDL_MAPP_SER_NUM<br>		        , 'MICM'   		            as AUDIT_ID<br>		        , EQUIP_CD              	as EQUIP_MDL_CD<br>		        , '000'                     as CLCT_NMS_CL_CD<br>		        , EQUIP_CD              	as CLCT_EQUIP_MDL_CD<br>		        , EQUIP_MDL_NM          	as CLCT_EQUIP_MDL_NM<br>		        , EQUIP_TYP_CD          	as CLCT_EQUIP_TYP_CD<br>		        , 'ZOSS_EQUIP_MDL'          as CLCT_TBL_NM<br>		from	OIV10208 M<br>		where	EQUIP_CD in (<br>					select 	EQUIP_CD<br>					from 	(<br>								select distinct EQP.EQUIP_CD<br>								from oiv10112 EQP<br>								    , oiv10208 MDL<br>								where EQP.EQUIP_CD = MDL.EQUIP_CD<br>							) M<br>					  			left join OIV10213 MDL on MDL.CLCT_NMS_CL_CD = '000' and MDL.CLCT_EQUIP_MDL_CD = M.EQUIP_CD<br>					where MDL.EQUIP_MDL_CD is nulL<br>				) <br>
*/
public final String INSERT_OIV10213__EXISTS_EQUIP = "INSERT_OIV10213__EXISTS_EQUIP";

}