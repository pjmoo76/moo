package com.skb.adams.cm.dao;

/**
* File : oiv10200_update.xml<br>
* @since 20171219144052
* @author subkjh 
*
*/


public class OIV10200UpdateQid { 

/** 쿼리 모임 화일명. oiv10200_update.xml*/
public static final String QUERY_XML_FILE = "oiv10200_update.xml";

public OIV10200UpdateQid() { 
} 
/**
* para : <br>
* result : RESULT_OIV10200=com.skb.adams.cm.model.OIV10200<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * select	EQUIP_MDL_CD<br>				, EQUIP_MFACT_CD<br>				, EQUIP_MDL_NM<br>				, EQUIP_TYP_CD<br>				, EQUIP_MDL_DESC<br>				, EQUIP_INTDC_YM<br>		from	OIV10200 <br>
*/
public final String SELECT_OIV10200 = "SELECT_OIV10200";

/**
* para : <br>
* result : RESULT_OIV10200=com.skb.adams.cm.model.OIV10200<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * select<br>		          MAP.EQUIP_MDL_CD			as EQUIP_MDL_CD<br>		        , SMDL.EQUIP_MFACT_CD       as EQUIP_MFACT_CD<br>		        , SMDL.EQUIP_MDL_NM         as EQUIP_MDL_NM<br>		        , SMDL.EQUIP_TYP_CD         as EQUIP_TYP_CD<br>		        , SMDL.EQUIP_DTLS_DESC      as EQUIP_MDL_DESC<br>		        , SMDL.EQUIP_INTDC_YM       as EQUIP_INTDC_YM<br>        from	OIV10208 SMDL<br>        		, OIV10213 MAP<br>        where	MAP.CLCT_NMS_CL_CD = '000' <br>        and		SMDL.EQUIP_CD = MAP.CLCT_EQUIP_MDL_CD <br>
*/
public final String SELECT_OIV10208 = "SELECT_OIV10208";

/**
* para : $getEquipMfactCd(), $getEquipMdlNm(), $getEquipTypCd(), $getEquipMdlDesc(), $getEquipIntdcYm(), $getEquipMdlCd()<br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * update OIV10200 set<br>				, AUDIT_ID = 'CM-BATCH'<br>				, AUDIT_DTM = SYSDATE<br>				, EQUIP_MFACT_CD = $getEquipMfactCd()<br>				, EQUIP_MDL_NM = $getEquipMdlNm()<br>				, EQUIP_TYP_CD = $getEquipTypCd()<br>				, EQUIP_MDL_DESC = $getEquipMdlDesc()<br>				, EQUIP_INTDC_YM = $getEquipIntdcYm()<br>		where 	EQUIP_MDL_CD = $getEquipMdlCd() <br>
*/
public final String UPDATE_OIV10200__BY_EQUIPMDLCD = "UPDATE_OIV10200__BY_EQUIPMDLCD";

}