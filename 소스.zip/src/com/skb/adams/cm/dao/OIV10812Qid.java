package com.skb.adams.cm.dao;

/**
* File : oiv10812.xml<br>
* @since 20171121145110
* @author subkjh 
*
*/


public class OIV10812Qid { 

/** 쿼리 모임 화일명. oiv10812.xml*/
public static final String QUERY_XML_FILE = "oiv10812.xml";

public OIV10812Qid() { 
} 
/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
 * delete <br>		from OIV10812 <br>		where RGST_DTM = to_char(sysdate, 'YYYYMMDDHH24MI') || '00' <br>
*/
public final String DELETE_OIV10812 = "DELETE_OIV10812";

/**
* para : <br>
* ---------------------------------------------------------------------------------- <br>
* database : null<br>
* sql <br><br>
*/
public final String INSERT_OIV10812 = "INSERT_OIV10812";

}