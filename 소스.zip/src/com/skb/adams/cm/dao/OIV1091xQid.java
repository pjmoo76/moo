package com.skb.adams.cm.dao;

public class OIV1091xQid {

	/** 쿼리 모임 화일명. oiv1091x.xml */
	public static final String QUERY_XML_FILE = "oiv1091x.xml";

	public OIV1091xQid() {
	}

	public final String DELETE_OIV10911 = "DELETE_OIV10911";
	public final String INSERT_OIV10911 = "INSERT_OIV10911";

	public final String DELETE_OIV10912 = "DELETE_OIV10912";
	public final String INSERT_OIV10912 = "INSERT_OIV10912";

	public final String DELETE_OIV10913 = "DELETE_OIV10913";
	public final String INSERT_OIV10913 = "INSERT_OIV10913";

	public final String DELETE_OIV10914 = "DELETE_OIV10914";
	public final String INSERT_OIV10914 = "INSERT_OIV10914";
}
