package com.skb.adams.cm;

public interface CmCode {

	/** 사설공유기연결구분코드 */
	public enum PrvShrrLinkClCd {

		/** 망직연동 (1) */
		LINK_DIR("1")

		,
		/** AP하부스캔 (2) */
		LINK_AP("2")

		,
		/** 사설AP-STB연결 (3) */
		LINK_PRV_AP_STB("3")

		,
		/** 사설AP-SKBAP연결 (4) */
		LINK_PRV_AP_SKBAP("4");

		private String code;

		private PrvShrrLinkClCd(String code) {
			this.code = code;
		}

		public String getCode() {
			return code;
		}

	}

	/**
	 * 장비속성변경구분코드
	 * 
	 * @author SUBKJH-DEV
	 *
	 */
	public enum EquipAttrChgClCd {

		/** 일괄변경 ( B0 ) */
		BATCH("B0"),
		/** 구성변경 ( C0 ) */
		ASIS("C0"),
		/** SWING변경 ( S0 ) */
		SWING("SO"),
		/** 운용자변경 ( U0 ) */
		USER("U0");

		private EquipAttrChgClCd(String code) {
			this.code = code;
		}

		private String code;

		public String getCode() {
			return code;
		}
	}

}
