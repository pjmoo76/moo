package com.skb.adams.cm;

import java.rmi.RemoteException;

import fxms.bas.fxo.service.FxServiceImpl;
import fxms.bas.fxo.service.ext.ExtServiceImpl;

public class CmGwServiceImpl extends ExtServiceImpl implements CmGwService {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2319704613952073136L;

	public static void main(String[] args) {
		FxServiceImpl.start(CmGwService.class.getSimpleName(), CmGwServiceImpl.class, args);
	}

	public CmGwServiceImpl(String name, int port) throws RemoteException, Exception {
		super(name, port);
	}

}
