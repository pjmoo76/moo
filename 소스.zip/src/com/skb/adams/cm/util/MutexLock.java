package com.skb.adams.cm.util;

/**
 * dummy object for synchronizing
 * @author csjung
 *
 */
public class MutexLock {

}
