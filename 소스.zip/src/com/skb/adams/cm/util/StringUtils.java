package com.skb.adams.cm.util;

import subkjh.bas.log.Logger;

public class StringUtils {
	public static boolean isEmpty(String s) {
		if (s == null) return true;
		return s.isEmpty();
	}
	
	public static boolean equals(String a, String b) {
		if (a == null && b == null) return true;
		if (a == null && b != null) return false;
		return a.equals(b);
	}

	public static String toReadableString(byte[] bytes) {
		return toReadableString(bytes, bytes.length);
	}

	public static String toReadableString(byte[] bytes, int len) {
		int bufLen = len < bytes.length ? len : bytes.length;
		StringBuffer sb = new StringBuffer(bufLen);
		for (int i = 0; i < bufLen; i ++) {
			if (bytes[i] >= 33 && bytes[i] <= 126) {
				sb.append((char)bytes[i]);
			} else {
				sb.append(".");
			}
		}
		return sb.toString();
	}

	public static String toHexString(byte[] bytes) {
		return toHexString(bytes, bytes.length);
	}

	public static String toHexString(byte[] bytes, int len) {
		if (len <= 0) return null;
		int bufLen = len < bytes.length ? len : bytes.length;
		StringBuffer sb = new StringBuffer(bufLen*2);
		for (int i = 0; i < bufLen; i ++) {
			sb.append(toHex(bytes[i] >> 4));
			sb.append(toHex(bytes[i]));
		}
		return sb.toString();
	}
	
	private static char toHex(int nibble) {
		final char[] hexDigit = {
			'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'
		};
		return hexDigit[nibble & 0xF];
	}
	
	public static void main(String[] args) {
		String str = "hello!!!";
		int len = 5;
		System.out.println(toHexString(str.getBytes(), 10));
		System.out.println(toReadableString(str.getBytes(), 10));
	}
}
