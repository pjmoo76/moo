package com.skb.adams.cm.util;

/**
 * measure elasped time
 * @author csjung
 *
 */
public class ElaspedTime {
	
	long 	m_STime;
	long 	m_ETime;
	
	public ElaspedTime() {
		m_STime = System.currentTimeMillis();
		m_ETime = m_STime;
	}
	
	public void start() {
		m_STime = System.currentTimeMillis();
		m_ETime = m_STime;
	}
	
	public void end() {
		m_ETime = System.currentTimeMillis();
	}
	
	public long getStartTime() {
		return m_STime;
	}
	
	public long getEndTime() {
		return m_ETime;
	}

	public long	getElaspedSec()
	{
		return getElaspedMiliSec()/1000;
	}

	public long	getElaspedMiliSec()
	{
		long sSec = m_ETime - m_STime;
		return sSec;
	}
	
	public String getElaspedSecString()
	{
		return String.format("%8.2f", ((double)getElaspedMiliSec())/1000.0).trim();
	}
	
	static public String getElaspedSecString(long Milisecond)
	{
		return String.format("%8.2f", ((double)Milisecond)/1000.0).trim();
	}

	
}
