package com.skb.adams.cm.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import subkjh.bas.log.Logger;

public class MiscUtils {
	public static String getPortNo(String data) {
		if (data == null) return null;
		int i = data.length();
		while (i > 0) {
			i --;
			if (Character.isDigit(data.charAt(i)) == false) {
				if (i+1 == data.length()) {
					return null;
				} else {
					return data.substring(i+1);
				}
			}
		}
		return data;
	}
	
	public static String getPortLoc(String data) {
		if (data == null) return "";
		if (data.startsWith("GigabitEthernet")) {
			return data.replace("GigabitEthernet", "");
		} else if (data.startsWith("pon")) {
			return data.replace("pon", "");
		} else if (data.startsWith("p")) {
			return data.replace("p", "");
		} else if (data.startsWith("ge-")) {
			return data.replace("ge-", "");
		} else if (data.startsWith("ge")) {
			return data.replace("ge", "");
		} else if (data.startsWith("Gi")) {
			return data.replace("Gi", "");
		} else if (data.startsWith("Fa")) {
			return data.replace("Fa", "");
		} else if (data.startsWith("Vlanif")) {
			return data.replace("Vlanif", "");
		} else if (data.startsWith("Vl")) {
			return data.replace("Vl", "");
		} else if (data.startsWith("vif")) {
			return data.replace("vif", "");
		} else if (data.startsWith("TenGigE")) {
			return data.replace("TenGigE", "");
		} else if (data.startsWith("Te")) {
			return data.replace("Te", "");
		} else if (data.startsWith("Eth-Trunk")) {
			return data.replace("Eth-Trunk", "");
		} else {
			return "";
		}
	}

	/**
	 * Determines if the specified string is a digit
	 * @param Str : source string
	 * @return boolean
	 */
	static public boolean isDigit(String Str) {
		for(int i = 0 ; i < Str.length() ; i++) {
			if(Character.isDigit(Str.charAt(i)) == false) {
				return false;
			}
		}
		return true;
	}
	
	public static void Sleep(long MiliSecond) {
		try {
			Thread.sleep(MiliSecond);
		} catch (InterruptedException e) {
		}
	}
	
	/**
	 * check that specific class are included on jar library given class path
	 * @param ClassName : class name for checking
	 * @return result
	 */
	public static boolean isValidClass(String ClassName) {
		try {
			Class.forName(ClassName);
			Logger.logger.info(String.format("class[%s] is exist", ClassName));
			return true;
		} catch (ClassNotFoundException e){
			Logger.logger.error(String.format("class[%s] isn't exist", ClassName));
	    } catch (Exception e) {
	    	Logger.logger.error(String.format("class[%s] isn't exist", ClassName));
	    }
	    return false;
	}
	
	/**
	 * execute thread
	 * @param runnable : implemented runnable
	 * @return thread object
	 */
	public static Thread runInBackgroundThread(Runnable runnable) {
        Thread t = new Thread(runnable);
        t.start();
        return t;
    }
	
	/**
	 * generate stack trace string from exception object
	 * @param e : exception
	 * @return result
	 */
	public static String getStackTraceStringFromException(Exception e)
	{
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		return sw.toString();
	}
	
	/**
	 * convert string to int
	 * @param ValueOrg : source string
	 * @param Default : default value
	 * @param LoggingTag : error logging tag
	 * @return int
	 */
	static public int stringToint(String ValueOrg, int Default, String LoggingTag) {
		if(ValueOrg == null || ValueOrg.length() == 0) {
			return Default;
		}
		
		String valueStr = ValueOrg;
		
		int value = Default;
		try {
			int pos = valueStr.indexOf('.');
			if(pos > -1) {
				if(pos == 0) {
					return value;
				}
				valueStr = valueStr.substring(0, pos);
			}
			value = Integer.parseInt(valueStr);
		} catch (NumberFormatException Nex) {
			Logger.logger.info(String.format("### error for changing string to int at %s [%s][%s]",
					LoggingTag != null ? LoggingTag : "" , ValueOrg, Nex.getMessage()));
		}
		return value;
	}
	
	/**
	 * convert Calendar to string
	 * @param Cal
	 * @return time format is YYYYMMDDHH24MISS
	 */
	public static String getTimeStrFromCalendar2(Calendar Cal) {
		if(Cal == null) {
			return "NULL";
		}
		
		return String.format("%04d%02d%02d%02d%02d%02d",
				Cal.get(Calendar.YEAR), Cal.get(Calendar.MONTH)+1, Cal.get(Calendar.DAY_OF_MONTH),
				Cal.get(Calendar.HOUR_OF_DAY), Cal.get(Calendar.MINUTE), Cal.get(Calendar.SECOND));
	}
	
	/**
	 * convert time(long) to string
	 * @param Time : time in milliseconds
	 * @return time format is YYYYMMDDHH24MISS
	 */
	public static String getTimeStrFromTime2(long Time) {
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(Time);
		return getTimeStrFromCalendar2(cal);
	}
	
	/**
	 * convert time(long) to string
	 * @param Time : time in milliseconds
	 * @return time format is YYYYMMDDHH24MISS
	 */
	public static String getCurrentTimeStr2() {
		return getTimeStrFromTime2(System.currentTimeMillis());
	}
	
	public static String RemoveLineFeed(String orgStr) {
		if(orgStr != null) {
			return orgStr.replace("\r", "").replace("\n", "");
		} else {
			return "";
		}
	}
	
	/**
	 * string을 token하여 String Array로 return
	 * @param Source : source 
	 * @param Delimiter : delimiter
	 * @return String Array
	 */
	public static String[] split(String Source, char Delimiter) {
		
		if(Source == null || Source.length() == 0) {
			return null;
		}
		return split(Source, Delimiter, new ArrayList<String>());
	}
	
	/**
	 * string을 token하여 String Array로 return
	 * @param Source : source 
	 * @param Delimiter : delimiter
	 * @param ReUseTempList : temporary buffer list, avoid to alloc interval buffer list
	 * @return String Array
	 */
	public static String[] split(String Source, char Delimiter, ArrayList<String> ReUseTempList) {
		
		if(Source == null || Source.length() == 0) {
			return null;
		}
		
		ReUseTempList.clear();
		
		ArrayList<String> strList = ReUseTempList;
		
		int startIndex = 0;
		int nextIndex = Source.indexOf((int)Delimiter, startIndex);
		
		while (nextIndex != -1) {
			if(startIndex == nextIndex) {
				strList.add("");
			} else {
				strList.add(Source.substring(startIndex, nextIndex));
			}
			startIndex = nextIndex + 1;
			nextIndex = Source.indexOf((int)Delimiter, startIndex);
		}
		
		strList.add(Source.substring(startIndex));
		
		//remove last empty split(s)
		int last = strList.size(); // last split
		--last;
		if(last>=0 && "".equals(strList.get(last))) {
			strList.remove(last);
		}
		return strList.toArray(new String[strList.size()]);
	}
	/**
	 * string을 token하여 String Array로 return 마지막 제거 로직 사용하지않음.
	 * @param Source : source 
	 * @param Delimiter : delimiter
	 * @param ReUseTempList : temporary buffer list, avoid to alloc interval buffer list
	 * @return String Array
	 */
	public static String[] split2(String Source, char Delimiter, ArrayList<String> ReUseTempList) {
		
		if(Source == null || Source.length() == 0) {
			return null;
		}
		
		ReUseTempList.clear();
		
		ArrayList<String> strList = ReUseTempList;
		
		int startIndex = 0;
		int nextIndex = Source.indexOf((int)Delimiter, startIndex);
		
		while (nextIndex != -1) {
			if(startIndex == nextIndex) {
				strList.add("");
			} else {
				strList.add(Source.substring(startIndex, nextIndex));
			}
			startIndex = nextIndex + 1;
			nextIndex = Source.indexOf((int)Delimiter, startIndex);
		}
		
		strList.add(Source.substring(startIndex));
		
	
		return strList.toArray(new String[strList.size()]);
	} 
	public static String addDays(String strDate, String pattern,  int daysToAdd) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		Date date = sdf.parse(strDate);
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		//Logger.logger.debug(String.format("(year=%d),(month=%d),(day=%d)", c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)));
		c.add(Calendar.DAY_OF_YEAR, daysToAdd);
		//Logger.logger.debug(String.format("(year=%d),(month=%d),(day=%d)", c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)));
		return sdf.format(c.getTime());
	}
}
