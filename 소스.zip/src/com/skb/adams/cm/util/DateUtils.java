package com.skb.adams.cm.util;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;

import com.skb.adams.fm.service.unms.PduVoipCallTrfMsgEnum;

public class DateUtils {
	public static ZonedDateTime getUnixTime(String unixTime) {
		try {
			long time = Long.parseLong(unixTime);
			Instant instant = Instant.ofEpochSecond(time);
			return instant.atZone(ZoneId.of("Asia/Seoul"));
		} catch (Exception e) {
			return ZonedDateTime.now();
		}
	}

	public static String getDate(ZonedDateTime zdTime) {
		return String.format("%04d%02d%02d", zdTime.getYear(), zdTime.getMonthValue(), zdTime.getDayOfMonth());
	}

	public static String getTime(ZonedDateTime zdTime) {
		return String.format("%04d%02d%02d%02d%02d%02d",
				zdTime.getYear(), zdTime.getMonthValue(), zdTime.getDayOfMonth(),
				zdTime.getHour(), zdTime.getMinute(), zdTime.getSecond());
	}

	public static void main(String[] args) {
		//Instant instant = Instant.now();
		//long time = instant.getEpochSecond();
		String unixTime = "1533615600";
		ZonedDateTime zdTime = DateUtils.getUnixTime(unixTime);
		String mntrDt = DateUtils.getDate(zdTime);
		String mntrDtm = DateUtils.getTime(zdTime);
		System.out.println(String.format("(%s),(%s),(%s)", unixTime, mntrDt, mntrDtm));
	}
}
