package com.skb.adams.cm.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.exception.DBObjectDupException;
import subkjh.bas.dao.exception.TableNotFoundException;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.CmMsg;
import com.skb.adams.cm.dao.CmDao;

public abstract class Batcher {

	private String filePrefix;
	private int length;
	private int index = 0;
	private boolean isTempTable = false;
	private DbTrans dstTran;
	private String dstTable;
	private List<Object[]> valueList;
	private StringBuffer createTempTableSql;
	private StringBuffer insertSql;
	private File file;

	protected abstract String[] getColumns();

	public String getFilePrefix() {
		return filePrefix;
	}

	protected abstract String getTableName();

	private void insert() throws Exception {

		if (valueList.size() == 0) {
			return;
		}

		try {
			dstTran.executeSql(insertSql.toString(), valueList);
		} catch (Exception e) {
			throw e;
		} finally {
			valueList.clear();
		}
	}

	protected void onData(int index, List<String> dataList) throws Exception {

		valueList.add(dataList.toArray(new Object[dataList.size()]));

		if (index % 50000 == 0) {
			insert();
		}

	}

	private void onFinished(Exception ex) {
		try {
			if (ex == null) {
				insert();
				dstTran.commit();

				Logger.logger.info(CmMsg.makeCmInfo(file.getName() + " -> " + dstTable, -1, index, -1));

			} else {
				throw ex;
			}
		} catch (Exception e) {
			dstTran.rollback();
			Logger.logger.error(e);
		} finally {
			dstTran.stop();
		}
	}

	private boolean onRead(String line) throws Exception {
		List<String> list = parse(line);
		if (list.size() == length) {
			onData(index, list);
			index++;
			return true;
		} else {
			System.out.println(list.size() + ", " + line);
		}
		return false;
	}

	private void onStart(File file) throws Exception {
		StringBuffer name = new StringBuffer();
		StringBuffer value = new StringBuffer();

		createTempTableSql = new StringBuffer();

		dstTran = DBManager.getMgr().getDataBase(CmDao.ADAMS).createDbTrans("deploy/conf/sql/neifdb.xml");

		dstTable = "FX_TMP_" + getTableName();

		try {
			dstTran.executeSql("drop table " + dstTable, null);
		} catch (TableNotFoundException e) {
		} catch (Exception e) {
			throw e;
		}

		if (isTempTable) {
			createTempTableSql.append("CREATE GLOBAL TEMPORARY TABLE ");
		} else {
			createTempTableSql.append("CREATE TABLE ");
		}
		createTempTableSql.append(dstTable);
		createTempTableSql.append(" ( ");

		for (String col : getColumns()) {
			if (name.length() > 0) {
				name.append(", ");
				value.append(", ");
				createTempTableSql.append(", ");
			}

			name.append(col);
			value.append("?");
			createTempTableSql.append(col + " varchar2(1000)");

		}
		createTempTableSql.append(", T_INS_DATE date default sysdate");

		if (isTempTable) {
			createTempTableSql.append(") on commit delete rows");
		} else {
			createTempTableSql.append(")");
		}

		System.out.println(createTempTableSql);

		try {
			dstTran.executeSql(createTempTableSql.toString(), null);
		} catch (DBObjectDupException e) {
		} catch (Exception e) {
			throw e;
		}

		insertSql = new StringBuffer();
		insertSql.append("insert into ");
		insertSql.append(dstTable);
		insertSql.append(" ( ");
		insertSql.append(name);
		insertSql.append(" ) values ( ");
		insertSql.append(value);
		insertSql.append(" )");

		valueList = new ArrayList<Object[]>();

	}

	private List<String> parse(String line) {

		StringBuffer sb = new StringBuffer();
		List<String> list = new ArrayList<String>();
		char chs[] = line.toCharArray();
		for (int i = 0; i < chs.length; i++) {
			if (i > 0 && chs[i] == '|' && chs[i - 1] == '\\') {
				sb.append(chs[i]);
			} else if (chs[i] == '|') {
				list.add(sb.toString());
				sb = new StringBuffer();
			} else {
				sb.append(chs[i]);
			}
		}

		// list.add(sb.toString());

		return list;
	}

	public void runBatch(File file) throws Exception {

		this.file = file;
		this.index = 0;

		long ptime = System.currentTimeMillis();
		BufferedReader in = null;
		String val;
		String valPrev = null;
		Exception ex = null;
		try {
			in = new BufferedReader(new InputStreamReader(new FileInputStream(file), "euc-kr"));

			onStart(file);

			while (true) {

				try {
					val = in.readLine();
					if (val == null) {
						break;
					}
					if (val.trim().length() == 0 || val.equals("\\"))
						continue;

					if (valPrev != null) {
						if (onRead(valPrev + val) == false) {
							valPrev = valPrev + val;
						} else {
							valPrev = null;
						}
					} else {
						if (onRead(val) == false) {
							valPrev = val;
						} else {
							valPrev = null;
						}
					}

					if (System.currentTimeMillis() > ptime + 5000) {
						Logger.logger.debug("READ = " + index);
						ptime += 5000;
					}

				} catch (IOException e) {
					break;
				}
			}

		} catch (Exception e) {
			Logger.logger.error(e);
			ex = e;
		} finally {
			if (in != null)
				try {
					in.close();
				} catch (IOException e) {
				}

			onFinished(ex);

		}

	}

	public void setFilePrefix(String filePrefix) {
		this.filePrefix = filePrefix;
	}

	public void setLength(int length) {
		this.length = length;
	}
}
