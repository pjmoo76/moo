package com.skb.adams.cm.batch;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import subkjh.bas.log.Logger;

public abstract class FileParser extends BasFileParser<List<String>> {

	private int length;

	public FileParser(int length) {
		super();
		this.length = length;
	}

	@Override
	protected boolean isCompeletedData(List<String> data) {
		return data.size() == length;
	}

	@Override
	protected void onFinished(File file, int size, Exception ex) {
		try {
			Logger.logger.info(file.getName());
		} catch (Exception e) {
			Logger.logger.error(e);
		} finally {
		}
	}

	protected void onFinishedAll() {

	}

	protected List<String> parse(String line) {

		StringBuffer sb = new StringBuffer();
		List<String> list = new ArrayList<String>();
		char chs[] = line.toCharArray();
		for (int i = 0; i < chs.length; i++) {
			// if (i > 0 && chs[i] == '|' && chs[i - 1] == '\\') {
			// sb.append(chs[i]);
			// } else
			if (chs[i] == '|') {
				list.add(sb.toString());
				sb = new StringBuffer();
			} else {
				sb.append(chs[i]);
			}
		}

		return list;
	}
}
