package com.skb.adams.cm.batch;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import subkjh.bas.utils.FileUtil;

import com.skb.adams.cm.dao.ParaMap;

import fxms.bas.define.PS_TYPE;

public class FindFileParser extends FileParser {

	public static void main(String[] args) {
		FindFileParser p = new FindFileParser();
		p.parseFolder(new File("datas/bos2"));
	}

	private static Map<String, String> map = new HashMap<String, String>();
	private static Map<String, String> custMap = new HashMap<String, String>();
	private static Map<String, String> svcMap = new HashMap<String, String>();
	private static Map<String, List<String>> tMap = new HashMap<String, List<String>>();
	private ParaMap teamMap;
	private ParaMap stbMap;

	public FindFileParser() {
		super(71);

//		ParaQid QID = new ParaQid();

		try {
			// teamMap = new ParaMap("SELECT__INFO_CD__TEAM_ID");
			teamMap = new ParaMap("SELECT__TPO_CD__TEAM_ID");
			stbMap = new ParaMap("SELECT_STB_MDL_FULLNAME");

		} catch (Exception e) {
			e.printStackTrace();
		}

		List<String> tpoList = FileUtil.getLines(new File("datas/송도동국사코드.txt"));
		for (String tpo : tpoList) {
			map.put(tpo, tpo);
		}
	}

	@Override
	protected void onFinished(File file, int size, Exception ex) {
		if (ex != null) {
			ex.printStackTrace();
		} else {
			// System.out.println("TPO_CD : " + map.size());
			// System.out.println("CUST_NUM : " + custMap.size());
			// System.out.println("SVC_NUM : " + svcMap.size());
		}

		System.out.println(file.getName() + " : " + PS_TYPE.getHstime());

		printOrg();
	}

	protected void onFinishedAll() {
		System.out.println("서비스명\t가입자수");
		for (String name : countMap.keySet()) {
			System.out.println(name + "\t" + countMap.get(name));
		}

		System.out.println("------------------------------------------------------------------------");

		System.out.println("TPO_CD : " + map.size());
		System.out.println("CUST_NUM : " + custMap.size());
		System.out.println("SVC_NUM : " + svcMap.size());

	}

	private Map<String, Integer> countMap = new HashMap<String, Integer>();

	protected void onData_SERVICE(int index, String line, List<String> dataList) throws Exception {
		String l3EquipId = dataList.get(27);
		if (l3EquipId.trim().length() == 0) {
			if ("케이블".equals(dataList.get(18))) {
				System.out.println(line);
				return;
			}

			addCount(dataList.get(18));
			addCount(dataList.get(19));
			addCount(dataList.get(20));
		}
	}

	private void addCount(String name) {
		if (name.trim().length() == 0) {
			return;
		}
		Integer cnt = countMap.get(name);

		if (cnt == null) {
			countMap.put(name, 1);
		} else {
			countMap.put(name, cnt.intValue() + 1);
		}
	}

	protected void onData(int index, String line, List<String> dataList) throws Exception {

		// countService(index, line, dataList);
		// findMac(index, line, dataList);
		findOrg(index, line, dataList);
		// findSvc(index, line, dataList);
		// findCust(index, line, dataList);
	}

	protected void onData_55(int index, String line, List<String> dataList) throws Exception {
		String l3EquipId = dataList.get(27);
		String l3Cell = dataList.get(33);

		if ("WB423R01".equals(l3EquipId) && "KM48".equals(l3Cell)) {
			System.out.println(line);
		}
		//
	}

	protected void countService(int index, String line, List<String> dataList) throws Exception {

		String l3EquipId = dataList.get(27);
		String l3Cell = dataList.get(33);

		// WB423R01
		// CM423102
		if ("WB423R01".equals(l3EquipId) && "KM48".equals(l3Cell)) {

			for (String s : dataList) {
				System.out.print(s);
				System.out.print("\t");
			}
			System.out.println();

			String custNum = dataList.get(5);

			if (custNum != null) {
				custMap.put(custNum, custNum);
			}
			String svcNum = dataList.get(13);
			if (svcNum != null) {
				svcMap.put(svcNum, svcNum);
			}
			svcNum = dataList.get(15);
			if (svcNum != null) {
				svcMap.put(svcNum, svcNum);
			}
			svcNum = dataList.get(17);
			if (svcNum != null) {
				svcMap.put(svcNum, svcNum);
			}
		}

	}

	// private String macs[] = new String[] { "000358D1FCE5", "00035831DC2B",
	// "000358D0E380", "000358310B51", "000308110D5F", "000358D26B7C",
	// "000358D1BCC8", "000358D1933C", "00020050B8A5", "000200499B9C",
	// "001AC3186072", "0002005474C7" };

	private String macs[] = new String[] { "00909635F0D4", "000358D12FCC", "0002007ECCF8", "0030EB14CBCF", "00035831DE8A", "0002005861C7",
			"000358D01215", "000358D0E452", "00020050439C", "000358D0A31E", "00035830C6DC", "000358D18CA3", "000358310B51", "000358D08AB1",
			"000200536A9B", "00020050B8A5", "00035831BD68", "000358D07077", "000358D17DFC", "0002007F1F6E", "0002005B0AF4" };

	protected void findMac(int index, String line, List<String> dataList) throws Exception {

		String mac = dataList.get(1).toUpperCase();

		for (String s : macs) {
			if (s.equals(mac)) {
				for (String s1 : dataList) {
					System.out.print(s1);
					System.out.print("\t");
				}
				System.out.println();
				return;
			}
		}

	}

	protected void findSvc(int index, String line, List<String> dataList) throws Exception {

		String inetSvc = dataList.get(13);
		String voipSvc = dataList.get(15);
		String iptvSvc = dataList.get(17);

		if ("7265513673".equals(inetSvc) //
				|| "7265513673".equals(voipSvc) //
				|| "7265513673".equals(iptvSvc)) //
		{
			System.out.println(index + ", " + line);
		}
	}

	private void printOrg() {
		for (String key : tMap.keySet()) {
			System.out.println(key + " : " + tMap.get(key));
		}
	}

	protected void findOrg(int index, String line, List<String> dataList) throws Exception {

//		String infoTpoCd = dataList.get(31);
		String tpoCd = dataList.get(43);
		String orgId = dataList.get(61);
		String weqpModel = dataList.get(4);
		
		if (stbMap.getParaCode(weqpModel) == null) {
			return;
		}

		String teamId = teamMap.getParaName(tpoCd);

//		 System.out.println(infoTpoCd + ", " + orgId + ", " + teamId);

		if (teamId == null)
			return;

		List<String> entry = tMap.get(teamId);
		if (entry == null) {
			entry = new ArrayList<String>();
			tMap.put(teamId, entry);
		}

		if (entry.contains(orgId) == false) {
			entry.add(orgId);
		}

	}

	protected void findCust(int index, String line, List<String> dataList) throws Exception {

		String custNum = dataList.get(5);
		if ("8001862315".equals(custNum)) {
			System.out.println(index + ", " + line);
		}

	}

	@Override
	public boolean isTargetFile(File file) {
		return file.getName().startsWith("BOS2IFNMS");
	}

}
