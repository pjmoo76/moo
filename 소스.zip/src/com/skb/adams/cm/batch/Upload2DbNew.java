package com.skb.adams.cm.batch;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.exception.TableNotFoundException;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.CmMsg;

public class Upload2DbNew<DATA> {

	private static final SimpleDateFormat YYYYMMDDHHMMSS = new SimpleDateFormat("yyyyMMddHHmmss");

	private String tableName;
	private DbTrans dstTran;
	private List<DATA> dataList;
	private int count = 0;
	private int batchSize = 300000;
	private String insertQid;
	private String checkQid;
	private String finishQids[];

	public Upload2DbNew(DbTrans dstTran, String targetTableName, String... qids) throws Exception {

		this.tableName = "FX_TMP_" + targetTableName;
		insertQid = "INSERT_" + this.tableName;
		String deleteQid = "DELETE_" + this.tableName;
		checkQid = "SELECT_COUNT_" + tableName;
		finishQids = qids;

		dataList = new ArrayList<DATA>();
		this.dstTran = dstTran;

		if (dstTran.getSqlBean(tableName) == null) {
			throw new Exception("QID NOT FOUND : " + tableName);
		}

		if (dstTran.getSqlBean(insertQid) == null) {
			throw new Exception("QID NOT FOUND : " + insertQid);
		}
		if (dstTran.getSqlBean(deleteQid) == null) {
			throw new Exception("QID NOT FOUND : " + deleteQid);
		}
		if (dstTran.getSqlBean(checkQid) == null) {
			throw new Exception("QID NOT FOUND : " + checkQid);
		}
		for (String qid : finishQids) {
			if (dstTran.getSqlBean(qid) == null) {
				throw new Exception("QID NOT FOUND : " + qid);
			}
		}

		try {
			dstTran.execute(deleteQid, null);
		} catch (TableNotFoundException e) {
			dstTran.execute(tableName, null);
		} catch (Exception e) {
			throw e;
		}

	}

	public void add(DATA data) throws Exception {
		if (data != null) {
			dataList.add(data);
			count++;
			if (count % batchSize == 0) {
				insert();
			}
		}
	}

	public void close(Exception ex) throws Exception {
		try {
			if (ex == null) {
				insert();

				long size = dstTran.selectQidLong(checkQid, null, 0);
				Logger.logger.info(checkQid + "=" + size);

				Map<String, Object> para = new HashMap<String, Object>();
				para.put("workDate", YYYYMMDDHHMMSS.format(new Date(System.currentTimeMillis())));

				for (String qid : finishQids) {
					try {
						int mergeCnt = dstTran.execute(qid, para);
						Logger.logger.info(CmMsg.makeCmInfo(qid, -1, mergeCnt, -1));
					} catch (Exception e) {
						Logger.logger.fail(qid);
						Logger.logger.error(e);
						throw e;
					}
				}

				Logger.logger.info(CmMsg.makeCmInfo(tableName, -1, count, size));

			} else {
				throw ex;
			}
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}
	}

	private void insert() throws Exception {

		if (dataList.size() == 0) {
			return;
		}

		try {
			dstTran.execute(insertQid, dataList);
		} catch (Exception e) {
			throw e;
		} finally {
			dataList.clear();
		}
	}

}
