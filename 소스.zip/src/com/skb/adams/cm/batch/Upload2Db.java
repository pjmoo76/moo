package com.skb.adams.cm.batch;

import java.util.ArrayList;
import java.util.List;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.exception.TableNotFoundException;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.CmMsg;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.FxTmpQid;

public class Upload2Db<DATA> {

	private String tableName;
	private DbTrans dstTran;
	private List<DATA> dataList;
	private int count = 0;
	private int batchSize = 300000;
	private String insertQid;
	private String finishQids[];

	public Upload2Db(String targetTableName, String... qids) throws Exception {

		this.tableName = "FX_TMP_" + targetTableName;
		insertQid = "INSERT_" + this.tableName;
		String truncateQid = "TRUNCATE_" + this.tableName;

		finishQids = qids;

		dataList = new ArrayList<DATA>();
		dstTran = DBManager.getMgr().getDataBase(CmDao.ADAMS).createDbTrans("deploy/conf/sql/" + FxTmpQid.QUERY_XML_FILE);

		if (dstTran.getSqlBean(tableName) == null) {
			throw new Exception("QID NOT FOUND : " + tableName);
		}
		if (dstTran.getSqlBean(insertQid) == null) {
			throw new Exception("QID NOT FOUND : " + insertQid);
		}
		if (dstTran.getSqlBean(truncateQid) == null) {
			throw new Exception("QID NOT FOUND : " + truncateQid);
		}

		for (String qid : finishQids) {
			if (dstTran.getSqlBean(qid) == null) {
				throw new Exception("QID NOT FOUND : " + qid);
			}
		}

		try {
			dstTran.execute(truncateQid, null);
		} catch (TableNotFoundException e) {
			dstTran.execute(tableName, null);
		} catch (Exception e) {
			throw e;
		}

	}

	public void add(DATA data) throws Exception {
		if (data != null) {

			dataList.add(data);

			count++;

			if (count % batchSize == 0) {
				insert();
			}

		}
	}

	public List<DATA> getDataList() {
		return dataList;
	}

	public void close(Exception ex) {
		try {

			if (ex == null) {

				insert();

				for (String qid : finishQids) {
					int mergeCnt = dstTran.execute(qid, null);
					Logger.logger.info(CmMsg.makeCmInfo("MERGE " + tableName, -1, mergeCnt, -1));
				}

				dstTran.commit();

				Logger.logger.info(CmMsg.makeCmInfo(tableName, -1, count, -1));

			} else {
				throw ex;
			}
		} catch (Exception e) {
			dstTran.rollback();
			Logger.logger.error(e);
		} finally {
			dstTran.stop();
		}
	}

	private void insert() throws Exception {

		if (dataList.size() == 0) {
			return;
		}

		try {
			dstTran.execute(insertQid, dataList);
			dstTran.commit();
		} catch (Exception e) {
			throw e;
		} finally {
			dataList.clear();
		}
	}

}
