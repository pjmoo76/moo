package com.skb.adams.cm.batch.swms;

import java.io.File;
import java.util.Map;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.log.Logger;

import com.google.gson.Gson;
import com.skb.adams.cm.CmCode;
import com.skb.adams.cm.batch.BasFileParser;
import com.skb.adams.cm.batch.Upload2DbNew;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.FxTmpQid;
import com.skb.adams.cm.model.OIV10821;

public class ApScanAllParser extends BasFileParser<OIV10821> {

	public static void main(String[] args) {
		ApScanAllParser parser = new ApScanAllParser();
		File folder = new File("datas/swms/ap_scan_all");
		parser.parseFolder(folder);
	}

	private Gson gson = new Gson();
	private Upload2DbNew<OIV10821> uploader;
	private DbTrans dstTran;

	public ApScanAllParser() {
		// super("utf-8");
	}

	@Override
	protected boolean isCompeletedData(OIV10821 data) {
		return true;
	}

	@Override
	public boolean isTargetFile(File file) {
		return file.getName().endsWith(".#FIN");
	}

	@Override
	protected void onData(int index, String line, OIV10821 data) throws Exception {

		if (data.getWeqpMacAddr() != null && data.getWeqpMacAddr().length() == 12) {
			uploader.add(data);
		}

	}

	@Override
	protected void onFinished(File file, int size, Exception ex) {
		try {
			uploader.close(ex);
			dstTran.commit();

			Logger.logger.info("FILE({}) DATA-COUNT({})", file.getName(), size);

		} catch (Exception e) {
			dstTran.rollback();
			Logger.logger.error(e);
			ex = e;
		} finally {
			backup(file, ex);
			dstTran.stop();
		}
	}

	@Override
	protected void onStart(File file) throws Exception {
		dstTran = DBManager.getMgr().getDataBase(CmDao.ADAMS).createDbTrans("deploy/conf/sql/" + FxTmpQid.QUERY_XML_FILE);
		dstTran.start();

		uploader = new Upload2DbNew<OIV10821>(dstTran, "OIV10821", new FxTmpQid().MERGE_OIV10821);

		Logger.logger.debug(file);
	}

	@SuppressWarnings("rawtypes")
	@Override
	protected OIV10821 parse(String line) throws Exception {

		Map map = gson.fromJson(line, Map.class);
		OIV10821 o821 = new OIV10821();

		o821.setPrvShrrIpAddr(null);
		o821.setPrvShrrLinkClCd(CmCode.PrvShrrLinkClCd.LINK_AP.getCode());
		o821.setPrvShrrMacAddr(getValStr(map.get("DEV_MAC")));
		o821.setPrvShrrMfactNm(getValStr(map.get("DEV_MKR")));
		o821.setRgstDt(getValYyyymmdd(map.get("YMD")));
		o821.setWeqpIpAddr(getValStr(map.get("AP_IP")));
		o821.setWeqpMacAddr(getValStr(map.get("OUI_MAC")));

		if (o821.getPrvShrrMacAddr().equals("A078BA81C1A6")) {
			System.out.println(line);
		}

		return o821;
	}
}

// {
// "INET_SERVICE_NUM": "0137959601",
// "TV_SVCMGMT_NUM": "7236513895",
// "STB_MODEL": "STB(\uac00\uc628 BKO-100)",
// "INET_SVCMGMT_NUM": "7126192672",
// "HP_CTR_NM": "\ubd80\ucc9c\ubd80\ud3c9Home\uc13c\ud130",
// "CUST_NUM": "8004672640",
// "SVC_TECH_CODE": "B0027",
// "UDEV2_NUM": "PL010020",
// "TEL_SERVICE_NUM": " ****",
// "AREA1_CD": "C20100",
// "NETWORK": "1",
// "TEL_SERVICE_NM": " ",
// "UDEV2_MODEL": "V5924C",
// "UDEV1_NUM": "NR028808",
// "DEV_MKR": "EFM Networks",
// "OUI_MAC": "00300DAA1613",
// "UDEV1_TID": "[2LB]\ubd80\uac1c\ud55c\uad6d_SGLT040G_OLT",
// "CUST_NM": "\uae40*\uc219",
// "UDEV2_MKR": "(\uc8fc)\ub2e4\uc0b0\ub124\ud2b8\uc6cd\uc2a4",
// "AREA2_CD": "C20465",
// "TV_SERVICE_NUM": "7236513895",
// "DEV_MAC": "909F332C9831",
// "TV_SERVICE_NM": "Btv(IPTV)",
// "YMD": "2017-12-26 14:01:22",
// "AREA1_NM": "\uacc4\uc591\uc815\ubcf4\uc13c\ud130",
// "INET_SERVICE_NM": "\uad11\ub79cV",
// "TEAM_NM": "\uc778\ucc9c\ud488\uc9c8\uc194\ub8e8\uc158\ud300",
// "UDEV2_TID": "\ubd80\uac1c\ud55c\uad6d_105\ub3d9_GP_M2",
// "AP_IP": "61.101.56.204",
// "STB_MAC": "0008B9B69147",
// "HP_CTR_CD": "1003002249",
// "TEAM_CD": "T126",
// "TEL_SVCMGMT_NUM": "0",
// "AREA2_NM": "\ubd80\uac1c\ud55c\uad6d_[OLT_B]",
// "UDEV2_CELL": "",
// "UDEV1_MODEL": "OLT SGL-T040G",
// "DEV_MODEL": "11n AP(\uc5e0\uc5e0\uc528 MW-2060AP)"
// }
