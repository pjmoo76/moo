package com.skb.adams.cm.batch.swms;

import java.io.File;
import java.util.Map;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.log.Logger;

import com.google.gson.Gson;
import com.skb.adams.cm.batch.BasFileParser;
import com.skb.adams.cm.batch.Upload2DbNew;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.FxTmpQid;
import com.skb.adams.cm.model.OIV10802;

public class ApInfoParser extends BasFileParser<OIV10802> {

	public static void main(String[] args) {
		ApInfoParser parser = new ApInfoParser();
		File folder = new File("datas/swms/apinfo");
		parser.parseFolder(folder);
	}

	private Gson gson = new Gson();
	private Upload2DbNew<OIV10802> uploader;
	private DbTrans dstTran;

	public ApInfoParser()
	{
		
	}
	
	@Override
	protected boolean isCompeletedData(OIV10802 data) {
		return true;
	}

	@Override
	public boolean isTargetFile(File file) {
		return file.getName().endsWith(".#FIN");
	}

	@Override
	protected void onData(int index, String line, OIV10802 data) throws Exception {

		// System.out.println(index + ", " + line + " , " + data);

		uploader.add(data);

	}

	@Override
	protected void onFinished(File file, int size, Exception ex) {
		try {
			uploader.close(ex);
			dstTran.commit();
			Logger.logger.info("FILE({}) DATA-COUNT({})", file.getName(), size);
		} catch (Exception e) {
			dstTran.rollback();
			Logger.logger.error(e);
			ex = e;
		} finally {
			backup(file, ex);
			dstTran.stop();
		}
	}

	@Override
	protected void onStart(File file) throws Exception {
		FxTmpQid QID = new FxTmpQid();
		
		dstTran = DBManager.getMgr().getDataBase(CmDao.ADAMS).createDbTrans("deploy/conf/sql/" + FxTmpQid.QUERY_XML_FILE);
		dstTran.start();
		
		uploader = new Upload2DbNew<OIV10802>(dstTran, "OIV10802", QID.MERGE_OIV10802__BY_AP);
		Logger.logger.debug(file);
	}

	@SuppressWarnings("rawtypes")
	@Override
	protected OIV10802 parse(String line) throws Exception {
		Map map = gson.fromJson(line, Map.class);
		OIV10802 o802 = new OIV10802();
		
		o802.setEqpUptimeCnt(getValLong(map.get("uptime"),0L));
		
		o802.setEqpVerInfo(getValStr(map.get("ver")));
		o802.setIpAddr(getValStr(map.get("ip")));
		o802.setIptvSvcModeVal(null);
		o802.setMacAddrVal(getValStr(map.get("mac")));
		o802.setOutLnkgIpAddr(getValStr(map.get("#src-ip")));
		o802.setPatchGrpCtt(null);
		o802.setTrapRcvDtm(getValTimestamp(map.get("mtime")));
		o802.setWeqpMdlNm(getValStr(map.get("sys")));

		return o802;
	}
}
