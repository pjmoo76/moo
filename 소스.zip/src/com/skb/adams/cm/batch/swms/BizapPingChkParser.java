package com.skb.adams.cm.batch.swms;

import java.io.File;
import java.util.Map;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.log.Logger;

import com.google.gson.Gson;
import com.skb.adams.cm.batch.BasFileParser;
import com.skb.adams.cm.batch.Upload2DbNew;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.FxTmpQid;
import com.skb.adams.cm.model.OIV10801;

public class BizapPingChkParser extends BasFileParser<OIV10801> {

	public static void main(String[] args) {
		BizapPingChkParser parser = new BizapPingChkParser();
		File folder = new File("datas/swms/bizap_ping_chk");
		parser.parseFolder(folder);

	}

	private Gson gson = new Gson();
	private Upload2DbNew<OIV10801> uploader;
	private DbTrans dstTran;

	public BizapPingChkParser() {

	}

	@Override
	protected boolean isCompeletedData(OIV10801 data) {
		return true;
	}

	@Override
	public boolean isTargetFile(File file) {
		return file.getName().endsWith(".#FIN");
	}

	@Override
	protected void onData(int index, String line, OIV10801 data) throws Exception {
		uploader.add(data);
	}

	@Override
	protected void onFinished(File file, int size, Exception ex) {
		try {
			uploader.close(ex);

			dstTran.commit();

			Logger.logger.info("FILE({}) DATA-COUNT({})", file.getName(), size);

		} catch (Exception e) {
			dstTran.rollback();
			Logger.logger.error(e);
			ex = e;
		} finally {
			backup(file, ex);
			dstTran.stop();
		}
	}

	@Override
	protected void onStart(File file) throws Exception {
		FxTmpQid QID = new FxTmpQid();

		dstTran = DBManager.getMgr().getDataBase(CmDao.ADAMS).createDbTrans("deploy/conf/sql/" + FxTmpQid.QUERY_XML_FILE);
		dstTran.start();

		uploader = new Upload2DbNew<OIV10801>(dstTran, "OIV10801", QID.MERGE_OIV10801);
		Logger.logger.debug(file);
	}

	@SuppressWarnings("rawtypes")
	@Override
	protected OIV10801 parse(String line) throws Exception {
		Map map = gson.fromJson(line, Map.class);
		OIV10801 o801 = new OIV10801();

		o801.setPingStVal(getValInt(map.get("result"), 0) + "");
		o801.setMacAddrVal(getValStrToUpperCase(map.get("mac")));
		o801.setIpAddr(getValStr(map.get("ip")));
		o801.setLastPingStCheckDtm(getValHstime(map.get("utime")));

		return o801;
	}
}