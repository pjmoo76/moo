package com.skb.adams.cm.batch.swms;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.log.Logger;

import com.google.gson.Gson;
import com.skb.adams.cm.CmCode;
import com.skb.adams.cm.batch.BasFileParser;
import com.skb.adams.cm.batch.Upload2DbNew;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.FxTmpQid;
import com.skb.adams.cm.model.OIV10821;

public class ApPortScanParser extends BasFileParser<OIV10821> {

	public static void main(String[] args) {
		ApPortScanParser parser = new ApPortScanParser();
		File folder = new File("datas/swms/ap_port_scan");
		parser.parseFolder(folder);
	}

	private final String USAGE_ETC = "ETC";
	@SuppressWarnings("unused")
	private final String USAGE_STB = "STB";
	@SuppressWarnings("unused")
	private final String USAGE_TEL = "TEL";
	@SuppressWarnings("unused")
	private final String USAGE_AP = "AP";

	private Gson gson = new Gson();
	private Upload2DbNew<OIV10821> uploader;
	private DbTrans dstTran;

	public ApPortScanParser() {
		// super("utf-8");
	}

	// protected void onStartFolder(File folder, List<File> fileList) throws
	// Exception {
	// Logger.logger.debug(folder.getName() + " :  " + fileList);
	// uploader = new Upload2Db<OIV10821>("OIV10821", new
	// FxTmpQid().MERGE_OIV10821);
	// }
	//
	// @Override
	// protected void onFinishedAll(File folder) {
	// Logger.logger.debug(folder.getPath());
	//
	// try {
	// uploader.close(null);
	// } catch (Exception e) {
	// Logger.logger.error(e);
	// } finally {
	// }
	// }

	@Override
	protected boolean isCompeletedData(OIV10821 data) {
		return true;
	}

	@Override
	public boolean isTargetFile(File file) {
		return file.getName().endsWith(".#FIN");
	}

	private OIV10821 make821(OIV10821 o821, String mac, String mkr) {
		OIV10821 o = new OIV10821();

		o.setPrvShrrIpAddr(null);
		o.setPrvShrrLinkClCd(CmCode.PrvShrrLinkClCd.LINK_AP.getCode());
		o.setPrvShrrMacAddr(mac);
		o.setPrvShrrMfactNm(mkr);
		o.setRgstDt(o821.getRgstDt());
		o.setWeqpIpAddr(o821.getWeqpIpAddr());
		o.setWeqpMacAddr(o821.getWeqpMacAddr());

		return o;
	}

	@Override
	protected void onData(int index, String line, OIV10821 data) throws Exception {

		if (data.getPrvShrrMacAddr().length() > 1) {

			if (data.getWeqpIpAddr().startsWith("192.168.0") //
					|| data.getWeqpIpAddr().startsWith("192.168.1") //
					|| data.getWeqpIpAddr().startsWith("10.")) {
				// 사설IP이면 사설공유기 하단으로 판단한다.
				data.setPrvShrrLinkClCd(CmCode.PrvShrrLinkClCd.LINK_PRV_AP_SKBAP.getCode());
				uploader.add(data);
			} else {
				// 사설공유기가 AP하부에 있다고 판단한다.
				data.setPrvShrrLinkClCd(CmCode.PrvShrrLinkClCd.LINK_AP.getCode());
				uploader.add(data);
			}
		}

	}

	@Override
	protected void onFinished(File file, int size, Exception ex) {
		try {
			uploader.close(ex);
			dstTran.commit();

			Logger.logger.info("FILE({}) DATA-COUNT({})", file.getName(), size);

		} catch (Exception e) {
			dstTran.rollback();
			Logger.logger.error(e);
			ex = e;
		} finally {
			backup(file, ex);
			dstTran.stop();
		}
	}

	@Override
	protected void onStart(File file) throws Exception {

		dstTran = DBManager.getMgr().getDataBase(CmDao.ADAMS).createDbTrans("deploy/conf/sql/" + FxTmpQid.QUERY_XML_FILE);
		dstTran.start();
		
		uploader = new Upload2DbNew<OIV10821>(dstTran, "OIV10821", new FxTmpQid().MERGE_OIV10821) {
			private Map<String, String> keyMap = new HashMap<String, String>();

			@Override
			public void add(OIV10821 data) throws Exception {
				if (keyMap.get(data.getWeqpMacAddr() + "," + data.getPrvShrrMacAddr()) == null) {
					keyMap.put(data.getWeqpMacAddr() + "," + data.getPrvShrrMacAddr(), "1");
					super.add(data);
				}
			}
		};

		Logger.logger.debug(file);
	}

	@SuppressWarnings("rawtypes")
	@Override
	protected OIV10821 parse(String line) throws Exception {

		Map map = gson.fromJson(line, Map.class);
		String mac, usage, mkr;
		OIV10821 o821 = new OIV10821();

		o821.setPrvShrrIpAddr(getValStr(map.get("PRIV_IP")));
		o821.setPrvShrrMacAddr(getValStr(map.get("PRIV_MAC")));
		o821.setPrvShrrMfactNm(getValStr(map.get("PRIV_MKR")));
		o821.setRgstDt(getValYyyymmdd(map.get("YMD")));
		o821.setWeqpIpAddr(getValStr(map.get("AP_IP")));
		o821.setWeqpMacAddr(getValStr(map.get("DEV_MAC")));

		// if ("00904C08000A".equals(o821.getPrvShrrMacAddr())) {
		// System.out.println(line);
		// }

		for (int i = 1; i <= 4; i++) {
			mac = getValStr(map.get("PORT" + i + "_MAC"));
			usage = getValStr(map.get("PORT" + i + "_USAGE"));
			mkr = getValStr(map.get("PORT" + i + "_MKR"));

			if (mac.length() == 12 && USAGE_ETC.equals(usage)) {
				if (mac.equals("000000000000") == false) {

					uploader.add(make821(o821, mac, mkr));

					// if ("00904C08000A".equals(mac)) {
					// System.out.println(line);
					// }

				}
			}
		}

		return o821;
	}

}

/*
 * {"PORT4_USAGE": "", "INET_SERVICE_NUM": "7264479401", "TV_SVCMGMT_NUM":
 * "7264479402", "INET_SVCMGMT_NUM": "7264479401", "HP_CTR_NM":
 * "\uc6b8\uc0b0\uc911\ubd80Home\uc13c\ud130", "PORT3_USAGE": "", "CUST_NUM":
 * "8030134005", "PRIV_MAC": "", "SVC_TECH_CODE": "B0039", "PORT1_MAC": "",
 * "PORT2_MAC": "", "TEL_SERVICE_NUM": " ****", "AREA1_CD": "D10100", "NETWORK":
 * "1", "PRIV_MKR": "", "TEL_SERVICE_NM": " ", "UDEV2_MODEL": "OLT SG7000G",
 * "PORT2_USAGE": "", "UDEV1_NUM": "NR023080
 * ", "DEV_MKR": "", "UDEV1_TID": "\ub0a8\uc6b8\uc0b0FTTH_OLT
 * #5(SG7000G)", "PORT3_MKR
 * ": "", "CUST_NM": "\uc774*\uc601", "PORT4_MKR": "", "UDEV2_MKR
 * ": "\uc9c0\ud53c\uc2dc\uc2a4
 * (HTTH)", "PORT2_MKR": "", "PORT4_MAC": "", "AREA2_CD": "D10100",
 * "PORT1_USAGE": "", "DEV_MAC": "085DDDDF50F4", "TV_SERVICE_NUM": "7264479402",
 * "YMD": "2017-12-26 17:27:50", "AREA1_NM":
 * "\ub0a8\uc6b8\uc0b0\uc815\ubcf4\uc13c\ud130", "TV_SERVICE_NM":
 * "Btv(IPTV_UHD_STB)", "INET_SERVICE_NM": "\uad11\ub79cF
 * TTH(GB)", "TEAM_NM": "\ubd80\uc0b0\ud488\uc9c8\uc194\ub8e8\uc158\ud300
 * ", "UDEV2_TID
 * ": "\ub0a8\uc6b8\uc0b0FTTH_OLT#5(SG7000G)", "PORT3_MAC": "", "UDEV2_NUM
 * ": "NR023080
 * ", "AP_IP": "219.250.187.44", "HP_CTR_CD": "1003002214", "PORT1_MKR": "
 * ", "TEAM_CD": "T108", "TEL_SVCMGMT_NUM": "0", "DEV_MODEL": "Giga
 * AP(\uba38\ud050\ub9ac
 * RUSH-337AC)", "AREA2_NM": "\ub0a8\uc6b8\uc0b0\uc815\ubcf4\uc13c\ud130
 * ", "UDEV2_CELL": "", "UDEV1_MODEL": "OLT SG7000G", "PRIV_IP": ""}
 */