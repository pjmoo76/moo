package com.skb.adams.cm.batch;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import subkjh.bas.log.Logger;
import fxms.bas.fxo.fxa.FxAImpl;
import fxms.bas.fxo.thread.QueueFxThread;

public class BatchData extends FxAImpl {

	private List<Batcher> batcherList;
	private final String FOLDER = "folder";
	private final String BATCHER = "batcher";
	private Runner runner;
	private File folder;

	public BatchData() {
		batcherList = new ArrayList<Batcher>();
	}

	public List<Batcher> getBatcherList() {
		return batcherList;
	}

	public File getFolder() {
		return folder;
	}

	@Override
	public void onCreated() {

	}

	public void set(String name, Object value) {

		super.set(name, value);

		if (name.equals(FOLDER)) {
			folder = new File(value.toString());
			return;
		}

		if (name.equals(BATCHER)) {

			String ss[] = value.toString().split(":");
			if (ss.length != 2) {
				return;
			}

			String filePrefix = ss[0].trim();
			String javaClass = ss[1].trim();

			try {
				Batcher batcher = (Batcher) Class.forName(javaClass).newInstance();
				batcher.setFilePrefix(filePrefix);
				runner = new Runner(getName());
				runner.start();
				batcherList.add(batcher);
			} catch (Exception e) {
				Logger.logger.error(e);
				super.set(name, value);
			}
		}
	}

	public void setBatcherList(List<Batcher> batcherList) {
		this.batcherList = batcherList;
	}

	public void setFolder(File folder) {
		this.folder = folder;
	}

	public void checkFile() {
		for (Batcher b : batcherList) {
			for (File f : folder.listFiles()) {
				if (f.getName().startsWith(b.getFilePrefix() + "_")) {
					File fileToMove = new File(f.getParent() + File.separator + "proc_" + f.getName());
					if (f.renameTo(fileToMove)) {
						runner.add(new RunData(b, fileToMove));
						break;
					}
				}
			}
		}
	}

	class RunData {
		RunData(Batcher batcher, File file) {
			this.batcher = batcher;
			this.file = file;
		}

		Batcher batcher;
		File file;
	}

	class Runner extends QueueFxThread<RunData> {

		public Runner(String name) {
			super(name, 0);
		}

		@Override
		protected void onNoDatas(long index) {

		}

		@Override
		protected void doWork(RunData data) throws Exception {
			data.batcher.runBatch(data.file);
		}

		@Override
		protected void doInit() {

		}

	}

}