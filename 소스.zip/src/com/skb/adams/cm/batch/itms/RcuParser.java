package com.skb.adams.cm.batch.itms;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.log.Logger;

import com.google.gson.Gson;
import com.skb.adams.cm.batch.BasFileParser;
import com.skb.adams.cm.batch.Upload2DbNew;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.FxTmpQid;
import com.skb.adams.cm.dao.ParaMap;
import com.skb.adams.cm.dao.ParaQid;
import com.skb.adams.cm.model.OIV10803;

public class RcuParser extends BasFileParser<OIV10803> {

	public static void main(String[] args) {
		RcuParser parser = new RcuParser();

		File folder = new File("datas/itms/rcu");
		parser.parseFolder(folder);

	}

	private Gson gson = new Gson();
	private Upload2DbNew<OIV10803> uploader803;
	private ParaMap teamMap;
	private ParaMap stbMdlMap;
	private DbTrans dstTran;

	public RcuParser() {

	}

	@Override
	protected boolean isCompeletedData(OIV10803 data) {
		return true;
	}

	@Override
	public boolean isTargetFile(File file) {
		return file.getName().endsWith(".#FIN");
	}

	@Override
	protected void onData(int index, String line, OIV10803 data) throws Exception {

		if (data.getMacAddrVal().length() == 0) {
			return;
		}

		if (data.getVerInfo().length() == 0) {
			data.setVerInfo("-");
		}

		if (data.getFwVerNum().length() == 0) {
			data.setFwVerNum("-");
		}

		uploader803.add(data);

	}

	@Override
	protected void onFinished(File file, int size, Exception ex) {

		try {
			uploader803.close(ex);
			dstTran.commit();
			Logger.logger.info("FILE({}) DATA-COUNT({})", file.getName(), size);

		} catch (Exception e) {
			dstTran.rollback();
			Logger.logger.error(e);
			ex = e;
		} finally {
			
			// RCU는 DB 장애인 경우엔 다음에 다시 시도해야 하므로 백업하지 않는다.			
			if ( ( ex instanceof IOException) == false ) {
				backup(file, ex);
			}
			
			dstTran.stop();
		}
	}

	@Override
	protected void onStart(File file) throws Exception {
		ParaQid QID = new ParaQid();

		dstTran = DBManager.getMgr().getDataBase(CmDao.ADAMS).createDbTrans("deploy/conf/sql/" + FxTmpQid.QUERY_XML_FILE);
		dstTran.start();

		uploader803 = new Upload2DbNew<OIV10803>(dstTran, "OIV10803", new FxTmpQid().MERGE_OIV10803);

		teamMap = new ParaMap(QID.SELECT_TEAM);
		stbMdlMap = new ParaMap(QID.SELECT_STB_MDL);
		Logger.logger.debug(file);
	}

	@SuppressWarnings("rawtypes")
	@Override
	protected OIV10803 parse(String line) throws Exception {
		Map map = gson.fromJson(line, Map.class);
		OIV10803 o803 = new OIV10803();

		o803.setEqpMdlCd(getValStr(map.get("RCU_MODEL")));
		o803.setEtcCtt(getValStr(map.get("ETC")));
		o803.setFwVerNum(getValStr(map.get("RCU_FIRMWARE_VERSION")));
		o803.setHomeCntrCd(getValStr(map.get("HP_CTR_CD")));
		o803.setIptvSvcMgmtNum(getValLong(map.get("TV_SVCMGMT_NUM"), 0));
		o803.setMacAddrVal(getValStr(map.get("RCU_MAC")));
		o803.setMfactNm(getValStr(map.get("RCU_MANUFACTURER_CODE")));
		o803.setRgstDtm(getValStr(map.get("EVENT_TS")).replaceAll("_|-", ""));
		o803.setStbMacAddrVal(getValStrToUpperCase(map.get("STB_MAC")));
		o803.setStbMdlNm(getValStr(map.get("STB_MODEL")));
		o803.setStbVerInfo(getValStr(map.get("STB_VER")));
		o803.setTeamOrgId(getValStr(map.get("TEAM_NM")));
		o803.setTpoCd(getValStr(map.get("AREA2_CD")));
		o803.setVerInfo(getValStr(map.get("RCU_VER")));

		o803.setTeamOrgId(teamMap.getParaCode(o803.getTeamOrgId().replaceFirst("팀", "")));
		o803.setEqpMdlCd(stbMdlMap.getParaCode(o803.getStbMdlNm()));

		return o803;
	}
}