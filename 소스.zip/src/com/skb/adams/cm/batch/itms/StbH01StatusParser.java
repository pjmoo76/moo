package com.skb.adams.cm.batch.itms;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.log.Logger;

import com.google.gson.Gson;
import com.skb.adams.cm.batch.BasFileParser;
import com.skb.adams.cm.batch.Upload2DbNew;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.FxTmpQid;
import com.skb.adams.cm.model.OIV10801;
import com.skb.adams.cm.model.OIV10802;

public class StbH01StatusParser extends BasFileParser<OIV10802> {

	public static void main(String[] args) {
		StbH01StatusParser parser = new StbH01StatusParser();
		File folder = new File("datas/itms/stb_h01_status");
		parser.parseFolder(folder);
	}

	private Gson gson = new Gson();
	private Upload2DbNew<OIV10802> uploader802;
	// private Upload2DbNew<OIV10801> uploader801;
	private DbTrans dstTran;
	private Map<String, String> dupMacCheckMap = new HashMap<String, String>();
	private int dupMacCnt;

	public StbH01StatusParser() {
	}

	@Override
	protected boolean isCompeletedData(OIV10802 data) {
		return true;
	}

	@Override
	public boolean isTargetFile(File file) {
		return file.getName().endsWith(".#FIN");
	}

	@Override
	protected void onData(int index, String line, OIV10802 data) throws Exception {

		// debug
		if (data.getEqpVerInfo().length() > 100) {
			Logger.logger.fail(index + ", " + line + " , " + data);
			return;
		}

		if (data.getMacAddrVal() != null) {
			if (dupMacCheckMap.get(data.getMacAddrVal()) != null) {
				dupMacCnt++;
				return;
			}

			dupMacCheckMap.put(data.getMacAddrVal(), data.getMacAddrVal());
		}

		uploader802.add(data);

	}

	@Override
	protected void onFinished(File file, int size, Exception ex) {
		try {
			uploader802.close(ex);
			// uploader801.close(ex);

			dstTran.commit();

			Logger.logger.info("FILE({}) DATA-COUNT({}) DUP={}", file.getName(), size, dupMacCnt);

		} catch (Exception e) {
			dstTran.rollback();
			Logger.logger.error(e);
			ex = e;
		} finally {
			backup(file, ex);
			dstTran.stop();
		}
	}

	@Override
	protected void onStart(File file) throws Exception {
		FxTmpQid QID = new FxTmpQid();

		dupMacCheckMap.clear();
		dupMacCnt = 0;

		dstTran = DBManager.getMgr().getDataBase(CmDao.ADAMS).createDbTrans("deploy/conf/sql/" + FxTmpQid.QUERY_XML_FILE);
		dstTran.start();

		uploader802 = new Upload2DbNew<OIV10802>(dstTran, "OIV10802", QID.MERGE_OIV10802__BY_STB);
		// uploader801 = new Upload2DbNew<OIV10801>(dstTran, "OIV10801",
		// QID.MERGE_OIV10801);

		Logger.logger.debug(file);
	}

	@SuppressWarnings("rawtypes")
	@Override
	protected OIV10802 parse(String line) throws Exception {
		Map map = gson.fromJson(line, Map.class);
		OIV10802 o802 = new OIV10802();

		o802.setEqpUptimeCnt(getValLong(map.get("SYS_RUNNING_TIME"), 0L));
		o802.setEqpVerInfo(getValStr(map.get("STB_SW_VER")));
		o802.setIpAddr(getIPv4(map.get("S_NET_IPADDR")));
		o802.setIptvSvcModeVal(getValStr(map.get("STB_SVC_MODE")));
		o802.setMacAddrVal(getValStrToUpperCase(map.get("STB_MAC")));
		o802.setOutLnkgIpAddr(getIPv4(map.get("_REMOTE_ADDR")));
		// o802.setPatchGrpCtt(null);
		o802.setTrapRcvDtm(getValTimestamp(map.get("X_UPD_TS")));
		// o802.setWeqpMdlNm(null);

		// OIV10801 o801 = new OIV10801();
		// o801.setPingStVal("1");
		// o801.setMacAddrVal(o802.getMacAddrVal());
		// o801.setIpAddr(o802.getIpAddr());
		// o801.setLastPingStCheckDtm(getValHstime(o802.getTrapRcvDtm()));
		// o801.setPingStChgDtm(o802.getTrapRcvDtm());
		// uploader801.add(o801);

		return o802;
	}
}