package com.skb.adams.cm.batch.itms;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.batch.BasFileParser;
import com.skb.adams.cm.batch.Upload2DbNew;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.FxTmpQid;
import com.skb.adams.cm.model.OIV10801;
import com.skb.adams.cm.model.OIV10802;

public class SdsStbInfoParser extends BasFileParser<OIV10802> {

	public static void main(String[] args) {
		SdsStbInfoParser parser = new SdsStbInfoParser();

		File folder = new File("datas/itms/sds_stb_info");
		parser.parseFolder(folder);

	}

	private DbTrans dstTran;
	private Upload2DbNew<OIV10802> uploader802;
	private Upload2DbNew<OIV10801> uploader801;
	private final int STB_MAC = 0;
	//	private final int SVC_MGMT_NUM = 1;
	// private final int VERSION = 2;
	private final int ST_VERSION = 2; //3->2 chg ics 2020-08-14 
	private final int UPTIME = 4;
	private final int STB_LOCAL_IP = 5;
	private final int STB_REAL_IP = 6;
	private final int SDS_PATCH_GROUP = 7;
	private final int STB_LAST_UTIME = 8;

	public SdsStbInfoParser() {
		super("utf-8");
	}

	@Override
	protected boolean isCompeletedData(OIV10802 data) {
		return true;
	}

	@Override
	public boolean isTargetFile(File file) {
		return file.getName().endsWith(".#FIN");
	}

	@Override
	protected void onData(int index, String line, OIV10802 data) throws Exception {

		// System.out.println(index + ", " + line + " , " + data);

		uploader802.add(data);

	}

	@Override
	protected void onFinished(File file, int size, Exception ex) {
		try {
			uploader802.close(ex);
			uploader801.close(ex);
			
			dstTran.commit();

			Logger.logger.info("FILE({}) DATA-COUNT({})", file.getName(), size);

		} catch (Exception e) {
			dstTran.rollback();
			Logger.logger.error(e);
			ex = e;
		} finally {
			dstTran.stop();
			backup(file, ex);
		}
	}

	@Override
	protected void onStart(File file) throws Exception {
		FxTmpQid QID = new FxTmpQid();
		
		dstTran = DBManager.getMgr().getDataBase(CmDao.ADAMS).createDbTrans("deploy/conf/sql/" + FxTmpQid.QUERY_XML_FILE);
		dstTran.start();

		uploader802 = new Upload2DbNew<OIV10802>(dstTran, "OIV10802", QID.MERGE_OIV10802_UPDATE__BY_SDS_STB_INFO, QID.MERGE_OIV10802_INSERT__BY_SDS_STB_INFO);
		uploader801 = new Upload2DbNew<OIV10801>(dstTran, "OIV10801", QID.MERGE_OIV10801);
		
		Logger.logger.debug(file);
	}

	@Override
	protected OIV10802 parse(String line) throws Exception {

		StringBuffer sb = new StringBuffer();
		List<String> list = new ArrayList<String>();
		char chs[] = line.toCharArray();
		for (int i = 0; i < chs.length; i++) {
			// if (i > 0 && chs[i] == '|' && chs[i - 1] == '\\') {
			// sb.append(chs[i]);
			// } else
			if (chs[i] == '|') {
				list.add(sb.toString());
				sb = new StringBuffer();
			} else {
				sb.append(chs[i]);
			}
		}

		list.add(sb.toString());

		OIV10802 o802 = new OIV10802();

		o802.setEqpUptimeCnt(getValUptime(list.get(UPTIME)));
		o802.setEqpVerInfo(list.get(ST_VERSION));
		o802.setIpAddr(list.get(STB_LOCAL_IP));
		o802.setIptvSvcModeVal(null);
		o802.setMacAddrVal(getValMac(list.get(STB_MAC)));
		o802.setOutLnkgIpAddr(list.get(STB_REAL_IP));
		o802.setPatchGrpCtt(list.get(SDS_PATCH_GROUP));
		o802.setTrapRcvDtm(getValTimestampByDate(list.get(STB_LAST_UTIME)));
		o802.setWeqpMdlNm(null);

		// System.out.println(ObjectUtil.toMap(o802));

		OIV10801 o801 = new OIV10801();
		o801.setPingStVal("1");
		o801.setMacAddrVal(o802.getMacAddrVal());
		o801.setIpAddr(o802.getIpAddr());
		o801.setLastPingStCheckDtm(getValHstime(o802.getTrapRcvDtm()));
		o801.setPingStChgDtm(o802.getTrapRcvDtm());
		uploader801.add(o801);

		return o802;
	}
}