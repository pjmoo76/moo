package com.skb.adams.cm.batch.itms;

import java.io.File;
import java.util.Map;

import subkjh.bas.log.Logger;
import subkjh.bas.utils.ObjectUtil;

import com.google.gson.Gson;
import com.skb.adams.cm.CmCode;
import com.skb.adams.cm.batch.BasFileParser;
import com.skb.adams.cm.model.OIV10821;

public class NatallParser extends BasFileParser<OIV10821> {

	public static void main(String[] args) {
		NatallParser parser = new NatallParser();
		File folder = new File("datas/itms/natall");
		parser.parseFolder(folder);
	}

	private Gson gson = new Gson();

	// private Upload2Db<OIV10821> uploader;

	public NatallParser() {
		// super("utf-8");
	}

	@Override
	protected boolean isCompeletedData(OIV10821 data) {
		return true;
	}

	@Override
	public boolean isTargetFile(File file) {
		return file.getName().endsWith(".#FIN");
	}

	@Override
	protected void onData(int index, String line, OIV10821 data) throws Exception {

		if (data.getWeqpMacAddr().length() == 12) {
			if (data.getPrvShrrMacAddr().length() == 12) {
				// uploader.add(data);
			}
		}

	}

	@Override
	protected void onFinished(File file, int size, Exception ex) {
		try {
			// uploader.close(ex);
			Logger.logger.info("FILE({}) DATA-COUNT({})", file.getName(), size);
		} catch (Exception e) {
			Logger.logger.error(e);
		} finally {
			backup(file, ex);
		}
	}

	@Override
	protected void onStart(File file) throws Exception {

		// uploader = new Upload2Db<OIV10821>("OIV10821", new
		// FxTmpQid().MERGE_OIV10821);

		Logger.logger.debug(file);
	}

	@SuppressWarnings("rawtypes")
	@Override
	protected OIV10821 parse(String line) throws Exception {

		// NATALL의 내용을 망직연동으로 표현하고 있음
		// 또한 사설AP - STB 연동으로도 표현하고 있음.

		Map map = gson.fromJson(line, Map.class);
		OIV10821 o821 = new OIV10821();

		o821.setPrvShrrIpAddr(getValStr(map.get("IPADDRESS")));
		o821.setPrvShrrLinkClCd(CmCode.PrvShrrLinkClCd.LINK_PRV_AP_STB.getCode());
		o821.setPrvShrrMacAddr(getValStr(map.get("MAC")));
		o821.setPrvShrrMfactNm(getValStr(map.get("MKR")));
		o821.setRgstDt(getValYyyymmdd(map.get("YMD")));
		o821.setWeqpIpAddr(null);
		o821.setWeqpMacAddr(getValStr(map.get("STB_MAC")));

		System.out.println(ObjectUtil.toMap(o821));

		return o821;
	}
}

// {"UDEV1_CELL": "", "A_BLD_CAT": "", "INET_SERVICE_NUM": "7258573181",
// "TV_SVCMGMT_NUM": "7258573182", "STB_MODEL":
// "STB(\ud734\ub9e5\uc2a4 BHX-S100)", "CUST_TEL": "****", "A_SVC_CONN_NUM
// ": "", "UDEV1_RACK": "01", "UDEV2_SHELF": "01", "UDEV2_IP": "211.215.78.40", "CUST_NUM": "9064556219", "MKR": "EFM
// Networks", "UDEV1_CARD": "023", "CUST_NM": "\ubc15*\ub839", "UDEV1_SHEL
// F": "01", "SVC_TECH_CODE": "B0032", "UDEV2_NUM": "NR018326", "TEL_SERVICE_NUM": "
// ****", "AREA1_CD": "D10100", "NETWORK": "1", "TEL_SERVICE_NM": "
// ", "UDEV2_MODEL": "OLT V5848G", "TEL_SE
// RVICE_ST": "
// ", "ONT_SERIAL": "01-01-3-00004-00002", "UDEV1_PORT": "00002", "UDEV1_NUM": "NR018326", "TV_CIRCUIT_CNT": "2", "UDEV1_MKR": "(\uc8fc)\ub2e4\uc0b0\ub124\ud2b8\uc6cd\uc2a4", "
// BJD_CD": "", "TV_IPTV_OK": "Y", "UDEV2_PORT": "00002", "UDEV2_CELL": "", "UDEV1_TID": "FTTH_OLT_\ub9e4\uace1\uc6d4\ub4dc\uba54\ub974\ub514\uc5592\ub2e8\uc9c0", "INET_SVCMGMT_NUM": "72585
// 73181", "CUST_ADDR": "\uc6b8\uc0b0 \ubd81\uad6c \ub9e4\uc0b0\ub85c
// 66,", "UDEV2_MKR": "(\uc8fc)\ub2e4\uc0b0\ub124\ud2b8\uc6cd\uc2a4", "AREA2_CD": "N38163", "TV_SERVICE_NUM": "7258573182"
// , "RN_TAB_ID": "", "TV_SERVICE_ST": "AC", "YMD": "2017-12-28 00:00:00",
// "PAYER_NUM": "6166712962", "TV_SERVICE_NM": "Btv(IPTV_smart STB)",
// "INET_SERVICE_NM": "\uad11\ub79cFTTH", "TEAM_NM
// ": "\ubd80\uc0b0\ud488\uc9c8\uc194\ub8e8\uc158\ud300", "UDEV2_TID": "FTTH_OLT_\ub9e4\uace1\uc6d4\ub4dc\uba54\ub974\ub514\uc5592\ub2e8\uc9c0", "UDEV2_RACK": "01", "INET_SERVICE_ST": "AC",
// "AREA1_NM": "\ub0a8\uc6b8\uc0b0\uc815\ubcf4\uc13c\ud130", "UDEV1_IP":
// "211.215.78.40", "STB_MAC": "2832C56BE6F6", "HP_CTR_CD": "0002029056",
// "UDEV2_CARD": "3", "TEAM_CD": "T108", "TEL_S
// VCMGMT_NUM": "0", "MAC": "909F33A50A49", "AREA2_NM": "FTTH_\ub9e4\uace1\uc6d4\ub4dc\uba54\ub974\ub514\uc5592\ub2e8\uc9c0", "TEL_POLE_NO": "", "UDEV1_MODEL": "OLT
// V5848G", "IPADDRESS": "1
// 16.123.252.165", "HP_CTR_NM": "\uc6b8\uc0b0\uc911\ubd80Home\uace0\uac1d\uc13c\ud130"}

