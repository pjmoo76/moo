package com.skb.adams.cm.batch;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;

import com.skb.adams.cm.dao.CmDao;

public class OrgFileParser extends FileParser {

	private Map<String, List<String>> orgMap = new HashMap<String, List<String>>();

	/**
	 * key : 정보센터코드, val : 팀조직ID
	 */
	private Map<String, String> centerMap = new HashMap<String, String>();
	
	

	public static void main(String[] args) {
		OrgFileParser p = new OrgFileParser();

		p.parseFolder(new File("datas/bos2"));

		System.out.println("----------------------------------------------------------");

		System.out.println("Table Name\tOIV10907");
		System.out.println("TEAM_ORG_ID\tORG_ID\tORG_NM\tCNTR_ORG_CL_CD");
		for (String key : p.orgMap.keySet()) {
			String teamId = p.centerMap.get(key);
			if (teamId == null) {
				continue;
			}

			for (String e : p.orgMap.get(key)) {
				System.out.println(teamId + "\t" + e + "\t" + 1);
			}
		}

	}

	public OrgFileParser() {
		
		super(71);
		
		DbTrans tran = null;

		try {
			tran = DBManager.getMgr().getDataBase(CmDao.ADAMS).createDbTrans("deploy/conf/sql/neifdb.xml");
			tran.start();
			List<Map<String, Object>> mapList = tran.selectSql2Map("select TPO_CD, TEAM_ORG_ID from OIV10301", null);
			for (Map<String, Object> map : mapList) {
				centerMap.put(map.get("TPO_CD") + "", map.get("TEAM_ORG_ID") + "");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (tran != null) {
				tran.stop();
			}
		}

	}

	@Override
	protected void onData(int index, String line, List<String> dataList) throws Exception {
		
		if (dataList.size() < 71) {
			System.out.println(">>> " + line);
			return;
		}

		String centerCd = dataList.get(31);
//		String centerNm = dataList.get(32);
		if (centerCd == null || centerCd.length() == 0) {
			return;
		}

		String hcenter = dataList.get(61) + "\t" + dataList.get(62);

		List<String> entry = orgMap.get(centerCd);
		if (entry == null) {
			entry = new ArrayList<String>();
			orgMap.put(centerCd, entry);
		}
		if (entry.contains(hcenter) == false) {
			entry.add(hcenter);
			// System.out.println(centerCd + "\t" + hcenter);
		}

	}

	@Override
	public boolean isTargetFile(File file) {
		return file.getName().startsWith("BOS2IFNMS");
	}
}
