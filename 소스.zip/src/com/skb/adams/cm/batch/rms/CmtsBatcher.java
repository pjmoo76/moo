package com.skb.adams.cm.batch.rms;

import java.io.File;

import com.skb.adams.cm.batch.Batcher;

/**
 * @deprecated 테스트용
 * @author SUBKJH-DEV
 *
 */
public class CmtsBatcher extends Batcher {

	public static void main(String[] args) {
		CmtsBatcher batcher = new CmtsBatcher();
		try {
			batcher.runBatch(new File("datas/cmts_20171107-011501.unl"));
		} catch (Exception e) {
			e.printStackTrace();
		}

		// batcher.onRead("172.23.0.63|WB412010|06|150|N01111|J10100|2838|GoYang_CBR_W10#|GoYang_CBR_W10.skbroadband.com||||WB412010|1|172.23.225.36|1|||5424|15.6(2)SP1a|hfc300aks|IOS-XE ROMMON||15.5(3)S1 , 15.6(2)SP1a , 15.6(1)S1|2017110701|���籹�� 4�� �� ��� ��||helpme|pos1004|||1||||24790591.0|1|||0|||1509967816|201711070105|bootflash:cbrsup-universalk9.03.18.01a.SP.156-2.SP1a-ext.SPA.bi|reload||||1|");
		// batcher.onRead("|TEQ442K05_SDV|06|200|N21754||6010|||||||||||||03.09.00.015|hfc300aks|||01.06.04.006 , 02.07.07.001 , 03.11.00.013 , 03.09.00.015|2016060304|�ȴޱ���|40G|||||1||||32405196.0|||||||1505682047|201709180630||||||1|");
	}

	public CmtsBatcher() {
		setLength(50);
	}

	@Override
	protected String[] getColumns() {
		String columns[] = {

		"CMTSID", "CMTSNAME", "AREACODE", "SOCODE", "TPO_CD"// 5
				, "MG_TPO_CD", "DEVTYPE", "PROMPT", "SYSNAME", "TELNO"// 10
				, "MODELNAME", "CHASSISTYPE", "TID", "MANG_TYPE", "MGR_DHCP"// 15
				, "ASSET_TYPE", "CAR_CONFORMED", "LOADBALANCE", "IFCOUNT", "HVERSION"// 20
				, "COMMUNITY", "SVERSION", "REG_CONFIG", "FROMOSS_SVERSION", "WRK_DT"// 25
				, "SETUPPOSITION", "DESCRIPTION", "LGNAME", "LGPWD", "ENPWD"// 30
				, "PING", "USED", "VOLTSTATE", "TEMPSTATE", "POWERSTATE"// 35
				, "SYSUPTIME", "SNMP", "TELNET", "MEM", "CPU"// 40
				, "MEMALM", "CPUALM", "CURTIME", "GENDATETIME", "BOOTIMAGE"// 45
				, "WHYRELOAD", "CMTSTIME", "BOARD", "AUTO_SWITCHOVER", "IOS_VERIFY"// 50
		};
		return columns;
	}

	@Override
	protected String getTableName() {
		return "RMS_CMTS";
	}
}
