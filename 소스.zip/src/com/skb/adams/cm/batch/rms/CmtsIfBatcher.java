package com.skb.adams.cm.batch.rms;

import java.io.File;

import com.skb.adams.cm.batch.Batcher;

/**
 * @deprecated 테스트용
 * @author SUBKJH-DEV
 *
 */
public class CmtsIfBatcher extends Batcher {

	public static void main(String[] args) {
		CmtsIfBatcher batcher = new CmtsIfBatcher();
		try {
			batcher.runBatch(new File("datas/interface_20171107-083001.unl"));
		} catch (Exception e) {
			e.printStackTrace();
		}

		// batcher.onRead("172.23.0.63|WB412010|06|150|N01111|J10100|2838|GoYang_CBR_W10#|GoYang_CBR_W10.skbroadband.com||||WB412010|1|172.23.225.36|1|||5424|15.6(2)SP1a|hfc300aks|IOS-XE ROMMON||15.5(3)S1 , 15.6(2)SP1a , 15.6(1)S1|2017110701|���籹�� 4�� �� ��� ��||helpme|pos1004|||1||||24790591.0|1|||0|||1509967816|201711070105|bootflash:cbrsup-universalk9.03.18.01a.SP.156-2.SP1a-ext.SPA.bi|reload||||1|");
		// batcher.onRead("|TEQ442K05_SDV|06|200|N21754||6010|||||||||||||03.09.00.015|hfc300aks|||01.06.04.006 , 02.07.07.001 , 03.11.00.013 , 03.09.00.015|2016060304|�ȴޱ���|40G|||||1||||32405196.0|||||||1505682047|201709180630||||||1|");
	}

	public CmtsIfBatcher() {
		setLength(41);
	}

	@Override
	protected String[] getColumns() {
		String columns[] = {

		"CMTSNAME"//
				, "CMTSID", "SNMPINDEX", "INTERFACEINDEX", "CARDINDEX", "CARDTYPECODE"//
				, "IFTYPECODE", "MAXSPEED", "IFALIAS", "DESCRIPTION", "DIR"//
				, "SLOTNO", "PORTNO", "CELL", "BW", "IPADDR"//
				, "NETMASK", "FREQUENCY", "ACTIVEMODEM", "REGMODEM", "TOTALMODEM"//
				, "IFSTATUS", "ADMINSTATUS", "LASTCHANGE", "SNR", "CHANUTIL"//
				, "INBPS", "OUTBPS", "INPPS", "OUTPPS", "UPUTILALM"//
				, "DOWNUTILALM", "UPSNRALM", "CHANUTILALM", "SNMP", "CURTIME"//
				, "GENDATETIME", "FLAG", "PING", "PINGALM", "BGID"//
		};
		return columns;
	}

	@Override
	protected String getTableName() {
		return "RMS_INTERFACE";
	}
}
