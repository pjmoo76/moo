package com.skb.adams.cm.batch.rms;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.batch.BasFileParser;
import com.skb.adams.cm.batch.Upload2DbNew;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.FxTmpQid;
import com.skb.adams.cm.model.OIV10802;

public class CmInfoTblParser extends BasFileParser<OIV10802> {

	public static void main(String[] args) {
		CmInfoTblParser parser = new CmInfoTblParser();
		File folder = new File("datas/rms");
		parser.parseFolder(folder);
	}

	private final int MACNO = 0;
	private final int CM_IP = 1;
	private final int MODEL = 2;
	private final int CMVERSION = 3;
	private final int CHG_DATE = 4;
	@SuppressWarnings("unused")
	private final int SYSUPTIME = 5;
	private final int SYSUPTIMEDIGIT = 6;

	private final int CM_IP_REAL = 0;
	private final int MODEL_REAL = 1;
	private final int CMVERSION_REAL = 2;
	private final int SYSUPTIMEDIGIT_REAL = 4;
	private final int CHG_DATE_REAL = 5;
	private final int MACNO_REAL = 6;

	private Upload2DbNew<OIV10802> uploader;
	private DbTrans dstTran;
	/** realtime과 전체 2가지가 온다. */
	private boolean isReal = false;

	public CmInfoTblParser() {

	}

	@Override
	protected boolean isCompeletedData(OIV10802 data) {
		return true;
	}

	@Override
	public boolean isTargetFile(File file) {

		boolean ret = file.getName().startsWith("cm_info_tbl") && file.getName().endsWith(".#FIN");
		return ret;
	}

	@Override
	protected void onData(int index, String line, OIV10802 data) throws Exception {

		// System.out.println(index + ", " + line + " , " + data);

		uploader.add(data);

	}

	@Override
	protected void onFinished(File file, int size, Exception ex) {
		try {
			uploader.close(ex);
			dstTran.commit();
			Logger.logger.info("FILE({}) DATA-COUNT({})", file.getName(), size);
		} catch (Exception e) {
			dstTran.rollback();
			Logger.logger.error(e);
			ex = e;
		} finally {
			dstTran.stop();
			backup(file, ex == null ? "OK" : "ERR", "cm_info_tbl");
		}
	}

	@Override
	protected void onStart(File file) throws Exception {
		FxTmpQid QID = new FxTmpQid();
		dstTran = DBManager.getMgr().getDataBase(CmDao.ADAMS).createDbTrans("deploy/conf/sql/" + FxTmpQid.QUERY_XML_FILE);
		dstTran.start();

		uploader = new Upload2DbNew<OIV10802>(dstTran, "OIV10802_CM", QID.MERGE_OIV10802__BY_CM);

		isReal = file.getName().startsWith("cm_info_tbl_realtime") && file.getName().endsWith(".#FIN");
		Logger.logger.debug("file={}, real={}", file, isReal);
	}

	@Override
	protected OIV10802 parse(String line) throws Exception {
		StringBuffer sb = new StringBuffer();
		List<String> list = new ArrayList<String>();
		char chs[] = line.toCharArray();
		for (int i = 0; i < chs.length; i++) {
			// if (i > 0 && chs[i] == '|' && chs[i - 1] == '\\') {
			// sb.append(chs[i]);
			// } else
			if (chs[i] == '|') {
				list.add(sb.toString());
				sb = new StringBuffer();
			} else {
				sb.append(chs[i]);
			}
		}

		list.add(sb.toString());

		OIV10802 o802 = new OIV10802();

		if (isReal) {

			// 10.186.0.53|MNG2300 Cable Modem|2.93.1014|102 days, 7 hours, 37
			// minutes, 22 seconds.|884024200|201801250951|0002.0048.F12C

			o802.setEqpUptimeCnt(getValLong(list.get(SYSUPTIMEDIGIT_REAL), 0));
			o802.setEqpVerInfo(getValStr(list.get(CMVERSION_REAL)));
			o802.setIpAddr(getValStr(list.get(CM_IP_REAL)));
			o802.setIptvSvcModeVal(null);
			o802.setMacAddrVal(getValMac(list.get(MACNO_REAL)));
			o802.setOutLnkgIpAddr(null);
			o802.setPatchGrpCtt(null);
			o802.setTrapRcvDtm(getValTimestampByDate(list.get(CHG_DATE_REAL)));
			o802.setWeqpMdlNm(getValStr(list.get(MODEL_REAL)));

		} else {
			// 0002.0048.FDE8|10.193.169.22|MNG2300 Cable Modem|
			// 2.93.1014|201712262102|66 days, 6 hours, 43 minutes, 32
			// seconds.|572661200|
			o802.setEqpUptimeCnt(getValLong(list.get(SYSUPTIMEDIGIT), 0));
			o802.setEqpVerInfo(getValStr(list.get(CMVERSION)));
			o802.setIpAddr(getValStr(list.get(CM_IP)));
			o802.setIptvSvcModeVal(null);
			o802.setMacAddrVal(getValMac(list.get(MACNO)));
			o802.setOutLnkgIpAddr(null);
			o802.setPatchGrpCtt(null);
			o802.setTrapRcvDtm(getValTimestampByDate(list.get(CHG_DATE)));
			o802.setWeqpMdlNm(getValStr(list.get(MODEL)));
		}
		return o802;
	}
}
