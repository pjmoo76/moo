package com.skb.adams.cm.batch;

import java.util.ArrayList;
import java.util.List;

import fxms.bas.cron.Cron;
import fxms.bas.fxo.fxa.FxaParser;
import fxms.bas.fxo.thread.CycleFxThread;

public class FileBatchThread extends CycleFxThread {

	private List<BatchData> fileCheckerList = new ArrayList<BatchData>();

	public FileBatchThread() throws Exception {

		super("FileFxThread", Cron.CYCLE_1_SECOND);

		fileCheckerList = FxaParser.getParser().getFilterList(BatchData.class);

	}

	@Override
	protected void doCycle(long mstime) {

		for (BatchData checker : fileCheckerList) {
			checker.checkFile();
		}

	}

}
