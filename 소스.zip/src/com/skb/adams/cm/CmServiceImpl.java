package com.skb.adams.cm;

import java.rmi.RemoteException;

import fxms.bas.fxo.service.FxServiceImpl;

public class CmServiceImpl extends FxServiceImpl implements CmService {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3490724989488252127L;

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		FxServiceImpl.start(CmService.class.getSimpleName(), CmServiceImpl.class, args);
	}

	public CmServiceImpl(String name, int port) throws RemoteException, Exception {
		super(name, port);
	}

}
