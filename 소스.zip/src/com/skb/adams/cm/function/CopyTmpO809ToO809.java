package com.skb.adams.cm.function;

import java.sql.SQLRecoverableException;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.CmMsg;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.ZossWeqpQid;

/**
 * FX_TMP_OIV10809 테이블 내용을 OIV10809 테이블로 복사한다.
 * 
 * @author SUBKJH-DEV
 *
 */
public class CopyTmpO809ToO809 implements Runnable {

	@Override
	public void run() {

		ZossWeqpQid qid = new ZossWeqpQid();

		// MIAPP에게 테이블 변경 권한이 있고
		// MICM이 FX_TMP_OIV10809를 만들어 MIAPP는 권한이 없는 관계로
		// MIAPP가 테이블 변경 작업을
		// MICM이 FX_TMP_OIV10809에서 OIV10809로 데이터 넣는 작업을 한다.
		DbTrans tran;
		DbTrans tran2;
		int count = -1;
		try {
			tran = DBManager.getMgr().getDataBase(CmDao.ADAMS_MIAPP).createDbTrans("deploy/conf/sql/" + ZossWeqpQid.QUERY_XML_FILE);
			tran2 = DBManager.getMgr().getDataBase(CmDao.ADAMS_MICM).createDbTrans("deploy/conf/sql/" + ZossWeqpQid.QUERY_XML_FILE);
		} catch (Exception e1) {
			Logger.logger.error(e1);
			return;
		}

		try {
			tran.start();
			try {
				tran.execute(qid.COPY_FX_TMP_OIV10809_01__DROP_PK, null);
			} catch (Exception e) {
				Logger.logger.error(e);
			}
			try {
				tran.execute(qid.COPY_FX_TMP_OIV10809_02__DROP_INDEX, null);
			} catch (Exception e) {
				Logger.logger.error(e);
			}
			try {
				tran.execute(qid.COPY_FX_TMP_OIV10809_03__DROP_INDEX, null);
			} catch (Exception e) {
				Logger.logger.error(e);
			}
			try {
				tran.execute(qid.COPY_FX_TMP_OIV10809_04__DROP_INDEX, null);
			} catch (Exception e) {
				Logger.logger.error(e);
			}
			try {
				tran.execute(qid.COPY_FX_TMP_OIV10809_05__TRUNCATE, null);
				tran.commit();
			} catch (Exception e) {
				Logger.logger.error(e);
			}

			try {
				count = tran2.execute(qid.COPY_FX_TMP_OIV10809_06__INSERT, null);
				tran2.commit();
			} catch (Exception e) {
				Logger.logger.error(e);
			}

			try {
				tran.stop();
			} catch (Exception e) {
				Logger.logger.error(e);
			}
			tran = DBManager.getMgr().getDataBase(CmDao.ADAMS_MIAPP).createDbTrans("deploy/conf/sql/" + ZossWeqpQid.QUERY_XML_FILE);
			
			try {
				tran.execute(qid.COPY_FX_TMP_OIV10809_07__CREATE_INDEX, null);
			} catch (SQLRecoverableException re) {
				Logger.logger.error(re);
				tran = DBManager.getMgr().getDataBase(CmDao.ADAMS_MIAPP).createDbTrans("deploy/conf/sql/" + ZossWeqpQid.QUERY_XML_FILE);
				try {
					tran.execute(qid.COPY_FX_TMP_OIV10809_07__CREATE_INDEX, null);
				} catch (Exception e) {
					Logger.logger.error(e);
				}
			} catch (Exception e) {
				Logger.logger.error(e);
			}

			try {
				tran.execute(qid.COPY_FX_TMP_OIV10809_07__ALTER_INDEX, null);
			} catch (SQLRecoverableException re) {
				Logger.logger.error(re);
				try {
					tran.execute(qid.COPY_FX_TMP_OIV10809_07__ALTER_INDEX, null);
				} catch (Exception e) {
					Logger.logger.error(e);
				}
			} catch (Exception e) {
				Logger.logger.error(e);
			}

			try {
				tran.execute(qid.COPY_FX_TMP_OIV10809_08__CREATE_PK, null);
			} catch (Exception e) {
				Logger.logger.error(e);
			}
			try {
				tran.execute(qid.COPY_FX_TMP_OIV10809_09__CREATE_INDEX, null);
			} catch (Exception e) {
				Logger.logger.error(e);
			}
			try {
				tran.execute(qid.COPY_FX_TMP_OIV10809_10__CREATE_INDEX, null);
			} catch (Exception e) {
				Logger.logger.error(e);
			}
			
			Logger.logger.info(CmMsg.makeCmInfo("FX_TMP_OIV10809 -> OIV10809", -1, count, -1));


		} catch (Exception e) {
			Logger.logger.error(e);
		} finally {
			try {
				tran.stop();
			} catch (Exception e) {
				Logger.logger.error(e);
			}
			try {
				tran2.stop();
			} catch (Exception e) {
				Logger.logger.error(e);
			}

		}

	}
}
