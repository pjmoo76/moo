package com.skb.adams.cm.function;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.CmCode;
import com.skb.adams.cm.dao.OIV10110Qid;
import com.skb.adams.cm.model.OIV10110;
import com.skb.adams.cm.model.OIV10901;

/**
 * 장비속성변경이력 처리 함수
 * 
 * @author SUBKJH-DEV
 *
 */
public class FOIV10110 {

	private DbTrans tran;
	private String hstime;
	private SimpleDateFormat YYYYMMDDHHMMSS = new SimpleDateFormat("yyyyMMddHHmmss");
	private Map<String, String> nameMap = new HashMap<String, String>();
	private Map<String, String> attrMap = new HashMap<String, String>();

	@SuppressWarnings("unchecked")
	public FOIV10110(DbTrans tran, OIV10110Qid qid) throws Exception {
		this.tran = tran;

		hstime = YYYYMMDDHHMMSS.format(new Date(System.currentTimeMillis()));
		List<OIV10901> o901List = tran.selectQid2Res(qid.SELECT_OIV10901, null);
		for (OIV10901 o901 : o901List) {
			attrMap.put(o901.getTblNm() + "." + o901.getColNm(), o901.getEquipAttrCd());
		}
	}

	private String getName(String colNm, String attrVal) {

		String name = nameMap.get(colNm + "\t" + attrVal);
		if (name != null) {
			return name;
		}
		try {
			name = tran.selectQidStr("SELECT_" + colNm, attrVal);
		} catch (Exception e) {
			Logger.logger.error(e);
			return null;
		}

		if (name == null) {
			name = "";
		}

		nameMap.put(colNm + "\t" + attrVal, name);
		return name;
	}

	public OIV10110 make110(Object val[], String colNm, String equipId) {

		String attrCd = attrMap.get("OIV10100." + colNm);
		if (attrCd == null) {
			return null;
		}

		String attrVal = val[0] + "";
		String bfAttrVal = val[1] + "";

		if (tran.getSqlBean("SELECT_" + colNm) != null) {
			try {
				attrVal += "(" + getName(colNm, attrVal) + ")";
				bfAttrVal += "(" + getName(colNm, bfAttrVal) + ")";
			} catch (Exception e) {
				Logger.logger.error(e);
			}
		}

		OIV10110 o110 = new OIV10110();
		o110.setAttrVal(attrVal);
		o110.setAuditId("MICM-SWG");
		o110.setChgDtm(hstime);
		o110.setBfAttrVal(bfAttrVal);
		o110.setEquipAttrCd(attrCd);
		o110.setEquipAttrChgClCd(CmCode.EquipAttrChgClCd.SWING.getCode());
		o110.setEquipId(equipId);
		return o110;
	}
}
