package com.skb.adams.cm.function;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.data.SoDo;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.fxdao.control.DiffDao;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.CmMsg;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.OIV10100UpdateQid;
import com.skb.adams.cm.dao.OIV10110Qid;
import com.skb.adams.cm.model.OIV10100;
import com.skb.adams.cm.model.OIV10110;

/**
 * 
 * OIV10112(SWING장비기본)과 OIV10100(장비기본)을 비교하여 정합하는 함수
 * 
 * @author SUBKJH-DEV
 *
 */
public class FOIV10100_01 extends DiffDao<OIV10100> implements Runnable {

	private OIV10100UpdateQid qid = new OIV10100UpdateQid();
	private OIV10110Qid qid110 = new OIV10110Qid();
	private List<OIV10110> o110List = new ArrayList<OIV10110>();
	private FOIV10110 f110;
	
	public static void main(String[] args) {
		FOIV10100_01 f = new FOIV10100_01();
		f.run();
	}

	public FOIV10100_01() {

	}

	@Override
	public void run() {

		try {
			DataBase database = DBManager.getMgr().getDataBase(CmDao.ADAMS);
			DbTrans tran = database.createDbTrans("deploy/conf/sql/" + OIV10100UpdateQid.QUERY_XML_FILE //
			, "deploy/conf/sql/" + OIV10110Qid.QUERY_XML_FILE);

			f110 = new FOIV10110(tran, qid110);

			setTrans(tran, tran);

			diff(qid.SELECT_OIV10112, qid.SELECT_OIV10100);

		} catch (Exception e) {
			Logger.logger.error(e);
		}

	}

	@Override
	protected String makeKey(OIV10100 o100) {
		return o100.getEquipMgmtNum();
	}

	@Override
	protected void onCompleted(Exception ex) {

		Logger.logger.error(ex);

	}

	@Override
	protected void onCompleted(List<OIV10100> addList, List<OIV10100> chgList, List<OIV10100> delList, List<OIV10100> nothingList) throws Exception {

		int insertCnt = 0;
		int deleteCnt = 0;
		int updateCnt = 0;
		int nothingCnt = nothingList == null ? 0 : nothingList.size();

		// 추가
		if (addList.size() > 0) {
			// 무시
			insertCnt = addList.size();
		}
		if (chgList.size() > 0) {
			updateCnt = getDstTran().execute(qid.UPDATE_OIV10100__BY_EQUIPID, chgList);
			// updateCnt = chgList.size();
		}
		if (delList.size() > 0) {
			// 무시
			deleteCnt = delList.size();
		}

		
		
		if (o110List.size() > 0) {
			Logger.logger.info("### INSERT_OIV10110 Start.");
			getDstTran().execute(qid110.INSERT_OIV10110, o110List);
			Logger.logger.info("### INSERT_OIV10110 Completed.");
		}
		
		getDstTran().commit();

		Logger.logger.info(CmMsg.makeCmInfo("OIV10112 & OIV10100 DIFF", deleteCnt, insertCnt, updateCnt, nothingCnt));
	}

	@Override
	protected void onDiff(OIV10100 data1, OIV10100 data2, Map<String, Object[]> diffMap) {
		
		// super는 log를 남기고 있다.
		super.onDiff(data1, data2, diffMap);

		OIV10110 o110;
		String colNm;

		// 쿼리에 SWING 장비는 장비ID가 없으므로 여기서 넣어줌.
		data1.setEquipId(data2.getEquipId());

		for (String key : diffMap.keySet()) {
			colNm = SoDo.getDaoName(key);

			o110 = f110.make110(diffMap.get(key), colNm, data2.getEquipId());
			if (o110 != null) {
				o110List.add(o110);
			}
		}

	}

}
