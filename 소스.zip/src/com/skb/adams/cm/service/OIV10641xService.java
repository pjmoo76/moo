package com.skb.adams.cm.service;

import java.util.HashMap;
import java.util.List;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.model.Address_OES30300;
import com.skb.adams.cm.model.LdongAddress_OES30300;
import com.skb.adams.cm.dao.OES30300Qid;

public class OIV10641xService {

	protected DbTrans		tran = null;
	protected OES30300Qid	qid = null;
	
	protected void setconn() throws Exception {
		DataBase database = DBManager.getMgr().getDataBase("ADAMS_MIAPP2");
		qid = new OES30300Qid();
		tran = database.createDbTrans("deploy/conf/sql/" + qid.QUERY_XML_FILE);
		tran.start();	
	}
	
	protected List<Address_OES30300> doOES30300() throws Exception {

		HashMap<String, String> hmap = null;
		List<Address_OES30300> weqpRelVOList = tran.selectQid2Res(qid.select_address_list,hmap);
	
		if (weqpRelVOList.get(0).getLdong_Cd() == null) {
    		Logger.logger.debug("LdongCd Is Value Null.");
    	}
		
			return weqpRelVOList;
		}
	protected List<LdongAddress_OES30300> doLdongList(String ldongCd) throws Exception {
		
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("ldong_cd", ldongCd);
		List<LdongAddress_OES30300> weqpRelVOList = tran.selectQid2Res(qid.select_ldongcd_address_list,hmap);
		return  weqpRelVOList;
		}
	
	protected void doUpdate(HashMap<String, String> hmap) throws Exception {

		tran.execute(qid.update_ldongcd_OIV10641, hmap);
		tran.commit();
	}

	}