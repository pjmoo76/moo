package com.skb.adams.cm.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.skb.adams.cm.dao.CmComProcQid;
import com.skb.adams.cm.model.OES10100;
import com.skb.adams.cm.util.FileUtils;
import com.skb.adams.cm.util.StringUtils;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.LOG_LEVEL;
import subkjh.bas.log.Logger;

public class SwingNEIFCustMaker {

	public static void main(String[] args) {
		// parameters: splitDir=/data/cm-neif/split ymd=20171209 targetDit= logDir logId debugMode={debug/info} 

		String	splitDirName	= null;
		String	ymd				= null;
		String	targetDirName	= null;
		
		String	logDirName = null;
		String	logId = null;
		String	debugMode = "INFO";
		
		for (int i = 0; i < args.length; i ++) {
			String[] tokens = args[i].split("=");
			if ("SPLITDIR".equalsIgnoreCase(tokens[0])) {
				splitDirName = tokens[1];
			} else if ("YMD".equalsIgnoreCase(tokens[0])) {
				ymd = tokens[1];
			} else if ("TARGETDIR".equalsIgnoreCase(tokens[0])) {
				targetDirName = tokens[1];
			} else if ("LOGDIR".equalsIgnoreCase(tokens[0])) {
				logDirName = tokens[1];
			} else if ("LOGID".equalsIgnoreCase(tokens[0])) {
				logId = tokens[1];
			} else if ("DEBUGMODE".equalsIgnoreCase(tokens[0])) {
				if ("DEBUG".equalsIgnoreCase(tokens[1])) {
					debugMode = "DEBUG";
				}
			}
		}
		
		if (logDirName != null && logId != null) {
			Logger.logger = Logger.createLogger(logDirName, logId);
			if ("DEBUG".equals(debugMode)) {
				Logger.logger.setLevel(LOG_LEVEL.debug);
			} else {
				Logger.logger.setLevel(LOG_LEVEL.info);
			}
		}
		
		SwingNEIFCustMaker swingNEIFCustMaker = new SwingNEIFCustMaker();

		swingNEIFCustMaker.setSplitDirName(splitDirName);
		swingNEIFCustMaker.setYmd(ymd);
		swingNEIFCustMaker.setTargetDirName(targetDirName);
		
		try {
			swingNEIFCustMaker.run();
		} catch (Exception e) {
			Logger.logger.error(e);
		}

	}
	
	static private final int	TOKEN_NO		= 69;
	
	private String	splitDirName	= null;
	private	String	ymd				= null;
	private	String	targetDirName	= null;
	private	int		recCnt			= 0;
	
	private List<String>		fileList	= null;
	private FileOutputStream	custInfoFw	= null;
	private FileOutputStream	svcInfoFw	= null;
	private FileOutputStream	custSvcMapFw	= null;
	private FileOutputStream	svcInfoLogFw	= null;
	
	private	CmComProcQid		QID = new CmComProcQid();
	private	DbTrans				tran;

	public SwingNEIFCustMaker() {
		
	}
	
	public void setSplitDirName(String splitDirName) {
		this.splitDirName = splitDirName;
	}
	public void setYmd(String ymd) {
		this.ymd = ymd;
	}
	public void setTargetDirName(String targetDirName) {
		this.targetDirName = targetDirName;
	}
	
	public void run() throws Exception {
		
		if (StringUtils.isEmpty(ymd)) {
			LocalDate currentDate = LocalDate.now();
			ymd = currentDate.getYear() +
					String.format("%02d", currentDate.getMonthValue()) +
					String.format("%02d", currentDate.getDayOfMonth());
		}

		fileList = getSplitedFiles();
		if (fileList == null) return;
		
		FileUtils.mkdir(targetDirName);
		
		String custInfoFileName = targetDirName + "/SWING_NEIF_CUST_INFO_" + ymd + ".dat";
		String svcInfoFileName = targetDirName + "/SWING_NEIF_SVC_INFO_" + ymd + ".dat";
		String custSvcMapFileName = targetDirName + "/SWING_NEIF_CUST_SVC_MAP_" + ymd + ".dat";
		String svcInfoLogFileName = targetDirName + "/log/SWING_NEIF_SVC_INFO_LOG_" + ymd + ".dat";

		custInfoFw = new FileOutputStream(custInfoFileName);
		svcInfoFw = new FileOutputStream(svcInfoFileName);
		custSvcMapFw = new FileOutputStream(custSvcMapFileName);
		svcInfoLogFw = new FileOutputStream(svcInfoLogFileName);
		
		// DataBase database = DBManager.getMgr().getDataBase("ADAMSDEV_MICL"); 개발서버
		DataBase database = DBManager.getMgr().getDataBase("ADAMS_MIAPP");
		tran = database.createDbTrans("deploy/conf/sql/cmComProc.xml");

		for (String fName : fileList) {
			load(fName);
		}
		custInfoFw.close();
		svcInfoFw.close();
		custSvcMapFw.close();
		svcInfoLogFw.close();

		FileUtils.rename(custInfoFileName, custInfoFileName + ".#FIN");
		FileUtils.rename(svcInfoFileName, svcInfoFileName + ".#FIN");
		FileUtils.rename(custSvcMapFileName, custSvcMapFileName + ".#FIN");
		FileUtils.rename(svcInfoLogFileName, svcInfoLogFileName + ".#FIN");
	}

	private List<String> getSplitedFiles() {
		File folder = new File(splitDirName + "/" + ymd);
		File[] files = folder.listFiles();
		if (files == null) {
			Logger.logger.error("failed to get files in " + splitDirName);
			return null;
		}
		
		List<String> fList = new ArrayList<String>();
		
		Pattern pattern = Pattern.compile(".*\\.dat$");
		int fileNo = 0;
		for (File file : files) {
			if (file.isFile()) {
				String fName = file.getName();
				Matcher matcher = pattern.matcher(fName);
				if (matcher.find()) {
					Logger.logger.debug("file : " + fName);
					fList.add(splitDirName + "/" + ymd + "/" + fName);
					fileNo ++;
					Logger.logger.info("added (" + fileNo + ") " + fName);
				}
			}
		}
		return fList;
	}
	
	private void load(String fName) throws Exception {
		Logger.logger.info("opening " + fName);
		FileInputStream fr =  new FileInputStream(fName);
		InputStreamReader ir = new InputStreamReader(fr, "eucKR");
		BufferedReader br = new BufferedReader(ir);
		String strLine;
		int lineNo = 0;
		while ((strLine = br.readLine()) != null) {
			try {
				process(strLine);
			} catch (Exception e) {
				Logger.logger.error(e);
			}
			lineNo ++;
			if (lineNo % 10000 == 0) {
				Logger.logger.info("reading " + lineNo + " lines in " + fName );
			}
		}
		try {
			if (br != null) br.close();
			if (fr != null) fr.close();
		} catch (IOException ex) {
			Logger.logger.error(ex);
		}
		Logger.logger.info("finished " + fName);
	}
	
	private void process(String data) throws Exception {
		
		String[] tokens = data.split("\\|");
		if (tokens.length < TOKEN_NO) {
			//Logger.logger.error("invalid token no : " + tokens.length);
			return;
		}
		long custNum = Long.parseLong(tokens[5]);
		
		OES10100 oes10100 = new OES10100();
		oes10100.setCustNum(custNum);
		oes10100.setCustNm(tokens[8]);
		oes10100.setBasAddr(tokens[59]);
		oes10100.setPhonNum(tokens[11]);
		oes10100.setLdongCd(tokens[53]);
		oes10100.setAssistAddr(tokens[60]);
		oes10100.setZip(tokens[58]);

		String macAddr = tokens[1];

		recCnt ++;
		String custInfoStr = oes10100.getCustNum() + "|" + oes10100.getCustNm() + "|" + oes10100.getBasAddr() + "|" +
				oes10100.getPhonNum() + "|" + oes10100.getLdongCd() + "|" + oes10100.getAssistAddr() + "|" + oes10100.getZip() + "|" + macAddr + "|" + recCnt;
				
		custInfoFw.write(custInfoStr.getBytes(Charset.forName("eucKR")));
		custInfoFw.write('\n');
		
		// 초고속서비스
		String svcMgmtNum = tokens[13].trim();
		if (StringUtils.isEmpty(svcMgmtNum) == false && svcMgmtNum.equals("0") == false) {
			String svcInfoStr =  svcMgmtNum + "|" + tokens[12] + "|I|" + recCnt;
			svcInfoFw.write(svcInfoStr.getBytes(Charset.forName("eucKR")));
			svcInfoFw.write('\n');
			String custSvcMapStr = oes10100.getCustNum() + "|" + svcMgmtNum + "|" + recCnt;
			custSvcMapFw.write(custSvcMapStr.getBytes(Charset.forName("eucKR")));
			custSvcMapFw.write('\n');
		}
		// 유선전화서비스
		svcMgmtNum = tokens[15].trim();
		if (StringUtils.isEmpty(svcMgmtNum) == false && svcMgmtNum.equals("0") == false) {
			String svcInfoStr =  svcMgmtNum + "|" + tokens[14] + "|P|" + recCnt;
			if(svcMgmtNum.equals(tokens[13].trim())) {
				// 초고속서비스 와 유선전화서비스 번호가 같은경우
				svcInfoLogFw.write(svcInfoStr.getBytes(Charset.forName("eucKR")));
				svcInfoLogFw.write('\n');
				sendCustinfoSms(svcMgmtNum);
			} else {
				svcInfoFw.write(svcInfoStr.getBytes(Charset.forName("eucKR")));
				svcInfoFw.write('\n');
			}
			String custSvcMapStr = oes10100.getCustNum() + "|" + svcMgmtNum + "|" + recCnt;
			custSvcMapFw.write(custSvcMapStr.getBytes(Charset.forName("eucKR")));
			custSvcMapFw.write('\n');
		}
		// TV서비스
		svcMgmtNum = tokens[17].trim();
		if (StringUtils.isEmpty(svcMgmtNum) == false && svcMgmtNum.equals("0") == false) {
			String svcInfoStr =  svcMgmtNum + "|" + tokens[16] + "|T|" + recCnt;
			if(svcMgmtNum.equals(tokens[13].trim()) || svcMgmtNum.equals(tokens[15].trim())) {
				// TV서비스 와 초고속서비스 번호가 같은경우
				// TV서비스 와 유선전화서비스 번호가 같은경우
				svcInfoLogFw.write(svcInfoStr.getBytes(Charset.forName("eucKR")));
				svcInfoLogFw.write('\n');
				sendCustinfoSms(svcMgmtNum);
			} else {
				svcInfoFw.write(svcInfoStr.getBytes(Charset.forName("eucKR")));
				svcInfoFw.write('\n');
			}
			String custSvcMapStr = oes10100.getCustNum() + "|" + svcMgmtNum + "|" + recCnt;
			custSvcMapFw.write(custSvcMapStr.getBytes(Charset.forName("eucKR")));
			custSvcMapFw.write('\n');
		}
		
		tran.stop();
	}
	
	private void sendCustinfoSms(String svcMgmtNum) {
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("svcMgmtNum", svcMgmtNum);
		try {
			tran.start();
			tran.execute(QID.INSERT_TBL_SUBMIT_QUEUE_CUSTINFO, hmap);
		} catch (Exception e) {
			Logger.logger.error(e);
		}
		tran.commit();
	}
}
