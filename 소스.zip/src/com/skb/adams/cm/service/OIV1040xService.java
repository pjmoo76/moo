package com.skb.adams.cm.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.exception.DBObjectDupException;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.dao.OIV1040xQid;
import com.skb.adams.cm.model.OIV10100;
import com.skb.adams.cm.model.OIV10401;
import com.skb.adams.cm.model.OIV10402;
import com.skb.adams.cm.model.OIV10403;
import com.skb.adams.cm.model.OIV10404;
import com.skb.adams.cm.model.OIV10805;
import com.skb.adams.cm.model.OIV10809;
import com.skb.adams.cm.model.WeqpRelVO;
import com.skb.adams.cm.util.StringUtils;

public class OIV1040xService {

	protected	DbTrans		tran			= null;
	protected	OIV1040xQid	QID				= null;

	protected	String		auditId			= null;
	protected	String		l3EquipId		= null;
	protected	String		l2EquipId		= null;
	protected	String		weqpMgmtNum		= null;
	protected	String		l3EquipPortId	= null;
	protected	String		l2EquipPortId	= null;
	protected	String		linkId			= null;
	protected	int			thruSerNum		= 0;
	
	private	String procId;
	
	// NET_CL_CD : 01(교환망), 03(FTTx), 04(HFC)
	// WEQP_MDL_TYP_CD : 10(AP), 20(STB), 30(CM), 40(ONT), 50(VDSL), 00(기타단말)
	
	public final static String	FTTX	= "03";
	public final static String	HFC		= "04";
	public final static String	AP		= "10";
	public final static String	STB		= "20";
	public final static String	CM		= "30";
	public final static String	ONT		= "40";
	public final static String	VDSL	= "50";
	public final static String	ETC		= "00";
	
	public final static String	IN_CD	= "1";
	public final static String	OUT_CD	= "2";

	Map<String, OIV10100> o100Map		= null;
	Map<String, String> equipPortIdMap	= null;
	Map<String, String> linkIdMap		= null;
	

	public OIV1040xService() {
		equipPortIdMap = new HashMap<String, String>();
		linkIdMap = new HashMap<String, String>();
	}
	
	public void set(DbTrans tran, OIV1040xQid QID) {
		this.tran = tran;
		this.QID = QID;
	}

	public void set(DbTrans tran, OIV1040xQid QID, Map<String, OIV10100> o100Map) {
		this.tran = tran;
		this.QID = QID;
		this.o100Map = o100Map;
	}
	
	public void setProcId(String procId) {
		this.procId = procId;
	}

	public boolean process(OIV10805 oiv10805) throws Exception {
		
		Logger.logger.debug("L3_TID:" + oiv10805.getL3EquipId() + ",L2_TID:" + oiv10805.getL2EquipId() + ",MAC:" + oiv10805.getMacAddr());
		
		auditId = oiv10805.getAuditId();
		
		checkValidation(oiv10805);
		
		HashMap<String, String> hmap = null;
		l3EquipPortId = null;
		l2EquipPortId = null;
		
		if (OUT_CD.equals(oiv10805.getInoutClCd())) {
			remove(oiv10805);
			return true;
		}
		
		doOIV10907(oiv10805);
		
		doOIV10400(oiv10805);
		doOIV10401(oiv10805);

		try {
			doOIV10402(oiv10805);
			doOIV10403(oiv10805);
			doOIV10404(oiv10805);
			updateWeqpRel(linkId, oiv10805.getCustNum());
		} catch (Exception e) {
			Logger.logger.error("L3_TID:" + oiv10805.getL3EquipId() + ",L2_TID:" + oiv10805.getL2EquipId() + ",MAC:" + oiv10805.getMacAddr());
			Logger.logger.error(e);
			throw e;
		}
		
		return true;
	}
	
	protected void checkValidation(OIV10805 oiv10805) throws Exception {
		/* check data validation */

		if (StringUtils.isEmpty(oiv10805.getL3EquipId())) {
			//Logger.logger.error("L3_TID is null");
			throw new CmException(CmException.NO_L3_TID);
		}
		if (StringUtils.isEmpty(oiv10805.getL2EquipId())) {
			//Logger.logger.error("L2_TID is null");
			throw new CmException(CmException.NO_L2_TID);			
		}
		if (StringUtils.isEmpty(oiv10805.getMacAddr())) {
			//Logger.logger.error("MAC is null");
			if (StringUtils.isEmpty(oiv10805.getWeqpMgmtNum())) {
				throw new CmException(CmException.NO_MAC);
			}
		}
		
		/* get equip_id/wepq_mgmt_num */

		l3EquipId = findEquipId(oiv10805.getL3EquipId());
		if (StringUtils.isEmpty(l3EquipId)) {
			//Logger.logger.error("failed to find EQUIP_ID by EQUIP_MGMT_NUM(" + oiv10805.getL3EquipId() + ")");
			throw new CmException(CmException.NOT_FOUND_EQUIP_ID, oiv10805.getL3EquipId());
		}
		l2EquipId = findEquipId(oiv10805.getL2EquipId());
		if (StringUtils.isEmpty(l2EquipId)) {
			//Logger.logger.error("failed to find EQUIP_ID by EQUIP_MGMT_NUM(" + oiv10805.getL2EquipId() + ")");
			throw new CmException(CmException.NOT_FOUND_EQUIP_ID, oiv10805.getL2EquipId());
		}
		try {
			if (StringUtils.isEmpty(oiv10805.getWeqpMgmtNum()) == false) {
				weqpMgmtNum = tran.selectQidStr(QID.SELECT_WEQP_MGMT_NUM__BY_WEQP_MGMT_NUM, oiv10805.getWeqpMgmtNum());
				if (StringUtils.isEmpty(weqpMgmtNum)) {
					findWeqpMgmtNumByWeqpMgmtNum(oiv10805.getWeqpMgmtNum());
				}
			} else {
				weqpMgmtNum = tran.selectQidStr(QID.SELECT_WEQP_MGMT_NUM__BY_MAC_ADDR_VAL, oiv10805.getMacAddr());
				if (StringUtils.isEmpty(weqpMgmtNum)) {
					findWeqpMgmtNumByMacAddr(oiv10805.getMacAddr());
				}
			}
		} catch (DBObjectDupException de) {
			Logger.logger.error("Already existed (weqpMgmtNum=" + weqpMgmtNum + ")");
			//Logger.logger.error(de);
		}
		Logger.logger.debug("l3EquipId:" + l3EquipId + ",l2EquipId:" + l2EquipId + ",weqpMgmtNum=" + weqpMgmtNum);
	}
	
	protected void doOIV10400(OIV10805 oiv10805) throws Exception {
		/* OIV10400 */
		if (StringUtils.isEmpty(oiv10805.getL3CellNum())) { /* FTTx */
		
			String mounLocNum = makeMounLocNum(oiv10805.getL3RackNum(), oiv10805.getL3ShlfNum(), oiv10805.getL3CardNum());
			String portNum = makePortNum(oiv10805.getL3PortNum());
			
			l3EquipPortId = findEquipPortId(l3EquipId, mounLocNum, portNum);
			Logger.logger.debug("l3EquipPortId:" + l3EquipPortId);

			mounLocNum = makeMounLocNum(oiv10805.getL2RackNum(), oiv10805.getL2ShlfNum(), oiv10805.getL2CardNum());
			portNum = makePortNum(oiv10805.getL2PortNum());

			l2EquipPortId = findEquipPortId(l2EquipId, mounLocNum, portNum);
			Logger.logger.debug("l2EquipPortId:" + l2EquipPortId);
		} else { /* HFC 도 Port 처리 */
			/*
			String mounLocNum = makeMounLocNum(oiv10805.getL3RackNum(), oiv10805.getL3ShlfNum(), oiv10805.getL3CardNum());
			String portNum = makePortNum(oiv10805.getL3PortNum());
			if (StringUtils.isEmpty(mounLocNum) || StringUtils.isEmpty(portNum)) {
				l3EquipPortId = null;
			} else {
				l3EquipPortId = findEquipPortId(l3EquipId, mounLocNum, portNum);
				Logger.logger.debug("l3EquipPortId:" + l3EquipPortId);
			}
			*/
		}
	}
	
	protected void doOIV10401(OIV10805 oiv10805) throws Exception {
		/* OIV10401 */
		linkId = null;
		if (StringUtils.isEmpty(oiv10805.getL3CellNum())) { /* FTTx */
			linkId = this.findLinkId(l3EquipId, l3EquipPortId, l2EquipId, l2EquipPortId);			
		} else { /* HFC */
			linkId = this.findLinkId(l3EquipId, oiv10805.getL3CellNum(), l3EquipPortId);
		}
		Logger.logger.debug("linkId:" + linkId);
	}
	
	protected void doOIV10402(OIV10805 oiv10805) throws Exception {
		/* 10402 */
		if (linkId == null) {
			throw new CmException(CmException.LINK_ID_NULL);
		}

		thruSerNum = 0;
		
		// 먼저, 고객/단말 정보가 다른 LINK_ID 로 존재하는지 체크
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("custNum", "" + oiv10805.getCustNum());
		hmap.put("weqpMgmtNum", weqpMgmtNum);
		OIV10402 oiv10402 = (OIV10402) tran.selectQidObj(QID.SELECT_OIV10402, hmap);
		
		if (oiv10402 == null) {
			// 고객/단말 정보가 다른 LINK_ID 로 존재하지 않는다면 새로 생성
			hmap.put("linkId", linkId);
			hmap.put("tpoCd", oiv10805.getTpoCd());
			hmap.put("hpyCntrOrgId", oiv10805.getDsnetId());
			try {
				thruSerNum = makeOIV10402(hmap);
			} catch (DBObjectDupException de) {
				// 단말이 다른 고객으로 되어 있는 경우
				// OIV10402, OIV10403, OIV10404 삭제 후 OIV10402 생성
				tran.execute(QID.DELETE_OIV10404__BY_WEQP_MGMT_NUM, hmap);
				tran.execute(QID.DELETE_OIV10403__BY_WEQP_MGMT_NUM, hmap);
				tran.execute(QID.DELETE_OIV10402__BY_WEQP_MGMT_NUM, hmap);
				thruSerNum = makeOIV10402(hmap);
			}
		} else {
			if (StringUtils.equals(linkId, oiv10402.getLinkId()) == false) {
				// 고객/단말 정보가 다른 LINK_ID 로 존재한다면 기존 데이터 업데이트
				hmap = new HashMap<String, String>();
				hmap.put("linkId", linkId);
				Logger.logger.info("BEFORE THRU_SER_NUM : " + thruSerNum + " / " + hmap.get("linkId"));
				thruSerNum = tran.selectQidInt(QID.SELECT_NEW_THRU_SER_NUM, hmap, thruSerNum);
				Logger.logger.info("AFTER THRU_SER_NUM : " + thruSerNum);
				updateOIV1040x(oiv10402, oiv10805);
			} else {
				// 고객/단말 정보가 동일한 LINK_ID 로 존재한다면
				thruSerNum = oiv10402.getThruSerNum();
				if (matchOIV10402(oiv10402, oiv10805) == false) {
					hmap.put("linkId", linkId);
					hmap.put("thruSerNum", ""+thruSerNum);
					hmap.put("tpoCd", oiv10805.getTpoCd());
					hmap.put("hpyCntrOrgId", oiv10805.getDsnetId());
					tran.update(QID.UPDATE_OIV10402, hmap);
				}
			}
		}
		Logger.logger.debug("thruSerNum:" + thruSerNum);
	}
	
	protected void doOIV10403(OIV10805 oiv10805) throws Exception {
		/* 10403 */
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("linkId", linkId);
		hmap.put("thruSerNum", "" + thruSerNum);

		OIV10403 oiv10403 = (OIV10403) tran.selectQidObj(QID.SELECT_OIV10403, hmap);
		if (oiv10403 == null) {
			if (StringUtils.isEmpty(oiv10805.getTelpolNum())) {
				if (StringUtils.isEmpty(oiv10805.getRnTapNum())) {
					return;
				}
			}
			hmap.put("telpolNum", oiv10805.getTelpolNum());
			hmap.put("tapNum", oiv10805.getRnTapNum());
			makeOIV10403(hmap);										
		} else {
			if (matchOIV10403(oiv10403, oiv10805) == false) {
				hmap.put("telpolNum", oiv10805.getTelpolNum());
				hmap.put("tapNum", oiv10805.getRnTapNum());
				tran.update(QID.UPDATE_OIV10403, hmap);
			}
		}
	}
	
	protected void doOIV10404(OIV10805 oiv10805) throws Exception {
		/* 10404 */
		
		Logger.logger.debug("(inetSvcMgmtNum=" + oiv10805.getInetSvcMgmtNum() + "),(phonSvcMgmtNum=" + oiv10805.getPhonSvcMgmtNum() + "),(iptvSvcMgmtNum=" + oiv10805.getIptvSvcMgmtNum() + ")");

		/* LINK_ID, THRU_SER_NUM 기준으로 SVC_MGMT_NUM 조회하여 필요한 경우 삭제 처리 */
		
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("linkId", linkId);
		hmap.put("thruSerNum", "" + thruSerNum);
		
		List<OIV10404> oiv10404List = tran.selectQid2Res(QID.SELECT_OIV10404__BY_THRU_SER_NUM, hmap);
		for (int j = 0; j < oiv10404List.size(); j ++) {
			OIV10404 oiv10404 = (OIV10404) oiv10404List.get(j);
			long svcMgmtNum = oiv10404.getSvcMgmtNum();
			if (svcMgmtNum != oiv10805.getInetSvcMgmtNum() && svcMgmtNum != oiv10805.getPhonSvcMgmtNum() && svcMgmtNum != oiv10805.getIptvSvcMgmtNum()) {
				hmap.put("svcMgmtNum", "" + svcMgmtNum);
				tran.execute(QID.DELETE_OIV10404, hmap);
			}
		}
		
		makeOIV10404(linkId, thruSerNum, oiv10805.getInetSvcMgmtNum());
		makeOIV10404(linkId, thruSerNum, oiv10805.getPhonSvcMgmtNum());
		makeOIV10404(linkId, thruSerNum, oiv10805.getIptvSvcMgmtNum());
	}

	protected String makeMounLocNum(String rack, String shelf, String card) {
		int rackNum = -1;
		int shelfNum = -1;
		int cardNum = -1;
		try {
			rackNum = Integer.parseInt(rack);
		} catch (NumberFormatException e) {
			rackNum = -1;
		}
		try {
			shelfNum = Integer.parseInt(shelf);
		} catch (NumberFormatException e) {
			shelfNum = -1;
		}
		try {
			cardNum = Integer.parseInt(card);
		} catch (NumberFormatException e) {
			cardNum = -1;
		}
		if (rackNum != -1) {
			return rackNum + "/" + shelfNum + "/" + cardNum;
		}
		if (shelfNum != -1) {
			return shelfNum + "/" + cardNum;
		}
		return "" + cardNum;
	}
	
	protected String makePortNum(String port) throws Exception {
		try {
			return "" + Integer.parseInt(port);
		} catch (NumberFormatException e) {
			return "0";
		}
	}
	
	protected String makeOIV10400(String equipId, String mounLocNum, String portNum) throws Exception {
		String newEquipPortId = tran.selectQidStr(QID.SELECT_NEW_EQUIP_PORT_ID, "");
		Logger.logger.debug("newEquipPortId:" + newEquipPortId);

		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("equipId", equipId);
		hmap.put("equipPortId", newEquipPortId);
		hmap.put("auditId", auditId);
		hmap.put("mounLocNum", mounLocNum);
		hmap.put("portNum", portNum);
		hmap.put("portTypCd", "0");
		hmap.put("portSpeedCd", "0");
		hmap.put("pollingMObjYn", "N");
		hmap.put("pingMObjYn", "Y");
		hmap.put("rgstCycl", "0");
		
		tran.create(QID.INSERT_OIV10400, hmap);

		return newEquipPortId;
	}
	
	protected String makeOIV10401(HashMap<String, String> hmap) throws Exception {
		String newLinkId = tran.selectQidStr(QID.SELECT_NEW_LINK_ID, "");
		Logger.logger.debug("newLinkId:" + newLinkId);

		hmap.put("linkId", newLinkId);
		hmap.put("auditId", auditId);
		hmap.put("linkTypCd", "01");
		hmap.put("linkUsgCd", "WEQP");
		hmap.put("linkRngCd", "000");
		
		tran.create(QID.INSERT_OIV10401, hmap);

		return newLinkId;
	}

	protected int makeOIV10402(HashMap<String, String> hmap) throws Exception {
		int thruSerNum = 0;
		thruSerNum = tran.selectQidInt(QID.SELECT_NEW_THRU_SER_NUM, hmap, thruSerNum);
		Logger.logger.debug("new thruSerNum:" + thruSerNum);

		hmap.put("thruSerNum", ""+thruSerNum);
		hmap.put("auditId", auditId+":I");
		
		tran.create(QID.INSERT_OIV10402, hmap);

		return thruSerNum;
	}

	protected void makeOIV10403(HashMap<String, String> hmap) throws Exception {
		hmap.put("auditId", auditId);
		
		tran.create(QID.INSERT_OIV10403, hmap);
	}

	protected void makeOIV10404(String linkId, int thruSerNum, long svcMgmtNum) throws Exception {
		if (svcMgmtNum == 0) {
			return;
		}
		Logger.logger.debug("(linkId:" + linkId + ",(thruSerNum=" + thruSerNum + "),(svcMgmtNum=" + svcMgmtNum + ")");
		
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("linkId", linkId);
		hmap.put("thruSerNum", "" + thruSerNum);
		hmap.put("svcMgmtNum", "" + svcMgmtNum);

		OIV10404 oiv10404 = (OIV10404) tran.selectQidObj(QID.SELECT_OIV10404, hmap);
		if (oiv10404 == null) {
			hmap.put("auditId", auditId);
			tran.create(QID.INSERT_OIV10404, hmap);
		}
	}

	protected boolean matchOIV10402(OIV10402 oiv10402, OIV10805 oiv10805) throws Exception {
		if (oiv10402.getCustNum() != oiv10805.getCustNum()) return false;
		if (oiv10402.getTpoCd() == null) {
			if (oiv10805.getTpoCd().length() > 0) return false;
		} else {
			if (oiv10402.getTpoCd().equals(oiv10805.getTpoCd()) == false) return false;
		}
		if (oiv10402.getHpyCntrOrgId() == null) {
			if (oiv10805.getDsnetId().length() > 0) return false;
		} else {
			if (oiv10402.getHpyCntrOrgId().equals(oiv10805.getDsnetId()) == false) return false;
		}
		
		return true;
	}

	protected boolean matchOIV10403(OIV10403 oiv10403, OIV10805 oiv10805) throws Exception {
		if (oiv10403.getTelpolNum() == null) {
			if (oiv10805.getTelpolNum().length() > 0) return false;
		} else {
			if (oiv10403.getTelpolNum().equals(oiv10805.getTelpolNum()) == false) return false;
		}
		if (oiv10403.getTapNum() == null) {
			if (oiv10805.getRnTapNum().length() > 0) return false;
		} else {
			if (oiv10403.getTapNum().equals(oiv10805.getRnTapNum()) == false) return false;
		}
		
		return true;
	}
	
	protected void findWeqpMgmtNumByMacAddr(String macAddr) throws Exception {
		weqpMgmtNum = tran.selectQidStr(QID.SELECT_WEQP_MGMT_NUM_IN_OIV10809_BY_MAC_ADDR_VAL, macAddr);

		if (StringUtils.isEmpty(weqpMgmtNum)) {
			//throw new CmException(CmException.NOT_FOUND_WEQP_MGMT_NUM, macAddr);
			weqpMgmtNum = tran.selectQidStr(QID.SELECT_WEQP_MGMT_NUM_IN_OIV10809_BY_MFACT_SER_NUM, macAddr);
			if (StringUtils.isEmpty(weqpMgmtNum)) {
				throw new CmException(CmException.NOT_FOUND_WEQP_MGMT_NUM, macAddr);
			}
		}
		Logger.logger.info("trying to insert " + weqpMgmtNum + " to OIV10800");
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("auditId", auditId);
		hmap.put("weqpMgmtNum", weqpMgmtNum);
		tran.create(QID.INSERT_OIV10800__BY_OIV10809, hmap);
	}

	protected void findWeqpMgmtNumByWeqpMgmtNum(String wmn) throws Exception {
		weqpMgmtNum = tran.selectQidStr(QID.SELECT_WEQP_MGMT_NUM_IN_OIV10809_BY_WEQP_MGMT_NUM, wmn);
		if (StringUtils.isEmpty(weqpMgmtNum)) {
			throw new CmException(CmException.NOT_FOUND_WEQP_MGMT_NUM, weqpMgmtNum);
		} else {
			Logger.logger.info("trying to insert " + weqpMgmtNum + " to OIV10800");
			HashMap<String, String> hmap = new HashMap<String, String>();
			hmap.put("auditId", auditId);
			hmap.put("weqpMgmtNum", weqpMgmtNum);
			tran.create(QID.INSERT_OIV10800__BY_OIV10809, hmap);
		}
	}
	
	protected void updateOIV1040x(OIV10402 oiv10402, OIV10805 oiv10805) throws Exception {
		// oiv10402 : old linkId, thruSerNum
		Logger.logger.info("(" + oiv10402.getLinkId() + "," + oiv10402.getThruSerNum() + ") -> (" + linkId + "," + thruSerNum + ") " + 
		oiv10402.getWeqpMgmtNum() + ", " + oiv10402.getCustNum());
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("newLinkId", linkId);
		hmap.put("newThruSerNum", "" + thruSerNum);
		hmap.put("oldLinkId", oiv10402.getLinkId());
		hmap.put("oldThruSerNum", "" + oiv10402.getThruSerNum());
		hmap.put("tpoCd", oiv10805.getTpoCd());
		hmap.put("hpyCntrOrgId", oiv10805.getDsnetId());
		hmap.put("auditId", auditId+":U");
		tran.update(QID.UPDATE_OIV10402_PK, hmap);
		hmap.put("telpolNum", oiv10805.getTelpolNum());
		hmap.put("tapNum", oiv10805.getRnTapNum());
		try {
			tran.update(QID.UPDATE_OIV10403_PK, hmap);
		} catch (DBObjectDupException de) {
			hmap = new HashMap<String, String>();
			hmap.put("linkId", oiv10402.getLinkId());
			hmap.put("thruSerNum", "" + oiv10402.getThruSerNum());
			tran.execute(QID.DELETE_OIV10403, hmap);
		}
		try {
			hmap = new HashMap<String, String>();
			hmap.put("newLinkId", linkId);
			hmap.put("newThruSerNum", "" + thruSerNum);
			hmap.put("oldLinkId", oiv10402.getLinkId());
			hmap.put("oldThruSerNum", "" + oiv10402.getThruSerNum());
			tran.update(QID.UPDATE_OIV10404_PK, hmap);
		} catch (DBObjectDupException de) {
			hmap = new HashMap<String, String>();
			hmap.put("linkId", oiv10402.getLinkId());
			hmap.put("thruSerNum", "" + oiv10402.getThruSerNum());
			tran.execute(QID.DELETE_OIV10404__ALL_SVC, hmap);
		}
	}
	
	protected void updateWeqpRel(String linkId, long custNum) throws Exception {
		// LINK_ID, CUST_NUM 기준
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("linkId", linkId);
		hmap.put("custNum", ""+custNum);
		
		List<WeqpRelVO> weqpRelVOList = tran.selectQid2Res(QID.SELECT_WEQP_REL, hmap);
		if (weqpRelVOList == null || weqpRelVOList.size() == 0) {
			return;
		}
		if (FTTX.equals(weqpRelVOList.get(0).getNetClCd())) {
			// ONT - AP - STB/기타
			List<WeqpRelVO> ontList = new ArrayList<WeqpRelVO>(); 
			List<WeqpRelVO> apList = new ArrayList<WeqpRelVO>(); 
			List<WeqpRelVO> stbList = new ArrayList<WeqpRelVO>();
			for (int i = 0; i < weqpRelVOList.size(); i ++) {
				WeqpRelVO weqpRelVO = weqpRelVOList.get(i); 
				if (ONT.equals(weqpRelVO.getWeqpMdlTypCd())) {
					ontList.add(weqpRelVO);
				} else if (AP.equals(weqpRelVO.getWeqpMdlTypCd())) {
					apList.add(weqpRelVO);
				} else {
					stbList.add(weqpRelVO);
				}
			}
			for (int i = 0; i < weqpRelVOList.size(); i ++) {
				WeqpRelVO weqpRelVO = weqpRelVOList.get(i);
				if (AP.equals(weqpRelVO.getWeqpMdlTypCd())) {
					WeqpRelVO pWeqp = findWeqp(ontList, weqpRelVO.getRepSvcMgmtNum());
					if (pWeqp != null) {
						weqpRelVO.setNewSupWeqpMgmtNum(pWeqp.getWeqpMgmtNum());
					}
				} else if (STB.equals(weqpRelVO.getWeqpMdlTypCd()) || ETC.equals(weqpRelVO.getWeqpMdlTypCd())) {
					// AP 에서 동일한 서비스관리번호 찾기
					WeqpRelVO pWeqp = findWeqp(apList, weqpRelVO.getRepSvcMgmtNum());
					if (pWeqp != null) {
						weqpRelVO.setNewSupWeqpMgmtNum(pWeqp.getWeqpMgmtNum());
					} else {
						// AP 에서 찾지 못했다면, ONT 에서 서비스관리번호 찾기
						pWeqp = findWeqp(ontList, weqpRelVO.getRepSvcMgmtNum());
						if (pWeqp != null) {
							weqpRelVO.setNewSupWeqpMgmtNum(pWeqp.getWeqpMgmtNum());
						} else {
							// ONT 에서도 못 찾았다면, 첫번째 AP 와 연결
							if (apList.size() > 0) {
								weqpRelVO.setNewSupWeqpMgmtNum(apList.get(0).getWeqpMgmtNum());
							} else {
								// AP 가 없다면 ONT 로 연결
								if (ontList.size() > 0) {
									weqpRelVO.setNewSupWeqpMgmtNum(ontList.get(0).getWeqpMgmtNum());
								}
							}
						}
					}
				}
			}
		} else if (HFC.equals(weqpRelVOList.get(0).getNetClCd())) {
			// CM - AP - STB/기타
			List<WeqpRelVO> cmList = new ArrayList<WeqpRelVO>(); 
			List<WeqpRelVO> apList = new ArrayList<WeqpRelVO>(); 
			List<WeqpRelVO> stbList = new ArrayList<WeqpRelVO>();
			for (int i = 0; i < weqpRelVOList.size(); i ++) {
				WeqpRelVO weqpRelVO = weqpRelVOList.get(i); 
				if (CM.equals(weqpRelVO.getWeqpMdlTypCd())) {
					cmList.add(weqpRelVO);
				} else if (AP.equals(weqpRelVO.getWeqpMdlTypCd())) {
					apList.add(weqpRelVO);
				} else {
					stbList.add(weqpRelVO);
				}
			}
			for (int i = 0; i < weqpRelVOList.size(); i ++) {
				WeqpRelVO weqpRelVO = weqpRelVOList.get(i);
				if (AP.equals(weqpRelVO.getWeqpMdlTypCd())) {
					WeqpRelVO pWeqp = findWeqp(cmList, weqpRelVO.getRepSvcMgmtNum());
					if (pWeqp != null) {
						weqpRelVO.setNewSupWeqpMgmtNum(pWeqp.getWeqpMgmtNum());
					}
				} else if (STB.equals(weqpRelVO.getWeqpMdlTypCd()) || ETC.equals(weqpRelVO.getWeqpMdlTypCd())) {
					// AP 에서 동일한 서비스관리번호 찾기
					WeqpRelVO pWeqp = findWeqp(apList, weqpRelVO.getRepSvcMgmtNum());
					if (pWeqp != null) {
						weqpRelVO.setNewSupWeqpMgmtNum(pWeqp.getWeqpMgmtNum());
					} else {
						// AP 에서 찾지 못했다면, CM 에서 서비스관리번호 찾기
						pWeqp = findWeqp(cmList, weqpRelVO.getRepSvcMgmtNum());
						if (pWeqp != null) {
							weqpRelVO.setNewSupWeqpMgmtNum(pWeqp.getWeqpMgmtNum());
						} else {
							// CM 에서도 못 찾았다면, 첫번째 AP 와 연결
							if (apList.size() > 0) {
								weqpRelVO.setNewSupWeqpMgmtNum(apList.get(0).getWeqpMgmtNum());
							} else {
								// AP 가 없다면 CM 으로 연결
								if (cmList.size() > 0) {
									weqpRelVO.setNewSupWeqpMgmtNum(cmList.get(0).getWeqpMgmtNum());
								}
							}
						}
					}
				}
			}
		} else {
			return;
		}
		for (int i = 0; i < weqpRelVOList.size(); i ++) {
			WeqpRelVO weqp = weqpRelVOList.get(i);
			Logger.logger.debug(weqp.debugMessage());
			if (StringUtils.equals(weqp.getSupWeqpMgmtNum(), weqp.getNewSupWeqpMgmtNum()) == false) {
				tran.update(QID.UPDATE_OIV10402_SUP_WEQP_MGMT_NUM, weqp);
			}
		}
	}
	
	private WeqpRelVO findWeqp(List<WeqpRelVO> weqpList, String svcMgmtNum) {
		if (StringUtils.isEmpty(svcMgmtNum)) return null;
		for (int i = 0; i < weqpList.size(); i ++) {
			if (svcMgmtNum.equals(weqpList.get(i).getRepSvcMgmtNum())) {
				return weqpList.get(i);
			}
		}
		return null;
	}
	
	private void doOIV10907(OIV10805 oiv10805) throws Exception {
		if (StringUtils.isEmpty(oiv10805.getInfoCntrCd()) || StringUtils.isEmpty(oiv10805.getDsnetId()) || StringUtils.isEmpty(oiv10805.getDsnetNm())) {
			return;
		}
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("auditId", auditId);
		hmap.put("infoCntrCd", oiv10805.getInfoCntrCd());
		hmap.put("orgId", oiv10805.getDsnetId());		
		hmap.put("orgNm", oiv10805.getDsnetNm());
		tran.update(QID.INSERT_OIV10907, hmap);
	}
	
	private void remove(OIV10805 oiv10805) throws Exception {
		// 고객/단말 정보가 존재하는지 체크
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("custNum", "" + oiv10805.getCustNum());
		hmap.put("weqpMgmtNum", weqpMgmtNum);
		OIV10402 oiv10402 = (OIV10402) tran.selectQidObj(QID.SELECT_OIV10402, hmap);
		if (oiv10402 == null) {
			throw new CmException(CmException.FAIL_TO_OUT);
		}
		// delete OIV10404
		hmap = new HashMap<String, String>();
		hmap.put("linkId", oiv10402.getLinkId());
		hmap.put("thruSerNum", "" + oiv10402.getThruSerNum());
		tran.execute(QID.DELETE_OIV10404__ALL_SVC, hmap);
		// delete OIV10403
		tran.execute(QID.DELETE_OIV10403, hmap);
		// delete OIV10402
		tran.execute(QID.DELETE_OIV10402, hmap);
	}
	
	private String findEquipId(String equipMgmtNum) throws Exception {
		String equipId = null;
		if (o100Map != null) {
			OIV10100 o100 = o100Map.get(equipMgmtNum);
			if (o100 != null) {
				return o100.getEquipId();
			}
		} else {
			o100Map = new HashMap<String, OIV10100>();
		}
		equipId = tran.selectQidStr(QID.SELECT_EQUIP_ID__BY_EQUIP_MGMT_NUM, equipMgmtNum);
		if (StringUtils.isEmpty(equipId) == false) {
			OIV10100 o100 = new OIV10100();
			o100.setEquipId(equipId);
			o100.setEquipMgmtNum(equipMgmtNum);
			o100Map.put(equipMgmtNum, o100);
		}
		return equipId;
	}
	
	private String findEquipPortId(String equipId, String mounLocNum, String portNum) throws Exception {
		
		String key = equipId + "|" + mounLocNum + "|" + portNum;
		String equipPortId = equipPortIdMap.get(key);
		
		if (equipPortId != null) return equipPortId;
		
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("equipId", equipId);
		hmap.put("mounLocNum", mounLocNum);
		hmap.put("portNum", portNum);
		
		equipPortId = tran.selectQidStr(QID.SELECT_EQUIP_PORT_ID, hmap);
		if (equipPortId != null) {
			equipPortIdMap.put(key, equipPortId);
		} else {
			equipPortId = makeOIV10400(equipId, mounLocNum, portNum);
			if (equipPortId != null) {
				equipPortIdMap.put(key, equipPortId);
			}
		}

		return equipPortId;
	}
	
	private String findLinkId(String aEquipId, String aEquipPortId, String zEquipId, String zEquipPortId) throws Exception {
		String key = aEquipId + "|" + aEquipPortId + "|" + zEquipId + "|" + zEquipPortId;
		String sLinkId = linkIdMap.get(key);
		if (sLinkId != null) return sLinkId;

		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("adrcEquipId", aEquipId);
		hmap.put("adrcEquipPortId", aEquipPortId);
		hmap.put("zdrcEquipId", zEquipId);
		hmap.put("zdrcEquipPortId", zEquipPortId);
		
		sLinkId = tran.selectQidStr(QID.SELECT_LINK_ID__FOR_FTTX, hmap);
		if (sLinkId != null) {
			linkIdMap.put(key, sLinkId);
		} else {
			sLinkId = makeOIV10401(hmap);
			if (sLinkId != null) {
				linkIdMap.put(key, sLinkId);
			}
		}

		return sLinkId;
	}

	private String findLinkId(String aEquipId, String aCellNum, String aEquipPortId) throws Exception {
		String key = aEquipId + "|" + aCellNum;
		String sLinkId = linkIdMap.get(key);
		if (sLinkId != null) return sLinkId;

		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("adrcEquipId", aEquipId);
		hmap.put("adrcCcellNum", aCellNum);
		
		OIV10401 o401 = (OIV10401) tran.selectQidObj(QID.SELECT_OIV10401__FOR_HFC, hmap);
		if (o401 != null) {
			sLinkId = o401.getLinkId();
			linkIdMap.put(key, sLinkId);
			/*
			if (StringUtils.equals(aEquipPortId, o401.getAdrcEquipPortId()) == false) {
				//
			}*/
		} else {
			/*
			if (StringUtils.isEmpty(aEquipPortId)) {
				aEquipPortId = "-";
			}
			hmap.put("adrcEquipPortId", aEquipPortId);
			*/
			hmap.put("adrcEquipPortId", "-");
			hmap.put("zdrcEquipId", "-");
			hmap.put("zdrcEquipPortId", "-");
			sLinkId = makeOIV10401(hmap);
			if (sLinkId != null) {
				linkIdMap.put(key, sLinkId);
			}
		}

		return sLinkId;
	}

	protected void updateRepSvcMgmtNum(String linkId, long custNum) throws Exception {
		;
	}
}
