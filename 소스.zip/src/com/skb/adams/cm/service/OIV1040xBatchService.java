package com.skb.adams.cm.service;

import java.util.HashMap;
import java.util.List;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.dao.OIV1040xQid;
import com.skb.adams.cm.model.OIV10402;
import com.skb.adams.cm.model.OIV10403;
import com.skb.adams.cm.model.OIV10404;
import com.skb.adams.cm.model.OIV10805;

public class OIV1040xBatchService extends OIV1040xService {

	public OIV1040xBatchService() {
	}

	@Override
	protected void doOIV10402(OIV10805 oiv10805) throws Exception {
		/* 10402 */
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("linkId", linkId);
		hmap.put("weqpMgmtNum", weqpMgmtNum);
		hmap.put("custNum", ""+oiv10805.getCustNum());
		hmap.put("tpoCd", oiv10805.getTpoCd());
		hmap.put("hpyCntrOrgId", oiv10805.getDsnetId());
		thruSerNum = makeOIV10402(hmap);
		Logger.logger.debug("thruSerNum:" + thruSerNum);
	}
	
	@Override
	protected void doOIV10403(OIV10805 oiv10805) throws Exception {
		/* 10403 */
		if (oiv10805.getTelpolNum() == null || oiv10805.getTelpolNum().isEmpty()) {
			if (oiv10805.getRnTapNum() == null || oiv10805.getRnTapNum().isEmpty()) {
				return;
			}
		}
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("linkId", linkId);
		hmap.put("thruSerNum", "" + thruSerNum);
		hmap.put("telpolNum", oiv10805.getTelpolNum());
		hmap.put("tapNum", oiv10805.getRnTapNum());
		makeOIV10403(hmap);										
	}
	
	@Override
	protected void doOIV10404(OIV10805 oiv10805) throws Exception {
		/* 10404 */
		Logger.logger.debug("(inetSvcMgmtNum=" + oiv10805.getInetSvcMgmtNum() + "),(phonSvcMgmtNum=" + oiv10805.getPhonSvcMgmtNum() + "),(iptvSvcMgmtNum=" + oiv10805.getIptvSvcMgmtNum() + ")");
		makeOIV10404(linkId, thruSerNum, oiv10805.getInetSvcMgmtNum());
		makeOIV10404(linkId, thruSerNum, oiv10805.getPhonSvcMgmtNum());
		makeOIV10404(linkId, thruSerNum, oiv10805.getIptvSvcMgmtNum());
	}
	
	@Override
	protected void makeOIV10404(String linkId, int thruSerNum, long svcMgmtNum) throws Exception {
		if (svcMgmtNum == 0) {
			return;
		}
		Logger.logger.debug("(linkId:" + linkId + ",(thruSerNum=" + thruSerNum + "),(svcMgmtNum=" + svcMgmtNum + ")");	
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("linkId", linkId);
		hmap.put("thruSerNum", "" + thruSerNum);
		hmap.put("svcMgmtNum", "" + svcMgmtNum);
		hmap.put("auditId", auditId);
		tran.create(QID.INSERT_OIV10404, hmap);
	}
}
