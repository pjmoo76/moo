package com.skb.adams.cm.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.skb.adams.cm.dao.OIV1040xQid;
import com.skb.adams.cm.dao.OIV1071xQid;
import com.skb.adams.cm.model.OIV10100;
import com.skb.adams.cm.model.OIV10402;
import com.skb.adams.cm.model.OIV10403;
import com.skb.adams.cm.model.OIV10404;
import com.skb.adams.cm.model.OIV10805;
import com.skb.adams.cm.util.FileUtils;
import com.skb.adams.cm.util.StringUtils;

import subkjh.bas.dao.control.DaoListener;
import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.dao.exception.DBObjectDupException;
import subkjh.bas.log.LOG_LEVEL;
import subkjh.bas.log.Logger;

public class SwingNEIFService {
	
	static private final int	TOKEN_NO	= 69;	
	static private final String	AUDIT_ID	= "CM-SWG-NEIF";

	// parameter
	Map<String, OIV10100>	o100Map			= null;
	String					outputDirName	= null;

	DbTrans			tran			= null;
	OIV1040xQid		QID				= null;
	OIV1040xService	oiv1040xService	= null;

	int 	totalCnt	= 0;
	int 	successCnt	= 0;
	String	dataFileName = null;
	
	FileOutputStream[]	errorDataFileList	= null;
	static private final int	ERROR_DATA_FILE_INVALID_DATA	= 0;
	static private final int	ERROR_DATA_FILE_NOT_FOUND_EQUIP	= 1;
	static private final int	ERROR_DATA_FILE_NOT_FOUND_WEQP 	= 2;
	static private final int	ERROR_DATA_FILE_FAILED_TO_OUT	= 3;
	static private final int	ERROR_DATA_FILE_ETC				= 4;
	static private final int	ERROR_DATA_FILE_MAX				= 5;
	
	public SwingNEIFService() {
	}
	
	public void setup(Map<String, OIV10100> o100Map, String outputDirName) throws Exception {
		this.o100Map = o100Map;
		this.outputDirName = outputDirName;

		DataBase database = DBManager.getMgr().getDataBase("ADAMS");
		tran = database.createDbTrans("deploy/conf/sql/oiv1040x.xml");
		tran.start();
		QID = new OIV1040xQid();
		oiv1040xService = new OIV1040xService();
		oiv1040xService.set(tran, QID, o100Map);
	}
	
	public void close() {
		tran.stop();
	}
	
	public int getTotalCnt() {
		return totalCnt;
	}
	
	public int getSuccessCnt() {
		return successCnt;
	}

	public boolean load(String filename) {
		Logger.logger.info(filename);
		
		FileInputStream		fr = null;
		BufferedReader		br = null;

		dataFileName = filename;
		
		totalCnt = 0;
		successCnt = 0;

		try {
			
			if (outputDirName != null) {
				errorDataFileList = new FileOutputStream[ERROR_DATA_FILE_MAX];
			}
			
			fr =  new FileInputStream(dataFileName);
			InputStreamReader ir = new InputStreamReader(fr, "eucKR");
			br = new BufferedReader(ir);
			
			String strLine;
			while ((strLine = br.readLine()) != null) {
				
				try {
					totalCnt ++;
					if (process(strLine)) {
						successCnt ++;
					} else {
						writeErrorData(strLine, ERROR_DATA_FILE_ETC);
					}
				} catch (NumberFormatException e) {
					writeErrorData(strLine, ERROR_DATA_FILE_ETC);
				} catch (CmException ce) {
					if (ce.getErrorCode() == CmException.NO_L3_TID ||
							ce.getErrorCode() == CmException.NO_L2_TID ||
							ce.getErrorCode() == CmException.NO_MAC) {
						writeErrorData(strLine, ERROR_DATA_FILE_INVALID_DATA);
					} else if (ce.getErrorCode() == CmException.NOT_FOUND_EQUIP_ID) {
						writeErrorData(strLine, ERROR_DATA_FILE_NOT_FOUND_EQUIP);
					} else if (ce.getErrorCode() == CmException.NOT_FOUND_WEQP_MGMT_NUM) {
						writeErrorData(strLine, ERROR_DATA_FILE_NOT_FOUND_WEQP);
					} else if (ce.getErrorCode() == CmException.FAIL_TO_OUT) {
						writeErrorData(strLine, ERROR_DATA_FILE_FAILED_TO_OUT);
					} else if (ce.getErrorCode() == CmException.LINK_ID_NULL) {
						Logger.logger.error(ce.getErrorCodeString());
						Logger.logger.error(strLine);
					} else {
						writeErrorData(strLine, ERROR_DATA_FILE_ETC);
					}
				} catch (DBObjectDupException de) {
					Logger.logger.error("ERROR at " + totalCnt + " line.");					
				} catch (SQLException se) {
					Logger.logger.error("ERROR at " + totalCnt + " line.");
				}
				
				tran.commit();
				/* for test */
				//if (i >= 1) break;
				if (totalCnt % 1000 == 0) {
					Logger.logger.info(dataFileName + " processed " + totalCnt + " lines ####################");
				}
			}
			Logger.logger.info(dataFileName + " (total:" + totalCnt + "),(success:" + successCnt + ")");
		} catch (Exception e) {
			Logger.logger.error(e);
		} finally {
			try {
				if (br != null) br.close();
				if (fr != null) fr.close();
				if (errorDataFileList != null) {
					for (int i = 0; i < ERROR_DATA_FILE_MAX; i ++) {
						if (errorDataFileList[i] != null) errorDataFileList[i].close();
					}
				}
			} catch (IOException ex) {
				Logger.logger.error(ex.toString());
			}
		}
		tran.commit();

		return true;
	}
	
	private void writeErrorData(String data, int fileIdx) throws Exception {
		if (errorDataFileList == null) return;
		if (errorDataFileList[fileIdx] == null) {
			if (fileIdx == ERROR_DATA_FILE_INVALID_DATA) {
				errorDataFileList[fileIdx] = new FileOutputStream(outputDirName + "/" + dataFileName.substring(dataFileName.lastIndexOf("/")+1) + ".error.invalidData");
			} else if (fileIdx == ERROR_DATA_FILE_NOT_FOUND_EQUIP) {
				errorDataFileList[fileIdx] = new FileOutputStream(outputDirName + "/" + dataFileName.substring(dataFileName.lastIndexOf("/")+1) + ".error.notFoundEquip");
			} else if (fileIdx == ERROR_DATA_FILE_NOT_FOUND_WEQP) {
				errorDataFileList[fileIdx] = new FileOutputStream(outputDirName + "/" + dataFileName.substring(dataFileName.lastIndexOf("/")+1) + ".error.notFoundWeqp");
			} else if (fileIdx == ERROR_DATA_FILE_FAILED_TO_OUT) {
				errorDataFileList[fileIdx] = new FileOutputStream(outputDirName + "/" + dataFileName.substring(dataFileName.lastIndexOf("/")+1) + ".error.failToOut");
			} else {
				errorDataFileList[fileIdx] = new FileOutputStream(outputDirName + "/" + dataFileName.substring(dataFileName.lastIndexOf("/")+1) + ".error.etc");
			}
		}
		errorDataFileList[fileIdx].write(data.getBytes(Charset.forName("eucKR")));
		errorDataFileList[fileIdx].write('\n');
	}
	
	public boolean process(String data) throws Exception {
		Logger.logger.debug(data);
		OIV10805 oiv10805 = make(data);
		if (oiv10805 == null) return false;

		return oiv1040xService.process(oiv10805);
	}
	
	private OIV10805 make(String data) throws Exception {
		OIV10805 oiv10805 = new OIV10805();
		String[] tokens = data.split("\\|");
		if (tokens.length < TOKEN_NO) {
			//Logger.logger.error("invalid token no : " + tokens.length);
			return null;
		}
		for (int i = 0; i < tokens.length; i ++) {
			Logger.logger.debug(i + ":" + tokens[i]);
		}
		oiv10805.setMqSerNum(totalCnt);
		oiv10805.setWeqpGrpCd(tokens[0]);
		oiv10805.setMacAddr(tokens[1]);
		oiv10805.setInoutClCd(tokens[2]); /* 출고 : 1, 입고 : 2 */
		oiv10805.setMfactNm(tokens[3]);
		oiv10805.setEquipMdlNm(tokens[4]);
		if (tokens[5].trim().length() > 0) oiv10805.setCustNum(tokens[5]);
		if (tokens[6].trim().length() > 0) oiv10805.setAcntNum(tokens[6]);
		oiv10805.setEquipCd(tokens[7]);
		oiv10805.setCustNm(tokens[8]);
		oiv10805.setSvcTechMthdCd(tokens[9]);
		oiv10805.setCustAddr(tokens[10]);
		oiv10805.setCustPhonNum(tokens[11]);
		if (tokens[12].trim().length() > 0) oiv10805.setInetSvcNum(tokens[12]);
		if (tokens[13].trim().length() > 0) oiv10805.setInetSvcMgmtNum(tokens[13]);
		if (tokens[14].trim().length() > 0) oiv10805.setPhonSvcNum(tokens[14]);
		if (tokens[15].trim().length() > 0) oiv10805.setPhonSvcMgmtNum(tokens[15]);
		if (tokens[16].trim().length() > 0) oiv10805.setIptvSvcNum(tokens[16]);
		if (tokens[17].trim().length() > 0) oiv10805.setIptvSvcMgmtNum(tokens[17]);
		oiv10805.setInetSvcNm(tokens[18]);
		oiv10805.setPhonSvcNm(tokens[19]);
		oiv10805.setIptvSvcNm(tokens[20]);
		oiv10805.setRltmTvClCd(tokens[21]);
		oiv10805.setInetOrbkStCd(tokens[22]);
		oiv10805.setWphonOrbkStCd(tokens[23]);
		oiv10805.setIptvOrbkStCd(tokens[24]);
		if (tokens[25].trim().length() > 0) oiv10805.setIptvLineCnt(tokens[25]);
		oiv10805.setL3TidVal(tokens[26]);
		oiv10805.setL3EquipId(tokens[27]);
		oiv10805.setL3EquipNm(tokens[28]);
		oiv10805.setL3EquipMfactNm(tokens[29]);
		oiv10805.setL3IpAddr(tokens[30]);
		oiv10805.setInfoCntrCd(tokens[31]);
		oiv10805.setInfcNm(tokens[32]);
		oiv10805.setL3CellNum(tokens[33]);
		oiv10805.setL3RackNum(tokens[34]);
		oiv10805.setL3ShlfNum(tokens[35]);
		oiv10805.setL3CardNum(tokens[36]);
		oiv10805.setL3PortNum(tokens[37]);
		oiv10805.setL2TidVal(tokens[38]);
		oiv10805.setL2EquipId(tokens[39]);
		oiv10805.setL2EquipNm(tokens[40]);
		oiv10805.setL2EquipMfactNm(tokens[41]);
		oiv10805.setL2IpAddr(tokens[42]);
		oiv10805.setTpoCd(tokens[43]);
		oiv10805.setTpoNm(tokens[44]);
		oiv10805.setL2CellNum(tokens[45]);
		oiv10805.setL2RackNum(tokens[46]);
		oiv10805.setL2ShlfNum(tokens[47]);
		oiv10805.setL2CardNum(tokens[48]);
		oiv10805.setL2PortNum(tokens[49]);
		if (tokens[50].length() <= 12) {
			oiv10805.setOnuEquipId(tokens[50]);
		} else {
			oiv10805.setOnuEquipId(tokens[50].substring(0,12));
		}
		oiv10805.setRnTapNum(tokens[51]);
		oiv10805.setTelpolNum(tokens[52]);
		oiv10805.setLdongCd(tokens[53]);
		oiv10805.setAddrId(tokens[54]);
		if (tokens[55].trim().length() > 0) oiv10805.setBldblkNum(tokens[55]);
		if (tokens[56].trim().length() > 0) oiv10805.setBlduntNum(tokens[56]);
		oiv10805.setAssistAddr(tokens[57]);
		oiv10805.setZip(tokens[58]);
		oiv10805.setBasAddr(tokens[59]);
		oiv10805.setDtlAddr(tokens[60]);
		oiv10805.setDsnetId(tokens[61]);
		oiv10805.setDsnetNm(tokens[62]);
		oiv10805.setFstScrbOrgId(tokens[63]);
		oiv10805.setFstScrbOrgNm(tokens[64]);
		oiv10805.setTeamOrgNm(tokens[65]);
		oiv10805.setSvcLinkNum(tokens[66]);
		oiv10805.setSetBldAttrInfo(tokens[67]);
		oiv10805.setAssistMacAddrSerNum(tokens[68]);
		oiv10805.setAuditId(AUDIT_ID);
		
		return oiv10805;
	}
}
