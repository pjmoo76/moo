package com.skb.adams.cm.service;

import java.util.Date;

import com.skb.adams.cm.dao.OIV1040xQid;
import com.skb.adams.cm.model.OIV10805;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.LOG_LEVEL;
import subkjh.bas.log.Logger;

/*
 * IF-SWING-0061 SWMS_AP정보_연동송신, AP 입출고 정보
 */
public class SwingRealApGetService implements MQInterface {

	private final	String	QUEUE_NAME	= "SWN.AP.ADAMS.REQ";
	private	final	String	AUDIT_ID	= "CM-SWG-0061";
	
	DbTrans		tran	= null;
	OIV1040xQid	QID		= null;
	MQService	mqService;

	int dataNo = 0;
	
	public static void main(String[] args) {
		MQService.PROC_MODE procMode = MQService.PROC_MODE.DEV_MODE;
		String	logDirName = null;
		String	logId = null;
		String	debugMode = "INFO";

		for (int i = 0; i < args.length; i ++) {
			String[] tokens = args[i].split("=");
			if ("PROCMODE".equals(tokens[0].toUpperCase())) {
				if("OPER".equals(tokens[1].toUpperCase())) {
					procMode = MQService.PROC_MODE.OPER_MODE;
				}
			} else if ("LOGDIR".equals(tokens[0].toUpperCase())) {
				logDirName = tokens[1];
			} else if ("LOGID".equals(tokens[0].toUpperCase())) {
				logId = tokens[1];
			} else if ("DEBUGMODE".equals(tokens[0].toUpperCase())) {
				if ("DEBUG".equals(tokens[1].toUpperCase())) {
					debugMode = "DEBUG";
				}
			}
		}

		SwingRealApGetService swingRealApGetService = new SwingRealApGetService();
		if (logDirName != null && logId != null) {
			swingRealApGetService.setLogPolicy(debugMode, logDirName, logId);
		}

		try {
			swingRealApGetService.start(procMode);
		} catch (Exception e) {
			Logger.logger.error(e);
		}
	}
	
	public SwingRealApGetService() {
	}

	public void setLogPolicy(String debugMode, String logDir, String logId) {
		Logger.logger = Logger.logger.createLogger(logDir, logId);
		if ("DEBUG".equals(debugMode)) {
			Logger.logger.setLevel(LOG_LEVEL.debug);
		} else {
			Logger.logger.setLevel(LOG_LEVEL.info);
		}
	}
	
	public void start(MQService.PROC_MODE procMode) throws Exception {
		DataBase database = DBManager.getMgr().getDataBase("ADAMS");

		tran = database.createDbTrans("deploy/conf/sql/oiv1040x.xml");
		QID = new OIV1040xQid();

		mqService = new MQService(this, procMode);
		
		mqService.connect();
		mqService.get();
		
		/* for test
		String data = "25751617:20171204171953:4:SW:085DDDEE01D9:001:대우통신:001972C002:Giga AP(머큐리 RUSH-337AC):::::::::::::7282378598:N:N:N::;";
		process(data);
		*/		
	}
	
	@Override
	public String getQueueName() {
		return QUEUE_NAME;
	}
	
	public boolean process(String data) throws Exception {
		Logger.logger.debug(data);
		try {
			OIV10805 oiv10805 = make(data);
			tran.create(QID.INSERT_OIV10805, oiv10805);
			dataNo ++;
			if (dataNo % 100 == 0){
				Logger.logger.info("### processed " + dataNo + " lines ####################");
			}
		} catch (Exception e) {
			Logger.logger.error(e);
			Logger.logger.error("[" + dataNo + "] " + data);
			throw e;
		}
		return true;
	}
	
	private OIV10805 make(String data) throws Exception {
		OIV10805 oiv10805 = new OIV10805();
		String[] tokens = data.split(":");
		for (int i = 0; i < tokens.length; i ++) {
			Logger.logger.debug(i + ":" + tokens[i]);
		}
		if (tokens[0].length() > 0 ) oiv10805.setMqSerNum(tokens[0]);
		oiv10805.setMqChgDtm(tokens[1]);
		oiv10805.setMqExecTms((int)(new Date().getTime()/1000));
		oiv10805.setInoutClCd(tokens[2]);
		oiv10805.setMacAddr(tokens[4]);
		oiv10805.setMfactNm(tokens[6]);
		oiv10805.setEquipMdlNm(tokens[8]);
		if (tokens[9].length() > 0 ) oiv10805.setInetSvcNum(tokens[9]);
		if (tokens[10].length() > 0) oiv10805.setInetSvcMgmtNum(tokens[10]);
		if (tokens[11].length() > 0 ) oiv10805.setPhonSvcNum(tokens[11]);
		if (tokens[12].length() > 0 ) oiv10805.setPhonSvcMgmtNum(tokens[12]);
		if (tokens[13].length() > 0) oiv10805.setIptvSvcNum(tokens[13]);
		if (tokens[14].length() > 0 ) oiv10805.setIptvSvcMgmtNum(tokens[14]);			
		if (tokens[15].length() > 0) {
			oiv10805.setSvcTechMthdCd(tokens[15]);
		} else if (tokens[16].length() > 0) {
			oiv10805.setSvcTechMthdCd(tokens[16]);
		} else if (tokens[17].length() > 0) {
			oiv10805.setSvcTechMthdCd(tokens[17]);
		}
		oiv10805.setInetOrbkStCd(tokens[18]);
		oiv10805.setWphonOrbkStCd(tokens[19]);
		oiv10805.setIptvOrbkStCd(tokens[20]);
		oiv10805.setSvcLinkNum(tokens[21]);
		oiv10805.setAuditId(AUDIT_ID);
		
		return oiv10805;
	}

	@Override
	public void commit() {
		// TODO Auto-generated method stub
		tran.commit();
	}
}
