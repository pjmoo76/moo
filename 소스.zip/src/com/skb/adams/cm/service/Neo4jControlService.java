package com.skb.adams.cm.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import subkjh.bas.log.LOG_LEVEL;
import subkjh.bas.log.Logger;

public class Neo4jControlService {

	class ShellRunner implements Runnable {
		private String command;

		public ShellRunner(String command) {
			this.command = command;
		}

		@Override
		public void run() {
			File f = new File(command);
			if (f.exists() && f.isFile()) {
				Process p;
				try {
					Logger.logger.info("starting " + command);
					p = Runtime.getRuntime().exec(command);

					BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
					String line = "";
					while ((line = br.readLine()) != null) {
						Logger.logger.debug(line);
					}

					p.waitFor();
					Logger.logger.info("finished. (" + command + ")");
				} catch (Exception e) {
					Logger.logger.error(e);
				}

			}
		}
		
	}

	public static void main(String[] args) {
		String logDirName	= null;
		String logId		= null;
		String debugMode	= null;

		for (int i = 0; i < args.length; i ++) {
			String[] tokens = args[i].split("=");
			if ("LOGDIR".equals(tokens[0].toUpperCase())) {
				logDirName = tokens[1];
			} else if ("LOGID".equals(tokens[0].toUpperCase())) {
				logId = tokens[1];
			} else if ("DEBUGMODE".equals(tokens[0].toUpperCase())) {
				if ("DEBUG".equals(tokens[1].toUpperCase())) {
					debugMode = "DEBUG";
				}
			}
		}
		
		Logger.logger = Logger.logger.createLogger(logDirName, logId);
		if ("DEBUG".equals(debugMode)) {
			Logger.logger.setLevel(LOG_LEVEL.debug);
		} else {
			Logger.logger.setLevel(LOG_LEVEL.info);
		}
		
		Neo4jControlService neo4jController = new Neo4jControlService();
		if (neo4jController.getEnv() == false) {
			System.out.println("failed to getEnv()");
			return;
		}
		try {
			neo4jController.run();
		} catch (Exception e) {
			;
		}

	}
	
	static private final int	STEP_EXPORT_DATE			= 0;
	static private final int	STEP_RECREATE_NEO4J_DB		= 1;
	static private final int	STEP_IMPORT_NODE			= 2;
	static private final int	STEP_CREATE_INDEX			= 3;
	static private final int	STEP_DELETE_TRANSCTION_FILE	= 4;
	static private final int	STEP_RESTART_NEO4J			= 5;
	static private final int	STEP_IMPORT_LINK			= 6;
	static private final int	STEP_COMPLETED				= 7;

	static private final int	WAIT_ONE_MINUTE			= (60*1000);
	
	static private final String[] SHELLS = {"skbmi_tp_export.sh",
		"skbmi_tp_recreate_neo4j_db.sh",
		"skbmi_tp_import_node.sh",
		"skbmi_tp_create_index.sh",
		"skbmi_tp_delete_transaction_file.sh",
		"skbmi_tp_restart_neo4j.sh",
		"skbmi_tp_import_link.sh" };
	
	private String	neo4jQueryDir	= null;
	private String	neo4jImportDir	= null;
	private String	neo4jBinDir		= null;
	private String	neo4jDbDir		= null;
	
	private	int		workStep;
	private	long	startTime;
	private	boolean	failedToImportLink = false;

	public Neo4jControlService() {
	}
	
	private boolean getEnv() {
		neo4jQueryDir = System.getenv("NEO4J_QUERY");
		if (neo4jQueryDir == null) return false;
		neo4jImportDir = System.getenv("NEO4J_IMPORT");
		if (neo4jImportDir == null) return false;
		neo4jBinDir = System.getenv("NEO4J_BIN");
		if (neo4jBinDir == null) return false;
		neo4jDbDir = System.getenv("NEO4J_DB");		
		if (neo4jDbDir == null) return false;
		
		Logger.logger.info("(neo4jQueryDir=" + neo4jQueryDir + "),(neo4jImportDir=" + neo4jImportDir + "),(neo4jBinDir=" + neo4jBinDir + "),(neo4jDbDir=" + neo4jDbDir + ")");
		
		return true;
	}
	
	public void run() throws Exception {
		if (getEnv() == false) {
			throw new Exception("failed to get env");
		}
		workStep = STEP_EXPORT_DATE;
		while (workStep != STEP_COMPLETED) {
			startTime = System.currentTimeMillis();
			Thread t = new Thread(new ShellRunner(neo4jQueryDir + "/" + SHELLS[workStep]));
			t.start();
			while (true) {
				t.join(WAIT_ONE_MINUTE);
				Logger.logger.debug("after join()");
				if (t.isAlive()) {
					Logger.logger.debug("thread is alive.");
					if (isProcessing(workStep) == false) {
						t.interrupt();
						workStep --;
						break;
					}
				} else {
					if (checkResult(workStep)) {
						workStep ++;
					} else {
						t.interrupt();
						workStep --;
					}
					if (failedToImportLink) Thread.sleep(WAIT_ONE_MINUTE);
					break;
				}
			}
		}
	}
	
	private boolean isProcessing(int workStep) throws Exception {
		if (workStep == STEP_EXPORT_DATE) return true;
		if (workStep == STEP_RECREATE_NEO4J_DB) return true;
		if (workStep == STEP_IMPORT_NODE) return true;
		if (workStep == STEP_CREATE_INDEX) return true;
		if (workStep == STEP_DELETE_TRANSCTION_FILE) return true;
		if (workStep == STEP_RESTART_NEO4J) return true;
		if (workStep == STEP_IMPORT_LINK) {
			if (checkTransactionDbChagned()) {
				return true;
			}
			long curTime = System.currentTimeMillis();
			// 3분 동안 변화가 없다면....
			if (curTime - startTime >= WAIT_ONE_MINUTE * 3) {
				return false;
			}
			return true;
		}
		return true;
	}

	private boolean checkResult(int workStep) {
		if (workStep == STEP_EXPORT_DATE) return true;
		if (workStep == STEP_RECREATE_NEO4J_DB) return true;
		if (workStep == STEP_IMPORT_NODE) return true;
		if (workStep == STEP_CREATE_INDEX) return true;
		if (workStep == STEP_DELETE_TRANSCTION_FILE) return true;
		if (workStep == STEP_RESTART_NEO4J) return true;
		if (workStep == STEP_IMPORT_LINK) return true;
		return true;
	}
	
	private boolean checkTransactionDbChagned() throws Exception {
		File folder = new File(neo4jDbDir);
		File[] files = folder.listFiles();
		if (files == null) {
			throw new Exception("invalid NEO4J_DB");
		}
		Pattern pattern = Pattern.compile("neostore.transaction.db.[0-9].*");
		for (File file : files) {
			if (file.isFile()) {
				String inFilename = file.getName();
				Matcher matcher = pattern.matcher(inFilename);
				if (matcher.find()) {
					Logger.logger.debug(inFilename);
					if (file.length() > 1000) {
						return true;
					}
				}
			}
		}
		failedToImportLink = true;

		return false;
	}

}
