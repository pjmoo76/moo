package com.skb.adams.cm.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.skb.adams.cm.dao.OIV1040xQid;
import com.skb.adams.cm.model.OIV10100;
import com.skb.adams.cm.util.FileUtils;
import com.skb.adams.cm.util.StringUtils;

import subkjh.bas.dao.control.DaoListener;
import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.LOG_LEVEL;
import subkjh.bas.log.Logger;

public class SwingNEIFServiceManager implements DaoListener {
	
	public static void main(String[] args) {
		// parameters: sourceDir=/app/swing/batch/subscriber files=BOS2IFNMS_[0-9].* noday=true [day=20171209] [dayOffset=1]
		//             splitDir outputDir logDir logId debugMode={debug/info} threadNo=
		//             endFile= waitTime=

		String	sourceDirName	= null;
		String	fileNames		= null;
		String	day				= null;
		int		dayOffset		= 0;
		boolean noDay			= false;
		String	splitDirName	= null;
		String	outputDirName	= null;
		int		threadNo		= 1;
		String	endFileName		= null;
		int		waitTime		= 0;
		
		String	logDirName = null;
		String	logId = null;
		String	debugMode = "INFO";
		
		for (int i = 0; i < args.length; i ++) {
			String[] tokens = args[i].split("=");
			if ("SOURCEDIR".equals(tokens[0].toUpperCase())) {
				sourceDirName = tokens[1];
			} else if ("FILES".equals(tokens[0].toUpperCase())) {
				fileNames = tokens[1];
			} else if ("DAY".equals(tokens[0].toUpperCase())) {
				day = tokens[1];
			} else if ("DAYOFFSET".equals(tokens[0].toUpperCase())) {
				dayOffset = Integer.parseInt(tokens[1]);
			} else if ("NODAY".equals(tokens[0].toUpperCase())) {
				if ("TRUE".equals(tokens[1].toUpperCase())) {
					noDay = true;
				}
			} else if ("SPLITDIR".equals(tokens[0].toUpperCase())) {
				splitDirName = tokens[1];
			} else if ("OUTPUTDIR".equals(tokens[0].toUpperCase())) {
				outputDirName = tokens[1];
			} else if ("THREADNO".equals(tokens[0].toUpperCase())) {
				threadNo = Integer.parseInt(tokens[1]);
			} else if ("ENDFILE".equals(tokens[0].toUpperCase())) {
				endFileName = tokens[1];
			} else if ("WAITTIME".equals(tokens[0].toUpperCase())) {
				waitTime = Integer.parseInt(tokens[1]);
			} else if ("LOGDIR".equals(tokens[0].toUpperCase())) {
				logDirName = tokens[1];
			} else if ("LOGID".equals(tokens[0].toUpperCase())) {
				logId = tokens[1];
			} else if ("DEBUGMODE".equals(tokens[0].toUpperCase())) {
				if ("DEBUG".equals(tokens[1].toUpperCase())) {
					debugMode = "DEBUG";
				}
			}
		}
		if (sourceDirName == null || fileNames == null) {
			System.out.println("invalid paramter. (dir=" + sourceDirName + " file=" + fileNames + ")");
			return;
		}
		
		if (logDirName != null && logId != null) {
			Logger.logger = Logger.logger.createLogger(logDirName, logId);
			if ("DEBUG".equals(debugMode)) {
				Logger.logger.setLevel(LOG_LEVEL.debug);
			} else {
				Logger.logger.setLevel(LOG_LEVEL.info);
			}
		}
		
		SwingNEIFServiceManager swingNEIFSvcMgr = new SwingNEIFServiceManager();

		swingNEIFSvcMgr.setSourceDirName(sourceDirName);
		swingNEIFSvcMgr.setFileNames(fileNames);
		swingNEIFSvcMgr.setDay(day);
		swingNEIFSvcMgr.setDayOffset(dayOffset);
		swingNEIFSvcMgr.setNoDay(noDay);
		swingNEIFSvcMgr.setSplitDirName(splitDirName);
		swingNEIFSvcMgr.setOutputDirName(outputDirName);
		swingNEIFSvcMgr.setThreadNo(threadNo);
		swingNEIFSvcMgr.setEndFileName(endFileName);
		swingNEIFSvcMgr.setWaitTime(waitTime);
		
		try {
			swingNEIFSvcMgr.run();
		} catch (Exception e) {
			Logger.logger.error(e);
		}

	}
	
	class SplitInfo {
		String				infoCntrCd;
		FileOutputStream	fw;
		int					recCnt;
	}

	class WorkResult {
		public int		threadIdx;
		public String	fileName;
		public int		totalCnt;
		public int		successCnt;
	}

	static private final int	TOKEN_NO				= 69;
	static private final int	WAIT_ONE_MINUTE			= (60*1000);
	
	// parameters
	private String	sourceDirName	= null;
	private String	fileNames		= null;
	private String	day				= null;
	private int		dayOffset		= 0;
	private boolean noDay			= false;
	private String	splitDirName	= null;
	private String	outputDirName	= null;
	private	int		threadNo		= 1;
	private	String	endFileName		= null;
	private	int		waitTime		= 0;

	Map<String, SplitInfo>	splitMap		= null;
	Map<String, OIV10100>	o100Map			= null;
	Queue<String>			fileQueue		= null;
	ArrayList<WorkResult>	workResultList	= null;

	int 	totalCnt	= 0;
	int 	successCnt	= 0;
	String	ymd  = null;

	public SwingNEIFServiceManager() {
	}
	
	public void setSourceDirName(String sourceDirName) {
		this.sourceDirName = sourceDirName;
	}

	public void setFileNames(String fileNames) {
		this.fileNames = fileNames;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public void setDayOffset(int dayOffset) {
		this.dayOffset = dayOffset;
	}

	public void setNoDay(boolean noDay) {
		this.noDay = noDay;
	}

	public void setSplitDirName(String splitDirName) {
		this.splitDirName = splitDirName;
	}

	public String getOutputDirName() {
		return this.outputDirName;
	}
	
	public void setOutputDirName(String outputDirName) {
		this.outputDirName = outputDirName;
	}
	
	public void setThreadNo(int threadNo) {
		this.threadNo = threadNo;
	}

	public void setEndFileName(String endFileName) {
		this.endFileName = endFileName;
	}

	public void setWaitTime(int waitTime) {
		this.waitTime = waitTime;
	}

	public Map<String, OIV10100> getO100Map() {
		return this.o100Map;
	}
	
	public Queue<String> getFileQueue() {
		return this.fileQueue;
	}
	
	public void addWorkResult(int threadIdx, String fileName, int totalCnt, int successCnt) {
		WorkResult workResult = new WorkResult();
		workResult.threadIdx = threadIdx;
		workResult.fileName = fileName;
		workResult.totalCnt = totalCnt;
		workResult.successCnt = successCnt;
		workResultList.add(workResult);
	}
	
	public void run() throws Exception {
		Logger.logger.error(">>ver.20200901.");
		Logger.logger.info("sourceDirName=" + sourceDirName);
		Logger.logger.info("fileNames=" + fileNames);
		Logger.logger.info("day=" + day);
		Logger.logger.info("dayOffset=" + dayOffset);
		Logger.logger.info("noDay=" + noDay);
		Logger.logger.info("splitDirName=" + splitDirName);
		Logger.logger.info("outputDirName=" + outputDirName);
		Logger.logger.info("threadNo=" + threadNo);
		Logger.logger.info("endFileName=" + endFileName);
		Logger.logger.info("waitTime=" + waitTime);
		
		if (StringUtils.isEmpty(endFileName) == false) {
			if (checkEndFile() == false) {
				Logger.logger.error("checkEndFile() is failed.");
				return;
			}
		}
		
		List<String> fileList = null;
		
		if (checkBosFile() == false) {
			Logger.logger.error("checkBosFile() is failed.");
			return;
		} else {
			fileList = getSourceFiles();
			if (fileList == null || fileList.size() == 0) {
				Logger.logger.error("no file...");
				return;
			}
		}

		splitDirName = splitDirName + "/" + ymd;

		if (FileUtils.mkdir(splitDirName) == false) {
			Logger.logger.error("failed to create " + splitDirName);
			return;
		}

		DataBase database = DBManager.getMgr().getDataBase("ADAMS");
		DbTrans tran = database.createDbTrans("deploy/conf/sql/oiv1040x.xml");
		tran.start();
		tran.setDaoListener(this);
		o100Map = new ConcurrentHashMap<String,OIV10100>();
		OIV1040xQid QID = new OIV1040xQid();
		tran.selectQid2Res(QID.SELECT_OIV10100, null);
		Logger.logger.info("O10100 MAP Size = " + o100Map.size());
		tran.setDaoListener(null);
		tran.stop();
		
		splitMap = new HashMap<String, SplitInfo>();
		for (String fName : fileList) {
			split(fName);
		}
		
		fileQueue = getSplitedFiles();
		if (fileQueue == null || fileQueue.size() == 0) {
			Logger.logger.error("no queue...");
			return;
		}
		
		workResultList = new ArrayList<WorkResult>();
		ArrayList<Thread> threads = new ArrayList<Thread>();
		for (int i = 0; i < threadNo; i ++) {
			Thread t = new Thread(new Runner(i, this));
			t.start();
			threads.add(t);
		}
		for (int i =0; i < threads.size(); i ++) {
			try {
				threads.get(i).join();
			} catch (InterruptedException e) {
				Logger.logger.error(e);
			}
		}
		Logger.logger.info("[RESULT]-----------------------------------------------");
		for (WorkResult workResult : workResultList) {
			Logger.logger.info("thread[" + workResult.threadIdx + "] " + workResult.fileName + " (" + workResult.totalCnt + "," + workResult.successCnt + ")");
		}
	}
	
	private boolean checkEndFile() throws Exception {
		// check end-file
		long startTime = System.currentTimeMillis();
		LocalDate currentDate = LocalDate.now().plusDays(dayOffset);
		ymd = currentDate.getYear() +
				String.format("%02d", currentDate.getMonthValue()) +
				String.format("%02d", currentDate.getDayOfMonth());
		if (noDay == false && day != null && day.isEmpty() == false) {
			ymd = day;
		}
		endFileName = endFileName + ymd;
		Logger.logger.info("endFileName=" + endFileName);

		Pattern pattern = Pattern.compile(endFileName);
		
		while (true) {
			File folder = new File(sourceDirName);
			File[] files = folder.listFiles();
			if (files == null) {
				Logger.logger.error("failed to get files in " + sourceDirName);
				return false;
			}
			
			// endFileName(BOS2IFNMS_FINAL_) 과 매치되는 파일이 있는지 확인
			List<String> fileList = new ArrayList<String>();
			int fileNo = 0;
			for (File file : files) {
				if (file.isFile()) {
					String fName = file.getName();
					Matcher matcher =  pattern.matcher(fName);
					if (matcher.find()) {
						return true;
					}
				}
			}
			long curTime = System.currentTimeMillis();
			if ((curTime - startTime) > (waitTime * WAIT_ONE_MINUTE)) break;
			Thread.sleep(WAIT_ONE_MINUTE);
			Logger.logger.info("awaked...");
		}
		return false;
	}
	
	private boolean checkBosFile() throws Exception {
		
		long startTime = System.currentTimeMillis();
		Logger.logger.info(">>checkBosFile");
		while(true) {
			
			List<String> fileList = getSourceFiles();
			if (fileList == null || fileList.size() == 0) {
				Logger.logger.error("no file...");
				if(threadSleep(startTime, 10)) {
					continue;
				} else {
					break;
				}
			} else if (fileList.size() > 29) {
				// 2020-08-26 기준 입수되는 BOS 파일 개수 : 31개 (파일개수가 30개 이상이 때 수행)			
				// 입수된 파일을 날짜순으로 정렬
				fileList.sort(new Comparator<String>() {
					@Override
					public int compare(String f1, String f2) {
						try {
							int index1 = Integer.valueOf(f1.split("_")[1]);
							int index2 = Integer.valueOf(f2.split("_")[1]);
							return index1 - index2;
						} catch (Exception e) {
							return 0;
						}
					}
				});
				
				String filename;
				boolean compareFlag = true;
				for (int i = 0; i < fileList.size(); i++) {
					filename = sourceDirName + "/BOS2IFNMS_" + (i + 1) + "_" + ymd + ".txt";
					Logger.logger.info("file compare > fileList.get(i) : " + fileList.get(i) + ", filename : " + filename);
					// 중간에 빠진 파일이 있는지 확인한다.
					if (fileList.get(i).equalsIgnoreCase(filename) == false) {
						Logger.logger.error("need to check :: file=" + fileList.get(i));
						compareFlag = false;
						break;
					}
				}
				
				if(!compareFlag) {
					if(threadSleep(startTime, 10)) {
						continue;
					} else {
						break;
					}
				}
				
				compareFlag = true;
				// 마지막 파일을 제외하고 이전 파일 라인수가 500,000 미만인 경우 비정상 파일
				for (int i = 0; i < fileList.size(); i++) {
					
					String commandStr = "wc -l " + fileList.get(i);
					Process process = Runtime.getRuntime().exec(commandStr);
					BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()));
					String wcStr = br.readLine();
					String[] cntStr = wcStr.split(" ");
					int count = Integer.parseInt(cntStr[0]);
					Logger.logger.info(commandStr + " -----> " + count + " line");
					
					if(i < fileList.size() - 1 && count < 500000) {
						Logger.logger.error("line count < 500,000");
						compareFlag = false;
						break;
					}
				}
				
				if(!compareFlag) {
					if(threadSleep(startTime, 10)) {
						continue;
					} else {
						break;
					}
				}
				
				return true;
				
			} else {
				Logger.logger.error("file count < 29 :: " + fileList.size());
				if(threadSleep(startTime, 10)) {
					continue;
				} else {
					break;
				}
			}
		
		}
		
		return false;
	}
	
	private boolean threadSleep(long startTime, int min) throws Exception {
		
		long curTime = System.currentTimeMillis();
		
		if((curTime-startTime) > (720 * WAIT_ONE_MINUTE)) return false;
		
		Thread.sleep(WAIT_ONE_MINUTE * min);
		Logger.logger.info("checkBosFile awaked...");
		
		return true;
	}

	private List<String> getSourceFiles() {
		LocalDate currentDate = LocalDate.now().plusDays(dayOffset);
		ymd = currentDate.getYear() +
				String.format("%02d", currentDate.getMonthValue()) +
				String.format("%02d", currentDate.getDayOfMonth());

		if (noDay == false && day != null && day.isEmpty() == false) {
			ymd = day;
		}
		String[] tokens = fileNames.split(",");
		Pattern[] patterns = new Pattern[tokens.length];
		for (int i = 0; i < tokens.length; i ++) {
			if (noDay) {
				patterns[i] = Pattern.compile(tokens[i]);
			} else {
				patterns[i] = Pattern.compile(tokens[i]+ymd);
			}
			Logger.logger.info("pattern:" + patterns[i].toString());
		}
		
		
		File folder = new File(sourceDirName);
		File[] files = folder.listFiles();
		if (files == null) {
			Logger.logger.error("failed to get files in " + sourceDirName);
			return null;
		}
		
		List<String> fileList = new ArrayList<String>();
		int fileNo = 0;
		for (File file : files) {
			if (file.isFile()) {
				String fName = file.getName();
				Logger.logger.debug("file : " + fName);
				for (int i = 0; i < patterns.length; i ++) {
					Matcher matcher = patterns[i].matcher(fName);
					if (matcher.find()) {
						Logger.logger.debug("matched : " + fName);
						fileList.add(sourceDirName + "/" + fName);
						fileNo ++;
						Logger.logger.info("added (" + fileNo + ") " + fName);
						break;
					}
				}
			}
		}
		return fileList;
	}
	
	private void split(String fileName) throws Exception {
		Logger.logger.info(fileName);

		FileInputStream		fr = null;
		BufferedReader		br = null;
		try {
			fr =  new FileInputStream(fileName);
			InputStreamReader ir = new InputStreamReader(fr, "eucKR");
			br = new BufferedReader(ir);
			
			String strLine;
			while ((strLine = br.readLine()) != null) {
				totalCnt ++;
				String[] tokens = strLine.split("\\|");
				if (tokens.length < TOKEN_NO) {
					writeSplitFile(strLine, "XNOINFOCNTR");
					continue;
				}
				// L3 EquipMgmtNum = tokens[27]
				// infoCntrCd = tokens[31]
				OIV10100 o100 = (OIV10100) o100Map.get(tokens[27]);
				if (o100 == null) {
					writeSplitFile(strLine, "XNOINFOCNTR");
					continue;					
				} else {
					/*
					if (StringUtils.equals(o100.getMgmtTpoCd(), tokens[31]) == false) {
						Logger.logger.info("infoCntrCd dismatched (" + tokens[27] + ":" + tokens[31] + ") - " + o100.getMgmtTpoCd());
					}*/
					if (StringUtils.isEmpty(o100.getMgmtTpoCd())) {
						writeSplitFile(strLine, "XNOINFOCNTR");
						continue;
					}
				}
				//String key = o100.getMgmtTpoCd() + "_" + o100.getEquipMgmtNum().substring(0,1);
				writeSplitFile(strLine, o100.getMgmtTpoCd());
				successCnt ++;
			}
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (br != null) br.close();
				if (fr != null) fr.close();
			} catch (IOException ex) {
				Logger.logger.error(ex.toString());
			}
		}
	}
	
	private void writeSplitFile(String strLine, String infoCntrCd) throws Exception {
		SplitInfo splitInfo = splitMap.get(infoCntrCd);
		if (splitInfo == null) {
			splitInfo = new SplitInfo();
			splitInfo.fw = new FileOutputStream(splitDirName + "/" + infoCntrCd + "_" + ymd + ".dat");
			splitMap.put(infoCntrCd, splitInfo);			
		}
		splitInfo.fw.write(strLine.getBytes(Charset.forName("eucKR")));
		splitInfo.fw.write('\n');
		splitInfo.recCnt ++;
	}
	
	private Queue<String> getSplitedFiles() {
		File folder = new File(splitDirName);
		File[] files = folder.listFiles();
		if (files == null) {
			Logger.logger.error("failed to get files in " + sourceDirName);
			return null;
		}
		
		Queue<String> clq = new ConcurrentLinkedQueue<String>();
		
		Pattern pattern = Pattern.compile(".*" + ymd + "\\.dat$");
		int fileNo = 0;
		for (File file : files) {
			if (file.isFile()) {
				String fName = file.getName();
				Matcher matcher = pattern.matcher(fName);
				if (matcher.find()) {
					Logger.logger.debug("file : " + fName);
					clq.add(splitDirName + "/" + fName);
					fileNo ++;
					Logger.logger.info("added (" + fileNo + ") " + fName);
				}
			}
		}
		return clq;
	}


	@Override
	public void onExecuted(Object arg0, Exception arg1) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onFinish(Exception arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public void onSelected(int rowNo, Object data) throws Exception {
		// TODO Auto-generated method stub
		OIV10100 o100 = (OIV10100) data;
		if (StringUtils.isEmpty(o100.getEquipMgmtNum())) return;
		o100Map.put(o100.getEquipMgmtNum(), o100);		
	}

	@Override
	public void onStart(String[] arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	class Runner implements Runnable {
		
		int						threadIdx	= 0;
		SwingNEIFServiceManager	svcMgr		= null;
		OIV1040xService			oiv1040xService	= null;
		
		public Runner(int threadIdx, SwingNEIFServiceManager svcMgr) {
			this.threadIdx = threadIdx;
			this.svcMgr = svcMgr;
		}
		
		@Override
		public void run() {
			Logger.logger.info("thread[" + threadIdx + "] running.");
			SwingNEIFService	swingNEIFService = new SwingNEIFService();
			try {
				swingNEIFService.setup(svcMgr.getO100Map(), svcMgr.getOutputDirName());
				while (true) {
					String fName = svcMgr.getFileQueue().poll();
					if (fName == null) return;
					swingNEIFService.load(fName);
					Logger.logger.info("thread[" + threadIdx + "] " + fName + " (" + swingNEIFService.getTotalCnt() + "," + swingNEIFService.getSuccessCnt() + ")");
					svcMgr.addWorkResult(threadIdx, fName, swingNEIFService.getTotalCnt(), swingNEIFService.getSuccessCnt());
				}
			} catch (Exception e) {
				Logger.logger.error(e);
				return;
			} finally {
				swingNEIFService.close();
				Logger.logger.info("thread[" + threadIdx + "] finished.");
			}
		}
	}
}
