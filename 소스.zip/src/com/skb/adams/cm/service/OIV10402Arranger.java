package com.skb.adams.cm.service;

import java.util.ArrayList;
import java.util.List;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.dao.OIV1040xQid;
import com.skb.adams.cm.model.WeqpRelVO;
import com.skb.adams.cm.util.StringUtils;

public class OIV10402Arranger {
	public final static String	AP		= "10";
	public final static String	STB		= "20";
	public final static String	CM		= "30";
	public final static String	ONT		= "40";
	public final static String	VDSL	= "50";
	public final static String	ETC		= "00";

	protected	DbTrans		tran			= null;
	protected	OIV1040xQid	QID				= null;
	
	public OIV10402Arranger() {
	}
	
	public void set(DbTrans tran, OIV1040xQid QID) {
		this.tran = tran;
		this.QID = QID;
	}

	public void doIt()throws Exception {
		List<WeqpRelVO> weqpRelVOList = tran.selectQid2Res(QID.SELECT_LINK_ID_CUST_NUM, null);
		Logger.logger.debug("size=" + weqpRelVOList.size());
		for (int i = 0; i < weqpRelVOList.size(); i ++) {
			WeqpRelVO weqpRelVO = weqpRelVOList.get(i);
			//logger.debug(weqpRelVO.debugMessage());
			doIt(weqpRelVO);
			if (i % 100 == 0) {
				Logger.logger.info(i + " processing...");
				tran.commit();
			}
		}
		tran.commit();
		Logger.logger.info("completed...");
	}
	
	private void doIt(WeqpRelVO weqpRelVO) throws Exception {
		List<WeqpRelVO> weqpRelVOList = tran.selectQid2Res(QID.SELECT_WEQP_REL2, weqpRelVO);
		if (weqpRelVOList == null || weqpRelVOList.size() == 0) {
			return;
		}
		arrangeWeqp(weqpRelVOList);
		
		for (int i = 0; i < weqpRelVOList.size(); i ++) {
			WeqpRelVO weqp = weqpRelVOList.get(i);
			if (StringUtils.equals(weqp.getSupWeqpMgmtNum(), weqp.getNewSupWeqpMgmtNum()) == false) {
				Logger.logger.debug(weqp.debugMessage());
				tran.update(QID.UPDATE_OIV10402_SUP_WEQP_MGMT_NUM, weqp);
			}
		}
	}

	protected void arrangeWeqp(List<WeqpRelVO> weqpRelVOList) {
		List<WeqpRelVO> teList = new ArrayList<WeqpRelVO>();
		List<WeqpRelVO> apList = new ArrayList<WeqpRelVO>(); 
		List<WeqpRelVO> stbList = new ArrayList<WeqpRelVO>();

		for (int i = 0; i < weqpRelVOList.size(); i ++) {
			WeqpRelVO weqpRelVO = weqpRelVOList.get(i); 
			if (ONT.equals(weqpRelVO.getWeqpMdlTypCd())) {
				teList.add(weqpRelVO);
			} else if (VDSL.equals(weqpRelVO.getWeqpMdlTypCd())) {
				teList.add(weqpRelVO);
			} else if (CM.equals(weqpRelVO.getWeqpMdlTypCd())) {
				teList.add(weqpRelVO);
			} else if (AP.equals(weqpRelVO.getWeqpMdlTypCd())) {
				apList.add(weqpRelVO);
			} else if (STB.equals(weqpRelVO.getWeqpMdlTypCd())) {
				stbList.add(weqpRelVO);
			}			
		}
		if (teList.size() > 1) { 
			Logger.logger.info("linkId=" + teList.get(0).getLinkId() + ",custNum=" + teList.get(0).getCustNum() + ",teList.size=" + teList.size() + " ... proces...");
		}
		for (int i = 0; i < weqpRelVOList.size(); i ++) {
			WeqpRelVO weqpRelVO = weqpRelVOList.get(i);
			if (AP.equals(weqpRelVO.getWeqpMdlTypCd())) {
				WeqpRelVO pWeqp = findWeqp(teList, weqpRelVO);
				if (pWeqp != null) {
					weqpRelVO.setNewSupWeqpMgmtNum(pWeqp.getWeqpMgmtNum());
				}
			} else if (STB.equals(weqpRelVO.getWeqpMdlTypCd()) || ETC.equals(weqpRelVO.getWeqpMdlTypCd())) {
				// AP 에서 동일한 서비스관리번호 찾기
				WeqpRelVO pWeqp = findWeqp(apList, weqpRelVO);
				if (pWeqp != null) {
					weqpRelVO.setNewSupWeqpMgmtNum(pWeqp.getWeqpMgmtNum());
				} else {
					// AP 에서 찾지 못했다면, TE 에서 서비스관리번호 찾기
					pWeqp = findWeqp(teList, weqpRelVO);
					if (pWeqp != null) {
						weqpRelVO.setNewSupWeqpMgmtNum(pWeqp.getWeqpMgmtNum());
					} else {
						// TE 에서도 못 찾았다면, 첫번째 AP 와 연결
						if (apList.size() > 0) {
							weqpRelVO.setNewSupWeqpMgmtNum(apList.get(0).getWeqpMgmtNum());
						} else {
							// AP 가 없다면 TE 로 연결
							if (teList.size() > 0) {
								weqpRelVO.setNewSupWeqpMgmtNum(teList.get(0).getWeqpMgmtNum());
							}
						}
					}
				}
			}
		}
	}

	private WeqpRelVO findWeqp(List<WeqpRelVO> weqpList, WeqpRelVO weqpVO) {
		String inetSvcMgmtNum = weqpVO.getInetSvcMgmtNum();
		for (int i = 0; i < weqpList.size(); i ++) {
			if (inetSvcMgmtNum == null || inetSvcMgmtNum.isEmpty()) break;
			if (inetSvcMgmtNum.equals(weqpList.get(i).getInetSvcMgmtNum())) {
				return weqpList.get(i);
			}
		}
		String iptvSvcMgmtNum = weqpVO.getIptvSvcMgmtNum();
		for (int i = 0; i < weqpList.size(); i ++) {
			if (iptvSvcMgmtNum == null || iptvSvcMgmtNum.isEmpty()) break;
			if (iptvSvcMgmtNum.equals(weqpList.get(i).getIptvSvcMgmtNum())) {
				return weqpList.get(i);
			}
		}
		String phonSvcMgmtNum = weqpVO.getPhonSvcMgmtNum();
		for (int i = 0; i < weqpList.size(); i ++) {
			if (phonSvcMgmtNum == null || phonSvcMgmtNum.isEmpty()) break;
			if (phonSvcMgmtNum.equals(weqpList.get(i).getPhonSvcMgmtNum())) {
				return weqpList.get(i);
			}
		}
		String repSvcMgmtNum = weqpVO.getRepSvcMgmtNum();
		for (int i = 0; i < weqpList.size(); i ++) {
			if (repSvcMgmtNum == null || repSvcMgmtNum.isEmpty()) break;
			if (repSvcMgmtNum.equals(weqpList.get(i).getRepSvcMgmtNum())) {
				return weqpList.get(i);
			}
		}
		return null;
	}
}
