package com.skb.adams.cm.service;

import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQException;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.constants.MQConstants;

public class MQConnection {
	private String hostName = null;
	private String channel = null;
	private String qManager = null;
	private String requestQueue = null;
	private int port = 0;
	private int ccsid = 0;

	private MQQueueManager qMgr = null;
	private MQQueue queue = null;

	public MQQueue getConnection() throws MQException {
		// Set up the MQEnvironment properties for Client Connections
		MQEnvironment.hostname = this.hostName;
		MQEnvironment.channel = this.channel;
		MQEnvironment.port = this.port;

		MQEnvironment.properties.put(MQConstants.TRANSPORT_PROPERTY, MQConstants.TRANSPORT_MQSERIES_CLIENT);
		MQEnvironment.properties.put(MQConstants.CCSID_PROPERTY, new Integer(ccsid));

		// Connection To the Queue Manager
		qMgr = new MQQueueManager(this.qManager);
		System.out.println("Connection -> Success");

		int openOptions = MQConstants.MQOO_INPUT_AS_Q_DEF;

		// Open the queue
		this.queue = qMgr.accessQueue(this.requestQueue, openOptions);
		System.out.println("Open Queue -> Success");

		return this.queue;
	}

	public MQQueue putConnection() throws MQException {
		// Set up the MQEnvironment properties for Client Connections
		MQEnvironment.hostname = this.hostName;
		MQEnvironment.channel = this.channel;
		MQEnvironment.port = this.port;

		MQEnvironment.properties.put(MQConstants.TRANSPORT_PROPERTY, MQConstants.TRANSPORT_MQSERIES_CLIENT);
		MQEnvironment.properties.put(MQConstants.CCSID_PROPERTY, new Integer(ccsid));

		// Connection To the Queue Manager
		qMgr = new MQQueueManager(this.qManager);
		System.out.println("Connection -> Success");

		int openOptions = MQConstants.MQOO_OUTPUT;

		// Open the queue
		this.queue = qMgr.accessQueue(this.requestQueue, openOptions);
		System.out.println("Open Queue -> Success");

		return this.queue;
	}

	public MQQueue reGetConnection(MQException e, long timeSleep) throws MQException {

		if (e.reasonCode == 2009 || e.reasonCode == 2017 || e.reasonCode == 2018 || e.reasonCode == 2019 || e.reasonCode == 2059
				|| e.reasonCode == 2162) {
			close();

			try {
				Thread.sleep(timeSleep);
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}

			try {
				System.out.println("Trying to reconnect");
				this.queue = getConnection();
			} catch (MQException ex) {
				System.out
						.println("An MQ Error Occurred: Completion Code is :\t" + ex.completionCode + "\n\n The Reason Code is :\t" + ex.reasonCode);
				ex.printStackTrace();
				for (Throwable t = ex.getCause(); t != null; t = t.getCause()) {
					System.out.println("... Caused by ");
					t.printStackTrace();
				}
			}
		} else {
			throw e;
		}

		return queue;
	}

	public MQQueue rePutConnection(MQException e, long timeSleep) throws MQException {

		if (e.reasonCode == 2009 || e.reasonCode == 2017 || e.reasonCode == 2018 || e.reasonCode == 2019 || e.reasonCode == 2059
				|| e.reasonCode == 2162) {
			close();

			try {
				Thread.sleep(timeSleep);
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}

			try {
				System.out.println("Trying to reconnect");
				this.queue = putConnection();
			} catch (MQException ex) {
				System.out
						.println("An MQ Error Occurred: Completion Code is :\t" + ex.completionCode + "\n\n The Reason Code is :\t" + ex.reasonCode);
				ex.printStackTrace();
				for (Throwable t = ex.getCause(); t != null; t = t.getCause()) {
					System.out.println("... Caused by ");
					t.printStackTrace();
				}
			}
		} else {
			throw e;
		}

		return queue;
	}

	public void close() {
		try {
			if (this.queue != null) {
				// Close the queue
				System.out.println("Closing the queue");
				this.queue.close();
			}
		} catch (MQException ex) {
			System.out.println("An MQ Error Occurred: Completion Code is :\t" + ex.completionCode + "\n\n The Reason Code is :\t" + ex.reasonCode);
			ex.printStackTrace();
			for (Throwable t = ex.getCause(); t != null; t = t.getCause()) {
				System.out.println("... Caused by ");
				t.printStackTrace();
			}
		}

		try {
			if (this.qMgr != null) {
				// Disconnect from the QueueManager
				System.out.println("Disconnecting from the Queue Manager");
				this.qMgr.disconnect();
				System.out.println("Done!");
			}
		} catch (MQException ex) {
			System.out.println("An MQ Error Occurred: Completion Code is :\t" + ex.completionCode + "\n\n The Reason Code is :\t" + ex.reasonCode);
			ex.printStackTrace();
			for (Throwable t = ex.getCause(); t != null; t = t.getCause()) {
				System.out.println("... Caused by ");
				t.printStackTrace();
			}
		}
	}

	public void commit() {
		try {
			if (this.qMgr != null) {
				this.qMgr.commit();
				System.out.println("Commit");
			}
		} catch (MQException ex) {
			System.out.println("An MQ Error Occurred: Completion Code is :\t" + ex.completionCode + "\n\n The Reason Code is :\t" + ex.reasonCode);
			ex.printStackTrace();
			for (Throwable t = ex.getCause(); t != null; t = t.getCause()) {
				System.out.println("... Caused by ");
				t.printStackTrace();
			}
		}
	}
	
	public void rollback() {
		try {
			if (this.qMgr != null) {
				this.qMgr.backout();
				System.out.println("Backout");
			}
		} catch (MQException ex) {
			System.out.println("An MQ Error Occurred: Completion Code is :\t" + ex.completionCode + "\n\n The Reason Code is :\t" + ex.reasonCode);
			ex.printStackTrace();
			for (Throwable t = ex.getCause(); t != null; t = t.getCause()) {
				System.out.println("... Caused by ");
				t.printStackTrace();
			}
		}
	}
	
	public int getCcsid() {
		return ccsid;
	}

	public void setCcsid(int ccsid) {
		this.ccsid = ccsid;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getqManager() {
		return qManager;
	}

	public void setqManager(String qManager) {
		this.qManager = qManager;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public String getRequestQueue() {
		return requestQueue;
	}

	public void setRequestQueue(String requestQueue) {
		this.requestQueue = requestQueue;
	}

}