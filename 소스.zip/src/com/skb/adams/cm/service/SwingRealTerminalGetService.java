package com.skb.adams.cm.service;

import java.sql.SQLException;
import java.util.Date;

import com.skb.adams.cm.dao.OIV1040xQid;
import com.skb.adams.cm.model.OIV10805;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.dao.exception.DBObjectDupException;
import subkjh.bas.log.LOG_LEVEL;
import subkjh.bas.log.Logger;

/*
 * IF-SWING-0028 임대 단말 FOMS 송신
 */
public class SwingRealTerminalGetService implements MQInterface {
	
	private final String	QUEUE_NAME		= "SWN.INMS.ADAMS.REQ";
	private	final	String	AUDIT_ID		= "CM-SWG-0028";
	
	DbTrans			tran			= null;
	OIV1040xQid		QID				= null;
	MQService		mqService		= null;
	OIV1040xService	oiv1040xService	= null;

	int totalCnt	= 0;
	int	successCnt	= 0;

	public static void main(String[] args) {
		MQService.PROC_MODE procMode = MQService.PROC_MODE.DEV_MODE;
		String	logDirName = null;
		String	logId = null;
		String	debugMode = "INFO";

		for (int i = 0; i < args.length; i ++) {
			String[] tokens = args[i].split("=");
			if ("PROCMODE".equals(tokens[0].toUpperCase())) {
				if("OPER".equals(tokens[1].toUpperCase())) {
					procMode = MQService.PROC_MODE.OPER_MODE;
				}
			} else if ("LOGDIR".equals(tokens[0].toUpperCase())) {
				logDirName = tokens[1];
			} else if ("LOGID".equals(tokens[0].toUpperCase())) {
				logId = tokens[1];
			} else if ("DEBUGMODE".equals(tokens[0].toUpperCase())) {
				if ("DEBUG".equals(tokens[1].toUpperCase())) {
					debugMode = "DEBUG";
				}
			}
		}

		SwingRealTerminalGetService swingRealTerminalGetService = new SwingRealTerminalGetService();
		
		if (logDirName != null && logId != null) {
			swingRealTerminalGetService.setLogPolicy(debugMode, logDirName, logId);
		}

		try {
			swingRealTerminalGetService.start(procMode);
		} catch (Exception e) {
			Logger.logger.error(e);
		}
	}

	public SwingRealTerminalGetService() {
	}
	
	public void setLogPolicy(String debugMode, String logDir, String logId) {
		Logger.logger = Logger.logger.createLogger(logDir, logId);
		if ("DEBUG".equals(debugMode)) {
			Logger.logger.setLevel(LOG_LEVEL.debug);
		} else {
			Logger.logger.setLevel(LOG_LEVEL.info);
		}
	}

	public void start(MQService.PROC_MODE procMode) throws Exception {
		DataBase database = DBManager.getMgr().getDataBase("ADAMS");

		tran = database.createDbTrans("deploy/conf/sql/oiv1040x.xml");
		QID = new OIV1040xQid();

		oiv1040xService = new OIV1040xService();
		oiv1040xService.set(tran, QID);

		try {
			mqService = new MQService(this, procMode);
			mqService.connect();
			mqService.get();
			Logger.logger.info("totalCnt=" + totalCnt + ", successCnt=" + successCnt);
			/* for test
			String data = "LSEIF91301201711131515279271|DSNW560B557E|1|다산네트웍스|ONT (다산 H655N)|8012074304|6424361009|1689271007|이*정|B0032||||0||0|7282374921|7282374921|광랜FTTH||Btv(단독IPTV)|Y|||AC|1|창원OLT#2_다산|NR012106|OLT_V5724G(GE-PON_다산)|(주)다산네트웍스|121.124.253.8|N03029|경남/창원||01|01|131|00001|창원OLT#2_다산|NR012106|OLT_V5724G(GE-PON_다산)|(주)다산네트웍스|121.124.253.8|N03029|경남/창원||01|01|10|00001|01-01-10-00002-00001|||4812312500|100000001170507|100000000321330|100000014298916||51515|경남 창원시 성산구 중앙대로 95,|1동 304호 (중앙동,파라다이스빌딩)|1003002201|경남중부Home센터|AB00480000|품질관리팀|부산고객담당||일반건물|1689271007201503006330|||0;";
			process(data);
			*/
		} catch (Exception e) {
			Logger.logger.info("totalCnt=" + totalCnt + ", successCnt=" + successCnt);
			tran.rollback();
			throw e;
		}
	}
	
	@Override
	public String getQueueName() {
		return QUEUE_NAME;
	}
	
	public boolean process(String data) throws Exception {
		Logger.logger.debug(data);
		try {
			OIV10805 oiv10805 = make(data);

			tran.create(QID.INSERT_OIV10805, oiv10805);
			/*
			if (oiv1040xService.process(oiv10805)) {
				successCnt ++;
			} else {
				Logger.logger.info("failed. [" + totalCnt + "] " + data);
			}
			*/
			totalCnt ++;

			if (totalCnt % 100 == 0){
				Logger.logger.info("### processed " + totalCnt + " lines ####################");
			}
		} catch (DBObjectDupException de) {
			Logger.logger.error(de);
			de.printStackTrace();
			Logger.logger.info(data);
			String[] tokens = data.split("\\|");
			for (int i = 0; i < tokens.length; i ++) {
				Logger.logger.info(i + ":" + tokens[i]);
			}
		} catch (CmException ce) {
			Logger.logger.error(ce.getErrorMessage());
			Logger.logger.info(data);
			String[] tokens = data.split("\\|");
			for (int i = 0; i < tokens.length; i ++) {
				Logger.logger.info(i + ":" + tokens[i]);
			}
		} catch (SQLException se) {
			Logger.logger.error(se.getMessage());
			Logger.logger.info(data);
			String[] tokens = data.split("\\|");
			for (int i = 0; i < tokens.length; i ++) {
				Logger.logger.info(i + ":" + tokens[i]);
			}
			Logger.logger.info("Skip");
	    } catch (Exception e) {
			Logger.logger.error("error. [" + totalCnt + "] " + data);
			String[] tokens = data.split("\\|");
			for (int i = 0; i < tokens.length; i ++) {
				Logger.logger.info(i + ":" + tokens[i]);
			}
			throw e;
		}
		return true;
	}

	private OIV10805 make(String data) throws Exception {
		OIV10805 oiv10805 = new OIV10805();
		String[] tokens = data.split("\\|");
		for (int i = 0; i < tokens.length; i ++) {
			Logger.logger.debug(i + ":" + tokens[i]);
		}
		oiv10805.setMqChgDtm(tokens[0].substring(10, 24).trim());
		oiv10805.setMqExecTms((int)(new Date().getTime()/1000));
		oiv10805.setWeqpGrpCd(tokens[0].substring(24));
		oiv10805.setMacAddr(tokens[1]);
		oiv10805.setInoutClCd(tokens[2]);
		oiv10805.setMfactNm(tokens[3].trim());
		oiv10805.setEquipMdlNm(tokens[4]);
		oiv10805.setCustNum(tokens[5]);
		oiv10805.setAcntNum(tokens[6]);
		oiv10805.setEquipCd(tokens[7]);
		oiv10805.setCustNm(tokens[8]);
		oiv10805.setSvcTechMthdCd(tokens[9]);
		oiv10805.setCustAddr(tokens[10]);
		oiv10805.setCustPhonNum(tokens[11]);
		if (tokens[12].length() > 0) oiv10805.setInetSvcNum(tokens[12]);
		if (tokens[13].length() > 0) oiv10805.setInetSvcMgmtNum(tokens[13]);
		if (tokens[14].length() > 0) oiv10805.setPhonSvcNum(tokens[14]);
		if (tokens[15].length() > 0) oiv10805.setPhonSvcMgmtNum(tokens[15]);
		if (tokens[16].length() > 0) oiv10805.setIptvSvcNum(tokens[16]);
		if (tokens[17].length() > 0) oiv10805.setIptvSvcMgmtNum(tokens[17]);
		oiv10805.setInetSvcNm(tokens[18]);
		oiv10805.setPhonSvcNm(tokens[19]);
		oiv10805.setIptvSvcNm(tokens[20]);
		oiv10805.setRltmTvClCd(tokens[21]);
		oiv10805.setInetOrbkStCd(tokens[22]);
		oiv10805.setWphonOrbkStCd(tokens[23]);
		oiv10805.setIptvOrbkStCd(tokens[24]);
		if (tokens[25].length() > 0) oiv10805.setIptvLineCnt(tokens[25]);
		oiv10805.setL3TidVal(tokens[26]);
		oiv10805.setL3EquipId(tokens[27]);
		oiv10805.setL3EquipNm(tokens[28]);
		oiv10805.setL3EquipMfactNm(tokens[29]);
		oiv10805.setL3IpAddr(tokens[30]);
		oiv10805.setInfoCntrCd(tokens[31]);
		oiv10805.setInfcNm(tokens[32]);
		oiv10805.setL3CellNum(tokens[33]);
		oiv10805.setL3RackNum(tokens[34]);
		oiv10805.setL3ShlfNum(tokens[35]);
		oiv10805.setL3CardNum(tokens[36]);
		oiv10805.setL3PortNum(tokens[37]);
		oiv10805.setL2TidVal(tokens[38]);
		oiv10805.setL2EquipId(tokens[39]);
		oiv10805.setL2EquipNm(tokens[40]);
		oiv10805.setL2EquipMfactNm(tokens[41]);
		oiv10805.setL2IpAddr(tokens[42]);
		oiv10805.setTpoCd(tokens[43]);
		oiv10805.setTpoNm(tokens[44]);
		oiv10805.setL2CellNum(tokens[45]);
		oiv10805.setL2RackNum(tokens[46]);
		oiv10805.setL2ShlfNum(tokens[47]);
		oiv10805.setL2CardNum(tokens[48]);
		oiv10805.setL2PortNum(tokens[49]);
		if (tokens[50].length() <= 12) {
			oiv10805.setOnuEquipId(tokens[50]);
		} else {
			oiv10805.setOnuEquipId(tokens[50].substring(0,12).trim());
		}
		oiv10805.setRnTapNum(tokens[51]);
		oiv10805.setTelpolNum(tokens[52]);
		oiv10805.setLdongCd(tokens[53]);
		oiv10805.setAddrId(tokens[54]);
		if (tokens[55].length() > 0) oiv10805.setBldblkNum(tokens[55]);
		if (tokens[56].length() > 0) oiv10805.setBlduntNum(tokens[56]);
		oiv10805.setAssistAddr(tokens[57]);
		oiv10805.setZip(tokens[58]);
		oiv10805.setBasAddr(tokens[59]);
		oiv10805.setDtlAddr(tokens[60]);
		oiv10805.setDsnetId(tokens[61]);
		oiv10805.setDsnetNm(tokens[62]);
		oiv10805.setFstScrbOrgId(tokens[63]);
		oiv10805.setFstScrbOrgNm(tokens[64]);
		oiv10805.setTeamOrgNm(tokens[65]);
		oiv10805.setSvcLinkNum(tokens[66]);
		oiv10805.setSetBldAttrInfo(tokens[67]);
		oiv10805.setWeqpMgmtNum(tokens[68]);
		oiv10805.setAssistMacAddrSerNum(tokens[69]);
		oiv10805.setAuditId(AUDIT_ID);
		
		return oiv10805;
	}

	@Override
	public void commit() {
		// TODO Auto-generated method stub
		tran.commit();
	}
}
