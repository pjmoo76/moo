package com.skb.adams.cm.service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.skb.adams.cm.dao.OIV1040xQid;
import com.skb.adams.cm.model.OIV10100;
import com.skb.adams.cm.util.StringUtils;

import subkjh.bas.dao.control.DaoListener;
import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.Logger;

public class SwingNEIFServiceTester implements DaoListener {
	
	Map<String, OIV10100>	o100Map			= null;

	public SwingNEIFServiceTester() {
	}
	
	public void loadEquipMap() throws Exception {
		DataBase database = DBManager.getMgr().getDataBase("ADAMS");
		DbTrans tran = database.createDbTrans("deploy/conf/sql/oiv1040x.xml");
		tran.start();
		tran.setDaoListener(this);
		o100Map = new ConcurrentHashMap<String,OIV10100>();
		OIV1040xQid QID = new OIV1040xQid();
		tran.selectQid2Res(QID.SELECT_OIV10100, null);
		Logger.logger.info("O10100 MAP Size = " + o100Map.size());
		tran.setDaoListener(null);
		tran.stop();		
	}
	
	public void process(String fileName) throws Exception {
		SwingNEIFService	swingNEIFService = new SwingNEIFService();
		swingNEIFService.setup(o100Map, null);

		FileInputStream fr = new FileInputStream(fileName);
		InputStreamReader ir = new InputStreamReader(fr, "eucKR");
		BufferedReader br = new BufferedReader(ir);

		int lineNo = 0;
		int successNo = 0;
		HashMap<Integer,Integer> errorRet = new HashMap<Integer, Integer>();

		String strLine;
		while ((strLine = br.readLine()) != null) {
			//Logger.logger.debug(strLine);
			String data = strLine.substring(strLine.indexOf(':')+1);
			//Logger.logger.debug(data);
			try {
				lineNo ++;
				swingNEIFService.process(data);
				successNo ++;
			} catch (CmException ce) {
				Integer errorCode = ce.getErrorCode();
				Integer errorCount = errorRet.get(errorCode);
				if (errorCount == null) {
					errorRet.put(errorCode, new Integer(1));
				} else {
					errorRet.put(errorCode, new Integer(errorCount.intValue() + 1));
				}
				Logger.logger.error(ce.getErrorMessage());
				Logger.logger.debug(data);
			} catch (Exception e) {
				Logger.logger.error(e);
				Logger.logger.debug(data);
			}
		}
		br.close();
		ir.close();
		fr.close();
		Logger.logger.info(String.format("lineNo=%d, successNo=%d", lineNo, successNo));
		Iterator itr = errorRet.entrySet().iterator();
		while (itr.hasNext()) {
			Map.Entry pair = (Map.Entry)itr.next();
			Integer errorCode = (Integer) pair.getKey();
			Integer errorCount = (Integer) pair.getValue();
			Logger.logger.info(String.format("(%s),(%d)", CmException.getErrorCodeString(errorCode.intValue()), errorCount.intValue()));
		}
	}

	@Override
	public void onExecuted(Object arg0, Exception arg1) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onFinish(Exception arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onSelected(int arg0, Object arg1) throws Exception {
		// TODO Auto-generated method stub
		OIV10100 o100 = (OIV10100) arg1;
		if (StringUtils.isEmpty(o100.getEquipMgmtNum())) return;
		o100Map.put(o100.getEquipMgmtNum(), o100);				
	}

	@Override
	public void onStart(String[] arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			SwingNEIFServiceTester tester = new SwingNEIFServiceTester();
			tester.loadEquipMap();
			tester.process(args[0]);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
