package com.skb.adams.cm.service;

public class CmException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7670004804309459363L;

	
	public final static int	NO_L3_TID	= 1;
	public final static int	NO_L2_TID	= 2;
	public final static int	NO_MAC		= 3;
	public final static int	NOT_FOUND_EQUIP_ID		= 11;
	public final static int	NOT_FOUND_WEQP_MGMT_NUM	= 12;
	public final static int	NOT_FOUND_CCELL_ID		= 13;
	public final static int	FAIL_TO_OUT				= 14;
	public final static int	LINK_ID_NULL			= 21;
	
	int		errorCode	= 0;
	String	errorData	= null;;

	public CmException(int errorCode) {
		this.errorCode = errorCode;
	}
	public CmException(int errorCode, String errorData) {
		this.errorCode = errorCode;
		this.errorData = errorData;
	}
	
	public int getErrorCode() {
		return this.errorCode;
	}
	
	public String getErrorCodeString() {
		return getErrorCodeString(errorCode);
	}
	
	static public String getErrorCodeString(int errorCode) {
		if (errorCode == NO_L3_TID) return "NO_L3_TID";
		if (errorCode == NO_L2_TID) return "NO_L2_TID";
		if (errorCode == NO_MAC) return "NO_MAC";
		if (errorCode == NOT_FOUND_EQUIP_ID) return "NOT_FOUND_EQUIP_ID";
		if (errorCode == NOT_FOUND_WEQP_MGMT_NUM) return "NOT_FOUND_WEQP_MGMT_NUM";
		if (errorCode == NOT_FOUND_CCELL_ID) return "NOT_FOUND_CCELL_ID";
		if (errorCode == FAIL_TO_OUT) return "FAIL_TO_OUT";
		if (errorCode == LINK_ID_NULL) return "LINK_ID_NULL";
		return null;
	}
	
	public String getErrorData() {
		return errorData;
	}
	
	public String getErrorMessage() {
		return getErrorCodeString() + "(" + getErrorData() + ")";
	}
}
