package com.skb.adams.cm.service;

public interface MQInterface {
	String	getQueueName();
	boolean	process(String data) throws Exception;
	void	commit();
}
