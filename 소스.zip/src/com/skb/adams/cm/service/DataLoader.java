package com.skb.adams.cm.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.CmMsg;

public class DataLoader {
	private	String		prefix;
	private	String		tableName;
	private	String[]	columnNames;
	private String[]	defColumnValues = null;
	private	int			valueLen = 0;
	private	String		fileName;
	private int			index = 0;
	private List<Object[]>	valueList;
	protected DbTrans		dstTran;
	private StringBuffer	insertSql;

	public DataLoader() {		
	}

	public String getPrefix() {
		return prefix;
	}

	public DataLoader setPrefix(String prefix) {
		this.prefix = prefix;
		return this;
	}

	public String getTableName() {
		return tableName;
	}

	public DataLoader setTableName(String tableName) {
		this.tableName = tableName;
		return this;
	}

	public String[] getColumnNames() {
		return columnNames;
	}

	public DataLoader setColumnNames(String[] columnNames) {
		this.columnNames = columnNames;
		return this;
	}

	public String[] getDefColumnValues() {
		return defColumnValues;
	}

	public DataLoader setDefColumnValues(String[] defColumnValues) {
		this.defColumnValues = defColumnValues;
		return this;
	}

	public DataLoader setDstTran(DbTrans dstTran) {
		this.dstTran = dstTran;
		return this;
	}
	
	public void open(String fileName) throws Exception {
		this.fileName = fileName;
		
		FileInputStream fr = null;
		BufferedReader br = null;
		Exception ex = null;
		try {
			fr =  new FileInputStream(fileName);
			br = new BufferedReader(new InputStreamReader(fr, "eucKR"));
			
			onStart();
			
			String strLine;
			while ((strLine = br.readLine()) != null) {
				onRead(strLine);
			}
		} catch (Exception e) {
			ex = e;
		} finally {
			try {
				br.close();
				fr.close();
			} catch (Exception e) {
			}
			onFinished(ex);
		}		
	}
	
	public void onStart() throws Exception {
		StringBuffer name = new StringBuffer();
		StringBuffer value = new StringBuffer();

		valueLen = 0;
		for (int i = 0; i < columnNames.length; i ++) {
			if (name.length() > 0) {
				name.append(", ");
				value.append(", ");
			}
			name.append(columnNames[i]);
			if (defColumnValues == null) {
				value.append("?");
				valueLen ++;
			} else {
				if (i < defColumnValues.length) {
					value.append(defColumnValues[i].trim());
					if (defColumnValues[i].contains("?")) {
						valueLen ++;
					}
				} else {
					value.append("?");
					valueLen ++;
				}
			}

		}
		insertSql = new StringBuffer();
		insertSql.append("insert into ");
		insertSql.append(tableName);
		insertSql.append(" ( ");
		insertSql.append(name);
		insertSql.append(" ) values ( ");
		insertSql.append(value);
		insertSql.append(" )");
		
		Logger.logger.info("insertSql=" + insertSql);

		valueList = new ArrayList<Object[]>();
		
	}

	private boolean onRead(String line) throws Exception {
		List<String> list = parse(line);
		if (list.size() == valueLen) {
			index++;
			onData(index, list);
			return true;
		} else {
			System.out.println(list.size() + ", " + line);
		}
		return false;
	}

	public boolean onRead(List<String> list) throws Exception {
		if (list.size() == valueLen) {
			index++;
			onData(index, list);
			return true;
		} else {
			System.out.println(list.size() + ", " + list);
		}
		return false;
	}

	protected List<String> parse(String line) {

		StringBuffer sb = new StringBuffer();
		List<String> list = new ArrayList<String>();
		char chs[] = line.toCharArray();
		for (int i = 0; i < chs.length; i++) {
			if (i > 0 && chs[i] == '|' && chs[i - 1] == '\\') {
				sb.append(chs[i]);
			} else if (chs[i] == '|') {
				list.add(sb.toString());
				sb = new StringBuffer();
			} else {
				sb.append(chs[i]);
			}
		}

		// list.add(sb.toString());

		return list;
	}

	private void insert() throws Exception {
		Logger.logger.info("insert");
		if (valueList.size() == 0) {
			return;
		}

		try {
			dstTran.executeSql(insertSql.toString(), valueList);
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		} finally {
			valueList.clear();
		}
	}

	protected void onData(int index, List<String> dataList) throws Exception {

		valueList.add(dataList.toArray(new Object[dataList.size()]));

		if (index % 50000 == 0) {
			insert();
		}

	}

	public void onFinished(Exception ex) {
		try {
			if (ex == null) {
				insert();
				dstTran.commit();
			} else {
				throw ex;
			}
		} catch (Exception e) {
			dstTran.rollback();
			Logger.logger.error(e);
		} finally {
			dstTran.stop();
		}
	}
}
