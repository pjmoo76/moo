package com.skb.adams.cm.service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import subkjh.bas.log.LOG_LEVEL;
import subkjh.bas.log.Logger;

public class SwingSchoolNetSendService {
    private static final String[][] KEY_LIST = {
    	  { "BIZ_NM", "통신사" }
      	, { "BIZ_APP_NO", "회선 관리번호" }
    	, { "ASGN_NO", "배정번호" }
    	, { "AGNC_NM", "이용기관명" }
    	, { "ADDR_STATE", "시도" }
    	, { "ADDR_CITY", "시군구" }
    	, { "BIZ_NO", "사업자등록번호" }
    	, { "SVC", "이용서비스" }
    	, { "SPEED", "속도" }
    	, { "OPEN_YMD", "개통일" }
    	, { "LINE_APP_TYPE", "회선신청구분" }
    	, { "LINE_MOD_TYPE", "회선변경유형" }
       };
    private StringBuilder sbErr = new StringBuilder();


	/*
	 * parameters: 
	 *		DATA_FILE=/app/swing/batch/schoolnet/SWING_SCHOOL_NET_20210722.dat
	 *		DEST_URL=http://222.112.0.232:35086/api/setLineInfo
	 *		LOG_PATH=/data/cm-neif/logs
	 *		LOG_ID=cm-schoolnet-send.${CUR_YMD}.log
	 *		LOG_MODE={DEBUG|INFO}
	 */
	public static void main(String[] args) {
		String	dataFile = null, destUrl = null, logDirName = null, logId = null, logMode = null;
		
		for (int i = 0; i < args.length; i ++) {
			String[] tokens = args[i].split("=");
			if ("DATA_FILE".equalsIgnoreCase(tokens[0])) {
				dataFile = tokens[1];
			} else if ("DEST_URL".equalsIgnoreCase(tokens[0])) {
				destUrl = tokens[1];
			} else if ("LOG_PATH".equalsIgnoreCase(tokens[0])) {
				logDirName = tokens[1];
			} else if ("LOG_ID".equalsIgnoreCase(tokens[0])) {
				logId = tokens[1];
			} else if ("LOG_MODE".equalsIgnoreCase(tokens[0])) {
				logMode = "DEBUG".equalsIgnoreCase(tokens[1]) ? "DEBUG" : "INFO";
			}
		}
		Logger.logger = Logger.createLogger(logDirName, logId);
		Logger.logger.setLevel("DEBUG".equals(logMode) ? LOG_LEVEL.debug : LOG_LEVEL.info);
		
		try {
			SwingSchoolNetSendService service = new SwingSchoolNetSendService();
			service.setFile(dataFile);
			service.setURL(destUrl);
			service.run();
		} catch (Exception e) {
			Logger.logger.error(e);
			System.exit(1);
		}
	}

    private String file = null;
    private String url = null;
    public void setFile(String file) {
    	this.file = file;
    }
    public void setURL(String url) {
    	this.url = url;
    }
	
	public void run() throws Exception {
        CloseableHttpClient httpClient = null;
        HttpPost req = null;
        HttpResponse res = null;

        StringEntity reqEntity = null;
        HttpEntity resEntity = null;
        int resCode = -1;
        String sendJson, resEntityString = null;
        JSONParser parser = null;
        JSONObject jobj = null;
        
        sbErr.setLength(0);

        try {
            httpClient = HttpClientBuilder.create().build();
            req = new HttpPost(this.url);
            Logger.logger.info("target url : " + this.url);

            req.addHeader("Content-Type", "application/json; utf-8");
            req.addHeader("Authorization", "Basic c2Nob29sX3NrYjoyMDIxU2tiXl4j");

            sendJson = makeData();
            Logger.logger.debug("sendJson : " + sendJson);
            reqEntity = new StringEntity(sendJson, "utf-8");
            reqEntity.setContentType("application/json; utf-8");

            req.setEntity(reqEntity);

            res = httpClient.execute(req);
            resCode = res.getStatusLine().getStatusCode();
            resEntity = res.getEntity();
            resEntityString = EntityUtils.toString(resEntity);

            Logger.logger.info("resCode : " + resCode);
            Logger.logger.info("res : [" + resEntityString + "]");
            
            if(resCode != HttpStatus.SC_OK)
            	sbErr.append("\nHttpStatus 오류 - resCode 확인 필요");

            parser = new JSONParser();
            jobj = (JSONObject)parser.parse(resEntityString);
    		if(!"__ok__".equals(jobj.get("result")))
    			sbErr.append("\nHttpStatus 오류 - res 오류 내용 확인 필요");
    		
    		if(sbErr.length() > 0)
    			throw new Exception(sbErr.toString());
        }
        catch(Exception e) {
            throw e;
        }
        finally {
            close(httpClient);
        }
	}

	@SuppressWarnings("unchecked")
	protected String makeData() throws Exception {
        FileInputStream fReader = null;
        InputStreamReader iReader = null;
        BufferedReader bReader = null;
        JSONArray jarr = new JSONArray();
        JSONParser parser = new JSONParser();
        JSONObject jobj = null;

        try {
        	Logger.logger.info("read file data : " + file);
            fReader = new FileInputStream(file);
            iReader = new InputStreamReader(fReader, "EUC-KR");
            bReader = new BufferedReader(iReader);

            String line, lineDatas[], key, value;
            int i, lineCount, skipCount;
            boolean chkValue = true;
            for(lineCount = 0, skipCount = 0; (line = bReader.readLine()) != null; ) {
            	if("".equals(line.trim())) continue;

            	lineCount++;

                jobj = new JSONObject();
            	lineDatas = line.split("\\|");
            	chkValue = true;
                for(i = 0; i < KEY_LIST.length; i++) {
                    key = KEY_LIST[i][0];
                    value = (i < lineDatas.length ? lineDatas[i] : "").trim();

                    if("".equals(value)) {
                    	// 회선신청구분(LINE_APP_TYPE) 'C'(변경) 인 경우  회선변경유형(LINE_MOD_TYPE) 필수 항목
                        if("LINE_MOD_TYPE".equals(key) && !"C".equals(jobj.get("LINE_APP_TYPE"))) {
                        	jobj.put(key, new JSONArray());
                        } else {
                        	Logger.logger.error(KEY_LIST[i][1] + "(" + key + ") null !!!");
                        	chkValue = false;
                        }
                    } else {
                        if("LINE_MOD_TYPE".equals(key)) {
                        	jobj.put(key, parser.parse(value));
                        } else {
                        	jobj.put(key, value);
                        }
                    }
                }
                if(!chkValue) {
                	Logger.logger.error("skip line data : " + line);
                	skipCount++;
                }
                else
                	jarr.add(jobj);
            }
            if(skipCount > 0) {
            	sbErr.append("\n입력값 체크 오류 데이터 존재 - 입력 파일 데이터(skip line data) 확인 필요");
            }
            
            Logger.logger.info("total : " + lineCount + " (" + (lineCount-skipCount) + " send / " + skipCount + " skip)");
        }
        catch(Exception e) {
            throw e;
        }
        finally {
            close(bReader);
            close(iReader);
            close(fReader);
        }
        return jarr.toJSONString();
    }

    protected void close(Object obj) {
        try {
            if(obj != null) {
                if(obj instanceof CloseableHttpClient) ((CloseableHttpClient)obj).close();
                else if(obj instanceof BufferedReader) ((BufferedReader)obj).close();
                else if(obj instanceof InputStreamReader) ((InputStreamReader)obj).close();
                else if(obj instanceof FileInputStream) ((FileInputStream)obj).close();
            }
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
}
