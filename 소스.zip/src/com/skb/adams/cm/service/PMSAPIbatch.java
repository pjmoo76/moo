package com.skb.adams.cm.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.io.IOException;
import java.io.InputStream;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.skb.adams.cm.model.Address_OES30300;
import com.skb.adams.cm.model.LdongAddress_OES30300;
import subkjh.bas.log.Logger;

class LocationINfo{
	String address;
	double lat;
	double lng;
}

public class PMSAPIbatch {

	private OIV10641xService dOIV1064;

	public void main(String[] args) throws Exception {
		pgetLocationInfo();
	}     
    	public void pgetLocationInfo() throws Exception {	
    	   
    		LocationINfo address_INfo = new LocationINfo();
    		String ACtpvcNM="";
        	String ACtguncuNM="";
        	String AUpmyundongNM="";
        	String ARiNm="";
        	String Address= "";
        	String LdongCd = "";
        	int i=0, j=0;
        	dOIV1064.setconn();
            List<Address_OES30300> AddressList = dOIV1064.doOES30300();
       		List<Address_OES30300> oneAddrList = new ArrayList<Address_OES30300>(); 
    	            
       		for (i= 0; i< AddressList.size(); i++)
       		{
        	   Address_OES30300 oes30300 = AddressList.get(i);
        	   oneAddrList.add(oes30300);
       		}
       				
            for (i= 0; i< AddressList.size(); i++)
            {
            	if(oneAddrList.get(i).getRiNm()==null){
	            	ACtpvcNM = oneAddrList.get(i).getCtpvcNm().toString().replace("세종", "세종시");
	            	ACtpvcNM = ACtpvcNM.replace(" ", "");
	            	ACtguncuNM = oneAddrList.get(i).getCtguncuNm().toString().replace(".", "");
	              	ACtguncuNM = ACtguncuNM.replace(" ", "");
	      	     	AUpmyundongNM = oneAddrList.get(i).getUpmyundongNm().toString();
	            	AUpmyundongNM = AUpmyundongNM.replace(" ", "");
	            	Address = ACtpvcNM+ACtguncuNM+AUpmyundongNM;
            	}else{
                	ACtpvcNM = oneAddrList.get(i).getCtpvcNm().toString().replace("세종", "세종시");
                  	ACtpvcNM = ACtpvcNM.replace(" ", "");
              	    ACtguncuNM = oneAddrList.get(i).getCtguncuNm().toString().replace(".","");
              	 	ACtguncuNM = ACtguncuNM.replace(" ", "");
     	            AUpmyundongNM = oneAddrList.get(i).getUpmyundongNm().toString();
     	          	AUpmyundongNM = AUpmyundongNM.replace(" ", "");
     	  	        ARiNm = oneAddrList.get(i).getRiNm().toString().replace("세종리","");
	            	Address = ACtpvcNM+ACtguncuNM+AUpmyundongNM+ARiNm;
            	}
            	LdongCd = oneAddrList.get(i).getLdong_Cd().toString();

            	//Logger.logger.debug("주소 :"+Address);
                
    		    JsonNode AddrObject;
    		    AddrObject=GoogleApi(Address);
    		    if(AddrObject==null)
    			{
    	        	//주소가 없을때 재 겁색
    		    	AddrObject=GoogleApi(ACtguncuNM+AUpmyundongNM);
    	            if(AddrObject ==null){
    	            	//Logger.logger.debug("API에서 검색이 안되는 주소입니다.("+ Address+")");
    	            	continue;
    	            }
    	    	}
    		       
    		    address_INfo.lat = AddrObject.get("geometry").get("location").get("lat").doubleValue();
    	        address_INfo.lng = AddrObject.get("geometry").get("location").get("lng").doubleValue();
    	        
    	        List<LdongAddress_OES30300> LdongAddresList= dOIV1064.doLdongList(LdongCd);
    			List<LdongAddress_OES30300> oneListLdong = new ArrayList<LdongAddress_OES30300>(); 
            	for (j= 0; j< LdongAddresList.size(); j++)
               {
            		LdongAddress_OES30300 LdongAddr = LdongAddresList.get(j);
            		oneListLdong.add(LdongAddr);
               }
    		
            	String lat = String.valueOf(address_INfo.lat);
            	String lng = String.valueOf(address_INfo.lng);
            
            	//Logger.logger.debug("위경도좌표  : "+lat+" "+lng);
            	   
            	for (j= 0; j< LdongAddresList.size(); j++)
                 {
            			HashMap<String, String> hmap = new HashMap<String, String>();
            	 		hmap.put("equip_id", oneListLdong.get(j).getEquipId().toString());
              			hmap.put("ldong_cd", oneListLdong.get(j).getLdong_Cd().toString());
            			hmap.put("audit_id", "BATCH");		
            			hmap.put("ltt_val", lat);
            			hmap.put("ltd_val", lng);
            	  		dOIV1064.doUpdate(hmap);
                 }

            }
    	}

    	//GooGle API
    	public JsonNode GoogleApi(String address) throws IOException { 
		    HttpGet httpGet = new HttpGet("https://maps.googleapis.com/maps/api/geocode/json?address="+address+"&key=AIzaSyAMVLJi3YvEW3TaqdLja0fQrc-f3KB29ro");
		    HttpClient httpClient = HttpClientBuilder.create().build();
		    HttpResponse response;
	        StringBuilder stringBuilder = new StringBuilder();
	        try {
	            response = httpClient.execute(httpGet);
	            HttpEntity entity = response.getEntity();
	            InputStream stream = entity.getContent();
	            int b;
	            while ((b = stream.read()) != -1) {
	                stringBuilder.append((char) b);
	            }
	        } catch (ClientProtocolException e) {
	            } catch (IOException e) {
	        }
	        ObjectMapper mapper = new ObjectMapper();
	        JsonNode array =  mapper.readValue(stringBuilder.toString(), JsonNode.class);
	        JsonNode object = array.get("results").get(0);
	        return object;
		}
}
