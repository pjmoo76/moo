package com.skb.adams.cm.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.Logger;

public class FomsCmService {

	public static void main(String[] args) {
		// parameters: sourceDir=/data/foms [day=20171209] [dayOffset=1]
		String	sourceDir = null;
		String	day = null;
		int		dayOffset = 0;
		for (int i = 0; i < args.length; i ++) {
			String[] tokens = args[i].split("=");
			if ("SOURCEDIR".equals(tokens[0].toUpperCase())) {
				sourceDir = tokens[1];
			} else if ("DAY".equals(tokens[0].toUpperCase())) {
				day = tokens[1];
			} else if ("DAYOFFSET".equals(tokens[0].toUpperCase())) {
				dayOffset = Integer.parseInt(tokens[1]);
			}
		}
		if (sourceDir == null) {
			System.out.println("invalid paramter. (sourceDir=" + sourceDir+ ")");
			return;
		}
		
		FomsCmService fomsCmService = new FomsCmService(sourceDir, day, dayOffset);
		fomsCmService.run();

	}
	
	private	String	sourceDir		= null;
	private	String	day				= null;
	private	int		dayOffset		= 0;
	private	String	cmBatchBinDir	= null;
	
	private	ArrayList<DataLoader> dataLoaders = null;
	
	public FomsCmService(String sourceDir, String day, int dayOffset) {
		this.sourceDir = sourceDir;
		this.day = day;
		this.dayOffset = dayOffset;
		
		if (day == null || day.isEmpty()) {
			LocalDate currentDate = LocalDate.now().plusDays(dayOffset);
			day = currentDate.getYear() +
					String.format("%02d", currentDate.getMonthValue()) +
					String.format("%02d", currentDate.getDayOfMonth());
		}

		cmBatchBinDir = System.getenv("FXMS_HOME") + "/bin";
	}
	
	public void run() {
		try {
			setDataLoaders();
	
			File folder = new File(sourceDir);
			File[] files = folder.listFiles();
			if (files == null) {
				Logger.logger.error("failed to get files in " + sourceDir);
				return;
			}
			for (File file : files) {
				if (file.isFile()) {
					String inFilename = file.getName();
					Logger.logger.debug("file : " + inFilename);
					DataLoader dl = getDataLoader(inFilename);
					if (dl == null) continue;
					try {
						dl.open(sourceDir + "/" + inFilename);
					} catch (Exception e) {
						Logger.logger.error(e);
					}
				}
			}
		} catch (Exception e) {
			Logger.logger.error(e);
		}
	}
	
	private void setDataLoaders() throws Exception {
		DataBase database = DBManager.getMgr().getDataBase("ADAMS");
		DbTrans tran = database.createDbTrans("deploy/conf/sql/foms.xml");
		tran.start();

		dataLoaders = new ArrayList<DataLoader>();
		dataLoaders.add(new DataLoader().setDstTran(tran)
										.setPrefix("conf_cell_info")
										.setTableName("IF_FOMS_CONF_CELL_INFO")
										.setColumnNames(new String[] {"DEVICENUM","CELL_NO","RACK_ID","SHELF_ID","CARD_ID","PON_PORT","RN_CNT","USER_CNT","DEL_FLAG"} ));
		dataLoaders.add(new DataLoader().setDstTran(tran)
										.setPrefix("conf_device")
										.setTableName("IF_FOMS_CONF_DEVICE")
										.setColumnNames(new String[] {"DEVICENUM","UP_DEVICENUM","TID","DEVTYPE","DEVICEIP","TPO_CD","TPO_NM","K_TPO_CD","K_TPO_NM","TEAMCODE","EMSIP","LOCATION","WRK_DT","GENDATETIME","DEVGROUP","COMMUNITY","FLAG","REMARK","FUNCGROUP","INGROUP","SERVICE_NAME","DEV_MAC","DEV_MASS_KIND","LDONG_CD","LSIDO_NM","LGUGUN_NM","LDONG_NM","DEL_FLAG"} ));
		dataLoaders.add(new DataLoader().setDstTran(tran)
										.setPrefix("conf_device_rn")
										.setTableName("IF_FOMS_CONF_DEVICE_RN")
										.setColumnNames(new String[] {"DEVICENUM","UP_DEVICENUM","TID","DEVTYPE","DEVICEIP","TPO_CD","TPO_NM","K_TPO_CD","K_TPO_NM","TEAMCODE","EMSIP","LOCATION","WRK_DT","GENDATETIME","DEVGROUP","COMMUNITY","FLAG","REMARK","FUNCGROUP","INGROUP","SERVICE_NAME","DEV_MAC","DEV_MASS_KIND","LDONG_CD","LSIDO_NM","LGUGUN_NM","LDONG_NM","DEL_FLAG"} ));
		dataLoaders.add(new DataLoader().setDstTran(tran)
										.setPrefix("conf_map_dev_level_rn")
										.setTableName("IF_FOMS_CONF_MAP_DEV_LEVEL_RN")
										.setColumnNames(new String[] {"DEVICENUM","DEV_LEVEL"} ));
		dataLoaders.add(new DataLoader().setDstTran(tran)
										.setPrefix("conf_map_grid")
										.setTableName("IF_FOMS_CONF_MAP_GRID")
										.setColumnNames(new String[] {"TEAMNAME","TEAMCODE","K_TPO_NM","K_TPO_CD","AR_TID","AR_DOWN_IFNAME","AR_DOWN_LINK_STAT","DEVICENUM1","TID1","TPO_NM1","UP_IFNAME1","DOWN_IFNAME1","DOWN_LINK_STAT1","DEVICENUM2","TID2","TPO_NM2","UP_IFNAME2","DOWN_IFNAME2","DOWN_LINK_STAT2","DEVICENUM3","TID3","TPO_NM3","UP_IFNAME3","DOWN_IFNAME3","DOWN_LINK_STAT3","DEVICENUM4","TID4","TPO_NM4","UP_IFNAME4","DOWN_IFNAME4","DOWN_LINK_STAT4","DEVICENUM5","TID5","TPO_NM5","UP_IFNAME5","DOWN_IFNAME5","DOWN_LINK_STAT5","DEVICENUM6","TID6","TPO_NM6","UP_IFNAME6","DOWN_IFNAME6","DOWN_LINK_STAT6","DEVICENUM7","TID7","TPO_NM7","UP_IFNAME7","DOWN_IFNAME7","DOWN_LINK_STAT7","DEVICENUM8","TID8","TPO_NM8","UP_IFNAME8","DOWN_IFNAME8","DOWN_LINK_STAT8","DEVICENUM9","TID9","TPO_NM9","UP_IFNAME9","DOWN_IFNAME9","DOWN_LINK_STAT9","DEVICENUM10","TID10","TPO_NM10","UP_IFNAME10","DOWN_IFNAME10","DOWN_LINK_STAT10","DEVICENUM11","TID11","TPO_NM11","UP_IFNAME11","DOWN_IFNAME11","DOWN_LINK_STAT11","DEVICENUM12","TID12","TPO_NM12","UP_IFNAME12","DOWN_IFNAME12","DOWN_LINK_STAT12","DEVICENUM13","TID13","TPO_NM13","UP_IFNAME13","DOWN_IFNAME13","DOWN_LINK_STAT13","DEVICENUM14","TID14","TPO_NM14","UP_IFNAME14","DOWN_IFNAME14","DOWN_LINK_STAT14","DEVICENUM15","TID15","TPO_NM15","UP_IFNAME15","DOWN_IFNAME15","DOWN_LINK_STAT15","DEVICENUM16","TID16","TPO_NM16","UP_IFNAME16","DOWN_IFNAME16","DOWN_LINK_STAT16","DEVICENUM17","TID17","TPO_NM17","UP_IFNAME17","DOWN_IFNAME17","DOWN_LINK_STAT17","DEVICENUM18","TID18","TPO_NM18","UP_IFNAME18","DOWN_IFNAME18","DOWN_LINK_STAT18","DEVICENUM19","TID19","TPO_NM19","UP_IFNAME19","DOWN_IFNAME19","DOWN_LINK_STAT19","DEVICENUM20","TID20","TPO_NM20","UP_IFNAME20","DOWN_IFNAME20","DOWN_LINK_STAT20"} ));
	}
	
	private DataLoader getDataLoader(String infileName) {
		for (int i = 0; i < dataLoaders.size(); i ++) {
			DataLoader dl = dataLoaders.get(i);
			if (dl.getPrefix().equals(infileName.substring(0, dl.getPrefix().length()))) {
				return dl;
			}
		}
		return null;
	}
	
}
