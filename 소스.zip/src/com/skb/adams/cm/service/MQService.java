package com.skb.adams.cm.service;

import subkjh.bas.log.Logger;

import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQQueue;
import com.ibm.mq.constants.MQConstants;

public class MQService {
	private final String	DEV_QUEUE_MANANGER	= "OSSIF1S";		// 개발 MQ서버의 큐매니저명
	private final String	DEV_HOST_NAME		= "12.4.8.247";		// 개발 MQ서버 IP
	private final int		DEV_PORT_NO			= 9415;				// 개발 MQ서버 접속 Port

	private final String	OPER_QUEUE_MANANGER	= "OSS1";			// 운영 MQ서버의 큐매니저명
	private final String	OPER_HOST_NAME		= "12.4.4.181";		// 운영 MQ서버 IP
	private final int		OPER_PORT_NO		= 1414;				// 운영 MQ서버 접속 Port

	private final String	CHANNEL_NAME	= "SYSTEM.DEF.SVRCONN";	// 채널명으로 기본값 사용
	private final int		CCSID			= 970;					// 한글문자셋 코드로 기본값 사용
	
	private	String	queueManager	= null;
	private	String	hostName		= null;
	private	int		portNO			= 0;
	
	MQConnection		mqConn	= null;
	MQQueue				mqQueue	= null;
	MQGetMessageOptions	mqGmo	= null;
	
	MQInterface	mqInterface;
	
	public enum PROC_MODE {
		OPER_MODE, DEV_MODE
	}

	public MQService(MQInterface mqInterface) {
		this.mqInterface = mqInterface;
		set(PROC_MODE.DEV_MODE);
	}
	
	public MQService(MQInterface mqInterface, PROC_MODE procMode) {
		this.mqInterface = mqInterface;
		set(procMode);
	}
	
	private void set(PROC_MODE procMode) {
		if (procMode == PROC_MODE.OPER_MODE) {
			queueManager = OPER_QUEUE_MANANGER;
			hostName = OPER_HOST_NAME;
			portNO = OPER_PORT_NO;
		} else {
			queueManager = DEV_QUEUE_MANANGER;
			hostName = DEV_HOST_NAME;
			portNO = DEV_PORT_NO;			
		}
		Logger.logger.info("queueManager:" + queueManager);
		Logger.logger.info("hostName:" + hostName);
		Logger.logger.info("portNO:" + portNO);
	}
	
	public void connect() throws Exception {
		mqConn = new MQConnection();
		mqConn.setqManager(queueManager);
		mqConn.setRequestQueue(mqInterface.getQueueName());
		mqConn.setHostName(hostName);
		mqConn.setPort(portNO);
		mqConn.setChannel(CHANNEL_NAME);
		mqConn.setCcsid(CCSID);
		
		Logger.logger.info("---------------------------------------------------------------------");
		Logger.logger.info("connecting to MQ (" + queueManager + "),(" + hostName + ":" + portNO + ")");
		Logger.logger.info("---------------------------------------------------------------------");

		mqQueue = mqConn.getConnection(); // MQGET 커넥션 연결
		// Specify default get message options
		mqGmo = new MQGetMessageOptions();
		mqGmo.options = mqGmo.options | MQConstants.MQGMO_SYNCPOINT;
		
		Logger.logger.info("connected.");
	}
	
	public void get() throws Exception {
		Logger.logger.info("get()");
		int nCnt = 0;
		try {
			while (true) {
				try {
					MQMessage message = new MQMessage();
					mqQueue.get(message, mqGmo);
					// MQ 메세지를 1만건 단위로 Commit 하는 기능 추가 (2024-03-20 by KMY) 
					nCnt  = nCnt+1;
					if (nCnt == 9999) {
						mqConn.commit();
						mqInterface.commit();
						Logger.logger.info("mq.commit & mqInterface.commit count=>" + nCnt);
						nCnt = 0;
					}
	
					int strLen = message.getMessageLength();
					byte[] strData = new byte[strLen];
					message.readFully(strData);
					String msgText = new String(strData, "MS949"); // MQ에서 읽은 메시지
	
					boolean ret = mqInterface.process(msgText);
					if (ret == false) {
						break;
					}
	
				} catch (MQException ex) {
					if (ex.reasonCode == 2033) { // 더 이상 읽을 메시지가 없는 경우 발생하는 Exception 코드 2033
						Logger.logger.info("There is no message on the queue");;
						mqConn.commit();
						mqInterface.commit();
						Logger.logger.info("commit.");
						Thread.sleep(10000);
					} else {
						try {
							mqQueue = mqConn.reGetConnection(ex, 60000); // 네트워크 장애로 인한 커넥션이 단절되었을 경우 60초 지연 후 재연결 요청
						} catch (Exception er) {
							Logger.logger.error(er);
							throw(er);
						}
					}
				} catch (Exception e) {
					Logger.logger.error(e);
					throw(e);
				}
			}
		} finally {
			mqConn.rollback(); // 트랜잭션 rollback
			Logger.logger.info("rollback.");
			mqConn.close();
		}
	}
}
