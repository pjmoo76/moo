package com.skb.adams.cm.service;

public class UnmsCmService {
	public static void main(String[] args) {
		// parameters: sourceDir=/data/foms [day=20171209] [dayOffset=1]
		String	sourceDir = null;
		String	day = null;
		int		dayOffset = 0;
		for (int i = 0; i < args.length; i ++) {
			String[] tokens = args[i].split("=");
			if ("SOURCEDIR".equals(tokens[0].toUpperCase())) {
				sourceDir = tokens[1];
			} else if ("DAY".equals(tokens[0].toUpperCase())) {
				day = tokens[1];
			} else if ("DAYOFFSET".equals(tokens[0].toUpperCase())) {
				dayOffset = Integer.parseInt(tokens[1]);
			}
		}
		if (sourceDir == null) {
			System.out.println("invalid paramter. (sourceDir=" + sourceDir+ ")");
			return;
		}
	}
	
	public UnmsCmService() {
		
	}
	
	private void getTargetTables() {
		
	}
}
