package com.skb.adams.cm;

import subkjh.bas.log.Logger;

public class CmMsg {

	public static void main(String[] args) {
		System.out.println(CmMsg.makeCmInfo("OIV10100(장비기본)", -1, 100, -1));
		System.out.println(CmMsg.makeCmInfo("OIV10100", -1, 100, -1));
	}

	public static String makeCmInfo(String id, long deleteCnt, long addCnt, long updateCnt) {
		return makeCmInfo(id, deleteCnt, addCnt, updateCnt, -1);
	}

	public static String makeCmInfo(String id, long deleteCnt, long addCnt, long updateCnt, long nothingCnt) {
		StringBuffer sb = new StringBuffer();

		sb.append("\n");
		sb.append(Logger.LINE);
		sb.append("\n");
		sb.append("*** CM-BATCH >>> ");
		sb.append(Logger.fill(id, 48, '.'));
		sb.append(" :");
		if (deleteCnt >= 0) {
			sb.append(" ");
			sb.append(deleteCnt);
			sb.append(" Deleted");
		}
		if (addCnt >= 0) {
			sb.append(" ");
			sb.append(addCnt);
			sb.append(" Added");
		}
		if (updateCnt >= 0) {
			sb.append(" ");
			sb.append(updateCnt);
			sb.append(" Updated");
		}
		if (nothingCnt >= 0) {
			sb.append(" ");
			sb.append(nothingCnt);
			sb.append(" Nothing");
		}
		sb.append("\n");
		sb.append(Logger.LINE);

		return sb.toString();
	}

	public static String makeCmInfo(String id, Object... msg) {
		StringBuffer sb = new StringBuffer();

		sb.append("\n");
		sb.append(Logger.LINE);
		sb.append("\n");
		sb.append("*** CM-BATCH >>> ");
		sb.append(Logger.fill(id, 48, '.'));
		sb.append(" :");
		for (Object s : msg) {
			sb.append(" ");
			sb.append(s);
		}

		sb.append("\n");
		sb.append(Logger.LINE);

		return sb.toString();
	}
}
