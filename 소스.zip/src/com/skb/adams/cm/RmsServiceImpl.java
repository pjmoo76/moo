package com.skb.adams.cm;

import java.rmi.RemoteException;

import com.skb.adams.cm.batch.FileBatchThread;

import fxms.bas.fxo.service.FxServiceImpl;

public class RmsServiceImpl extends FxServiceImpl implements RmsService {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3490724989488252127L;

	private FileBatchThread batchThread;

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		FxServiceImpl.start(RmsService.class.getSimpleName(), RmsServiceImpl.class, args);
	}

	public RmsServiceImpl(String name, int port) throws RemoteException, Exception {
		super(name, port);
	}

	@Override
	protected void onStarted() throws Exception {
		batchThread = new FileBatchThread();
		batchThread.start();
	}
}
