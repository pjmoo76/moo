package com.skb.adams.cm.model;

import java.sql.Timestamp;

public class ZordCustVO {
	private	long		custNum;
	private	String		auditId;
	private	Timestamp	auditDtm;
	private	String		birthDt;
	private	String		sexCd;
	private	String		custTypCd;
	private	String		custDtlTypCd;
	private	String		natCd;
	private	String		rnmCheckYn;
	private	String		rnmAuthMthdCd;
	private	String		stayQualfCd;
	private	String		stayExpirDt;
	private	long		ctzCorpBizSerNum;
	private	String		ctzCorpBizNumPinf;
	private	String		custRgstDt;
	private	String		logicDelYn;
	private	String		custNm;
	private	String		custChrticCd;

	public String getCustNm() {
		return custNm;
	}
	public void setCustNm(String custNm) {
		this.custNm = custNm;
	}
	public String getCustChrticCd() {
		return custChrticCd;
	}
	public void setCustChrticCd(String custChrticCd) {
		this.custChrticCd = custChrticCd;
	}
	public long getCustNum() {
		return custNum;
	}
	public void setCustNum(long custNum) {
		this.custNum = custNum;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public Timestamp getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(Timestamp auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getBirthDt() {
		return birthDt;
	}
	public void setBirthDt(String birthDt) {
		this.birthDt = birthDt;
	}
	public String getSexCd() {
		return sexCd;
	}
	public void setSexCd(String sexCd) {
		this.sexCd = sexCd;
	}
	public String getCustTypCd() {
		return custTypCd;
	}
	public void setCustTypCd(String custTypCd) {
		this.custTypCd = custTypCd;
	}
	public String getCustDtlTypCd() {
		return custDtlTypCd;
	}
	public void setCustDtlTypCd(String custDtlTypCd) {
		this.custDtlTypCd = custDtlTypCd;
	}
	public String getNatCd() {
		return natCd;
	}
	public void setNatCd(String natCd) {
		this.natCd = natCd;
	}
	public String getRnmCheckYn() {
		return rnmCheckYn;
	}
	public void setRnmCheckYn(String rnmCheckYn) {
		this.rnmCheckYn = rnmCheckYn;
	}
	public String getRnmAuthMthdCd() {
		return rnmAuthMthdCd;
	}
	public void setRnmAuthMthdCd(String rnmAuthMthdCd) {
		this.rnmAuthMthdCd = rnmAuthMthdCd;
	}
	public String getStayQualfCd() {
		return stayQualfCd;
	}
	public void setStayQualfCd(String stayQualfCd) {
		this.stayQualfCd = stayQualfCd;
	}
	public String getStayExpirDt() {
		return stayExpirDt;
	}
	public void setStayExpirDt(String stayExpirDt) {
		this.stayExpirDt = stayExpirDt;
	}
	public long getCtzCorpBizSerNum() {
		return ctzCorpBizSerNum;
	}
	public void setCtzCorpBizSerNum(long ctzCorpBizSerNum) {
		this.ctzCorpBizSerNum = ctzCorpBizSerNum;
	}
	public String getCtzCorpBizNumPinf() {
		return ctzCorpBizNumPinf;
	}
	public void setCtzCorpBizNumPinf(String ctzCorpBizNumPinf) {
		this.ctzCorpBizNumPinf = ctzCorpBizNumPinf;
	}
	public String getCustRgstDt() {
		return custRgstDt;
	}
	public void setCustRgstDt(String custRgstDt) {
		this.custRgstDt = custRgstDt;
	}
	public String getLogicDelYn() {
		return logicDelYn;
	}
	public void setLogicDelYn(String logicDelYn) {
		this.logicDelYn = logicDelYn;
	}
}
