package com.skb.adams.cm.model.map;

import java.util.HashMap;
import java.util.Map;

public class MacMap<DATA> {

	private Map<String, Map<String, DATA>> map;
	private int size = 0;
	
	
	public MacMap() {
		map = new HashMap<String, Map<String, DATA>>();
	}

	public int sizeParent() {
		return map.size();
	}

	public int size() {
		return size;
	}

	public synchronized DATA findMac(String mac, DATA data) {

		if (mac == null || mac.length() < 12) {
			return null;
		}
		String pMac = mac.substring(0, 6);
		String sMac = mac.substring(6);

		Map<String, DATA> pMap = map.get(pMac);
		if (pMap == null) {
			pMap = new HashMap<String, DATA>();
			map.put(pMac, pMap);
		}

		DATA oldData = pMap.get(sMac);
		if (oldData != null) {
			return oldData;
		}

		pMap.put(sMac, data);
		size++;
		return data;
	}

}
