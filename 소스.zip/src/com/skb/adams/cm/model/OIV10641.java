package com.skb.adams.cm.model;

public class OIV10641 {

	private String equip_id;
	private String audit_id;
	private String audit_dtm;
	private String ltt_val;
	private String ltd_val;
	private String ldong_cd;
	private String ri_nm;

	public OIV10641() {
	
	}
	
	public String getEquipId() {
		return equip_id;
	}
	public void setEquipId(String EquipId) {
		this.equip_id = EquipId;
	}
	public String getAuditId(){
		return audit_id;
	}
	public void setAuditId(String AuditId) {
		this.audit_id = AuditId;
	}
	public String getAuditDtm(){
		return audit_dtm;
	} 
	public void setAuditDtm(String AuditDtm){
		this.audit_dtm = AuditDtm;
	}
	public String getLttVal(){
		return ltt_val;
	}
	public void setLttval(String LttVal){
		this.ltt_val = ltt_val;
	}
	public String getLtdVal(){
		return ltd_val;
	}
	public void setLtdval(String LtdVal){
		this.ltd_val = LtdVal;
	}
	public String getLdongCd(){
		return ldong_cd;
	}
	public void setLdongCd(String LdongCd){
		this.ldong_cd = LdongCd;
	}
	public String getRiNm(){
		return ri_nm;
	}
	public void setRiNm(String rinm){
		this.ri_nm = rinm;
	}

}
