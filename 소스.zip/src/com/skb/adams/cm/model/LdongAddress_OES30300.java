package com.skb.adams.cm.model;

public class LdongAddress_OES30300 { 

	private String ldong_cd;
	private String equip_id;
	private String ct_pvc_nm;
	private String ct_gun_cu_nm;
	private String up_myun_dong_nm;
	private String ri_nm;
	
	public LdongAddress_OES30300(){
		
	}
	
	public String getLdong_Cd() {
		return ldong_cd;
	}
	public void setLdong_Cd(String ldong_cd) {
		this.ldong_cd = ldong_cd;
	}
	public String getEquipId() {
		return equip_id;
	}
	public void setEquipId(String EQUIP_ID) {
		this.equip_id =EQUIP_ID;
	}
	public String getCtpvcNm() {
		return ct_pvc_nm;		
	}
	public void setCtpvcNm(String CT_PVC_NM) {
		this.ct_pvc_nm =  CT_PVC_NM;
	}
	public String getCtguncuNm() {
		return ct_gun_cu_nm;
	}
	public void setCtguncuNm(String CT_GUN_CU_NM) {
		this.ct_gun_cu_nm = CT_GUN_CU_NM;
	}
	public String getUpmyundongNm() {
		return up_myun_dong_nm;
	}
	public void setUpmyundongNm(String UP_MYUN_DONG_NM) {
		this.up_myun_dong_nm = UP_MYUN_DONG_NM;
	}
	public String getRiNm(){
		return ri_nm;
	}
	public void setRiNm(String rinm){
		this.ri_nm = rinm;
	}
}

