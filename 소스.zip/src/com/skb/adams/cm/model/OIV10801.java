package com.skb.adams.cm.model;

import java.io.Serializable;
import java.sql.Timestamp;

import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;

/**
 * @since 2017.12.26 12:54
 * @author subkjh autometic create by subkjh.dao
 *
 */

@FxTable(name = "OIV10801", comment = "유선단말상태수집내역")
public class OIV10801 implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1596864565767971303L;

	@FxColumn(name = "MAC_ADDR_VAL", size = 15, comment = "MAC주소값")
	private String macAddrVal;

	@FxColumn(name = "AUDIT_ID", size = 15, comment = "최종변경자ID")
	private String auditId;

	@FxColumn(name = "IP_ADDR", size = 23, nullable = true, comment = "IP주소")
	private String ipAddr;

	@FxColumn(name = "PING_ST_VAL", size = 8, nullable = true, comment = "PING상태값")
	private String pingStVal;

	@FxColumn(name = "PING_ST_CHG_DTM", size = 0, nullable = true, comment = "PING상태변경일시")
	private Timestamp pingStChgDtm;

	@FxColumn(name = "LAST_PING_ST_CHECK_DTM", size = 14, nullable = true, comment = "최종PING상태확인일시")
	private String lastPingStCheckDtm;

	public OIV10801() {
	}

	/**
	 * 최종변경자ID
	 * 
	 * @return 최종변경자ID
	 */
	public String getAuditId() {
		return auditId;
	}

	/**
	 * IP주소
	 * 
	 * @return IP주소
	 */
	public String getIpAddr() {
		return ipAddr;
	}

	/**
	 * 최종PING상태확인일시
	 * 
	 * @return 최종PING상태확인일시
	 */
	public String getLastPingStCheckDtm() {
		return lastPingStCheckDtm;
	}

	/**
	 * MAC주소값
	 * 
	 * @return MAC주소값
	 */
	public String getMacAddrVal() {
		return macAddrVal;
	}

	/**
	 * PING상태변경일시
	 * 
	 * @return PING상태변경일시
	 */
	public Timestamp getPingStChgDtm() {
		return pingStChgDtm;
	}

	/**
	 * PING상태값
	 * 
	 * @return PING상태값
	 */
	public String getPingStVal() {
		return pingStVal;
	}

	/**
	 * 최종변경자ID
	 *
	 * @param auditId
	 *            최종변경자ID
	 */
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	/**
	 * IP주소
	 *
	 * @param ipAddr
	 *            IP주소
	 */
	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}

	/**
	 * 최종PING상태확인일시
	 *
	 * @param lastPingStCheckDtm
	 *            최종PING상태확인일시
	 */
	public void setLastPingStCheckDtm(String lastPingStCheckDtm) {
		this.lastPingStCheckDtm = lastPingStCheckDtm;
	}

	/**
	 * MAC주소값
	 *
	 * @param macAddrVal
	 *            MAC주소값
	 */
	public void setMacAddrVal(String macAddrVal) {
		this.macAddrVal = macAddrVal;
	}

	/**
	 * PING상태변경일시
	 *
	 * @param pingStChgDtm
	 *            PING상태변경일시
	 */
	public void setPingStChgDtm(Timestamp pingStChgDtm) {
		this.pingStChgDtm = pingStChgDtm;
	}

	/**
	 * PING상태값
	 *
	 * @param pingStVal
	 *            PING상태값
	 */
	public void setPingStVal(String pingStVal) {
		this.pingStVal = pingStVal;
	}

	@Override
	public String toString() {
		return macAddrVal + ":" + pingStVal + ":" + lastPingStCheckDtm;
	}
}
