package com.skb.adams.cm.model;

import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;

import java.io.Serializable;
import java.sql.Timestamp;

/**
* @since 2018.09.26 14:22
* @author subkjh 
* autometic create by subkjh.dao 
*
*/


@FxTable(name = "OES10400", comment = "서비스기술방식기본")
public class OES10400 implements Serializable {

/**
	 * 
	 */
	private static final long serialVersionUID = 5185219876274592972L;


public OES10400() {
 }

@FxColumn(name = "SVC_TECH_MTHD_CD", size = 5, comment = "서비스기술방식코드")
private String svcTechMthdCd;


@FxColumn(name = "AUDIT_ID", size = 15, comment = "최종변경자ID")
private String auditId;


@FxColumn(name = "AUDIT_DTM", size = 0, comment = "최종변경일시")
private Timestamp auditDtm;


@FxColumn(name = "SVC_TECH_MTHD_NM", size = 30, comment = "서비스기술방식명")
private String svcTechMthdNm;


@FxColumn(name = "SVC_TS", size = 1, nullable = true, comment = "서비스차수")
private int svcTs;


@FxColumn(name = "SVC_CD", size = 1, comment = "서비스코드")
private String svcCd;


@FxColumn(name = "WSVC_TYP_CD", size = 3, comment = "유선서비스유형코드")
private String wsvcTypCd;


@FxColumn(name = "WIRE_MEDIA_FCLT_TYP_CD", size = 3, comment = "유선매체별시설유형코드")
private String wireMediaFcltTypCd;


@FxColumn(name = "OPER_GRP_SEL_STRD_ID", size = 2, nullable = true, comment = "작업그룹선정기준ID")
private String operGrpSelStrdId;


@FxColumn(name = "AVAIL_CHECK_YN", size = 1, nullable = true, comment = "가용확인여부")
private String availCheckYn;


@FxColumn(name = "CAPA_CHECK_YN", size = 1, nullable = true, comment = "용량확인여부")
private String capaCheckYn;


@FxColumn(name = "HK_FLSH_YN", size = 1, nullable = true, comment = "HOOKFLASH여부")
private String hkFlshYn;


@FxColumn(name = "WEQP_NEED_YN", size = 1, nullable = true, comment = "유선단말필요여부")
private String weqpNeedYn;


@FxColumn(name = "WEQP_SUBMIT_YN", size = 1, nullable = true, comment = "유선단말불출여부")
private String weqpSubmitYn;


@FxColumn(name = "WEQP_DISTB_YN", size = 1, nullable = true, comment = "유선단말배분여부")
private String weqpDistbYn;


@FxColumn(name = "OSS_SVC_NEED_YN", size = 1, comment = "OSS개통필요여부")
private String ossSvcNeedYn;


@FxColumn(name = "SCHDLG_OBJ_YN", size = 1, comment = "스케줄링대상여부")
private String schdlgObjYn;


@FxColumn(name = "EFF_STA_DT", size = 8, comment = "유효시작일자")
private String effStaDt;


@FxColumn(name = "EFF_END_DT", size = 8, comment = "유효종료일자")
private String effEndDt;


@FxColumn(name = "VOICE_TECH_MTHD_TYP_CD", size = 4, comment = "음성기술방식유형코드")
private String voiceTechMthdTypCd;


@FxColumn(name = "MSC_LNKG_VAL", size = 50, nullable = true, comment = "교환기연동값")
private String mscLnkgVal;


@FxColumn(name = "TECH_ABL_ID", size = 7, nullable = true, comment = "기술역량ID")
private int techAblId;


@FxColumn(name = "BRWS_SEQ", size = 3, nullable = true, comment = "조회순번")
private int brwsSeq;


@FxColumn(name = "AVAIL_OP_CL_CD", size = 1, comment = "가용처리분류코드")
private String availOpClCd;


@FxColumn(name = "END_OP_ASGN_ID", size = 15, nullable = true, comment = "종료처리지정ID")
private String endOpAsgnId;


@FxColumn(name = "SVC_TECH_MTHD_END_OBJ_YN", size = 1, nullable = true, comment = "서비스기술방식종료대상여부")
private String svcTechMthdEndObjYn;


@FxColumn(name = "END_OP_ASGNR_ID", size = 15, nullable = true, comment = "종료처리할당자ID")
private String endOpAsgnrId;


@FxColumn(name = "END_OBJ_EXTRT_DTM", size = 0, nullable = true, comment = "종료대상추출일시")
private Timestamp endObjExtrtDtm;

@FxColumn(name = "END_OBJ_EXTRT_DT", size = 0, nullable = true, comment = "종료대상추출일")
private String endObjExtrtDt;


/**
* 서비스기술방식코드
* @return 서비스기술방식코드
*/
public String getSvcTechMthdCd() {
return svcTechMthdCd;
}
/**
* 서비스기술방식코드
*@param svcTechMthdCd 서비스기술방식코드
*/
public void setSvcTechMthdCd(String svcTechMthdCd) {
	this.svcTechMthdCd = svcTechMthdCd;
}
/**
* 최종변경자ID
* @return 최종변경자ID
*/
public String getAuditId() {
return auditId;
}
/**
* 최종변경자ID
*@param auditId 최종변경자ID
*/
public void setAuditId(String auditId) {
	this.auditId = auditId;
}
/**
* 최종변경일시
* @return 최종변경일시
*/
public Timestamp getAuditDtm() {
return auditDtm;
}
/**
* 최종변경일시
*@param auditDtm 최종변경일시
*/
public void setAuditDtm(Timestamp auditDtm) {
	this.auditDtm = auditDtm;
}
/**
* 서비스기술방식명
* @return 서비스기술방식명
*/
public String getSvcTechMthdNm() {
return svcTechMthdNm;
}
/**
* 서비스기술방식명
*@param svcTechMthdNm 서비스기술방식명
*/
public void setSvcTechMthdNm(String svcTechMthdNm) {
	this.svcTechMthdNm = svcTechMthdNm;
}
/**
* 서비스차수
* @return 서비스차수
*/
public int getSvcTs() {
return svcTs;
}
/**
* 서비스차수
*@param svcTs 서비스차수
*/
public void setSvcTs(int svcTs) {
	this.svcTs = svcTs;
}
/**
* 서비스코드
* @return 서비스코드
*/
public String getSvcCd() {
return svcCd;
}
/**
* 서비스코드
*@param svcCd 서비스코드
*/
public void setSvcCd(String svcCd) {
	this.svcCd = svcCd;
}
/**
* 유선서비스유형코드
* @return 유선서비스유형코드
*/
public String getWsvcTypCd() {
return wsvcTypCd;
}
/**
* 유선서비스유형코드
*@param wsvcTypCd 유선서비스유형코드
*/
public void setWsvcTypCd(String wsvcTypCd) {
	this.wsvcTypCd = wsvcTypCd;
}
/**
* 유선매체별시설유형코드
* @return 유선매체별시설유형코드
*/
public String getWireMediaFcltTypCd() {
return wireMediaFcltTypCd;
}
/**
* 유선매체별시설유형코드
*@param wireMediaFcltTypCd 유선매체별시설유형코드
*/
public void setWireMediaFcltTypCd(String wireMediaFcltTypCd) {
	this.wireMediaFcltTypCd = wireMediaFcltTypCd;
}
/**
* 작업그룹선정기준ID
* @return 작업그룹선정기준ID
*/
public String getOperGrpSelStrdId() {
return operGrpSelStrdId;
}
/**
* 작업그룹선정기준ID
*@param operGrpSelStrdId 작업그룹선정기준ID
*/
public void setOperGrpSelStrdId(String operGrpSelStrdId) {
	this.operGrpSelStrdId = operGrpSelStrdId;
}
/**
* 가용확인여부
* @return 가용확인여부
*/
public String getAvailCheckYn() {
return availCheckYn;
}
/**
* 가용확인여부
*@param availCheckYn 가용확인여부
*/
public void setAvailCheckYn(String availCheckYn) {
	this.availCheckYn = availCheckYn;
}
/**
* 용량확인여부
* @return 용량확인여부
*/
public String getCapaCheckYn() {
return capaCheckYn;
}
/**
* 용량확인여부
*@param capaCheckYn 용량확인여부
*/
public void setCapaCheckYn(String capaCheckYn) {
	this.capaCheckYn = capaCheckYn;
}
/**
* HOOKFLASH여부
* @return HOOKFLASH여부
*/
public String getHkFlshYn() {
return hkFlshYn;
}
/**
* HOOKFLASH여부
*@param hkFlshYn HOOKFLASH여부
*/
public void setHkFlshYn(String hkFlshYn) {
	this.hkFlshYn = hkFlshYn;
}
/**
* 유선단말필요여부
* @return 유선단말필요여부
*/
public String getWeqpNeedYn() {
return weqpNeedYn;
}
/**
* 유선단말필요여부
*@param weqpNeedYn 유선단말필요여부
*/
public void setWeqpNeedYn(String weqpNeedYn) {
	this.weqpNeedYn = weqpNeedYn;
}
/**
* 유선단말불출여부
* @return 유선단말불출여부
*/
public String getWeqpSubmitYn() {
return weqpSubmitYn;
}
/**
* 유선단말불출여부
*@param weqpSubmitYn 유선단말불출여부
*/
public void setWeqpSubmitYn(String weqpSubmitYn) {
	this.weqpSubmitYn = weqpSubmitYn;
}
/**
* 유선단말배분여부
* @return 유선단말배분여부
*/
public String getWeqpDistbYn() {
return weqpDistbYn;
}
/**
* 유선단말배분여부
*@param weqpDistbYn 유선단말배분여부
*/
public void setWeqpDistbYn(String weqpDistbYn) {
	this.weqpDistbYn = weqpDistbYn;
}
/**
* OSS개통필요여부
* @return OSS개통필요여부
*/
public String getOssSvcNeedYn() {
return ossSvcNeedYn;
}
/**
* OSS개통필요여부
*@param ossSvcNeedYn OSS개통필요여부
*/
public void setOssSvcNeedYn(String ossSvcNeedYn) {
	this.ossSvcNeedYn = ossSvcNeedYn;
}
/**
* 스케줄링대상여부
* @return 스케줄링대상여부
*/
public String getSchdlgObjYn() {
return schdlgObjYn;
}
/**
* 스케줄링대상여부
*@param schdlgObjYn 스케줄링대상여부
*/
public void setSchdlgObjYn(String schdlgObjYn) {
	this.schdlgObjYn = schdlgObjYn;
}
/**
* 유효시작일자
* @return 유효시작일자
*/
public String getEffStaDt() {
return effStaDt;
}
/**
* 유효시작일자
*@param effStaDt 유효시작일자
*/
public void setEffStaDt(String effStaDt) {
	this.effStaDt = effStaDt;
}
/**
* 유효종료일자
* @return 유효종료일자
*/
public String getEffEndDt() {
return effEndDt;
}
/**
* 유효종료일자
*@param effEndDt 유효종료일자
*/
public void setEffEndDt(String effEndDt) {
	this.effEndDt = effEndDt;
}
/**
* 음성기술방식유형코드
* @return 음성기술방식유형코드
*/
public String getVoiceTechMthdTypCd() {
return voiceTechMthdTypCd;
}
/**
* 음성기술방식유형코드
*@param voiceTechMthdTypCd 음성기술방식유형코드
*/
public void setVoiceTechMthdTypCd(String voiceTechMthdTypCd) {
	this.voiceTechMthdTypCd = voiceTechMthdTypCd;
}
/**
* 교환기연동값
* @return 교환기연동값
*/
public String getMscLnkgVal() {
return mscLnkgVal;
}
/**
* 교환기연동값
*@param mscLnkgVal 교환기연동값
*/
public void setMscLnkgVal(String mscLnkgVal) {
	this.mscLnkgVal = mscLnkgVal;
}
/**
* 기술역량ID
* @return 기술역량ID
*/
public int getTechAblId() {
return techAblId;
}
/**
* 기술역량ID
*@param techAblId 기술역량ID
*/
public void setTechAblId(int techAblId) {
	this.techAblId = techAblId;
}
/**
* 조회순번
* @return 조회순번
*/
public int getBrwsSeq() {
return brwsSeq;
}
/**
* 조회순번
*@param brwsSeq 조회순번
*/
public void setBrwsSeq(int brwsSeq) {
	this.brwsSeq = brwsSeq;
}
/**
* 가용처리분류코드
* @return 가용처리분류코드
*/
public String getAvailOpClCd() {
return availOpClCd;
}
/**
* 가용처리분류코드
*@param availOpClCd 가용처리분류코드
*/
public void setAvailOpClCd(String availOpClCd) {
	this.availOpClCd = availOpClCd;
}
/**
* 종료처리지정ID
* @return 종료처리지정ID
*/
public String getEndOpAsgnId() {
return endOpAsgnId;
}
/**
* 종료처리지정ID
*@param endOpAsgnId 종료처리지정ID
*/
public void setEndOpAsgnId(String endOpAsgnId) {
	this.endOpAsgnId = endOpAsgnId;
}
/**
* 서비스기술방식종료대상여부
* @return 서비스기술방식종료대상여부
*/
public String getSvcTechMthdEndObjYn() {
return svcTechMthdEndObjYn;
}
/**
* 서비스기술방식종료대상여부
*@param svcTechMthdEndObjYn 서비스기술방식종료대상여부
*/
public void setSvcTechMthdEndObjYn(String svcTechMthdEndObjYn) {
	this.svcTechMthdEndObjYn = svcTechMthdEndObjYn;
}
/**
* 종료처리할당자ID
* @return 종료처리할당자ID
*/
public String getEndOpAsgnrId() {
return endOpAsgnrId;
}
/**
* 종료처리할당자ID
*@param endOpAsgnrId 종료처리할당자ID
*/
public void setEndOpAsgnrId(String endOpAsgnrId) {
	this.endOpAsgnrId = endOpAsgnrId;
}
/**
* 종료대상추출일시
* @return 종료대상추출일시
*/
public Timestamp getEndObjExtrtDtm() {
return endObjExtrtDtm;
}
/**
* 종료대상추출일시
*@param endObjExtrtDtm 종료대상추출일시
*/
public void setEndObjExtrtDtm(Timestamp endObjExtrtDtm) {
	this.endObjExtrtDtm = endObjExtrtDtm;
}
/**
* 종료대상추출일
* @return 종료대상추출일
*/
public String getEndObjExtrtDt() {
return endObjExtrtDt;
}
/**
* 종료대상추출일
*@param endObjExtrtDtm 종료대상추출일
*/
public void setEndObjExtrtDt(String endObjExtrtDt) {
	this.endObjExtrtDt = endObjExtrtDt;
}
}