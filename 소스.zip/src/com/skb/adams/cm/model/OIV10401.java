package com.skb.adams.cm.model;

public class OIV10401 {
	private String	linkId;
	private String	adrcEquipId;
	private String	adrcEquipPortId;
	private String	adrcIfId;
	private String	adrcCcellNum;
	private String	zdrcEquipId;
	private String	zdrcEquipPortId;
	private String	zdrcIfId;
	private String	zdrcCcellNum;
	private String	linkTypCd;
	private String	linkUsgCd;
	private String	linkRngCd;
	private String	lineNum;
	private long	lineSerNum;
	
	public String getLinkId() {
		return linkId;
	}
	public void setLinkId(String linkId) {
		this.linkId = linkId;
	}
	public String getAdrcEquipId() {
		return adrcEquipId;
	}
	public void setAdrcEquipId(String adrcEquipId) {
		this.adrcEquipId = adrcEquipId;
	}
	public String getAdrcEquipPortId() {
		return adrcEquipPortId;
	}
	public void setAdrcEquipPortId(String adrcEquipPortId) {
		this.adrcEquipPortId = adrcEquipPortId;
	}
	public String getAdrcIfId() {
		return adrcIfId;
	}
	public void setAdrcIfId(String adrcIfId) {
		this.adrcIfId = adrcIfId;
	}
	public String getAdrcCcellNum() {
		return adrcCcellNum;
	}
	public void setAdrcCcellNum(String adrcCcellNum) {
		this.adrcCcellNum = adrcCcellNum;
	}
	public String getZdrcEquipId() {
		return zdrcEquipId;
	}
	public void setZdrcEquipId(String zdrcEquipId) {
		this.zdrcEquipId = zdrcEquipId;
	}
	public String getZdrcEquipPortId() {
		return zdrcEquipPortId;
	}
	public void setZdrcEquipPortId(String zdrcEquipPortId) {
		this.zdrcEquipPortId = zdrcEquipPortId;
	}
	public String getZdrcIfId() {
		return zdrcIfId;
	}
	public void setZdrcIfId(String zdrcIfId) {
		this.zdrcIfId = zdrcIfId;
	}
	public String getZdrcCcellNum() {
		return zdrcCcellNum;
	}
	public void setZdrcCcellNum(String zdrcCcellNum) {
		this.zdrcCcellNum = zdrcCcellNum;
	}
	public String getLinkTypCd() {
		return linkTypCd;
	}
	public void setLinkTypCd(String linkTypCd) {
		this.linkTypCd = linkTypCd;
	}
	public String getLinkUsgCd() {
		return linkUsgCd;
	}
	public void setLinkUsgCd(String linkUsgCd) {
		this.linkUsgCd = linkUsgCd;
	}
	public String getLinkRngCd() {
		return linkRngCd;
	}
	public void setLinkRngCd(String linkRngCd) {
		this.linkRngCd = linkRngCd;
	}
	public String getLineNum() {
		return lineNum;
	}
	public void setLineNum(String lineNum) {
		this.lineNum = lineNum;
	}
	public long getLineSerNum() {
		return lineSerNum;
	}
	public void setLineSerNum(long lineSerNum) {
		this.lineSerNum = lineSerNum;
	}
}
