package com.skb.adams.cm.model;
import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;

import java.io.Serializable;
import java.sql.Timestamp;

/**
* @since 2018.09.26 14:25
* @author subkjh 
* autometic create by subkjh.dao 
*
*/


@FxTable(name = "OES10100", comment = "고객기본")
public class OES10100 implements Serializable {

/**
	 * 
	 */
	private static final long serialVersionUID = -1909197142489207693L;


public OES10100() {
 }

@FxColumn(name = "CUST_NUM", size = 10, comment = "고객번호")
private long custNum;


@FxColumn(name = "AUDIT_ID", size = 15, comment = "최종변경자ID")
private String auditId;


@FxColumn(name = "AUDIT_DTM", size = 0, comment = "최종변경일시")
private Timestamp auditDtm;


@FxColumn(name = "CUST_NM", size = 40, comment = "고객명")
private String custNm;


@FxColumn(name = "CUST_ST_CD", size = 2, comment = "고객상태코드")
private String custStCd;


@FxColumn(name = "CUST_CL_CD", size = 1, comment = "고객구분코드")
private String custClCd;


@FxColumn(name = "CUST_TYP_CD", size = 2, comment = "고객유형코드")
private String custTypCd;


@FxColumn(name = "MGMT_AREA_CD", size = 7, comment = "관리지역코드")
private String mgmtAreaCd;


@FxColumn(name = "ZIP", size = 6, nullable = true, comment = "우편번호")
private String zip;


@FxColumn(name = "HOUSE_NUM_CL_CD", size = 1, comment = "번지구분코드")
private String houseNumClCd;


@FxColumn(name = "MAIN_HOUSE_NUM_CTT", size = 40, nullable = true, comment = "메인번지내용")
private String mainHouseNumCtt;


@FxColumn(name = "SUB_HOUSE_NUM_CTT", size = 40, nullable = true, comment = "서브번지내용")
private String subHouseNumCtt;


@FxColumn(name = "BLD_CL_CD", size = 2, comment = "건물분류코드")
private String bldClCd;


@FxColumn(name = "BLD_CD", size = 15, nullable = true, comment = "건물코드")
private String bldCd;


@FxColumn(name = "BLDBLK_NUM", size = 15, nullable = true, comment = "건물동번호")
private long bldblkNum;


@FxColumn(name = "BLDUNT_NUM", size = 15, nullable = true, comment = "건물호번호")
private long blduntNum;


@FxColumn(name = "BAS_ADDR", size = 70, nullable = true, comment = "기본주소")
private String basAddr;


@FxColumn(name = "ASSIST_ADDR", size = 100, nullable = true, comment = "보조주소")
private String assistAddr;


@FxColumn(name = "LDONG_CD", size = 10, nullable = true, comment = "법정동코드")
private String ldongCd;


@FxColumn(name = "PHON_NUM", size = 12, nullable = true, comment = "전화번호")
private String phonNum;


@FxColumn(name = "INLINE_NUM", size = 10, nullable = true, comment = "내선번호")
private String inlineNum;


@FxColumn(name = "FAX_NUM", size = 12, nullable = true, comment = "팩스번호")
private String faxNum;


@FxColumn(name = "MBL_PHON_NUM", size = 12, nullable = true, comment = "이동전화번호")
private String mblPhonNum;


@FxColumn(name = "FST_RGST_DTM", size = 14, nullable = true, comment = "최초등록일시")
private String fstRgstDtm;


@FxColumn(name = "EFF_STA_DTM", size = 14, nullable = true, comment = "유효시작일시")
private String effStaDtm;


@FxColumn(name = "OFFC_PHON_NUM", size = 12, nullable = true, comment = "직장전화번호")
private String offcPhonNum;


@FxColumn(name = "EMAIL_ADDR", size = 100, nullable = true, comment = "EMAIL주소")
private String emailAddr;


@FxColumn(name = "SPCL_CUST_YN", size = 1, nullable = true, comment = "특별고객여부")
private String spclCustYn;


/**
* 고객번호
* @return 고객번호
*/
public long getCustNum() {
return custNum;
}
/**
* 고객번호
*@param custNum 고객번호
*/
public void setCustNum(long custNum) {
	this.custNum = custNum;
}
/**
* 최종변경자ID
* @return 최종변경자ID
*/
public String getAuditId() {
return auditId;
}
/**
* 최종변경자ID
*@param auditId 최종변경자ID
*/
public void setAuditId(String auditId) {
	this.auditId = auditId;
}
/**
* 최종변경일시
* @return 최종변경일시
*/
public Timestamp getAuditDtm() {
return auditDtm;
}
/**
* 최종변경일시
*@param auditDtm 최종변경일시
*/
public void setAuditDtm(Timestamp auditDtm) {
	this.auditDtm = auditDtm;
}
/**
* 고객명
* @return 고객명
*/
public String getCustNm() {
return custNm;
}
/**
* 고객명
*@param custNm 고객명
*/
public void setCustNm(String custNm) {
	this.custNm = custNm;
}
/**
* 고객상태코드
* @return 고객상태코드
*/
public String getCustStCd() {
return custStCd;
}
/**
* 고객상태코드
*@param custStCd 고객상태코드
*/
public void setCustStCd(String custStCd) {
	this.custStCd = custStCd;
}
/**
* 고객구분코드
* @return 고객구분코드
*/
public String getCustClCd() {
return custClCd;
}
/**
* 고객구분코드
*@param custClCd 고객구분코드
*/
public void setCustClCd(String custClCd) {
	this.custClCd = custClCd;
}
/**
* 고객유형코드
* @return 고객유형코드
*/
public String getCustTypCd() {
return custTypCd;
}
/**
* 고객유형코드
*@param custTypCd 고객유형코드
*/
public void setCustTypCd(String custTypCd) {
	this.custTypCd = custTypCd;
}
/**
* 관리지역코드
* @return 관리지역코드
*/
public String getMgmtAreaCd() {
return mgmtAreaCd;
}
/**
* 관리지역코드
*@param mgmtAreaCd 관리지역코드
*/
public void setMgmtAreaCd(String mgmtAreaCd) {
	this.mgmtAreaCd = mgmtAreaCd;
}
/**
* 우편번호
* @return 우편번호
*/
public String getZip() {
return zip;
}
/**
* 우편번호
*@param zip 우편번호
*/
public void setZip(String zip) {
	this.zip = zip;
}
/**
* 번지구분코드
* @return 번지구분코드
*/
public String getHouseNumClCd() {
return houseNumClCd;
}
/**
* 번지구분코드
*@param houseNumClCd 번지구분코드
*/
public void setHouseNumClCd(String houseNumClCd) {
	this.houseNumClCd = houseNumClCd;
}
/**
* 메인번지내용
* @return 메인번지내용
*/
public String getMainHouseNumCtt() {
return mainHouseNumCtt;
}
/**
* 메인번지내용
*@param mainHouseNumCtt 메인번지내용
*/
public void setMainHouseNumCtt(String mainHouseNumCtt) {
	this.mainHouseNumCtt = mainHouseNumCtt;
}
/**
* 서브번지내용
* @return 서브번지내용
*/
public String getSubHouseNumCtt() {
return subHouseNumCtt;
}
/**
* 서브번지내용
*@param subHouseNumCtt 서브번지내용
*/
public void setSubHouseNumCtt(String subHouseNumCtt) {
	this.subHouseNumCtt = subHouseNumCtt;
}
/**
* 건물분류코드
* @return 건물분류코드
*/
public String getBldClCd() {
return bldClCd;
}
/**
* 건물분류코드
*@param bldClCd 건물분류코드
*/
public void setBldClCd(String bldClCd) {
	this.bldClCd = bldClCd;
}
/**
* 건물코드
* @return 건물코드
*/
public String getBldCd() {
return bldCd;
}
/**
* 건물코드
*@param bldCd 건물코드
*/
public void setBldCd(String bldCd) {
	this.bldCd = bldCd;
}
/**
* 건물동번호
* @return 건물동번호
*/
public long getBldblkNum() {
return bldblkNum;
}
/**
* 건물동번호
*@param bldblkNum 건물동번호
*/
public void setBldblkNum(long bldblkNum) {
	this.bldblkNum = bldblkNum;
}
/**
* 건물호번호
* @return 건물호번호
*/
public long getBlduntNum() {
return blduntNum;
}
/**
* 건물호번호
*@param blduntNum 건물호번호
*/
public void setBlduntNum(long blduntNum) {
	this.blduntNum = blduntNum;
}
/**
* 기본주소
* @return 기본주소
*/
public String getBasAddr() {
return basAddr;
}
/**
* 기본주소
*@param basAddr 기본주소
*/
public void setBasAddr(String basAddr) {
	this.basAddr = basAddr;
}
/**
* 보조주소
* @return 보조주소
*/
public String getAssistAddr() {
return assistAddr;
}
/**
* 보조주소
*@param assistAddr 보조주소
*/
public void setAssistAddr(String assistAddr) {
	this.assistAddr = assistAddr;
}
/**
* 법정동코드
* @return 법정동코드
*/
public String getLdongCd() {
return ldongCd;
}
/**
* 법정동코드
*@param ldongCd 법정동코드
*/
public void setLdongCd(String ldongCd) {
	this.ldongCd = ldongCd;
}
/**
* 전화번호
* @return 전화번호
*/
public String getPhonNum() {
return phonNum;
}
/**
* 전화번호
*@param phonNum 전화번호
*/
public void setPhonNum(String phonNum) {
	this.phonNum = phonNum;
}
/**
* 내선번호
* @return 내선번호
*/
public String getInlineNum() {
return inlineNum;
}
/**
* 내선번호
*@param inlineNum 내선번호
*/
public void setInlineNum(String inlineNum) {
	this.inlineNum = inlineNum;
}
/**
* 팩스번호
* @return 팩스번호
*/
public String getFaxNum() {
return faxNum;
}
/**
* 팩스번호
*@param faxNum 팩스번호
*/
public void setFaxNum(String faxNum) {
	this.faxNum = faxNum;
}
/**
* 이동전화번호
* @return 이동전화번호
*/
public String getMblPhonNum() {
return mblPhonNum;
}
/**
* 이동전화번호
*@param mblPhonNum 이동전화번호
*/
public void setMblPhonNum(String mblPhonNum) {
	this.mblPhonNum = mblPhonNum;
}
/**
* 최초등록일시
* @return 최초등록일시
*/
public String getFstRgstDtm() {
return fstRgstDtm;
}
/**
* 최초등록일시
*@param fstRgstDtm 최초등록일시
*/
public void setFstRgstDtm(String fstRgstDtm) {
	this.fstRgstDtm = fstRgstDtm;
}
/**
* 유효시작일시
* @return 유효시작일시
*/
public String getEffStaDtm() {
return effStaDtm;
}
/**
* 유효시작일시
*@param effStaDtm 유효시작일시
*/
public void setEffStaDtm(String effStaDtm) {
	this.effStaDtm = effStaDtm;
}
/**
* 직장전화번호
* @return 직장전화번호
*/
public String getOffcPhonNum() {
return offcPhonNum;
}
/**
* 직장전화번호
*@param offcPhonNum 직장전화번호
*/
public void setOffcPhonNum(String offcPhonNum) {
	this.offcPhonNum = offcPhonNum;
}
/**
* EMAIL주소
* @return EMAIL주소
*/
public String getEmailAddr() {
return emailAddr;
}
/**
* EMAIL주소
*@param emailAddr EMAIL주소
*/
public void setEmailAddr(String emailAddr) {
	this.emailAddr = emailAddr;
}
/**
* 특별고객여부
* @return 특별고객여부
*/
public String getSpclCustYn() {
return spclCustYn;
}
/**
* 특별고객여부
*@param spclCustYn 특별고객여부
*/
public void setSpclCustYn(String spclCustYn) {
	this.spclCustYn = spclCustYn;
}
}