package com.skb.adams.cm.model;

import java.io.Serializable;

import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;

import com.skb.adams.cm.dao.CmDao;

/**
 * @since 2017.12.29 16:46
 * @author subkjh autometic create by subkjh.dao
 *
 */

@FxTable(name = "OIV10970", comment = "구성통계생성이력")
public class OIV10970 implements Serializable {

	public OIV10970(String creTblId, String creDtm) {
		this.creTblId = creTblId;
		this.creDtm = creDtm;
		this.creStaDtm = CmDao.getDate(System.currentTimeMillis());
	}
	
	@FxColumn(name = "CRE_TBL_ID", size = 8, comment = "생성테이블ID")
	private String creTblId;

	@FxColumn(name = "CRE_DTM", size = 14, comment = "생성일시")
	private String creDtm;

	@FxColumn(name = "CRE_STA_DTM", size = 14, nullable = true, comment = "생성시작일시")
	private String creStaDtm;

	@FxColumn(name = "CRE_END_DTM", size = 14, nullable = true, comment = "생성종료일시")
	private String creEndDtm;

	@FxColumn(name = "CRE_CNT", size = 15, nullable = true, comment = "생성건수")
	private long creCnt;

	public void addCnt(int cnt) {
		if (cnt > 0) {
			creCnt += cnt;
		}
	}

	/**
	 * 생성테이블ID
	 * 
	 * @return 생성테이블ID
	 */
	public String getCreTblId() {
		return creTblId;
	}

	/**
	 * 생성테이블ID
	 *
	 * @param creTblId
	 *            생성테이블ID
	 */
	public void setCreTblId(String creTblId) {
		this.creTblId = creTblId;
	}

	/**
	 * 생성일시
	 * 
	 * @return 생성일시
	 */
	public String getCreDtm() {
		return creDtm;
	}

	/**
	 * 생성일시
	 *
	 * @param creDtm
	 *            생성일시
	 */
	public void setCreDtm(String creDtm) {
		this.creDtm = creDtm;
	}

	/**
	 * 생성시작일시
	 * 
	 * @return 생성시작일시
	 */
	public String getCreStaDtm() {
		return creStaDtm;
	}

	/**
	 * 생성시작일시
	 *
	 * @param creStaDtm
	 *            생성시작일시
	 */
	public void setCreStaDtm(String creStaDtm) {
		this.creStaDtm = creStaDtm;
	}

	/**
	 * 생성종료일시
	 * 
	 * @return 생성종료일시
	 */
	public String getCreEndDtm() {
		return creEndDtm;
	}

	/**
	 * 생성종료일시
	 *
	 * @param creEndDtm
	 *            생성종료일시
	 */
	public void setCreEndDtm(String creEndDtm) {
		this.creEndDtm = creEndDtm;
	}

	/**
	 * 생성건수
	 * 
	 * @return 생성건수
	 */
	public long getCreCnt() {
		return creCnt;
	}

	/**
	 * 생성건수
	 *
	 * @param creCnt
	 *            생성건수
	 */
	public void setCreCnt(long creCnt) {
		this.creCnt = creCnt;		
		this.creEndDtm = CmDao.getDate(System.currentTimeMillis());

	}
}
