package com.skb.adams.cm.model;


import java.io.Serializable;
import java.sql.Timestamp;

import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;

/**
* @since 2017.11.30 18:06
* @author subkjh 
* autometic create by subkjh.dao 
*
*/


@FxTable(name = "OIV10800", comment = "유선단말기본")
public class OIV10800 implements Serializable {

public OIV10800() {
 }

@FxColumn(name = "WEQP_MGMT_NUM", size = 22, comment = "유선단말관리번호")
private String weqpMgmtNum;


@FxColumn(name = "AUDIT_ID", size = 15, comment = "최종변경자ID")
private String auditId;


@FxColumn(name = "AUDIT_DTM", size = 0, comment = "최종변경일시", defValue = "SYSDATE")
private Timestamp auditDtm;


@FxColumn(name = "WEQP_GRP_CD", size = 4, comment = "유선단말군코드")
private String weqpGrpCd;


@FxColumn(name = "EQP_MDL_CD", size = 10, comment = "단말모델코드")
private String eqpMdlCd;


@FxColumn(name = "MAC_ADDR_VAL", size = 12, nullable = true, comment = "MAC주소값")
private String macAddrVal;


@FxColumn(name = "MFACT_SER_NUM", size = 20, nullable = true, comment = "제조사일련번호")
private String mfactSerNum;


@FxColumn(name = "WEQP_CL_CD", size = 1, comment = "유선단말구분코드")
private String weqpClCd;


@FxColumn(name = "REP_SVC_MGMT_NUM", size = 10, nullable = true, comment = "대표서비스관리번호")
private Number repSvcMgmtNum;


@FxColumn(name = "WEQP_LOC_CL_CD", size = 2, comment = "유선단말위치구분코드")
private String weqpLocClCd;


@FxColumn(name = "WEQP_LOC_ID", size = 10, nullable = true, comment = "유선단말위치ID")
private String weqpLocId;


@FxColumn(name = "DSNET_ORG_ID", size = 10, nullable = true, comment = "유통망조직ID")
private String dsnetOrgId;


@FxColumn(name = "VIP_EQP_YN", size = 1, nullable = true, comment = "VIP단말여부")
private String vipEqpYn;


@FxColumn(name = "VIP_EQP_RGST_RSN_CTT", size = 200, nullable = true, comment = "VIP단말등록사유내용")
private String vipEqpRgstRsnCtt;


@FxColumn(name = "HOME_CNTR_CD", size = 10, nullable = true, comment = "홈센터코드")
private String homeCntrCd;

private String stFluDt;

public String getStFluDt() {
	return stFluDt;
}
public void setStFluDt(String stFluDt) {
	this.stFluDt = stFluDt;
}
/**
* 유선단말관리번호
* @return 유선단말관리번호
*/
public String getWeqpMgmtNum() {
return weqpMgmtNum;
}
/**
* 유선단말관리번호
*@param weqpMgmtNum 유선단말관리번호
*/
public void setWeqpMgmtNum(String weqpMgmtNum) {
	this.weqpMgmtNum = weqpMgmtNum;
}
/**
* 최종변경자ID
* @return 최종변경자ID
*/
public String getAuditId() {
return auditId;
}
/**
* 최종변경자ID
*@param auditId 최종변경자ID
*/
public void setAuditId(String auditId) {
	this.auditId = auditId;
}
/**
* 최종변경일시
* @return 최종변경일시
*/
public Timestamp getAuditDtm() {
return auditDtm;
}
/**
* 최종변경일시
*@param auditDtm 최종변경일시
*/
public void setAuditDtm(Timestamp auditDtm) {
	this.auditDtm = auditDtm;
}
/**
* 유선단말군코드
* @return 유선단말군코드
*/
public String getWeqpGrpCd() {
return weqpGrpCd;
}
/**
* 유선단말군코드
*@param weqpGrpCd 유선단말군코드
*/
public void setWeqpGrpCd(String weqpGrpCd) {
	this.weqpGrpCd = weqpGrpCd;
}
/**
* 단말모델코드
* @return 단말모델코드
*/
public String getEqpMdlCd() {
return eqpMdlCd;
}
/**
* 단말모델코드
*@param eqpMdlCd 단말모델코드
*/
public void setEqpMdlCd(String eqpMdlCd) {
	this.eqpMdlCd = eqpMdlCd;
}
/**
* MAC주소값
* @return MAC주소값
*/
public String getMacAddrVal() {
return macAddrVal;
}
/**
* MAC주소값
*@param macAddrVal MAC주소값
*/
public void setMacAddrVal(String macAddrVal) {
	this.macAddrVal = macAddrVal;
}
/**
* 제조사일련번호
* @return 제조사일련번호
*/
public String getMfactSerNum() {
return mfactSerNum;
}
/**
* 제조사일련번호
*@param mfactSerNum 제조사일련번호
*/
public void setMfactSerNum(String mfactSerNum) {
	this.mfactSerNum = mfactSerNum;
}
/**
* 유선단말구분코드
* @return 유선단말구분코드
*/
public String getWeqpClCd() {
return weqpClCd;
}
/**
* 유선단말구분코드
*@param weqpClCd 유선단말구분코드
*/
public void setWeqpClCd(String weqpClCd) {
	this.weqpClCd = weqpClCd;
}
/**
* 대표서비스관리번호
* @return 대표서비스관리번호
*/
public Number getRepSvcMgmtNum() {
return repSvcMgmtNum;
}
/**
* 대표서비스관리번호
*@param repSvcMgmtNum 대표서비스관리번호
*/
public void setRepSvcMgmtNum(Number repSvcMgmtNum) {
	this.repSvcMgmtNum = repSvcMgmtNum;
}
/**
* 유선단말위치구분코드
* @return 유선단말위치구분코드
*/
public String getWeqpLocClCd() {
return weqpLocClCd;
}
/**
* 유선단말위치구분코드
*@param weqpLocClCd 유선단말위치구분코드
*/
public void setWeqpLocClCd(String weqpLocClCd) {
	this.weqpLocClCd = weqpLocClCd;
}
/**
* 유선단말위치ID
* @return 유선단말위치ID
*/
public String getWeqpLocId() {
return weqpLocId;
}
/**
* 유선단말위치ID
*@param weqpLocId 유선단말위치ID
*/
public void setWeqpLocId(String weqpLocId) {
	this.weqpLocId = weqpLocId;
}
/**
* 유통망조직ID
* @return 유통망조직ID
*/
public String getDsnetOrgId() {
return dsnetOrgId;
}
/**
* 유통망조직ID
*@param dsnetOrgId 유통망조직ID
*/
public void setDsnetOrgId(String dsnetOrgId) {
	this.dsnetOrgId = dsnetOrgId;
}
/**
* VIP단말여부
* @return VIP단말여부
*/
public String isVipEqpYn() {
return vipEqpYn;
}
/**
* VIP단말여부
*@param vipEqpYn VIP단말여부
*/
public void setVipEqpYn(String vipEqpYn) {
	this.vipEqpYn = vipEqpYn;
}
/**
* VIP단말등록사유내용
* @return VIP단말등록사유내용
*/
public String getVipEqpRgstRsnCtt() {
return vipEqpRgstRsnCtt;
}
/**
* VIP단말등록사유내용
*@param vipEqpRgstRsnCtt VIP단말등록사유내용
*/
public void setVipEqpRgstRsnCtt(String vipEqpRgstRsnCtt) {
	this.vipEqpRgstRsnCtt = vipEqpRgstRsnCtt;
}
/**
* 홈센터코드
* @return 홈센터코드
*/
public String getHomeCntrCd() {
return homeCntrCd;
}
/**
* 홈센터코드
*@param homeCntrCd 홈센터코드
*/
public void setHomeCntrCd(String homeCntrCd) {
	this.homeCntrCd = homeCntrCd;
}
}
