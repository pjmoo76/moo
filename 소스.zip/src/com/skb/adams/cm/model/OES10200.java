package com.skb.adams.cm.model;

import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;

import java.io.Serializable;
import java.sql.Timestamp;

/**
* @since 2018.09.21 14:11
* @author subkjh 
* autometic create by subkjh.dao 
*
*/


@FxTable(name = "OES10200", comment = "서비스기본")
public class OES10200 implements Serializable {

/**
	 * 
	 */
	private static final long serialVersionUID = -5526231296979989376L;


public OES10200() {
 }

@FxColumn(name = "SVC_MGMT_NUM", size = 10, comment = "서비스관리번호")
private long svcMgmtNum;


@FxColumn(name = "AUDIT_ID", size = 15, comment = "최종변경자ID")
private String auditId;


@FxColumn(name = "AUDIT_DTM", size = 0, comment = "최종변경일시")
private Timestamp auditDtm;


@FxColumn(name = "SVC_CD", size = 1, comment = "서비스코드")
private String svcCd;


@FxColumn(name = "CNTRCT_MGMT_NUM", size = 15, nullable = true, comment = "계약관리번호")
private String cntrctMgmtNum;


@FxColumn(name = "SVC_NUM", size = 20, nullable = true, comment = "서비스번호")
private String svcNum;


@FxColumn(name = "SVC_ST_CD", size = 2, comment = "서비스상태코드")
private String svcStCd;


@FxColumn(name = "SVC_ST_CHG_CD", size = 2, comment = "서비스상태변경코드")
private String svcStChgCd;


@FxColumn(name = "SVC_CHG_RSN_CD", size = 2, comment = "서비스변경사유코드")
private String svcChgRsnCd;


@FxColumn(name = "SVC_USE_TYP_CD", size = 2, comment = "서비스이용종류코드")
private String svcUseTypCd;


@FxColumn(name = "SVC_SCRB_DT", size = 8, nullable = true, comment = "서비스가입일자")
private String svcScrbDt;


@FxColumn(name = "SVC_TERM_DT", size = 8, nullable = true, comment = "서비스해지일자")
private String svcTermDt;


@FxColumn(name = "FEE_PROD_ID", size = 10, nullable = true, comment = "요금상품ID")
private String feeProdId;


@FxColumn(name = "CO_CL_CD", size = 1, comment = "회사구분코드")
private String coClCd;


@FxColumn(name = "SVC_DTL_CL_CD", size = 2, comment = "서비스상세구분코드")
private String svcDtlClCd;


@FxColumn(name = "TERM_DTL_RSN_CD", size = 2, comment = "해지상세사유코드")
private String termDtlRsnCd;


@FxColumn(name = "MASS_CO_CL_CD", size = 1, comment = "매스기업구분코드")
private String massCoClCd;


/**
* 서비스관리번호
* @return 서비스관리번호
*/
public long getSvcMgmtNum() {
return svcMgmtNum;
}
/**
* 서비스관리번호
*@param svcMgmtNum 서비스관리번호
*/
public void setSvcMgmtNum(long svcMgmtNum) {
	this.svcMgmtNum = svcMgmtNum;
}
/**
* 최종변경자ID
* @return 최종변경자ID
*/
public String getAuditId() {
return auditId;
}
/**
* 최종변경자ID
*@param auditId 최종변경자ID
*/
public void setAuditId(String auditId) {
	this.auditId = auditId;
}
/**
* 최종변경일시
* @return 최종변경일시
*/
public Timestamp getAuditDtm() {
return auditDtm;
}
/**
* 최종변경일시
*@param auditDtm 최종변경일시
*/
public void setAuditDtm(Timestamp auditDtm) {
	this.auditDtm = auditDtm;
}
/**
* 서비스코드
* @return 서비스코드
*/
public String getSvcCd() {
return svcCd;
}
/**
* 서비스코드
*@param svcCd 서비스코드
*/
public void setSvcCd(String svcCd) {
	this.svcCd = svcCd;
}
/**
* 계약관리번호
* @return 계약관리번호
*/
public String getCntrctMgmtNum() {
return cntrctMgmtNum;
}
/**
* 계약관리번호
*@param cntrctMgmtNum 계약관리번호
*/
public void setCntrctMgmtNum(String cntrctMgmtNum) {
	this.cntrctMgmtNum = cntrctMgmtNum;
}
/**
* 서비스번호
* @return 서비스번호
*/
public String getSvcNum() {
return svcNum;
}
/**
* 서비스번호
*@param svcNum 서비스번호
*/
public void setSvcNum(String svcNum) {
	this.svcNum = svcNum;
}
/**
* 서비스상태코드
* @return 서비스상태코드
*/
public String getSvcStCd() {
return svcStCd;
}
/**
* 서비스상태코드
*@param svcStCd 서비스상태코드
*/
public void setSvcStCd(String svcStCd) {
	this.svcStCd = svcStCd;
}
/**
* 서비스상태변경코드
* @return 서비스상태변경코드
*/
public String getSvcStChgCd() {
return svcStChgCd;
}
/**
* 서비스상태변경코드
*@param svcStChgCd 서비스상태변경코드
*/
public void setSvcStChgCd(String svcStChgCd) {
	this.svcStChgCd = svcStChgCd;
}
/**
* 서비스변경사유코드
* @return 서비스변경사유코드
*/
public String getSvcChgRsnCd() {
return svcChgRsnCd;
}
/**
* 서비스변경사유코드
*@param svcChgRsnCd 서비스변경사유코드
*/
public void setSvcChgRsnCd(String svcChgRsnCd) {
	this.svcChgRsnCd = svcChgRsnCd;
}
/**
* 서비스이용종류코드
* @return 서비스이용종류코드
*/
public String getSvcUseTypCd() {
return svcUseTypCd;
}
/**
* 서비스이용종류코드
*@param svcUseTypCd 서비스이용종류코드
*/
public void setSvcUseTypCd(String svcUseTypCd) {
	this.svcUseTypCd = svcUseTypCd;
}
/**
* 서비스가입일자
* @return 서비스가입일자
*/
public String getSvcScrbDt() {
return svcScrbDt;
}
/**
* 서비스가입일자
*@param svcScrbDt 서비스가입일자
*/
public void setSvcScrbDt(String svcScrbDt) {
	this.svcScrbDt = svcScrbDt;
}
/**
* 서비스해지일자
* @return 서비스해지일자
*/
public String getSvcTermDt() {
return svcTermDt;
}
/**
* 서비스해지일자
*@param svcTermDt 서비스해지일자
*/
public void setSvcTermDt(String svcTermDt) {
	this.svcTermDt = svcTermDt;
}
/**
* 요금상품ID
* @return 요금상품ID
*/
public String getFeeProdId() {
return feeProdId;
}
/**
* 요금상품ID
*@param feeProdId 요금상품ID
*/
public void setFeeProdId(String feeProdId) {
	this.feeProdId = feeProdId;
}
/**
* 회사구분코드
* @return 회사구분코드
*/
public String getCoClCd() {
return coClCd;
}
/**
* 회사구분코드
*@param coClCd 회사구분코드
*/
public void setCoClCd(String coClCd) {
	this.coClCd = coClCd;
}
/**
* 서비스상세구분코드
* @return 서비스상세구분코드
*/
public String getSvcDtlClCd() {
return svcDtlClCd;
}
/**
* 서비스상세구분코드
*@param svcDtlClCd 서비스상세구분코드
*/
public void setSvcDtlClCd(String svcDtlClCd) {
	this.svcDtlClCd = svcDtlClCd;
}
/**
* 해지상세사유코드
* @return 해지상세사유코드
*/
public String getTermDtlRsnCd() {
return termDtlRsnCd;
}
/**
* 해지상세사유코드
*@param termDtlRsnCd 해지상세사유코드
*/
public void setTermDtlRsnCd(String termDtlRsnCd) {
	this.termDtlRsnCd = termDtlRsnCd;
}
/**
* 매스기업구분코드
* @return 매스기업구분코드
*/
public String getMassCoClCd() {
return massCoClCd;
}
/**
* 매스기업구분코드
*@param massCoClCd 매스기업구분코드
*/
public void setMassCoClCd(String massCoClCd) {
	this.massCoClCd = massCoClCd;
}
}
