package com.skb.adams.cm.model;


import java.io.Serializable;
import java.sql.Timestamp;

import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;

/**
* @since 2017.12.10 13:53
* @author subkjh 
* autometic create by subkjh.dao 
*
*/


@FxTable(name = "OIV10170", comment = "커버리지셀기본")
public class OIV10170 implements Serializable {
	
	private boolean isNew = true;

public boolean isNew() {
		return isNew;
	}
	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}
public OIV10170() {
 }

@FxColumn(name = "CCELL_ID", size = 14, comment = "커버리지셀ID")
private String ccellId;


@FxColumn(name = "AUDIT_ID", size = 15, comment = "최종변경자ID")
private String auditId;


@FxColumn(name = "AUDIT_DTM", size = 0, comment = "최종변경일시", defValue = "SYSDATE")
private Timestamp auditDtm;


@FxColumn(name = "EQUIP_ID", size = 12, nullable = true, comment = "장비ID")
private String equipId;


@FxColumn(name = "CCELL_NUM", size = 50, nullable = true, comment = "커버리지셀번호")
private String ccellNum;


@FxColumn(name = "OPER_TPO_CD", size = 6, comment = "운영국사코드")
private String operTpoCd;


/**
* 커버리지셀ID
* @return 커버리지셀ID
*/
public String getCcellId() {
return ccellId;
}
/**
* 커버리지셀ID
*@param ccellId 커버리지셀ID
*/
public void setCcellId(String ccellId) {
	this.ccellId = ccellId;
}
/**
* 최종변경자ID
* @return 최종변경자ID
*/
public String getAuditId() {
return auditId;
}
/**
* 최종변경자ID
*@param auditId 최종변경자ID
*/
public void setAuditId(String auditId) {
	this.auditId = auditId;
}
/**
* 최종변경일시
* @return 최종변경일시
*/
public Timestamp getAuditDtm() {
return auditDtm;
}
/**
* 최종변경일시
*@param auditDtm 최종변경일시
*/
public void setAuditDtm(Timestamp auditDtm) {
	this.auditDtm = auditDtm;
}
/**
* 장비ID
* @return 장비ID
*/
public String getEquipId() {
return equipId;
}
/**
* 장비ID
*@param equipId 장비ID
*/
public void setEquipId(String equipId) {
	this.equipId = equipId;
}
/**
* 커버리지셀번호
* @return 커버리지셀번호
*/
public String getCcellNum() {
return ccellNum;
}
/**
* 커버리지셀번호
*@param ccellNum 커버리지셀번호
*/
public void setCcellNum(String ccellNum) {
	this.ccellNum = ccellNum;
}
/**
* 운영국사코드
* @return 운영국사코드
*/
public String getOperTpoCd() {
return operTpoCd;
}
/**
* 운영국사코드
*@param operTpoCd 운영국사코드
*/
public void setOperTpoCd(String operTpoCd) {
	this.operTpoCd = operTpoCd;
}
}
