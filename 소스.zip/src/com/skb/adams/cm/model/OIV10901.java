package com.skb.adams.cm.model;


import java.io.Serializable;
import java.sql.Timestamp;

import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;

/**
* @since 2017.12.19 13:18
* @author subkjh 
* autometic create by subkjh.dao 
*
*/


@FxTable(name = "OIV10901", comment = "장비속성목록")
public class OIV10901 implements Serializable {

public OIV10901() {
 }

@FxColumn(name = "EQUIP_ATTR_CD", size = 3, comment = "장비속성코드")
private String equipAttrCd;


@FxColumn(name = "AUDIT_ID", size = 15, comment = "최종변경자ID")
private String auditId;


@FxColumn(name = "AUDIT_DTM", size = 0, comment = "최종변경일시")
private Timestamp auditDtm;


@FxColumn(name = "COL_NM", size = 40, nullable = true, comment = "컬럼명")
private String colNm;


@FxColumn(name = "ATTR_NM", size = 100, nullable = true, comment = "속성명")
private String attrNm;


@FxColumn(name = "TBL_NM", size = 40, nullable = true, comment = "테이블명")
private String tblNm;


@FxColumn(name = "ATTR_GRP_NM", size = 60, nullable = true, comment = "속성그룹명")
private String attrGrpNm;


/**
* 장비속성코드
* @return 장비속성코드
*/
public String getEquipAttrCd() {
return equipAttrCd;
}
/**
* 장비속성코드
*@param equipAttrCd 장비속성코드
*/
public void setEquipAttrCd(String equipAttrCd) {
	this.equipAttrCd = equipAttrCd;
}
/**
* 최종변경자ID
* @return 최종변경자ID
*/
public String getAuditId() {
return auditId;
}
/**
* 최종변경자ID
*@param auditId 최종변경자ID
*/
public void setAuditId(String auditId) {
	this.auditId = auditId;
}
/**
* 최종변경일시
* @return 최종변경일시
*/
public Timestamp getAuditDtm() {
return auditDtm;
}
/**
* 최종변경일시
*@param auditDtm 최종변경일시
*/
public void setAuditDtm(Timestamp auditDtm) {
	this.auditDtm = auditDtm;
}
/**
* 컬럼명
* @return 컬럼명
*/
public String getColNm() {
return colNm;
}
/**
* 컬럼명
*@param colNm 컬럼명
*/
public void setColNm(String colNm) {
	this.colNm = colNm;
}
/**
* 속성명
* @return 속성명
*/
public String getAttrNm() {
return attrNm;
}
/**
* 속성명
*@param attrNm 속성명
*/
public void setAttrNm(String attrNm) {
	this.attrNm = attrNm;
}
/**
* 테이블명
* @return 테이블명
*/
public String getTblNm() {
return tblNm;
}
/**
* 테이블명
*@param tblNm 테이블명
*/
public void setTblNm(String tblNm) {
	this.tblNm = tblNm;
}
/**
* 속성그룹명
* @return 속성그룹명
*/
public String getAttrGrpNm() {
return attrGrpNm;
}
/**
* 속성그룹명
*@param attrGrpNm 속성그룹명
*/
public void setAttrGrpNm(String attrGrpNm) {
	this.attrGrpNm = attrGrpNm;
}
}
