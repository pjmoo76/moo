package com.skb.adams.cm.model;

public class ParaVO {

	private String paraName;

	private String paraCode;

	public String getParaCode() {
		return paraCode;
	}

	public String getParaName() {
		return paraName;
	}

	public void setParaCode(String paraCode) {
		this.paraCode = paraCode;
	}

	public void setParaName(String paraName) {
		this.paraName = paraName;
	}


}
