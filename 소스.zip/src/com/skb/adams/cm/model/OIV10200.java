package com.skb.adams.cm.model;

import java.io.Serializable;
import java.sql.Timestamp;

import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;

/**
 * @since 2017.12.19 14:33
 * @author subkjh autometic create by subkjh.dao
 *
 */

@FxTable(name = "OIV10200", comment = "장비모델기본")
public class OIV10200 implements Serializable {

	public OIV10200() {
	}

	@FxColumn(name = "EQUIP_MDL_CD", size = 10, comment = "장비모델코드")
	private String equipMdlCd;

	@FxColumn(name = "AUDIT_ID", size = 15, comment = "최종변경자ID")
	private String auditId;

	@FxColumn(name = "AUDIT_DTM", size = 0, comment = "최종변경일시")
	private Timestamp auditDtm;

	@FxColumn(name = "EQUIP_MFACT_CD", size = 3, comment = "장비제조사코드")
	private String equipMfactCd;

	@FxColumn(name = "EQUIP_MDL_NM", size = 300, nullable = true, comment = "장비모델명")
	private String equipMdlNm;

	@FxColumn(name = "EQUIP_MDL_TYP_CD", size = 3, comment = "장비모델종류코드")
	private String equipMdlTypCd;

	@FxColumn(name = "EQUIP_TYP_CD", size = 4, comment = "장비종류코드")
	private String equipTypCd;

	@FxColumn(name = "EQUIP_MDL_DESC", size = 500, nullable = true, comment = "장비모델설명")
	private String equipMdlDesc;

	@FxColumn(name = "EQUIP_INTDC_YM", size = 6, nullable = true, comment = "장비도입년월")
	private String equipIntdcYm;

	@FxColumn(name = "CONS_ITM_MANL_RGST_YN", size = 1, comment = "구성품수동등록여부")
	private boolean consItmManlRgstYn;

	@FxColumn(name = "SAME_CONN_ID_USE_YN", size = 1, comment = "동일접속ID사용여부")
	private boolean sameConnIdUseYn;

	/**
	 * 장비모델코드
	 * 
	 * @return 장비모델코드
	 */
	public String getEquipMdlCd() {
		return equipMdlCd;
	}

	/**
	 * 장비모델코드
	 *
	 * @param equipMdlCd
	 *            장비모델코드
	 */
	public void setEquipMdlCd(String equipMdlCd) {
		this.equipMdlCd = equipMdlCd;
	}

	/**
	 * 최종변경자ID
	 * 
	 * @return 최종변경자ID
	 */
	public String getAuditId() {
		return auditId;
	}

	/**
	 * 최종변경자ID
	 *
	 * @param auditId
	 *            최종변경자ID
	 */
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	/**
	 * 최종변경일시
	 * 
	 * @return 최종변경일시
	 */
	public Timestamp getAuditDtm() {
		return auditDtm;
	}

	/**
	 * 최종변경일시
	 *
	 * @param auditDtm
	 *            최종변경일시
	 */
	public void setAuditDtm(Timestamp auditDtm) {
		this.auditDtm = auditDtm;
	}

	/**
	 * 장비제조사코드
	 * 
	 * @return 장비제조사코드
	 */
	public String getEquipMfactCd() {
		return equipMfactCd;
	}

	/**
	 * 장비제조사코드
	 *
	 * @param equipMfactCd
	 *            장비제조사코드
	 */
	public void setEquipMfactCd(String equipMfactCd) {
		this.equipMfactCd = equipMfactCd;
	}

	/**
	 * 장비모델명
	 * 
	 * @return 장비모델명
	 */
	public String getEquipMdlNm() {
		return equipMdlNm;
	}

	/**
	 * 장비모델명
	 *
	 * @param equipMdlNm
	 *            장비모델명
	 */
	public void setEquipMdlNm(String equipMdlNm) {
		this.equipMdlNm = equipMdlNm;
	}

	/**
	 * 장비모델종류코드
	 * 
	 * @return 장비모델종류코드
	 */
	public String getEquipMdlTypCd() {
		return equipMdlTypCd;
	}

	/**
	 * 장비모델종류코드
	 *
	 * @param equipMdlTypCd
	 *            장비모델종류코드
	 */
	public void setEquipMdlTypCd(String equipMdlTypCd) {
		this.equipMdlTypCd = equipMdlTypCd;
	}

	/**
	 * 장비종류코드
	 * 
	 * @return 장비종류코드
	 */
	public String getEquipTypCd() {
		return equipTypCd;
	}

	/**
	 * 장비종류코드
	 *
	 * @param equipTypCd
	 *            장비종류코드
	 */
	public void setEquipTypCd(String equipTypCd) {
		this.equipTypCd = equipTypCd;
	}

	/**
	 * 장비모델설명
	 * 
	 * @return 장비모델설명
	 */
	public String getEquipMdlDesc() {
		return equipMdlDesc;
	}

	/**
	 * 장비모델설명
	 *
	 * @param equipMdlDesc
	 *            장비모델설명
	 */
	public void setEquipMdlDesc(String equipMdlDesc) {
		this.equipMdlDesc = equipMdlDesc;
	}

	/**
	 * 장비도입년월
	 * 
	 * @return 장비도입년월
	 */
	public String getEquipIntdcYm() {
		return equipIntdcYm;
	}

	/**
	 * 장비도입년월
	 *
	 * @param equipIntdcYm
	 *            장비도입년월
	 */
	public void setEquipIntdcYm(String equipIntdcYm) {
		this.equipIntdcYm = equipIntdcYm;
	}

	/**
	 * 구성품수동등록여부
	 * 
	 * @return 구성품수동등록여부
	 */
	public boolean isConsItmManlRgstYn() {
		return consItmManlRgstYn;
	}

	/**
	 * 구성품수동등록여부
	 *
	 * @param consItmManlRgstYn
	 *            구성품수동등록여부
	 */
	public void setConsItmManlRgstYn(boolean consItmManlRgstYn) {
		this.consItmManlRgstYn = consItmManlRgstYn;
	}

	/**
	 * 동일접속ID사용여부
	 * 
	 * @return 동일접속ID사용여부
	 */
	public boolean isSameConnIdUseYn() {
		return sameConnIdUseYn;
	}

	/**
	 * 동일접속ID사용여부
	 *
	 * @param sameConnIdUseYn
	 *            동일접속ID사용여부
	 */
	public void setSameConnIdUseYn(boolean sameConnIdUseYn) {
		this.sameConnIdUseYn = sameConnIdUseYn;
	}
}
