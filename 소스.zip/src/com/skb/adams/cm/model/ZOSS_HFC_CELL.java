package com.skb.adams.cm.model;

import java.io.Serializable;
import java.sql.Timestamp;

import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;

/**
 * @since 2017.12.10 13:49
 * @author subkjh autometic create by subkjh.dao
 *
 */

@FxTable(name = "ZOSS_HFC_CELL", comment = "ZOSS_HFC_CELL")
public class ZOSS_HFC_CELL implements Serializable {

	public ZOSS_HFC_CELL() {
	}

	@FxColumn(name = "AUDIT_DTM", size = 0, comment = "AUDIT_DTM")
	private Timestamp auditDtm;

	@FxColumn(name = "AUDIT_ID", size = 15, comment = "AUDIT_ID")
	private String auditId;

	@FxColumn(name = "CCELL_ID", size = 14, nullable = true, comment = "CCELL_ID")
	private String ccellId;

	@FxColumn(name = "CCELL_NUM", size = 30, comment = "CCELL_NUM")
	private String ccellNum;

	@FxColumn(name = "CMTS_SET_TPO_CD", size = 6, comment = "CMTS_SET_TPO_CD")
	private String cmtsSetTpoCd;

	@FxColumn(name = "EQUIP_MGMT_NUM", size = 8, comment = "EQUIP_MGMT_NUM")
	private String equipMgmtNum;

	@FxColumn(name = "MEMO", size = 2000, nullable = true, comment = "MEMO")
	private String memo;

	@FxColumn(name = "OTX_NUM", size = 15, nullable = true, comment = "OTX_NUM")
	private String otxNum;

	@FxColumn(name = "REF_INFO", size = 50, nullable = true, comment = "REF_INFO")
	private String refInfo;

	@FxColumn(name = "REP_SLOT_YN", size = 1, nullable = true, comment = "REP_SLOT_YN")
	private boolean repSlotYn;

	@FxColumn(name = "SLOT_PORT_GRP_NUM", size = 8, nullable = true, comment = "SLOT_PORT_GRP_NUM")
	private String slotPortGrpNum;

	@FxColumn(name = "SLOT_REF_INFO", size = 14, comment = "SLOT_REF_INFO")
	private String slotRefInfo;

	/**
	 * AUDIT_DTM
	 * 
	 * @return AUDIT_DTM
	 */
	public Timestamp getAuditDtm() {
		return auditDtm;
	}

	/**
	 * AUDIT_DTM
	 *
	 * @param auditDtm
	 *            AUDIT_DTM
	 */
	public void setAuditDtm(Timestamp auditDtm) {
		this.auditDtm = auditDtm;
	}

	/**
	 * AUDIT_ID
	 * 
	 * @return AUDIT_ID
	 */
	public String getAuditId() {
		return auditId;
	}

	/**
	 * AUDIT_ID
	 *
	 * @param auditId
	 *            AUDIT_ID
	 */
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	/**
	 * CCELL_ID
	 * 
	 * @return CCELL_ID
	 */
	public String getCcellId() {
		return ccellId;
	}

	/**
	 * CCELL_ID
	 *
	 * @param ccellId
	 *            CCELL_ID
	 */
	public void setCcellId(String ccellId) {
		this.ccellId = ccellId;
	}

	/**
	 * CCELL_NUM
	 * 
	 * @return CCELL_NUM
	 */
	public String getCcellNum() {
		return ccellNum;
	}

	/**
	 * CCELL_NUM
	 *
	 * @param ccellNum
	 *            CCELL_NUM
	 */
	public void setCcellNum(String ccellNum) {
		this.ccellNum = ccellNum;
	}

	/**
	 * CMTS_SET_TPO_CD
	 * 
	 * @return CMTS_SET_TPO_CD
	 */
	public String getCmtsSetTpoCd() {
		return cmtsSetTpoCd;
	}

	/**
	 * CMTS_SET_TPO_CD
	 *
	 * @param cmtsSetTpoCd
	 *            CMTS_SET_TPO_CD
	 */
	public void setCmtsSetTpoCd(String cmtsSetTpoCd) {
		this.cmtsSetTpoCd = cmtsSetTpoCd;
	}

	/**
	 * EQUIP_MGMT_NUM
	 * 
	 * @return EQUIP_MGMT_NUM
	 */
	public String getEquipMgmtNum() {
		return equipMgmtNum;
	}

	/**
	 * EQUIP_MGMT_NUM
	 *
	 * @param equipMgmtNum
	 *            EQUIP_MGMT_NUM
	 */
	public void setEquipMgmtNum(String equipMgmtNum) {
		this.equipMgmtNum = equipMgmtNum;
	}

	/**
	 * MEMO
	 * 
	 * @return MEMO
	 */
	public String getMemo() {
		return memo;
	}

	/**
	 * MEMO
	 *
	 * @param memo
	 *            MEMO
	 */
	public void setMemo(String memo) {
		this.memo = memo;
	}

	/**
	 * OTX_NUM
	 * 
	 * @return OTX_NUM
	 */
	public String getOtxNum() {
		return otxNum;
	}

	/**
	 * OTX_NUM
	 *
	 * @param otxNum
	 *            OTX_NUM
	 */
	public void setOtxNum(String otxNum) {
		this.otxNum = otxNum;
	}

	/**
	 * REF_INFO
	 * 
	 * @return REF_INFO
	 */
	public String getRefInfo() {
		return refInfo;
	}

	/**
	 * REF_INFO
	 *
	 * @param refInfo
	 *            REF_INFO
	 */
	public void setRefInfo(String refInfo) {
		this.refInfo = refInfo;
	}

	/**
	 * REP_SLOT_YN
	 * 
	 * @return REP_SLOT_YN
	 */
	public boolean isRepSlotYn() {
		return repSlotYn;
	}

	/**
	 * REP_SLOT_YN
	 *
	 * @param repSlotYn
	 *            REP_SLOT_YN
	 */
	public void setRepSlotYn(boolean repSlotYn) {
		this.repSlotYn = repSlotYn;
	}

	/**
	 * SLOT_PORT_GRP_NUM
	 * 
	 * @return SLOT_PORT_GRP_NUM
	 */
	public String getSlotPortGrpNum() {
		return slotPortGrpNum;
	}

	/**
	 * SLOT_PORT_GRP_NUM
	 *
	 * @param slotPortGrpNum
	 *            SLOT_PORT_GRP_NUM
	 */
	public void setSlotPortGrpNum(String slotPortGrpNum) {
		this.slotPortGrpNum = slotPortGrpNum;
	}

	/**
	 * SLOT_REF_INFO
	 * 
	 * @return SLOT_REF_INFO
	 */
	public String getSlotRefInfo() {
		return slotRefInfo;
	}

	/**
	 * SLOT_REF_INFO
	 *
	 * @param slotRefInfo
	 *            SLOT_REF_INFO
	 */
	public void setSlotRefInfo(String slotRefInfo) {
		this.slotRefInfo = slotRefInfo;
	}
}
