package com.skb.adams.cm.model;

import java.io.Serializable;

import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;

/**
 * @since 2017.12.26 19:11
 * @author subkjh autometic create by subkjh.dao
 *
 */

@FxTable(name = "OIV10803", comment = "리모콘관리내역")
public class OIV10803 implements Serializable {

	public OIV10803() {
	}

	@FxColumn(name = "MAC_ADDR_VAL", size = 15, comment = "MAC주소값")
	private String macAddrVal;

	@FxColumn(name = "VER_INFO", size = 150, comment = "버전정보")
	private String verInfo;

	@FxColumn(name = "TPO_CD", size = 6, nullable = true, comment = "국사코드")
	private String tpoCd;

	@FxColumn(name = "IPTV_SVC_MGMT_NUM", size = 10, nullable = true, comment = "IPTV서비스관리번호")
	private long iptvSvcMgmtNum;

	@FxColumn(name = "HOME_CNTR_CD", size = 10, nullable = true, comment = "홈센터코드")
	private String homeCntrCd;

	@FxColumn(name = "STB_MAC_ADDR_VAL", size = 15, nullable = true, comment = "STBMAC주소값")
	private String stbMacAddrVal;

	@FxColumn(name = "STB_MDL_NM", size = 40, nullable = true, comment = "STB모델명")
	private String stbMdlNm;

	@FxColumn(name = "STB_VER_INFO", size = 100, nullable = true, comment = "STB버전정보")
	private String stbVerInfo;

	@FxColumn(name = "EQP_MDL_CD", size = 10, nullable = true, comment = "단말모델코드")
	private String eqpMdlCd;

	@FxColumn(name = "ETC_CTT", size = 2000, nullable = true, comment = "기타내용")
	private String etcCtt;

	@FxColumn(name = "FW_VER_NUM", size = 150, nullable = true, comment = "펌웨어버전번호")
	private String fwVerNum;

	@FxColumn(name = "MFACT_NM", size = 30, nullable = true, comment = "제조사명")
	private String mfactNm;

	@FxColumn(name = "RGST_DTM", size = 14, nullable = true, comment = "등록일시")
	private String rgstDtm;

	@FxColumn(name = "TEAM_ORG_ID", size = 10, nullable = true, comment = "팀조직ID")
	private String teamOrgId;

	/**
	 * MAC주소값
	 * 
	 * @return MAC주소값
	 */
	public String getMacAddrVal() {
		return macAddrVal;
	}

	/**
	 * MAC주소값
	 *
	 * @param macAddrVal
	 *            MAC주소값
	 */
	public void setMacAddrVal(String macAddrVal) {
		this.macAddrVal = macAddrVal;
	}

	/**
	 * 버전정보
	 * 
	 * @return 버전정보
	 */
	public String getVerInfo() {
		return verInfo;
	}

	/**
	 * 버전정보
	 *
	 * @param verInfo
	 *            버전정보
	 */
	public void setVerInfo(String verInfo) {
		this.verInfo = verInfo;
	}

	/**
	 * 국사코드
	 * 
	 * @return 국사코드
	 */
	public String getTpoCd() {
		return tpoCd;
	}

	/**
	 * 국사코드
	 *
	 * @param tpoCd
	 *            국사코드
	 */
	public void setTpoCd(String tpoCd) {
		this.tpoCd = tpoCd;
	}

	/**
	 * IPTV서비스관리번호
	 * 
	 * @return IPTV서비스관리번호
	 */
	public long getIptvSvcMgmtNum() {
		return iptvSvcMgmtNum;
	}

	/**
	 * IPTV서비스관리번호
	 *
	 * @param iptvSvcMgmtNum
	 *            IPTV서비스관리번호
	 */
	public void setIptvSvcMgmtNum(long iptvSvcMgmtNum) {
		this.iptvSvcMgmtNum = iptvSvcMgmtNum;
	}

	/**
	 * 홈센터코드
	 * 
	 * @return 홈센터코드
	 */
	public String getHomeCntrCd() {
		return homeCntrCd;
	}

	/**
	 * 홈센터코드
	 *
	 * @param homeCntrCd
	 *            홈센터코드
	 */
	public void setHomeCntrCd(String homeCntrCd) {
		this.homeCntrCd = homeCntrCd;
	}

	/**
	 * STBMAC주소값
	 * 
	 * @return STBMAC주소값
	 */
	public String getStbMacAddrVal() {
		return stbMacAddrVal;
	}

	/**
	 * STBMAC주소값
	 *
	 * @param stbMacAddrVal
	 *            STBMAC주소값
	 */
	public void setStbMacAddrVal(String stbMacAddrVal) {
		this.stbMacAddrVal = stbMacAddrVal;
	}

	/**
	 * STB모델명
	 * 
	 * @return STB모델명
	 */
	public String getStbMdlNm() {
		return stbMdlNm;
	}

	/**
	 * STB모델명
	 *
	 * @param stbMdlNm
	 *            STB모델명
	 */
	public void setStbMdlNm(String stbMdlNm) {
		this.stbMdlNm = stbMdlNm;
	}

	/**
	 * STB버전정보
	 * 
	 * @return STB버전정보
	 */
	public String getStbVerInfo() {
		return stbVerInfo;
	}

	/**
	 * STB버전정보
	 *
	 * @param stbVerInfo
	 *            STB버전정보
	 */
	public void setStbVerInfo(String stbVerInfo) {
		this.stbVerInfo = stbVerInfo;
	}

	/**
	 * 단말모델코드
	 * 
	 * @return 단말모델코드
	 */
	public String getEqpMdlCd() {
		return eqpMdlCd;
	}

	/**
	 * 단말모델코드
	 *
	 * @param eqpMdlCd
	 *            단말모델코드
	 */
	public void setEqpMdlCd(String eqpMdlCd) {
		this.eqpMdlCd = eqpMdlCd;
	}

	/**
	 * 기타내용
	 * 
	 * @return 기타내용
	 */
	public String getEtcCtt() {
		return etcCtt;
	}

	/**
	 * 기타내용
	 *
	 * @param etcCtt
	 *            기타내용
	 */
	public void setEtcCtt(String etcCtt) {
		this.etcCtt = etcCtt;
	}

	/**
	 * 펌웨어버전번호
	 * 
	 * @return 펌웨어버전번호
	 */
	public String getFwVerNum() {
		return fwVerNum;
	}

	/**
	 * 펌웨어버전번호
	 *
	 * @param fwVerNum
	 *            펌웨어버전번호
	 */
	public void setFwVerNum(String fwVerNum) {
		this.fwVerNum = fwVerNum;
	}

	/**
	 * 제조사명
	 * 
	 * @return 제조사명
	 */
	public String getMfactNm() {
		return mfactNm;
	}

	/**
	 * 제조사명
	 *
	 * @param mfactNm
	 *            제조사명
	 */
	public void setMfactNm(String mfactNm) {
		this.mfactNm = mfactNm;
	}

	/**
	 * 등록일시
	 * 
	 * @return 등록일시
	 */
	public String getRgstDtm() {
		return rgstDtm;
	}

	/**
	 * 등록일시
	 *
	 * @param rgstDtm
	 *            등록일시
	 */
	public void setRgstDtm(String rgstDtm) {
		this.rgstDtm = rgstDtm;
	}

	/**
	 * 팀조직ID
	 * 
	 * @return 팀조직ID
	 */
	public String getTeamOrgId() {
		return teamOrgId;
	}

	/**
	 * 팀조직ID
	 *
	 * @param teamOrgId
	 *            팀조직ID
	 */
	public void setTeamOrgId(String teamOrgId) {
		this.teamOrgId = teamOrgId;
	}
}
