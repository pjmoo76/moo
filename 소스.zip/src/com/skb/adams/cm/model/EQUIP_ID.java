package com.skb.adams.cm.model;

public class EQUIP_ID {
	
	private String equipMgmtNum;
	
	private String equipId;
	
	private String tpoCd;

	public String getTpoCd() {
		return tpoCd;
	}

	public void setTpoCd(String tpoCd) {
		this.tpoCd = tpoCd;
	}

	public String getEquipMgmtNum() {
		return equipMgmtNum;
	}

	public void setEquipMgmtNum(String equipMgmtNum) {
		this.equipMgmtNum = equipMgmtNum;
	}

	public String getEquipId() {
		return equipId;
	}

	public void setEquipId(String equipId) {
		this.equipId = equipId;
	}

}
