package com.skb.adams.cm.model;

public class OIV10402 {
	private	String	linkId;
	private	int		thruSerNum;
	private	String	weqpMgmtNum;
	private	long	custNum;
	private	String	tpoCd;
	private	String	hpyCntrOrgId;
	private	String	supWeqpMgmtNum;

	public OIV10402() {
		
	}
	
	public String getLinkId() {
		return linkId;
	}
	public void setLinkId(String linkId) {
		this.linkId = linkId;
	}
	public int getThruSerNum() {
		return thruSerNum;
	}
	public void setThruSerNum(int thruSerNum) {
		this.thruSerNum = thruSerNum;
	}
	public String getWeqpMgmtNum() {
		return weqpMgmtNum;
	}
	public void setWeqpMgmtNum(String weqpMgmtNum) {
		this.weqpMgmtNum = weqpMgmtNum;
	}
	public long getCustNum() {
		return custNum;
	}
	public void setCustNum(long custNum) {
		this.custNum = custNum;
	}
	public String getTpoCd() {
		return tpoCd;
	}
	public void setTpoCd(String tpoCd) {
		this.tpoCd = tpoCd;
	}
	public String getHpyCntrOrgId() {
		return hpyCntrOrgId;
	}
	public void setHpyCntrOrgId(String hpyCntrOrgId) {
		this.hpyCntrOrgId = hpyCntrOrgId;
	}
	public String getSupWeqpMgmtNum() {
		return supWeqpMgmtNum;
	}
	public void setSupWeqpMgmtNum(String supWeqpMgmtNum) {
		this.supWeqpMgmtNum = supWeqpMgmtNum;
	}
}
