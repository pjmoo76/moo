package com.skb.adams.cm.model;
import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;
import java.io.Serializable;
import java.sql.Timestamp;


/**
* @since 2018.09.26 14:04
* @author subkjh 
* autometic create by subkjh.dao 
*
*/


@FxTable(name = "OES10300", comment = "유선서비스기본")
public class OES10300 implements Serializable {

/**
	 * 
	 */
	private static final long serialVersionUID = 9026698980170905738L;


public OES10300() {
 }

@FxColumn(name = "SVC_MGMT_NUM", size = 10, comment = "서비스관리번호")
private long svcMgmtNum;


@FxColumn(name = "AUDIT_ID", size = 15, comment = "최종변경자ID")
private String auditId;


@FxColumn(name = "AUDIT_DTM", size = 0, comment = "최종변경일시")
private Timestamp auditDtm;


@FxColumn(name = "AP_MAC_ADDR_VAL", size = 15, nullable = true, comment = "AP장비MAC주소값")
private String apMacAddrVal;


@FxColumn(name = "SWTCHG_CL_CD", size = 1, comment = "절체구분코드")
private String swtchgClCd;


@FxColumn(name = "DOD_LINE_CL_CD", size = 1, comment = "DOD회선분류코드")
private String dodLineClCd;


@FxColumn(name = "PUB_PHON_TYP_CD", size = 1, comment = "공중전화유형코드")
private String pubPhonTypCd;


@FxColumn(name = "RENT_LINE_USE_YN", size = 1, nullable = true, comment = "임차회선사용여부")
private String rentLineUseYn;


@FxColumn(name = "IOCALL_CL_CD", size = 1, comment = "착발신구분코드")
private String iocallClCd;


@FxColumn(name = "IOCALL_ST_CD", size = 1, comment = "착발신상태코드")
private String iocallStCd;


@FxColumn(name = "DID_REP_SVC_NUM", size = 20, nullable = true, comment = "DID대표서비스번호")
private String didRepSvcNum;


@FxColumn(name = "DOD_REP_SVC_NUM", size = 20, nullable = true, comment = "DOD대표서비스번호")
private String dodRepSvcNum;


@FxColumn(name = "STRM_PHON_STA_DT", size = 8, nullable = true, comment = "단기전화시작일자")
private String strmPhonStaDt;


@FxColumn(name = "STRM_PHON_END_DT", size = 8, nullable = true, comment = "단기전화종료일자")
private String strmPhonEndDt;


@FxColumn(name = "OTHR_CO_SVC_ID", size = 10, nullable = true, comment = "타사서비스ID")
private String othrCoSvcId;


@FxColumn(name = "PRMS_OUT_CL_CD", size = 1, comment = "댁내외구분코드")
private String prmsOutClCd;


@FxColumn(name = "INT_PHON_WLBIZR_CD", size = 1, comment = "국제전화무선사업자코드")
private String intPhonWlbizrCd;


@FxColumn(name = "AP_ADD_YN", size = 1, nullable = true, comment = "AP추가여부")
private String apAddYn;


@FxColumn(name = "RCV_DT", size = 8, nullable = true, comment = "접수일자")
private String rcvDt;


@FxColumn(name = "STRM_RENT_STA_DT", size = 8, nullable = true, comment = "단기임대시작일자")
private String strmRentStaDt;


@FxColumn(name = "STRM_RENT_END_DT", size = 8, nullable = true, comment = "단기임대종료일자")
private String strmRentEndDt;


@FxColumn(name = "EQP_MDL_CD", size = 10, nullable = true, comment = "단말모델코드")
private String eqpMdlCd;


@FxColumn(name = "EQP_SER_NUM", size = 15, nullable = true, comment = "단말기일련번호")
private String eqpSerNum;


@FxColumn(name = "MASS_CO_CL_CD", size = 1, comment = "매스기업구분코드")
private String massCoClCd;


@FxColumn(name = "SVC_TECH_MTHD_CD", size = 5, comment = "서비스기술방식코드")
private String svcTechMthdCd;


@FxColumn(name = "WPHON_DWTN_BIZR_CD", size = 1, comment = "유선전화시내사업자코드")
private String wphonDwtnBizrCd;


@FxColumn(name = "WPHON_PSEL_SYS_BIZR_CD", size = 1, comment = "유선전화사선제사업자코드")
private String wphonPselSysBizrCd;


@FxColumn(name = "INOFC_SVC_YN", size = 1, nullable = true, comment = "구내서비스여부")
private String inofcSvcYn;


/**
* 서비스관리번호
* @return 서비스관리번호
*/
public long getSvcMgmtNum() {
return svcMgmtNum;
}
/**
* 서비스관리번호
*@param svcMgmtNum 서비스관리번호
*/
public void setSvcMgmtNum(long svcMgmtNum) {
	this.svcMgmtNum = svcMgmtNum;
}
/**
* 최종변경자ID
* @return 최종변경자ID
*/
public String getAuditId() {
return auditId;
}
/**
* 최종변경자ID
*@param auditId 최종변경자ID
*/
public void setAuditId(String auditId) {
	this.auditId = auditId;
}
/**
* 최종변경일시
* @return 최종변경일시
*/
public Timestamp getAuditDtm() {
return auditDtm;
}
/**
* 최종변경일시
*@param auditDtm 최종변경일시
*/
public void setAuditDtm(Timestamp auditDtm) {
	this.auditDtm = auditDtm;
}
/**
* AP장비MAC주소값
* @return AP장비MAC주소값
*/
public String getApMacAddrVal() {
return apMacAddrVal;
}
/**
* AP장비MAC주소값
*@param apMacAddrVal AP장비MAC주소값
*/
public void setApMacAddrVal(String apMacAddrVal) {
	this.apMacAddrVal = apMacAddrVal;
}
/**
* 절체구분코드
* @return 절체구분코드
*/
public String getSwtchgClCd() {
return swtchgClCd;
}
/**
* 절체구분코드
*@param swtchgClCd 절체구분코드
*/
public void setSwtchgClCd(String swtchgClCd) {
	this.swtchgClCd = swtchgClCd;
}
/**
* DOD회선분류코드
* @return DOD회선분류코드
*/
public String getDodLineClCd() {
return dodLineClCd;
}
/**
* DOD회선분류코드
*@param dodLineClCd DOD회선분류코드
*/
public void setDodLineClCd(String dodLineClCd) {
	this.dodLineClCd = dodLineClCd;
}
/**
* 공중전화유형코드
* @return 공중전화유형코드
*/
public String getPubPhonTypCd() {
return pubPhonTypCd;
}
/**
* 공중전화유형코드
*@param pubPhonTypCd 공중전화유형코드
*/
public void setPubPhonTypCd(String pubPhonTypCd) {
	this.pubPhonTypCd = pubPhonTypCd;
}
/**
* 임차회선사용여부
* @return 임차회선사용여부
*/
public String getRentLineUseYn() {
return rentLineUseYn;
}
/**
* 임차회선사용여부
*@param rentLineUseYn 임차회선사용여부
*/
public void setRentLineUseYn(String rentLineUseYn) {
	this.rentLineUseYn = rentLineUseYn;
}
/**
* 착발신구분코드
* @return 착발신구분코드
*/
public String getIocallClCd() {
return iocallClCd;
}
/**
* 착발신구분코드
*@param iocallClCd 착발신구분코드
*/
public void setIocallClCd(String iocallClCd) {
	this.iocallClCd = iocallClCd;
}
/**
* 착발신상태코드
* @return 착발신상태코드
*/
public String getIocallStCd() {
return iocallStCd;
}
/**
* 착발신상태코드
*@param iocallStCd 착발신상태코드
*/
public void setIocallStCd(String iocallStCd) {
	this.iocallStCd = iocallStCd;
}
/**
* DID대표서비스번호
* @return DID대표서비스번호
*/
public String getDidRepSvcNum() {
return didRepSvcNum;
}
/**
* DID대표서비스번호
*@param didRepSvcNum DID대표서비스번호
*/
public void setDidRepSvcNum(String didRepSvcNum) {
	this.didRepSvcNum = didRepSvcNum;
}
/**
* DOD대표서비스번호
* @return DOD대표서비스번호
*/
public String getDodRepSvcNum() {
return dodRepSvcNum;
}
/**
* DOD대표서비스번호
*@param dodRepSvcNum DOD대표서비스번호
*/
public void setDodRepSvcNum(String dodRepSvcNum) {
	this.dodRepSvcNum = dodRepSvcNum;
}
/**
* 단기전화시작일자
* @return 단기전화시작일자
*/
public String getStrmPhonStaDt() {
return strmPhonStaDt;
}
/**
* 단기전화시작일자
*@param strmPhonStaDt 단기전화시작일자
*/
public void setStrmPhonStaDt(String strmPhonStaDt) {
	this.strmPhonStaDt = strmPhonStaDt;
}
/**
* 단기전화종료일자
* @return 단기전화종료일자
*/
public String getStrmPhonEndDt() {
return strmPhonEndDt;
}
/**
* 단기전화종료일자
*@param strmPhonEndDt 단기전화종료일자
*/
public void setStrmPhonEndDt(String strmPhonEndDt) {
	this.strmPhonEndDt = strmPhonEndDt;
}
/**
* 타사서비스ID
* @return 타사서비스ID
*/
public String getOthrCoSvcId() {
return othrCoSvcId;
}
/**
* 타사서비스ID
*@param othrCoSvcId 타사서비스ID
*/
public void setOthrCoSvcId(String othrCoSvcId) {
	this.othrCoSvcId = othrCoSvcId;
}
/**
* 댁내외구분코드
* @return 댁내외구분코드
*/
public String getPrmsOutClCd() {
return prmsOutClCd;
}
/**
* 댁내외구분코드
*@param prmsOutClCd 댁내외구분코드
*/
public void setPrmsOutClCd(String prmsOutClCd) {
	this.prmsOutClCd = prmsOutClCd;
}
/**
* 국제전화무선사업자코드
* @return 국제전화무선사업자코드
*/
public String getIntPhonWlbizrCd() {
return intPhonWlbizrCd;
}
/**
* 국제전화무선사업자코드
*@param intPhonWlbizrCd 국제전화무선사업자코드
*/
public void setIntPhonWlbizrCd(String intPhonWlbizrCd) {
	this.intPhonWlbizrCd = intPhonWlbizrCd;
}
/**
* AP추가여부
* @return AP추가여부
*/
public String getApAddYn() {
return apAddYn;
}
/**
* AP추가여부
*@param apAddYn AP추가여부
*/
public void setApAddYn(String apAddYn) {
	this.apAddYn = apAddYn;
}
/**
* 접수일자
* @return 접수일자
*/
public String getRcvDt() {
return rcvDt;
}
/**
* 접수일자
*@param rcvDt 접수일자
*/
public void setRcvDt(String rcvDt) {
	this.rcvDt = rcvDt;
}
/**
* 단기임대시작일자
* @return 단기임대시작일자
*/
public String getStrmRentStaDt() {
return strmRentStaDt;
}
/**
* 단기임대시작일자
*@param strmRentStaDt 단기임대시작일자
*/
public void setStrmRentStaDt(String strmRentStaDt) {
	this.strmRentStaDt = strmRentStaDt;
}
/**
* 단기임대종료일자
* @return 단기임대종료일자
*/
public String getStrmRentEndDt() {
return strmRentEndDt;
}
/**
* 단기임대종료일자
*@param strmRentEndDt 단기임대종료일자
*/
public void setStrmRentEndDt(String strmRentEndDt) {
	this.strmRentEndDt = strmRentEndDt;
}
/**
* 단말모델코드
* @return 단말모델코드
*/
public String getEqpMdlCd() {
return eqpMdlCd;
}
/**
* 단말모델코드
*@param eqpMdlCd 단말모델코드
*/
public void setEqpMdlCd(String eqpMdlCd) {
	this.eqpMdlCd = eqpMdlCd;
}
/**
* 단말기일련번호
* @return 단말기일련번호
*/
public String getEqpSerNum() {
return eqpSerNum;
}
/**
* 단말기일련번호
*@param eqpSerNum 단말기일련번호
*/
public void setEqpSerNum(String eqpSerNum) {
	this.eqpSerNum = eqpSerNum;
}
/**
* 매스기업구분코드
* @return 매스기업구분코드
*/
public String getMassCoClCd() {
return massCoClCd;
}
/**
* 매스기업구분코드
*@param massCoClCd 매스기업구분코드
*/
public void setMassCoClCd(String massCoClCd) {
	this.massCoClCd = massCoClCd;
}
/**
* 서비스기술방식코드
* @return 서비스기술방식코드
*/
public String getSvcTechMthdCd() {
return svcTechMthdCd;
}
/**
* 서비스기술방식코드
*@param svcTechMthdCd 서비스기술방식코드
*/
public void setSvcTechMthdCd(String svcTechMthdCd) {
	this.svcTechMthdCd = svcTechMthdCd;
}
/**
* 유선전화시내사업자코드
* @return 유선전화시내사업자코드
*/
public String getWphonDwtnBizrCd() {
return wphonDwtnBizrCd;
}
/**
* 유선전화시내사업자코드
*@param wphonDwtnBizrCd 유선전화시내사업자코드
*/
public void setWphonDwtnBizrCd(String wphonDwtnBizrCd) {
	this.wphonDwtnBizrCd = wphonDwtnBizrCd;
}
/**
* 유선전화사선제사업자코드
* @return 유선전화사선제사업자코드
*/
public String getWphonPselSysBizrCd() {
return wphonPselSysBizrCd;
}
/**
* 유선전화사선제사업자코드
*@param wphonPselSysBizrCd 유선전화사선제사업자코드
*/
public void setWphonPselSysBizrCd(String wphonPselSysBizrCd) {
	this.wphonPselSysBizrCd = wphonPselSysBizrCd;
}
/**
* 구내서비스여부
* @return 구내서비스여부
*/
public String getInofcSvcYn() {
return inofcSvcYn;
}
/**
* 구내서비스여부
*@param inofcSvcYn 구내서비스여부
*/
public void setInofcSvcYn(String inofcSvcYn) {
	this.inofcSvcYn = inofcSvcYn;
}
}
