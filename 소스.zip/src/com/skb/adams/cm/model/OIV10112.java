package com.skb.adams.cm.model;

import java.io.Serializable;
import java.sql.Timestamp;

import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;

/**
 * @since 2017.11.29 14:03
 * @author subkjh autometic create by subkjh.dao
 *
 */

@FxTable(name = "OIV10112", comment = "SWING장비기본")
public class OIV10112 implements Serializable {

	public OIV10112() {
	}

	@FxColumn(name = "AUDIT_DTM", size = 0, comment = "AUDIT_DTM")
	private Timestamp auditDtm;

	@FxColumn(name = "AUDIT_ID", size = 15, comment = "AUDIT_ID")
	private String auditId;

	@FxColumn(name = "AUTO_ACTVN_YN", size = 1, nullable = true, comment = "AUTO_ACTVN_YN")
	private String autoActvnYn;

	@FxColumn(name = "DTL_WIRE_MEDIA_CL_CD", size = 4, nullable = true, comment = "DTL_WIRE_MEDIA_CL_CD")
	private String dtlWireMediaClCd;

	@FxColumn(name = "EMS_IP_ADDR", size = 23, nullable = true, comment = "EMS_IP_ADDR")
	private String emsIpAddr;

	@FxColumn(name = "EMS_LINK_TYP_CTT", size = 30, nullable = true, comment = "EMS_LINK_TYP_CTT")
	private String emsLinkTypCtt;

	@FxColumn(name = "EQUIP_CD", size = 10, comment = "EQUIP_CD")
	private String equipCd;

	@FxColumn(name = "EQUIP_MGMT_DEPT_ORG_ID", size = 10, nullable = true, comment = "EQUIP_MGMT_DEPT_ORG_ID")
	private String equipMgmtDeptOrgId;

	@FxColumn(name = "EQUIP_MGMT_NUM", size = 8, comment = "EQUIP_MGMT_NUM")
	private String equipMgmtNum;

	@FxColumn(name = "EQUIP_OWN_YN", size = 1, nullable = true, comment = "EQUIP_OWN_YN")
	private String equipOwnYn;

	@FxColumn(name = "EQUIP_SET_LOC_DESC", size = 100, nullable = true, comment = "EQUIP_SET_LOC_DESC")
	private String equipSetLocDesc;

	@FxColumn(name = "EQUIP_SYS_NM", size = 40, nullable = true, comment = "EQUIP_SYS_NM")
	private String equipSysNm;

	@FxColumn(name = "EQUIP_SYS_SET_DT", size = 8, nullable = true, comment = "EQUIP_SYS_SET_DT")
	private String equipSysSetDt;

	@FxColumn(name = "EQUIP_TID_VAL", size = 30, nullable = true, comment = "EQUIP_TID_VAL")
	private String equipTidVal;

	@FxColumn(name = "EQUIP_TYP_CL_CD", size = 5, nullable = true, comment = "EQUIP_TYP_CL_CD")
	private String equipTypClCd;

	@FxColumn(name = "EQUIP_VER_NUM", size = 2, nullable = true, comment = "EQUIP_VER_NUM")
	private String equipVerNum;

	@FxColumn(name = "EXCHG_TPO_CD", size = 6, nullable = true, comment = "EXCHG_TPO_CD")
	private String exchgTpoCd;

	@FxColumn(name = "IEQUIP_NET_CL_CD", size = 2, nullable = true, comment = "IEQUIP_NET_CL_CD")
	private String iequipNetClCd;

	@FxColumn(name = "IP_ADDR", size = 23, nullable = true, comment = "IP_ADDR")
	private String ipAddr;

	@FxColumn(name = "IP_ADDR_CL_CD", size = 1, nullable = true, comment = "IP_ADDR_CL_CD")
	private String ipAddrClCd;

	@FxColumn(name = "JURIS_TPO_CD", size = 6, nullable = true, comment = "JURIS_TPO_CD")
	private String jurisTpoCd;

	@FxColumn(name = "KEY_RCV_LOC_DESC", size = 50, nullable = true, comment = "KEY_RCV_LOC_DESC")
	private String keyRcvLocDesc;

	@FxColumn(name = "LINE_NUM", size = 12, nullable = true, comment = "LINE_NUM")
	private String lineNum;

	@FxColumn(name = "LINK_EQUIP_MGMT_NUM", size = 8, nullable = true, comment = "LINK_EQUIP_MGMT_NUM")
	private String linkEquipMgmtNum;

	@FxColumn(name = "MEMO", size = 2000, nullable = true, comment = "MEMO")
	private String memo;

	@FxColumn(name = "MGMT_DEPT_CL_CD", size = 1, nullable = true, comment = "MGMT_DEPT_CL_CD")
	private String mgmtDeptClCd;

	@FxColumn(name = "MGMT_TPO_CD", size = 6, nullable = true, comment = "MGMT_TPO_CD")
	private String mgmtTpoCd;

	@FxColumn(name = "NET_CHG_YN", size = 1, nullable = true, comment = "NET_CHG_YN")
	private String netChgYn;

	@FxColumn(name = "NMS_EQUIP_CD", size = 12, nullable = true, comment = "NMS_EQUIP_CD")
	private String nmsEquipCd;

	@FxColumn(name = "OPER_CO_ID", size = 10, nullable = true, comment = "OPER_CO_ID")
	private String operCoId;

	@FxColumn(name = "OPER_GRP_ID", size = 10, nullable = true, comment = "OPER_GRP_ID")
	private String operGrpId;

	@FxColumn(name = "SHR_EQUIP_YN", size = 1, nullable = true, comment = "SHR_EQUIP_YN")
	private String shrEquipYn;

	@FxColumn(name = "SPCL_INSP_CL_CD", size = 2, nullable = true, comment = "SPCL_INSP_CL_CD")
	private String spclInspClCd;

	@FxColumn(name = "TPO_CD", size = 6, comment = "TPO_CD")
	private String tpoCd;

	@FxColumn(name = "TPO_EQUIP_SER_NUM", size = 15, nullable = true, comment = "TPO_EQUIP_SER_NUM")
	private Number tpoEquipSerNum;

	@FxColumn(name = "TPO_SER_NUM", size = 15, nullable = true, comment = "TPO_SER_NUM")
	private Number tpoSerNum;

	@FxColumn(name = "UPS_LINK_YN", size = 1, nullable = true, comment = "UPS_LINK_YN")
	private String upsLinkYn;

	@FxColumn(name = "WIRE_MEDIA_CL_CD", size = 1, nullable = true, comment = "WIRE_MEDIA_CL_CD")
	private String wireMediaClCd;

	/**
	 * AUDIT_DTM
	 * 
	 * @return AUDIT_DTM
	 */
	public Timestamp getAuditDtm() {
		return auditDtm;
	}

	/**
	 * AUDIT_DTM
	 *
	 * @param auditDtm
	 *            AUDIT_DTM
	 */
	public void setAuditDtm(Timestamp auditDtm) {
		this.auditDtm = auditDtm;
	}

	/**
	 * AUDIT_ID
	 * 
	 * @return AUDIT_ID
	 */
	public String getAuditId() {
		return auditId;
	}

	/**
	 * AUDIT_ID
	 *
	 * @param auditId
	 *            AUDIT_ID
	 */
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	/**
	 * AUTO_ACTVN_YN
	 * 
	 * @return AUTO_ACTVN_YN
	 */
	public String isAutoActvnYn() {
		return autoActvnYn;
	}

	/**
	 * AUTO_ACTVN_YN
	 *
	 * @param autoActvnYn
	 *            AUTO_ACTVN_YN
	 */
	public void setAutoActvnYn(String autoActvnYn) {
		this.autoActvnYn = autoActvnYn;
	}

	/**
	 * DTL_WIRE_MEDIA_CL_CD
	 * 
	 * @return DTL_WIRE_MEDIA_CL_CD
	 */
	public String getDtlWireMediaClCd() {
		return dtlWireMediaClCd;
	}

	/**
	 * DTL_WIRE_MEDIA_CL_CD
	 *
	 * @param dtlWireMediaClCd
	 *            DTL_WIRE_MEDIA_CL_CD
	 */
	public void setDtlWireMediaClCd(String dtlWireMediaClCd) {
		this.dtlWireMediaClCd = dtlWireMediaClCd;
	}

	/**
	 * EMS_IP_ADDR
	 * 
	 * @return EMS_IP_ADDR
	 */
	public String getEmsIpAddr() {
		return emsIpAddr;
	}

	/**
	 * EMS_IP_ADDR
	 *
	 * @param emsIpAddr
	 *            EMS_IP_ADDR
	 */
	public void setEmsIpAddr(String emsIpAddr) {
		this.emsIpAddr = emsIpAddr;
	}

	/**
	 * EMS_LINK_TYP_CTT
	 * 
	 * @return EMS_LINK_TYP_CTT
	 */
	public String getEmsLinkTypCtt() {
		return emsLinkTypCtt;
	}

	/**
	 * EMS_LINK_TYP_CTT
	 *
	 * @param emsLinkTypCtt
	 *            EMS_LINK_TYP_CTT
	 */
	public void setEmsLinkTypCtt(String emsLinkTypCtt) {
		this.emsLinkTypCtt = emsLinkTypCtt;
	}

	/**
	 * EQUIP_CD
	 * 
	 * @return EQUIP_CD
	 */
	public String getEquipCd() {
		return equipCd;
	}

	/**
	 * EQUIP_CD
	 *
	 * @param equipCd
	 *            EQUIP_CD
	 */
	public void setEquipCd(String equipCd) {
		this.equipCd = equipCd;
	}

	/**
	 * EQUIP_MGMT_DEPT_ORG_ID
	 * 
	 * @return EQUIP_MGMT_DEPT_ORG_ID
	 */
	public String getEquipMgmtDeptOrgId() {
		return equipMgmtDeptOrgId;
	}

	/**
	 * EQUIP_MGMT_DEPT_ORG_ID
	 *
	 * @param equipMgmtDeptOrgId
	 *            EQUIP_MGMT_DEPT_ORG_ID
	 */
	public void setEquipMgmtDeptOrgId(String equipMgmtDeptOrgId) {
		this.equipMgmtDeptOrgId = equipMgmtDeptOrgId;
	}

	/**
	 * EQUIP_MGMT_NUM
	 * 
	 * @return EQUIP_MGMT_NUM
	 */
	public String getEquipMgmtNum() {
		return equipMgmtNum;
	}

	/**
	 * EQUIP_MGMT_NUM
	 *
	 * @param equipMgmtNum
	 *            EQUIP_MGMT_NUM
	 */
	public void setEquipMgmtNum(String equipMgmtNum) {
		this.equipMgmtNum = equipMgmtNum;
	}

	/**
	 * EQUIP_OWN_YN
	 * 
	 * @return EQUIP_OWN_YN
	 */
	public String isEquipOwnYn() {
		return equipOwnYn;
	}

	/**
	 * EQUIP_OWN_YN
	 *
	 * @param equipOwnYn
	 *            EQUIP_OWN_YN
	 */
	public void setEquipOwnYn(String equipOwnYn) {
		this.equipOwnYn = equipOwnYn;
	}

	/**
	 * EQUIP_SET_LOC_DESC
	 * 
	 * @return EQUIP_SET_LOC_DESC
	 */
	public String getEquipSetLocDesc() {
		return equipSetLocDesc;
	}

	/**
	 * EQUIP_SET_LOC_DESC
	 *
	 * @param equipSetLocDesc
	 *            EQUIP_SET_LOC_DESC
	 */
	public void setEquipSetLocDesc(String equipSetLocDesc) {
		this.equipSetLocDesc = equipSetLocDesc;
	}

	/**
	 * EQUIP_SYS_NM
	 * 
	 * @return EQUIP_SYS_NM
	 */
	public String getEquipSysNm() {
		return equipSysNm;
	}

	/**
	 * EQUIP_SYS_NM
	 *
	 * @param equipSysNm
	 *            EQUIP_SYS_NM
	 */
	public void setEquipSysNm(String equipSysNm) {
		this.equipSysNm = equipSysNm;
	}

	/**
	 * EQUIP_SYS_SET_DT
	 * 
	 * @return EQUIP_SYS_SET_DT
	 */
	public String getEquipSysSetDt() {
		return equipSysSetDt;
	}

	/**
	 * EQUIP_SYS_SET_DT
	 *
	 * @param equipSysSetDt
	 *            EQUIP_SYS_SET_DT
	 */
	public void setEquipSysSetDt(String equipSysSetDt) {
		this.equipSysSetDt = equipSysSetDt;
	}

	/**
	 * EQUIP_TID_VAL
	 * 
	 * @return EQUIP_TID_VAL
	 */
	public String getEquipTidVal() {
		return equipTidVal;
	}

	/**
	 * EQUIP_TID_VAL
	 *
	 * @param equipTidVal
	 *            EQUIP_TID_VAL
	 */
	public void setEquipTidVal(String equipTidVal) {
		this.equipTidVal = equipTidVal;
	}

	/**
	 * EQUIP_TYP_CL_CD
	 * 
	 * @return EQUIP_TYP_CL_CD
	 */
	public String getEquipTypClCd() {
		return equipTypClCd;
	}

	/**
	 * EQUIP_TYP_CL_CD
	 *
	 * @param equipTypClCd
	 *            EQUIP_TYP_CL_CD
	 */
	public void setEquipTypClCd(String equipTypClCd) {
		this.equipTypClCd = equipTypClCd;
	}

	/**
	 * EQUIP_VER_NUM
	 * 
	 * @return EQUIP_VER_NUM
	 */
	public String getEquipVerNum() {
		return equipVerNum;
	}

	/**
	 * EQUIP_VER_NUM
	 *
	 * @param equipVerNum
	 *            EQUIP_VER_NUM
	 */
	public void setEquipVerNum(String equipVerNum) {
		this.equipVerNum = equipVerNum;
	}

	/**
	 * EXCHG_TPO_CD
	 * 
	 * @return EXCHG_TPO_CD
	 */
	public String getExchgTpoCd() {
		return exchgTpoCd;
	}

	/**
	 * EXCHG_TPO_CD
	 *
	 * @param exchgTpoCd
	 *            EXCHG_TPO_CD
	 */
	public void setExchgTpoCd(String exchgTpoCd) {
		this.exchgTpoCd = exchgTpoCd;
	}

	/**
	 * IEQUIP_NET_CL_CD
	 * 
	 * @return IEQUIP_NET_CL_CD
	 */
	public String getIequipNetClCd() {
		return iequipNetClCd;
	}

	/**
	 * IEQUIP_NET_CL_CD
	 *
	 * @param iequipNetClCd
	 *            IEQUIP_NET_CL_CD
	 */
	public void setIequipNetClCd(String iequipNetClCd) {
		this.iequipNetClCd = iequipNetClCd;
	}

	/**
	 * IP_ADDR
	 * 
	 * @return IP_ADDR
	 */
	public String getIpAddr() {
		return ipAddr;
	}

	/**
	 * IP_ADDR
	 *
	 * @param ipAddr
	 *            IP_ADDR
	 */
	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}

	/**
	 * IP_ADDR_CL_CD
	 * 
	 * @return IP_ADDR_CL_CD
	 */
	public String getIpAddrClCd() {
		return ipAddrClCd;
	}

	/**
	 * IP_ADDR_CL_CD
	 *
	 * @param ipAddrClCd
	 *            IP_ADDR_CL_CD
	 */
	public void setIpAddrClCd(String ipAddrClCd) {
		this.ipAddrClCd = ipAddrClCd;
	}

	/**
	 * JURIS_TPO_CD
	 * 
	 * @return JURIS_TPO_CD
	 */
	public String getJurisTpoCd() {
		return jurisTpoCd;
	}

	/**
	 * JURIS_TPO_CD
	 *
	 * @param jurisTpoCd
	 *            JURIS_TPO_CD
	 */
	public void setJurisTpoCd(String jurisTpoCd) {
		this.jurisTpoCd = jurisTpoCd;
	}

	/**
	 * KEY_RCV_LOC_DESC
	 * 
	 * @return KEY_RCV_LOC_DESC
	 */
	public String getKeyRcvLocDesc() {
		return keyRcvLocDesc;
	}

	/**
	 * KEY_RCV_LOC_DESC
	 *
	 * @param keyRcvLocDesc
	 *            KEY_RCV_LOC_DESC
	 */
	public void setKeyRcvLocDesc(String keyRcvLocDesc) {
		this.keyRcvLocDesc = keyRcvLocDesc;
	}

	/**
	 * LINE_NUM
	 * 
	 * @return LINE_NUM
	 */
	public String getLineNum() {
		return lineNum;
	}

	/**
	 * LINE_NUM
	 *
	 * @param lineNum
	 *            LINE_NUM
	 */
	public void setLineNum(String lineNum) {
		this.lineNum = lineNum;
	}

	/**
	 * LINK_EQUIP_MGMT_NUM
	 * 
	 * @return LINK_EQUIP_MGMT_NUM
	 */
	public String getLinkEquipMgmtNum() {
		return linkEquipMgmtNum;
	}

	/**
	 * LINK_EQUIP_MGMT_NUM
	 *
	 * @param linkEquipMgmtNum
	 *            LINK_EQUIP_MGMT_NUM
	 */
	public void setLinkEquipMgmtNum(String linkEquipMgmtNum) {
		this.linkEquipMgmtNum = linkEquipMgmtNum;
	}

	/**
	 * MEMO
	 * 
	 * @return MEMO
	 */
	public String getMemo() {
		return memo;
	}

	/**
	 * MEMO
	 *
	 * @param memo
	 *            MEMO
	 */
	public void setMemo(String memo) {
		this.memo = memo;
	}

	/**
	 * MGMT_DEPT_CL_CD
	 * 
	 * @return MGMT_DEPT_CL_CD
	 */
	public String getMgmtDeptClCd() {
		return mgmtDeptClCd;
	}

	/**
	 * MGMT_DEPT_CL_CD
	 *
	 * @param mgmtDeptClCd
	 *            MGMT_DEPT_CL_CD
	 */
	public void setMgmtDeptClCd(String mgmtDeptClCd) {
		this.mgmtDeptClCd = mgmtDeptClCd;
	}

	/**
	 * MGMT_TPO_CD
	 * 
	 * @return MGMT_TPO_CD
	 */
	public String getMgmtTpoCd() {
		return mgmtTpoCd;
	}

	/**
	 * MGMT_TPO_CD
	 *
	 * @param mgmtTpoCd
	 *            MGMT_TPO_CD
	 */
	public void setMgmtTpoCd(String mgmtTpoCd) {
		this.mgmtTpoCd = mgmtTpoCd;
	}

	/**
	 * NET_CHG_YN
	 * 
	 * @return NET_CHG_YN
	 */
	public String isNetChgYn() {
		return netChgYn;
	}

	/**
	 * NET_CHG_YN
	 *
	 * @param netChgYn
	 *            NET_CHG_YN
	 */
	public void setNetChgYn(String netChgYn) {
		this.netChgYn = netChgYn;
	}

	/**
	 * NMS_EQUIP_CD
	 * 
	 * @return NMS_EQUIP_CD
	 */
	public String getNmsEquipCd() {
		return nmsEquipCd;
	}

	/**
	 * NMS_EQUIP_CD
	 *
	 * @param nmsEquipCd
	 *            NMS_EQUIP_CD
	 */
	public void setNmsEquipCd(String nmsEquipCd) {
		this.nmsEquipCd = nmsEquipCd;
	}

	/**
	 * OPER_CO_ID
	 * 
	 * @return OPER_CO_ID
	 */
	public String getOperCoId() {
		return operCoId;
	}

	/**
	 * OPER_CO_ID
	 *
	 * @param operCoId
	 *            OPER_CO_ID
	 */
	public void setOperCoId(String operCoId) {
		this.operCoId = operCoId;
	}

	/**
	 * OPER_GRP_ID
	 * 
	 * @return OPER_GRP_ID
	 */
	public String getOperGrpId() {
		return operGrpId;
	}

	/**
	 * OPER_GRP_ID
	 *
	 * @param operGrpId
	 *            OPER_GRP_ID
	 */
	public void setOperGrpId(String operGrpId) {
		this.operGrpId = operGrpId;
	}

	/**
	 * SHR_EQUIP_YN
	 * 
	 * @return SHR_EQUIP_YN
	 */
	public String isShrEquipYn() {
		return shrEquipYn;
	}

	/**
	 * SHR_EQUIP_YN
	 *
	 * @param shrEquipYn
	 *            SHR_EQUIP_YN
	 */
	public void setShrEquipYn(String shrEquipYn) {
		this.shrEquipYn = shrEquipYn;
	}

	/**
	 * SPCL_INSP_CL_CD
	 * 
	 * @return SPCL_INSP_CL_CD
	 */
	public String getSpclInspClCd() {
		return spclInspClCd;
	}

	/**
	 * SPCL_INSP_CL_CD
	 *
	 * @param spclInspClCd
	 *            SPCL_INSP_CL_CD
	 */
	public void setSpclInspClCd(String spclInspClCd) {
		this.spclInspClCd = spclInspClCd;
	}

	/**
	 * TPO_CD
	 * 
	 * @return TPO_CD
	 */
	public String getTpoCd() {
		return tpoCd;
	}

	/**
	 * TPO_CD
	 *
	 * @param tpoCd
	 *            TPO_CD
	 */
	public void setTpoCd(String tpoCd) {
		this.tpoCd = tpoCd;
	}

	/**
	 * TPO_EQUIP_SER_NUM
	 * 
	 * @return TPO_EQUIP_SER_NUM
	 */
	public Number getTpoEquipSerNum() {
		return tpoEquipSerNum;
	}

	/**
	 * TPO_EQUIP_SER_NUM
	 *
	 * @param tpoEquipSerNum
	 *            TPO_EQUIP_SER_NUM
	 */
	public void setTpoEquipSerNum(Number tpoEquipSerNum) {
		this.tpoEquipSerNum = tpoEquipSerNum;
	}

	/**
	 * TPO_SER_NUM
	 * 
	 * @return TPO_SER_NUM
	 */
	public Number getTpoSerNum() {
		return tpoSerNum;
	}

	/**
	 * TPO_SER_NUM
	 *
	 * @param tpoSerNum
	 *            TPO_SER_NUM
	 */
	public void setTpoSerNum(Number tpoSerNum) {
		this.tpoSerNum = tpoSerNum;
	}

	/**
	 * UPS_LINK_YN
	 * 
	 * @return UPS_LINK_YN
	 */
	public String isUpsLinkYn() {
		return upsLinkYn;
	}

	/**
	 * UPS_LINK_YN
	 *
	 * @param upsLinkYn
	 *            UPS_LINK_YN
	 */
	public void setUpsLinkYn(String upsLinkYn) {
		this.upsLinkYn = upsLinkYn;
	}

	/**
	 * WIRE_MEDIA_CL_CD
	 * 
	 * @return WIRE_MEDIA_CL_CD
	 */
	public String getWireMediaClCd() {
		return wireMediaClCd;
	}

	/**
	 * WIRE_MEDIA_CL_CD
	 *
	 * @param wireMediaClCd
	 *            WIRE_MEDIA_CL_CD
	 */
	public void setWireMediaClCd(String wireMediaClCd) {
		this.wireMediaClCd = wireMediaClCd;
	}
}
