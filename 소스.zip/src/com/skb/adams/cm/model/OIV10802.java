package com.skb.adams.cm.model;

import java.io.Serializable;
import java.sql.Timestamp;

import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;

/**
 * @since 2017.12.26 12:54
 * @author subkjh autometic create by subkjh.dao
 *
 */

@FxTable(name = "OIV10802", comment = "유선단말수집내역")
public class OIV10802 implements Serializable {

	public OIV10802() {
	}

	@FxColumn(name = "MAC_ADDR_VAL", size = 15, comment = "MAC주소값")
	private String macAddrVal;

	@FxColumn(name = "AUDIT_ID", size = 15, comment = "최종변경자ID")
	private String auditId;

	@FxColumn(name = "IP_ADDR", size = 23, nullable = true, comment = "IP주소")
	private String ipAddr;

	@FxColumn(name = "OUT_LNKG_IP_ADDR", size = 23, nullable = true, comment = "외부연동IP주소")
	private String outLnkgIpAddr;

	@FxColumn(name = "WEQP_MDL_NM", size = 40, nullable = true, comment = "유선단말모델명")
	private String weqpMdlNm;

	@FxColumn(name = "EQP_UPTIME_CNT", size = 11, nullable = true, comment = "단말UPTIME수")
	private long eqpUptimeCnt;

	@FxColumn(name = "EQP_VER_INFO", size = 100, nullable = true, comment = "단말버전정보")
	private String eqpVerInfo;

	@FxColumn(name = "IPTV_SVC_MODE_VAL", size = 20, nullable = true, comment = "IPTV서비스모드값")
	private String iptvSvcModeVal;

	@FxColumn(name = "PATCH_GRP_CTT", size = 50, nullable = true, comment = "패치그룹내용")
	private String patchGrpCtt;

	@FxColumn(name = "TRAP_RCV_DTM", size = 0, comment = "트랩수신일시", defValue = "SYSDATE")
	private Timestamp trapRcvDtm;

	/**
	 * MAC주소값
	 * 
	 * @return MAC주소값
	 */
	public String getMacAddrVal() {
		return macAddrVal;
	}

	/**
	 * MAC주소값
	 *
	 * @param macAddrVal
	 *            MAC주소값
	 */
	public void setMacAddrVal(String macAddrVal) {
		this.macAddrVal = macAddrVal;
	}

	/**
	 * 최종변경자ID
	 * 
	 * @return 최종변경자ID
	 */
	public String getAuditId() {
		return auditId;
	}

	/**
	 * 최종변경자ID
	 *
	 * @param auditId
	 *            최종변경자ID
	 */
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	/**
	 * IP주소
	 * 
	 * @return IP주소
	 */
	public String getIpAddr() {
		return ipAddr;
	}

	/**
	 * IP주소
	 *
	 * @param ipAddr
	 *            IP주소
	 */
	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}

	/**
	 * 외부연동IP주소
	 * 
	 * @return 외부연동IP주소
	 */
	public String getOutLnkgIpAddr() {
		return outLnkgIpAddr;
	}

	/**
	 * 외부연동IP주소
	 *
	 * @param outLnkgIpAddr
	 *            외부연동IP주소
	 */
	public void setOutLnkgIpAddr(String outLnkgIpAddr) {
		this.outLnkgIpAddr = outLnkgIpAddr;
	}

	/**
	 * 유선단말모델명
	 * 
	 * @return 유선단말모델명
	 */
	public String getWeqpMdlNm() {
		return weqpMdlNm;
	}

	/**
	 * 유선단말모델명
	 *
	 * @param weqpMdlNm
	 *            유선단말모델명
	 */
	public void setWeqpMdlNm(String weqpMdlNm) {
		this.weqpMdlNm = weqpMdlNm;
	}

	/**
	 * 단말UPTIME수
	 * 
	 * @return 단말UPTIME수
	 */
	public long getEqpUptimeCnt() {
		return eqpUptimeCnt;
	}

	/**
	 * 단말UPTIME수
	 *
	 * @param eqpUptimeCnt
	 *            단말UPTIME수
	 */
	public void setEqpUptimeCnt(long eqpUptimeCnt) {
		this.eqpUptimeCnt = eqpUptimeCnt;
	}

	/**
	 * 단말버전정보
	 * 
	 * @return 단말버전정보
	 */
	public String getEqpVerInfo() {
		return eqpVerInfo;
	}

	/**
	 * 단말버전정보
	 *
	 * @param eqpVerInfo
	 *            단말버전정보
	 */
	public void setEqpVerInfo(String eqpVerInfo) {
		this.eqpVerInfo = eqpVerInfo;
	}

	/**
	 * IPTV서비스모드값
	 * 
	 * @return IPTV서비스모드값
	 */
	public String getIptvSvcModeVal() {
		return iptvSvcModeVal;
	}

	/**
	 * IPTV서비스모드값
	 *
	 * @param iptvSvcModeVal
	 *            IPTV서비스모드값
	 */
	public void setIptvSvcModeVal(String iptvSvcModeVal) {
		this.iptvSvcModeVal = iptvSvcModeVal;
	}

	/**
	 * 패치그룹내용
	 * 
	 * @return 패치그룹내용
	 */
	public String getPatchGrpCtt() {
		return patchGrpCtt;
	}

	/**
	 * 패치그룹내용
	 *
	 * @param patchGrpCtt
	 *            패치그룹내용
	 */
	public void setPatchGrpCtt(String patchGrpCtt) {
		this.patchGrpCtt = patchGrpCtt;
	}

	/**
	 * 트랩수신일시
	 * 
	 * @return 트랩수신일시
	 */
	public Timestamp getTrapRcvDtm() {
		return trapRcvDtm;
	}

	/**
	 * 트랩수신일시
	 *
	 * @param trapRcvDtm
	 *            트랩수신일시
	 */
	public void setTrapRcvDtm(Timestamp trapRcvDtm) {
		this.trapRcvDtm = trapRcvDtm;
	}
}
