package com.skb.adams.cm.model;

import java.io.Serializable;
import java.sql.Timestamp;

import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;

/**
 * @since 2017.12.10 13:53
 * @author subkjh autometic create by subkjh.dao
 *
 */

@FxTable(name = "OIV10171", comment = "셀포트내역")
public class OIV10171 implements Serializable {
	private boolean isNew = true;

	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

	public OIV10171() {
	}
	
	private String equipId;

	public String getEquipId() {
		return equipId;
	}

	public void setEquipId(String equipId) {
		this.equipId = equipId;
	}

	@FxColumn(name = "CCELL_ID", size = 14, comment = "커버리지셀ID")
	private String ccellId;

	@FxColumn(name = "EQUIP_PORT_ID", size = 15, comment = "장비포트ID")
	private String equipPortId;

	@FxColumn(name = "AUDIT_ID", size = 15, comment = "최종변경자ID")
	private String auditId;

	@FxColumn(name = "AUDIT_DTM", size = 0, comment = "최종변경일시", defValue = "SYSDATE")
	private Timestamp auditDtm;

	@FxColumn(name = "MOUN_LOC_NUM", size = 10, nullable = true, comment = "실장위치번호")
	private String mounLocNum;

	@FxColumn(name = "PORT_NUM", size = 5, nullable = true, comment = "포트번호")
	private String portNum;

	@FxColumn(name = "OTX_NUM", size = 15, nullable = true, comment = "OTX번호")
	private String otxNum;

	@FxColumn(name = "CRE_DTM", size = 14, nullable = true, comment = "생성일시")
	private String creDtm;

	/**
	 * 커버리지셀ID
	 * 
	 * @return 커버리지셀ID
	 */
	public String getCcellId() {
		return ccellId;
	}

	/**
	 * 커버리지셀ID
	 *
	 * @param ccellId
	 *            커버리지셀ID
	 */
	public void setCcellId(String ccellId) {
		this.ccellId = ccellId;
	}

	/**
	 * 장비포트ID
	 * 
	 * @return 장비포트ID
	 */
	public String getEquipPortId() {
		return equipPortId;
	}

	/**
	 * 장비포트ID
	 *
	 * @param equipPortId
	 *            장비포트ID
	 */
	public void setEquipPortId(String equipPortId) {
		this.equipPortId = equipPortId;
	}

	/**
	 * 최종변경자ID
	 * 
	 * @return 최종변경자ID
	 */
	public String getAuditId() {
		return auditId;
	}

	/**
	 * 최종변경자ID
	 *
	 * @param auditId
	 *            최종변경자ID
	 */
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	/**
	 * 최종변경일시
	 * 
	 * @return 최종변경일시
	 */
	public Timestamp getAuditDtm() {
		return auditDtm;
	}

	/**
	 * 최종변경일시
	 *
	 * @param auditDtm
	 *            최종변경일시
	 */
	public void setAuditDtm(Timestamp auditDtm) {
		this.auditDtm = auditDtm;
	}

	/**
	 * 실장위치번호
	 * 
	 * @return 실장위치번호
	 */
	public String getMounLocNum() {
		return mounLocNum;
	}

	/**
	 * 실장위치번호
	 *
	 * @param mounLocNum
	 *            실장위치번호
	 */
	public void setMounLocNum(String mounLocNum) {
		this.mounLocNum = mounLocNum;
	}

	/**
	 * 포트번호
	 * 
	 * @return 포트번호
	 */
	public String getPortNum() {
		return portNum;
	}

	/**
	 * 포트번호
	 *
	 * @param portNum
	 *            포트번호
	 */
	public void setPortNum(String portNum) {
		this.portNum = portNum;
	}

	/**
	 * OTX번호
	 * 
	 * @return OTX번호
	 */
	public String getOtxNum() {
		return otxNum;
	}

	/**
	 * OTX번호
	 *
	 * @param otxNum
	 *            OTX번호
	 */
	public void setOtxNum(String otxNum) {
		this.otxNum = otxNum;
	}

	/**
	 * 생성일시
	 * 
	 * @return 생성일시
	 */
	public String getCreDtm() {
		return creDtm;
	}

	/**
	 * 생성일시
	 *
	 * @param creDtm
	 *            생성일시
	 */
	public void setCreDtm(String creDtm) {
		this.creDtm = creDtm;
	}
}
