package com.skb.adams.cm.model;

import java.io.Serializable;
import java.sql.Timestamp;

import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;

/**
 * @since 2017.11.29 14:03
 * @author subkjh autometic create by subkjh.dao
 *
 */

@FxTable(name = "OIV10709", comment = "SWING유선단말모델기본")
public class OIV10709 implements Serializable {

	public OIV10709() {
	}

	@FxColumn(name = "ACCS_CL_CD", size = 2, nullable = true, comment = "ACCS_CL_CD")
	private String accsClCd;

	@FxColumn(name = "APPL_WEQP_CD", size = 10, nullable = true, comment = "APPL_WEQP_CD")
	private String applWeqpCd;

	@FxColumn(name = "AUDIT_DTM", size = 0, comment = "AUDIT_DTM")
	private Timestamp auditDtm;

	@FxColumn(name = "AUDIT_ID", size = 15, comment = "AUDIT_ID")
	private String auditId;

	@FxColumn(name = "BARCD_CHK_YN", size = 1, nullable = true, comment = "BARCD_CHK_YN")
	private String barcdChkYn;

	@FxColumn(name = "CO_WEQP_GRP_CD", size = 4, nullable = true, comment = "CO_WEQP_GRP_CD")
	private String coWeqpGrpCd;

	@FxColumn(name = "MFACT_MDL_NM", size = 40, nullable = true, comment = "MFACT_MDL_NM")
	private String mfactMdlNm;

	@FxColumn(name = "MNUFACT_NAT_CL_CD", size = 2, nullable = true, comment = "MNUFACT_NAT_CL_CD")
	private String mnufactNatClCd;

	@FxColumn(name = "PRFER_WEQP_YN", size = 1, nullable = true, comment = "PRFER_WEQP_YN")
	private String prferWeqpYn;

	@FxColumn(name = "RMK", size = 200, nullable = true, comment = "RMK")
	private String rmk;

	@FxColumn(name = "SALE_EQP_YN", size = 1, nullable = true, comment = "SALE_EQP_YN")
	private String saleEqpYn;

	@FxColumn(name = "TECH_MTHD_NM", size = 20, nullable = true, comment = "TECH_MTHD_NM")
	private String techMthdNm;

	@FxColumn(name = "TOT_PORT_CNT", size = 3, nullable = true, comment = "TOT_PORT_CNT")
	private Number totPortCnt;

	@FxColumn(name = "USE_YN", size = 1, nullable = true, comment = "USE_YN")
	private String useYn;

	@FxColumn(name = "WEQP_ATTCHT_EXIST_YN", size = 1, nullable = true, comment = "WEQP_ATTCHT_EXIST_YN")
	private String weqpAttchtExistYn;

	@FxColumn(name = "WEQP_CHRTIC_CL_CD", size = 2, nullable = true, comment = "WEQP_CHRTIC_CL_CD")
	private String weqpChrticClCd;

	@FxColumn(name = "WEQP_DLVED_GDS_CO_CD", size = 3, nullable = true, comment = "WEQP_DLVED_GDS_CO_CD")
	private String weqpDlvedGdsCoCd;

	@FxColumn(name = "WEQP_ENG_NM", size = 40, nullable = true, comment = "WEQP_ENG_NM")
	private String weqpEngNm;

	@FxColumn(name = "WEQP_GRP_CD", size = 4, comment = "WEQP_GRP_CD")
	private String weqpGrpCd;

	@FxColumn(name = "WEQP_MDL_CD", size = 10, comment = "WEQP_MDL_CD")
	private String weqpMdlCd;

	@FxColumn(name = "WEQP_MDL_NM", size = 40, comment = "WEQP_MDL_NM")
	private String weqpMdlNm;

	@FxColumn(name = "WEQP_MNUFACT_CO_CD", size = 3, comment = "WEQP_MNUFACT_CO_CD")
	private String weqpMnufactCoCd;

	@FxColumn(name = "WEQP_RENT_CL_CD", size = 1, nullable = true, comment = "WEQP_RENT_CL_CD")
	private String weqpRentClCd;

	@FxColumn(name = "WEQP_STC_CL_CD", size = 10, nullable = true, comment = "WEQP_STC_CL_CD")
	private String weqpStcClCd;

	@FxColumn(name = "WEQP_UNIT_CD", size = 10, nullable = true, comment = "WEQP_UNIT_CD")
	private String weqpUnitCd;

	/**
	 * ACCS_CL_CD
	 * 
	 * @return ACCS_CL_CD
	 */
	public String getAccsClCd() {
		return accsClCd;
	}

	/**
	 * ACCS_CL_CD
	 *
	 * @param accsClCd
	 *            ACCS_CL_CD
	 */
	public void setAccsClCd(String accsClCd) {
		this.accsClCd = accsClCd;
	}

	/**
	 * APPL_WEQP_CD
	 * 
	 * @return APPL_WEQP_CD
	 */
	public String getApplWeqpCd() {
		return applWeqpCd;
	}

	/**
	 * APPL_WEQP_CD
	 *
	 * @param applWeqpCd
	 *            APPL_WEQP_CD
	 */
	public void setApplWeqpCd(String applWeqpCd) {
		this.applWeqpCd = applWeqpCd;
	}

	/**
	 * AUDIT_DTM
	 * 
	 * @return AUDIT_DTM
	 */
	public Timestamp getAuditDtm() {
		return auditDtm;
	}

	/**
	 * AUDIT_DTM
	 *
	 * @param auditDtm
	 *            AUDIT_DTM
	 */
	public void setAuditDtm(Timestamp auditDtm) {
		this.auditDtm = auditDtm;
	}

	/**
	 * AUDIT_ID
	 * 
	 * @return AUDIT_ID
	 */
	public String getAuditId() {
		return auditId;
	}

	/**
	 * AUDIT_ID
	 *
	 * @param auditId
	 *            AUDIT_ID
	 */
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	/**
	 * BARCD_CHK_YN
	 * 
	 * @return BARCD_CHK_YN
	 */
	public String isBarcdChkYn() {
		return barcdChkYn;
	}

	/**
	 * BARCD_CHK_YN
	 *
	 * @param barcdChkYn
	 *            BARCD_CHK_YN
	 */
	public void setBarcdChkYn(String barcdChkYn) {
		this.barcdChkYn = barcdChkYn;
	}

	/**
	 * CO_WEQP_GRP_CD
	 * 
	 * @return CO_WEQP_GRP_CD
	 */
	public String getCoWeqpGrpCd() {
		return coWeqpGrpCd;
	}

	/**
	 * CO_WEQP_GRP_CD
	 *
	 * @param coWeqpGrpCd
	 *            CO_WEQP_GRP_CD
	 */
	public void setCoWeqpGrpCd(String coWeqpGrpCd) {
		this.coWeqpGrpCd = coWeqpGrpCd;
	}

	/**
	 * MFACT_MDL_NM
	 * 
	 * @return MFACT_MDL_NM
	 */
	public String getMfactMdlNm() {
		return mfactMdlNm;
	}

	/**
	 * MFACT_MDL_NM
	 *
	 * @param mfactMdlNm
	 *            MFACT_MDL_NM
	 */
	public void setMfactMdlNm(String mfactMdlNm) {
		this.mfactMdlNm = mfactMdlNm;
	}

	/**
	 * MNUFACT_NAT_CL_CD
	 * 
	 * @return MNUFACT_NAT_CL_CD
	 */
	public String getMnufactNatClCd() {
		return mnufactNatClCd;
	}

	/**
	 * MNUFACT_NAT_CL_CD
	 *
	 * @param mnufactNatClCd
	 *            MNUFACT_NAT_CL_CD
	 */
	public void setMnufactNatClCd(String mnufactNatClCd) {
		this.mnufactNatClCd = mnufactNatClCd;
	}

	/**
	 * PRFER_WEQP_YN
	 * 
	 * @return PRFER_WEQP_YN
	 */
	public String isPrferWeqpYn() {
		return prferWeqpYn;
	}

	/**
	 * PRFER_WEQP_YN
	 *
	 * @param prferWeqpYn
	 *            PRFER_WEQP_YN
	 */
	public void setPrferWeqpYn(String prferWeqpYn) {
		this.prferWeqpYn = prferWeqpYn;
	}

	/**
	 * RMK
	 * 
	 * @return RMK
	 */
	public String getRmk() {
		return rmk;
	}

	/**
	 * RMK
	 *
	 * @param rmk
	 *            RMK
	 */
	public void setRmk(String rmk) {
		this.rmk = rmk;
	}

	/**
	 * SALE_EQP_YN
	 * 
	 * @return SALE_EQP_YN
	 */
	public String isSaleEqpYn() {
		return saleEqpYn;
	}

	/**
	 * SALE_EQP_YN
	 *
	 * @param saleEqpYn
	 *            SALE_EQP_YN
	 */
	public void setSaleEqpYn(String saleEqpYn) {
		this.saleEqpYn = saleEqpYn;
	}

	/**
	 * TECH_MTHD_NM
	 * 
	 * @return TECH_MTHD_NM
	 */
	public String getTechMthdNm() {
		return techMthdNm;
	}

	/**
	 * TECH_MTHD_NM
	 *
	 * @param techMthdNm
	 *            TECH_MTHD_NM
	 */
	public void setTechMthdNm(String techMthdNm) {
		this.techMthdNm = techMthdNm;
	}

	/**
	 * TOT_PORT_CNT
	 * 
	 * @return TOT_PORT_CNT
	 */
	public Number getTotPortCnt() {
		return totPortCnt;
	}

	/**
	 * TOT_PORT_CNT
	 *
	 * @param totPortCnt
	 *            TOT_PORT_CNT
	 */
	public void setTotPortCnt(Number totPortCnt) {
		this.totPortCnt = totPortCnt;
	}

	/**
	 * USE_YN
	 * 
	 * @return USE_YN
	 */
	public String isUseYn() {
		return useYn;
	}

	/**
	 * USE_YN
	 *
	 * @param useYn
	 *            USE_YN
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * WEQP_ATTCHT_EXIST_YN
	 * 
	 * @return WEQP_ATTCHT_EXIST_YN
	 */
	public String isWeqpAttchtExistYn() {
		return weqpAttchtExistYn;
	}

	/**
	 * WEQP_ATTCHT_EXIST_YN
	 *
	 * @param weqpAttchtExistYn
	 *            WEQP_ATTCHT_EXIST_YN
	 */
	public void setWeqpAttchtExistYn(String weqpAttchtExistYn) {
		this.weqpAttchtExistYn = weqpAttchtExistYn;
	}

	/**
	 * WEQP_CHRTIC_CL_CD
	 * 
	 * @return WEQP_CHRTIC_CL_CD
	 */
	public String getWeqpChrticClCd() {
		return weqpChrticClCd;
	}

	/**
	 * WEQP_CHRTIC_CL_CD
	 *
	 * @param weqpChrticClCd
	 *            WEQP_CHRTIC_CL_CD
	 */
	public void setWeqpChrticClCd(String weqpChrticClCd) {
		this.weqpChrticClCd = weqpChrticClCd;
	}

	/**
	 * WEQP_DLVED_GDS_CO_CD
	 * 
	 * @return WEQP_DLVED_GDS_CO_CD
	 */
	public String getWeqpDlvedGdsCoCd() {
		return weqpDlvedGdsCoCd;
	}

	/**
	 * WEQP_DLVED_GDS_CO_CD
	 *
	 * @param weqpDlvedGdsCoCd
	 *            WEQP_DLVED_GDS_CO_CD
	 */
	public void setWeqpDlvedGdsCoCd(String weqpDlvedGdsCoCd) {
		this.weqpDlvedGdsCoCd = weqpDlvedGdsCoCd;
	}

	/**
	 * WEQP_ENG_NM
	 * 
	 * @return WEQP_ENG_NM
	 */
	public String getWeqpEngNm() {
		return weqpEngNm;
	}

	/**
	 * WEQP_ENG_NM
	 *
	 * @param weqpEngNm
	 *            WEQP_ENG_NM
	 */
	public void setWeqpEngNm(String weqpEngNm) {
		this.weqpEngNm = weqpEngNm;
	}

	/**
	 * WEQP_GRP_CD
	 * 
	 * @return WEQP_GRP_CD
	 */
	public String getWeqpGrpCd() {
		return weqpGrpCd;
	}

	/**
	 * WEQP_GRP_CD
	 *
	 * @param weqpGrpCd
	 *            WEQP_GRP_CD
	 */
	public void setWeqpGrpCd(String weqpGrpCd) {
		this.weqpGrpCd = weqpGrpCd;
	}

	/**
	 * WEQP_MDL_CD
	 * 
	 * @return WEQP_MDL_CD
	 */
	public String getWeqpMdlCd() {
		return weqpMdlCd;
	}

	/**
	 * WEQP_MDL_CD
	 *
	 * @param weqpMdlCd
	 *            WEQP_MDL_CD
	 */
	public void setWeqpMdlCd(String weqpMdlCd) {
		this.weqpMdlCd = weqpMdlCd;
	}

	/**
	 * WEQP_MDL_NM
	 * 
	 * @return WEQP_MDL_NM
	 */
	public String getWeqpMdlNm() {
		return weqpMdlNm;
	}

	/**
	 * WEQP_MDL_NM
	 *
	 * @param weqpMdlNm
	 *            WEQP_MDL_NM
	 */
	public void setWeqpMdlNm(String weqpMdlNm) {
		this.weqpMdlNm = weqpMdlNm;
	}

	/**
	 * WEQP_MNUFACT_CO_CD
	 * 
	 * @return WEQP_MNUFACT_CO_CD
	 */
	public String getWeqpMnufactCoCd() {
		return weqpMnufactCoCd;
	}

	/**
	 * WEQP_MNUFACT_CO_CD
	 *
	 * @param weqpMnufactCoCd
	 *            WEQP_MNUFACT_CO_CD
	 */
	public void setWeqpMnufactCoCd(String weqpMnufactCoCd) {
		this.weqpMnufactCoCd = weqpMnufactCoCd;
	}

	/**
	 * WEQP_RENT_CL_CD
	 * 
	 * @return WEQP_RENT_CL_CD
	 */
	public String getWeqpRentClCd() {
		return weqpRentClCd;
	}

	/**
	 * WEQP_RENT_CL_CD
	 *
	 * @param weqpRentClCd
	 *            WEQP_RENT_CL_CD
	 */
	public void setWeqpRentClCd(String weqpRentClCd) {
		this.weqpRentClCd = weqpRentClCd;
	}

	/**
	 * WEQP_STC_CL_CD
	 * 
	 * @return WEQP_STC_CL_CD
	 */
	public String getWeqpStcClCd() {
		return weqpStcClCd;
	}

	/**
	 * WEQP_STC_CL_CD
	 *
	 * @param weqpStcClCd
	 *            WEQP_STC_CL_CD
	 */
	public void setWeqpStcClCd(String weqpStcClCd) {
		this.weqpStcClCd = weqpStcClCd;
	}

	/**
	 * WEQP_UNIT_CD
	 * 
	 * @return WEQP_UNIT_CD
	 */
	public String getWeqpUnitCd() {
		return weqpUnitCd;
	}

	/**
	 * WEQP_UNIT_CD
	 *
	 * @param weqpUnitCd
	 *            WEQP_UNIT_CD
	 */
	public void setWeqpUnitCd(String weqpUnitCd) {
		this.weqpUnitCd = weqpUnitCd;
	}
}
