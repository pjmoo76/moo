package com.skb.adams.cm.model;

import java.io.Serializable;
import java.sql.Timestamp;

import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;

/**
 * @since 2017.11.29 14:03
 * @author subkjh autometic create by subkjh.dao
 *
 */

@FxTable(name = "OIV10809", comment = "SWING유선단말기본")
public class OIV10809 implements Serializable {

	public OIV10809() {
	}

	@FxColumn(name = "AGRMT_ID", size = 15, nullable = true, comment = "AGRMT_ID")
	private String agrmtId;

	@FxColumn(name = "ASSET_MGMT_CL_CD", size = 1, nullable = true, comment = "ASSET_MGMT_CL_CD")
	private String assetMgmtClCd;

	@FxColumn(name = "ASSET_NUM", size = 22, nullable = true, comment = "ASSET_NUM")
	private String assetNum;

	@FxColumn(name = "AUDIT_DTM", size = 0, comment = "AUDIT_DTM")
	private Timestamp auditDtm;

	@FxColumn(name = "AUDIT_ID", size = 15, comment = "AUDIT_ID")
	private String auditId;

	@FxColumn(name = "BF_WEQP_MGMT_NUM", size = 22, nullable = true, comment = "BF_WEQP_MGMT_NUM")
	private String bfWeqpMgmtNum;

	@FxColumn(name = "CRE_DTM", size = 14, nullable = true, comment = "CRE_DTM")
	private String creDtm;

	@FxColumn(name = "CRTR_ID", size = 10, nullable = true, comment = "CRTR_ID")
	private String crtrId;

	@FxColumn(name = "DSNET_ORG_ID", size = 10, nullable = true, comment = "DSNET_ORG_ID")
	private String dsnetOrgId;

	@FxColumn(name = "IWEI_NUM", size = 18, nullable = true, comment = "IWEI_NUM")
	private String iweiNum;

	@FxColumn(name = "MAC_ADDR_VAL", size = 12, nullable = true, comment = "MAC_ADDR_VAL")
	private String macAddrVal;

	@FxColumn(name = "MFACT_SER_NUM", size = 15, nullable = true, comment = "MFACT_SER_NUM")
	private String mfactSerNum;

	@FxColumn(name = "QLTY_GRT_TRM_EXPIR_DT", size = 8, nullable = true, comment = "QLTY_GRT_TRM_EXPIR_DT")
	private String qltyGrtTrmExpirDt;

	@FxColumn(name = "REP_SVC_MGMT_NUM", size = 10, nullable = true, comment = "REP_SVC_MGMT_NUM")
	private Number repSvcMgmtNum;

	@FxColumn(name = "SALE_CHRGR_ID", size = 15, nullable = true, comment = "SALE_CHRGR_ID")
	private String saleChrgrId;

	@FxColumn(name = "SALE_DSNET_ORG_ID", size = 10, nullable = true, comment = "SALE_DSNET_ORG_ID")
	private String saleDsnetOrgId;

	@FxColumn(name = "SALE_DT", size = 8, nullable = true, comment = "SALE_DT")
	private String saleDt;

	@FxColumn(name = "SALE_PSBL_YN", size = 1, nullable = true, comment = "SALE_PSBL_YN")
	private String salePsblYn;

	@FxColumn(name = "SALE_RCP_NUM", size = 20, nullable = true, comment = "SALE_RCP_NUM")
	private String saleRcpNum;

	@FxColumn(name = "ST_FLU_DT", size = 8, nullable = true, comment = "ST_FLU_DT")
	private String stFluDt;

	@FxColumn(name = "VOICE_MAC_ADDR_VAL", size = 14, nullable = true, comment = "VOICE_MAC_ADDR_VAL")
	private String voiceMacAddrVal;

	@FxColumn(name = "WEQP_CL_CD", size = 1, nullable = true, comment = "WEQP_CL_CD")
	private String weqpClCd;

	@FxColumn(name = "WEQP_GR", size = 1, nullable = true, comment = "WEQP_GR")
	private String weqpGr;

	@FxColumn(name = "WEQP_GRP_CD", size = 4, nullable = true, comment = "WEQP_GRP_CD")
	private String weqpGrpCd;

	@FxColumn(name = "WEQP_HST_CL_CD", size = 5, nullable = true, comment = "WEQP_HST_CL_CD")
	private String weqpHstClCd;

	@FxColumn(name = "WEQP_HST_NUM", size = 15, nullable = true, comment = "WEQP_HST_NUM")
	private Number weqpHstNum;

	@FxColumn(name = "WEQP_LOC_CL_CD", size = 2, nullable = true, comment = "WEQP_LOC_CL_CD")
	private String weqpLocClCd;

	@FxColumn(name = "WEQP_LOC_ID", size = 10, nullable = true, comment = "WEQP_LOC_ID")
	private String weqpLocId;

	@FxColumn(name = "WEQP_MDL_CD", size = 10, comment = "WEQP_MDL_CD")
	private String weqpMdlCd;

	@FxColumn(name = "WEQP_MGMT_NUM", size = 22, comment = "WEQP_MGMT_NUM")
	private String weqpMgmtNum;

	@FxColumn(name = "WEQP_ORD_NUM", size = 20, comment = "WEQP_ORD_NUM")
	private String weqpOrdNum;

	@FxColumn(name = "WEQP_SET_LOC_CD", size = 3, nullable = true, comment = "WEQP_SET_LOC_CD")
	private String weqpSetLocCd;

	@FxColumn(name = "WEQP_SET_LOC_CTT", size = 20, nullable = true, comment = "WEQP_SET_LOC_CTT")
	private String weqpSetLocCtt;

	@FxColumn(name = "WEQP_ST_CD", size = 2, nullable = true, comment = "WEQP_ST_CD")
	private String weqpStCd;

	@FxColumn(name = "WEQP_USE_PERM_YN", size = 1, nullable = true, comment = "WEQP_USE_PERM_YN")
	private String weqpUsePermYn;

	/**
	 * AGRMT_ID
	 * 
	 * @return AGRMT_ID
	 */
	public String getAgrmtId() {
		return agrmtId;
	}

	/**
	 * AGRMT_ID
	 *
	 * @param agrmtId
	 *            AGRMT_ID
	 */
	public void setAgrmtId(String agrmtId) {
		this.agrmtId = agrmtId;
	}

	/**
	 * ASSET_MGMT_CL_CD
	 * 
	 * @return ASSET_MGMT_CL_CD
	 */
	public String getAssetMgmtClCd() {
		return assetMgmtClCd;
	}

	/**
	 * ASSET_MGMT_CL_CD
	 *
	 * @param assetMgmtClCd
	 *            ASSET_MGMT_CL_CD
	 */
	public void setAssetMgmtClCd(String assetMgmtClCd) {
		this.assetMgmtClCd = assetMgmtClCd;
	}

	/**
	 * ASSET_NUM
	 * 
	 * @return ASSET_NUM
	 */
	public String getAssetNum() {
		return assetNum;
	}

	/**
	 * ASSET_NUM
	 *
	 * @param assetNum
	 *            ASSET_NUM
	 */
	public void setAssetNum(String assetNum) {
		this.assetNum = assetNum;
	}

	/**
	 * AUDIT_DTM
	 * 
	 * @return AUDIT_DTM
	 */
	public Timestamp getAuditDtm() {
		return auditDtm;
	}

	/**
	 * AUDIT_DTM
	 *
	 * @param auditDtm
	 *            AUDIT_DTM
	 */
	public void setAuditDtm(Timestamp auditDtm) {
		this.auditDtm = auditDtm;
	}

	/**
	 * AUDIT_ID
	 * 
	 * @return AUDIT_ID
	 */
	public String getAuditId() {
		return auditId;
	}

	/**
	 * AUDIT_ID
	 *
	 * @param auditId
	 *            AUDIT_ID
	 */
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	/**
	 * BF_WEQP_MGMT_NUM
	 * 
	 * @return BF_WEQP_MGMT_NUM
	 */
	public String getBfWeqpMgmtNum() {
		return bfWeqpMgmtNum;
	}

	/**
	 * BF_WEQP_MGMT_NUM
	 *
	 * @param bfWeqpMgmtNum
	 *            BF_WEQP_MGMT_NUM
	 */
	public void setBfWeqpMgmtNum(String bfWeqpMgmtNum) {
		this.bfWeqpMgmtNum = bfWeqpMgmtNum;
	}

	/**
	 * CRE_DTM
	 * 
	 * @return CRE_DTM
	 */
	public String getCreDtm() {
		return creDtm;
	}

	/**
	 * CRE_DTM
	 *
	 * @param creDtm
	 *            CRE_DTM
	 */
	public void setCreDtm(String creDtm) {
		this.creDtm = creDtm;
	}

	/**
	 * CRTR_ID
	 * 
	 * @return CRTR_ID
	 */
	public String getCrtrId() {
		return crtrId;
	}

	/**
	 * CRTR_ID
	 *
	 * @param crtrId
	 *            CRTR_ID
	 */
	public void setCrtrId(String crtrId) {
		this.crtrId = crtrId;
	}

	/**
	 * DSNET_ORG_ID
	 * 
	 * @return DSNET_ORG_ID
	 */
	public String getDsnetOrgId() {
		return dsnetOrgId;
	}

	/**
	 * DSNET_ORG_ID
	 *
	 * @param dsnetOrgId
	 *            DSNET_ORG_ID
	 */
	public void setDsnetOrgId(String dsnetOrgId) {
		this.dsnetOrgId = dsnetOrgId;
	}

	/**
	 * IWEI_NUM
	 * 
	 * @return IWEI_NUM
	 */
	public String getIweiNum() {
		return iweiNum;
	}

	/**
	 * IWEI_NUM
	 *
	 * @param iweiNum
	 *            IWEI_NUM
	 */
	public void setIweiNum(String iweiNum) {
		this.iweiNum = iweiNum;
	}

	/**
	 * MAC_ADDR_VAL
	 * 
	 * @return MAC_ADDR_VAL
	 */
	public String getMacAddrVal() {
		return macAddrVal;
	}

	/**
	 * MAC_ADDR_VAL
	 *
	 * @param macAddrVal
	 *            MAC_ADDR_VAL
	 */
	public void setMacAddrVal(String macAddrVal) {
		this.macAddrVal = macAddrVal;
	}

	/**
	 * MFACT_SER_NUM
	 * 
	 * @return MFACT_SER_NUM
	 */
	public String getMfactSerNum() {
		return mfactSerNum;
	}

	/**
	 * MFACT_SER_NUM
	 *
	 * @param mfactSerNum
	 *            MFACT_SER_NUM
	 */
	public void setMfactSerNum(String mfactSerNum) {
		this.mfactSerNum = mfactSerNum;
	}

	/**
	 * QLTY_GRT_TRM_EXPIR_DT
	 * 
	 * @return QLTY_GRT_TRM_EXPIR_DT
	 */
	public String getQltyGrtTrmExpirDt() {
		return qltyGrtTrmExpirDt;
	}

	/**
	 * QLTY_GRT_TRM_EXPIR_DT
	 *
	 * @param qltyGrtTrmExpirDt
	 *            QLTY_GRT_TRM_EXPIR_DT
	 */
	public void setQltyGrtTrmExpirDt(String qltyGrtTrmExpirDt) {
		this.qltyGrtTrmExpirDt = qltyGrtTrmExpirDt;
	}

	/**
	 * REP_SVC_MGMT_NUM
	 * 
	 * @return REP_SVC_MGMT_NUM
	 */
	public Number getRepSvcMgmtNum() {
		return repSvcMgmtNum;
	}

	/**
	 * REP_SVC_MGMT_NUM
	 *
	 * @param repSvcMgmtNum
	 *            REP_SVC_MGMT_NUM
	 */
	public void setRepSvcMgmtNum(Number repSvcMgmtNum) {
		this.repSvcMgmtNum = repSvcMgmtNum;
	}

	/**
	 * SALE_CHRGR_ID
	 * 
	 * @return SALE_CHRGR_ID
	 */
	public String getSaleChrgrId() {
		return saleChrgrId;
	}

	/**
	 * SALE_CHRGR_ID
	 *
	 * @param saleChrgrId
	 *            SALE_CHRGR_ID
	 */
	public void setSaleChrgrId(String saleChrgrId) {
		this.saleChrgrId = saleChrgrId;
	}

	/**
	 * SALE_DSNET_ORG_ID
	 * 
	 * @return SALE_DSNET_ORG_ID
	 */
	public String getSaleDsnetOrgId() {
		return saleDsnetOrgId;
	}

	/**
	 * SALE_DSNET_ORG_ID
	 *
	 * @param saleDsnetOrgId
	 *            SALE_DSNET_ORG_ID
	 */
	public void setSaleDsnetOrgId(String saleDsnetOrgId) {
		this.saleDsnetOrgId = saleDsnetOrgId;
	}

	/**
	 * SALE_DT
	 * 
	 * @return SALE_DT
	 */
	public String getSaleDt() {
		return saleDt;
	}

	/**
	 * SALE_DT
	 *
	 * @param saleDt
	 *            SALE_DT
	 */
	public void setSaleDt(String saleDt) {
		this.saleDt = saleDt;
	}

	/**
	 * SALE_PSBL_YN
	 * 
	 * @return SALE_PSBL_YN
	 */
	public String isSalePsblYn() {
		return salePsblYn;
	}

	/**
	 * SALE_PSBL_YN
	 *
	 * @param salePsblYn
	 *            SALE_PSBL_YN
	 */
	public void setSalePsblYn(String salePsblYn) {
		this.salePsblYn = salePsblYn;
	}

	/**
	 * SALE_RCP_NUM
	 * 
	 * @return SALE_RCP_NUM
	 */
	public String getSaleRcpNum() {
		return saleRcpNum;
	}

	/**
	 * SALE_RCP_NUM
	 *
	 * @param saleRcpNum
	 *            SALE_RCP_NUM
	 */
	public void setSaleRcpNum(String saleRcpNum) {
		this.saleRcpNum = saleRcpNum;
	}

	/**
	 * ST_FLU_DT
	 * 
	 * @return ST_FLU_DT
	 */
	public String getStFluDt() {
		return stFluDt;
	}

	/**
	 * ST_FLU_DT
	 *
	 * @param stFluDt
	 *            ST_FLU_DT
	 */
	public void setStFluDt(String stFluDt) {
		this.stFluDt = stFluDt;
	}

	/**
	 * VOICE_MAC_ADDR_VAL
	 * 
	 * @return VOICE_MAC_ADDR_VAL
	 */
	public String getVoiceMacAddrVal() {
		return voiceMacAddrVal;
	}

	/**
	 * VOICE_MAC_ADDR_VAL
	 *
	 * @param voiceMacAddrVal
	 *            VOICE_MAC_ADDR_VAL
	 */
	public void setVoiceMacAddrVal(String voiceMacAddrVal) {
		this.voiceMacAddrVal = voiceMacAddrVal;
	}

	/**
	 * WEQP_CL_CD
	 * 
	 * @return WEQP_CL_CD
	 */
	public String getWeqpClCd() {
		return weqpClCd;
	}

	/**
	 * WEQP_CL_CD
	 *
	 * @param weqpClCd
	 *            WEQP_CL_CD
	 */
	public void setWeqpClCd(String weqpClCd) {
		this.weqpClCd = weqpClCd;
	}

	/**
	 * WEQP_GR
	 * 
	 * @return WEQP_GR
	 */
	public String getWeqpGr() {
		return weqpGr;
	}

	/**
	 * WEQP_GR
	 *
	 * @param weqpGr
	 *            WEQP_GR
	 */
	public void setWeqpGr(String weqpGr) {
		this.weqpGr = weqpGr;
	}

	/**
	 * WEQP_GRP_CD
	 * 
	 * @return WEQP_GRP_CD
	 */
	public String getWeqpGrpCd() {
		return weqpGrpCd;
	}

	/**
	 * WEQP_GRP_CD
	 *
	 * @param weqpGrpCd
	 *            WEQP_GRP_CD
	 */
	public void setWeqpGrpCd(String weqpGrpCd) {
		this.weqpGrpCd = weqpGrpCd;
	}

	/**
	 * WEQP_HST_CL_CD
	 * 
	 * @return WEQP_HST_CL_CD
	 */
	public String getWeqpHstClCd() {
		return weqpHstClCd;
	}

	/**
	 * WEQP_HST_CL_CD
	 *
	 * @param weqpHstClCd
	 *            WEQP_HST_CL_CD
	 */
	public void setWeqpHstClCd(String weqpHstClCd) {
		this.weqpHstClCd = weqpHstClCd;
	}

	/**
	 * WEQP_HST_NUM
	 * 
	 * @return WEQP_HST_NUM
	 */
	public Number getWeqpHstNum() {
		return weqpHstNum;
	}

	/**
	 * WEQP_HST_NUM
	 *
	 * @param weqpHstNum
	 *            WEQP_HST_NUM
	 */
	public void setWeqpHstNum(Number weqpHstNum) {
		this.weqpHstNum = weqpHstNum;
	}

	/**
	 * WEQP_LOC_CL_CD
	 * 
	 * @return WEQP_LOC_CL_CD
	 */
	public String getWeqpLocClCd() {
		return weqpLocClCd;
	}

	/**
	 * WEQP_LOC_CL_CD
	 *
	 * @param weqpLocClCd
	 *            WEQP_LOC_CL_CD
	 */
	public void setWeqpLocClCd(String weqpLocClCd) {
		this.weqpLocClCd = weqpLocClCd;
	}

	/**
	 * WEQP_LOC_ID
	 * 
	 * @return WEQP_LOC_ID
	 */
	public String getWeqpLocId() {
		return weqpLocId;
	}

	/**
	 * WEQP_LOC_ID
	 *
	 * @param weqpLocId
	 *            WEQP_LOC_ID
	 */
	public void setWeqpLocId(String weqpLocId) {
		this.weqpLocId = weqpLocId;
	}

	/**
	 * WEQP_MDL_CD
	 * 
	 * @return WEQP_MDL_CD
	 */
	public String getWeqpMdlCd() {
		return weqpMdlCd;
	}

	/**
	 * WEQP_MDL_CD
	 *
	 * @param weqpMdlCd
	 *            WEQP_MDL_CD
	 */
	public void setWeqpMdlCd(String weqpMdlCd) {
		this.weqpMdlCd = weqpMdlCd;
	}

	/**
	 * WEQP_MGMT_NUM
	 * 
	 * @return WEQP_MGMT_NUM
	 */
	public String getWeqpMgmtNum() {
		return weqpMgmtNum;
	}

	/**
	 * WEQP_MGMT_NUM
	 *
	 * @param weqpMgmtNum
	 *            WEQP_MGMT_NUM
	 */
	public void setWeqpMgmtNum(String weqpMgmtNum) {
		this.weqpMgmtNum = weqpMgmtNum;
	}

	/**
	 * WEQP_ORD_NUM
	 * 
	 * @return WEQP_ORD_NUM
	 */
	public String getWeqpOrdNum() {
		return weqpOrdNum;
	}

	/**
	 * WEQP_ORD_NUM
	 *
	 * @param weqpOrdNum
	 *            WEQP_ORD_NUM
	 */
	public void setWeqpOrdNum(String weqpOrdNum) {
		this.weqpOrdNum = weqpOrdNum;
	}

	/**
	 * WEQP_SET_LOC_CD
	 * 
	 * @return WEQP_SET_LOC_CD
	 */
	public String getWeqpSetLocCd() {
		return weqpSetLocCd;
	}

	/**
	 * WEQP_SET_LOC_CD
	 *
	 * @param weqpSetLocCd
	 *            WEQP_SET_LOC_CD
	 */
	public void setWeqpSetLocCd(String weqpSetLocCd) {
		this.weqpSetLocCd = weqpSetLocCd;
	}

	/**
	 * WEQP_SET_LOC_CTT
	 * 
	 * @return WEQP_SET_LOC_CTT
	 */
	public String getWeqpSetLocCtt() {
		return weqpSetLocCtt;
	}

	/**
	 * WEQP_SET_LOC_CTT
	 *
	 * @param weqpSetLocCtt
	 *            WEQP_SET_LOC_CTT
	 */
	public void setWeqpSetLocCtt(String weqpSetLocCtt) {
		this.weqpSetLocCtt = weqpSetLocCtt;
	}

	/**
	 * WEQP_ST_CD
	 * 
	 * @return WEQP_ST_CD
	 */
	public String getWeqpStCd() {
		return weqpStCd;
	}

	/**
	 * WEQP_ST_CD
	 *
	 * @param weqpStCd
	 *            WEQP_ST_CD
	 */
	public void setWeqpStCd(String weqpStCd) {
		this.weqpStCd = weqpStCd;
	}

	/**
	 * WEQP_USE_PERM_YN
	 * 
	 * @return WEQP_USE_PERM_YN
	 */
	public String isWeqpUsePermYn() {
		return weqpUsePermYn;
	}

	/**
	 * WEQP_USE_PERM_YN
	 *
	 * @param weqpUsePermYn
	 *            WEQP_USE_PERM_YN
	 */
	public void setWeqpUsePermYn(String weqpUsePermYn) {
		this.weqpUsePermYn = weqpUsePermYn;
	}
}
