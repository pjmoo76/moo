package com.skb.adams.cm.model;

import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;

import java.io.Serializable;
import java.sql.Timestamp;

/**
* @since 2018.09.26 14:09
* @author subkjh 
* autometic create by subkjh.dao 
*
*/


@FxTable(name = "OES30100", comment = "주소기본")
public class OES30100 implements Serializable {

/**
	 * 
	 */
	private static final long serialVersionUID = -6636168135191909784L;


public OES30100() {
 }

@FxColumn(name = "ADDR_ID", size = 15, comment = "주소ID")
private String addrId;


@FxColumn(name = "AUDIT_ID", size = 15, comment = "최종변경자ID")
private String auditId;


@FxColumn(name = "AUDIT_DTM", size = 0, comment = "최종변경일시")
private Timestamp auditDtm;


@FxColumn(name = "EFF_STA_DT", size = 8, nullable = true, comment = "유효시작일자")
private String effStaDt;


@FxColumn(name = "EFF_END_DT", size = 8, nullable = true, comment = "유효종료일자")
private String effEndDt;


@FxColumn(name = "LDONG_CD", size = 10, nullable = true, comment = "법정동코드")
private String ldongCd;


@FxColumn(name = "HOUSE_NUM_TYP_CD", size = 1, nullable = true, comment = "번지유형코드")
private String houseNumTypCd;


@FxColumn(name = "MAIN_HOUSE_NUM_CTT", size = 40, nullable = true, comment = "메인번지내용")
private String mainHouseNumCtt;


@FxColumn(name = "SUB_HOUSE_NUM_CTT", size = 40, nullable = true, comment = "서브번지내용")
private String subHouseNumCtt;


@FxColumn(name = "BLD_CD", size = 15, nullable = true, comment = "건물코드")
private String bldCd;


@FxColumn(name = "ST_NM_CD", size = 12, nullable = true, comment = "도로명코드")
private String stNmCd;


@FxColumn(name = "BLD_MAIN_NUM", size = 10, nullable = true, comment = "건물메인번호")
private String bldMainNum;


@FxColumn(name = "BLD_SUB_NUM", size = 10, nullable = true, comment = "건물서브번호")
private String bldSubNum;


/**
* 주소ID
* @return 주소ID
*/
public String getAddrId() {
return addrId;
}
/**
* 주소ID
*@param addrId 주소ID
*/
public void setAddrId(String addrId) {
	this.addrId = addrId;
}
/**
* 최종변경자ID
* @return 최종변경자ID
*/
public String getAuditId() {
return auditId;
}
/**
* 최종변경자ID
*@param auditId 최종변경자ID
*/
public void setAuditId(String auditId) {
	this.auditId = auditId;
}
/**
* 최종변경일시
* @return 최종변경일시
*/
public Timestamp getAuditDtm() {
return auditDtm;
}
/**
* 최종변경일시
*@param auditDtm 최종변경일시
*/
public void setAuditDtm(Timestamp auditDtm) {
	this.auditDtm = auditDtm;
}
/**
* 유효시작일자
* @return 유효시작일자
*/
public String getEffStaDt() {
return effStaDt;
}
/**
* 유효시작일자
*@param effStaDt 유효시작일자
*/
public void setEffStaDt(String effStaDt) {
	this.effStaDt = effStaDt;
}
/**
* 유효종료일자
* @return 유효종료일자
*/
public String getEffEndDt() {
return effEndDt;
}
/**
* 유효종료일자
*@param effEndDt 유효종료일자
*/
public void setEffEndDt(String effEndDt) {
	this.effEndDt = effEndDt;
}
/**
* 법정동코드
* @return 법정동코드
*/
public String getLdongCd() {
return ldongCd;
}
/**
* 법정동코드
*@param ldongCd 법정동코드
*/
public void setLdongCd(String ldongCd) {
	this.ldongCd = ldongCd;
}
/**
* 번지유형코드
* @return 번지유형코드
*/
public String getHouseNumTypCd() {
return houseNumTypCd;
}
/**
* 번지유형코드
*@param houseNumTypCd 번지유형코드
*/
public void setHouseNumTypCd(String houseNumTypCd) {
	this.houseNumTypCd = houseNumTypCd;
}
/**
* 메인번지내용
* @return 메인번지내용
*/
public String getMainHouseNumCtt() {
return mainHouseNumCtt;
}
/**
* 메인번지내용
*@param mainHouseNumCtt 메인번지내용
*/
public void setMainHouseNumCtt(String mainHouseNumCtt) {
	this.mainHouseNumCtt = mainHouseNumCtt;
}
/**
* 서브번지내용
* @return 서브번지내용
*/
public String getSubHouseNumCtt() {
return subHouseNumCtt;
}
/**
* 서브번지내용
*@param subHouseNumCtt 서브번지내용
*/
public void setSubHouseNumCtt(String subHouseNumCtt) {
	this.subHouseNumCtt = subHouseNumCtt;
}
/**
* 건물코드
* @return 건물코드
*/
public String getBldCd() {
return bldCd;
}
/**
* 건물코드
*@param bldCd 건물코드
*/
public void setBldCd(String bldCd) {
	this.bldCd = bldCd;
}
/**
* 도로명코드
* @return 도로명코드
*/
public String getStNmCd() {
return stNmCd;
}
/**
* 도로명코드
*@param stNmCd 도로명코드
*/
public void setStNmCd(String stNmCd) {
	this.stNmCd = stNmCd;
}
/**
* 건물메인번호
* @return 건물메인번호
*/
public String getBldMainNum() {
return bldMainNum;
}
/**
* 건물메인번호
*@param bldMainNum 건물메인번호
*/
public void setBldMainNum(String bldMainNum) {
	this.bldMainNum = bldMainNum;
}
/**
* 건물서브번호
* @return 건물서브번호
*/
public String getBldSubNum() {
return bldSubNum;
}
/**
* 건물서브번호
*@param bldSubNum 건물서브번호
*/
public void setBldSubNum(String bldSubNum) {
	this.bldSubNum = bldSubNum;
}
}