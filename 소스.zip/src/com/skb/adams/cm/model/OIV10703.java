package com.skb.adams.cm.model;

import java.io.Serializable;
import java.sql.Timestamp;

import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;

/**
 * @since 2017.11.30 11:09
 * @author subkjh autometic create by subkjh.dao
 *
 */

@FxTable(name = "OIV10703", comment = "유선단말제조사")
public class OIV10703 implements Serializable {

	public OIV10703() {
	}

	@FxColumn(name = "WEQP_MNUFACT_CO_CD", size = 3, comment = "유선단말제조업체코드")
	private String weqpMnufactCoCd;

	@FxColumn(name = "AUDIT_ID", size = 15, comment = "최종변경자ID")
	private String auditId;

	@FxColumn(name = "AUDIT_DTM", size = 0, comment = "최종변경일시", defValue = "SYSDATE")
	private Timestamp auditDtm = null;

	@FxColumn(name = "WEQP_MNUFACT_CO_NM", size = 40, comment = "유선단말제조업체명")
	private String weqpMnufactCoNm;

	/**
	 * 유선단말제조업체코드
	 * 
	 * @return 유선단말제조업체코드
	 */
	public String getWeqpMnufactCoCd() {
		return weqpMnufactCoCd;
	}

	/**
	 * 유선단말제조업체코드
	 *
	 * @param weqpMnufactCoCd
	 *            유선단말제조업체코드
	 */
	public void setWeqpMnufactCoCd(String weqpMnufactCoCd) {
		this.weqpMnufactCoCd = weqpMnufactCoCd;
	}

	/**
	 * 최종변경자ID
	 * 
	 * @return 최종변경자ID
	 */
	public String getAuditId() {
		return auditId;
	}

	/**
	 * 최종변경자ID
	 *
	 * @param auditId
	 *            최종변경자ID
	 */
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	/**
	 * 최종변경일시
	 * 
	 * @return 최종변경일시
	 */
	public Timestamp getAuditDtm() {
		return auditDtm;
	}

	/**
	 * 최종변경일시
	 *
	 * @param auditDtm
	 *            최종변경일시
	 */
	public void setAuditDtm(Timestamp auditDtm) {
		this.auditDtm = auditDtm;
	}

	/**
	 * 유선단말제조업체명
	 * 
	 * @return 유선단말제조업체명
	 */
	public String getWeqpMnufactCoNm() {
		return weqpMnufactCoNm;
	}

	/**
	 * 유선단말제조업체명
	 *
	 * @param weqpMnufactCoNm
	 *            유선단말제조업체명
	 */
	public void setWeqpMnufactCoNm(String weqpMnufactCoNm) {
		this.weqpMnufactCoNm = weqpMnufactCoNm;
	}
}
