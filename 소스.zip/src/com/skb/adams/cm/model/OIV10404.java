package com.skb.adams.cm.model;

public class OIV10404 {
	private	String	linkId;
	private	int		thruSerNum;
	private	long	svcMgmtNum;
	
	public void OIV10404() {
		
	}

	public String getLinkId() {
		return linkId;
	}

	public void setLinkId(String linkId) {
		this.linkId = linkId;
	}

	public int getThruSerNum() {
		return thruSerNum;
	}

	public void setThruSerNum(int thruSerNum) {
		this.thruSerNum = thruSerNum;
	}

	public long getSvcMgmtNum() {
		return svcMgmtNum;
	}

	public void setSvcMgmtNum(long svcMgmtNum) {
		this.svcMgmtNum = svcMgmtNum;
	}

}
