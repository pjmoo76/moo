package com.skb.adams.cm.model;

import java.io.Serializable;
import java.sql.Timestamp;

import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;

/**
 * @since 2017.11.29 14:03
 * @author subkjh autometic create by subkjh.dao
 *
 */

@FxTable(name = "OIV10208", comment = "SWING장비모델기본")
public class OIV10208 implements Serializable {

	public OIV10208() {
	}

	@FxColumn(name = "ALT_ITM_APLY_OBJ_YN", size = 1, nullable = true, comment = "ALT_ITM_APLY_OBJ_YN")
	private String altItmAplyObjYn;

	@FxColumn(name = "AUDIT_DTM", size = 0, comment = "AUDIT_DTM")
	private Timestamp auditDtm;

	@FxColumn(name = "AUDIT_ID", size = 15, comment = "AUDIT_ID")
	private String auditId;

	@FxColumn(name = "CONS_ITM_TYP_CD", size = 2, nullable = true, comment = "CONS_ITM_TYP_CD")
	private String consItmTypCd;

	@FxColumn(name = "EQUIP_CD", size = 10, comment = "EQUIP_CD")
	private String equipCd;

	@FxColumn(name = "EQUIP_DPLXG_YN", size = 1, nullable = true, comment = "EQUIP_DPLXG_YN")
	private String equipDplxgYn;

	@FxColumn(name = "EQUIP_DTLS_DESC", size = 500, nullable = true, comment = "EQUIP_DTLS_DESC")
	private String equipDtlsDesc;

	@FxColumn(name = "EQUIP_INTDC_YM", size = 6, nullable = true, comment = "EQUIP_INTDC_YM")
	private String equipIntdcYm;

	@FxColumn(name = "EQUIP_MDL_NM", size = 40, nullable = true, comment = "EQUIP_MDL_NM")
	private String equipMdlNm;

	@FxColumn(name = "EQUIP_MFACT_CD", size = 3, nullable = true, comment = "EQUIP_MFACT_CD")
	private String equipMfactCd;

	@FxColumn(name = "EQUIP_NM", size = 40, nullable = true, comment = "EQUIP_NM")
	private String equipNm;

	@FxColumn(name = "EQUIP_RPR_PRD", size = 5, nullable = true, comment = "EQUIP_RPR_PRD")
	private Number equipRprPrd;

	@FxColumn(name = "EQUIP_TYP_CD", size = 4, nullable = true, comment = "EQUIP_TYP_CD")
	private String equipTypCd;

	@FxColumn(name = "EQUIP_UNIT_CD", size = 6, nullable = true, comment = "EQUIP_UNIT_CD")
	private String equipUnitCd;

	@FxColumn(name = "EQUIP_UNIT_PRC", size = 15, nullable = true, comment = "EQUIP_UNIT_PRC")
	private Number equipUnitPrc;

	@FxColumn(name = "FCLT_DLVED_GDS_CO_CD", size = 3, nullable = true, comment = "FCLT_DLVED_GDS_CO_CD")
	private String fcltDlvedGdsCoCd;

	@FxColumn(name = "FIN_ASSET_CD", size = 10, nullable = true, comment = "FIN_ASSET_CD")
	private String finAssetCd;

	@FxColumn(name = "INI_ALT_ITM_APLY_RT", size = 5, nullable = true, comment = "INI_ALT_ITM_APLY_RT")
	private Number iniAltItmAplyRt;

	@FxColumn(name = "SCARD_USE_USG_CD", size = 2, nullable = true, comment = "SCARD_USE_USG_CD")
	private String scardUseUsgCd;

	@FxColumn(name = "SRGT_SCARD_EQUIP_CD", size = 10, nullable = true, comment = "SRGT_SCARD_EQUIP_CD")
	private String srgtScardEquipCd;

	@FxColumn(name = "SVC_INFLU_YN", size = 1, nullable = true, comment = "SVC_INFLU_YN")
	private String svcInfluYn;

	/**
	 * ALT_ITM_APLY_OBJ_YN
	 * 
	 * @return ALT_ITM_APLY_OBJ_YN
	 */
	public String isAltItmAplyObjYn() {
		return altItmAplyObjYn;
	}

	/**
	 * ALT_ITM_APLY_OBJ_YN
	 *
	 * @param altItmAplyObjYn
	 *            ALT_ITM_APLY_OBJ_YN
	 */
	public void setAltItmAplyObjYn(String altItmAplyObjYn) {
		this.altItmAplyObjYn = altItmAplyObjYn;
	}

	/**
	 * AUDIT_DTM
	 * 
	 * @return AUDIT_DTM
	 */
	public Timestamp getAuditDtm() {
		return auditDtm;
	}

	/**
	 * AUDIT_DTM
	 *
	 * @param auditDtm
	 *            AUDIT_DTM
	 */
	public void setAuditDtm(Timestamp auditDtm) {
		this.auditDtm = auditDtm;
	}

	/**
	 * AUDIT_ID
	 * 
	 * @return AUDIT_ID
	 */
	public String getAuditId() {
		return auditId;
	}

	/**
	 * AUDIT_ID
	 *
	 * @param auditId
	 *            AUDIT_ID
	 */
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	/**
	 * CONS_ITM_TYP_CD
	 * 
	 * @return CONS_ITM_TYP_CD
	 */
	public String getConsItmTypCd() {
		return consItmTypCd;
	}

	/**
	 * CONS_ITM_TYP_CD
	 *
	 * @param consItmTypCd
	 *            CONS_ITM_TYP_CD
	 */
	public void setConsItmTypCd(String consItmTypCd) {
		this.consItmTypCd = consItmTypCd;
	}

	/**
	 * EQUIP_CD
	 * 
	 * @return EQUIP_CD
	 */
	public String getEquipCd() {
		return equipCd;
	}

	/**
	 * EQUIP_CD
	 *
	 * @param equipCd
	 *            EQUIP_CD
	 */
	public void setEquipCd(String equipCd) {
		this.equipCd = equipCd;
	}

	/**
	 * EQUIP_DPLXG_YN
	 * 
	 * @return EQUIP_DPLXG_YN
	 */
	public String isEquipDplxgYn() {
		return equipDplxgYn;
	}

	/**
	 * EQUIP_DPLXG_YN
	 *
	 * @param equipDplxgYn
	 *            EQUIP_DPLXG_YN
	 */
	public void setEquipDplxgYn(String equipDplxgYn) {
		this.equipDplxgYn = equipDplxgYn;
	}

	/**
	 * EQUIP_DTLS_DESC
	 * 
	 * @return EQUIP_DTLS_DESC
	 */
	public String getEquipDtlsDesc() {
		return equipDtlsDesc;
	}

	/**
	 * EQUIP_DTLS_DESC
	 *
	 * @param equipDtlsDesc
	 *            EQUIP_DTLS_DESC
	 */
	public void setEquipDtlsDesc(String equipDtlsDesc) {
		this.equipDtlsDesc = equipDtlsDesc;
	}

	/**
	 * EQUIP_INTDC_YM
	 * 
	 * @return EQUIP_INTDC_YM
	 */
	public String getEquipIntdcYm() {
		return equipIntdcYm;
	}

	/**
	 * EQUIP_INTDC_YM
	 *
	 * @param equipIntdcYm
	 *            EQUIP_INTDC_YM
	 */
	public void setEquipIntdcYm(String equipIntdcYm) {
		this.equipIntdcYm = equipIntdcYm;
	}

	/**
	 * EQUIP_MDL_NM
	 * 
	 * @return EQUIP_MDL_NM
	 */
	public String getEquipMdlNm() {
		return equipMdlNm;
	}

	/**
	 * EQUIP_MDL_NM
	 *
	 * @param equipMdlNm
	 *            EQUIP_MDL_NM
	 */
	public void setEquipMdlNm(String equipMdlNm) {
		this.equipMdlNm = equipMdlNm;
	}

	/**
	 * EQUIP_MFACT_CD
	 * 
	 * @return EQUIP_MFACT_CD
	 */
	public String getEquipMfactCd() {
		return equipMfactCd;
	}

	/**
	 * EQUIP_MFACT_CD
	 *
	 * @param equipMfactCd
	 *            EQUIP_MFACT_CD
	 */
	public void setEquipMfactCd(String equipMfactCd) {
		this.equipMfactCd = equipMfactCd;
	}

	/**
	 * EQUIP_NM
	 * 
	 * @return EQUIP_NM
	 */
	public String getEquipNm() {
		return equipNm;
	}

	/**
	 * EQUIP_NM
	 *
	 * @param equipNm
	 *            EQUIP_NM
	 */
	public void setEquipNm(String equipNm) {
		this.equipNm = equipNm;
	}

	/**
	 * EQUIP_RPR_PRD
	 * 
	 * @return EQUIP_RPR_PRD
	 */
	public Number getEquipRprPrd() {
		return equipRprPrd;
	}

	/**
	 * EQUIP_RPR_PRD
	 *
	 * @param equipRprPrd
	 *            EQUIP_RPR_PRD
	 */
	public void setEquipRprPrd(Number equipRprPrd) {
		this.equipRprPrd = equipRprPrd;
	}

	/**
	 * EQUIP_TYP_CD
	 * 
	 * @return EQUIP_TYP_CD
	 */
	public String getEquipTypCd() {
		return equipTypCd;
	}

	/**
	 * EQUIP_TYP_CD
	 *
	 * @param equipTypCd
	 *            EQUIP_TYP_CD
	 */
	public void setEquipTypCd(String equipTypCd) {
		this.equipTypCd = equipTypCd;
	}

	/**
	 * EQUIP_UNIT_CD
	 * 
	 * @return EQUIP_UNIT_CD
	 */
	public String getEquipUnitCd() {
		return equipUnitCd;
	}

	/**
	 * EQUIP_UNIT_CD
	 *
	 * @param equipUnitCd
	 *            EQUIP_UNIT_CD
	 */
	public void setEquipUnitCd(String equipUnitCd) {
		this.equipUnitCd = equipUnitCd;
	}

	/**
	 * EQUIP_UNIT_PRC
	 * 
	 * @return EQUIP_UNIT_PRC
	 */
	public Number getEquipUnitPrc() {
		return equipUnitPrc;
	}

	/**
	 * EQUIP_UNIT_PRC
	 *
	 * @param equipUnitPrc
	 *            EQUIP_UNIT_PRC
	 */
	public void setEquipUnitPrc(Number equipUnitPrc) {
		this.equipUnitPrc = equipUnitPrc;
	}

	/**
	 * FCLT_DLVED_GDS_CO_CD
	 * 
	 * @return FCLT_DLVED_GDS_CO_CD
	 */
	public String getFcltDlvedGdsCoCd() {
		return fcltDlvedGdsCoCd;
	}

	/**
	 * FCLT_DLVED_GDS_CO_CD
	 *
	 * @param fcltDlvedGdsCoCd
	 *            FCLT_DLVED_GDS_CO_CD
	 */
	public void setFcltDlvedGdsCoCd(String fcltDlvedGdsCoCd) {
		this.fcltDlvedGdsCoCd = fcltDlvedGdsCoCd;
	}

	/**
	 * FIN_ASSET_CD
	 * 
	 * @return FIN_ASSET_CD
	 */
	public String getFinAssetCd() {
		return finAssetCd;
	}

	/**
	 * FIN_ASSET_CD
	 *
	 * @param finAssetCd
	 *            FIN_ASSET_CD
	 */
	public void setFinAssetCd(String finAssetCd) {
		this.finAssetCd = finAssetCd;
	}

	/**
	 * INI_ALT_ITM_APLY_RT
	 * 
	 * @return INI_ALT_ITM_APLY_RT
	 */
	public Number getIniAltItmAplyRt() {
		return iniAltItmAplyRt;
	}

	/**
	 * INI_ALT_ITM_APLY_RT
	 *
	 * @param iniAltItmAplyRt
	 *            INI_ALT_ITM_APLY_RT
	 */
	public void setIniAltItmAplyRt(Number iniAltItmAplyRt) {
		this.iniAltItmAplyRt = iniAltItmAplyRt;
	}

	/**
	 * SCARD_USE_USG_CD
	 * 
	 * @return SCARD_USE_USG_CD
	 */
	public String getScardUseUsgCd() {
		return scardUseUsgCd;
	}

	/**
	 * SCARD_USE_USG_CD
	 *
	 * @param scardUseUsgCd
	 *            SCARD_USE_USG_CD
	 */
	public void setScardUseUsgCd(String scardUseUsgCd) {
		this.scardUseUsgCd = scardUseUsgCd;
	}

	/**
	 * SRGT_SCARD_EQUIP_CD
	 * 
	 * @return SRGT_SCARD_EQUIP_CD
	 */
	public String getSrgtScardEquipCd() {
		return srgtScardEquipCd;
	}

	/**
	 * SRGT_SCARD_EQUIP_CD
	 *
	 * @param srgtScardEquipCd
	 *            SRGT_SCARD_EQUIP_CD
	 */
	public void setSrgtScardEquipCd(String srgtScardEquipCd) {
		this.srgtScardEquipCd = srgtScardEquipCd;
	}

	/**
	 * SVC_INFLU_YN
	 * 
	 * @return SVC_INFLU_YN
	 */
	public String isSvcInfluYn() {
		return svcInfluYn;
	}

	/**
	 * SVC_INFLU_YN
	 *
	 * @param svcInfluYn
	 *            SVC_INFLU_YN
	 */
	public void setSvcInfluYn(String svcInfluYn) {
		this.svcInfluYn = svcInfluYn;
	}
}
