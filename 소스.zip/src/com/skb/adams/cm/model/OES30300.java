package com.skb.adams.cm.model;

import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;

import java.io.Serializable;
import java.sql.Timestamp;

/**
* @since 2018.09.26 14:18
* @author subkjh 
* autometic create by subkjh.dao 
*
*/


@FxTable(name = "OES30300", comment = "법정동목록")
public class OES30300 implements Serializable {

/**
	 * 
	 */
	private static final long serialVersionUID = 7110906142930789774L;


public OES30300() {
 }

@FxColumn(name = "LDONG_CD", size = 10, comment = "법정동코드")
private String ldongCd;


@FxColumn(name = "AUDIT_ID", size = 15, comment = "최종변경자ID")
private String auditId;


@FxColumn(name = "AUDIT_DTM", size = 0, comment = "최종변경일시")
private Timestamp auditDtm;


@FxColumn(name = "EFF_STA_DT", size = 8, nullable = true, comment = "유효시작일자")
private String effStaDt;


@FxColumn(name = "EFF_END_DT", size = 8, nullable = true, comment = "유효종료일자")
private String effEndDt;


@FxColumn(name = "LDONG_CL_CD", size = 1, nullable = true, comment = "법정동구분코드")
private String ldongClCd;


@FxColumn(name = "CT_PVC_NM", size = 20, nullable = true, comment = "시도명")
private String ctPvcNm;


@FxColumn(name = "CT_GUN_GU_NM", size = 40, nullable = true, comment = "시군구명")
private String ctGunGuNm;


@FxColumn(name = "UP_MYUN_DONG_NM", size = 100, nullable = true, comment = "읍면동명")
private String upMyunDongNm;


@FxColumn(name = "RI_NM", size = 20, nullable = true, comment = "리명")
private String riNm;


@FxColumn(name = "SUP_LDONG_CD", size = 10, nullable = true, comment = "상위법정동코드")
private String supLdongCd;


@FxColumn(name = "CT_PVC_ENG_NM", size = 20, nullable = true, comment = "시도영문명")
private String ctPvcEngNm;


@FxColumn(name = "CT_GUN_GU_ENG_NM", size = 40, nullable = true, comment = "시군구영문명")
private String ctGunGuEngNm;


@FxColumn(name = "UP_MYUN_DONG_ENG_NM", size = 100, nullable = true, comment = "읍면동영문명")
private String upMyunDongEngNm;


@FxColumn(name = "RI_ENG_NM", size = 20, nullable = true, comment = "리영문명")
private String riEngNm;


/**
* 법정동코드
* @return 법정동코드
*/
public String getLdongCd() {
return ldongCd;
}
/**
* 법정동코드
*@param ldongCd 법정동코드
*/
public void setLdongCd(String ldongCd) {
	this.ldongCd = ldongCd;
}
/**
* 최종변경자ID
* @return 최종변경자ID
*/
public String getAuditId() {
return auditId;
}
/**
* 최종변경자ID
*@param auditId 최종변경자ID
*/
public void setAuditId(String auditId) {
	this.auditId = auditId;
}
/**
* 최종변경일시
* @return 최종변경일시
*/
public Timestamp getAuditDtm() {
return auditDtm;
}
/**
* 최종변경일시
*@param auditDtm 최종변경일시
*/
public void setAuditDtm(Timestamp auditDtm) {
	this.auditDtm = auditDtm;
}
/**
* 유효시작일자
* @return 유효시작일자
*/
public String getEffStaDt() {
return effStaDt;
}
/**
* 유효시작일자
*@param effStaDt 유효시작일자
*/
public void setEffStaDt(String effStaDt) {
	this.effStaDt = effStaDt;
}
/**
* 유효종료일자
* @return 유효종료일자
*/
public String getEffEndDt() {
return effEndDt;
}
/**
* 유효종료일자
*@param effEndDt 유효종료일자
*/
public void setEffEndDt(String effEndDt) {
	this.effEndDt = effEndDt;
}
/**
* 법정동구분코드
* @return 법정동구분코드
*/
public String getLdongClCd() {
return ldongClCd;
}
/**
* 법정동구분코드
*@param ldongClCd 법정동구분코드
*/
public void setLdongClCd(String ldongClCd) {
	this.ldongClCd = ldongClCd;
}
/**
* 시도명
* @return 시도명
*/
public String getCtPvcNm() {
return ctPvcNm;
}
/**
* 시도명
*@param ctPvcNm 시도명
*/
public void setCtPvcNm(String ctPvcNm) {
	this.ctPvcNm = ctPvcNm;
}
/**
* 시군구명
* @return 시군구명
*/
public String getCtGunGuNm() {
return ctGunGuNm;
}
/**
* 시군구명
*@param ctGunGuNm 시군구명
*/
public void setCtGunGuNm(String ctGunGuNm) {
	this.ctGunGuNm = ctGunGuNm;
}
/**
* 읍면동명
* @return 읍면동명
*/
public String getUpMyunDongNm() {
return upMyunDongNm;
}
/**
* 읍면동명
*@param upMyunDongNm 읍면동명
*/
public void setUpMyunDongNm(String upMyunDongNm) {
	this.upMyunDongNm = upMyunDongNm;
}
/**
* 리명
* @return 리명
*/
public String getRiNm() {
return riNm;
}
/**
* 리명
*@param riNm 리명
*/
public void setRiNm(String riNm) {
	this.riNm = riNm;
}
/**
* 상위법정동코드
* @return 상위법정동코드
*/
public String getSupLdongCd() {
return supLdongCd;
}
/**
* 상위법정동코드
*@param supLdongCd 상위법정동코드
*/
public void setSupLdongCd(String supLdongCd) {
	this.supLdongCd = supLdongCd;
}
/**
* 시도영문명
* @return 시도영문명
*/
public String getCtPvcEngNm() {
return ctPvcEngNm;
}
/**
* 시도영문명
*@param ctPvcEngNm 시도영문명
*/
public void setCtPvcEngNm(String ctPvcEngNm) {
	this.ctPvcEngNm = ctPvcEngNm;
}
/**
* 시군구영문명
* @return 시군구영문명
*/
public String getCtGunGuEngNm() {
return ctGunGuEngNm;
}
/**
* 시군구영문명
*@param ctGunGuEngNm 시군구영문명
*/
public void setCtGunGuEngNm(String ctGunGuEngNm) {
	this.ctGunGuEngNm = ctGunGuEngNm;
}
/**
* 읍면동영문명
* @return 읍면동영문명
*/
public String getUpMyunDongEngNm() {
return upMyunDongEngNm;
}
/**
* 읍면동영문명
*@param upMyunDongEngNm 읍면동영문명
*/
public void setUpMyunDongEngNm(String upMyunDongEngNm) {
	this.upMyunDongEngNm = upMyunDongEngNm;
}
/**
* 리영문명
* @return 리영문명
*/
public String getRiEngNm() {
return riEngNm;
}
/**
* 리영문명
*@param riEngNm 리영문명
*/
public void setRiEngNm(String riEngNm) {
	this.riEngNm = riEngNm;
}
}