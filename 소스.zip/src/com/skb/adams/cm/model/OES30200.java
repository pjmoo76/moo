package com.skb.adams.cm.model;

import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;

import java.io.Serializable;
import java.sql.Timestamp;

/**
* @since 2018.09.26 14:12
* @author subkjh 
* autometic create by subkjh.dao 
*
*/


@FxTable(name = "OES30200", comment = "건물기본")
public class OES30200 implements Serializable {

/**
	 * 
	 */
	private static final long serialVersionUID = 7806997839372452695L;


public OES30200() {
 }

@FxColumn(name = "BLD_CD", size = 15, comment = "건물코드")
private String bldCd;


@FxColumn(name = "AUDIT_ID", size = 15, comment = "최종변경자ID")
private String auditId;


@FxColumn(name = "AUDIT_DTM", size = 0, comment = "최종변경일시")
private Timestamp auditDtm;


@FxColumn(name = "BLD_NM", size = 100, nullable = true, comment = "건물명")
private String bldNm;


@FxColumn(name = "HOUS_CNT", size = 5, nullable = true, comment = "가구수")
private int housCnt;


@FxColumn(name = "BLD_ST_CD", size = 3, comment = "건물상태코드")
private String bldStCd;


@FxColumn(name = "BLD_CL_CD", size = 2, comment = "건물분류코드")
private String bldClCd;


@FxColumn(name = "MIN_STA_DT", size = 8, nullable = true, comment = "입주개시일자")
private String minStaDt;


@FxColumn(name = "ACNST_YN", size = 1, nullable = true, comment = "기구축여부")
private String acnstYn;


@FxColumn(name = "RGST_DT", size = 8, nullable = true, comment = "등록일자")
private String rgstDt;


@FxColumn(name = "RGSTR_ID", size = 15, nullable = true, comment = "등록자ID")
private String rgstrId;


@FxColumn(name = "BLD_RMK", size = 200, nullable = true, comment = "건물비고")
private String bldRmk;


@FxColumn(name = "BLD_DTL_CL_CD", size = 2, nullable = true, comment = "건물상세분류코드")
private String bldDtlClCd;


@FxColumn(name = "TMP_BLD_APRV_DT", size = 8, nullable = true, comment = "임시건물승인일자")
private String tmpBldAprvDt;


@FxColumn(name = "TMP_BLD_APRVR_ID", size = 15, nullable = true, comment = "임시건물승인자ID")
private String tmpBldAprvrId;


@FxColumn(name = "DTL_DONG_YN", size = 1, nullable = true, comment = "상세동여부")
private String dtlDongYn;


@FxColumn(name = "BLD_MGMT_NUM", size = 25, nullable = true, comment = "건물관리번호")
private String bldMgmtNum;


@FxColumn(name = "UGRN_CL_CD", size = 1, comment = "지하구분코드")
private String ugrnClCd;


@FxColumn(name = "BAS_DSRCT_NUM", size = 5, nullable = true, comment = "기초구역번호")
private String basDsrctNum;


@FxColumn(name = "CNSTR_DT", size = 8, nullable = true, comment = "건축일자")
private String cnstrDt;


@FxColumn(name = "CUST_CO_FIX_YN", size = 1, nullable = true, comment = "고객사확정여부")
private String custCoFixYn;


@FxColumn(name = "CUST_CO_FIX_RSN_CTT", size = 200, nullable = true, comment = "고객사확정사유내용")
private String custCoFixRsnCtt;


@FxColumn(name = "CO_BLD_YN", size = 1, nullable = true, comment = "기업용건물여부")
private String coBldYn;


@FxColumn(name = "SMKT_YN", size = 1, nullable = true, comment = "SMARKET여부")
private String smktYn;


@FxColumn(name = "PAPPL_BLD_RGST_ST_CD", size = 1, nullable = true, comment = "사전청약건물등록상태코드")
private String papplBldRgstStCd;


@FxColumn(name = "ADDR_CURNT_OBJ_YN", size = 1, nullable = true, comment = "주소현행화대상여부")
private String addrCurntObjYn;


@FxColumn(name = "SMKT_BLD_TYP_CD", size = 2, nullable = true, comment = "SMARKET건물유형코드")
private String smktBldTypCd;


/**
* 건물코드
* @return 건물코드
*/
public String getBldCd() {
return bldCd;
}
/**
* 건물코드
*@param bldCd 건물코드
*/
public void setBldCd(String bldCd) {
	this.bldCd = bldCd;
}
/**
* 최종변경자ID
* @return 최종변경자ID
*/
public String getAuditId() {
return auditId;
}
/**
* 최종변경자ID
*@param auditId 최종변경자ID
*/
public void setAuditId(String auditId) {
	this.auditId = auditId;
}
/**
* 최종변경일시
* @return 최종변경일시
*/
public Timestamp getAuditDtm() {
return auditDtm;
}
/**
* 최종변경일시
*@param auditDtm 최종변경일시
*/
public void setAuditDtm(Timestamp auditDtm) {
	this.auditDtm = auditDtm;
}
/**
* 건물명
* @return 건물명
*/
public String getBldNm() {
return bldNm;
}
/**
* 건물명
*@param bldNm 건물명
*/
public void setBldNm(String bldNm) {
	this.bldNm = bldNm;
}
/**
* 가구수
* @return 가구수
*/
public int getHousCnt() {
return housCnt;
}
/**
* 가구수
*@param housCnt 가구수
*/
public void setHousCnt(int housCnt) {
	this.housCnt = housCnt;
}
/**
* 건물상태코드
* @return 건물상태코드
*/
public String getBldStCd() {
return bldStCd;
}
/**
* 건물상태코드
*@param bldStCd 건물상태코드
*/
public void setBldStCd(String bldStCd) {
	this.bldStCd = bldStCd;
}
/**
* 건물분류코드
* @return 건물분류코드
*/
public String getBldClCd() {
return bldClCd;
}
/**
* 건물분류코드
*@param bldClCd 건물분류코드
*/
public void setBldClCd(String bldClCd) {
	this.bldClCd = bldClCd;
}
/**
* 입주개시일자
* @return 입주개시일자
*/
public String getMinStaDt() {
return minStaDt;
}
/**
* 입주개시일자
*@param minStaDt 입주개시일자
*/
public void setMinStaDt(String minStaDt) {
	this.minStaDt = minStaDt;
}
/**
* 기구축여부
* @return 기구축여부
*/
public String getAcnstYn() {
return acnstYn;
}
/**
* 기구축여부
*@param acnstYn 기구축여부
*/
public void setAcnstYn(String acnstYn) {
	this.acnstYn = acnstYn;
}
/**
* 등록일자
* @return 등록일자
*/
public String getRgstDt() {
return rgstDt;
}
/**
* 등록일자
*@param rgstDt 등록일자
*/
public void setRgstDt(String rgstDt) {
	this.rgstDt = rgstDt;
}
/**
* 등록자ID
* @return 등록자ID
*/
public String getRgstrId() {
return rgstrId;
}
/**
* 등록자ID
*@param rgstrId 등록자ID
*/
public void setRgstrId(String rgstrId) {
	this.rgstrId = rgstrId;
}
/**
* 건물비고
* @return 건물비고
*/
public String getBldRmk() {
return bldRmk;
}
/**
* 건물비고
*@param bldRmk 건물비고
*/
public void setBldRmk(String bldRmk) {
	this.bldRmk = bldRmk;
}
/**
* 건물상세분류코드
* @return 건물상세분류코드
*/
public String getBldDtlClCd() {
return bldDtlClCd;
}
/**
* 건물상세분류코드
*@param bldDtlClCd 건물상세분류코드
*/
public void setBldDtlClCd(String bldDtlClCd) {
	this.bldDtlClCd = bldDtlClCd;
}
/**
* 임시건물승인일자
* @return 임시건물승인일자
*/
public String getTmpBldAprvDt() {
return tmpBldAprvDt;
}
/**
* 임시건물승인일자
*@param tmpBldAprvDt 임시건물승인일자
*/
public void setTmpBldAprvDt(String tmpBldAprvDt) {
	this.tmpBldAprvDt = tmpBldAprvDt;
}
/**
* 임시건물승인자ID
* @return 임시건물승인자ID
*/
public String getTmpBldAprvrId() {
return tmpBldAprvrId;
}
/**
* 임시건물승인자ID
*@param tmpBldAprvrId 임시건물승인자ID
*/
public void setTmpBldAprvrId(String tmpBldAprvrId) {
	this.tmpBldAprvrId = tmpBldAprvrId;
}
/**
* 상세동여부
* @return 상세동여부
*/
public String getDtlDongYn() {
return dtlDongYn;
}
/**
* 상세동여부
*@param dtlDongYn 상세동여부
*/
public void setDtlDongYn(String dtlDongYn) {
	this.dtlDongYn = dtlDongYn;
}
/**
* 건물관리번호
* @return 건물관리번호
*/
public String getBldMgmtNum() {
return bldMgmtNum;
}
/**
* 건물관리번호
*@param bldMgmtNum 건물관리번호
*/
public void setBldMgmtNum(String bldMgmtNum) {
	this.bldMgmtNum = bldMgmtNum;
}
/**
* 지하구분코드
* @return 지하구분코드
*/
public String getUgrnClCd() {
return ugrnClCd;
}
/**
* 지하구분코드
*@param ugrnClCd 지하구분코드
*/
public void setUgrnClCd(String ugrnClCd) {
	this.ugrnClCd = ugrnClCd;
}
/**
* 기초구역번호
* @return 기초구역번호
*/
public String getBasDsrctNum() {
return basDsrctNum;
}
/**
* 기초구역번호
*@param basDsrctNum 기초구역번호
*/
public void setBasDsrctNum(String basDsrctNum) {
	this.basDsrctNum = basDsrctNum;
}
/**
* 건축일자
* @return 건축일자
*/
public String getCnstrDt() {
return cnstrDt;
}
/**
* 건축일자
*@param cnstrDt 건축일자
*/
public void setCnstrDt(String cnstrDt) {
	this.cnstrDt = cnstrDt;
}
/**
* 고객사확정여부
* @return 고객사확정여부
*/
public String getCustCoFixYn() {
return custCoFixYn;
}
/**
* 고객사확정여부
*@param custCoFixYn 고객사확정여부
*/
public void setCustCoFixYn(String custCoFixYn) {
	this.custCoFixYn = custCoFixYn;
}
/**
* 고객사확정사유내용
* @return 고객사확정사유내용
*/
public String getCustCoFixRsnCtt() {
return custCoFixRsnCtt;
}
/**
* 고객사확정사유내용
*@param custCoFixRsnCtt 고객사확정사유내용
*/
public void setCustCoFixRsnCtt(String custCoFixRsnCtt) {
	this.custCoFixRsnCtt = custCoFixRsnCtt;
}
/**
* 기업용건물여부
* @return 기업용건물여부
*/
public String getCoBldYn() {
return coBldYn;
}
/**
* 기업용건물여부
*@param coBldYn 기업용건물여부
*/
public void setCoBldYn(String coBldYn) {
	this.coBldYn = coBldYn;
}
/**
* SMARKET여부
* @return SMARKET여부
*/
public String getSmktYn() {
return smktYn;
}
/**
* SMARKET여부
*@param smktYn SMARKET여부
*/
public void setSmktYn(String smktYn) {
	this.smktYn = smktYn;
}
/**
* 사전청약건물등록상태코드
* @return 사전청약건물등록상태코드
*/
public String getPapplBldRgstStCd() {
return papplBldRgstStCd;
}
/**
* 사전청약건물등록상태코드
*@param papplBldRgstStCd 사전청약건물등록상태코드
*/
public void setPapplBldRgstStCd(String papplBldRgstStCd) {
	this.papplBldRgstStCd = papplBldRgstStCd;
}
/**
* 주소현행화대상여부
* @return 주소현행화대상여부
*/
public String getAddrCurntObjYn() {
return addrCurntObjYn;
}
/**
* 주소현행화대상여부
*@param addrCurntObjYn 주소현행화대상여부
*/
public void setAddrCurntObjYn(String addrCurntObjYn) {
	this.addrCurntObjYn = addrCurntObjYn;
}
/**
* SMARKET건물유형코드
* @return SMARKET건물유형코드
*/
public String getSmktBldTypCd() {
return smktBldTypCd;
}
/**
* SMARKET건물유형코드
*@param smktBldTypCd SMARKET건물유형코드
*/
public void setSmktBldTypCd(String smktBldTypCd) {
	this.smktBldTypCd = smktBldTypCd;
}
}
