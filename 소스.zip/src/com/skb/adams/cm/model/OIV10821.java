package com.skb.adams.cm.model;

import java.io.Serializable;

import subkjh.bas.fxdao.define.FxColumn;
import subkjh.bas.fxdao.define.FxTable;

/**
 * @since 2017.12.28 09:32
 * @author subkjh autometic create by subkjh.dao
 *
 */

@FxTable(name = "OIV10821", comment = "사설공유기내역")
public class OIV10821 implements Serializable {

	public OIV10821() {
	}

	@FxColumn(name = "RGST_DT", size = 8, comment = "등록일자")
	private String rgstDt;

	@FxColumn(name = "WEQP_MAC_ADDR", size = 15, comment = "유선단말MAC주소")
	private String weqpMacAddr;

	@FxColumn(name = "WEQP_IP_ADDR", size = 23, nullable = true, comment = "유선단말IP주소")
	private String weqpIpAddr;

	@FxColumn(name = "PRV_SHRR_LINK_CL_CD", size = 1, nullable = true, comment = "사설공유기연결구분코드")
	private String prvShrrLinkClCd;

	@FxColumn(name = "PRV_SHRR_MAC_ADDR", size = 15, nullable = true, comment = "사설공유기MAC주소")
	private String prvShrrMacAddr;

	@FxColumn(name = "PRV_SHRR_MFACT_NM", size = 100, nullable = true, comment = "사설공유기제조사명")
	private String prvShrrMfactNm;

	@FxColumn(name = "PRV_SHRR_IP_ADDR", size = 23, nullable = true, comment = "사설공유기IP주소")
	private String prvShrrIpAddr;

	/**
	 * 등록일자
	 * 
	 * @return 등록일자
	 */
	public String getRgstDt() {
		return rgstDt;
	}

	/**
	 * 등록일자
	 *
	 * @param rgstDt
	 *            등록일자
	 */
	public void setRgstDt(String rgstDt) {
		this.rgstDt = rgstDt;
	}

	/**
	 * 유선단말MAC주소
	 * 
	 * @return 유선단말MAC주소
	 */
	public String getWeqpMacAddr() {
		return weqpMacAddr;
	}

	/**
	 * 유선단말MAC주소
	 *
	 * @param weqpMacAddr
	 *            유선단말MAC주소
	 */
	public void setWeqpMacAddr(String weqpMacAddr) {
		this.weqpMacAddr = weqpMacAddr;
	}

	/**
	 * 유선단말IP주소
	 * 
	 * @return 유선단말IP주소
	 */
	public String getWeqpIpAddr() {
		return weqpIpAddr;
	}

	/**
	 * 유선단말IP주소
	 *
	 * @param weqpIpAddr
	 *            유선단말IP주소
	 */
	public void setWeqpIpAddr(String weqpIpAddr) {
		this.weqpIpAddr = weqpIpAddr;
	}

	/**
	 * 사설공유기연결구분코드
	 * 
	 * @return 사설공유기연결구분코드
	 */
	public String getPrvShrrLinkClCd() {
		return prvShrrLinkClCd;
	}

	/**
	 * 사설공유기연결구분코드
	 *
	 * @param prvShrrLinkClCd
	 *            사설공유기연결구분코드
	 */
	public void setPrvShrrLinkClCd(String prvShrrLinkClCd) {
		this.prvShrrLinkClCd = prvShrrLinkClCd;
	}

	/**
	 * 사설공유기MAC주소
	 * 
	 * @return 사설공유기MAC주소
	 */
	public String getPrvShrrMacAddr() {
		return prvShrrMacAddr;
	}

	/**
	 * 사설공유기MAC주소
	 *
	 * @param prvShrrMacAddr
	 *            사설공유기MAC주소
	 */
	public void setPrvShrrMacAddr(String prvShrrMacAddr) {
		this.prvShrrMacAddr = prvShrrMacAddr;
	}

	/**
	 * 사설공유기제조사명
	 * 
	 * @return 사설공유기제조사명
	 */
	public String getPrvShrrMfactNm() {
		return prvShrrMfactNm;
	}

	/**
	 * 사설공유기제조사명
	 *
	 * @param prvShrrMfactNm
	 *            사설공유기제조사명
	 */
	public void setPrvShrrMfactNm(String prvShrrMfactNm) {
		this.prvShrrMfactNm = prvShrrMfactNm;
	}

	/**
	 * 사설공유기IP주소
	 * 
	 * @return 사설공유기IP주소
	 */
	public String getPrvShrrIpAddr() {
		return prvShrrIpAddr;
	}

	/**
	 * 사설공유기IP주소
	 *
	 * @param prvShrrIpAddr
	 *            사설공유기IP주소
	 */
	public void setPrvShrrIpAddr(String prvShrrIpAddr) {
		this.prvShrrIpAddr = prvShrrIpAddr;
	}
}
