package com.skb.adams.cm.model;

public class OIV10403 {
	private	String	linkId;
	private	int		thruSerNum;
	private	String	rnNum;
	private	String	rnPortNum;
	private	String	telpolNum;
	private	String	tapNum;
	private	String	ontSerNum;
	
	public void OIV10403() {
		
	}

	public String getLinkId() {
		return linkId;
	}

	public void setLinkId(String linkId) {
		this.linkId = linkId;
	}

	public int getThruSerNum() {
		return thruSerNum;
	}

	public void setThruSerNum(int thruSerNum) {
		this.thruSerNum = thruSerNum;
	}

	public String getRnNum() {
		return rnNum;
	}

	public void setRnNum(String rnNum) {
		this.rnNum = rnNum;
	}

	public String getRnPortNum() {
		return rnPortNum;
	}

	public void setRnPortNum(String rnPortNum) {
		this.rnPortNum = rnPortNum;
	}

	public String getTelpolNum() {
		return telpolNum;
	}

	public void setTelpolNum(String telpolNum) {
		this.telpolNum = telpolNum;
	}

	public String getTapNum() {
		return tapNum;
	}

	public void setTapNum(String tapNum) {
		this.tapNum = tapNum;
	}

	public String getOntSerNum() {
		return ontSerNum;
	}

	public void setOntSerNum(String ontSerNum) {
		this.ontSerNum = ontSerNum;
	}
}
