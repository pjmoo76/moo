package com.skb.adams.cm;

import java.io.File;
import java.rmi.RemoteException;

import com.skb.adams.cm.batch.itms.NatallParser;
import com.skb.adams.cm.batch.itms.RcuParser;
import com.skb.adams.cm.batch.itms.SdsStbInfoParser;
import com.skb.adams.cm.batch.itms.StbH01StatusParser;
import com.skb.adams.cm.batch.rms.CmInfoTblParser;
import com.skb.adams.cm.batch.swms.ApInfoParser;
import com.skb.adams.cm.batch.swms.ApPingChkParser;
import com.skb.adams.cm.batch.swms.ApPortScanParser;
import com.skb.adams.cm.batch.swms.ApScanAllParser;
import com.skb.adams.cm.batch.swms.BizapPingChkParser;

import fxms.bas.fxo.FxCfg;
import fxms.bas.fxo.service.FxServiceImpl;
import fxms.bas.fxo.thread.FxThread;

public class CmBatchServiceImpl extends FxServiceImpl implements CmBatchService {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7910346915945518959L;

	public CmBatchServiceImpl(String name, int port) throws RemoteException, Exception {
		super(name, port);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		FxServiceImpl.start(CmBatchService.class.getSimpleName(), CmBatchServiceImpl.class, args);
	}

	private FxThread weqpWatcher;
	private FxThread priApWatcher;

	@Override
	protected void onStarted() throws Exception {

		final String swmsFolder = FxCfg.getCfg().getString("swms-folder", "/app/data/swms");
		final String itmsFolder = FxCfg.getCfg().getString("itms-folder", "/app/data/itms");
		final String rmsFolder = FxCfg.getCfg().getString("rms-folder", "/app/data/rms");

		weqpWatcher = new FxThread("WEQP-WATCHER") {

			@Override
			protected void doInit() {

			}

			@Override
			protected void doWork() {

				int count = 0;

				while (isContinue()) {

					count = 0;

					StbH01StatusParser p4 = new StbH01StatusParser();
					count += p4.parseFolder(new File(itmsFolder + File.separator + "stb_h01_status"));

					SdsStbInfoParser p6 = new SdsStbInfoParser();
					count += p6.parseFolder(new File(itmsFolder + File.separator + "sds_stb_info"));

					ApPingChkParser p1 = new ApPingChkParser();
					count += p1.parseFolder(new File(swmsFolder + File.separator + "ap_ping_chk"));

					ApInfoParser p2 = new ApInfoParser();
					count += p2.parseFolder(new File(swmsFolder + File.separator + "apinfo"));

					BizapPingChkParser p3 = new BizapPingChkParser();
					count += p3.parseFolder(new File(swmsFolder + File.separator + "bizap_ping_chk"));

					RcuParser p5 = new RcuParser();
					count += p5.parseFolder(new File(itmsFolder + File.separator + "rcu"));

					CmInfoTblParser p7 = new CmInfoTblParser();
					count += p7.parseFolder(new File(rmsFolder));

					try {
						Thread.sleep(1000L);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}

					if (count > 0) {
						System.gc();
						logger.info("max=" + (Runtime.getRuntime().maxMemory() / 1000000L) + ", free="
								+ (Runtime.getRuntime().freeMemory() / 1000000L));
					}
				}
			}
		};

		weqpWatcher.start();

		priApWatcher = new FxThread("PRI-AP-WATCHER") {

			@Override
			protected void doInit() {

			}

			@Override
			protected void doWork() {

				while (isContinue()) {

					NatallParser p1 = new NatallParser();
					p1.parseFolder(new File(itmsFolder + File.separator + "natall"));

					ApPortScanParser p2 = new ApPortScanParser();
					p2.parseFolder(new File(swmsFolder + File.separator + "ap_port_scan"));

					ApScanAllParser p3 = new ApScanAllParser();
					p3.parseFolder(new File(swmsFolder + File.separator + "ap_scan_all"));

					try {
						Thread.sleep(30000L);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		};

		priApWatcher.start();

	}

}
