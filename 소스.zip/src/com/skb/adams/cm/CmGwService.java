package com.skb.adams.cm;

import fxms.bas.fxo.service.ext.ExtService;

public interface CmGwService extends ExtService {

}
