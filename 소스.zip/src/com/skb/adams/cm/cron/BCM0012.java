package com.skb.adams.cm.cron;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.CmMsg;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.OIV10812Qid;
import com.skb.adams.cm.dao.OIV10970Qid;
import com.skb.adams.cm.model.OIV10970;

import fxms.bas.cron.Crontab;

/**
 * 유선단말 현행화를 집계한다.
 * 
 * @author SUBKJH-DEV
 *
 */
public class BCM0012 extends Crontab {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7381073685642224151L;

	public static void main(String[] args) {
		BCM0012 cron = new BCM0012();
		try {
			cron.cron();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void cron() throws Exception {

		DataBase database = DBManager.getMgr().getDataBase(CmDao.ADAMS);
		DbTrans tran;
		OIV10812Qid QID = new OIV10812Qid();
		OIV10970Qid logQid = new OIV10970Qid();
		try {
			tran = database.createDbTrans("deploy/conf/sql/" + OIV10812Qid.QUERY_XML_FILE //
			, "deploy/conf/sql/" + OIV10970Qid.QUERY_XML_FILE);
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}

		try {
			tran.start();

			String yyyymmddhh = CmDao.YYYYMMDDHHMM(System.currentTimeMillis()) + "00";

			int delCnt = tran.execute(QID.DELETE_OIV10812, yyyymmddhh);

			OIV10970 o812Log = new OIV10970("OIV10812", yyyymmddhh);
			int addCnt = tran.execute(QID.INSERT_OIV10812, yyyymmddhh);
			o812Log.setCreCnt(addCnt);

			tran.commit();
			Logger.logger.info(CmMsg.makeCmInfo("OIV10812(유선단말현행화집계)", delCnt, addCnt, -1));

			tran.execute(logQid.DELETE_OIV10970, o812Log);
			tran.execute(logQid.INSERT_OIV10970, o812Log);
			tran.commit();

		} catch (Exception e) {
			tran.rollback();
			Logger.logger.error(e);
			throw e;
		} finally {
			tran.stop();
		}

	}

	@Override
	public String getGroup() {
		return "WEQP";
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}

}
