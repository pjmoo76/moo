package com.skb.adams.cm.cron;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.CmMsg;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.OIV10713Qid;
import com.skb.adams.cm.dao.OIV1071xQid;

import fxms.bas.cron.Crontab;

/**
 * 장비/CELL/PORT 단위로 고객수 및 가입서비스수를 집계한다.
 * 
 * @author SUBKJH-DEV
 *
 */
public class BCM0013 extends Crontab {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3834261629455202197L;

	@Override
	public void cron() throws Exception {
		
		DataBase database = DBManager.getMgr().getDataBase(CmDao.ADAMS);
		DbTrans tran;
		DbTrans tran2;
		OIV1071xQid QID = new OIV1071xQid();
		OIV10713Qid QID2 = new OIV10713Qid();
		try {
			tran = database.createDbTrans("deploy/conf/sql/" + OIV1071xQid.QUERY_XML_FILE);
			tran2 = database.createDbTrans("deploy/conf/sql/" + OIV10713Qid.QUERY_XML_FILE);
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}
		int deleteCnt;
		int addCnt;

		try {
			tran.start();

			//배치가 수행되어야하는지 E2E,OCO30341 배치상태 체크
			int chkE2eCnt = tran.selectQidInt(QID.CHECK_E2E_COMPLETE, null,0);
			int stNum = tran.selectQidInt(QID.SELECT_OCO30341, null, 0);

			Logger.logger.debug("chkE2eCnt >>>> " + chkE2eCnt);
			Logger.logger.debug("BCM0013Cnt >>>> " + stNum);

			//E2E생성 완료 && BCM0013 최초실행시
			if(chkE2eCnt > 0 && stNum == 0){
				
				//OCO30341 이력생성
				tran.execute(QID.INSERT_OCO30341, null);
				tran.commit();
				
				deleteCnt = tran.execute(QID.DELETE_OIV10711, null);
				addCnt = tran.execute(QID.INSERT_OIV10711_CMTS, null);
				addCnt += tran.execute(QID.INSERT_OIV10711_L3, null);
				addCnt += tran.execute(QID.INSERT_OIV10711_L2, null);
				addCnt += tran.execute(QID.INSERT_OIV10711_DHCP, null);
				tran.commit();
				Logger.logger.info(CmMsg.makeCmInfo("OIV10711(장비수용고객수내역)", deleteCnt, addCnt, -1));

				deleteCnt = tran.execute(QID.DELETE_OIV10712, null);
				addCnt = tran.execute(QID.INSERT_OIV10712_CMTS, null);
				addCnt = tran.execute(QID.INSERT_OIV10712_L3, null);
				addCnt += tran.execute(QID.INSERT_OIV10712_L2, null);
				addCnt += tran.execute(QID.INSERT_OIV10712_DHCP, null);
				tran.commit();
				Logger.logger.info(CmMsg.makeCmInfo("OIV10712(장비수용서비스수내역)", deleteCnt, addCnt, -1));
				
				deleteCnt = tran.execute(QID.DELETE_OIV10715, null);
				addCnt = tran.execute(QID.INSERT_OIV10715_CMTS, null);
				addCnt = tran.execute(QID.INSERT_OIV10715_L3, null);
				tran.commit();
				Logger.logger.info(CmMsg.makeCmInfo("OIV10715(장비셀수용고객수내역)", deleteCnt, addCnt, -1));

				deleteCnt = tran.execute(QID.DELETE_OIV10716, null);
				addCnt = tran.execute(QID.INSERT_OIV10716_CMTS, null);
				addCnt = tran.execute(QID.INSERT_OIV10716_L3, null);
				tran.commit();
				
				Logger.logger.info(CmMsg.makeCmInfo("OIV10716(장비셀수용서비스수내역)", deleteCnt, addCnt, -1));
				
				tran2.start();
				
				deleteCnt = tran2.execute(QID2.DELETE_OIV10713, null);
				addCnt = tran2.execute(QID2.INSERT_OIV10713_CMTS, null);
				addCnt += tran2.execute(QID2.INSERT_OIV10713_L3, null);
				addCnt += tran2.execute(QID2.INSERT_OIV10713_L2, null);
				tran2.commit();
				Logger.logger.info(CmMsg.makeCmInfo("OIV10713(장비포트수용고객수내역)", deleteCnt, addCnt, -1));

				deleteCnt = tran2.execute(QID2.DELETE_OIV10714, null);
				addCnt = tran2.execute(QID2.INSERT_OIV10714_CMTS, null);
				addCnt += tran2.execute(QID2.INSERT_OIV10714_L3, null);
				addCnt += tran2.execute(QID2.INSERT_OIV10714_L2, null);
				tran2.commit();
				Logger.logger.info(CmMsg.makeCmInfo("OIV10714(장비포트수용서비스수내역)", deleteCnt, addCnt, -1));
				
				//OCO30341 이력생성
				tran2.execute(QID2.UPDATE_OCO30341, null);
				tran2.commit();
			}

		} catch (Exception e) {
			tran.rollback();
			tran2.rollback();
			Logger.logger.error(e);
			throw e;
		} finally {
			tran.stop();
			tran2.stop();
		}

	}

	@Override
	public String getGroup() {
		return "STT";
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}

}