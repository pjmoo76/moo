package com.skb.adams.cm.cron;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import subkjh.bas.dao.control.CommDao.INSERT_TYPE;
import subkjh.bas.dao.control.DaoListener;
import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.CmMsg;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.OIV10800Qid;
import com.skb.adams.cm.model.OIV10800;

import fxms.bas.cron.Crontab;

/**
 * OIV10809에서 유효한 유선단말만을 OIV10800에 넣는다.
 * 
 * @author SUBKJH-DEV
 *
 */
public class BCM0010 extends Crontab {

	class ZossWeqp implements DaoListener {

		private OIV10800 old800 = null;
		private List<OIV10800> toAddList = new ArrayList<OIV10800>();

		public void onExecuted(Object data, Exception ex) throws Exception {

		}

		@Override
		public void onFinish(Exception ex) throws Exception {

			if (toAddList.size() > 0) {

				addCount += addTran.execute(qid.INSERT_OIV10800, toAddList);

				toAddList.clear();
			}
		}

		@Override
		public void onSelected(int rowNo, Object data) throws Exception {
			OIV10800 o = (OIV10800) data;

			if (old800 == null) {
				old800 = o;
				toAddList.add(old800);
				return;
			}

			if (old800.getMacAddrVal() != null && old800.getMacAddrVal().equals(o.getMacAddrVal())) {
				return;
			}

			old800 = o;
			toAddList.add(old800);

			if (toAddList.size() >= 50000) {
				addCount += addTran.execute(qid.INSERT_OIV10800, toAddList);
				toAddList.clear();
			}

			// OIV10800 prevO = weqpMap.get(o.getMacAddrVal());
			//
			// if (prevO != null) {
			//
			// // 이전 자료가 더 크면 현재꺼 버림.
			// if (o.getStFluDt().compareTo(prevO.getStFluDt()) <= 0) {
			// return;
			// }
			// }
			//
			// weqpMap.put(o.getMacAddrVal(), o);
		}

		@Override
		public void onStart(String[] colNames) throws Exception {
			toAddList.clear();
			Logger.logger.debug(Arrays.toString(colNames));
		}
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -8833532345382904705L;

	public static void main(String[] args) {

		BCM0010 o = new BCM0010();
		try {
			o.cron();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private DbTrans addTran;
	private OIV10800Qid qid = new OIV10800Qid();
	private int addCount = 0;

	@Override
	public void cron() throws Exception {
		DataBase database = DBManager.getMgr().getDataBase(CmDao.ADAMS);
		DbTrans tran;
		try {
			tran = database.createDbTrans("deploy/conf/sql/" + OIV10800Qid.QUERY_XML_FILE);
			addTran = database.createDbTrans("deploy/conf/sql/" + OIV10800Qid.QUERY_XML_FILE);
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}

		addCount = 0;
		int delCount = 0;
		
		try {
			tran.start();
			addTran.start();
			addTran.setInsertType(INSERT_TYPE.oneByOneIgnoreExp);

			ZossWeqp daoListener = new ZossWeqp();
			tran.setDaoListener(daoListener);

			// 상태가 변경되었다고 삭제하지 않는다.
//			delCount = addTran.execute(qid.DELETE_OIV10800__ST_CD_NOT_40, null);
			
			delCount += addTran.execute(qid.DELETE_OIV10800__MAC_CHANGED, null);

			tran.selectQid2Res(qid.SELECT_OIV10800, null);

			tran.selectQid2Res(qid.SELECT_OIV10800__BY_AMI, null);

			tran.selectQid2Res(qid.SELECT_OIV10800__BY_402, null);

			addTran.commit();
			
			Logger.logger.info(CmMsg.makeCmInfo("OIV10800(유선단말기본)", delCount, addCount, -1));

			
		} catch (Exception e) {
			addTran.rollback();
			Logger.logger.error(e);
			throw e;
		} finally {
			addTran.stop();
			tran.stop();
		}

	}

	@Override
	public String getGroup() {
		return "WEQP";
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}
}
