package com.skb.adams.cm.cron;

import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.OIV1091xQid;

import fxms.bas.cron.Crontab;
import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.Logger;

public class MakeOiv1091x extends Crontab {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3540950953321385235L;

	@Override
	public void cron() throws Exception {

		DataBase database = DBManager.getMgr().getDataBase(CmDao.ADAMS);
		DbTrans tran;
		OIV1091xQid QID = new OIV1091xQid();
		try {
			tran = database.createDbTrans("deploy/conf/sql/oiv1091x.xml");
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}

		try {
			tran.start();

			tran.execute(QID.DELETE_OIV10911, null);
			tran.execute(QID.INSERT_OIV10911, null);
			tran.commit();
			
			/* c_sts_voip_cur_subs 필요 */
			/*
			tran.execute(QID.DELETE_OIV10912, null);
			tran.execute(QID.INSERT_OIV10912, null);
			tran.commit();
			*/

			tran.execute(QID.DELETE_OIV10913, null);
			tran.execute(QID.INSERT_OIV10913, null);
			tran.commit();

			/* c_sts_voip_ipt_subs 필요 */
			/*
			tran.execute(QID.DELETE_OIV10914, null);
			tran.execute(QID.INSERT_OIV10914, null);
			tran.commit();
			*/

		} catch (Exception e) {
			tran.rollback();
			Logger.logger.error(e);
			throw e;
		} finally {
			tran.stop();
		}

	}

	@Override
	public String getGroup() {
		return null;
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}

}