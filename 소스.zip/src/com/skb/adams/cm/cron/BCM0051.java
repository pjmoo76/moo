package com.skb.adams.cm.cron;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import subkjh.bas.dao.control.DaoListener;
import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.CmMsg;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.ZordSvcQid;
import com.skb.adams.cm.function.CopyTmpO809ToO809;

import fxms.bas.cron.Crontab;
import fxms.bas.fxo.thread.QueueFxThread;

/**
 * ZORD_SVC to OES10200(서비스기본)
 * 
 * @author
 *
 */
public class BCM0051 extends Crontab {

	private static final long serialVersionUID = 4383405768627406482L;

	class InsertThread extends QueueFxThread<List<Object>> {

		private boolean toFinish = false;
		private DbTrans dstTran;

		public InsertThread(DbTrans dstTran) {
			super("FX_TMP_OES10200", 5);
			this.dstTran = dstTran;
		}

		@Override
		protected void doInit() {

		}

		@Override
		protected void doWork(List<Object> dataList) throws Exception {

			Logger.logger.debug("SIZE IN QUEUE : " + getSizeInQueue());

			dstTran.execute(qid.INSERT_FX_TMP_OES10200, dataList);
			dstTran.commit();
		}

		@Override
		protected void onNoDatas(long index) {

			Logger.logger.debug("NO DATAS: " + index);

			if (toFinish) {
				this.stop("no more datas");
			}
		}
	}

	class ZordSvc implements DaoListener {

		private List<Object> oList = new ArrayList<Object>();
		private InsertThread thread;
		private DbTrans dstTran;
		private int count;

		public ZordSvc(DbTrans dstTran) {
			this.dstTran = dstTran;
		}

		public void onExecuted(Object data, Exception ex) throws Exception {

		}

		@Override
		public void onFinish(Exception ex) throws Exception {

			if (oList.size() > 0) {

				count += oList.size();

				thread.add(oList);

				thread.toFinish = true;

				thread.join();
			}

			Logger.logger.info(CmMsg.makeCmInfo("ZORD_SVC -> FX_TMP_OES10200", -1, count, -1));

		}

		@Override
		public void onSelected(int rowNo, Object data) throws Exception {
			oList.add(data);

			if (oList.size() >= 100000) {
				count += oList.size();
				thread.add(oList);
				oList = new ArrayList<Object>();
			}
		}

		@Override
		public void onStart(String[] colNames) throws Exception {
			Logger.logger.debug(Arrays.toString(colNames));

			try {
				dstTran.execute(qid.DROP_TABLE_FX_TMP_OES10200, null);
			} catch (Exception e) {
				Logger.logger.error(e);
			}

			try {
				dstTran.execute(qid.CREATE_TABLE_FX_TMP_OES10200, null);
			} catch (Exception e) {
				Logger.logger.error(e);
			}

			thread = new InsertThread(dstTran);
			thread.start();
		}
	}

	/**
	 * 
	 */

	public static void main(String[] args) {
		BCM0051 cron = new BCM0051();
		try {
			cron.cron();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private ZordSvcQid qid = new ZordSvcQid();

	private void copyToFxTmpOES10200() throws Exception {

		DbTrans srcTran;
		DbTrans dstTran;

		srcTran = DBManager.getMgr().getDataBase(CmDao.NEIFDB).createDbTrans("deploy/conf/sql/" + ZordSvcQid.QUERY_XML_FILE);
		dstTran = DBManager.getMgr().getDataBase(CmDao.ADAMS).createDbTrans("deploy/conf/sql/" + ZordSvcQid.QUERY_XML_FILE);

		try {
			srcTran.start();
		} catch (Exception e) {
			throw e;
		}

		try {
			dstTran.start();
		} catch (Exception e) {
			srcTran.stop();
			throw e;
		}

		ZordSvc daoListener = new ZordSvc(dstTran);
		srcTran.setDaoListener(daoListener);

		try {
			srcTran.selectQid2Res(qid.SELECT_ZORD_SVC, null);

			int mergeCount = dstTran.execute(qid.MERGE_OES10200__BY_FX_TMP_OES10200, null);
			//int deleteCount = dstTran.execute(qid.DELETE_OES10200__BY_FX_TMP_OES10200, null);
			dstTran.commit();

			Logger.logger.info(CmMsg.makeCmInfo("FX_TMP_OES10200 -> OES10200 (merge)", -1, -1, mergeCount));
			//Logger.logger.info(CmMsg.makeCmInfo("FX_TMP_OES10200 -> OES10200 (delete)", deleteCount, -1, -1));
			
		} catch (Exception e) {
			dstTran.rollback();
			Logger.logger.error(e);
			Logger.logger.fail(CmMsg.makeCmInfo("ZORD_SVC -> OES10200 (ERROR)", -1, -1, -1));
			throw e;
		} finally {
			try {
				srcTran.stop();
			} catch (Exception e) {
				Logger.logger.error(e);
			}
			try {
				dstTran.stop();
			} catch (Exception e) {
				Logger.logger.error(e);
			}
		}

	}

	@Override
	public void cron() throws Exception {

		try {
			copyToFxTmpOES10200();
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}
	}

	@Override
	public String getGroup() {
		return "ZORD";
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}

}