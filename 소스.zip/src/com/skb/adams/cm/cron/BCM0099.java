package com.skb.adams.cm.cron;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.CmMsg;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.OIV10800Qid;

import fxms.bas.cron.Crontab;

/**
 * OIV10809에서 유효한 유선단말만을 OIV10800에 넣는다.
 * 
 * @author SUBKJH-DEV
 *
 */
public class BCM0099 extends Crontab {


	/**
	 * 
	 */
	private static final long serialVersionUID = -8833532345382904705L;

	public static void main(String[] args) {

		BCM0099 o = new BCM0099();
		Logger.logger.info(">>>BCM0099 Run");
		try {
			o.cron();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void cron() throws Exception {
		DataBase database = DBManager.getMgr().getDataBase(CmDao.ADAMS);
		DbTrans tran;
		try {
			tran = database.createDbTrans("deploy/conf/sql/" + OIV10800Qid.QUERY_XML_FILE);
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}
				
		int delCount = 0;
		int addCount = 0;
		OIV10800Qid qid = new OIV10800Qid();

		try {
			tran.start();
			Logger.logger.info(">>>BCM0099 Start");

			// 1.OIV10809 기준으로 MAC_ADDR_VAL 값이 중복된 것들은 OIV10800 의 MAC_ADDR_VAL 값을 NULL 처리
			int delCount1 = tran.execute(qid.UPDATE_OIV10800__MAC_NULL, null);

			// 2.OIV10809 기준으로 MFACT_SER_NUM 값이 중복된 것들은 OIV10800 의 MAC_ADDR_VAL 값을 NULL 처리
			int delCount2 = tran.execute(qid.UPDATE_OIV10800__MAC_NULL_BY_MFACT, null);

			// 3.OIV10809 기준으로 MAC_ADDR_VAL 값이 NULL 인데 MFACT_SER_NUM 값이 중복된 경우는 OIV10800 의 MAC_ADDR_VAL 값을 NULL 처리
			int delCount3 = tran.execute(qid.UPDATE_OIV10800__MAC_NULL_BY_DUP, null);

			// 4.OIV10673 에 존재하는 데이터에 대해서만 처리 + OIV10673 기준으로 MERGE : MAC이 중복되면 모두 NULL 처리
			//   WEQP_MDL_TYP_CD 값이 40(ONT), 50(VDLS) 인 경우 +  MAC_ADDR_VAL 값이 NULL 이고 MFACT_SER_NUM 값이 존재하는 경우
			//	 MFACT_SER_NUM 값이 중복되지 않는 경우는 MFACT_SER_NUM 값을 MAC_ADDR_VAL 과 MFACT_SER_NUM 에 업데이트
			//	 MFACT_SER_NUM 값이 중복되는 경우는 MAC_ADDR_VAL 에는 NULL, MFACT_SER_NUM 에 업데이트
			int merge809 = tran.execute(qid.MERGE_OIV10800__BY_OIV10809, null);

			// 5.WEQP_MDL_TYP_CD 값이 40(ONT), 50(VDLS) 인 경우 +  MAC_ADDR_VAL 값이 NULL 이고 MFACT_SER_NUM 값이 존재하는 경우
			//	 MFACT_SER_NUM 값이 중복되지 않는 경우는 MFACT_SER_NUM 값을 MAC_ADDR_VAL 과 MFACT_SER_NUM 에 업데이트
			//	 MFACT_SER_NUM 값이 중복되는 경우는 MAC_ADDR_VAL 에는 NULL, MFACT_SER_NUM 에 업데이트
			//int merge809Mfact = tran.execute(qid.MERGE_OIV10800__BY_OIV10809_BY_MFACT, null);

			// 5.OIV10809 기준으로 MAC정보가 중복된 경우 최근상태변동일자 기준으로 OIV10800에 MAC정보에 MERGE 처리
			int merge809Dup = tran.execute(qid.MERGE_OIV10800__BY_OIV10809_BY_DUP, null);

			delCount = delCount1 + delCount2 + delCount3;
			addCount = merge809 + merge809Dup;
			//addCount = merge809 + merge809Mfact + merge809Dup;

			tran.commit();
			
			Logger.logger.info(">>> OIV10800(유선단말기본)_UPDATE_OIV10800__MAC_NULL : " + delCount1);
			Logger.logger.info(">>> OIV10800(유선단말기본)_UPDATE_OIV10800__MAC_NULL_BY_MFACTL : " + delCount2);
			Logger.logger.info(">>> OIV10800(유선단말기본)_UPDATE_OIV10800__MAC_NULL_BY_DUPL : " + delCount3);
			Logger.logger.info(">>> OIV10800(유선단말기본)_MERGE_OIV10800__BY_OIV10809L : " + merge809);
			Logger.logger.info(">>> OIV10800(유선단말기본)_MERGE_OIV10800__BY_OIV10809_BY_DUPL : " + merge809Dup);

			Logger.logger.info(CmMsg.makeCmInfo("OIV10809 -> OIV10800(유선단말기본)(merge: MAC_ADDR_VAL)", delCount, addCount, -1));

			
		} catch (Exception e) {
			tran.rollback();
			Logger.logger.error(e);
			throw e;
		} finally {
			tran.stop();
		}

	}

	@Override
	public String getGroup() {
		return "WEQP";
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}
}
