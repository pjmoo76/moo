package com.skb.adams.cm.cron;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import subkjh.bas.dao.control.DaoListener;
import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.CmMsg;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.ZossWeqpQid;
import com.skb.adams.cm.function.CopyTmpO809ToO809;

import fxms.bas.cron.Crontab;
import fxms.bas.fxo.thread.QueueFxThread;

/**
 * ZOSS_WEQP to OIV10809(유선단말)
 * 
 * @author SUBKJH-DEV
 *
 */
public class BCM0008 extends Crontab {

	class InsertThread extends QueueFxThread<List<Object>> {

		private boolean toFinish = false;
		private DbTrans dstTran;

		public InsertThread(DbTrans dstTran) {
			super("FX_TMP_OIV10809", 5);
			this.dstTran = dstTran;
		}

		@Override
		protected void doInit() {

		}

		@Override
		protected void doWork(List<Object> dataList) throws Exception {

			Logger.logger.debug("SIZE IN QUEUE : " + getSizeInQueue());

			dstTran.execute(qid.INSERT_FX_TMP_OIV10809, dataList);
			dstTran.commit();
		}

		@Override
		protected void onNoDatas(long index) {

			Logger.logger.debug("NO DATAS: " + index);

			if (toFinish) {
				this.stop("no more datas");
			}
		}
	}

	class ZossWeqp implements DaoListener {

		private List<Object> oList = new ArrayList<Object>();
		private InsertThread thread;
		private DbTrans dstTran;
		private int count;

		public ZossWeqp(DbTrans dstTran) {
			this.dstTran = dstTran;
		}

		public void onExecuted(Object data, Exception ex) throws Exception {

		}

		@Override
		public void onFinish(Exception ex) throws Exception {

			if (oList.size() > 0) {

				count += oList.size();

				thread.add(oList);

				thread.toFinish = true;

				thread.join();
			}

			Logger.logger.info(CmMsg.makeCmInfo("ZOSS_WEQP -> FX_TMP_OIV10809", -1, count, -1));

		}

		@Override
		public void onSelected(int rowNo, Object data) throws Exception {
			oList.add(data);

			if (oList.size() >= 100000) {
				count += oList.size();
				thread.add(oList);
				oList = new ArrayList<Object>();
			}
		}

		@Override
		public void onStart(String[] colNames) throws Exception {
			Logger.logger.debug(Arrays.toString(colNames));

			try {
				dstTran.execute(qid.DROP_TABLE_FX_TMP_OIV10809, null);
			} catch (Exception e) {
				Logger.logger.error(e);
			}

			try {
				dstTran.execute(qid.CREATE_TABLE_FX_TMP_OIV10809, null);
			} catch (Exception e) {
				Logger.logger.error(e);
			}

			thread = new InsertThread(dstTran);
			thread.start();
		}
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -6394431113545986462L;

	public static void main(String[] args) {
		BCM0008 cron = new BCM0008();
		try {
			cron.cron();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private ZossWeqpQid qid = new ZossWeqpQid();

	private void copyToFxTmpOIV10809() throws Exception {

		DbTrans srcTran;
		DbTrans dstTran;

		srcTran = DBManager.getMgr().getDataBase(CmDao.NEIFDB).createDbTrans("deploy/conf/sql/" + ZossWeqpQid.QUERY_XML_FILE);
		dstTran = DBManager.getMgr().getDataBase(CmDao.ADAMS_MICM).createDbTrans("deploy/conf/sql/" + ZossWeqpQid.QUERY_XML_FILE);

		try {
			srcTran.start();
		} catch (Exception e) {
			throw e;
		}

		try {
			dstTran.start();
		} catch (Exception e) {
			srcTran.stop();
			throw e;
		}

		ZossWeqp daoListener = new ZossWeqp(dstTran);
		srcTran.setDaoListener(daoListener);

		try {
			srcTran.selectQid2Res(qid.SELECT_ZOSS_WEQP, null);
			dstTran.commit();
		} catch (Exception e) {
			dstTran.rollback();
			Logger.logger.error(e);
			Logger.logger.fail(CmMsg.makeCmInfo("ZOSS_WEQP -> OIV10809 (ERROR)", -1, -1, -1));
			throw e;
		} finally {
			try {
				srcTran.stop();
			} catch (Exception e) {
				Logger.logger.error(e);
			}
			try {
				dstTran.stop();
			} catch (Exception e) {
				Logger.logger.error(e);
			}
		}

	}

	@Override
	public void cron() throws Exception {

		try {
			copyToFxTmpOIV10809();
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}

		try {
			new CopyTmpO809ToO809().run();
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}

	}

	@Override
	public String getGroup() {
		return "WEQP";
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}

}