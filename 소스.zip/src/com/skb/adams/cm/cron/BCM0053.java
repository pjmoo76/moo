package com.skb.adams.cm.cron;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import subkjh.bas.dao.control.DaoListener;
import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.CmMsg;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.ZngmAddrQid;

import fxms.bas.cron.Crontab;
import fxms.bas.fxo.thread.QueueFxThread;

/**
 * ZNGM_ADDR to OES30100(주소기본)
 * 
 * @author
 *
 */
public class BCM0053 extends Crontab {

	private static final long serialVersionUID = 8206956343476424643L;

	class InsertThread extends QueueFxThread<List<Object>> {

		private boolean toFinish = false;
		private DbTrans dstTran;

		public InsertThread(DbTrans dstTran) {
			super("FX_TMP_OES30100", 5);
			this.dstTran = dstTran;
		}

		@Override
		protected void doInit() {

		}

		@Override
		protected void doWork(List<Object> dataList) throws Exception {

			Logger.logger.debug("SIZE IN QUEUE : " + getSizeInQueue());

			dstTran.execute(qid.INSERT_FX_TMP_OES30100, dataList);
			dstTran.commit();
		}

		@Override
		protected void onNoDatas(long index) {

			Logger.logger.debug("NO DATAS: " + index);

			if (toFinish) {
				this.stop("no more datas");
			}
		}
	}

	class ZngmAddr implements DaoListener {

		private List<Object> oList = new ArrayList<Object>();
		private InsertThread thread;
		private DbTrans dstTran;
		private int count;

		public ZngmAddr(DbTrans dstTran) {
			this.dstTran = dstTran;
		}

		public void onExecuted(Object data, Exception ex) throws Exception {

		}

		@Override
		public void onFinish(Exception ex) throws Exception {

			if (oList.size() > 0) {

				count += oList.size();

				thread.add(oList);

				thread.toFinish = true;

				thread.join();
			}

			Logger.logger.info(CmMsg.makeCmInfo("ZNGM_ADDR -> FX_TMP_OES30100", -1, count, -1));

		}

		@Override
		public void onSelected(int rowNo, Object data) throws Exception {
			oList.add(data);

			if (oList.size() >= 100000) {
				count += oList.size();
				thread.add(oList);
				oList = new ArrayList<Object>();
			}
		}

		@Override
		public void onStart(String[] colNames) throws Exception {
			Logger.logger.debug(Arrays.toString(colNames));

			try {
				dstTran.execute(qid.DROP_TABLE_FX_TMP_OES30100, null);
			} catch (Exception e) {
				Logger.logger.error(e);
			}

			try {
				dstTran.execute(qid.CREATE_TABLE_FX_TMP_OES30100, null);
			} catch (Exception e) {
				Logger.logger.error(e);
			}

			thread = new InsertThread(dstTran);
			thread.start();
		}
	}

	/**
	 * 
	 */

	public static void main(String[] args) {
		BCM0053 cron = new BCM0053();
		try {
			cron.cron();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private ZngmAddrQid qid = new ZngmAddrQid();

	private void copyToFxTmpOES30100() throws Exception {

		DbTrans srcTran;
		DbTrans dstTran;

		srcTran = DBManager.getMgr().getDataBase(CmDao.NEIFDB).createDbTrans("deploy/conf/sql/" + ZngmAddrQid.QUERY_XML_FILE);
		dstTran = DBManager.getMgr().getDataBase(CmDao.ADAMS).createDbTrans("deploy/conf/sql/" + ZngmAddrQid.QUERY_XML_FILE);

		try {
			srcTran.start();
		} catch (Exception e) {
			throw e;
		}

		try {
			dstTran.start();
		} catch (Exception e) {
			srcTran.stop();
			throw e;
		}

		ZngmAddr daoListener = new ZngmAddr(dstTran);
		srcTran.setDaoListener(daoListener);

		try {
			srcTran.selectQid2Res(qid.SELECT_ZNGM_ADDR, null);

			int mergeCount = dstTran.execute(qid.MERGE_OES30100__BY_FX_TMP_OES30100, null);
			//int deleteCount = dstTran.execute(qid.DELETE_OES30100__BY_FX_TMP_OES30100, null);
			dstTran.commit();

			Logger.logger.info(CmMsg.makeCmInfo("FX_TMP_OES30100 -> OES30100 (merge)", -1, -1, mergeCount));
			//Logger.logger.info(CmMsg.makeCmInfo("FX_TMP_OES30100 -> OES30100 (delete)", deleteCount, -1, -1));
			
		} catch (Exception e) {
			dstTran.rollback();
			Logger.logger.error(e);
			Logger.logger.fail(CmMsg.makeCmInfo("ZNGM_ADDR -> OES30100 (ERROR)", -1, -1, -1));
			throw e;
		} finally {
			try {
				srcTran.stop();
			} catch (Exception e) {
				Logger.logger.error(e);
			}
			try {
				dstTran.stop();
			} catch (Exception e) {
				Logger.logger.error(e);
			}
		}

	}

	@Override
	public void cron() throws Exception {

		try {
			copyToFxTmpOES30100();
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}
	}

	@Override
	public String getGroup() {
		return "ZORD";
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}

}
