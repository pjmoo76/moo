package com.skb.adams.cm.cron;

import subkjh.bas.log.Logger;

import com.skb.adams.cm.dao.NeifdbQid;
import com.skb.adams.cm.dao.ZossCopyDao;

import fxms.bas.cron.Crontab;

/**
 * SWING 장비기본(ZOSS_EQUIP_SYS)을 ADAMS SWING장비기본(OIV10112)으로 복사
 * 
 * @author SUBKJH-DEV
 *
 */
public class BCM0003 extends Crontab {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7561693298339951534L;

	public static void main(String[] args) {
		BCM0003 cron = new BCM0003();
		try {
			cron.cron();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void cron() throws Exception {

		try {
			NeifdbQid qid = new NeifdbQid();

			ZossCopyDao dao = new ZossCopyDao();
			dao.copy("ZOSS_EQUIP_SYS -> OIV10112(SWING장비기본)", qid.SELECT_ZOSS_EQUIP_SYS, qid.INSERT_OIV10112, qid.DELETE_OIV10112);
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}

	}

	@Override
	public String getGroup() {
		return "EQUIP";
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}

}