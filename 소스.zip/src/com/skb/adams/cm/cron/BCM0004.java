package com.skb.adams.cm.cron;

import java.util.List;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.fxdao.control.DiffDao;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.CmMsg;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.OIV10200UpdateQid;
import com.skb.adams.cm.dao.OIV1020xQid;
import com.skb.adams.cm.model.OIV10200;

import fxms.bas.cron.Crontab;

/**
 * OIV10208(SWING장비모델기본)에서 OIV10213(수집장비모델매핑내역)과 OIV10200(장비모델기본)에 없는 자료를 추가한다.
 * 
 * @author SUBKJH-DEV
 *
 */
public class BCM0004 extends Crontab {

	class EquipModelDiffDao extends DiffDao<OIV10200> {

		private OIV10200UpdateQid qid = new OIV10200UpdateQid();
		private DbTrans tran;

		public EquipModelDiffDao() {

		}

		public void check() throws Exception {
			DataBase database = DBManager.getMgr().getDataBase(CmDao.ADAMS);
			tran = null;
			try {
				tran = database.createDbTrans("deploy/conf/sql/" + OIV10200UpdateQid.QUERY_XML_FILE);
			} catch (Exception e) {
				Logger.logger.error(e);
				throw e;
			}

			setTrans(tran, tran);

			diff(qid.SELECT_OIV10208, qid.SELECT_OIV10200);
		}

		@Override
		protected String makeKey(OIV10200 o200) {
			return o200.getEquipMdlCd();
		}

		@Override
		protected void onCompleted(Exception ex) {
			Logger.logger.error(ex);
		}

		@Override
		protected void onCompleted(List<OIV10200> addList, List<OIV10200> chgList, List<OIV10200> delList, List<OIV10200> nothingList)
				throws Exception {

			int insertCnt = -1;
			int deleteCnt = -1;
			int updateCnt = -1;
			int nothingCnt = nothingList == null ? 0 : nothingList.size();

			if (chgList.size() > 0) {
				updateCnt = getDstTran().execute(qid.UPDATE_OIV10200__BY_EQUIPMDLCD, chgList);
			}

			getDstTran().commit();

			Logger.logger.info(CmMsg.makeCmInfo("OIV10208 & OIV10200 DIFF", deleteCnt, insertCnt, updateCnt, nothingCnt));
		}

	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 8279912046689347516L;

	public static void main(String[] args) {
		BCM0004 o107 = new BCM0004();
		try {
			o107.cron();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void cron() throws Exception {
		DataBase database = DBManager.getMgr().getDataBase(CmDao.ADAMS);
		DbTrans tran;
		try {
			tran = database.createDbTrans("deploy/conf/sql/" + OIV1020xQid.QUERY_XML_FILE);
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}

		OIV1020xQid qid = new OIV1020xQid();

		try {
			tran.start();
			int ret = tran.execute(qid.INSERT_OIV10213, null);
			ret += tran.execute(qid.INSERT_OIV10213__ADD, null);
			ret += tran.execute(qid.INSERT_OIV10213__EXISTS_EQUIP, null);
			tran.commit();
			Logger.logger.info(CmMsg.makeCmInfo("OIV10213(수집장비모델매핑내역)", -1, ret, -1));

			ret = tran.execute(qid.INSERT_OIV10200, null);
			ret += tran.execute(qid.INSERT_OIV10200__ADD, null);
			ret += tran.execute(qid.INSERT_OIV10200__EXISTS_EQUIP, null);
			tran.commit();
			Logger.logger.info(CmMsg.makeCmInfo("OIV10200(장비모델기본)", -1, ret, -1));

			// 변경분 처리
			new EquipModelDiffDao().check();

		} catch (Exception e) {
			tran.rollback();
			Logger.logger.error(e);
			throw e;
		} finally {
			tran.stop();
		}

	}

	@Override
	public String getGroup() {
		return "EQUIP";
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}

}