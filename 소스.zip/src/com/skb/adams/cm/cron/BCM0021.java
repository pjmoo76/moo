package com.skb.adams.cm.cron;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import subkjh.bas.dao.control.DaoListener;
import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.log.Logger;
import subkjh.bas.utils.FileLogger;
import subkjh.bas.utils.ObjectUtil;
//import sun.security.x509.OIDMap;

import com.skb.adams.cm.batch.Upload2DbNew;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.SwingHfcCellQid;
import com.skb.adams.cm.model.EQUIP_ID;
import com.skb.adams.cm.model.OIV10170;
import com.skb.adams.cm.model.OIV10171;
import com.skb.adams.cm.model.OIV10400;
import com.skb.adams.cm.model.ZOSS_HFC_CELL;

import fxms.bas.cron.Crontab;
import fxms.bas.fxo.FxCfg;

/**
 * ZOSS_HFC_CELL to OIV10170(커버리지셀기본), OIV10171(셀포트내역)
 * 
 * @author SUBKJH-DEV
 *
 */
public class BCM0021 extends Crontab implements DaoListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3284214266873497483L;
	private static final SimpleDateFormat YYYYMMDD = new SimpleDateFormat("yyyyMMdd");

	public static void main(String[] args) {
		BCM0021 cron = new BCM0021();
		try {
			cron.cron();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * KEY : EQUIP_ID + CCELL_NUM
	 */
	private Map<String, OIV10170> old170Map;
	private Map<String, OIV10170> cur170Map;
	private Map<String, OIV10171> o171Map;
	private Map<String, String> old400EtcMap;
	private Map<String, String> old400WideMap;
	private Map<String, EQUIP_ID> equipMap;
	private List<String> notFoundEquipList;
	private DbTrans srcTran;
	private DbTrans dstTran;
	private SwingHfcCellQid QID = new SwingHfcCellQid();
	private long maxCellId;
	private Upload2DbNew<OIV10170> upload170;
	private Upload2DbNew<OIV10171> upload171;
	private FileLogger fileLogger = null;

	@SuppressWarnings("unchecked")
	@Override
	public void cron() throws Exception {

		old170Map = new HashMap<String, OIV10170>();
		old400EtcMap = new HashMap<String, String>();
		old400WideMap = new HashMap<String, String>();
		cur170Map = new HashMap<String, OIV10170>();
		o171Map = new HashMap<String, OIV10171>();
		equipMap = new HashMap<String, EQUIP_ID>();
		notFoundEquipList = new ArrayList<String>();

		srcTran = DBManager.getMgr().getDataBase(CmDao.NEIFDB).createDbTrans("deploy/conf/sql/" + SwingHfcCellQid.QUERY_XML_FILE);
		dstTran = DBManager.getMgr().getDataBase(CmDao.ADAMS).createDbTrans("deploy/conf/sql/" + SwingHfcCellQid.QUERY_XML_FILE);

		try {
			srcTran.start();
		} catch (Exception e) {
			throw e;
		}

		try {
			dstTran.start();
		} catch (Exception e) {
			srcTran.stop();
			throw e;
		}

		upload170 = new Upload2DbNew<OIV10170>(dstTran, "OIV10170", QID.MERGE_OIV10170, QID.DELETE_OIV10170_REMOVED);
		upload171 = new Upload2DbNew<OIV10171>(dstTran, "OIV10171", QID.MERGE_OIV10171, QID.DELETE_OIV10171_REMOVED);

		maxCellId = dstTran.selectQidLong(QID.SELECT_MAX_CELLID, null, -1);
		if (maxCellId <= 0) {
			throw new Exception("현재 최대 CCELL_ID를 확인하지 못했습니다.");
		}
		Logger.logger.debug("NEXT CCELL_ID = " + makeNextCellId());

		List<EQUIP_ID> equipList = dstTran.selectQid2Res(QID.SELECT_EQUIP_ID__EQUIP_MGMT_NUM, null);
		for (EQUIP_ID e : equipList) {
			equipMap.put(e.getEquipMgmtNum(), e);
		}

		List<OIV10170> o170List = dstTran.selectQid2Res(QID.SELECT_OIV10170, null);
		for (OIV10170 o : o170List) {
			old170Map.put(o.getEquipId() + ":" + o.getCcellNum(), o);
		}

		List<OIV10400> o400List = dstTran.selectQid2Res(QID.SELECT_OIV10400, null);
		for (OIV10400 o : o400List) {
			if (o.getPortAlsNm() != null && o.getPortAlsNm().toLowerCase().startsWith("wideband")) {
				old400WideMap.put(o.getEquipId() + ":" + o.getMounLocNum() + ":" + o.getPortNum(), o.getEquipPortId());
			} else {
				old400EtcMap.put(o.getEquipId() + ":" + o.getMounLocNum() + ":" + o.getPortNum(), o.getEquipPortId());
			}
		}

		srcTran.setDaoListener(this);

		try {
			srcTran.selectQid2Res(QID.SELECT_ZOSS_HFC_CELL, null);

			upload170.close(null);
			upload171.close(null);
			
			dstTran.commit();

		} catch (Exception e) {
			dstTran.rollback();
			Logger.logger.error(e);
			throw e;
		} finally {
			try {
				srcTran.stop();
			} catch (Exception e) {
				Logger.logger.error(e);
			}
			try {
				dstTran.stop();
			} catch (Exception e) {
				Logger.logger.error(e);
			}
		}

	}

	@Override
	public String getGroup() {
		return "EQUIP";
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}

	private String makeNextCellId() {
		maxCellId++;

		String ret = String.valueOf(maxCellId);
		int size = ret.length();
		for (int i = 0; i < size; i++) {
			ret = "0" + ret;
		}

		return "SW" + ret;
	}

	public void onExecuted(Object data, Exception ex) throws Exception {

	}

	@Override
	public void onFinish(Exception ex) throws Exception {
		if (fileLogger != null) {
			fileLogger.onFinished(ex);
			fileLogger = null;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public void onSelected(int rowNo, Object data) throws Exception {

		if (fileLogger != null) {
			fileLogger.onSelected(rowNo, data);
		}

		ZOSS_HFC_CELL cell = (ZOSS_HFC_CELL) data;
		StringBuffer msg = new StringBuffer();
		String portNos[] = null;
		try {
			portNos = cell.getRefInfo().split(",");
		} catch (Exception e) {
			Logger.logger.fail(ObjectUtil.toMap(cell));
			Logger.logger.error(e);
			return;
		}

		EQUIP_ID equip = equipMap.get(cell.getEquipMgmtNum());
		if (equip == null) {
			if (notFoundEquipList.contains(cell.getEquipMgmtNum()) == false) {
				List<EQUIP_ID> equipList = dstTran.selectQid2Res(QID.SELECT_EQUIP_ID__BY_EQUIP_MGMT_NUM, cell.getEquipMgmtNum());
				if (equipList.size() == 1) {
					equip = equipList.get(0);
					equipMap.put(cell.getEquipMgmtNum(), equip);
				}
			}
		}

		if (equip == null) {
			if (notFoundEquipList.contains(cell.getEquipMgmtNum()) == false) {
				notFoundEquipList.add(cell.getEquipMgmtNum());
				Logger.logger.fail("EQUIP NOT FOUND : EQUIP_MGMT_NUM(" + cell.getEquipMgmtNum() + ")");
			}
			return;
		}

		msg.append("EQUIP_ID(" + equip.getEquipId() + ")CELL_NUM(" + cell.getCcellNum() + ")");

		OIV10170 o170 = old170Map.get(equip.getEquipId() + ":" + cell.getCcellNum());
		if (o170 == null) {
			String cellId = makeNextCellId();
			msg.append(" MAKE NEW CCELL_ID = " + cellId);
			Logger.logger.debug(msg);

			o170 = new OIV10170();
			o170.setCcellId(cellId);
			o170.setCcellNum(cell.getCcellNum());
			o170.setEquipId(equip.getEquipId());

			o170.setAuditId("MICM");

			old170Map.put(o170.getEquipId() + ":" + o170.getCcellNum(), o170);
		}

		o170.setOperTpoCd(cell.getCmtsSetTpoCd() == null ? equip.getTpoCd() : cell.getCmtsSetTpoCd());
		if (o170.getOperTpoCd() == null || o170.getOperTpoCd().length() == 0) {
			o170.setOperTpoCd("NULL");
		}

		if (cur170Map.get(o170.getEquipId() + ":" + o170.getCcellNum()) == null) {
			cur170Map.put(o170.getEquipId() + ":" + o170.getCcellNum(), o170);
			upload170.add(o170);
		}

		// portNum에 / 있으면 refInfo의 것도 만든다.
		if (cell.getRefInfo().lastIndexOf('/') > 0) {
			makeOIV10171(cell, o170, cell.getSlotRefInfo());
		}

		for (String portNum : portNos) {
			makeOIV10171(cell, o170, portNum);
		}

	}

	private void makeOIV10171(ZOSS_HFC_CELL cell, OIV10170 o170, String portNum) throws Exception {
		OIV10171 o171 = new OIV10171();
		String equipPortId;

		if (portNum.lastIndexOf('/') > 0) {
			o171.setMounLocNum(portNum.substring(0, portNum.lastIndexOf('/')));
			o171.setPortNum(portNum.substring(portNum.lastIndexOf('/') + 1));
		} else {
			o171.setMounLocNum(cell.getSlotRefInfo());
			o171.setPortNum(portNum);
		}

		String portUk = o170.getEquipId() + ":" + o171.getMounLocNum() + ":" + o171.getPortNum();

		equipPortId = old400EtcMap.get(portUk);
		if (equipPortId == null) {
			equipPortId = old400WideMap.get(portUk);
		}

		// 있으면 무시함.
		if (o171Map.get(portUk) == null) {

			o171.setCcellId(o170.getCcellId());
			o171.setCreDtm(YYYYMMDD.format(cell.getAuditDtm()));
			o171.setEquipPortId(equipPortId == null ? "NULL" : equipPortId);
			o171.setAuditId("MICM");
			o171.setNew(true);
			o171.setOtxNum(cell.getOtxNum());

			String id = o170.getEquipId() + ":" + o170.getCcellNum() + ":" + o171.getMounLocNum() + ":" + o171.getPortNum();
			if (o171Map.get(id) == null) {
				o171Map.put(id, o171);
				upload171.add(o171);
			}

		}
	}

	@Override
	public void onStart(String[] colNames) throws Exception {
		Logger.logger.debug(Arrays.toString(colNames));

		fileLogger = new FileLogger(FxCfg.getFile("datas", "swing-db", "ZOSS_HFC_CELL.data"));
		fileLogger.onStart(colNames);
	}

}
