package com.skb.adams.cm.cron;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.CmMsg;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.NeifdbQid;
import com.skb.adams.cm.model.OIV10703;

import fxms.bas.cron.Crontab;

/**
 * ZOSS_WEQP_MFACT to OIV10703(유선단말제조사)
 * 
 * @author SUBKJH-DEV
 *
 */
public class BCM0006 extends Crontab {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3970264972666706553L;

	public static void main(String[] args) {
		BCM0006 cron = new BCM0006();
		try {
			cron.cron();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void cron() throws Exception {

		try {
			copy();
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}

	}

	@Override
	public String getGroup() {
		return "WEQP";
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}

	@SuppressWarnings("unchecked")
	public void copy() throws Exception {

		DbTrans srcTran;
		DbTrans dstTran;

		srcTran = DBManager.getMgr().getDataBase(CmDao.NEIFDB).createDbTrans("deploy/conf/sql/" + NeifdbQid.QUERY_XML_FILE);
		dstTran = DBManager.getMgr().getDataBase(CmDao.ADAMS).createDbTrans("deploy/conf/sql/" + NeifdbQid.QUERY_XML_FILE);
		int count = 0;

		try {
			srcTran.start();
		} catch (Exception e) {
			throw e;
		}

		try {
			dstTran.start();
		} catch (Exception e) {
			srcTran.stop();
			throw e;
		}
		NeifdbQid qid = new NeifdbQid();

		try {
			List<OIV10703> swingList = srcTran.selectQid2Res(qid.SELECT_ZOSS_WEQP_MFACT, null);
			List<OIV10703> adamsList = dstTran.selectQid2Res(qid.SELECT_OIV10703, null);
			Map<String, OIV10703> aMap = convert(adamsList);

			for (int i = swingList.size() - 1; i >= 0; i--) {
				if (aMap.get(swingList.get(i).getWeqpMnufactCoCd()) != null) {
					swingList.remove(i);
				}
			}

			if (swingList.size() > 0) {
				count = dstTran.execute(qid.INSERT_OIV10703, swingList);
				dstTran.commit();
			}

			Logger.logger.info(CmMsg.makeCmInfo("ZOSS_WEQP_MFACT -> OIV10703(유선단말제조사)", -1, count, -1));

		} catch (Exception e) {
			dstTran.rollback();
			Logger.logger.error(e);
			throw e;
		} finally {
			try {
				srcTran.stop();
			} catch (Exception e) {
				Logger.logger.error(e);
			}
			try {
				dstTran.stop();
			} catch (Exception e) {
				Logger.logger.error(e);
			}
		}

	}

	private Map<String, OIV10703> convert(List<OIV10703> list) {
		Map<String, OIV10703> map = new HashMap<String, OIV10703>();
		for (OIV10703 o : list) {
			map.put(o.getWeqpMnufactCoCd(), o);
		}
		return map;
	}

}