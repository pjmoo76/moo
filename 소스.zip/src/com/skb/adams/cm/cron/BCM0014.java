package com.skb.adams.cm.cron;

import java.util.Arrays;
import java.util.List;

import com.skb.adams.cm.CmMsg;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.OIV10808Qid;
import com.skb.adams.cm.dao.OIV10970Qid;
import com.skb.adams.cm.model.OIV10970;

import fxms.bas.cron.Crontab;
import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.Logger;

/**
 * 유선단말을 집계한다. OIV10808 (유선단말집계)
 * 
 * @author SUBKJH-DEV
 *
 */
public class BCM0014 extends Crontab {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2519192609007524868L;

	public static void main(String[] args) {
		BCM0014 cron = new BCM0014();
		try {
			cron.cron();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void cron() throws Exception {

		DataBase database = DBManager.getMgr().getDataBase(CmDao.ADAMS);
		DbTrans tran;
		OIV10808Qid QID = new OIV10808Qid();
		OIV10970Qid logQid = new OIV10970Qid();

		try {
			tran = database.createDbTrans("deploy/conf/sql/" + OIV10808Qid.QUERY_XML_FILE//
			, "deploy/conf/sql/" + OIV10970Qid.QUERY_XML_FILE);
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}

		try {
			tran.start();

			String yyyymmdd = CmDao.getYYYYMMDD(System.currentTimeMillis());

			OIV10970 o808Log = new OIV10970("OIV10808", yyyymmdd);
			int delCntL3 = tran.execute(QID.DELETE_OIV10808, null);
			int addCntL3 = tran.execute(QID.INSERT_OIV10808, null);
			o808Log.setCreCnt(addCntL3);

			OIV10970 o813Log = new OIV10970("OIV10813", yyyymmdd);
			int delCntL2 = tran.execute(QID.DELETE_OIV10813, null);
			int addCntL2 = tran.execute(QID.INSERT_OIV10813, null);
			o813Log.setCreCnt(addCntL2);

			OIV10970 o814Log = new OIV10970("OIV10814", yyyymmdd);
			int delCntCell = tran.execute(QID.DELETE_OIV10814, null);
			int addCntCell = tran.execute(QID.INSERT_OIV10814, null);
			o814Log.setCreCnt(addCntCell);

			// 2018.03.28, 김종훈) 유선단말모델버전표준기준 테이블에 버전 자동 추가용 쿼리 실행
			tran.execute(QID.MERGE_OIV10702, yyyymmdd);

			tran.commit();

			List<OIV10970> o907List = Arrays.asList(o808Log, o813Log, o814Log);
			tran.execute(logQid.DELETE_OIV10970, o907List);
			tran.execute(logQid.INSERT_OIV10970, o907List);

			tran.commit();

			Logger.logger.info(CmMsg.makeCmInfo("OIV10808(유선단말집계-L3)", delCntL3, addCntL3, -1));
			Logger.logger.info(CmMsg.makeCmInfo("OIV10813(유선단말집계-L2)", delCntL2, addCntL2, -1));
			Logger.logger.info(CmMsg.makeCmInfo("OIV10814(유선단말집계-CELL)", delCntCell, addCntCell, -1));

		} catch (Exception e) {
			tran.rollback();
			Logger.logger.error(e);
			throw e;
		} finally {
			tran.stop();
		}

	}

	@Override
	public String getGroup() {
		return "WEQP";
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}

}