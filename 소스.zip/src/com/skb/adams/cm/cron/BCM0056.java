package com.skb.adams.cm.cron;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import subkjh.bas.dao.control.DaoListener;
import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.CmMsg;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.ZossSvcTechMthdQid;

import fxms.bas.cron.Crontab;
import fxms.bas.fxo.thread.QueueFxThread;

/**
 * ZOSS_SVC_TECH_MTHD to OES10400(서비스기술방식기본)
 * 
 * @author
 *
 */
public class BCM0056 extends Crontab {

	private static final long serialVersionUID = 7687982824089909091L;

	class InsertThread extends QueueFxThread<List<Object>> {

		private boolean toFinish = false;
		private DbTrans dstTran;

		public InsertThread(DbTrans dstTran) {
			super("FX_TMP_OES10400", 5);
			this.dstTran = dstTran;
		}

		@Override
		protected void doInit() {

		}

		@Override
		protected void doWork(List<Object> dataList) throws Exception {

			Logger.logger.debug("SIZE IN QUEUE : " + getSizeInQueue());

			dstTran.execute(qid.INSERT_FX_TMP_OES10400, dataList);
			dstTran.commit();
		}

		@Override
		protected void onNoDatas(long index) {

			Logger.logger.debug("NO DATAS: " + index);

			if (toFinish) {
				this.stop("no more datas");
			}
		}
	}

	class ZossSvcTechMthd implements DaoListener {

		private List<Object> oList = new ArrayList<Object>();
		private InsertThread thread;
		private DbTrans dstTran;
		private int count;

		public ZossSvcTechMthd(DbTrans dstTran) {
			this.dstTran = dstTran;
		}

		public void onExecuted(Object data, Exception ex) throws Exception {

		}

		@Override
		public void onFinish(Exception ex) throws Exception {

			if (oList.size() > 0) {

				count += oList.size();

				thread.add(oList);

				thread.toFinish = true;

				thread.join();
			}

			Logger.logger.info(CmMsg.makeCmInfo("ZOSS_SVC_TECH_MTHD -> FX_TMP_OES10400", -1, count, -1));

		}

		@Override
		public void onSelected(int rowNo, Object data) throws Exception {
			oList.add(data);

			if (oList.size() >= 100000) {
				count += oList.size();
				thread.add(oList);
				oList = new ArrayList<Object>();
			}
		}

		@Override
		public void onStart(String[] colNames) throws Exception {
			Logger.logger.debug(Arrays.toString(colNames));

			try {
				dstTran.execute(qid.DROP_TABLE_FX_TMP_OES10400, null);
			} catch (Exception e) {
				Logger.logger.error(e);
			}

			try {
				dstTran.execute(qid.CREATE_TABLE_FX_TMP_OES10400, null);
			} catch (Exception e) {
				Logger.logger.error(e);
			}

			thread = new InsertThread(dstTran);
			thread.start();
		}
	}

	/**
	 * 
	 */

	public static void main(String[] args) {
		BCM0056 cron = new BCM0056();
		try {
			cron.cron();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private ZossSvcTechMthdQid qid = new ZossSvcTechMthdQid();

	private void copyToFxTmpOES10400() throws Exception {

		DbTrans srcTran;
		DbTrans dstTran;

		srcTran = DBManager.getMgr().getDataBase(CmDao.NEIFDB).createDbTrans("deploy/conf/sql/" + ZossSvcTechMthdQid.QUERY_XML_FILE);
		dstTran = DBManager.getMgr().getDataBase(CmDao.ADAMS).createDbTrans("deploy/conf/sql/" + ZossSvcTechMthdQid.QUERY_XML_FILE);

		try {
			srcTran.start();
		} catch (Exception e) {
			throw e;
		}

		try {
			dstTran.start();
		} catch (Exception e) {
			srcTran.stop();
			throw e;
		}

		ZossSvcTechMthd daoListener = new ZossSvcTechMthd(dstTran);
		srcTran.setDaoListener(daoListener);

		try {
			srcTran.selectQid2Res(qid.SELECT_ZOSS_SVC_TECH_MTHD, null);

			int mergeCount = dstTran.execute(qid.MERGE_OES10400__BY_FX_TMP_OES10400, null);
			//int deleteCount = dstTran.execute(qid.DELETE_OES10400__BY_FX_TMP_OES10400, null);
			dstTran.commit();

			Logger.logger.info(CmMsg.makeCmInfo("FX_TMP_OES10400 -> OES10400 (merge)", -1, -1, mergeCount));
			//Logger.logger.info(CmMsg.makeCmInfo("FX_TMP_OES10400 -> OES10400 (delete)", deleteCount, -1, -1));
			
		} catch (Exception e) {
			dstTran.rollback();
			Logger.logger.error(e);
			Logger.logger.fail(CmMsg.makeCmInfo("ZOSS_SVC_TECH_MTHD -> OES10400 (ERROR)", -1, -1, -1));
			throw e;
		} finally {
			try {
				srcTran.stop();
			} catch (Exception e) {
				Logger.logger.error(e);
			}
			try {
				dstTran.stop();
			} catch (Exception e) {
				Logger.logger.error(e);
			}
		}

	}

	@Override
	public void cron() throws Exception {

		try {
			copyToFxTmpOES10400();
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}
	}

	@Override
	public String getGroup() {
		return "ZOSS";
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}

}