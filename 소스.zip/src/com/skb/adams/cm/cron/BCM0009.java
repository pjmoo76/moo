package com.skb.adams.cm.cron;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.CmMsg;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.OIV10700Qid;

import fxms.bas.cron.Crontab;

/**
 * OIV10709(SWING유선단말모델기본)에서<br>
 * 1. OIV10700(유선단말모델기본)에 추가한다.
 * 2. OIV10700(유선단말모델기본)에 삭제처리한다.
 * 
 * @author SUBKJH-DEV
 *
 */
public class BCM0009 extends Crontab {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8326392767344732262L;

	public static void main(String[] args) {
		BCM0009 o107 = new BCM0009();
		try {
			o107.cron();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void cron() throws Exception {
		DataBase database = DBManager.getMgr().getDataBase(CmDao.ADAMS);
		DbTrans tran;
		try {
			tran = database.createDbTrans("deploy/conf/sql/" + OIV10700Qid.QUERY_XML_FILE	);
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}

		OIV10700Qid qid = new OIV10700Qid();

		try {
			tran.start();
			int ret = tran.execute(qid.INSERT_OIV10700, null);
			int ret2 = tran.execute(qid.UPDATE_OIV10700, null);
			tran.commit();
			
			Logger.logger.info(CmMsg.makeCmInfo("OIV10700(유선단말모델기본)", -1, ret, -1));
			Logger.logger.info(CmMsg.makeCmInfo("OIV10700(유선단말모델기본 DEL처리)", -1, ret2, -1));

		} catch (Exception e) {
			tran.rollback();
			Logger.logger.error(e);
			throw e;
		} finally {
			tran.stop();
		}

	}

	@Override
	public String getGroup() {
		return "WEQP";
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}

}