package com.skb.adams.cm.cron;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import com.skb.adams.cm.service.SwingNEIFService;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.Logger;
import fxms.bas.cron.Crontab;

public class MakeOiv1040x extends Crontab {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2838235669400749754L;

	@Override
	public void cron() throws Exception {
		String fileName = "D:/skbmi/swing_neif/BOS2IFNMS_25_20170830.txt";
		SwingNEIFService swingNEIFService = new SwingNEIFService();
		//swingNEIFService.loadUpdate(fileName);
	}

	@Override
	public String getGroup() {
		return null;
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}
}
