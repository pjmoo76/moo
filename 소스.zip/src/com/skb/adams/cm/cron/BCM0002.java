package com.skb.adams.cm.cron;

import subkjh.bas.log.Logger;

import com.skb.adams.cm.dao.NeifdbQid;
import com.skb.adams.cm.dao.ZossCopyDao;

import fxms.bas.cron.Crontab;

/**
 * SWING 장비모델기본(ZOSS_EQUIP_MDL)을 ADAMS SWING장비모델기본(OIV10208)으로 복사 
 * 
 * @author SUBKJH-DEV
 *
 */
public class BCM0002 extends Crontab {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6394431113545986462L;

	public static void main(String[] args) {
		BCM0002 cron = new BCM0002();
		try {
			cron.cron();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void cron() throws Exception {

		try {
			NeifdbQid qid = new NeifdbQid();

			ZossCopyDao dao = new ZossCopyDao();
			dao.copy("ZOSS_EQUIP_MDL -> OIV10208(SWING장비모델기본)", qid.SELECT_ZOSS_EQUIP_MDL, qid.INSERT_OIV10208, qid.DELETE_OIV10208);
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}

	}

	@Override
	public String getGroup() {
		return "EQUIP";
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}

}
