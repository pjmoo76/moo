package com.skb.adams.cm.cron;

import subkjh.bas.log.Logger;

import com.skb.adams.cm.dao.NeifdbQid;
import com.skb.adams.cm.dao.ZossCopyDao;

import fxms.bas.cron.Crontab;

/**
 * ZOSS_WEQP_MDL to OIV10709 (유선단말모델)
 * 
 * @author SUBKJH-DEV
 *
 */
public class BCM0007 extends Crontab {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7520494924495404334L;

	public static void main(String[] args) {
		BCM0007 cron = new BCM0007();
		try {
			cron.cron();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void cron() throws Exception {

		try {
			NeifdbQid qid = new NeifdbQid();

			ZossCopyDao dao = new ZossCopyDao();
			dao.copy("ZOSS_WEQP_MDL -> OIV10709", qid.SELECT_ZOSS_WEQP_MDL, qid.INSERT_OIV10709, qid.DELETE_OIV10709);
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}

	}

	@Override
	public String getGroup() {
		return "WEQP";
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}

}