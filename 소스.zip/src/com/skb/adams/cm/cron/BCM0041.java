package com.skb.adams.cm.cron;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.CmMsg;
import com.skb.adams.cm.dao.CmDao;

import fxms.bas.cron.Crontab;

public class BCM0041 extends Crontab {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2116298218337801242L;

	public static void main(String[] args) {
		BCM0041 cron = new BCM0041();
		try {
			cron.cron();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void cron() throws Exception {
		// TODO Auto-generated method stub
		DataBase database = DBManager.getMgr().getDataBase(CmDao.ADAMS);
		DbTrans tran;
		try {
			tran = database.createDbTrans("deploy/conf/sql/oco10100.xml");
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}

		try {

			tran.start();

			int cnt = tran.execute("UPDATE_OCO10100__BY_OCO10108", null);
			
			tran.execute("UPDATE_OCO10100_MNTG_ACNT_RGSTR_ID__BY_OCO10108", null);

			tran.commit();

			Logger.logger.info(CmMsg.makeCmInfo("OCO10100(OCO10108)", -1, -1, cnt));

		} catch (Exception e) {
			tran.rollback();
			Logger.logger.error(e);
			throw e;
		} finally {
			tran.stop();
		}
		
	}

	@Override
	public String getGroup() {
		return "STAT";
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}

}
