package com.skb.adams.cm.cron;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.CmMsg;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.OIV10113Qid;
import com.skb.adams.cm.dao.OIV10970Qid;
import com.skb.adams.cm.model.OIV10970;

import fxms.bas.cron.Crontab;

/**
 * OIV10113(장비집계) 일단위로 장비 통계 정보를 생성한다.
 * 
 * @author SUBKJH-DEV
 *
 */
public class BCM0011 extends Crontab {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4414670786471059229L;

	public static void main(String[] args) {
		BCM0011 cron = new BCM0011();
		try {
			cron.cron();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void cron() throws Exception {

		DataBase database = DBManager.getMgr().getDataBase(CmDao.ADAMS);
		DbTrans tran;
		OIV10113Qid QID = new OIV10113Qid();
		OIV10970Qid logQid = new OIV10970Qid();
		String yyyymmdd = CmDao.getYYYYMMDD(System.currentTimeMillis());

		try {
			tran = database.createDbTrans("deploy/conf/sql/" + OIV10113Qid.QUERY_XML_FILE//
			, "deploy/conf/sql/" + OIV10970Qid.QUERY_XML_FILE);
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}

		try {
			tran.start();

			OIV10970 o113Log = new OIV10970("OIV10113", yyyymmdd);
			int delCnt = tran.execute(QID.DELETE_OIV10113, null);
			int addCnt = tran.execute(QID.INSERT_OIV10113, null);
			o113Log.setCreCnt(addCnt);

			tran.commit();

			tran.execute(logQid.DELETE_OIV10970, o113Log);
			tran.execute(logQid.INSERT_OIV10970, o113Log);

			tran.commit();

			Logger.logger.info(CmMsg.makeCmInfo("OIV10113(장비집계)", delCnt, addCnt, -1));

		} catch (Exception e) {
			tran.rollback();
			Logger.logger.error(e);
			throw e;
		} finally {
			tran.stop();
		}

	}

	@Override
	public String getGroup() {
		return "EQUIP";
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}

}
