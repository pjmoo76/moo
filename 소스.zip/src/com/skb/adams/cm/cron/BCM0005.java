package com.skb.adams.cm.cron;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.CmMsg;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.OIV1010xQid;
import com.skb.adams.cm.function.FOIV10100_01;

import fxms.bas.cron.Crontab;

/**
 * OIV10112(SWING장비기본)에서 아래 테이블에 기록<br>
 * 1. OIV10107 (수집장비매핑)<br>
 * 2. OIV10100 (장비기본), SWING에 없는 장비DEL_YN = 'Y'<br>
 * 3. OIV10115 (망구분별장비목록)<br>
 *  
 *  2023-12-12일  NBS 로 전환  JOB_ID : ADAMS_CM_EAI_MERGE_OIV10100
 * @author SUBKJH-DEV
 *
 */
public class BCM0005 extends Crontab {


	/**
	 * 
	 */
	private static final long serialVersionUID = 8279912046689347516L;

	public static void main(String[] args) {
		BCM0005 o107 = new BCM0005();
		Logger.logger.info(">>>Run 2020-11-05");
		try {
			o107.cron();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void cron() throws Exception {
		DataBase database = DBManager.getMgr().getDataBase(CmDao.ADAMS);
		DataBase database2 = DBManager.getMgr().getDataBase(CmDao.ADAMS_MIAPP);
		DataBase model_database = DBManager.getMgr().getDataBase(CmDao.ADAMS);
		DbTrans tran;
		DbTrans tran2;
		DbTrans model_tran;
		
		try {
			tran = database.createDbTrans("deploy/conf/sql/" + OIV1010xQid.QUERY_XML_FILE);
			tran2 = database2.createDbTrans("deploy/conf/sql/" + OIV1010xQid.QUERY_XML_FILE);
			model_tran = model_database.createDbTrans("deploy/conf/sql/" + OIV1010xQid.QUERY_XML_FILE);
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}
				
		int add100, delete100;
		OIV1010xQid qid = new OIV1010xQid();

		try {
			tran.start();

			int add107 = tran.execute(qid.INSERT_OIV10107_ASIS, null);
			add107 += tran.execute(qid.INSERT_OIV10107, null);

			add100 = tran.execute(qid.INSERT_OIV10100, null);

			int update100 = tran.execute(qid.UPDATE_OIV10100_DELYN__BY_SWING_FOUND, null);
			delete100 = tran.execute(qid.UPDATE_OIV10100_DELYN__BY_SWING_NOT_FOUND, null);

			int add115 = tran.execute(qid.INSERT_OIV10115__MODEL_TYPE, null);
			add115 += tran.execute(qid.INSERT_OIV10115__EQUIP_USG, null);
			/* 21.11.24 망-전송장비 매핑목록 현행화로 인해 제거함. */
			//add115 += tran.execute(qid.INSERT_OIV10115__EQUIP_TYP_CL_CD, null); /* 2020-12-07 INSERT_OIV10115__EQUIP_TYP_CL_CD 추가 */

			int del115 = tran.execute(qid.DELETE_OIV10115__DEL_Y, null);
			
			/* FOMS 관련된 삭제로직 추가 2023-04-12 강대윤  */
			int del115_2 = tran.execute(qid.DELETE_OIV10115_FOMS, null);
			
			int merge100 = tran.execute(qid.MERGE_OIV10100_EQUIP_ADDR_IP_BY__OIV10112, null);
			
			int mergeAgw100 = tran.execute(qid.MERGE_OIV10100_AGW_EQUIP_IP_ADDR_BY__OIV10112, null);

			// 전송망 장비에서 별도로 작업이 있어서 해당 처리를 주석처리함(2022-01-21)
			//int merge011 = tran.execute(qid.MERGE_OIV10011_IEQUIP_NET_CL_CD_BY__OIV10112, null);
			
			tran.commit();

			Logger.logger.info(CmMsg.makeCmInfo("OIV10107(수집장비매핑)", -1, add107, -1));
			Logger.logger.info(CmMsg.makeCmInfo("OIV10100(장비기본)", delete100, add100, update100));
			Logger.logger.info(CmMsg.makeCmInfo("OIV10100(장비기본)_EQUIP_IP_ADDR MERGE OIV10112(SWING장비기본)", merge100));
			Logger.logger.info(CmMsg.makeCmInfo("OIV10100(장비기본)_AGW_EQUIP_IP_ADDR MERGE OIV10112(SWING장비기본)", mergeAgw100));
			// 전송망 장비에서 별도로 작업이 있어서 해당 처리를 주석처리함(2022-01-21)
			//Logger.logger.info(CmMsg.makeCmInfo("OIV10011(장비부가)_IEQUIP_NET_CL_CD MERGE OIV10112(SWING장비기본)", merge011));
			Logger.logger.info(CmMsg.makeCmInfo("OIV10115(망구분별장비목록)", del115, add115, del115_2));
			

			// 속성변경 처리
			new FOIV10100_01().run();

			// 장비모델코드변경 처리 추가(2023-03-22)
			// 처리 기준 : SQL 주석 확인
			model_tran.start();
			int mergeEquipMdlCd100 = model_tran.execute(qid.MERGE_OIV10100_EQUIP_MDL_CD_BY__OIV10112, null); 
			model_tran.commit(); 
			Logger.logger.info(CmMsg.makeCmInfo("OIV10100(장비기본)_EQUIP_MDL_CD MERGE OIV10112(SWING장비기본)", mergeEquipMdlCd100)); 
			
		} catch (Exception e) {
			tran.rollback();
			model_tran.rollback();

			Logger.logger.error(e);
			
			tran2.start();
			// SMS 전송
			tran2.execute(qid.INSERT_TBL_SUBMIT_QUEUE, null);
			tran2.commit();
			
			throw e;
		} finally {
			tran.stop();
			tran2.stop();
			model_tran.stop();
		}

	}

	@Override
	public String getGroup() {
		return "EQUIP";
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}

}
