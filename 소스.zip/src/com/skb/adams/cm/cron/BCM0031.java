package com.skb.adams.cm.cron;

import java.util.Arrays;
import java.util.List;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.CmMsg;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.OIV10114Qid;
import com.skb.adams.cm.dao.OIV10970Qid;
import com.skb.adams.cm.model.OIV10970;

import fxms.bas.cron.Crontab;

/**
 * 사설공유기 통계<br>
 * from<br>
 * OIV10821(사설공유기목록)<br>
 * to <br>
 * OIV10114(사설공유기집계)<br>
 * OIV10117(사설공유기센터별집계)<br>
 * 
 * @author SUBKJH-DEV
 *
 */
public class BCM0031 extends Crontab {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5931772495507063421L;

	public static void main(String[] args) {
		BCM0031 cron = new BCM0031();
		try {
			cron.cron();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void cron() throws Exception {

		DataBase database = DBManager.getMgr().getDataBase(CmDao.ADAMS);
		DbTrans tran;
		OIV10114Qid QID = new OIV10114Qid();
		OIV10970Qid logQid = new OIV10970Qid();
		try {
			tran = database.createDbTrans("deploy/conf/sql/" + OIV10114Qid.QUERY_XML_FILE //
			, "deploy/conf/sql/" + OIV10970Qid.QUERY_XML_FILE);
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}

		try {

			String yyyymmdd = CmDao.getYYYYMMDD(System.currentTimeMillis());

			tran.start();

			OIV10970 o114Log = new OIV10970("OIV10114", yyyymmdd);
			tran.execute(QID.DELETE_OIV10114, null);
			int o114Cnt = tran.execute(QID.INSERT_OIV10114__01_FTTX, null);
			o114Cnt += tran.execute(QID.INSERT_OIV10114__01_HFC, null);
			o114Cnt += tran.execute(QID.INSERT_OIV10114__02_FTTX, null);
			o114Cnt += tran.execute(QID.INSERT_OIV10114__02_HFC, null);
			o114Log.setCreCnt(o114Cnt);

			OIV10970 o117Log = new OIV10970("OIV10117", yyyymmdd);
			tran.execute(QID.DELETE_OIV10117, null);
			int o117Cnt = tran.execute(QID.INSERT_OIV10117__01_FTTX, null);
			o117Cnt += tran.execute(QID.INSERT_OIV10117__01_HFC, null);
			o117Cnt += tran.execute(QID.INSERT_OIV10117__02_FTTX, null);
			o117Cnt += tran.execute(QID.INSERT_OIV10117__02_HFC, null);
			o117Log.setCreCnt(o117Cnt);

			tran.commit();

			List<OIV10970> o907List = Arrays.asList(o114Log, o117Log);
			tran.execute(logQid.DELETE_OIV10970, o907List);
			tran.execute(logQid.INSERT_OIV10970, o907List);

			tran.commit();

			Logger.logger.info(CmMsg.makeCmInfo("OIV10114(사설공유기집계)", -1, o114Cnt, -1));
			Logger.logger.info(CmMsg.makeCmInfo("OIV10117(사설공유기센터별집계)", -1, o117Cnt, -1));

		} catch (Exception e) {
			tran.rollback();
			Logger.logger.error(e);
			throw e;
		} finally {
			tran.stop();
		}

	}

	@Override
	public String getGroup() {
		return "STAT";
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}

}