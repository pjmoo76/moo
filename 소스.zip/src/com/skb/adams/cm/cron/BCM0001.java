package com.skb.adams.cm.cron;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.fxdao.control.DiffDao;
import subkjh.bas.log.Logger;
import subkjh.bas.utils.FileLogger;

import com.skb.adams.cm.CmMsg;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.NeifdbQid;
import com.skb.adams.cm.model.OIV10300;

import fxms.bas.cron.Crontab;

/**
 * SWING 국사기본(ZOSS_TPO)을 ADAMS 국사기본(OIV10300)으로 복사
 * 
 * @author SUBKJH-DEV
 *
 */
public class BCM0001 extends Crontab {

	class TpoDiffDao extends DiffDao<OIV10300> {

		public TpoDiffDao(DbTrans srcTran, DbTrans dstTran) {
			super(srcTran, dstTran);
		}

		@Override
		protected String makeKey(OIV10300 o300) {
			return o300.getTpoCd();
		}

		@Override
		protected void onCompleted(Exception ex) {

			Logger.logger.error(ex);

		}

		@Override
		protected void onSelected(List<OIV10300> srcList, List<OIV10300> dstList) {
			try {
				new FileLogger(CmDao.getSwingDataFile("ZOSS_TPO.data"), srcList);
			} catch (Exception e) {
				Logger.logger.error(e);
			}
		}

		@Override
		protected void onCompleted(List<OIV10300> addList, List<OIV10300> chgList, List<OIV10300> delList, List<OIV10300> nothingList)
				throws Exception {

			int insertCnt = 0;
			int deleteCnt = 0;
			int updateCnt = 0;
			int nothingCnt = nothingList == null ? 0 : nothingList.size();

			// 추가
			if (addList.size() > 0) {
				insertCnt = getDstTran().execute(qid.INSERT_OIV10300, addList);
			}
			if (chgList.size() > 0) {
				updateCnt = getDstTran().execute(qid.UPDATE_OIV10300, chgList);
			}

			// 2018.03.29, 김종훈) SWING에서 없어진 국사 처리하는 쿼리
			if (delList.size() > 0) {
				deleteCnt = getDstTran().execute(qid.UPDATE_OIV10300_SWING_DELETED, delList);
			}
			// 2018.03.29, 김종훈) 장비가 없는 국사에 대한 사용여부 처리
			int useNCnt = getDstTran().execute(qid.UPDATE_OIV10300_USE_N, null);
			// 2018.03.29, 김종훈) 장비가 있는 국사에 대한 사용여부 처리
			int useYCnt = getDstTran().execute(qid.UPDATE_OIV10300_USE_Y, null);

			getDstTran().commit();

			Logger.logger.info(CmMsg.makeCmInfo("ZOSS_TPO -> OIV10300(국사기본)", deleteCnt, insertCnt, updateCnt, nothingCnt));
			Logger.logger.info(CmMsg.makeCmInfo("ZOSS_TPO -> OIV10300(국사기본)", "tpo-use-n=" + useNCnt + ", tpo-use-y=" + useYCnt));
		}

		protected void onDiff(Map<String, Object[]> diffMap) {
			StringBuffer sb = new StringBuffer();

			for (String key : diffMap.keySet()) {
				sb.append(key);
				sb.append("=");
				sb.append(Arrays.toString(diffMap.get(key)));
			}

			Logger.logger.trace(sb.toString());
		}

	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 2610149772331800794L;

	public static void main(String[] args) {
		BCM0001 cron = new BCM0001();
		try {
			cron.cron();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private NeifdbQid qid = new NeifdbQid();

	public void copy() throws Exception {

		DbTrans srcTran;
		DbTrans dstTran;

		srcTran = DBManager.getMgr().getDataBase(CmDao.NEIFDB).createDbTrans("deploy/conf/sql/neifdb.xml");
		dstTran = DBManager.getMgr().getDataBase(CmDao.ADAMS).createDbTrans("deploy/conf/sql/neifdb.xml");

		TpoDiffDao diffDao = new TpoDiffDao(srcTran, dstTran);
		diffDao.diff(qid.SELECT_ZOSS_TPO, qid.SELECT_OIV10300);

	}

	@Override
	public void cron() throws Exception {

		try {
			copy();
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}

	}

	@Override
	public String getGroup() {
		return "TPO";
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}

}