package com.skb.adams.cm.cron;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.CmMsg;
import com.skb.adams.cm.dao.CmDao;
import com.skb.adams.cm.dao.OIV10191Qid;
import com.skb.adams.cm.dao.OIV10970Qid;
import com.skb.adams.cm.model.OIV10970;

import fxms.bas.cron.Crontab;

/**
 * OIV10191(UPS집계내역) 생성
 * 
 * @author SUBKJH-DEV
 *
 */
public class BCM0032 extends Crontab {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5931772495507063421L;

	public static void main(String[] args) {
		BCM0032 cron = new BCM0032();
		try {
			cron.cron();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void cron() throws Exception {

		DataBase database = DBManager.getMgr().getDataBase(CmDao.ADAMS);
		DbTrans tran;
		OIV10191Qid QID = new OIV10191Qid();
		OIV10970Qid logQid = new OIV10970Qid();
		try {
			tran = database.createDbTrans("deploy/conf/sql/" + OIV10191Qid.QUERY_XML_FILE //
			, "deploy/conf/sql/" + OIV10970Qid.QUERY_XML_FILE);
		} catch (Exception e) {
			Logger.logger.error(e);
			throw e;
		}

		try {

			String yyyymmdd = CmDao.getYYYYMMDD(System.currentTimeMillis());

			tran.start();

			OIV10970 o191Log = new OIV10970("OIV10191", yyyymmdd);
			tran.execute(QID.DELETE_OIV10191, yyyymmdd);
			
			int cnt = tran.execute(QID.INSERT_OIV10191, yyyymmdd);
			o191Log.setCreCnt(cnt);

			tran.commit();

			tran.execute(logQid.DELETE_OIV10970, o191Log);
			tran.execute(logQid.INSERT_OIV10970, o191Log);

			tran.commit();

			Logger.logger.info(CmMsg.makeCmInfo("OIV10191(UPS집계내역)", -1, cnt, -1));

		} catch (Exception e) {
			tran.rollback();
			Logger.logger.error(e);
			throw e;
		} finally {
			tran.stop();
		}

	}

	@Override
	public String getGroup() {
		return "STAT";
	}

	@Override
	public String getLog() {
		return null;
	}

	@Override
	public int getOpcode() {
		return 0;
	}

}