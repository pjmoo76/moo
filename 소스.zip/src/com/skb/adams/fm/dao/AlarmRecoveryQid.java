package com.skb.adams.fm.dao;

public class AlarmRecoveryQid {
	public final String QUERY_XML_FILE = "deploy/conf/sql/AlarmRecovery.xml";
	public final String SELECT_DABL_NUM = "SELECT_DABL_NUM";
	public final String SELECT_EQUIP_INFO__BY_EQUIP_TID_VAL = "SELECT_EQUIP_INFO__BY_EQUIP_TID_VAL";
	public final String SELECT_EQUIP_INFO__BY_EQUIP_ID = "SELECT_EQUIP_INFO__BY_EQUIP_ID";
	public final String SELECT_EQUIP_INFO__BY_TEAMS = "SELECT_EQUIP_INFO__BY_TEAMS";
	public final String SELECT_EQUIP_INFO__BY_SBNNMS = "SELECT_EQUIP_INFO__BY_SBNNMS";
	public final String SELECT_EQUIP_INFO__BY_RMS = "SELECT_EQUIP_INFO__BY_RMS";
	public final String INSERT_OMN30110 = "INSERT_OMN30110";
	public final String INSERT_OMN30111 = "INSERT_OMN30111";
	public final String INSERT_OMN30120 = "INSERT_OMN30120";
	public final String INSERT_OMN30130 = "INSERT_OMN30130";
	
}
