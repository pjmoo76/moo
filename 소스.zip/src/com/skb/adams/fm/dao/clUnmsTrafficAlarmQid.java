package com.skb.adams.fm.dao;

public class clUnmsTrafficAlarmQid {
	public final String QUERY_XML_FILE = "clUnmsTrafficAlarm.xml";

	public final String SELECT_OMN30203 = "SELECT_OMN30203";
	public final String SELECT_OMN10223 = "SELECT_OMN10223";
	public final String SELECT_OMN10221 = "SELECT_OMN10221";

	public final String SELECT_PSTN_ROUTE_CDR_TRF = "SELECT_PSTN_ROUTE_CDR_TRF";
	public final String SELECT_PSTN_ROUTE_MSG_TRF = "SELECT_PSTN_ROUTE_MSG_TRF";

	public final String SELECT_PSTN_SERVICE_CDR_TRF = "SELECT_PSTN_SERVICE_CDR_TRF";
	public final String SELECT_PSTN_SERVICE_MSG_TRF = "SELECT_PSTN_SERVICE_MSG_TRF";

	public final String SELECT_VOIP_TRF = "SELECT_VOIP_TRF";

	public final String INSERT_OMN30131_ROUTE	= "INSERT_OMN30131_ROUTE";
	public final String INSERT_OMN30131_SERVICE = "INSERT_OMN30131_SERVICE";
	public final String INSERT_OMN30131_VOIP = "INSERT_OMN30131_VOIP";
	
	public final String UPDATE_OMN30131_AUTO_RLSE = "UPDATE_OMN30131_AUTO_RLSE";

}
