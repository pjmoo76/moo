package com.skb.adams.fm.service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.sql.SQLException;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.concurrent.BlockingQueue;

import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

import subkjh.bas.BasCfg;
import subkjh.bas.dao.control.DaoListener;
import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.LOG_LEVEL;
import subkjh.bas.log.Logger;

import com.skb.adams.cm.util.DateUtils;
import com.skb.adams.cm.util.MiscUtils;
import com.skb.adams.cm.util.StringUtils;
import com.skb.adams.co.service.TimeEventReceiver;
import com.skb.adams.co.service.TimerService;
import com.skb.adams.fm.dao.clUnmsTrafficAlarmQid;
import com.skb.adams.fm.model.FmConstants;
import com.skb.adams.fm.model.OMN10221;
import com.skb.adams.fm.model.OMN10223;
import com.skb.adams.fm.model.OMN20305;
import com.skb.adams.fm.model.OMN30131;
import com.skb.adams.fm.model.OMN30203;
import com.skb.adams.fm.model.PrfmDablGrLstCttEnum;
import com.skb.adams.fm.model.UnmsTrafficPI;
import com.skb.adams.fm.service.unms.PduEssTrfMsgEnum;
import com.skb.adams.fm.service.unms.PduVoipCallTrfMsgEnum;
import com.skb.adams.fm.service.unms.UnmsHeader;
import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.EnvManager;

import fxms.bas.cron.Cron;

public class UnmsTrafficReceiver implements DaoListener, TimeEventReceiver {

	static final protected String C_TRF_TYPE	= "TRF_TYPE";

	final private int	SOCKET_TIME_OUT	= (60*5);	// 5 minute
	final private int	SLEEP_TIME		= 5;

	final private byte 	IDENTIFIER		= 0x1f;
	
	final private String	CHARSET_NAME	= "EUC-KR";

//	final private String	login = "daims_test";
//	final private String	password = "5fbbbd91ecb1cbe2a726b1f53b8fd51b9becfa9e0a4758f21948a363714fc57c1342abdd9300ba51e49c2f1870ed864814275a4085b63d1302adaf2939954d0c";
	final private String	login = "adams";
	final private String	password = "adams";

	final private int PSTN_PRFM_DABL_GR_LST_CTT_LEN	= 11;
	final private int VOIP_PRFM_DABL_GR_LST_CTT_LEN	= 12;

	private	DbTrans					tran	= null;
	private	clUnmsTrafficAlarmQid	QID		= null;

	UnmsTrafficThresholdManager thresholdMgr = null;
	private HashMap<String, OMN30203> omn30203Map = null;
	private HashMap<String, String> autoRlseMap = null; 
	
	final private	int	STEP_OMN30203	= 1;
	final private	int	STEP_OMN10223	= 2;
	final private	int	STEP_OMN10221	= 3;
	
	private	int		step;

	private Socket	sock;
	private String	ipAddress;
	private int		portNo		= 0;
	private	int		timeOut		= 0;
	private	OutputStream	os	= null;
	private InputStream		is	= null;
	
	private	String	pushIpAddress;
	private	int		pushPortNo;
	
	private	UnmsHeader	header;
	
	private	String	maxDablGrCd;
	private	String	maxGrDablCd;
	private String	dablCdLstCtt;
	private	char[]	prfmDablGrLstCtt;

	private	BlockingQueue	queue;
	private	TimerService	timerService;

	private String	trfType;
	private	long	recNo;
	private	long	cdrRecNo;
	private	long	trfAlarmRecNo;
	
	public UnmsTrafficReceiver(String[] args) {
		trfType = EnvManager.env.getOptionValue(C_TRF_TYPE);
		if ("PSTN".equals(trfType) == false && "VOIP".equals(trfType) == false) {
			System.out.println("invalid TRF_TYPE : " + trfType);
			System.exit(0);			
		}
		Logger.logger = Logger.logger.createLogger(BasCfg.getHomeLogs(), this.getClass().getSimpleName() + "." + trfType);
		String logLevel = EnvManager.env.getLogLevel();
		if (logLevel != null) {
			if (logLevel.toUpperCase().equals("INFO")) {
				Logger.logger.setLevel(LOG_LEVEL.info);
			} else if (logLevel.toUpperCase().equals("DEBUG")) {
				Logger.logger.setLevel(LOG_LEVEL.debug);
			}
		}

		sock = null;
		timeOut = SOCKET_TIME_OUT;

		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		if (trfType.equals("PSTN")) {
			ipAddress = configManager.getConfig(Constants.UNMS_PSTN_TRAFFIC2, Constants.IP_ADDRESS);
			portNo = Integer.parseInt(configManager.getConfig(Constants.UNMS_PSTN_TRAFFIC2, Constants.PORT_NO));
		} else {
			ipAddress = configManager.getConfig(Constants.UNMS_VOIP_TRAFFIC2, Constants.IP_ADDRESS);
			portNo = Integer.parseInt(configManager.getConfig(Constants.UNMS_VOIP_TRAFFIC2, Constants.PORT_NO));
		}
		pushIpAddress = configManager.getConfig(Constants.WEB_PUSH, Constants.IP_ADDRESS);
		pushPortNo = Integer.parseInt(configManager.getConfig(Constants.WEB_PUSH, Constants.PORT_NO));
		
		QID = new clUnmsTrafficAlarmQid();
		
		thresholdMgr = new UnmsTrafficThresholdManager();
		omn30203Map = new HashMap<String, OMN30203>();
		autoRlseMap = new HashMap<String, String>();

		try {
			timerService = new TimerService("timer", Cron.EVERY_MINUTES);
			timerService.set("init", "0 * * * *", this);
		} catch (Exception e) {
			Logger.logger.error(e);
		}
	}
	
	private void init() throws Exception {
		thresholdMgr.clear();
		omn30203Map.clear();
		
		initDb();

		tran.setDaoListener(this);
		step = STEP_OMN30203;
		tran.selectQid2Res(QID.SELECT_OMN30203, null);
		step = STEP_OMN10223;
		tran.selectQid2Res(QID.SELECT_OMN10223, null);
		step = STEP_OMN10221;
		tran.selectQid2Res(QID.SELECT_OMN10221, null);
		tran.setDaoListener(null);
		
		Logger.logger.info(String.format("omn30203Map:%d", omn30203Map.size()));
	}
	
	private void initDb() throws Exception {
		if (tran != null) {
			try {
				tran.stop();
			} catch (Exception e) {
				
			}
		}
		DataBase database = DBManager.getMgr().getDataBase("ADAMS");
		tran = database.createDbTrans("deploy/conf/sql/" + QID.QUERY_XML_FILE);
		tran.start();
	}

	private void run() {
		header = new UnmsHeader();
		while (true) {
			try {
				if (sock == null) {
					try {
						connectUnms();
					} catch (Exception e) {
						Logger.logger.error(e);
						Thread.sleep(SLEEP_TIME*1000);
						continue;
					}
				}
				synchronized (thresholdMgr) {
					readTraffic();
				}
				tran.commit();
				if (recNo < 0) {
					Logger.logger.info(String.format("recNo is negative. so reset. (cdrRecNo=%d),(trfAlarmRecNo=%d)", cdrRecNo, trfAlarmRecNo));
					recNo = 0;
					cdrRecNo = 0;
					trfAlarmRecNo = 0;
				} else if (recNo % 1000 == 0) {
					Logger.logger.info(String.format("(recNo=%d),(cdrRecNo=%d),(trfAlarmRecNo=%d)", recNo, cdrRecNo, trfAlarmRecNo));
				}
			} catch (SocketTimeoutException ste) {
				Logger.logger.error(ste);
				disconnect();
				Logger.logger.info(String.format("(recNo=%d),(cdrRecNo=%d),(trfAlarmRecNo=%d)", recNo, cdrRecNo, trfAlarmRecNo));
			} catch (SocketException se) {
				Logger.logger.error(se);
				disconnect();
			} catch (IOException ioe) {
				Logger.logger.error(ioe);
				disconnect();
			} catch (SQLException sqle) {
				Logger.logger.error(sqle);
				try {
					initDb();
				} catch (Exception e) {
					
				}
			} catch (Exception e) {
				Logger.logger.error(e);
			}
		}
	}
	
	private void connectUnms() throws Exception {
		Logger.logger.info(String.format("trying connect %s:%d", ipAddress, portNo));
		sock = new Socket(ipAddress, portNo);
		if (timeOut > 0) {
			sock.setSoTimeout(timeOut*1000);
		}
		os = sock.getOutputStream();
		is = sock.getInputStream();

//		sendRequestPort();
		sendLoginPacket();
	}
	
	private void disconnect() {
		try {
			os.close();
		} catch (Exception e) {			
		}
		try {
			is.close();
		} catch (Exception e) {			
		}
		try {
			sock.close();
		} catch (Exception e) {			
		}
		os = null;
		is = null;
		sock = null;
		try {
			Thread.sleep(SLEEP_TIME*1000);
		} catch (Exception e) {
			;
		}
	}
	
	private void sendRequestPort() throws Exception {
		
		header.setPduType(UnmsHeader.PDU_REQUEST);
		header.setServiceCode(UnmsHeader.SVCD_TRAFFIC_PORT);
		header.setMessageSerialNo(UnmsHeader.MSN_DONT_CARE);
		header.setLastYn(UnmsHeader.LAST_N);
		header.setResponseResult(UnmsHeader.RESPONSE_SUCC);
		header.setExtendArea(UnmsHeader.EA_DONT_CARE);
		header.setBodyLength(login.length());
		
		header.write(os);
		os.write(login.getBytes());

		Logger.logger.info(StringUtils.toReadableString(login.getBytes()));
		
		byte[]	recvPacket = new byte[100];
		int len = is.read(recvPacket);
		if (len < 0) {
			throw new Exception("failed to read");
		}
		Logger.logger.debug(StringUtils.toHexString(recvPacket, len));
		Logger.logger.debug(StringUtils.toReadableString(recvPacket, len));
		
		String recvPortNoStr = new String(recvPacket, 20, 4);
		
		disconnect();
		
		sock = new Socket(ipAddress, Integer.parseInt(recvPortNoStr));
		if (timeOut > 0) {
			sock.setSoTimeout(timeOut*1000);
		}
		os = sock.getOutputStream();
		is = sock.getInputStream();
	}
	
	private void sendLoginPacket() throws Exception {
		
		byte[] body = new byte[login.length() + 1 + password.length()];
		System.arraycopy(login.getBytes(), 0, body, 0, login.length());
		body[login.length()] = IDENTIFIER;
		System.arraycopy(password.getBytes(), 0, body, login.length()+1, password.length());
		
		header.setPduType(UnmsHeader.PDU_REQUEST);
		header.setServiceCode(UnmsHeader.SVCD_LOGIN);
		header.setMessageSerialNo(UnmsHeader.MSN_DONT_CARE);
		header.setLastYn(UnmsHeader.LAST_N);
		header.setResponseResult(UnmsHeader.RESPONSE_SUCC);
		header.setExtendArea(UnmsHeader.EA_BLANK);
		header.setBodyLength(body.length);
		
		header.write(os);
		os.write(body);
		os.flush();
		
		Logger.logger.info(StringUtils.toReadableString(body));

		byte[]	recvPacket = new byte[100];
		int len = is.read(recvPacket);
		if (len < 0) {
			throw new Exception("failed to read");
		}
		Logger.logger.debug(StringUtils.toHexString(recvPacket, len));
		Logger.logger.debug(StringUtils.toReadableString(recvPacket, len));
	}

	private void readTraffic() throws Exception {
		
		if (header.read(is) == false) {
			Logger.logger.error("failed to read header packet");
			return;
		}
		byte[] body = new byte[header.getBodyLength()];
		int len = is.read(body);
		if (len != header.getBodyLength()) {
			Logger.logger.error(String.format("invalid body length(%d:%d)", header.getBodyLength(), len));
			return;
		}
		String[] bodyColumns = split(body);

		// equipUsgCd
		String equipUsgCd = bodyColumns[PduEssTrfMsgEnum.E_EQUIP_USG_CD.getIndex()];
		String dataSrcClCd = bodyColumns[PduEssTrfMsgEnum.E_DATA_SRC_CL_CD.getIndex()].toUpperCase();
		
		Logger.logger.debug(String.format("(%s),(%s)", equipUsgCd, dataSrcClCd));

		recNo ++;
		if (FmConstants.EQUIP_USG_CD.CD_4101.equals(equipUsgCd)) { // PSTN 은 CDR(C), CLOG(M)
			if (FmConstants.DATA_SRC_CL_CD.CDR.equals(dataSrcClCd) == false && FmConstants.DATA_SRC_CL_CD.MSG.equals(dataSrcClCd) == false) {
				return;
			}			
		} else {	// VOIP는 CDR(C), CLOG(L)
			if (FmConstants.DATA_SRC_CL_CD.CDR.equals(dataSrcClCd) == false && FmConstants.DATA_SRC_CL_CD.CALL.equals(dataSrcClCd) == false) {
				return;
			}
			
		}
		cdrRecNo ++;

		// bodyColumns[2] : '0' - 20305, '1' - 20306, '2' - 20307
		Logger.logger.info(StringUtils.toReadableString(body));
		for (int i = 0; i < bodyColumns.length; i ++) {
			Logger.logger.debug(String.format("(%d)(%s)", i, bodyColumns[i]));
		}

		OMN20305 omn20305 = new OMN20305();

		omn20305.setDataSrcClCd(dataSrcClCd);
		if (FmConstants.EQUIP_USG_CD.CD_4101.equals(equipUsgCd)) {
			ZonedDateTime zdTime = DateUtils.getUnixTime(bodyColumns[PduEssTrfMsgEnum.E_EVENT_DATE.getIndex()]);
			String mntrDt = DateUtils.getDate(zdTime);
			String mntrDtm = DateUtils.getTime(zdTime);

			omn20305.setMntrCyclCd(bodyColumns[PduEssTrfMsgEnum.E_MNTR_CYCL_CD.getIndex()]);
			omn20305.setEquipId(bodyColumns[PduEssTrfMsgEnum.E_EQUIP_ID.getIndex()]);
			omn20305.setRoutNumCtt(bodyColumns[PduEssTrfMsgEnum.E_ROUT_NUM.getIndex()]);
			omn20305.setMntrDtm(mntrDtm);
			omn20305.setMntrDt(mntrDt);
			omn20305.setRoutUsgCtt(bodyColumns[PduEssTrfMsgEnum.E_ROUT_USG_CTT.getIndex()]);
			omn20305.setRoutDirnCd(bodyColumns[PduEssTrfMsgEnum.E_ROUT_CONN_DIRN_CD.getIndex()]);
			omn20305.setConnClCd(bodyColumns[PduEssTrfMsgEnum.E_ROUT_CONN_TYP_CD.getIndex()]);
			omn20305.setDoexgBizrId(bodyColumns[PduEssTrfMsgEnum.E_DOEXG_BIZR_ID.getIndex()]);
			omn20305.setDablYn(bodyColumns[PduEssTrfMsgEnum.E_IS_ALARM.getIndex()]);
			omn20305.setIoexgTryCallCnt(bodyColumns[PduEssTrfMsgEnum.E_INTRA_ATT.getIndex()]);
			omn20305.setIoexgFnshCallCnt(bodyColumns[PduEssTrfMsgEnum.E_INTRA_ANS.getIndex()]);
			omn20305.setItCallCnt(bodyColumns[PduEssTrfMsgEnum.E_INC_ATT.getIndex()]);
			omn20305.setIcallFnshCallCnt(bodyColumns[PduEssTrfMsgEnum.E_INC_ANS.getIndex()]);
			omn20305.setOtCallCnt(bodyColumns[PduEssTrfMsgEnum.E_OUT_ATT.getIndex()]);
			omn20305.setOcallFnshCallCnt(bodyColumns[PduEssTrfMsgEnum.E_OUT_ANS.getIndex()]);
			omn20305.setOcallNumTmTryCallCnt(bodyColumns[PduEssTrfMsgEnum.E_A_TM_ATT.getIndex()]);
			omn20305.setOcallNumTmFnshCallCnt(bodyColumns[PduEssTrfMsgEnum.E_A_TM_ANS.getIndex()]);
			omn20305.setIcallNumTmTryCallCnt(bodyColumns[PduEssTrfMsgEnum.E_B_TM_ATT.getIndex()]);
			omn20305.setIcallNumTmFnshCallCnt(bodyColumns[PduEssTrfMsgEnum.E_B_TM_ANS.getIndex()]);
			omn20305.setAvgRsvTms(bodyColumns[PduEssTrfMsgEnum.E_AHDT.getIndex()]);
			omn20305.setTrunkCnt(bodyColumns[PduEssTrfMsgEnum.E_EQP_TRK.getIndex()]);
			omn20305.setErlangVal(bodyColumns[PduEssTrfMsgEnum.E_ERLANG.getIndex()]);
			omn20305.setOvrCallCnt(bodyColumns[PduEssTrfMsgEnum.E_OVFL.getIndex()]);
			omn20305.setAllTryCallExfluRt(bodyColumns[PduEssTrfMsgEnum.E_VAR_ATT_RATIO.getIndex()]);
			omn20305.setItCallExfluRt(bodyColumns[PduEssTrfMsgEnum.E_VAR_IATT_RATIO.getIndex()]);
			omn20305.setOtCallExfluRt(bodyColumns[PduEssTrfMsgEnum.E_VAR_OATT_RATIO.getIndex()]);
			omn20305.setNyOccrDcOccrCnt(bodyColumns[PduEssTrfMsgEnum.E_CONN_NUM_NO_ATT.getIndex()]);
			omn20305.setFnshRtDcOccrCnt(bodyColumns[PduEssTrfMsgEnum.E_CONN_NUM_ANSR.getIndex()]);
			omn20305.setOosRtDcOccrCnt(bodyColumns[PduEssTrfMsgEnum.E_CONN_NUM_OOS.getIndex()]);
			omn20305.setLineUseRtDcOccrCnt(bodyColumns[PduEssTrfMsgEnum.E_CONN_NUM_RTEUSG.getIndex()]);
			omn20305.setOvrCallRtDcOccrCnt(bodyColumns[PduEssTrfMsgEnum.E_CONN_NUM_OVFL.getIndex()]);
			omn20305.setExfluRtDcOccrCnt(bodyColumns[PduEssTrfMsgEnum.E_CONN_NUM_VAR_ATT.getIndex()]);
			omn20305.setIcallFnshRtDcOccrCnt(bodyColumns[PduEssTrfMsgEnum.E_CONN_NUM_IANSR.getIndex()]);
			omn20305.setOcallFnshRtDcOccrCnt(bodyColumns[PduEssTrfMsgEnum.E_CONN_NUM_OANSR.getIndex()]);
			omn20305.setItCallExfluDcOccrCnt(bodyColumns[PduEssTrfMsgEnum.E_CONN_NUM_IVAR_ATT.getIndex()]);
			omn20305.setOtCallExfluRtDcOccrCnt(bodyColumns[PduEssTrfMsgEnum.E_CONN_NUM_OVAR_ATT.getIndex()]);
			omn20305.setScrbrErrCnt(bodyColumns[PduEssTrfMsgEnum.E_INCOMPL_1.getIndex()]);
			omn20305.setSysErrCnt(bodyColumns[PduEssTrfMsgEnum.E_INCOMPL_2.getIndex()]);
			omn20305.setNwErrCnt(bodyColumns[PduEssTrfMsgEnum.E_INCOMPL_3.getIndex()]);
			omn20305.setSvcErrCnt(bodyColumns[PduEssTrfMsgEnum.E_INCOMPL_4.getIndex()]);
			omn20305.setTryCallDcOccrCnt(bodyColumns[PduEssTrfMsgEnum.E_CONN_NUM_ATT.getIndex()]);
		} else {
			ZonedDateTime zdTime = DateUtils.getUnixTime(bodyColumns[PduVoipCallTrfMsgEnum.E_EVENT_DATE_ZONE.getIndex()]);
			String mntrDt = DateUtils.getDate(zdTime);
			String mntrDtm = DateUtils.getTime(zdTime);
			
			Logger.logger.info(String.format("(%s),(mntrDt=%s),(mntrDtm=%s)", bodyColumns[PduVoipCallTrfMsgEnum.E_EVENT_DATE_ZONE.getIndex()], mntrDt, mntrDtm));

			omn20305.setMntrCyclCd(bodyColumns[PduVoipCallTrfMsgEnum.E_MNTR_CYCL_CD.getIndex()]);
			omn20305.setEquipId(bodyColumns[PduVoipCallTrfMsgEnum.E_EQUIP_ID.getIndex()]);
			omn20305.setRoutNumCtt(bodyColumns[PduVoipCallTrfMsgEnum.E_ROUT_NUM.getIndex()]);
			omn20305.setMntrDtm(mntrDtm);
			omn20305.setMntrDt(mntrDt);
			omn20305.setRoutUsgCtt(bodyColumns[PduVoipCallTrfMsgEnum.E_ROUT_USG_CTT.getIndex()]);
			omn20305.setExgNum(bodyColumns[PduVoipCallTrfMsgEnum.E_EXG_NUM.getIndex()]);
			omn20305.setPhonSvcCd(bodyColumns[PduVoipCallTrfMsgEnum.E_EXG_NUM_CALL_TYP_CD.getIndex()]);
			omn20305.setBizrId(bodyColumns[PduVoipCallTrfMsgEnum.E_SVC_BIZR_ID.getIndex()]);
			omn20305.setPhonSvcNum(bodyColumns[PduVoipCallTrfMsgEnum.E_SVC_NUM.getIndex()]);
			omn20305.setPortNum(bodyColumns[PduVoipCallTrfMsgEnum.E_PORT_NO.getIndex()]);
			omn20305.setPriBizrId(bodyColumns[PduVoipCallTrfMsgEnum.E_PRI_BIZR_ID.getIndex()]);
			omn20305.setConnClCd(bodyColumns[PduVoipCallTrfMsgEnum.E_ROUT_CONN_TYP_CD.getIndex()]);
			omn20305.setRoutDirnCd(bodyColumns[PduVoipCallTrfMsgEnum.E_ROUT_CONN_DIRN_CD.getIndex()]);
			omn20305.setDablYn(bodyColumns[PduVoipCallTrfMsgEnum.E_IS_ALARM.getIndex()]);
			omn20305.setItCallCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_INC_ATT.getIndex()]);
			omn20305.setIcallFnshCallCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_INC_ANS.getIndex()]);
			omn20305.setOtCallCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_OUT_ATT.getIndex()]);
			omn20305.setOcallFnshCallCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_OUT_ANS.getIndex()]);
			omn20305.setTrunkCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_TRUNK_NUM.getIndex()]);
			omn20305.setIcallTcTms(bodyColumns[PduVoipCallTrfMsgEnum.E_INC_CALL_SEC.getIndex()]);
			omn20305.setOcallTcTms(bodyColumns[PduVoipCallTrfMsgEnum.E_OUT_CALL_SEC.getIndex()]);
			omn20305.setOcallNumTmTryCallCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_A_TM_ATT.getIndex()]);
			omn20305.setOcallNumTmFnshCallCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_A_TM_ANS.getIndex()]);
			omn20305.setOcallNumTmTcTms(bodyColumns[PduVoipCallTrfMsgEnum.E_A_TM_CALL_SEC.getIndex()]);
			omn20305.setIcallNumTmTryCallCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_B_TM_ATT.getIndex()]);
			omn20305.setIcallNumTmFnshCallCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_B_TM_ANS.getIndex()]);
			omn20305.setIcallNumTmTcTms(bodyColumns[PduVoipCallTrfMsgEnum.E_B_TM_CALL_SEC.getIndex()]);
			omn20305.setAvgRsvTms(bodyColumns[PduVoipCallTrfMsgEnum.E_AHDT.getIndex()]);
			omn20305.setErlangVal(bodyColumns[PduVoipCallTrfMsgEnum.E_ERLANG.getIndex()]);
			omn20305.setScrbrErrCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_INCOMPL_subs.getIndex()]);
			omn20305.setRoutErrCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_INCOMPL_routing.getIndex()]);
			omn20305.setNumConvErrCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_INCOMPL_number.getIndex()]);
			omn20305.setTrunkErrCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_INCOMPL_trunk.getIndex()]);
			omn20305.setEtcNcmplCallCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_INCOMPL_etc.getIndex()]);
			omn20305.setDoexgBizrId(bodyColumns[PduVoipCallTrfMsgEnum.E_DOEXG_BIZR_ID.getIndex()]);
			omn20305.setVipCustYn(bodyColumns[PduVoipCallTrfMsgEnum.E_DOEXG_VIP_CUST_YN.getIndex()]);
			omn20305.setNyOccrDcOccrCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_CONN_NUM_NO_ATT.getIndex()]);
			omn20305.setFnshRtDcOccrCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_CONN_NUM_ANSR.getIndex()]);
			omn20305.setExfluRtDcOccrCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_CONN_NUM_VAR_ATT.getIndex()]);
			omn20305.setItCallExfluDcOccrCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_CONN_NUM_IVAR_ATT.getIndex()]);
			omn20305.setOtCallExfluRtDcOccrCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_CONN_NUM_OVAR_ATT.getIndex()]);
			omn20305.setLineUseRtDcOccrCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_CONN_NUM_RTE_USG.getIndex()]);
			omn20305.setItCallExfluRt(bodyColumns[PduVoipCallTrfMsgEnum.E_VAR_IATT_RATIO.getIndex()]);
			omn20305.setOtCallExfluRt(bodyColumns[PduVoipCallTrfMsgEnum.E_VAR_OATT_RATIO.getIndex()]);
			omn20305.setTestOtCallCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_A_TEST_ATT.getIndex()]);
			omn20305.setTestOcallFnshCallCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_A_TEST_ANS.getIndex()]);
			omn20305.setTestOcallTcTms(bodyColumns[PduVoipCallTrfMsgEnum.E_A_TEST_CALL_SEC.getIndex()]);
			omn20305.setTestItCallCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_B_TEST_ATT.getIndex()]);
			omn20305.setTestIcallFnshCallCnt(bodyColumns[PduVoipCallTrfMsgEnum.E_B_TEST_ANS.getIndex()]);
			omn20305.setTestIcallTcTms(bodyColumns[PduVoipCallTrfMsgEnum.E_B_TEST_CALL_SEC.getIndex()]);
		}
		// select tpoCd, equipSysNm from ....
		//omn20305.setTpoCd(tpoCd);
		//omn20305.setEquipSysNm(equipSysNm);

		calcuThreshold(equipUsgCd, omn20305);
	}
	
	private void calcuThreshold(String equipUsgCd, OMN20305 omn20305) throws Exception {		
		// DABL_MCL_CD
		// - 03101, 03107 : 루트별&V5.2별 트래픽 장애
		// - 03102, 03108 : 서비스별&사업자별 트래픽 장애
		
		maxDablGrCd = FmConstants.DABL_GR_CD.NONE;
		maxGrDablCd = null;
		dablCdLstCtt = null;

		if (FmConstants.EQUIP_USG_CD.CD_4101.equals(equipUsgCd)) {
			if (FmConstants.ROUT_USG_CTT.RUC_ROUTE_0.equals(omn20305.getRoutUsgCtt())
					|| FmConstants.ROUT_USG_CTT.RUC_ROUTE_1.equals(omn20305.getRoutUsgCtt())
					|| FmConstants.ROUT_USG_CTT.RUC_ROUTE_3.equals(omn20305.getRoutUsgCtt())) {
				calcuThreshold(omn20305, FmConstants.DABL_MCL_CD.PSTN_TRAFFIC_ROUTE);
			} else if (FmConstants.ROUT_USG_CTT.RUC_V52.equals(omn20305.getRoutUsgCtt())) {
				calcuThreshold(omn20305, FmConstants.DABL_MCL_CD.PSTN_TRAFFIC_V52);
			} else if (FmConstants.ROUT_USG_CTT.RUC_BIZR_110.equals(omn20305.getRoutUsgCtt())) {
				calcuThreshold(omn20305, FmConstants.DABL_MCL_CD.PSTN_TRAFFIC_BIZR);
			} else if (FmConstants.ROUT_USG_CTT.RUC_SERVICE_120.equals(omn20305.getRoutUsgCtt())) {
				calcuThreshold(omn20305, FmConstants.DABL_MCL_CD.PSTN_TRAFFIC_SERVICE);
			} else {
				return;
			}
		} else {
			if (FmConstants.ROUT_USG_CTT.RUC_V52.equals(omn20305.getRoutUsgCtt())) {
				calcuThreshold(omn20305, FmConstants.DABL_MCL_CD.VOIP_TRAFFIC_V52);
			} else {
				// ROUT_USG_CTT < 100
				int routeUsgCttNum = -1;
				try {
					routeUsgCttNum = Integer.parseInt(omn20305.getRoutUsgCtt());
				} catch (Exception e) {
				}
				if (routeUsgCttNum >= 0 && routeUsgCttNum < 100) {
					calcuThreshold(omn20305, FmConstants.DABL_MCL_CD.VOIP_TRAFFIC_CALL);
				}
			}
		}
		
	}
	
	private void calcuThreshold(OMN20305 omn20305, String dablMclCd) throws Exception {
		// 전주 CDR, MSG 데이터 조회
		// S001_CDR_TRF, S001_MSG_TRF
		// S002_CDR_TRF, S002_MSG_TRF

		UnmsTrafficPI trafficPI = null;
		HashMap<String, OMN10223> omn10223Map = null;

		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("mntrCyclCd", omn20305.getMntrCyclCd());
		hmap.put("dataSrcClCd", omn20305.getDataSrcClCd());
		hmap.put("mntrDt", omn20305.getMntrDt());
		hmap.put("mntrDtm", omn20305.getMntrDtm());
		hmap.put("equipId", omn20305.getEquipId());
		hmap.put("routNumCtt", omn20305.getRoutNumCtt());
		hmap.put("routUsgCtt", omn20305.getRoutUsgCtt());
		hmap.put("trunkCnt", ""+omn20305.getTrunkCnt());

		if (FmConstants.DABL_MCL_CD.PSTN_TRAFFIC_ROUTE.equals(dablMclCd) || FmConstants.DABL_MCL_CD.PSTN_TRAFFIC_V52.equals(dablMclCd)) {
			
			if (FmConstants.DATA_SRC_CL_CD.CDR.equals(omn20305.getDataSrcClCd())) {
				trafficPI = (UnmsTrafficPI) tran.selectQidObj(QID.SELECT_PSTN_ROUTE_CDR_TRF, hmap);
				if (trafficPI != null) {
					trafficPI.set(omn20305);
					omn10223Map = thresholdMgr.get(dablMclCd, omn20305, trafficPI);
					calcuPstnRouteTraffic(omn20305, trafficPI, omn10223Map);
				}
			} else {
				trafficPI = (UnmsTrafficPI) tran.selectQidObj(QID.SELECT_PSTN_ROUTE_MSG_TRF, hmap);
				if (trafficPI != null) {
					trafficPI.set(omn20305);
					// reset
					trafficPI.setExfluRt(omn20305.getAllTryCallExfluRt());
					omn10223Map = thresholdMgr.get(dablMclCd, omn20305, trafficPI);
					calcuPstnRouteTraffic(omn20305, trafficPI, omn10223Map);
				}
			}
		
		} else if (FmConstants.DABL_MCL_CD.PSTN_TRAFFIC_BIZR.equals(dablMclCd) || FmConstants.DABL_MCL_CD.PSTN_TRAFFIC_SERVICE.equals(dablMclCd)) {
			
			if (FmConstants.DATA_SRC_CL_CD.CDR.equals(omn20305.getDataSrcClCd())) {
				trafficPI = (UnmsTrafficPI) tran.selectQidObj(QID.SELECT_PSTN_SERVICE_CDR_TRF, hmap);
				if (trafficPI != null) {
					trafficPI.set(omn20305);
					omn10223Map = thresholdMgr.get(dablMclCd, omn20305, trafficPI);
					calcuPstnServiceTraffic(omn20305, trafficPI, omn10223Map);
				}
			} else {
				trafficPI = (UnmsTrafficPI) tran.selectQidObj(QID.SELECT_PSTN_SERVICE_MSG_TRF, hmap);
				if (trafficPI != null) {
					trafficPI.set(omn20305);
					omn10223Map = thresholdMgr.get(dablMclCd, omn20305, trafficPI);
					calcuPstnServiceTraffic(omn20305, trafficPI, omn10223Map);
				}
			}
		} else if (FmConstants.DABL_MCL_CD.VOIP_TRAFFIC_CALL.equals(dablMclCd) || FmConstants.DABL_MCL_CD.VOIP_TRAFFIC_V52.equals(dablMclCd)) {
			trafficPI = (UnmsTrafficPI) tran.selectQidObj(QID.SELECT_VOIP_TRF, hmap);
			if (trafficPI != null) {
				trafficPI.set(omn20305);
				//reset
				trafficPI.setTmexlOcallRlayExfluRt(0.0);
				trafficPI.setTmexlRcvRlayExfluRt(0.0);
				omn10223Map = thresholdMgr.get(dablMclCd, omn20305, trafficPI);
				OMN10221 omn10221 = thresholdMgr.getOMN10221(omn20305, trafficPI);
				calcuVoipTraffic(omn20305, trafficPI, omn10221, omn10223Map);
			}
		}
	}
	
	private void calcuPstnRouteTraffic(OMN20305 omn20305, UnmsTrafficPI trafficPI, HashMap<String, OMN10223> omn10223Map) throws Exception {

		maxDablGrCd = null;
		maxGrDablCd = null;
		dablCdLstCtt = null;

		// 00000000000 형식으로 장애 등급 표시 : checkThrsValue 함수의 순서 가장 중요 : PRFM_DABL_GR_LST_CTT 생성값 
		// 루트별&V5.2별 트래픽 장애 : 임계치 체크 항목 : 미발생,시도호(TM제외),완료호(TM제외),완료율(TM제외),OOS율,넘침호율,이용율,과다변동율,TM완료율,전체시도호,전체완료율 - 11개
		// ==> 12/13일 임계치 체크변경(3가지 빠짐) : 미발생,0,0,0,OSS율,넘침호율,이용율,과다변동율,TM완료율,전체시도호,전체완료율
		prfmDablGrLstCtt = new char[PSTN_PRFM_DABL_GR_LST_CTT_LEN];
		Arrays.fill(prfmDablGrLstCtt, '0');
		
		OMN30131 omn30131 = new OMN30131();

		if (omn10223Map == null) return;
		
		omn30131.set(omn20305, trafficPI);
		
		OMN10223 omn10223 = omn10223Map.get(FmConstants.THRS_ITM_NM.NOT);
		if (omn10223 != null) {
			/* 미발생장애연속발생횟수 */
			if (FmConstants.ROUT_USG_CTT.RUC_V52.equals(omn20305.getRoutUsgCtt())) {
				checkThrsValue(omn10223, trafficPI.getNyOccrDcOccrCnt(), FmConstants.DABL_CD.CD_031043);
			} else {
				checkThrsValue(omn10223, trafficPI.getNyOccrDcOccrCnt(), FmConstants.DABL_CD.CD_031004);
			}
			setPrfmDablGrLstCtt(prfmDablGrLstCtt, PrfmDablGrLstCttEnum.NY_OCCR_DC_OCCR_CNT);
		}
		/* 완료율(TM제외) */
		float tmexlFnshRt = getRt(trafficPI.getTmexlFnshCallCnt(), trafficPI.getTmexlTryCallCnt());
		omn30131.setTmexlFnshRt(tmexlFnshRt);
		setPrfmDablGrLstCtt(prfmDablGrLstCtt, PrfmDablGrLstCttEnum.TMEXL_FNSH_RT);
		
		/* OOS율 */
		float oosRt = getRt((int)trafficPI.getOosRt(), trafficPI.getMounLineCnt());
		if (oosRt == 100) {
			;
		} else {
			omn10223 = omn10223Map.get(FmConstants.THRS_ITM_NM.OSS);
			if (omn10223 != null) {
				if (FmConstants.ROUT_USG_CTT.RUC_V52.equals(omn20305.getRoutUsgCtt())) {
					checkThrsValue(omn10223, oosRt, FmConstants.DABL_CD.CD_031040);
				} else {
					checkThrsValue(omn10223, oosRt, FmConstants.DABL_CD.CD_031001);
				}
				setPrfmDablGrLstCtt(prfmDablGrLstCtt, PrfmDablGrLstCttEnum.OOS_RT);
			}
		}
		omn30131.setOosRt(oosRt);
		/* 넘침호율 */
		float ovrCallRt = getRt(trafficPI.getOvrCallRt(), trafficPI.getMounLineCnt());
		omn10223 = omn10223Map.get(FmConstants.THRS_ITM_NM.OVEREFF);
		if (omn10223 != null) {
			if (FmConstants.ROUT_USG_CTT.RUC_V52.equals(omn20305.getRoutUsgCtt())) {
				checkThrsValue(omn10223, ovrCallRt, FmConstants.DABL_CD.CD_031041);
			} else {
				checkThrsValue(omn10223, ovrCallRt, FmConstants.DABL_CD.CD_031002);
			}
			setPrfmDablGrLstCtt(prfmDablGrLstCtt, PrfmDablGrLstCttEnum.OVR_CALL_RT);
		}
		omn30131.setOvrCallRt(ovrCallRt);
		/* 회선이용율 */
		float lineUseRt = calcUsageR(trafficPI.getMounLineCnt(), calcCircuitNum((float)trafficPI.getLineUseRt()));
		omn10223 = omn10223Map.get(FmConstants.THRS_ITM_NM.USAGE);
		if (omn10223 != null) {
			if (FmConstants.ROUT_USG_CTT.RUC_V52.equals(omn20305.getRoutUsgCtt())) {
				checkThrsValue(omn10223, lineUseRt, FmConstants.DABL_CD.CD_031045);
			} else {
				checkThrsValue(omn10223, lineUseRt, FmConstants.DABL_CD.CD_031006);
			}
			setPrfmDablGrLstCtt(prfmDablGrLstCtt, PrfmDablGrLstCttEnum.USE_RT);
		}
		omn30131.setLineUseRt(lineUseRt);
		/* 과다변동율  */
		float exfluRt = getRt(Math.abs((int)(trafficPI.getAllTryCallCnt() - trafficPI.getExfluRt())), (int)trafficPI.getExfluRt());
		omn10223 = omn10223Map.get(FmConstants.THRS_ITM_NM.OVE);
		if (omn10223 != null) {
			if (FmConstants.ROUT_USG_CTT.RUC_V52.equals(omn20305.getRoutUsgCtt())) {
				checkThrsValue(omn10223, exfluRt, FmConstants.DABL_CD.CD_031044);
			} else {
				checkThrsValue(omn10223, exfluRt, FmConstants.DABL_CD.CD_031005);
			}
			setPrfmDablGrLstCtt(prfmDablGrLstCtt, PrfmDablGrLstCttEnum.EXFLU_RT);
		}
		omn30131.setExfluRt(exfluRt);
		omn10223 = omn10223Map.get(FmConstants.THRS_ITM_NM.COM);
		if (omn10223 != null) {
			/* TM완료율  */
			float tmFnshRt = getRt(trafficPI.getTmFnshCallCnt(), trafficPI.getTmTryCallCnt());
			if (FmConstants.ROUT_USG_CTT.RUC_V52.equals(omn20305.getRoutUsgCtt())) {
				checkThrsValue(omn10223, tmFnshRt, FmConstants.DABL_CD.CD_031050);
			} else {
				checkThrsValue(omn10223, tmFnshRt, FmConstants.DABL_CD.CD_031033);
			}
			setPrfmDablGrLstCtt(prfmDablGrLstCtt, PrfmDablGrLstCttEnum.TM_FNSH_RT);
			omn30131.setTmFnshRt(tmFnshRt);
		}
		/* 전체시도호 */
		omn10223 = omn10223Map.get(FmConstants.THRS_ITM_NM.TRY);
		if (omn10223 != null) {
			if (FmConstants.ROUT_USG_CTT.RUC_V52.equals(omn20305.getRoutUsgCtt())) {
				checkThrsValue(omn10223, trafficPI.getAllTryCallCnt(), FmConstants.DABL_CD.CD_031048);
			} else {
				checkThrsValue(omn10223, trafficPI.getAllTryCallCnt(), FmConstants.DABL_CD.CD_031019);
			}
			setPrfmDablGrLstCtt(prfmDablGrLstCtt, PrfmDablGrLstCttEnum.ALL_TRY_CALL_CNT);
		}
		omn10223 = omn10223Map.get(FmConstants.THRS_ITM_NM.COM);
		if (omn10223 != null) {
			/* 전체완료율 */
			float allFnshRt = getRt((int)trafficPI.getAllFnshRt(), trafficPI.getAllTryCallCnt());
			omn10223 = omn10223Map.get(FmConstants.THRS_ITM_NM.COM);
			if (trafficPI.getAllTryCallCnt() > 0) {	//시도호가 0보다 크면 전체 체크
				if (FmConstants.ROUT_USG_CTT.RUC_V52.equals(omn20305.getRoutUsgCtt())) {
					checkAllThrsValue(omn10223, allFnshRt, FmConstants.DABL_CD.CD_031049);
				} else {
					checkAllThrsValue(omn10223, allFnshRt, FmConstants.DABL_CD.CD_031020);
				}
			} else {
				if (FmConstants.ROUT_USG_CTT.RUC_V52.equals(omn20305.getRoutUsgCtt())) {
					checkThrsValue(omn10223, allFnshRt, FmConstants.DABL_CD.CD_031049);
				} else {
					checkThrsValue(omn10223, allFnshRt, FmConstants.DABL_CD.CD_031020);
				}					
			}
			setPrfmDablGrLstCtt(prfmDablGrLstCtt, PrfmDablGrLstCttEnum.ALL_FNSH_RT);
			omn30131.setAllFnshRt(allFnshRt);
		}
		insertOMN30131(omn30131, QID.INSERT_OMN30131_ROUTE);

	}
	
	private void insertOMN30131(OMN30131 omn30131, String qid) throws Exception {
		if (maxGrDablCd != null) {
			OMN30203 omn30203 = omn30203Map.get(maxGrDablCd);
			if (omn30203 == null) {
				throw new Exception(String.format("OMN30203(DABL_CD:%s) is not exist.", maxGrDablCd));
			}
	
			omn30131.setPrfmDablGrLstCtt(new String(prfmDablGrLstCtt));
			omn30131.setDablCdLstCtt(dablCdLstCtt);
			omn30131.setDablGrCd(maxDablGrCd);
			
			omn30131.setDablLclCd(omn30203.getDablLclCd());
			omn30131.setDablMclCd(omn30203.getDablMclCd());
			omn30131.setDablCd(omn30203.getDablCd());
			
			Logger.logger.info(String.format("(equipId=%s),(dablLclCd=%s),(dablMclCd=%s),(dablCd=%s),(dablGrCd=%s),(dablCdLstCtt=%s),(prfmDablGrLstCtt=%s)",
					omn30131.getEquipId(), omn30131.getDablLclCd(), omn30131.getDablMclCd(), omn30131.getDablCd(),
					omn30131.getDablGrCd(), omn30131.getDablCdLstCtt(), omn30131.getPrfmDablGrLstCtt()));
		
			// mntrDtm/mntrCyclCd/dablLclCd/dablMclCd 기준의 임계치 장애 최초 생성 전에 90분 이내의 해당 임계치 장애 자동 해제 처리
			String key = omn30131.getOccrDtm() + "|" + omn30131.getMntrCyclCd() + "|" + omn30203.getDablLclCd() + "|" + omn30203.getDablMclCd();
			String val = autoRlseMap.get(key);
			if (val == null) {
				autoRlseMap.put(key, key);
				HashMap<String, String> hmap = new HashMap<String, String>();
				hmap.put("mntrCyclCd", omn30131.getMntrCyclCd());
				hmap.put("occrDtm", omn30131.getOccrDtm());
				hmap.put("dablMclCd", omn30203.getDablMclCd());
				tran.update(QID.UPDATE_OMN30131_AUTO_RLSE, hmap);
				Logger.logger.info(String.format("auto-released (mntrCyclCd=%s),(occrDtm=%s),(dablMclCd=%s)",
						omn30131.getMntrCyclCd(), omn30131.getOccrDtm(), omn30203.getDablMclCd()));
			}
			// insert OMN30131(교환성능장애내역)
			tran.create(qid, omn30131);
			trfAlarmRecNo ++;
		}
	}

	private void calcuPstnServiceTraffic(OMN20305 omn20305, UnmsTrafficPI trafficPI, HashMap<String, OMN10223> omn10223Map) throws Exception {

		maxDablGrCd = null;
		maxGrDablCd = null;
		dablCdLstCtt = null;
		prfmDablGrLstCtt = new char[PSTN_PRFM_DABL_GR_LST_CTT_LEN];
		Arrays.fill(prfmDablGrLstCtt, '0');
		
		OMN30131 omn30131 = new OMN30131();
		
		if (omn10223Map == null) return;
		
		omn30131.set(omn20305, trafficPI);
		
		OMN10223 omn10223 = omn10223Map.get(FmConstants.THRS_ITM_NM.COM);
		if (omn10223 != null) {
			/* 출중계 완료율(TM제외) */
			float tmexlOcallRlayFnshRt = getRt(trafficPI.getTmexlOcallRlayFnshCallCnt(), trafficPI.getTmexlOcallRlayTryCallCnt());
			omn30131.setTmexlOcallRlayFnshRt(tmexlOcallRlayFnshRt);
			if (trafficPI.getTmexlOcallRlayTryCallCnt() > 0) {	//시도호가 0보다 크면
				if (FmConstants.ROUT_USG_CTT.RUC_SERVICE_120.equals(omn20305.getRoutUsgCtt())) {
					checkAllThrsValue(omn10223, tmexlOcallRlayFnshRt, FmConstants.DABL_CD.CD_031009);
				} else {
					checkAllThrsValue(omn10223, tmexlOcallRlayFnshRt, FmConstants.DABL_CD.CD_031052);
				}
			} else {
				if (FmConstants.ROUT_USG_CTT.RUC_SERVICE_120.equals(omn20305.getRoutUsgCtt())) {
					checkThrsValue(omn10223, tmexlOcallRlayFnshRt, FmConstants.DABL_CD.CD_031009);
				} else {
					checkThrsValue(omn10223, tmexlOcallRlayFnshRt, FmConstants.DABL_CD.CD_031052);
				}
			}
			setPrfmDablGrLstCtt(prfmDablGrLstCtt, PrfmDablGrLstCttEnum.NY_OCCR_DC_OCCR_CNT);	// ????
		}
		omn10223 = omn10223Map.get(FmConstants.THRS_ITM_NM.OVE);
		if (omn10223 != null) {
			if (FmConstants.DATA_SRC_CL_CD.CDR.equals(omn20305.getDataSrcClCd())) {
				/* 출중계과다변동율(TM제외) */
				float tmexlOcallRlayExfluRt = getRt((int)Math.abs(trafficPI.getTmexlOcallRlayExfluRt()-trafficPI.getOtCallCnt7()), trafficPI.getOtCallCnt7());
				omn30131.setTmexlOcallRlayExfluRt(tmexlOcallRlayExfluRt);
				if (trafficPI.getOtCallCnt7() > 0) {
					if (FmConstants.ROUT_USG_CTT.RUC_SERVICE_120.equals(omn20305.getRoutUsgCtt())) {
						checkAllThrsValue(omn10223, tmexlOcallRlayExfluRt, FmConstants.DABL_CD.CD_031011);
					} else {
						checkAllThrsValue(omn10223, tmexlOcallRlayExfluRt, FmConstants.DABL_CD.CD_031054);
					}
				} else {
					if (FmConstants.ROUT_USG_CTT.RUC_SERVICE_120.equals(omn20305.getRoutUsgCtt())) {
						checkThrsValue(omn10223, tmexlOcallRlayExfluRt, FmConstants.DABL_CD.CD_031011);
					} else {
						checkThrsValue(omn10223, tmexlOcallRlayExfluRt, FmConstants.DABL_CD.CD_031054);
					}					
				}
				setPrfmDablGrLstCtt(prfmDablGrLstCtt, PrfmDablGrLstCttEnum.OVR_CALL_RT);
			}
		}
		omn10223 = omn10223Map.get(FmConstants.THRS_ITM_NM.COM);
		if (omn10223 != null) {
			/* 입중계 완료율(TM제외) */
			float tmexlRcvRlayFnshRt = getRt(trafficPI.getTmexlRcvRlayFnshCallCnt(), trafficPI.getTmexlRcvRlayTryCallCnt());
			omn30131.setTmexlRcvRlayFnshRt(tmexlRcvRlayFnshRt);
			if (tmexlRcvRlayFnshRt > 0) {
				if (FmConstants.ROUT_USG_CTT.RUC_SERVICE_120.equals(omn20305.getRoutUsgCtt())) {
					checkAllThrsValue(omn10223, tmexlRcvRlayFnshRt, FmConstants.DABL_CD.CD_031008);
				} else {
					checkAllThrsValue(omn10223, tmexlRcvRlayFnshRt, FmConstants.DABL_CD.CD_031051);
				}
			} else {
				if (FmConstants.ROUT_USG_CTT.RUC_SERVICE_120.equals(omn20305.getRoutUsgCtt())) {
					checkThrsValue(omn10223, tmexlRcvRlayFnshRt, FmConstants.DABL_CD.CD_031008);
				} else {
					checkThrsValue(omn10223, tmexlRcvRlayFnshRt, FmConstants.DABL_CD.CD_031051);
				}
			}
			setPrfmDablGrLstCtt(prfmDablGrLstCtt, PrfmDablGrLstCttEnum.TMEXL_FNSH_RT);
		}
		omn10223 = omn10223Map.get(FmConstants.THRS_ITM_NM.OVE);
		if (omn10223 != null) {
			if (FmConstants.DATA_SRC_CL_CD.CDR.equals(omn20305.getDataSrcClCd())) {
				/* 입중계과다변동율(TM제외) */
				float tmexlRcvRlayExfluRt = getRt((int)Math.abs(trafficPI.getTmexlRcvRlayExfluRt() - trafficPI.getItCallCnt7()), trafficPI.getItCallCnt7());
				omn30131.setTmexlRcvRlayExfluRt(tmexlRcvRlayExfluRt);
				if (trafficPI.getItCallCnt7() > 0) {
					if (FmConstants.ROUT_USG_CTT.RUC_SERVICE_120.equals(omn20305.getRoutUsgCtt())) {
						checkAllThrsValue(omn10223, tmexlRcvRlayExfluRt, FmConstants.DABL_CD.CD_031010);
					} else {
						checkAllThrsValue(omn10223, tmexlRcvRlayExfluRt, FmConstants.DABL_CD.CD_031053);
					}
				} else {
					if (FmConstants.ROUT_USG_CTT.RUC_SERVICE_120.equals(omn20305.getRoutUsgCtt())) {
						checkThrsValue(omn10223, tmexlRcvRlayExfluRt, FmConstants.DABL_CD.CD_031010);
					} else {
						checkThrsValue(omn10223, tmexlRcvRlayExfluRt, FmConstants.DABL_CD.CD_031053);
					}					
				}
				setPrfmDablGrLstCtt(prfmDablGrLstCtt, PrfmDablGrLstCttEnum.EXFLU_RT);
			}
		}		/* TM완료율 */
		float tmFnshRt = getRt(trafficPI.getTmexlFnshCallCnt(), trafficPI.getTmTryCallCnt());
		omn30131.setTmFnshRt(tmFnshRt);
		setPrfmDablGrLstCtt(prfmDablGrLstCtt, PrfmDablGrLstCttEnum.TM_FNSH_RT);
		/* 전체완료율 */
		float allFnshRt = getRt((int)trafficPI.getAllFnshRt(), trafficPI.getAllTryCallCnt());
		omn30131.setAllFnshRt(allFnshRt);
		setPrfmDablGrLstCtt(prfmDablGrLstCtt, PrfmDablGrLstCttEnum.ALL_FNSH_RT);
		
		insertOMN30131(omn30131, QID.INSERT_OMN30131_SERVICE);
	}

	private void calcuVoipTraffic(OMN20305 omn20305, UnmsTrafficPI trafficPI, OMN10221 omn10221, HashMap<String, OMN10223> omn10223Map) throws Exception {

		maxDablGrCd = null;
		maxGrDablCd = null;
		dablCdLstCtt = null;

		/*
		 * 
		 PRFM_DABL_GR_LST_CTT 에 저장할 순서 대로 처리해야함.
		 
		 USAGE 이용율
		 NOT 미발생
		 OVER_S 발신과다 : 발신시도콜과다변동률
		 COM_S 발신완료 : 발신완료율
		 COM_R 착신완료 : 착신완료율
		 OVER_R 착신과다 : 착신시도콜과다변동률
		 *
		 */

		prfmDablGrLstCtt = new char[VOIP_PRFM_DABL_GR_LST_CTT_LEN];
		Arrays.fill(prfmDablGrLstCtt, '0');
		
		OMN30131 omn30131 = new OMN30131();

		if (omn10223Map == null) return;
		
		omn30131.set(omn20305, trafficPI);
		
		// 최소 시도호 수, 과다변동 최소 시도호 수, 과다변동 최소 시도호 차를 확인 하기 위해 mntrDtm 에서 시간만 가져온다. ( 08~24, 24~08 두가지 값이 있어서 임 )
		int occrHour = Integer.parseInt(omn20305.getMntrDtm().substring(8, 10));
		
		OMN10223 omn10223 = omn10223Map.get(FmConstants.THRS_ITM_NM.NOT);
		if (omn10223 != null) {
			/* 미발생장애연속발생횟수 */
			if (FmConstants.ROUT_USG_CTT.RUC_V52.equals(omn20305.getRoutUsgCtt())) {
				checkThrsValue(omn10223, trafficPI.getNyOccrDcOccrCnt(), FmConstants.DABL_CD.CD_031034);
			} else {
				checkThrsValue(omn10223, trafficPI.getNyOccrDcOccrCnt(), FmConstants.DABL_CD.CD_031021);
			}
			setPrfmDablGrLstCtt(prfmDablGrLstCtt, PrfmDablGrLstCttEnum.NY_OCCR_DC_OCCR_CNT);
		}
		if (omn20305.getNyOccrDcOccrCnt() > 0) {
			omn30131.setOtCallCnt(0);
			omn30131.setOcallFnshCallCnt(0);
			omn30131.setOcallFnshRt(0);
			omn30131.setOtCallExfluRt(0);
			omn30131.setOcallTmFnshRt(0);
			omn30131.setItCallCnt(0);
			omn30131.setIcallFnshCallCnt(0);
			omn30131.setIcallFnshRt(0);
			omn30131.setItCallExfluRt(0);
			omn30131.setIcallTmFnshRt(0);
		} else {
			/* 발신완료율 */
			// [최소 시도호수] ==> 값 확인 후 임계치 적용
			if (checkMinTryCall(omn10221, omn20305.getOtCallCnt(), occrHour)) {
				double ocallFnshRt = 0;
				if (omn20305.getOtCallCnt() > 0) ocallFnshRt = (omn20305.getOcallFnshCallCnt() / omn20305.getOtCallCnt()) * 100;
				omn10223 = omn10223Map.get(FmConstants.THRS_ITM_NM.COM_S);
				if (omn10223 != null) {
					if (FmConstants.ROUT_USG_CTT.RUC_V52.equals(omn20305.getRoutUsgCtt())) {
						checkThrsValue(omn10223, ocallFnshRt, FmConstants.DABL_CD.CD_031035);
					} else {
						checkThrsValue(omn10223, ocallFnshRt, FmConstants.DABL_CD.CD_031024);
					}
					setPrfmDablGrLstCtt(prfmDablGrLstCtt, PrfmDablGrLstCttEnum.COM_S);
				}
				omn30131.setOcallFnshRt(ocallFnshRt);
			}
			
			/* 발신시도콜과다변동률 */
			// [과다변동 최소 시도호수, 과다변동 최소 시도호수 차] ==> 값 확인 후 임계치 적용
			float otCallExfluRt = getRt(Math.abs(omn20305.getOtCallCnt()-trafficPI.getOtCallCnt7()), trafficPI.getOtCallCnt7());
			if (checkExfluTryCall(omn10221, trafficPI.getOtCallCnt7(), omn20305.getOtCallCnt(), occrHour)) {
				omn10223 = omn10223Map.get(FmConstants.THRS_ITM_NM.OVER_S);
				if (omn10223 != null) {
					if (FmConstants.ROUT_USG_CTT.RUC_V52.equals(omn20305.getRoutUsgCtt())) {
						checkThrsValue(omn10223, otCallExfluRt, FmConstants.DABL_CD.CD_031036);
					} else {
						checkThrsValue(omn10223, otCallExfluRt, FmConstants.DABL_CD.CD_031025);
					}
					setPrfmDablGrLstCtt(prfmDablGrLstCtt, PrfmDablGrLstCttEnum.OVER_S);
				}				
				omn30131.setOtCallExfluRt(otCallExfluRt);
			}
			
			/* 착신완료율 */
			if (checkMinTryCall(omn10221, omn20305.getItCallCnt(), occrHour)) {
				double icallFnshRt = 0;
				if (omn20305.getItCallCnt() > 0) icallFnshRt = (omn20305.getIcallFnshCallCnt() / omn20305.getItCallCnt()) * 100;
				omn10223 = omn10223Map.get(FmConstants.THRS_ITM_NM.COM_R);
				if (omn10223 != null) {
					if (FmConstants.ROUT_USG_CTT.RUC_V52.equals(omn20305.getRoutUsgCtt())) {
						checkThrsValue(omn10223, icallFnshRt, FmConstants.DABL_CD.CD_031037);
					} else {
						checkThrsValue(omn10223, icallFnshRt, FmConstants.DABL_CD.CD_031029);
					}
					setPrfmDablGrLstCtt(prfmDablGrLstCtt, PrfmDablGrLstCttEnum.COM_R);
				}
				omn30131.setIcallFnshRt(icallFnshRt);
			}
			
			/* 착신시도콜과다변동률 */
			if (checkExfluTryCall(omn10221, trafficPI.getItCallCnt7(), omn20305.getItCallCnt(), occrHour)) {
				double itCallExfluRt = getRt(Math.abs(omn20305.getItCallCnt()-trafficPI.getItCallCnt7()), trafficPI.getItCallCnt7());
				omn10223 = omn10223Map.get(FmConstants.THRS_ITM_NM.OVER_R);
				if (omn10223 != null) {
					if (FmConstants.ROUT_USG_CTT.RUC_V52.equals(omn20305.getRoutUsgCtt())) {
						checkThrsValue(omn10223, itCallExfluRt, FmConstants.DABL_CD.CD_031038);
					} else {
						checkThrsValue(omn10223, itCallExfluRt, FmConstants.DABL_CD.CD_031030);
					}
					setPrfmDablGrLstCtt(prfmDablGrLstCtt, PrfmDablGrLstCttEnum.OVER_R);
				}
				omn30131.setItCallExfluRt(itCallExfluRt);
			}
		}
		
		/* 회선이용율 */
		float lineUseRt = calcUsageR(trafficPI.getMounLineCnt(), calcCircuitNum((float)trafficPI.getLineUseRt()));
		omn10223 = omn10223Map.get(FmConstants.THRS_ITM_NM.USAGE);
		if (omn10223 != null) {
			if (FmConstants.ROUT_USG_CTT.RUC_V52.equals(omn20305.getRoutUsgCtt())) {
				checkThrsValue(omn10223, lineUseRt, FmConstants.DABL_CD.CD_031039);
			} else {
				checkThrsValue(omn10223, lineUseRt, FmConstants.DABL_CD.CD_031032);
			}
			setPrfmDablGrLstCtt(prfmDablGrLstCtt, PrfmDablGrLstCttEnum.VOIP_USR_RT);
		}
		omn30131.setLineUseRt(lineUseRt);

		insertOMN30131(omn30131, QID.INSERT_OMN30131_VOIP);

	}

	private void checkThrsValue(OMN10223 omn10223, double piVal, String dablCd) {
		if (piVal != 0) {
			checkAllThrsValue(omn10223, piVal, dablCd);
		}
	}

	private void checkAllThrsValue(OMN10223 omn10223, double piVal, String dablCd) {
		String dablGrCd = null;
		if (FmConstants.SING_VAL.GREATER_OR_EQUAL.equals(omn10223.getSignVal())) {
			if (piVal >= omn10223.getCrtgVal()) {
				dablGrCd = FmConstants.DABL_GR_CD.CRITICAL;
			} else if (piVal >= omn10223.getMjrgVal()) {
				dablGrCd = FmConstants.DABL_GR_CD.MAJOR;
			} else if (piVal >= omn10223.getMnrgVal()) {
				dablGrCd = FmConstants.DABL_GR_CD.MINOR;
			}
		} else if (FmConstants.SING_VAL.LESS_OR_EQUAL.equals(omn10223.getSignVal())) {
			if (piVal <= omn10223.getCrtgVal()) {
				dablGrCd = FmConstants.DABL_GR_CD.CRITICAL;
			} else if (piVal <= omn10223.getMjrgVal()) {
				dablGrCd = FmConstants.DABL_GR_CD.MAJOR;
			} else if (piVal <= omn10223.getMnrgVal()) {
				dablGrCd = FmConstants.DABL_GR_CD.MINOR;
			}			
		} else if (FmConstants.SING_VAL.GREATER.equals(omn10223.getSignVal())) {
			if (piVal > omn10223.getCrtgVal()) {
				dablGrCd = FmConstants.DABL_GR_CD.CRITICAL;
			} else if (piVal > omn10223.getMjrgVal()) {
				dablGrCd = FmConstants.DABL_GR_CD.MAJOR;
			} else if (piVal > omn10223.getMnrgVal()) {
				dablGrCd = FmConstants.DABL_GR_CD.MINOR;
			}
		} else if (FmConstants.SING_VAL.LESS.equals(omn10223.getSignVal())) {
			if (piVal < omn10223.getCrtgVal()) {
				dablGrCd = FmConstants.DABL_GR_CD.CRITICAL;
			} else if (piVal < omn10223.getMjrgVal()) {
				dablGrCd = FmConstants.DABL_GR_CD.MAJOR;
			} else if (piVal < omn10223.getMnrgVal()) {
				dablGrCd = FmConstants.DABL_GR_CD.MINOR;
			}
		}
		if (dablGrCd != null) {
			if (maxDablGrCd == null || maxDablGrCd.compareTo(dablGrCd) < 0) {
				maxDablGrCd = dablGrCd;
				maxGrDablCd = dablCd;
			}
			if (FmConstants.DABL_GR_CD.NONE.equals(dablGrCd) == false) {
				if (dablCdLstCtt == null) {
					dablCdLstCtt = dablCd;
				} else {
					dablCdLstCtt = dablCdLstCtt + "|" + dablCd;
				}
			}
		}
	}
	
    private boolean checkMinTryCall(OMN10221 omn10221, double occrVal, int occrHour){
    	// [최소 시도호수]  MIN_TRY_CALL_CNT0824, MIN_TRY_CALL_CNT2408
    	double dblMinTryCallCnt = 0;
    	if (occrHour >= 0 && occrHour < 8) {
    		dblMinTryCallCnt = omn10221.getMinTryCallCnt2408();
    	} else {
    		dblMinTryCallCnt = omn10221.getMinTryCallCnt0824();    		
    	}
    	if (occrVal >= dblMinTryCallCnt) {
    		return true;
    	} else {
    		return false;
    	}
    }
    
    private boolean checkExfluTryCall(OMN10221 omn10221, double occrValPrev, double occrValCurr, int occrHour){
    	// [과다변동 최소 시도호수, 과다변동 최소 시도호수 차] 	EXFLU_MIN_TRY_CALL_CNT0824, EXFLU_TRY_CALL_CNT0824, EXFLU_MIN_TRY_CALL_CNT2408, EXFLU_TRY_CALL_CNT2408
    	double dblExfluMinTryCallCnt = 0;
    	double dblExfluTryCallCnt = 0;
    	if (occrHour >= 0 && occrHour < 8) {
    		dblExfluMinTryCallCnt = omn10221.getExfluMinTryCallCnt2408();
    		dblExfluTryCallCnt = omn10221.getExfluTryCallCnt2408();
    	} else {
    		dblExfluMinTryCallCnt = omn10221.getExfluMinTryCallCnt0824();
    		dblExfluTryCallCnt = omn10221.getExfluTryCallCnt0824();
    	}
    	if (occrValCurr >= dblExfluMinTryCallCnt && Math.abs(occrValPrev-occrValCurr) >= dblExfluTryCallCnt) {
    		return true;
    	} else {
    		return false;
    	}
    }

	private String[] split(byte[] body) throws Exception {
		if (body == null || body.length == 0) return null;
		ArrayList<String> strList = new ArrayList<String>();
		int startIndex = 0;
		int nextIndex = 0;
		while (nextIndex < body.length) {
			if (body[nextIndex] == IDENTIFIER) {
				if (startIndex == nextIndex) {
					strList.add("");
				} else {
					strList.add(new String (body, startIndex, nextIndex - startIndex, CHARSET_NAME));
				}
				startIndex = nextIndex + 1;
			}
			nextIndex ++;
		}
		if (startIndex < nextIndex) {
			strList.add(new String (body, startIndex, nextIndex - startIndex, CHARSET_NAME));
		}
		return strList.toArray(new String[strList.size()]);
	}

	@Override
	public void onExecuted(Object arg0, Exception arg1) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onFinish(Exception arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onSelected(int rowNo, Object data) throws Exception {
		// TODO Auto-generated method stub
		if (step == this.STEP_OMN30203) {
			OMN30203 omn30203 = (OMN30203) data;
			omn30203Map.put(omn30203.getDablCd(), omn30203);
		} else if (step == this.STEP_OMN10223) {
			OMN10223 omn10223 = (OMN10223) data;
			thresholdMgr.add(omn10223);
		} else if (step == this.STEP_OMN10221) {
			OMN10221 omn10221 = (OMN10221) data;
			thresholdMgr.add(omn10221);
		}
	}

	@Override
	public void onStart(String[] arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	private float getRt(int val1, int val2) {
		float fVal = 0f;
		if (val2 == 0) {
			if (val1 == 0) fVal = 0f;
			else fVal = 100f;
		} else {
			fVal = (float)val1/(float)val2*100f;
		}
		return fVal;
	}

	private int calcCircuitNum(float _erlang) {
		float BLOCK = 0.01f;
		float E  = 1.0f;
		int  N  = 0;

		if (_erlang <= 0.0f) return 0;
		while (true) {
			N++;
			E = E/(E+N/_erlang);
			if (E > BLOCK) continue;
			else return (N);
		}
	}

	private float calcUsageR(int _iEqpTrk, int _iCircuitNum) {
		if (_iEqpTrk==0) return 0.0f;
		else return ((_iCircuitNum*100.0f)/_iEqpTrk);
	}

	private void setPrfmDablGrLstCtt(char[] prfmDablGrLstCtt, PrfmDablGrLstCttEnum code) {
		prfmDablGrLstCtt[code.getCode()] = '1';
	}
	
	public void testPstnCdr() throws Exception {
		OMN20305 omn20305 = new OMN20305();
		omn20305.setDataSrcClCd("C");
		omn20305.setMntrCyclCd("04");
		omn20305.setEquipId("000000113485");
		omn20305.setRoutNumCtt("164029");
		omn20305.setMntrDtm("20180724104500");
		omn20305.setMntrDt("20180724");
		omn20305.setRoutUsgCtt("2");
		omn20305.setRoutDirnCd("N");
		omn20305.setConnClCd("62");
		omn20305.setDoexgBizrId("1");
		omn20305.setDablYn("N");
		omn20305.setIoexgTryCallCnt(0);
		omn20305.setIoexgFnshCallCnt(0);
		omn20305.setItCallCnt(0);
		omn20305.setIcallFnshCallCnt(0);
		omn20305.setOtCallCnt(0);
		omn20305.setOcallFnshCallCnt(0);
		omn20305.setOcallNumTmTryCallCnt(0);
		omn20305.setOcallNumTmFnshCallCnt(0);
		omn20305.setIcallNumTmTryCallCnt(0);
		omn20305.setIcallNumTmFnshCallCnt(0);
		omn20305.setAvgRsvTms(null);
		omn20305.setTrunkCnt(null);
		omn20305.setErlangVal(null);
		omn20305.setOvrCallCnt(0);
		omn20305.setAllTryCallExfluRt(null);
		omn20305.setItCallExfluRt(null);
		omn20305.setOtCallExfluRt(null);
		omn20305.setNyOccrDcOccrCnt(28134);
		omn20305.setFnshRtDcOccrCnt(0);
		omn20305.setOosRtDcOccrCnt(0);
		omn20305.setLineUseRtDcOccrCnt(0);
		omn20305.setOvrCallRtDcOccrCnt(0);
		omn20305.setExfluRtDcOccrCnt(0);
		omn20305.setIcallFnshRtDcOccrCnt(0);
		omn20305.setOcallFnshRtDcOccrCnt(0);
		omn20305.setItCallExfluDcOccrCnt(0);
		omn20305.setOtCallExfluRtDcOccrCnt(0);
		omn20305.setScrbrErrCnt(0);
		omn20305.setSysErrCnt(null);
		omn20305.setNwErrCnt(null);
		omn20305.setSvcErrCnt(null);
		omn20305.setTryCallDcOccrCnt(null);
		
		calcuThreshold("4101", omn20305);
		
		tran.commit();
	}

	public void testVoipCdr() throws Exception {
		OMN20305 omn20305 = new OMN20305();

		omn20305.setDataSrcClCd("C");
		omn20305.setMntrCyclCd("02");
		omn20305.setEquipId("000000063124");
		omn20305.setRoutNumCtt("034001");
		omn20305.setMntrDtm("20180807001500");
		omn20305.setMntrDt("20180807");
		omn20305.setRoutUsgCtt("2");
		omn20305.setExgNum("N");
		omn20305.setPhonSvcCd("N");
		omn20305.setBizrId("-1");
		omn20305.setPhonSvcNum("N");
		omn20305.setPortNum("-1");
		omn20305.setPriBizrId("-1");
		omn20305.setConnClCd("00");
		omn20305.setRoutDirnCd("N");
		omn20305.setDablYn("N");
		omn20305.setItCallCnt("0");
		omn20305.setIcallFnshCallCnt("0");
		omn20305.setOtCallCnt("0");
		omn20305.setOcallFnshCallCnt("0");
		omn20305.setTrunkCnt("60");
		omn20305.setIcallTcTms("0");
		omn20305.setOcallTcTms("0");
		omn20305.setOcallNumTmTryCallCnt("0");
		omn20305.setOcallNumTmFnshCallCnt("0");
		omn20305.setOcallNumTmTcTms("0");
		omn20305.setIcallNumTmTryCallCnt("0");
		omn20305.setIcallNumTmFnshCallCnt("0");
		omn20305.setIcallNumTmTcTms("0");
		omn20305.setAvgRsvTms("0.000000");
		omn20305.setErlangVal("0.000000");
		omn20305.setScrbrErrCnt("0");
		omn20305.setRoutErrCnt("0");
		omn20305.setNumConvErrCnt("0");
		omn20305.setTrunkErrCnt("0");
		omn20305.setEtcNcmplCallCnt("0");
		omn20305.setDoexgBizrId("1");
		omn20305.setVipCustYn("");
		omn20305.setNyOccrDcOccrCnt("100");
		omn20305.setFnshRtDcOccrCnt("0");
		omn20305.setExfluRtDcOccrCnt("0");
		omn20305.setItCallExfluDcOccrCnt("0");
		omn20305.setOtCallExfluRtDcOccrCnt("0");
		omn20305.setLineUseRtDcOccrCnt("0");
		omn20305.setItCallExfluRt("0.000000");
		omn20305.setOtCallExfluRt("0.000000");
		omn20305.setTestOtCallCnt("");
		omn20305.setTestOcallFnshCallCnt("");
		omn20305.setTestOcallTcTms("");
		omn20305.setTestItCallCnt("");
		omn20305.setTestIcallFnshCallCnt("");
		omn20305.setTestIcallTcTms("");
		
		calcuThreshold(omn20305.getDataSrcClCd(), omn20305);
		tran.commit();
	}


	public static void main(String[] args) {
		Options options = new Options();
		Option trfType = Option.builder().longOpt(C_TRF_TYPE)
				.desc("TRF_TYPE (PSTN or VOIP)").hasArg().argName(C_TRF_TYPE).build();
		options.addOption(trfType);

		EnvManager envManager = new EnvManager(args, options);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("UnmsTrafficReceiver", envManager.getOptions());
    		System.exit(0);
    	}
    	UnmsTrafficReceiver unmsTrafficReceiver = new UnmsTrafficReceiver(args);
		try {
			unmsTrafficReceiver.init();
			unmsTrafficReceiver.run();
			//unmsTrafficReceiver.testPstnCdr();
			//unmsTrafficReceiver.testVoipCdr();
		} catch (Exception e) {
			Logger.logger.error(e);
		}

	}

	@Override
	public void onTimeEvent(String name) {
		// TODO Auto-generated method stub
		synchronized (thresholdMgr) {
			try {
				init();
			} catch (Exception e) {
				Logger.logger.error(e);
			}
		}
	}
}
