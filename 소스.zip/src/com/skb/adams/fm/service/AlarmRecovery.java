package com.skb.adams.fm.service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.List;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.skb.adams.cm.util.StringUtils;
import com.skb.adams.fm.dao.AlarmRecoveryQid;
import com.skb.adams.fm.model.AlarmEquipInfo;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;
import subkjh.bas.dao.database.DataBase;
import subkjh.bas.log.Logger;

public class AlarmRecovery {
	final private String	TEAMS_NMS_CD 		= "005";
	final private String	SBNNMS_NMS_CD		= "006";
	final private String	BMS_NMS_CD	 		= "009";
	final private String	MIDKNIGHT_NMS_CD 	= "013";
	final private String	DAPS_NMS_CD 		= "013";
	final private String	TRAFFIC_FAULT		= "03";
	final private String	CIRCUIT_FAULT		= "04";
	
	private	String	startTime;
	private	String	endTime;
	private JSONParser			jsonParser = new JSONParser();
	private	AlarmRecoveryQid	QID = new AlarmRecoveryQid();
	private	DbTrans	tran;
	
	public AlarmRecovery(String[] args) {
		// args[0] : logFile
		// args[1] : startTime (HH24:MI:SS)
		// args[2] : endTime   (HH24:MI:SS)
		try {
			DataBase database = DBManager.getMgr().getDataBase("ADAMS");
			tran = database.createDbTrans(QID.QUERY_XML_FILE);
			tran.start();
			
			startTime = args[1];
			endTime = args[2];
			
			Logger.logger.info(String.format("startTime:%s", startTime));
			Logger.logger.info(String.format("endTime:%s", endTime));
	
			doIt(args[0]);
			
			tran.commit();
		} catch (Exception e) {
			Logger.logger.error(e);
		}
	}
	
	public void doIt(String fileName) {
		FileInputStream		fr = null;
		BufferedReader		br = null;

		try {
			fr = new FileInputStream(fileName);
			InputStreamReader ir = new InputStreamReader(fr);
			br = new BufferedReader(ir);
			String strLine;
			while ((strLine = br.readLine()) != null) {
				//Logger.logger.debug(strLine);
				String data = getJsonData(strLine);
				if (data == null) continue;
				JSONObject jsonObject = null;
				try {
					jsonObject = (JSONObject) jsonParser.parse(data);
				} catch (Exception e1) {
					Logger.logger.error(data);
					throw e1;
				}
				String kindStr = (String) jsonObject.get("kind");
				if ("GEN".equals(kindStr)) {
					Logger.logger.debug(strLine);
					//Logger.logger.debug(jsonObject.toString());
					recovery(jsonObject);
				}
			}
		} catch (Exception e) {
			Logger.logger.error(e);
		}
	}
	
	private String getJsonData(String data) {
		try {
			// 01234567890123456789
			// [2018-07-05 19:06:17.250]
			String timeStr = data.substring(12,20);
			if (startTime.compareTo(timeStr) <= 0 && endTime.compareTo(timeStr) >= 0) {
				// [2018-10-01 08:18:41.872][Thread-194862]NMSThread.run (NMSThread.java:137) {
				int pos = data.indexOf("NMSThread.java:137"); 
				if (pos == -1) return null;
				pos = data.indexOf('{');
				if (pos == -1) return null;
				return data.substring(pos);
			}
		} catch (Exception e) {
		}
		return null;
	}
	
	private void recovery(JSONObject jsonObject) throws Exception {
		String nmsCd = jsonObject.get("NMS_CD").toString();
		String occrDtm = jsonObject.get("OCCR_DTM").toString();
		String nmsDablNumCtt = jsonObject.get("NMS_DABL_NUM_CTT").toString();

		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("occrDtm", occrDtm);
		hmap.put("nmsDablNumCtt", nmsDablNumCtt);
		String dablNum = tran.selectQidStr(QID.SELECT_DABL_NUM, hmap);
		if (dablNum == null || dablNum.length() == 0) {
			Logger.logger.error(String.format("failed to get dablNum (%s,%s)", occrDtm, nmsDablNumCtt));
			return;
		}
		Logger.logger.debug(String.format("(%s,%s)->(%s)", occrDtm, nmsDablNumCtt, dablNum));
		
		jsonObject.put ("DABL_NUM", dablNum);
		
		jsonObject.put ("DABL_NET_CL_CD", "1");	// 가입자망

		if (!jsonObject.containsKey("EQUIP_MDL_NM")) jsonObject.put("EQUIP_MDL_NM", "*");
		if (!jsonObject.containsKey("LINE_DABL_TYP_CD")) jsonObject.put("LINE_DABL_TYP_CD", "N");
		if (!jsonObject.containsKey("CUST_CHRTIC_CD")) jsonObject.put("CUST_CHRTIC_CD", "");

		String qid = null;
		hmap = new HashMap<String, String>();
		if (nmsCd.equals("002") || nmsCd.equals("007")) {	// UNMS(PNMS,VOIP)
			qid = QID.SELECT_EQUIP_INFO__BY_EQUIP_ID;
			hmap.put("equipId", (String)jsonObject.get("EQUIP_ID"));
		} else if (nmsCd.equals("005")) {	// TEAMS
			qid = QID.SELECT_EQUIP_INFO__BY_TEAMS;
			hmap.put("equipId", (String)jsonObject.get("EQUIP_ID"));
			hmap.put("equipTidVal", (String)jsonObject.get("EQUIP_TID_VAL"));
		} else if (nmsCd.equals("006")) {	// SBNNMS
			qid = QID.SELECT_EQUIP_INFO__BY_SBNNMS;
			hmap.put("equipTidVal", (String)jsonObject.get("EQUIP_TID_VAL"));
		} else {
			if (!jsonObject.get("DABL_LCL_CD").toString().equals(CIRCUIT_FAULT) || !nmsCd.equals("009")) {
				qid = QID.SELECT_EQUIP_INFO__BY_EQUIP_TID_VAL;
				hmap.put("equipTidVal", (String)jsonObject.get("EQUIP_TID_VAL"));
			}
		}

		if (qid != null) {
			List<AlarmEquipInfo> alarmEquipInfoList = tran.selectQid2Res(qid, hmap);
			if (alarmEquipInfoList != null && alarmEquipInfoList.size() > 0) {
				AlarmEquipInfo alarmEquipInfo = alarmEquipInfoList.get(0);
				setAlarmEquipInfo(jsonObject, alarmEquipInfo);
			} else {
				String lclCd = (String) jsonObject.get("DABL_LCL_CD");
				if (nmsCd.equals("011")) {	// RMS
					hmap = new HashMap<String, String>();
					hmap.put("equipNm", (String)jsonObject.get("EQUIP_NM"));
					alarmEquipInfoList = tran.selectQid2Res(QID.SELECT_EQUIP_INFO__BY_RMS, hmap);
					if (alarmEquipInfoList != null && alarmEquipInfoList.size() > 0) {
						
					} else {
						jsonObject.put ("EQUIP_ID", "*****");
						jsonObject.put ("DIV_NM", "");
						jsonObject.put ("DIV_ID", "");
						jsonObject.put ("MGMT_TPO_CD", "#");
						jsonObject.put ("DISTB_CNTR_NM", "");
						jsonObject.put ("INFO_CNTR_NM", "");
						jsonObject.put ("EQUIP_MDL_TYP_CD", "");
						jsonObject.put ("EQUIP_MDL_TYP_NM", "");

					}
				} else if (nmsCd.equals ("009") && !"04".equals(lclCd)) {		// BMS
					return;
				} else {
					jsonObject.put ("EQUIP_ID", "*****");
					if (nmsCd.equals (SBNNMS_NMS_CD)) {
						jsonObject.put ("DABL_CONS_ITM_DESC", jsonObject.get("EQUIP_MDL_NM"));
						jsonObject.put ("EQUIP_DABL_MSG_CTT", jsonObject.get ("EQUIP_IP_ADDR"));
					}
					jsonObject.put ("DIV_NM", "");
					jsonObject.put ("DIV_ID", "");
					jsonObject.put ("TPO_CD", "#");
					jsonObject.put ("MGMT_TPO_CD", "#");
					jsonObject.put ("EQUIP_MDL_TYP_CD", "");
					jsonObject.put ("EQUIP_MDL_TYP_NM", "");
				}
				
			}
		}

		if (jsonObject.get("CO_VIP_CUST_YN") == null || jsonObject.get("CO_VIP_CUST_YN").equals ("")) {
			jsonObject.put("CO_VIP_CUST_YN", "N");
		}
		if (nmsCd.equals (MIDKNIGHT_NMS_CD)) {
			// MidKnight일 경우, EQUIP_MDL_NM을 저장
			jsonObject.put ("EQUIP_TID_VAL", (String) jsonObject.get("SBNMS_EQUIP_NM"));
		}
		
		insertOMN30110(jsonObject);
		
		if (nmsCd.equals(DAPS_NMS_CD)) {
			insertOMN30111(jsonObject);
		} else if (nmsCd.equals(TEAMS_NMS_CD) || nmsCd.equals(BMS_NMS_CD)) {
			if (((String) jsonObject.get ("DABL_LCL_CD")).equals(CIRCUIT_FAULT)) {
				insertOMN30120(jsonObject);
			}
		}
		/*
		if (jsonObject.get ("DABL_LCL_CD").toString().equals(TRAFFIC_FAULT) && jsonObject.get("NET_CL_CD").toString().equals("01")) {	// 01 : 교환망
			insertOMN30130(jsonObject);
		}
		*/
	}
	
	private void setAlarmEquipInfo(JSONObject jsonObject, AlarmEquipInfo alarmEquipInfo) {
		jsonObject.put("EQUIP_ID", alarmEquipInfo.getEquipId());
		jsonObject.put("EQUIP_NM", alarmEquipInfo.getEquipNm());
		jsonObject.put("TPO_NM", alarmEquipInfo.getTpoNm());
		jsonObject.put("DISTB_CNTR_NM", alarmEquipInfo.getTpoNm());
		jsonObject.put("EQUIP_IP_ADDR", alarmEquipInfo.getEquipIpAddr());
		jsonObject.put("EQUIP_MDL_CD", alarmEquipInfo.getEquipMdlCd());
		jsonObject.put("EQUIP_MDL_NM", alarmEquipInfo.getEquipMdlNm());
		jsonObject.put("EQUIP_SET_LOC_DESC", alarmEquipInfo.getEquipSetLocDesc());
		if (StringUtils.isEmpty(alarmEquipInfo.getTpoCd())) {
			jsonObject.put("TPO_CD", "#");
		} else {
			jsonObject.put("TPO_CD", alarmEquipInfo.getTpoCd());
		}
		jsonObject.put("DISTB_CNTR_CD", alarmEquipInfo.getTpoCd());
		jsonObject.put("MGMT_TPO_NM", alarmEquipInfo.getMgmtTpoNm());
		jsonObject.put("INFO_CNTR_NM", alarmEquipInfo.getMgmtTpoNm());
		if (StringUtils.isEmpty(alarmEquipInfo.getMgmtTpoCd())) {
			jsonObject.put("MGMT_TPO_CD", "#");
		} else {
			jsonObject.put("MGMT_TPO_CD", alarmEquipInfo.getMgmtTpoCd());
		}
		jsonObject.put("INFO_CNTR_CD", alarmEquipInfo.getMgmtTpoCd());
		jsonObject.put("TEAM_NM", alarmEquipInfo.getTeamNm());
		jsonObject.put("TEAM_ID", alarmEquipInfo.getTeamId());
		jsonObject.put("DIV_NM", alarmEquipInfo.getDivNm());
		jsonObject.put("DIV_ID", alarmEquipInfo.getDivId());
		jsonObject.put("EQUIP_MDL_TYP_CD", alarmEquipInfo.getEquipMdlTypCd());
		jsonObject.put("EQUIP_MDL_TYP_NM", alarmEquipInfo.getEquipMdlTypNm());
	}
	
	private void insertOMN30110(JSONObject jsonObject) throws Exception {
		String routNum = (String) jsonObject.get("ROUT_NUM");
		String routInfo = "";
		if (routNum == null) {
			routNum = "";
		} else {
			routInfo = routNum;
			if (routNum.length() > 6) {
				routNum = "";
			}
		}

		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("dablNum", (String) jsonObject.get("DABL_NUM"));
		hmap.put("coVipCustYn", (String) jsonObject.get("CO_VIP_CUST_YN"));
		hmap.put("equipId", (String) jsonObject.get("EQUIP_ID"));
		hmap.put("otxNum", (String) jsonObject.get("OTX_NUM"));
		hmap.put("ccellNum", (String) jsonObject.get("CCELL_NUM"));
		hmap.put("scardNumCtt", (String) jsonObject.get("SCARD_NUM_CTT"));
		hmap.put("portNum", (String) jsonObject.get("PORT_NUM"));
		hmap.put("routNum", routNum);
		hmap.put("moduleEquipId", (String) jsonObject.get("MODULE_EQUIP_ID"));
		hmap.put("mscModuleTypCd", (String) jsonObject.get("MSC_MODULE_TYP_CD"));
		hmap.put("mscModuleNm", (String) jsonObject.get("MSC_MODULE_NM"));
		hmap.put("incommBizrNm", (String) jsonObject.get("INCOMM_BIZR_NM"));
		hmap.put("tmId", (String) jsonObject.get("TM_ID"));
		hmap.put("procId", (String) jsonObject.get("PROC_ID"));
		hmap.put("subProcId", (String) jsonObject.get("SUB_PROC_ID"));
		hmap.put("supEquipIpAddr", (String) jsonObject.get("SUP_EQUIP_IP_ADDR"));
		hmap.put("supEquipNm", (String) jsonObject.get("SUP_EQUIP_NM"));
		hmap.put("supEquipIfPortNm", (String) jsonObject.get("SUP_EQUIP_IF_PORT_NM"));
		hmap.put("supEquipIfAlsNm", (String) jsonObject.get("SUP_EQUIP_IF_ALS_NM"));
		hmap.put("ringNm", (String) jsonObject.get("RING_NM"));
		hmap.put("dablLocNm", (String) jsonObject.get("DABL_LOC_NM"));
		hmap.put("sbnmsEquipNm", (String) jsonObject.get("SBNMS_EQUIP_NM"));
		hmap.put("routInfo", routInfo);
		hmap.put("shspdInetDmgLineCnt", (String) jsonObject.get("SHSPD_INET_DMG_LINE_CNT"));
		hmap.put("gnrlIptvDmgLineCnt", (String) jsonObject.get("GNRL_IPTV_DMG_LINE_CNT"));
		hmap.put("indpndIptvDmgLineCnt", (String) jsonObject.get("INDPND_IPTV_DMG_LINE_CNT"));
		hmap.put("gnlphDmgLineCnt", (String) jsonObject.get("GNLPH_DMG_LINE_CNT"));
		hmap.put("shspdVocCnt", (String) jsonObject.get("SHSPD_VOC_CNT"));
		hmap.put("iptvVocCnt", (String) jsonObject.get("IPTV_VOC_CNT"));
		hmap.put("voipVocCnt", (String) jsonObject.get("VOIP_VOC_CNT"));
		hmap.put("phonVocCnt", (String) jsonObject.get("PHON_VOC_CNT"));
		hmap.put("totVocCnt", (String) jsonObject.get("TOT_VOC_CNT"));
		tran.create(QID.INSERT_OMN30110, hmap);
	}
	
	private void insertOMN30111(JSONObject jsonObject) throws Exception {
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("dablNum", (String) jsonObject.get("DABL_NUM"));
		hmap.put("srcIpAddr", (String) jsonObject.get("SRC_IP"));
		hmap.put("objIpAddr", (String) jsonObject.get("DST_IP"));
		hmap.put("dmgIpAddr", (String) jsonObject.get("AFF_IP"));
		hmap.put("custMacAddr", (String) jsonObject.get("CUST_MAC"));
		hmap.put("custNum", (String) jsonObject.get("CUST_NUM"));
		hmap.put("dirnCd", ((String) jsonObject.get("DIRECTION")).substring(0,1));
		hmap.put("dapsBlkClCd", (String) jsonObject.get("DAPS_BLOCK_FLAG"));
		hmap.put("grpId", (String) jsonObject.get("GROUP_CODE"));
		hmap.put("grpNm", (String) jsonObject.get("GROUP_NAME"));
		hmap.put("dapsGrpNm", (String) jsonObject.get("DAPS_GROUP_NAME"));
		hmap.put("blkTypCd", (String) jsonObject.get("BLOCK_TYPE"));
		hmap.put("clznBlkClCd", (String) jsonObject.get("CLEAN_BLOCK_FLAG"));
		hmap.put("asNumCtt", (String) jsonObject.get("ASNUM"));
		hmap.put("prtclCtt", (String) jsonObject.get("PROTOCOLS"));
		hmap.put("influBpsCtt", (String) jsonObject.get("IMPACT_BPS"));
		hmap.put("influPpsCtt", (String) jsonObject.get("IMPACT_PPS"));
		hmap.put("dapsAlmTypVal", (String) jsonObject.get("ALERT_TYPE"));
		hmap.put("dapsTeamCd", (String) jsonObject.get("TEAM_CODE"));
		hmap.put("dapsTeamNm", (String) jsonObject.get("TEAM_NAME"));
		hmap.put("dapsAreaCd", (String) jsonObject.get("AREA_CODE"));
		hmap.put("dapsAreaNm", (String) jsonObject.get("AREA_NAME"));
		hmap.put("dapsTpoCd", (String) jsonObject.get("DEV_AREA_CODE"));
		hmap.put("dapsTpoNm", (String) jsonObject.get("DEV_AREA_NAME"));
		hmap.put("dapsMgmtTeamCd", (String) jsonObject.get("DEV_TEAM_CODE"));
		hmap.put("dapsMgmtTeamNm", (String) jsonObject.get("DEV_TEAM_NAME"));
		hmap.put("dapsInfcNm", (String) jsonObject.get("DAPS_INFC_NM"));
		hmap.put("keepTms", (String) jsonObject.get("KEEP_TMS"));
		tran.create(QID.INSERT_OMN30111, hmap);
	}

	private void insertOMN30120(JSONObject jsonObject) throws Exception {
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("dablNum", (String) jsonObject.get("DABL_NUM"));
		hmap.put("equipId", (String) jsonObject.get("EQUIP_ID"));
		hmap.put("otxNum", (String) jsonObject.get("OTX_NUM"));
		hmap.put("ccellNum", (String) jsonObject.get("CCELL_NUM"));
		hmap.put("scardNumCtt", (String) jsonObject.get("SCARD_NUM_CTT"));
		hmap.put("portNum", (String) jsonObject.get("PORT_NUM"));
		hmap.put("lineNum", (String) jsonObject.get("LINE_NUM"));
		hmap.put("custNum", (String) jsonObject.get("CUST_NUM"));
		hmap.put("supTpoCd", (String) jsonObject.get("SUP_TPO_CD"));
		hmap.put("subTpoCd", (String) jsonObject.get("SUB_TPO_CD"));
		hmap.put("svcTechMthdNm", (String) jsonObject.get("SVC_TECH_MTHD_NM"));
		hmap.put("speedCd", (String) jsonObject.get("SPEED_CD"));
		hmap.put("dmgLineCnt", (String) jsonObject.get("DMG_LINE_CNT"));
		hmap.put("chrgrId", (String) jsonObject.get("CHRGR_ID"));
		hmap.put("massCoClCd", (String) jsonObject.get("MASS_CO_CL_CD"));
		hmap.put("ringNm", (String) jsonObject.get("RING_NM"));
		hmap.put("bmsEquipIpAddr", (String) jsonObject.get("EQUIP_IP_ADDR"));
		hmap.put("custNm", (String) jsonObject.get("CUST_NM"));
		hmap.put("lineDablTypCd", (String) jsonObject.get("LINE_DABL_TYP_CD"));
		hmap.put("custChrticNm", (String) jsonObject.get("CUST_CHRTIC_CD"));
		hmap.put("lineNm", (String) jsonObject.get("LINE_NM"));
		hmap.put("custChrticNm", (String) jsonObject.get("CUST_CHRTIC_NM"));
		hmap.put("speedNm", (String) jsonObject.get("SPEED_NM"));
		hmap.put("supTpoNm", (String) jsonObject.get("SUP_TPO_NM"));
		hmap.put("subTpoNm", (String) jsonObject.get("SUB_TPO_NM"));
		hmap.put("svcMgmtNum", (String) jsonObject.get("SVC_MGMT_NUM"));
		tran.create(QID.INSERT_OMN30120, hmap);
	}

	private void insertOMN30130(JSONObject jsonObject) throws Exception {
		HashMap<String, String> hmap = new HashMap<String, String>();
		tran.create(QID.INSERT_OMN30130, hmap);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new AlarmRecovery(args);
	}

}
