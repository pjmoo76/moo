package com.skb.adams.fm.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.skb.adams.fm.model.FmConstants;
import com.skb.adams.fm.model.OMN10221;
import com.skb.adams.fm.model.OMN10223;
import com.skb.adams.fm.model.OMN20305;
import com.skb.adams.fm.model.UnmsTrafficPI;

public class UnmsTrafficThresholdManager {
	
	// OMN10221
	// 1. 루트별&V5.2별 트래픽 장애
	//    MNTR_CYCL_CD + EQUIP_ID + ROUT_NUM + ROUT_CONN_DIRN_CD + THRS_NM(시내 루트별 임계치)
	//    --> DEFAULT 임계치 : 8
	// 2. 서비스별&사업자별 트래픽 장애
	//    rout_usg_ctt(110) : MNTR_CYCL_CD + EQUIP_ID + CONN_BIZR_ID + THRS_NM(시내 사업자별 임계치)
	//    rout_usg_ctt(120) : MNTR_CYCL_CD + EQUIP_ID + CONN_CL_CD + THRS_NM(시내 서비스별 임계치)
	//    --> DEFAULT 임계치 : 사업자별:16, 서비스별:17
	
	private HashMap<String, OMN10221> thrsRouteMap;
	private HashMap<String, OMN10221> thrsServiceMap;
	private HashMap<String, OMN10221> thrsBizrMap;
	private HashMap<String, OMN10221> thrsVoipMap;

	// WPHON_THRS_ID, List<WPHON_THRS_ITM_NM>

	private HashMap<String, HashMap<String, OMN10223>>	omn10223Map;

	public UnmsTrafficThresholdManager() {
		thrsRouteMap = new HashMap<String, OMN10221>();
		thrsServiceMap = new HashMap<String, OMN10221>();
		thrsBizrMap = new HashMap<String, OMN10221>();
		thrsVoipMap = new HashMap<String, OMN10221>();
		omn10223Map = new HashMap<String, HashMap<String, OMN10223>>();
	}
	
	public void clear() {
		thrsRouteMap.clear();
		thrsServiceMap.clear();
		thrsBizrMap.clear();
		omn10223Map.clear();
	}
	
	public void add(OMN10221 omn10221) {
		if (FmConstants.THRS_NM.ROUTE.equals(omn10221.getThrsNm())) {
			String key = getThrsRouteKey(omn10221);
			OMN10221 value = thrsRouteMap.get(key);
			if (value == null) {
				thrsRouteMap.put(key, omn10221);
			} else {
				int oldThrsId = Integer.parseInt(value.getWphonThrsId());
				int newThrsId = Integer.parseInt(omn10221.getWphonThrsId());
				if (oldThrsId < newThrsId) {
					thrsRouteMap.put(key, omn10221);
				}
			}
		} else if (FmConstants.THRS_NM.SERVICE.equals(omn10221.getThrsNm())) {
			String key = getThrsServiceKey(omn10221);
			OMN10221 value = thrsServiceMap.get(key);
			if (value == null) {
				thrsServiceMap.put(key, omn10221);
			} else {
				int oldThrsId = Integer.parseInt(value.getWphonThrsId());
				int newThrsId = Integer.parseInt(omn10221.getWphonThrsId());
				if (oldThrsId < newThrsId) {
					thrsServiceMap.put(key, omn10221);
				}
			}
		} else if (FmConstants.THRS_NM.BIZR.equals(omn10221.getThrsNm())) {
			String key = getThrsBizrKey(omn10221);
			OMN10221 value = thrsBizrMap.get(key);
			if (value == null) {
				thrsBizrMap.put(key, omn10221);
			} else {
				int oldThrsId = Integer.parseInt(value.getWphonThrsId());
				int newThrsId = Integer.parseInt(omn10221.getWphonThrsId());
				if (oldThrsId < newThrsId) {
					thrsBizrMap.put(key, omn10221);
				}
			}
		} else if (FmConstants.THRS_NM.VOIP_ROUTE.equals(omn10221.getThrsNm())) {
			String key = getThrsVoipKey(omn10221);
			OMN10221 value = thrsVoipMap.get(key);
			if (value == null) {
				thrsVoipMap.put(key, omn10221);
			} else {
				int oldThrsId = Integer.parseInt(value.getWphonThrsId());
				int newThrsId = Integer.parseInt(omn10221.getWphonThrsId());
				if (oldThrsId < newThrsId) {
					thrsVoipMap.put(key, omn10221);
				}
			}
		}
	}

	public void add(OMN10223 omn10223) {
		HashMap<String, OMN10223> value = omn10223Map.get(omn10223.getWphonThrsId());
		if (value == null) {
			value = new HashMap<String, OMN10223>();
			value.put(omn10223.getWphonThrsItmNm(), omn10223);
			omn10223Map.put(omn10223.getWphonThrsId(), value);
		} else {
			value.put(omn10223.getWphonThrsItmNm(), omn10223);
		}
	}

	public String getThrsKey(OMN10221 omn10221) {
		if (FmConstants.THRS_NM.ROUTE.equals(omn10221.getThrsNm())) {
			return getThrsRouteKey(omn10221);
		} else if (FmConstants.THRS_NM.SERVICE.equals(omn10221.getThrsNm())) {
			return getThrsServiceKey(omn10221);
		} else if (FmConstants.THRS_NM.BIZR.equals(omn10221.getThrsNm())) {
			return getThrsBizrKey(omn10221);
		} else if (FmConstants.THRS_NM.VOIP_ROUTE.equals(omn10221.getThrsNm())) {
			return getThrsVoipKey(omn10221);
		} else {
			return null;
		}
	}

	private String getThrsRouteKey(OMN10221 omn10221) {
		return omn10221.getMntrCyclCd() + "|" + omn10221.getEquipId() + "|" + convRoutNumCtt(omn10221.getRoutNum()) + "|" + omn10221.getRoutConnDirnCd();
	}

	private String getThrsServiceKey(OMN10221 omn10221) {
		return omn10221.getMntrCyclCd() + "|" + omn10221.getEquipId() + "|" + omn10221.getConnClCd();
	}

	private String getThrsBizrKey(OMN10221 omn10221) {
		return omn10221.getMntrCyclCd() + "|" + omn10221.getEquipId() + "|" + omn10221.getConnBizrId();
	}

	private String getThrsVoipKey(OMN10221 omn10221) {
		return omn10221.getEquipId() + "|" + convRoutNumCtt(omn10221.getRoutNum()) + "|" + omn10221.getRoutConnDirnCd();
	}

	public HashMap<String, OMN10223> get(String dablMclCd, OMN20305 omn20305, UnmsTrafficPI trafficPI) {
		String wphonThrsId = null;
		if (FmConstants.DABL_MCL_CD.PSTN_TRAFFIC_ROUTE.equals(dablMclCd) || FmConstants.DABL_MCL_CD.PSTN_TRAFFIC_V52.equals(dablMclCd)) {
			String key = omn20305.getMntrCyclCd() + "|" + omn20305.getEquipId() + "|" + convRoutNumCtt(omn20305.getRoutNumCtt()) + "|" + trafficPI.getRoutConnDirnCd();
			OMN10221 omn10221 = thrsRouteMap.get(key);
			if (omn10221 != null) {
				wphonThrsId = omn10221.getWphonThrsId();
			} else {
				wphonThrsId = FmConstants.THRS_DEFAULT_ID.ROUTE;
			}
		} else if (FmConstants.ROUT_USG_CTT.RUC_BIZR_110.equals(omn20305.getRoutUsgCtt())) {
			String key = omn20305.getMntrCyclCd() + "|" + omn20305.getEquipId() + "|" + omn20305.getDoexgBizrId();
			OMN10221 omn10221 = thrsRouteMap.get(key);
			if (omn10221 != null) {
				wphonThrsId = omn10221.getWphonThrsId();
			} else {
				wphonThrsId = FmConstants.THRS_DEFAULT_ID.BIZR;
			}
		} else if (FmConstants.ROUT_USG_CTT.RUC_SERVICE_120.equals(omn20305.getRoutUsgCtt())) {			
			String key = omn20305.getMntrCyclCd() + "|" + omn20305.getEquipId() + "|" + omn20305.getConnClCd();
			OMN10221 omn10221 = thrsRouteMap.get(key);
			if (omn10221 != null) {
				wphonThrsId = omn10221.getWphonThrsId();
			} else {
				wphonThrsId = FmConstants.THRS_DEFAULT_ID.SERVICE;
			}
		} else if (FmConstants.DABL_MCL_CD.VOIP_TRAFFIC_CALL.equals(dablMclCd) || FmConstants.DABL_MCL_CD.VOIP_TRAFFIC_V52.equals(dablMclCd)) {
			String key = omn20305.getEquipId() + "|" + convRoutNumCtt(omn20305.getRoutNumCtt()) + "|" + trafficPI.getRoutConnDirnCd();
			OMN10221 omn10221 = thrsVoipMap.get(key);
			if (omn10221 != null) {
				wphonThrsId = omn10221.getWphonThrsId();
			} else {
				wphonThrsId = FmConstants.THRS_DEFAULT_ID.VOIP_ROUTE;
			}
		}
		if (wphonThrsId != null) {
			return omn10223Map.get(wphonThrsId);
		}
		return null;
	}
	
	public OMN10221 getOMN10221(OMN20305 omn20305, UnmsTrafficPI trafficPI) {
		String key = omn20305.getEquipId() + "|" + convRoutNumCtt(omn20305.getRoutNumCtt()) + "|" + trafficPI.getRoutConnDirnCd();
		return thrsVoipMap.get(key);
	}
	
	private String convRoutNumCtt(String val) {
		try {
			int routeNum = Integer.parseInt(val);
			return "" + routeNum;
		} catch (Exception e) {
			return val;
		}
	}
}
