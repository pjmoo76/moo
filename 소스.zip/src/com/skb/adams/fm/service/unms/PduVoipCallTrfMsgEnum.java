package com.skb.adams.fm.service.unms;

public enum PduVoipCallTrfMsgEnum {
	E_EQUIP_USG_CD(0),
	E_DATA_SRC_CL_CD(1),
	E_MNTR_CYCL_CD(2),
	E_EQUIP_ID(3),
	E_ROUT_NUM(4), /* routNumCtt */
	E_ROUT_NM(5),
	E_ROUT_USG_CTT(6), /* routUsgCtt */
	E_EXG_NUM(7), /* exgNum : 국번호 */
	E_PHON_IDNT_NUM(8), /* 국번호의 지역 노드 아이디 */
	E_TPO_NM(9), /* 국번호의 지역 노드명 */
	E_EXG_NM(10), /* 국번호 지역명 */
	E_EXG_NUM_CALL_TYP_CD(11), /* phonSvcCd : 국번호의 "발착신"(I, O, B) */
	E_ROUT_CONN_HRCHY_CD(12), /* 서비스 식별 번호 코드 */
	E_SVC_BIZR_ID(13), /* priBizrId : 서비스 식별 번호 관련 사업자 코드 */
	E_SVC_BIZR_NM(14), /* 서비스 식별 번호 관련 사업자명 */
	E_SVC_NUM(15), /* phonSvcNum : 서비스 식별 번호 */
	E_SVC_NM(16), /* 서비스 식별 번호명 */
	E_PORT_NO(17), /* portNum : PRI port 또는 ROUTE_USG가 RTEUSG_trunk(4)일 경우, TG의 포트번호(cf_port.port_no) */
	E_PRI_NUM(18), /* PRI num */
	E_PRI_BIZR_ID(19), /* PRI carrier id */
	E_PRI_BIZR_NM(20), /* PRI carrier name */
	E_ROUT_CONN_TYP_CD(21), /* connClCd */
	E_ROUT_CONN_DIRN_CD(22), /* routDirnCd */
	E_EVENT_DATE_ZONE(23), 
	E_IS_ALARM(24), /* dablYn */
	E_ALARM(25),
	E_INC_ATT(26), /* itCallCnt */
	E_INC_ANS(27), /* icallFnshCallCnt */
	E_OUT_ATT(28), /* otCallCnt */
	E_OUT_ANS(29), /* ocallFnshCallCnt */
	E_TRUNK_NUM(30), /* trunkCnt : 실장 회선수 */
	E_INC_CALL_SEC(31), /* icallTcTms : 착신 통화시간(초) */
	E_OUT_CALL_SEC(32), /* ocallTcTms : 발신 통화시간(초) */
	E_A_TM_ATT(33), /* ocallNumTmTryCallCnt */
	E_A_TM_ANS(34), /* ocallNumTmFnshCallCnt */
	E_A_TM_CALL_SEC(35), /* ocallNumTmTcTms */
	E_B_TM_ATT(36), /* icallNumTmTryCallCnt */
	E_B_TM_ANS(37), /* icallNumTmFnshCallCnt */
	E_B_TM_CALL_SEC(38), /* icallNumTmTcTms */
	E_AHDT(39), /* avgRsvTms : AHDT */
	E_ERLANG(40), /* erlangVal : 얼랑 */
	E_INCOMPL_subs(41), /* scrbrErrCnt : 가입자 오류 */
	E_INCOMPL_routing(42), /* routErrCnt : 라우팅 오류 */
	E_INCOMPL_number(43), /* numConvErrCnt : 번호번역 오류 */
	E_INCOMPL_norm(44), /* 정상 불완료 오류 */
	E_INCOMPL_trunk(45), /* trunkErrCnt : 트렁크 오류 */
	E_INCOMPL_etc(46), /* etcNcmplCallCnt : 기타 불완료 오류 */
	E_DOEXG_MSC_NM(47), /* 대국교환기명, 착신지(접속교환기) */
	E_DOEXG_BIZR_ID(48), /* doexgBizrId : 대국사업자ID, 접속 사업자 코드 */
	E_DOEXG_BIZR_NM(49), /* 대국사업자명, 접속 사업자 명 */
	E_DOEXG_VIP_CUST_YN(50), /* vipCustYn : VIP 고객 여부('Y', 'N') */
	E_RTEUSG(51), /* 회선이용율 */
	E_CONN_NUM_NO_ATT(52), /* nyOccrDcOccrCnt : 연속 미발생 횟수 */
	E_CONN_NUM_ANSR(53), /* fnshRtDcOccrCnt */
	E_CONN_NUM_VAR_ATT(54), /* exfluRtDcOccrCnt */
	E_CONN_NUM_IANSR(55),
	E_CONN_NUM_OANSR(56),
	E_CONN_NUM_IVAR_ATT(57), /* itCallExfluDcOccrCnt */
	E_CONN_NUM_OVAR_ATT(58), /* otCallExfluRtDcOccrCnt */
	E_CONN_NUM_RTE_USG(59), /* lineUseRtDcOccrCnt */
	E_VAR_ATT_RATIO(60),
	E_VAR_IATT_RATIO(61), /* itCallExfluRt */
	E_VAR_OATT_RATIO(62), /* otCallExfluRt */
	E_JITTER(63),
	E_LATENCY(64),
	E_LOSS(65),
	E_R_VALUE_CNT(66),
	E_R_VALUE_SUM(67), /* R값 평균(=R_VALUE_SUM/R_VALUE_CNT) */
	E_MOS_SUM(68), /* MOS 평균을 보여줌 (=MOS_SUM/R_VALUE_CNT) */
	E_OPP_JITTER(69),
	E_OPP_LATENCY(70),
	E_OPP_LOSS(71),
	E_OPP_R_VALUE_CNT(72),
	E_OPP_R_VALUE_SUM(73), /* R값 평균(=R_VALUE_SUM/R_VALUE_CNT) */
	E_OPP_MOS_SUM(74), /* MOS 평균을 보여줌 (=MOS_SUM/R_VALUE_CNT) */
	E_A_TEST_ATT(75), /* testOtCallCnt */
	E_A_TEST_ANS(76), /* testOcallFnshCallCnt */
	E_A_TEST_CALL_SEC(77), /* testOcallTcTms */
	E_B_TEST_ATT(78), /* testItCallCnt */
	E_B_TEST_ANS(79), /* testIcallFnshCallCnt */
	E_B_TEST_CALL_SEC(80), /* testIcallTcTms */
	E_TM_NM(81),
	E_BIZR_NM(82),
	NUM_EVENT(83)
	;

	private	final int	index;
	PduVoipCallTrfMsgEnum(int index) {
		this.index = index;
	}
	public int getIndex() {
		return this.index;
	}
}
