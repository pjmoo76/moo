package com.skb.adams.fm.model;

public class OMN20305 {
	private	String	mntrDt;
	private	int	mntrNum;
	private	String	auditId;
	private	String	auditDtm;
	private	String	mntrDtm;
	private	String	mntrCyclCd;
	private	String	dataSrcClCd;
	private	String	exchgEquipClCd;
	private	String	equipId;
	private	String	equipSysNm;
	private	String	routNumCtt;
	private	String	routUsgCtt;
	private	String	exgNum;
	private	String	tpoCd;
	private	String	phonSvcCd;
	private	int	bizrId;
	private	String	phonSvcNum;
	private	String	portNum;
	private	String	connClCd;
	private	String	routDirnCd;
	private	int	doexgBizrId;
	private	String	priGrpNum;
	private	int	priBizrId;
	private	String	dablYn;
	private	int	ocallOutRlayCallCnt;
	private	int	ioexgTryCallCnt;
	private	int	ioexgFnshCallCnt;
	private	int	itCallCnt;
	private	int	icallFnshCallCnt;
	private	int	otCallCnt;
	private	int	ocallFnshCallCnt;
	private	String	trunkLineNum;
	private	int	ovrCallCnt;
	private	int	icallTcTms;
	private	int	ocallTcTms;
	private	int	tcTms;
	private	int	ocallNumTmTryCallCnt;
	private	int	ocallNumTmFnshCallCnt;
	private	int	ocallNumTmTcTms;
	private	int	icallNumTmTryCallCnt;
	private	int	icallNumTmFnshCallCnt;
	private	int	icallNumTmTcTms;
	private	double	avgRsvTms;
	private	double	erlangVal;
	private	int	scrbrErrCnt;
	private	int	sysErrCnt;
	private	int	nwErrCnt;
	private	int	svcErrCnt;
	private	int	routErrCnt;
	private	int	numConvErrCnt;
	private	int	trunkErrCnt;
	private	int	ncmplCallCnt;
	private	int	etcNcmplCallCnt;
	private	int	scrbrCnt;
	private	int	trunkCnt;
	private	int	equipLinkCnt;
	private	int	trnkCngsCnt;
	private	int	mscCngsCnt;
	private	int	dirRoutPossCallCnt;
	private	int	altRoutPossCallCnt;
	private	int	rpsBfGvupCallCnt;
	private	int	adiCnt;
	private	int	icallScrbrLineBusyCnt;
	private	int	dialingGvupCnt;
	private	int	sgnlOpErrCnt;
	private	int	outTrnkDablCnt;
	private	int	fblkCnt;
	private	int	mblkCnt;
	private	int	sblkCnt;
	private	int	cardSpratCnt;
	private	int	nyOccrDcOccrCnt;
	private	int	fnshRtDcOccrCnt;
	private	int	oosRtDcOccrCnt;
	private	int	ovrCallRtDcOccrCnt;
	private	int	exfluRtDcOccrCnt;
	private	int	icallFnshRtDcOccrCnt;
	private	int	ocallFnshRtDcOccrCnt;
	private	int	itCallExfluDcOccrCnt;
	private	int	otCallExfluRtDcOccrCnt;
	private	int	lineUseRtDcOccrCnt;
	private	int	allTryCallExfluRt;
	private	int	itCallExfluRt;
	private	int	otCallExfluRt;
	private	int	tryCallDcOccrCnt;
	private	String	supEquipId;
	private	String	vipCustYn;
	private	String	exgNumClCd;
	private	int	jitrAvgVal;
	private	int	dlayAvgVal;
	private	int	lossAvgVal;
	private	int	rTotVal;
	private	int	rCallCnt;
	private	int	rAvgVal;
	private	int	mosTotVal;
	private	int	mosAvgVal;
	private	int	testOtCallCnt;
	private	int	testOcallFnshCallCnt;
	private	int	testOcallTcTms;
	private	int	testItCallCnt;
	private	int	testIcallFnshCallCnt;
	private	int	testIcallTcTms;

	public String getMntrDt() {
		return mntrDt;
	}
	public void setMntrDt(String mntrDt) {
		this.mntrDt = mntrDt;
	}
	public int getMntrNum() {
		return mntrNum;
	}
	public void setMntrNum(int mntrNum) {
		this.mntrNum = mntrNum;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getMntrDtm() {
		return mntrDtm;
	}
	public void setMntrDtm(String mntrDtm) {
		this.mntrDtm = mntrDtm;
	}
	public String getMntrCyclCd() {
		return mntrCyclCd;
	}
	public void setMntrCyclCd(String mntrCyclCd) {
		this.mntrCyclCd = mntrCyclCd;
	}
	public String getDataSrcClCd() {
		return dataSrcClCd;
	}
	public void setDataSrcClCd(String dataSrcClCd) {
		this.dataSrcClCd = dataSrcClCd;
	}
	public String getExchgEquipClCd() {
		return exchgEquipClCd;
	}
	public void setExchgEquipClCd(String exchgEquipClCd) {
		this.exchgEquipClCd = exchgEquipClCd;
	}
	public String getEquipId() {
		return equipId;
	}
	public void setEquipId(String equipId) {
		this.equipId = equipId;
	}
	public String getEquipSysNm() {
		return equipSysNm;
	}
	public void setEquipSysNm(String equipSysNm) {
		this.equipSysNm = equipSysNm;
	}
	public String getRoutNumCtt() {
		return routNumCtt;
	}
	public void setRoutNumCtt(String routNumCtt) {
		this.routNumCtt = routNumCtt;
	}
	public String getRoutUsgCtt() {
		return routUsgCtt;
	}
	public void setRoutUsgCtt(String routUsgCtt) {
		this.routUsgCtt = routUsgCtt;
	}
	public String getExgNum() {
		return exgNum;
	}
	public void setExgNum(String exgNum) {
		this.exgNum = exgNum;
	}
	public String getTpoCd() {
		return tpoCd;
	}
	public void setTpoCd(String tpoCd) {
		this.tpoCd = tpoCd;
	}
	public String getPhonSvcCd() {
		return phonSvcCd;
	}
	public void setPhonSvcCd(String phonSvcCd) {
		this.phonSvcCd = phonSvcCd;
	}
	public int getBizrId() {
		return bizrId;
	}
	public void setBizrId(int bizrId) {
		this.bizrId = bizrId;
	}
	public void setBizrId(String bizrId) {
		try {
			this.bizrId = Integer.parseInt(bizrId);
		} catch (Exception e) {
			this.bizrId = 0;
		}
	}
	public String getPhonSvcNum() {
		return phonSvcNum;
	}
	public void setPhonSvcNum(String phonSvcNum) {
		this.phonSvcNum = phonSvcNum;
	}
	public String getPortNum() {
		return portNum;
	}
	public void setPortNum(String portNum) {
		this.portNum = portNum;
	}
	public String getConnClCd() {
		return connClCd;
	}
	public void setConnClCd(String connClCd) {
		this.connClCd = connClCd;
	}
	public String getRoutDirnCd() {
		return routDirnCd;
	}
	public void setRoutDirnCd(String routDirnCd) {
		this.routDirnCd = routDirnCd;
	}
	public int getDoexgBizrId() {
		return doexgBizrId;
	}
	public void setDoexgBizrId(int doexgBizrId) {
		this.doexgBizrId = doexgBizrId;
	}
	public void setDoexgBizrId(String doexgBizrIdStr) {
		try {
			this.doexgBizrId = Integer.parseInt(doexgBizrIdStr);
		} catch (Exception e) {
			this.doexgBizrId = 0;
		}
	}
	public String getPriGrpNum() {
		return priGrpNum;
	}
	public void setPriGrpNum(String priGrpNum) {
		this.priGrpNum = priGrpNum;
	}
	public int getPriBizrId() {
		return priBizrId;
	}
	public void setPriBizrId(int priBizrId) {
		this.priBizrId = priBizrId;
	}
	public void setPriBizrId(String priBizrId) {
		try {
			this.priBizrId = Integer.parseInt(priBizrId);
		} catch (Exception e) {
			this.priBizrId = 0;
		}
	}
	public String getDablYn() {
		return dablYn;
	}
	public void setDablYn(String dablYn) {
		this.dablYn = dablYn;
	}
	public int getOcallOutRlayCallCnt() {
		return ocallOutRlayCallCnt;
	}
	public void setOcallOutRlayCallCnt(int ocallOutRlayCallCnt) {
		this.ocallOutRlayCallCnt = ocallOutRlayCallCnt;
	}
	public int getIoexgTryCallCnt() {
		return ioexgTryCallCnt;
	}
	public void setIoexgTryCallCnt(int ioexgTryCallCnt) {
		this.ioexgTryCallCnt = ioexgTryCallCnt;
	}
	public void setIoexgTryCallCnt(String ioexgTryCallCntStr) {
		try {
			this.ioexgTryCallCnt = Integer.parseInt(ioexgTryCallCntStr);
		} catch (Exception e) {
			this.ioexgTryCallCnt = 0;
		}
	}
	public int getIoexgFnshCallCnt() {
		return ioexgFnshCallCnt;
	}
	public void setIoexgFnshCallCnt(int ioexgFnshCallCnt) {
		this.ioexgFnshCallCnt = ioexgFnshCallCnt;
	}
	public void setIoexgFnshCallCnt(String ioexgFnshCallCntStr) {
		try {
			this.ioexgFnshCallCnt = Integer.parseInt(ioexgFnshCallCntStr);
		} catch (Exception e) {
			this.ioexgFnshCallCnt = 0;
		}
	}
	public int getItCallCnt() {
		return itCallCnt;
	}
	public void setItCallCnt(int itCallCnt) {
		this.itCallCnt = itCallCnt;
	}
	public void setItCallCnt(String itCallCntStr) {
		try {
			this.itCallCnt = Integer.parseInt(itCallCntStr);
		} catch (Exception e) {
			this.itCallCnt = 0;
		}
	}
	public int getIcallFnshCallCnt() {
		return icallFnshCallCnt;
	}
	public void setIcallFnshCallCnt(int icallFnshCallCnt) {
		this.icallFnshCallCnt = icallFnshCallCnt;
	}
	public void setIcallFnshCallCnt(String icallFnshCallCntStr) {
		try {
			this.icallFnshCallCnt = Integer.parseInt(icallFnshCallCntStr);
		} catch (Exception e) {
			this.icallFnshCallCnt = 0;
		}
	}
	public int getOtCallCnt() {
		return otCallCnt;
	}
	public void setOtCallCnt(int otCallCnt) {
		this.otCallCnt = otCallCnt;
	}
	public void setOtCallCnt(String otCallCntStr) {
		try {
			this.otCallCnt = Integer.parseInt(otCallCntStr);
		} catch (Exception e) {
			this.otCallCnt = 0;
		}
	}
	public int getOcallFnshCallCnt() {
		return ocallFnshCallCnt;
	}
	public void setOcallFnshCallCnt(int ocallFnshCallCnt) {
		this.ocallFnshCallCnt = ocallFnshCallCnt;
	}
	public void setOcallFnshCallCnt(String ocallFnshCallCntStr) {
		try {
			this.ocallFnshCallCnt = Integer.parseInt(ocallFnshCallCntStr);
		} catch (Exception e) {
			this.ocallFnshCallCnt = 0;
		}
	}
	public String getTrunkLineNum() {
		return trunkLineNum;
	}
	public void setTrunkLineNum(String trunkLineNum) {
		this.trunkLineNum = trunkLineNum;
	}
	public int getOvrCallCnt() {
		return ovrCallCnt;
	}
	public void setOvrCallCnt(int ovrCallCnt) {
		this.ovrCallCnt = ovrCallCnt;
	}
	public void setOvrCallCnt(String ovrCallCntStr) {
		try {
			this.ovrCallCnt = Integer.parseInt(ovrCallCntStr);
		} catch (Exception e) {
			this.ovrCallCnt = 0;
		}
	}
	public int getIcallTcTms() {
		return icallTcTms;
	}
	public void setIcallTcTms(int icallTcTms) {
		this.icallTcTms = icallTcTms;
	}
	public void setIcallTcTms(String icallTcTms) {
		try {
			this.icallTcTms = Integer.parseInt(icallTcTms);
		} catch (Exception e) {
			this.icallTcTms = 0;
		}
	}
	public int getOcallTcTms() {
		return ocallTcTms;
	}
	public void setOcallTcTms(int ocallTcTms) {
		this.ocallTcTms = ocallTcTms;
	}
	public void setOcallTcTms(String ocallTcTms) {
		try {
			this.ocallTcTms = Integer.parseInt(ocallTcTms);
		} catch (Exception e) {
			this.ocallTcTms = 0;
		}
	}
	public int getTcTms() {
		return tcTms;
	}
	public void setTcTms(int tcTms) {
		this.tcTms = tcTms;
	}
	public int getOcallNumTmTryCallCnt() {
		return ocallNumTmTryCallCnt;
	}
	public void setOcallNumTmTryCallCnt(int ocallNumTmTryCallCnt) {
		this.ocallNumTmTryCallCnt = ocallNumTmTryCallCnt;
	}
	public void setOcallNumTmTryCallCnt(String ocallNumTmTryCallCntStr) {
		try {
			this.ocallNumTmTryCallCnt = Integer.parseInt(ocallNumTmTryCallCntStr);
		} catch (Exception e) {
			this.ocallNumTmTryCallCnt = 0;
		}
	}
	public int getOcallNumTmFnshCallCnt() {
		return ocallNumTmFnshCallCnt;
	}
	public void setOcallNumTmFnshCallCnt(int ocallNumTmFnshCallCnt) {
		this.ocallNumTmFnshCallCnt = ocallNumTmFnshCallCnt;
	}
	public void setOcallNumTmFnshCallCnt(String ocallNumTmFnshCallCntStr) {
		try {
			this.ocallNumTmFnshCallCnt = Integer.parseInt(ocallNumTmFnshCallCntStr);
		} catch (Exception e) {
			this.ocallNumTmFnshCallCnt = 0;
		}
	}
	public int getOcallNumTmTcTms() {
		return ocallNumTmTcTms;
	}
	public void setOcallNumTmTcTms(int ocallNumTmTcTms) {
		this.ocallNumTmTcTms = ocallNumTmTcTms;
	}
	public void setOcallNumTmTcTms(String ocallNumTmTcTms) {
		try {
			this.ocallNumTmTcTms = Integer.parseInt(ocallNumTmTcTms);
		} catch (Exception e) {
			this.ocallNumTmTcTms = 0;
		}
	}
	public int getIcallNumTmTryCallCnt() {
		return icallNumTmTryCallCnt;
	}
	public void setIcallNumTmTryCallCnt(int icallNumTmTryCallCnt) {
		this.icallNumTmTryCallCnt = icallNumTmTryCallCnt;
	}
	public void setIcallNumTmTryCallCnt(String icallNumTmTryCallCntStr) {
		try {
			this.icallNumTmTryCallCnt = Integer.parseInt(icallNumTmTryCallCntStr);
		} catch (Exception e) {
			this.icallNumTmTryCallCnt = 0;
		}
	}
	public int getIcallNumTmFnshCallCnt() {
		return icallNumTmFnshCallCnt;
	}
	public void setIcallNumTmFnshCallCnt(int icallNumTmFnshCallCnt) {
		this.icallNumTmFnshCallCnt = icallNumTmFnshCallCnt;
	}
	public void setIcallNumTmFnshCallCnt(String icallNumTmFnshCallCnt) {
		try {
			this.icallNumTmFnshCallCnt = Integer.parseInt(icallNumTmFnshCallCnt);
		} catch (Exception e) {
			this.icallNumTmFnshCallCnt = 0;
		}
	}
	public int getIcallNumTmTcTms() {
		return icallNumTmTcTms;
	}
	public void setIcallNumTmTcTms(int icallNumTmTcTms) {
		this.icallNumTmTcTms = icallNumTmTcTms;
	}
	public void setIcallNumTmTcTms(String icallNumTmTcTms) {
		try {
			this.icallNumTmTcTms = Integer.parseInt(icallNumTmTcTms);
		} catch (Exception e) {
			this.icallNumTmTcTms = 0;
		}
	}
	public double getAvgRsvTms() {
		return avgRsvTms;
	}
	public void setAvgRsvTms(double avgRsvTms) {
		this.avgRsvTms = avgRsvTms;
	}
	public void setAvgRsvTms(String avgRsvTmsStr) {
		try {
			this.avgRsvTms = Double.parseDouble(avgRsvTmsStr);
		} catch (Exception e) {
			this.avgRsvTms = 0;
		}
	}
	public double getErlangVal() {
		return erlangVal;
	}
	public void setErlangVal(double erlangVal) {
		this.erlangVal = erlangVal;
	}
	public void setErlangVal(String erlangValStr) {
		try {
			this.erlangVal = Double.parseDouble(erlangValStr);
		} catch (Exception e) {
			this.erlangVal = 0;
		}
	}
	public int getScrbrErrCnt() {
		return scrbrErrCnt;
	}
	public void setScrbrErrCnt(int scrbrErrCnt) {
		this.scrbrErrCnt = scrbrErrCnt;
	}
	public void setScrbrErrCnt(String scrbrErrCntStr) {
		try {
			this.scrbrErrCnt = Integer.parseInt(scrbrErrCntStr);
		} catch (Exception e) {
			this.scrbrErrCnt = 0;
		}
	}
	public int getSysErrCnt() {
		return sysErrCnt;
	}
	public void setSysErrCnt(int sysErrCnt) {
		this.sysErrCnt = sysErrCnt;
	}
	public void setSysErrCnt(String sysErrCntStr) {
		try {
			this.sysErrCnt = Integer.parseInt(sysErrCntStr);
		} catch (Exception e) {
			this.sysErrCnt = 0;
		}
	}
	public int getNwErrCnt() {
		return nwErrCnt;
	}
	public void setNwErrCnt(int nwErrCnt) {
		this.nwErrCnt = nwErrCnt;
	}
	public void setNwErrCnt(String nwErrCntStr) {
		try {
			this.nwErrCnt = Integer.parseInt(nwErrCntStr);
		} catch (Exception e) {
			this.nwErrCnt = 0;
		}
	}
	public int getSvcErrCnt() {
		return svcErrCnt;
	}
	public void setSvcErrCnt(int svcErrCnt) {
		this.svcErrCnt = svcErrCnt;
	}
	public void setSvcErrCnt(String svcErrCntStr) {
		try {
			this.svcErrCnt = Integer.parseInt(svcErrCntStr);
		} catch (Exception e) {
			this.svcErrCnt = 0;
		}
	}
	public int getRoutErrCnt() {
		return routErrCnt;
	}
	public void setRoutErrCnt(int routErrCnt) {
		this.routErrCnt = routErrCnt;
	}
	public void setRoutErrCnt(String routErrCnt) {
		try {
			this.routErrCnt = Integer.parseInt(routErrCnt);
		} catch (Exception e) {
			this.routErrCnt = 0;
		}
	}
	public int getNumConvErrCnt() {
		return numConvErrCnt;
	}
	public void setNumConvErrCnt(int numConvErrCnt) {
		this.numConvErrCnt = numConvErrCnt;
	}
	public void setNumConvErrCnt(String numConvErrCnt) {
		try {
			this.numConvErrCnt = Integer.parseInt(numConvErrCnt);
		} catch (Exception e) {
			this.numConvErrCnt = 0;
		}
	}
	public int getTrunkErrCnt() {
		return trunkErrCnt;
	}
	public void setTrunkErrCnt(int trunkErrCnt) {
		this.trunkErrCnt = trunkErrCnt;
	}
	public void setTrunkErrCnt(String trunkErrCnt) {
		try {
			this.trunkErrCnt = Integer.parseInt(trunkErrCnt);
		} catch (Exception e) {
			this.trunkErrCnt = 0;
		}
	}
	public int getNcmplCallCnt() {
		return ncmplCallCnt;
	}
	public void setNcmplCallCnt(int ncmplCallCnt) {
		this.ncmplCallCnt = ncmplCallCnt;
	}
	public int getEtcNcmplCallCnt() {
		return etcNcmplCallCnt;
	}
	public void setEtcNcmplCallCnt(int etcNcmplCallCnt) {
		this.etcNcmplCallCnt = etcNcmplCallCnt;
	}
	public void setEtcNcmplCallCnt(String etcNcmplCallCnt) {
		try {
			this.etcNcmplCallCnt = Integer.parseInt(etcNcmplCallCnt);
		} catch (Exception e) {
			this.etcNcmplCallCnt = 0;
		}
	}
	public int getScrbrCnt() {
		return scrbrCnt;
	}
	public void setScrbrCnt(int scrbrCnt) {
		this.scrbrCnt = scrbrCnt;
	}
	public int getTrunkCnt() {
		return trunkCnt;
	}
	public void setTrunkCnt(int trunkCnt) {
		this.trunkCnt = trunkCnt;
	}
	public void setTrunkCnt(String trunkCntStr) {
		try {
			this.trunkCnt = Integer.parseInt(trunkCntStr);
		} catch (Exception e) {
			this.trunkCnt = 0;
		}
	}
	public int getEquipLinkCnt() {
		return equipLinkCnt;
	}
	public void setEquipLinkCnt(int equipLinkCnt) {
		this.equipLinkCnt = equipLinkCnt;
	}
	public int getTrnkCngsCnt() {
		return trnkCngsCnt;
	}
	public void setTrnkCngsCnt(int trnkCngsCnt) {
		this.trnkCngsCnt = trnkCngsCnt;
	}
	public int getMscCngsCnt() {
		return mscCngsCnt;
	}
	public void setMscCngsCnt(int mscCngsCnt) {
		this.mscCngsCnt = mscCngsCnt;
	}
	public int getDirRoutPossCallCnt() {
		return dirRoutPossCallCnt;
	}
	public void setDirRoutPossCallCnt(int dirRoutPossCallCnt) {
		this.dirRoutPossCallCnt = dirRoutPossCallCnt;
	}
	public int getAltRoutPossCallCnt() {
		return altRoutPossCallCnt;
	}
	public void setAltRoutPossCallCnt(int altRoutPossCallCnt) {
		this.altRoutPossCallCnt = altRoutPossCallCnt;
	}
	public int getRpsBfGvupCallCnt() {
		return rpsBfGvupCallCnt;
	}
	public void setRpsBfGvupCallCnt(int rpsBfGvupCallCnt) {
		this.rpsBfGvupCallCnt = rpsBfGvupCallCnt;
	}
	public int getAdiCnt() {
		return adiCnt;
	}
	public void setAdiCnt(int adiCnt) {
		this.adiCnt = adiCnt;
	}
	public int getIcallScrbrLineBusyCnt() {
		return icallScrbrLineBusyCnt;
	}
	public void setIcallScrbrLineBusyCnt(int icallScrbrLineBusyCnt) {
		this.icallScrbrLineBusyCnt = icallScrbrLineBusyCnt;
	}
	public int getDialingGvupCnt() {
		return dialingGvupCnt;
	}
	public void setDialingGvupCnt(int dialingGvupCnt) {
		this.dialingGvupCnt = dialingGvupCnt;
	}
	public int getSgnlOpErrCnt() {
		return sgnlOpErrCnt;
	}
	public void setSgnlOpErrCnt(int sgnlOpErrCnt) {
		this.sgnlOpErrCnt = sgnlOpErrCnt;
	}
	public int getOutTrnkDablCnt() {
		return outTrnkDablCnt;
	}
	public void setOutTrnkDablCnt(int outTrnkDablCnt) {
		this.outTrnkDablCnt = outTrnkDablCnt;
	}
	public int getFblkCnt() {
		return fblkCnt;
	}
	public void setFblkCnt(int fblkCnt) {
		this.fblkCnt = fblkCnt;
	}
	public int getMblkCnt() {
		return mblkCnt;
	}
	public void setMblkCnt(int mblkCnt) {
		this.mblkCnt = mblkCnt;
	}
	public int getSblkCnt() {
		return sblkCnt;
	}
	public void setSblkCnt(int sblkCnt) {
		this.sblkCnt = sblkCnt;
	}
	public int getCardSpratCnt() {
		return cardSpratCnt;
	}
	public void setCardSpratCnt(int cardSpratCnt) {
		this.cardSpratCnt = cardSpratCnt;
	}
	public int getNyOccrDcOccrCnt() {
		return nyOccrDcOccrCnt;
	}
	public void setNyOccrDcOccrCnt(int nyOccrDcOccrCnt) {
		this.nyOccrDcOccrCnt = nyOccrDcOccrCnt;
	}
	public void setNyOccrDcOccrCnt(String nyOccrDcOccrCntStr) {
		try {
			this.nyOccrDcOccrCnt = Integer.parseInt(nyOccrDcOccrCntStr);
		} catch (Exception e) {
			this.nyOccrDcOccrCnt = 0;
		}
	}
	public int getFnshRtDcOccrCnt() {
		return fnshRtDcOccrCnt;
	}
	public void setFnshRtDcOccrCnt(int fnshRtDcOccrCnt) {
		this.fnshRtDcOccrCnt = fnshRtDcOccrCnt;
	}
	public void setFnshRtDcOccrCnt(String fnshRtDcOccrCntStr) {
		try {
			this.fnshRtDcOccrCnt = Integer.parseInt(fnshRtDcOccrCntStr);
		} catch (Exception e) {
			this.fnshRtDcOccrCnt = 0;
		}
	}
	public int getOosRtDcOccrCnt() {
		return oosRtDcOccrCnt;
	}
	public void setOosRtDcOccrCnt(int oosRtDcOccrCnt) {
		this.oosRtDcOccrCnt = oosRtDcOccrCnt;
	}
	public void setOosRtDcOccrCnt(String oosRtDcOccrCntStr) {
		try {
			this.oosRtDcOccrCnt = Integer.parseInt(oosRtDcOccrCntStr);
		} catch (Exception e) {
			this.oosRtDcOccrCnt = 0;
		}
	}
	public int getOvrCallRtDcOccrCnt() {
		return ovrCallRtDcOccrCnt;
	}
	public void setOvrCallRtDcOccrCnt(int ovrCallRtDcOccrCnt) {
		this.ovrCallRtDcOccrCnt = ovrCallRtDcOccrCnt;
	}
	public void setOvrCallRtDcOccrCnt(String ovrCallRtDcOccrCntStr) {
		try {
			this.ovrCallRtDcOccrCnt = Integer.parseInt(ovrCallRtDcOccrCntStr);
		} catch (Exception e) {
			this.ovrCallRtDcOccrCnt = 0;
		}
	}
	public int getExfluRtDcOccrCnt() {
		return exfluRtDcOccrCnt;
	}
	public void setExfluRtDcOccrCnt(int exfluRtDcOccrCnt) {
		this.exfluRtDcOccrCnt = exfluRtDcOccrCnt;
	}
	public void setExfluRtDcOccrCnt(String exfluRtDcOccrCntStr) {
		try {
			this.exfluRtDcOccrCnt = Integer.parseInt(exfluRtDcOccrCntStr);
		} catch (Exception e) {
			this.exfluRtDcOccrCnt = 0;
		}
	}
	public int getIcallFnshRtDcOccrCnt() {
		return icallFnshRtDcOccrCnt;
	}
	public void setIcallFnshRtDcOccrCnt(int icallFnshRtDcOccrCnt) {
		this.icallFnshRtDcOccrCnt = icallFnshRtDcOccrCnt;
	}
	public void setIcallFnshRtDcOccrCnt(String icallFnshRtDcOccrCntStr) {
		try {
			this.icallFnshRtDcOccrCnt = Integer.parseInt(icallFnshRtDcOccrCntStr);
		} catch (Exception e) {
			this.icallFnshRtDcOccrCnt = 0;
		}
	}
	public int getOcallFnshRtDcOccrCnt() {
		return ocallFnshRtDcOccrCnt;
	}
	public void setOcallFnshRtDcOccrCnt(int ocallFnshRtDcOccrCnt) {
		this.ocallFnshRtDcOccrCnt = ocallFnshRtDcOccrCnt;
	}
	public void setOcallFnshRtDcOccrCnt(String ocallFnshRtDcOccrCntStr) {
		try {
			this.ocallFnshRtDcOccrCnt = Integer.parseInt(ocallFnshRtDcOccrCntStr);
		} catch (Exception e) {
			this.ocallFnshRtDcOccrCnt = 0;
		}
	}
	public int getItCallExfluDcOccrCnt() {
		return itCallExfluDcOccrCnt;
	}
	public void setItCallExfluDcOccrCnt(int itCallExfluDcOccrCnt) {
		this.itCallExfluDcOccrCnt = itCallExfluDcOccrCnt;
	}
	public void setItCallExfluDcOccrCnt(String itCallExfluDcOccrCntStr) {
		try {
			this.itCallExfluDcOccrCnt = Integer.parseInt(itCallExfluDcOccrCntStr);
		} catch (Exception e) {
			this.itCallExfluDcOccrCnt = 0;
		}
	}
	public int getOtCallExfluRtDcOccrCnt() {
		return otCallExfluRtDcOccrCnt;
	}
	public void setOtCallExfluRtDcOccrCnt(int otCallExfluRtDcOccrCnt) {
		this.otCallExfluRtDcOccrCnt = otCallExfluRtDcOccrCnt;
	}
	public void setOtCallExfluRtDcOccrCnt(String otCallExfluRtDcOccrCntStr) {
		try {
			this.otCallExfluRtDcOccrCnt = Integer.parseInt(otCallExfluRtDcOccrCntStr);
		} catch (Exception e) {
			this.otCallExfluRtDcOccrCnt = 0;
		}
	}
	public int getLineUseRtDcOccrCnt() {
		return lineUseRtDcOccrCnt;
	}
	public void setLineUseRtDcOccrCnt(int lineUseRtDcOccrCnt) {
		this.lineUseRtDcOccrCnt = lineUseRtDcOccrCnt;
	}
	public void setLineUseRtDcOccrCnt(String lineUseRtDcOccrCntStr) {
		try {
			this.lineUseRtDcOccrCnt = Integer.parseInt(lineUseRtDcOccrCntStr);
		} catch (Exception e) {
			this.lineUseRtDcOccrCnt = 0;
		}
	}
	public int getAllTryCallExfluRt() {
		return allTryCallExfluRt;
	}
	public void setAllTryCallExfluRt(int allTryCallExfluRt) {
		this.allTryCallExfluRt = allTryCallExfluRt;
	}
	public void setAllTryCallExfluRt(String allTryCallExfluRtStr) {
		try {
			this.allTryCallExfluRt = Integer.parseInt(allTryCallExfluRtStr);
		} catch (Exception e) {
			this.allTryCallExfluRt = 0;
		}
	}
	public int getItCallExfluRt() {
		return itCallExfluRt;
	}
	public void setItCallExfluRt(int itCallExfluRt) {
		this.itCallExfluRt = itCallExfluRt;
	}
	public void setItCallExfluRt(String itCallExfluRtStr) {
		try {
			this.itCallExfluRt = Integer.parseInt(itCallExfluRtStr);
		} catch (Exception e) {
			this.itCallExfluRt = 0;
		}
	}
	public int getOtCallExfluRt() {
		return otCallExfluRt;
	}
	public void setOtCallExfluRt(int otCallExfluRt) {
		this.otCallExfluRt = otCallExfluRt;
	}
	public void setOtCallExfluRt(String otCallExfluRtStr) {
		try {
			this.otCallExfluRt = Integer.parseInt(otCallExfluRtStr);
		} catch (Exception e) {
			this.otCallExfluRt = 0;
		}
	}
	public int getTryCallDcOccrCnt() {
		return tryCallDcOccrCnt;
	}
	public void setTryCallDcOccrCnt(int tryCallDcOccrCnt) {
		this.tryCallDcOccrCnt = tryCallDcOccrCnt;
	}
	public void setTryCallDcOccrCnt(String tryCallDcOccrCntStr) {
		try {
			this.tryCallDcOccrCnt = Integer.parseInt(tryCallDcOccrCntStr);
		} catch (Exception e) {
			this.tryCallDcOccrCnt = 0;
		}
	}
	public String getSupEquipId() {
		return supEquipId;
	}
	public void setSupEquipId(String supEquipId) {
		this.supEquipId = supEquipId;
	}
	public String getVipCustYn() {
		return vipCustYn;
	}
	public void setVipCustYn(String vipCustYn) {
		this.vipCustYn = vipCustYn;
	}
	public String getExgNumClCd() {
		return exgNumClCd;
	}
	public void setExgNumClCd(String exgNumClCd) {
		this.exgNumClCd = exgNumClCd;
	}
	public int getJitrAvgVal() {
		return jitrAvgVal;
	}
	public void setJitrAvgVal(int jitrAvgVal) {
		this.jitrAvgVal = jitrAvgVal;
	}
	public int getDlayAvgVal() {
		return dlayAvgVal;
	}
	public void setDlayAvgVal(int dlayAvgVal) {
		this.dlayAvgVal = dlayAvgVal;
	}
	public int getLossAvgVal() {
		return lossAvgVal;
	}
	public void setLossAvgVal(int lossAvgVal) {
		this.lossAvgVal = lossAvgVal;
	}
	public int getrTotVal() {
		return rTotVal;
	}
	public void setrTotVal(int rTotVal) {
		this.rTotVal = rTotVal;
	}
	public int getrCallCnt() {
		return rCallCnt;
	}
	public void setrCallCnt(int rCallCnt) {
		this.rCallCnt = rCallCnt;
	}
	public int getrAvgVal() {
		return rAvgVal;
	}
	public void setrAvgVal(int rAvgVal) {
		this.rAvgVal = rAvgVal;
	}
	public int getMosTotVal() {
		return mosTotVal;
	}
	public void setMosTotVal(int mosTotVal) {
		this.mosTotVal = mosTotVal;
	}
	public int getMosAvgVal() {
		return mosAvgVal;
	}
	public void setMosAvgVal(int mosAvgVal) {
		this.mosAvgVal = mosAvgVal;
	}
	public int getTestOtCallCnt() {
		return testOtCallCnt;
	}
	public void setTestOtCallCnt(int testOtCallCnt) {
		this.testOtCallCnt = testOtCallCnt;
	}
	public void setTestOtCallCnt(String testOtCallCnt) {
		try {
			this.testOtCallCnt = Integer.parseInt(testOtCallCnt);
		} catch (Exception e) {
			this.testOtCallCnt = 0;
		}
	}
	public int getTestOcallFnshCallCnt() {
		return testOcallFnshCallCnt;
	}
	public void setTestOcallFnshCallCnt(int testOcallFnshCallCnt) {
		this.testOcallFnshCallCnt = testOcallFnshCallCnt;
	}
	public void setTestOcallFnshCallCnt(String testOcallFnshCallCnt) {
		try {
			this.testOcallFnshCallCnt = Integer.parseInt(testOcallFnshCallCnt);
		} catch (Exception e) {
			this.testOcallFnshCallCnt = 0;
		}
	}
	public int getTestOcallTcTms() {
		return testOcallTcTms;
	}
	public void setTestOcallTcTms(int testOcallTcTms) {
		this.testOcallTcTms = testOcallTcTms;
	}
	public void setTestOcallTcTms(String testOcallTcTms) {
		try {
			this.testOcallTcTms = Integer.parseInt(testOcallTcTms);
		} catch (Exception e) {
			this.testOcallTcTms = 0;
		}
	}
	public int getTestItCallCnt() {
		return testItCallCnt;
	}
	public void setTestItCallCnt(int testItCallCnt) {
		this.testItCallCnt = testItCallCnt;
	}
	public void setTestItCallCnt(String testItCallCnt) {
		try {
			this.testItCallCnt = Integer.parseInt(testItCallCnt);
		} catch (Exception e) {
			this.testItCallCnt = 0;
		}
	}
	public int getTestIcallFnshCallCnt() {
		return testIcallFnshCallCnt;
	}
	public void setTestIcallFnshCallCnt(int testIcallFnshCallCnt) {
		this.testIcallFnshCallCnt = testIcallFnshCallCnt;
	}
	public void setTestIcallFnshCallCnt(String testIcallFnshCallCnt) {
		try {
			this.testIcallFnshCallCnt = Integer.parseInt(testIcallFnshCallCnt);
		} catch (Exception e) {
			this.testIcallFnshCallCnt = 0;
		}
	}
	public int getTestIcallTcTms() {
		return testIcallTcTms;
	}
	public void setTestIcallTcTms(int testIcallTcTms) {
		this.testIcallTcTms = testIcallTcTms;
	}
	public void setTestIcallTcTms(String testIcallTcTms) {
		try {
			this.testIcallTcTms = Integer.parseInt(testIcallTcTms);
		} catch (Exception e) {
			this.testIcallTcTms = 0;
		}
	}
}
