package com.skb.adams.fm.model;

public class OMN10223 {
	private	String	userId;
	private	String	wphonThrsId;
	private	int	thrsSerNum;
	private	String	wphonThrsItmId;
	private	String	signVal;
	private	double	mnrgVal;
	private	double	mjrgVal;
	private	double	crtgVal;
	private	String	wphonThrsItmNm;

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getWphonThrsId() {
		return wphonThrsId;
	}
	public void setWphonThrsId(String wphonThrsId) {
		this.wphonThrsId = wphonThrsId;
	}
	public int getThrsSerNum() {
		return thrsSerNum;
	}
	public void setThrsSerNum(int thrsSerNum) {
		this.thrsSerNum = thrsSerNum;
	}
	public String getWphonThrsItmId() {
		return wphonThrsItmId;
	}
	public void setWphonThrsItmId(String wphonThrsItmId) {
		this.wphonThrsItmId = wphonThrsItmId;
	}
	public String getSignVal() {
		return signVal;
	}
	public void setSignVal(String signVal) {
		this.signVal = signVal;
	}
	public double getMnrgVal() {
		return mnrgVal;
	}
	public void setMnrgVal(double mnrgVal) {
		this.mnrgVal = mnrgVal;
	}
	public double getMjrgVal() {
		return mjrgVal;
	}
	public void setMjrgVal(double mjrgVal) {
		this.mjrgVal = mjrgVal;
	}
	public double getCrtgVal() {
		return crtgVal;
	}
	public void setCrtgVal(double crtgVal) {
		this.crtgVal = crtgVal;
	}
	public String getWphonThrsItmNm() {
		return wphonThrsItmNm;
	}
	public void setWphonThrsItmNm(String wphonThrsItmNm) {
		this.wphonThrsItmNm = wphonThrsItmNm;
	}	
}
