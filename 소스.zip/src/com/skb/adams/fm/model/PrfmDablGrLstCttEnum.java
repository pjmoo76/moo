package com.skb.adams.fm.model;

public enum PrfmDablGrLstCttEnum {
	// 루트별&V5.2별 트래픽 장애 : 임계치 체크 항목 : 미발생,시도호(TM제외),완료호(TM제외),완료율(TM제외),OOS율,넘침호율,이용율,과다변동율,TM완료율,전체시도호,전체완료율 - 11개
	// ==> 12/13일 임계치 체크변경(3가지 빠짐) : 미발생,0,0,0,OSS율,넘침호율,이용율,과다변동율,TM완료율,전체시도호,전체완료율
	NY_OCCR_DC_OCCR_CNT(0),	// 미발생
	TMEXL_FNSH_RT(3),		// 완료율(TM제외)
	OOS_RT(4),				// OOS율
	OVR_CALL_RT(5),			// 넘침호율
	USE_RT(6),				// 이용율
	EXFLU_RT(7),			// 과다변동율
	TM_FNSH_RT(8),			// TM완료율
	ALL_TRY_CALL_CNT(9),	// 전체시도호
	ALL_FNSH_RT(10),		// 전체완료율
	COM_S(3),				// VOIP 발신완료율
	OVER_S(4),				// VOIP 발신시도콜과다변동률
	COM_R(8),				// VOIP 착신완료율
	OVER_R(9),				// VOIP 착신시도콜과다변동률
	VOIP_USR_RT(11)			// VOIP 회선이용율
	;
	
	final private int	code;
	PrfmDablGrLstCttEnum(int code) {
		this.code = code;
	}
	public int getCode() {
		return this.code;
	}
}
