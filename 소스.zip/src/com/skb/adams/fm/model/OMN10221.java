package com.skb.adams.fm.model;

public class OMN10221 {
	private	String	wphonThrsId;
	private	String	userId;
	private	int	thrsSerNum;
	private	String	thrsNm;
	private	String	mntrCyclCd;
	private	String	equipId;
	private	String	routNum;
	private	String	routConnDirnCd;
	private	String	connClCd;
	private	String	connBizrId;
	private	String	minTryCallCnt;
	private	String	exfluMinTryCallCnt;
	private	String	exfluTryCallCnt;
	private	int	minTryCallCnt0824;
	private	int	exfluMinTryCallCnt0824;
	private	int	exfluTryCallCnt0824;
	private	int	minTryCallCnt2408;
	private	int	exfluMinTryCallCnt2408;
	private	int	exfluTryCallCnt2408;
	private	String	menuId;

	public String getWphonThrsId() {
		return wphonThrsId;
	}
	public void setWphonThrsId(String wphonThrsId) {
		this.wphonThrsId = wphonThrsId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getThrsSerNum() {
		return thrsSerNum;
	}
	public void setThrsSerNum(int thrsSerNum) {
		this.thrsSerNum = thrsSerNum;
	}
	public String getThrsNm() {
		return thrsNm;
	}
	public void setThrsNm(String thrsNm) {
		this.thrsNm = thrsNm;
	}
	public String getMntrCyclCd() {
		return mntrCyclCd;
	}
	public void setMntrCyclCd(String mntrCyclCd) {
		this.mntrCyclCd = mntrCyclCd;
	}
	public String getEquipId() {
		return equipId;
	}
	public void setEquipId(String equipId) {
		this.equipId = equipId;
	}
	public String getRoutNum() {
		return routNum;
	}
	public void setRoutNum(String routNum) {
		this.routNum = routNum;
	}
	public String getRoutConnDirnCd() {
		return routConnDirnCd;
	}
	public void setRoutConnDirnCd(String routConnDirnCd) {
		this.routConnDirnCd = routConnDirnCd;
	}
	public String getConnClCd() {
		return connClCd;
	}
	public void setConnClCd(String connClCd) {
		this.connClCd = connClCd;
	}
	public String getConnBizrId() {
		return connBizrId;
	}
	public void setConnBizrId(String connBizrId) {
		this.connBizrId = connBizrId;
	}
	public String getMinTryCallCnt() {
		return minTryCallCnt;
	}
	public void setMinTryCallCnt(String minTryCallCnt) {
		this.minTryCallCnt = minTryCallCnt;
	}
	public String getExfluMinTryCallCnt() {
		return exfluMinTryCallCnt;
	}
	public void setExfluMinTryCallCnt(String exfluMinTryCallCnt) {
		this.exfluMinTryCallCnt = exfluMinTryCallCnt;
	}
	public String getExfluTryCallCnt() {
		return exfluTryCallCnt;
	}
	public void setExfluTryCallCnt(String exfluTryCallCnt) {
		this.exfluTryCallCnt = exfluTryCallCnt;
	}
	public int getMinTryCallCnt0824() {
		return minTryCallCnt0824;
	}
	public void setMinTryCallCnt0824(String minTryCallCnt0824) {
		if (minTryCallCnt0824 != null) {
			try {
				this.minTryCallCnt0824 = Integer.parseInt(minTryCallCnt0824);
			} catch (Exception e) {
			}
		}
	}
	public int getExfluMinTryCallCnt0824() {
		return exfluMinTryCallCnt0824;
	}
	public void setExfluMinTryCallCnt0824(String exfluMinTryCallCnt0824) {
		if (exfluMinTryCallCnt0824 != null) {
			try {
				this.exfluMinTryCallCnt0824 = Integer.parseInt(exfluMinTryCallCnt0824);
			} catch (Exception e) {
			}
		}
	}
	public int getExfluTryCallCnt0824() {
		return exfluTryCallCnt0824;
	}
	public void setExfluTryCallCnt0824(String exfluTryCallCnt0824) {
		if (exfluTryCallCnt0824 != null) {
			try {
				this.exfluTryCallCnt0824 = Integer.parseInt(exfluTryCallCnt0824);
			} catch (Exception e) {
			}
		}
	}
	public int getMinTryCallCnt2408() {
		return minTryCallCnt2408;
	}
	public void setMinTryCallCnt2408(String minTryCallCnt2408) {
		if (minTryCallCnt2408 != null) {
			try {
				this.minTryCallCnt2408 = Integer.parseInt(minTryCallCnt2408);
			} catch (Exception e) {
			}
		}
	}
	public int getExfluMinTryCallCnt2408() {
		return exfluMinTryCallCnt2408;
	}
	public void setExfluMinTryCallCnt2408(String exfluMinTryCallCnt2408) {
		if (exfluMinTryCallCnt2408 != null) {
			try {
				this.exfluMinTryCallCnt2408 = Integer.parseInt(exfluMinTryCallCnt2408);
			} catch (Exception e) {
			}
		}
	}
	public int getExfluTryCallCnt2408() {
		return exfluTryCallCnt2408;
	}
	public void setExfluTryCallCnt2408(String exfluTryCallCnt2408) {
		if (exfluTryCallCnt2408 != null) {
			try {
				this.exfluMinTryCallCnt2408 = Integer.parseInt(exfluTryCallCnt2408);
			} catch (Exception e) {
			}
		}
	}
	public String getMenuId() {
		return menuId;
	}
	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}
}
