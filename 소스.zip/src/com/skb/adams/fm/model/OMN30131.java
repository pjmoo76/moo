package com.skb.adams.fm.model;

public class OMN30131 {
	public	int	dablNum;
	public	String	auditId;
	public	String	auditDtm;
	public	String	equipId;
	public	String	mntrCyclCd;
	public	String	dablLclCd;
	public	String	dablMclCd;
	public	String	dablCd;
	public	String	dablGrCd;
	public	String	infoCntrCd;
	public	String	distbCntrCd;
	public	String	occrDtm;
	public	String	occrRcvDtm;
	public	String	rlseDtm;
	public	String	rlseRcvDtm;
	public	String	dablRlseMthdCd;
	public	String	dablRlseRsnCtt;
	public	String	dablRlsrId;
	public	String	dablCheckYn;
	public	String	dablChkrId;
	public	String	dablCheckDtm;
	public	String	dablOccrLocDesc;
	public	int	keepTms;
	public	String	netClCd;
	public	String	dablDesc;
	public	String	routNum;
	public	String	routUsgCtt;
	public	String	assaspNum;
	public	String	bizrClCd;
	public	String	incommBizrNm;
	public	String	doexgMscNm;
	public	String	routConnDirnCd;
	public	String	routConnTypCd;
	public	String	connBizrNm;
	public	String	connCustNm;
	public	String	tmClCd;
	public	int	mntrNum;
	public	String	dataSrcClCd;
	public	String	connClCd;
	public	String	prfmDablGrLstCtt;
	public	int	nyOccrDcOccrCnt;
	public	int	tmexlTryCallCnt;
	public	int	tmexlFnshCallCnt;
	public	double	tmexlFnshRt;
	public	int	tmexlOcallRlayTryCallCnt;
	public	int	tmexlOcallRlayFnshCallCnt;
	public	double	tmexlOcallRlayFnshRt;
	public	double	tmexlOcallRlayExfluRt;
	public	int	tmexlRcvRlayTryCallCnt;
	public	int	tmexlRcvRlayFnshCallCnt;
	public	double	tmexlRcvRlayFnshRt;
	public	double	tmexlRcvRlayExfluRt;
	public	int	otCallCnt;
	public	int	ocallFnshCallCnt;
	public	double	ocallFnshRt;
	public	double	otCallExfluRt;
	public	double	ocallTmFnshRt;
	public	int	itCallCnt;
	public	int	icallFnshCallCnt;
	public	double	icallFnshRt;
	public	double	itCallExfluRt;
	public	double	icallTmFnshRt;
	public	int	mounLineCnt;
	public	double	oosRt;
	public	int	oosRtDcOccrCnt;
	public	double	ovrCallRt;
	public	int	ovrCallRtDcOccrCnt;
	public	double	lineUseRt;
	public	int	lineUseRtDcOccrCnt;
	public	double	exfluRt;
	public	double	tmFnshRt;
	public	int	tmTryCallCnt;
	public	int	tmFnshCallCnt;
	public	int	allTryCallCnt;
	public	int	tryCallDcOccrCnt;
	public	double	allFnshRt;
	public	int	fnshRtDcOccrCnt;
	public	String	audblExlTm;
	public	int	doexgBizrId;
	public	String	exchgEquipClCd;
	public	String	dablCdLstCtt;

	public int getDablNum() {
		return dablNum;
	}
	public void setDablNum(int dablNum) {
		this.dablNum = dablNum;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getEquipId() {
		return equipId;
	}
	public void setEquipId(String equipId) {
		this.equipId = equipId;
	}
	public String getMntrCyclCd() {
		return mntrCyclCd;
	}
	public void setMntrCyclCd(String mntrCyclCd) {
		this.mntrCyclCd = mntrCyclCd;
	}
	public String getDablLclCd() {
		return dablLclCd;
	}
	public void setDablLclCd(String dablLclCd) {
		this.dablLclCd = dablLclCd;
	}
	public String getDablMclCd() {
		return dablMclCd;
	}
	public void setDablMclCd(String dablMclCd) {
		this.dablMclCd = dablMclCd;
	}
	public String getDablCd() {
		return dablCd;
	}
	public void setDablCd(String dablCd) {
		this.dablCd = dablCd;
	}
	public String getDablGrCd() {
		return dablGrCd;
	}
	public void setDablGrCd(String dablGrCd) {
		this.dablGrCd = dablGrCd;
	}
	public String getInfoCntrCd() {
		return infoCntrCd;
	}
	public void setInfoCntrCd(String infoCntrCd) {
		this.infoCntrCd = infoCntrCd;
	}
	public String getDistbCntrCd() {
		return distbCntrCd;
	}
	public void setDistbCntrCd(String distbCntrCd) {
		this.distbCntrCd = distbCntrCd;
	}
	public String getOccrDtm() {
		return occrDtm;
	}
	public void setOccrDtm(String occrDtm) {
		this.occrDtm = occrDtm;
	}
	public String getOccrRcvDtm() {
		return occrRcvDtm;
	}
	public void setOccrRcvDtm(String occrRcvDtm) {
		this.occrRcvDtm = occrRcvDtm;
	}
	public String getRlseDtm() {
		return rlseDtm;
	}
	public void setRlseDtm(String rlseDtm) {
		this.rlseDtm = rlseDtm;
	}
	public String getRlseRcvDtm() {
		return rlseRcvDtm;
	}
	public void setRlseRcvDtm(String rlseRcvDtm) {
		this.rlseRcvDtm = rlseRcvDtm;
	}
	public String getDablRlseMthdCd() {
		return dablRlseMthdCd;
	}
	public void setDablRlseMthdCd(String dablRlseMthdCd) {
		this.dablRlseMthdCd = dablRlseMthdCd;
	}
	public String getDablRlseRsnCtt() {
		return dablRlseRsnCtt;
	}
	public void setDablRlseRsnCtt(String dablRlseRsnCtt) {
		this.dablRlseRsnCtt = dablRlseRsnCtt;
	}
	public String getDablRlsrId() {
		return dablRlsrId;
	}
	public void setDablRlsrId(String dablRlsrId) {
		this.dablRlsrId = dablRlsrId;
	}
	public String getDablCheckYn() {
		return dablCheckYn;
	}
	public void setDablCheckYn(String dablCheckYn) {
		this.dablCheckYn = dablCheckYn;
	}
	public String getDablChkrId() {
		return dablChkrId;
	}
	public void setDablChkrId(String dablChkrId) {
		this.dablChkrId = dablChkrId;
	}
	public String getDablCheckDtm() {
		return dablCheckDtm;
	}
	public void setDablCheckDtm(String dablCheckDtm) {
		this.dablCheckDtm = dablCheckDtm;
	}
	public String getDablOccrLocDesc() {
		return dablOccrLocDesc;
	}
	public void setDablOccrLocDesc(String dablOccrLocDesc) {
		this.dablOccrLocDesc = dablOccrLocDesc;
	}
	public int getKeepTms() {
		return keepTms;
	}
	public void setKeepTms(int keepTms) {
		this.keepTms = keepTms;
	}
	public String getNetClCd() {
		return netClCd;
	}
	public void setNetClCd(String netClCd) {
		this.netClCd = netClCd;
	}
	public String getDablDesc() {
		return dablDesc;
	}
	public void setDablDesc(String dablDesc) {
		this.dablDesc = dablDesc;
	}
	public String getRoutNum() {
		return routNum;
	}
	public void setRoutNum(String routNum) {
		this.routNum = routNum;
	}
	public String getRoutUsgCtt() {
		return routUsgCtt;
	}
	public void setRoutUsgCtt(String routUsgCtt) {
		this.routUsgCtt = routUsgCtt;
	}
	public String getAssaspNum() {
		return assaspNum;
	}
	public void setAssaspNum(String assaspNum) {
		this.assaspNum = assaspNum;
	}
	public String getBizrClCd() {
		return bizrClCd;
	}
	public void setBizrClCd(String bizrClCd) {
		this.bizrClCd = bizrClCd;
	}
	public String getIncommBizrNm() {
		return incommBizrNm;
	}
	public void setIncommBizrNm(String incommBizrNm) {
		this.incommBizrNm = incommBizrNm;
	}
	public String getDoexgMscNm() {
		return doexgMscNm;
	}
	public void setDoexgMscNm(String doexgMscNm) {
		this.doexgMscNm = doexgMscNm;
	}
	public String getRoutConnDirnCd() {
		return routConnDirnCd;
	}
	public void setRoutConnDirnCd(String routConnDirnCd) {
		this.routConnDirnCd = routConnDirnCd;
	}
	public String getRoutConnTypCd() {
		return routConnTypCd;
	}
	public void setRoutConnTypCd(String routConnTypCd) {
		this.routConnTypCd = routConnTypCd;
	}
	public String getConnBizrNm() {
		return connBizrNm;
	}
	public void setConnBizrNm(String connBizrNm) {
		this.connBizrNm = connBizrNm;
	}
	public String getConnCustNm() {
		return connCustNm;
	}
	public void setConnCustNm(String connCustNm) {
		this.connCustNm = connCustNm;
	}
	public String getTmClCd() {
		return tmClCd;
	}
	public void setTmClCd(String tmClCd) {
		this.tmClCd = tmClCd;
	}
	public int getMntrNum() {
		return mntrNum;
	}
	public void setMntrNum(int mntrNum) {
		this.mntrNum = mntrNum;
	}
	public String getDataSrcClCd() {
		return dataSrcClCd;
	}
	public void setDataSrcClCd(String dataSrcClCd) {
		this.dataSrcClCd = dataSrcClCd;
	}
	public String getConnClCd() {
		return connClCd;
	}
	public void setConnClCd(String connClCd) {
		this.connClCd = connClCd;
	}
	public String getPrfmDablGrLstCtt() {
		return prfmDablGrLstCtt;
	}
	public void setPrfmDablGrLstCtt(String prfmDablGrLstCtt) {
		this.prfmDablGrLstCtt = prfmDablGrLstCtt;
	}
	public int getNyOccrDcOccrCnt() {
		return nyOccrDcOccrCnt;
	}
	public void setNyOccrDcOccrCnt(int nyOccrDcOccrCnt) {
		this.nyOccrDcOccrCnt = nyOccrDcOccrCnt;
	}
	public int getTmexlTryCallCnt() {
		return tmexlTryCallCnt;
	}
	public void setTmexlTryCallCnt(int tmexlTryCallCnt) {
		this.tmexlTryCallCnt = tmexlTryCallCnt;
	}
	public int getTmexlFnshCallCnt() {
		return tmexlFnshCallCnt;
	}
	public void setTmexlFnshCallCnt(int tmexlFnshCallCnt) {
		this.tmexlFnshCallCnt = tmexlFnshCallCnt;
	}
	public double getTmexlFnshRt() {
		return tmexlFnshRt;
	}
	public void setTmexlFnshRt(double tmexlFnshRt) {
		this.tmexlFnshRt = tmexlFnshRt;
	}
	public int getTmexlOcallRlayTryCallCnt() {
		return tmexlOcallRlayTryCallCnt;
	}
	public void setTmexlOcallRlayTryCallCnt(int tmexlOcallRlayTryCallCnt) {
		this.tmexlOcallRlayTryCallCnt = tmexlOcallRlayTryCallCnt;
	}
	public int getTmexlOcallRlayFnshCallCnt() {
		return tmexlOcallRlayFnshCallCnt;
	}
	public void setTmexlOcallRlayFnshCallCnt(int tmexlOcallRlayFnshCallCnt) {
		this.tmexlOcallRlayFnshCallCnt = tmexlOcallRlayFnshCallCnt;
	}
	public double getTmexlOcallRlayFnshRt() {
		return tmexlOcallRlayFnshRt;
	}
	public void setTmexlOcallRlayFnshRt(double tmexlOcallRlayFnshRt) {
		this.tmexlOcallRlayFnshRt = tmexlOcallRlayFnshRt;
	}
	public double getTmexlOcallRlayExfluRt() {
		return tmexlOcallRlayExfluRt;
	}
	public void setTmexlOcallRlayExfluRt(double tmexlOcallRlayExfluRt) {
		this.tmexlOcallRlayExfluRt = tmexlOcallRlayExfluRt;
	}
	public int getTmexlRcvRlayTryCallCnt() {
		return tmexlRcvRlayTryCallCnt;
	}
	public void setTmexlRcvRlayTryCallCnt(int tmexlRcvRlayTryCallCnt) {
		this.tmexlRcvRlayTryCallCnt = tmexlRcvRlayTryCallCnt;
	}
	public int getTmexlRcvRlayFnshCallCnt() {
		return tmexlRcvRlayFnshCallCnt;
	}
	public void setTmexlRcvRlayFnshCallCnt(int tmexlRcvRlayFnshCallCnt) {
		this.tmexlRcvRlayFnshCallCnt = tmexlRcvRlayFnshCallCnt;
	}
	public double getTmexlRcvRlayFnshRt() {
		return tmexlRcvRlayFnshRt;
	}
	public void setTmexlRcvRlayFnshRt(double tmexlRcvRlayFnshRt) {
		this.tmexlRcvRlayFnshRt = tmexlRcvRlayFnshRt;
	}
	public double getTmexlRcvRlayExfluRt() {
		return tmexlRcvRlayExfluRt;
	}
	public void setTmexlRcvRlayExfluRt(double tmexlRcvRlayExfluRt) {
		this.tmexlRcvRlayExfluRt = tmexlRcvRlayExfluRt;
	}
	public int getOtCallCnt() {
		return otCallCnt;
	}
	public void setOtCallCnt(int otCallCnt) {
		this.otCallCnt = otCallCnt;
	}
	public int getOcallFnshCallCnt() {
		return ocallFnshCallCnt;
	}
	public void setOcallFnshCallCnt(int ocallFnshCallCnt) {
		this.ocallFnshCallCnt = ocallFnshCallCnt;
	}
	public double getOcallFnshRt() {
		return ocallFnshRt;
	}
	public void setOcallFnshRt(double ocallFnshRt) {
		this.ocallFnshRt = ocallFnshRt;
	}
	public double getOtCallExfluRt() {
		return otCallExfluRt;
	}
	public void setOtCallExfluRt(double otCallExfluRt) {
		this.otCallExfluRt = otCallExfluRt;
	}
	public double getOcallTmFnshRt() {
		return ocallTmFnshRt;
	}
	public void setOcallTmFnshRt(double ocallTmFnshRt) {
		this.ocallTmFnshRt = ocallTmFnshRt;
	}
	public int getItCallCnt() {
		return itCallCnt;
	}
	public void setItCallCnt(int itCallCnt) {
		this.itCallCnt = itCallCnt;
	}
	public int getIcallFnshCallCnt() {
		return icallFnshCallCnt;
	}
	public void setIcallFnshCallCnt(int icallFnshCallCnt) {
		this.icallFnshCallCnt = icallFnshCallCnt;
	}
	public double getIcallFnshRt() {
		return icallFnshRt;
	}
	public void setIcallFnshRt(double icallFnshRt) {
		this.icallFnshRt = icallFnshRt;
	}
	public double getItCallExfluRt() {
		return itCallExfluRt;
	}
	public void setItCallExfluRt(double itCallExfluRt) {
		this.itCallExfluRt = itCallExfluRt;
	}
	public double getIcallTmFnshRt() {
		return icallTmFnshRt;
	}
	public void setIcallTmFnshRt(double icallTmFnshRt) {
		this.icallTmFnshRt = icallTmFnshRt;
	}
	public int getMounLineCnt() {
		return mounLineCnt;
	}
	public void setMounLineCnt(int mounLineCnt) {
		this.mounLineCnt = mounLineCnt;
	}
	public double getOosRt() {
		return oosRt;
	}
	public void setOosRt(double oosRt) {
		this.oosRt = oosRt;
	}
	public int getOosRtDcOccrCnt() {
		return oosRtDcOccrCnt;
	}
	public void setOosRtDcOccrCnt(int oosRtDcOccrCnt) {
		this.oosRtDcOccrCnt = oosRtDcOccrCnt;
	}
	public double getOvrCallRt() {
		return ovrCallRt;
	}
	public void setOvrCallRt(double ovrCallRt) {
		this.ovrCallRt = ovrCallRt;
	}
	public int getOvrCallRtDcOccrCnt() {
		return ovrCallRtDcOccrCnt;
	}
	public void setOvrCallRtDcOccrCnt(int ovrCallRtDcOccrCnt) {
		this.ovrCallRtDcOccrCnt = ovrCallRtDcOccrCnt;
	}
	public double getLineUseRt() {
		return lineUseRt;
	}
	public void setLineUseRt(double lineUseRt) {
		this.lineUseRt = lineUseRt;
	}
	public int getLineUseRtDcOccrCnt() {
		return lineUseRtDcOccrCnt;
	}
	public void setLineUseRtDcOccrCnt(int lineUseRtDcOccrCnt) {
		this.lineUseRtDcOccrCnt = lineUseRtDcOccrCnt;
	}
	public double getExfluRt() {
		return exfluRt;
	}
	public void setExfluRt(double exfluRt) {
		this.exfluRt = exfluRt;
	}
	public double getTmFnshRt() {
		return tmFnshRt;
	}
	public void setTmFnshRt(double tmFnshRt) {
		this.tmFnshRt = tmFnshRt;
	}
	public int getTmTryCallCnt() {
		return tmTryCallCnt;
	}
	public void setTmTryCallCnt(int tmTryCallCnt) {
		this.tmTryCallCnt = tmTryCallCnt;
	}
	public int getTmFnshCallCnt() {
		return tmFnshCallCnt;
	}
	public void setTmFnshCallCnt(int tmFnshCallCnt) {
		this.tmFnshCallCnt = tmFnshCallCnt;
	}
	public int getAllTryCallCnt() {
		return allTryCallCnt;
	}
	public void setAllTryCallCnt(int allTryCallCnt) {
		this.allTryCallCnt = allTryCallCnt;
	}
	public int getTryCallDcOccrCnt() {
		return tryCallDcOccrCnt;
	}
	public void setTryCallDcOccrCnt(int tryCallDcOccrCnt) {
		this.tryCallDcOccrCnt = tryCallDcOccrCnt;
	}
	public double getAllFnshRt() {
		return allFnshRt;
	}
	public void setAllFnshRt(double allFnshRt) {
		this.allFnshRt = allFnshRt;
	}
	public int getFnshRtDcOccrCnt() {
		return fnshRtDcOccrCnt;
	}
	public void setFnshRtDcOccrCnt(int fnshRtDcOccrCnt) {
		this.fnshRtDcOccrCnt = fnshRtDcOccrCnt;
	}
	public String getAudblExlTm() {
		return audblExlTm;
	}
	public void setAudblExlTm(String audblExlTm) {
		this.audblExlTm = audblExlTm;
	}
	public int getDoexgBizrId() {
		return doexgBizrId;
	}
	public void setDoexgBizrId(int doexgBizrId) {
		this.doexgBizrId = doexgBizrId;
	}
	public String getExchgEquipClCd() {
		return exchgEquipClCd;
	}
	public void setExchgEquipClCd(String exchgEquipClCd) {
		this.exchgEquipClCd = exchgEquipClCd;
	}
	public String getDablCdLstCtt() {
		return dablCdLstCtt;
	}
	public void setDablCdLstCtt(String dablCdLstCtt) {
		this.dablCdLstCtt = dablCdLstCtt;
	}

	public void set(OMN20305 omn20305, UnmsTrafficPI trafficPI) {
		this.mntrCyclCd = omn20305.getMntrCyclCd();
		this.equipId = omn20305.getEquipId();
		this.infoCntrCd = trafficPI.getInfoCntrCd();
		this.distbCntrCd = trafficPI.getDistbCntrCd();
		this.occrDtm = omn20305.getMntrDtm();
		this.dablOccrLocDesc = trafficPI.getClctCyclNm() + "-" + trafficPI.getDataSrcClNm() + "-" + trafficPI.getEquipNm() + "-" + omn20305.getRoutNumCtt();
		this.netClCd = trafficPI.getNetClCd();
		this.routNum = omn20305.getRoutNumCtt();
		this.routUsgCtt = omn20305.getRoutUsgCtt();
		this.assaspNum = trafficPI.getAssaspNum();
		this.bizrClCd = trafficPI.getBizrClCd();
		this.incommBizrNm = trafficPI.getIncommBizrNm();
		this.doexgMscNm = trafficPI.getDoexgMscNm();
		this.routConnDirnCd = trafficPI.getRoutConnDirnCd();
		this.routConnTypCd = trafficPI.getRoutConnTypCd();
		this.connBizrNm = trafficPI.getConnBizrNm();
		this.connCustNm = trafficPI.getConnCustNm();
		this.tmClCd = trafficPI.getTmClCd();
		this.mntrNum = omn20305.getMntrNum();
		this.dataSrcClCd = omn20305.getDataSrcClCd();
		this.connClCd = omn20305.getConnClCd();
		this.nyOccrDcOccrCnt = trafficPI.getNyOccrDcOccrCnt();
		this.tmexlTryCallCnt = trafficPI.getTmexlTryCallCnt();
		this.tmexlFnshCallCnt = trafficPI.getTmexlFnshCallCnt();
		this.tmexlFnshRt = trafficPI.getTmexlFnshRt();
		this.mounLineCnt = trafficPI.getMounLineCnt();
		this.oosRt = trafficPI.getOosRt();
		this.oosRtDcOccrCnt = trafficPI.getOosRtDcOccrCnt();
		this.ovrCallRt = trafficPI.getOvrCallRt();
		this.ovrCallRtDcOccrCnt = trafficPI.getOvrCallRtDcOccrCnt();
		this.lineUseRt = trafficPI.getLineUseRt();
		this.lineUseRtDcOccrCnt = trafficPI.getLineUseRtDcOccrCnt();
		this.exfluRt = trafficPI.getExfluRt();
		this.allTryCallCnt = trafficPI.getAllTryCallCnt();
		this.tryCallDcOccrCnt = trafficPI.getTryCallDcOccrCnt();
		this.tmFnshRt = trafficPI.getTmFnshRt();
		this.tmTryCallCnt = trafficPI.getTmTryCallCnt();
		this.tmFnshCallCnt = trafficPI.getTmFnshCallCnt();
		this.allFnshRt = trafficPI.getAllFnshRt();
		this.fnshRtDcOccrCnt = trafficPI.getFnshRtDcOccrCnt();
		this.doexgBizrId = omn20305.getDoexgBizrId();
		this.exchgEquipClCd = omn20305.getExchgEquipClCd();
		this.tmexlOcallRlayTryCallCnt = trafficPI.getTmexlOcallRlayTryCallCnt();
		this.tmexlOcallRlayFnshCallCnt = trafficPI.getTmexlOcallRlayFnshCallCnt();
		this.tmexlOcallRlayFnshRt = trafficPI.getTmexlOcallRlayFnshRt();
		this.tmexlOcallRlayExfluRt = trafficPI.getTmexlOcallRlayExfluRt();
		this.tmexlRcvRlayTryCallCnt = trafficPI.getTmexlRcvRlayTryCallCnt();
		this.tmexlRcvRlayFnshCallCnt = trafficPI.getTmexlRcvRlayFnshCallCnt();
		this.tmexlRcvRlayFnshRt = trafficPI.getTmexlRcvRlayFnshRt();
		this.tmexlRcvRlayExfluRt = trafficPI.getTmexlRcvRlayExfluRt();
	}
	
}
