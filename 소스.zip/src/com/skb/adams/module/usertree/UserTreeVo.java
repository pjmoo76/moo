package com.skb.adams.module.usertree;

import java.util.ArrayList;
import java.util.List;

public class UserTreeVo {

	private int treeNo;

	private int upperTreeNo;

	private String treeName;

	private boolean orYn;

	public String toString() {
		return upperTreeNo + " - " + treeNo;
	}

	private List<UserTreeAttrVo> attrList;
	private List<UserTreeVo> children;
	private List<UserTreeEquipVo> equipList;

	public List<UserTreeEquipVo> getEquipList() {
		if (equipList == null) {
			equipList = new ArrayList<UserTreeEquipVo>();
		}

		return equipList;
	}

	public List<UserTreeVo> getChildren() {
		if (children == null) {
			children = new ArrayList<UserTreeVo>();
		}

		return children;
	}

	public List<UserTreeAttrVo> getAttrList() {
		if (attrList == null) {
			attrList = new ArrayList<UserTreeAttrVo>();
		}

		return attrList;
	}

	public int getTreeNo() {
		return treeNo;
	}

	public void setTreeNo(int treeNo) {
		this.treeNo = treeNo;
	}

	public int getUpperTreeNo() {
		return upperTreeNo;
	}

	public void setUpperTreeNo(int upperTreeNo) {
		this.upperTreeNo = upperTreeNo;
	}

	public String getTreeName() {
		return treeName;
	}

	public void setTreeName(String treeName) {
		this.treeName = treeName;
	}

	public boolean isOrYn() {
		return orYn;
	}

	public void setOrYn(boolean orYn) {
		this.orYn = orYn;
	}

	public int getEquipCountAll() {
		if (getChildren().size() == 0) {
			return getEquipList().size();
		}

		return getEquipCountAll(getChildren());
	}

	private int getEquipCountAll(List<UserTreeVo> childern) {
		int size = 0;
		
		for ( UserTreeVo tree : childern ) {
			if ( tree.getChildren().size() == 0 ) {
				size += tree.getEquipList().size();
			} else {
				size += getEquipCountAll(tree.getChildren());
			}
		}
		
		return size;

	}
}
