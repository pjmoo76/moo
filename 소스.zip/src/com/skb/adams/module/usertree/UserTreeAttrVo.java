package com.skb.adams.module.usertree;

public class UserTreeAttrVo {

	private int treeNo;

	private String columnName;

	private String columnValues;

	public String toString() {
		return treeNo + "-" + columnName + "-" + columnValues;
	}

	public int getTreeNo() {
		return treeNo;
	}

	public void setTreeNo(int treeNo) {
		this.treeNo = treeNo;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getColumnValues() {
		return columnValues;
	}

	public boolean match(String value) {
		
		for (String s : getValues()) {
			if (s.equals(value)) {
				return true;
			}
		}
		
		return false;
	}

	private String values[];

	private String[] getValues() {
		if (values == null) {
			values = columnValues.split(",");
		}

		return values;
	}

	public String getWhereData() {
		StringBuffer sb = new StringBuffer();
		for (String s : getValues()) {
			if (sb.length() > 0) {
				sb.append(", ");
			}

			sb.append("'" + s + "'");
		}

		return sb.toString();

	}

	public void setColumnValues(String columnValues) {
		this.columnValues = columnValues;
	}

}
