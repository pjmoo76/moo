package com.skb.adams.module.usertree;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import subkjh.bas.utils.ObjectUtil;

public class UserTreeMaker {

	private List<UserTreeEquipVo> rootEquipAllList;
	private Map<String, Map<String, List<UserTreeEquipVo>>> columnMap = new HashMap<String, Map<String, List<UserTreeEquipVo>>>();

	public UserTreeMaker(UserTreeVo rootTree, List<UserTreeEquipVo> rootEquipAllList) {

		this.rootEquipAllList = rootEquipAllList;

		List<UserTreeAttrVo> upperAttrList = new ArrayList<UserTreeAttrVo>();

		try {

			if (rootTree.getChildren().size() == 0) {
				setEquip(upperAttrList, rootTree);
			} else {
				for (UserTreeVo childTree : rootTree.getChildren()) {
					setEquip(upperAttrList, childTree);
				}
			}

			print("", rootTree);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void setEquip(List<UserTreeAttrVo> upperAttrList, UserTreeVo tree) {

		if (tree.getChildren().size() > 0) {

			upperAttrList.addAll(tree.getAttrList());
			for (UserTreeVo child : tree.getChildren()) {
				setEquip(upperAttrList, child);
			}

		} else {

			Map<String, UserTreeEquipVo> containsEquipMap = null;

			for (UserTreeAttrVo attr : upperAttrList) {
				containsEquipMap = getEquipMap(attr, containsEquipMap);
				if (containsEquipMap.size() == 0) {
					return;
				}
			}

			for (UserTreeAttrVo attr : tree.getAttrList()) {
				containsEquipMap = getEquipMap(attr, containsEquipMap);
				if (containsEquipMap.size() == 0) {
					return;
				}
			}

			for (UserTreeEquipVo equip : containsEquipMap.values()) {
				tree.getEquipList().add(equip);
			}
		}

	}

	private Map<String, UserTreeEquipVo> getEquipMap(UserTreeAttrVo attr, Map<String, UserTreeEquipVo> containsEquipMap) {
		Map<String, List<UserTreeEquipVo>> map = columnMap.get(attr.getColumnName());
		List<UserTreeEquipVo> list;
		String attrValue;

		if (map == null) {
			map = new HashMap<String, List<UserTreeEquipVo>>();
			columnMap.put(attr.getColumnName(), map);

			for (UserTreeEquipVo equip : rootEquipAllList) {

				list = null;

				attrValue = getAttrValue(equip, attr);

				list = map.get(attrValue);
				if (list == null) {
					list = new ArrayList<UserTreeEquipVo>();
					map.put(attrValue, list);
				}

				list.add(equip);
			}
		}

		String valueArr[] = attr.getColumnValues().split(",");
		List<UserTreeEquipVo> retList = new ArrayList<UserTreeEquipVo>();
		List<UserTreeEquipVo> entry;
		for (String value : valueArr) {
			entry = map.get(value);

			if (entry != null) {
				retList.addAll(entry);
			}
		}

		Map<String, UserTreeEquipVo> retMap = new HashMap<String, UserTreeEquipVo>();

		if (containsEquipMap == null) {
			for (UserTreeEquipVo vo : retList) {
				retMap.put(vo.getEquipId(), vo);
			}
			return retMap;
		} else {
			for (UserTreeEquipVo vo : retList) {
				if (containsEquipMap.get(vo.getEquipId()) != null) {
					retMap.put(vo.getEquipId(), vo);
				}
			}

			return retMap;
		}

	}

	private String getAttrValue(UserTreeEquipVo equip, UserTreeAttrVo attr) {
		if (attr.getColumnName().equals("TPO_CD")) {
			return equip.getTpoCd();
		} else if (attr.getColumnName().equals("LDONG_CD")) {
			return equip.getLdongCd();
		} else if (attr.getColumnName().equals("SUP_LDONG_CD")) {
			return equip.getSupLdongCd();
		} else if (attr.getColumnName().equals("EQUIP_USG_CD")) {
			return equip.getEquipUsgCd();
		} else if (attr.getColumnName().equals("EQUIP_MDL_CD")) {
			return equip.getEquipMdlCd();
		} else if (attr.getColumnName().equals("EQUIP_MDL_TYP_CD")) {
			return equip.getEquipMdlTypCd();
		} else {
			return null;
		}
	}

	private void print(String tag, UserTreeVo tree) {

		if (tree.getEquipCountAll() == 0) {
			return;
		}

		System.out.println(tag + tree.getTreeName() + " (" + tree.getEquipCountAll() + ")");

		for (UserTreeAttrVo attr : tree.getAttrList()) {
			System.out.println(tag + "\tattr : " + attr);
		}

		tree.getEquipList().sort(new Comparator<UserTreeEquipVo>() {
			@Override
			public int compare(UserTreeEquipVo arg0, UserTreeEquipVo arg1) {
				return arg0.getEquipAlias().compareTo(arg1.getEquipAlias());
			}
		});
		for (UserTreeEquipVo equip : tree.getEquipList()) {
			System.out.println(tag + "\tequip : " + ObjectUtil.toMap(equip));
		}

		for (UserTreeVo child : tree.getChildren()) {
			print(tag + "\t", child);
		}
	}
}
