package com.skb.adams.module.usertree;

public class UserTreeEquipVo {

	private String equipId;
	private String equipNm;
	private String equipTidVal;
	private String tpoCd;
	private String tpoNm;
	private String ldongCd;
	private String supLdongCd;
	private String equipMdlTypCd;
	private String equipUsgCd;
	private String equipMdlCd;

	public String getEquipAlias()
	{
		if ( equipNm  != null ) {
			return equipNm;
		}
		
		if ( equipTidVal != null ) {
			return equipTidVal;
		}
		
		return equipId;
	}
	
	public String getTpoNm() {
		return tpoNm;
	}

	public void setTpoNm(String tpoNm) {
		this.tpoNm = tpoNm;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof UserTreeEquipVo) {
			return ((UserTreeEquipVo) obj).equipId.equals(equipId);
		}
		return super.equals(obj);
	}

	public String getEquipId() {
		return equipId;
	}

	public String getEquipMdlCd() {
		return equipMdlCd;
	}

	public String getEquipMdlTypCd() {
		return equipMdlTypCd;
	}

	public String getEquipNm() {
		return equipNm;
	}

	public String getEquipTidVal() {
		return equipTidVal;
	}

	public String getEquipUsgCd() {
		return equipUsgCd;
	}

	public String getLdongCd() {
		return ldongCd;
	}

	public String getSupLdongCd() {
		return supLdongCd;
	}

	public String getTpoCd() {
		return tpoCd;
	}

	@Override
	public int hashCode() {
		return 1;
	}

	public void setEquipId(String equipId) {
		this.equipId = equipId;
	}

	public void setEquipMdlCd(String equipMdlCd) {
		this.equipMdlCd = equipMdlCd;
	}

	public void setEquipMdlTypCd(String equipMdlTypCd) {
		this.equipMdlTypCd = equipMdlTypCd;
	}

	public void setEquipNm(String equipNm) {
		this.equipNm = equipNm;
	}

	public void setEquipTidVal(String equipTidVal) {
		this.equipTidVal = equipTidVal;
	}

	public void setEquipUsgCd(String equipUsgCd) {
		this.equipUsgCd = equipUsgCd;
	}

	public void setLdongCd(String ldongCd) {
		this.ldongCd = ldongCd;
	}

	public void setSupLdongCd(String supLdongCd) {
		this.supLdongCd = supLdongCd;
	}

	public void setTpoCd(String tpoCd) {
		this.tpoCd = tpoCd;
	}

	
}
