package com.skb.adams.module.usertree;

public class LdongVo {

	private String ldongClCd;
	private String ldongCd;
	private String supLdongCd;
	
	public String getLdongClCd() {
		return ldongClCd;
	}
	public void setLdongClCd(String ldongClCd) {
		this.ldongClCd = ldongClCd;
	}
	public String getLdongCd() {
		return ldongCd;
	}
	public void setLdongCd(String ldongCd) {
		this.ldongCd = ldongCd;
	}
	public String getSupLdongCd() {
		return supLdongCd;
	}
	public void setSupLdongCd(String supLdongCd) {
		this.supLdongCd = supLdongCd;
	}

}
