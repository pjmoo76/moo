package com.skb.adams.module.usertree;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import subkjh.bas.dao.control.DbTrans;
import subkjh.bas.dao.database.DBManager;

public class UserTreeItemSelector {

	public static void main(String[] args) {
		new UserTreeItemSelector();
	}

	private final String userId = "TEST";

	public UserTreeItemSelector() {

		long ptime = System.currentTimeMillis();

		try {
			Map<Integer, UserTreeVo> map = selectUserTreeList();
			// print(map);
			findEquip(map);
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("소요 시간 -----");
		System.out.println(System.currentTimeMillis() - ptime);
	}

	private void findEquip(Map<Integer, UserTreeVo> map) {

		for (UserTreeVo tree : map.values()) {

			try {
				new UserTreeMaker(tree, selectEquip(tree));
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

	}

	@SuppressWarnings("unchecked")
	private List<UserTreeEquipVo> selectEquip(UserTreeVo tree) throws Exception {
		DbTrans tran;

		tran = DBManager.getMgr().getDataBase("ADAMS_MICM").createDbTrans("deploy/conf/sql/user-tree.xml");

		try {
			tran.start();

			Map<String, Object> para = new HashMap<String, Object>();
			for (UserTreeAttrVo attr : tree.getAttrList()) {
				para.put(attr.getColumnName(), attr.getWhereData());
			}

			List<UserTreeEquipVo> equipList = (List<UserTreeEquipVo>) tran.selectQid2Res("SELECT_USER_TREE_EQUIP_LIST", para);
			return equipList;

		} catch (Exception e) {
			throw e;
		} finally {
			tran.stop();
		}
	}

	@SuppressWarnings("unchecked")
	public Map<Integer, UserTreeVo> selectUserTreeList() throws Exception {

		DbTrans tran;

		tran = DBManager.getMgr().getDataBase("MICM_DEV").createDbTrans("deploy/conf/sql/user-tree.xml");

		Map<String, Object> para = new HashMap<String, Object>();
		para.put("userId", userId);

		try {
			tran.start();

			UserTreeVo tree, upperTree;
			List<UserTreeVo> treeList = (List<UserTreeVo>) tran.selectQid2Res("SELECT_USER_TREE_LIST", para);
			Map<Integer, UserTreeVo> tmpTreeMap = new HashMap<Integer, UserTreeVo>();
			Map<Integer, UserTreeVo> treeMap = new HashMap<Integer, UserTreeVo>();
			for (UserTreeVo e : treeList) {
				tmpTreeMap.put(e.getTreeNo(), e);
			}

			List<UserTreeAttrVo> attrList = (List<UserTreeAttrVo>) tran.selectQid2Res("SELECT_USER_TREE_ATTR_LIST", para);

			for (UserTreeAttrVo attr : attrList) {
				tree = tmpTreeMap.get(attr.getTreeNo());
				if (tree != null) {
					tree.getAttrList().add(attr);
				}
			}

			for (UserTreeVo e : treeList) {
				if (e.getUpperTreeNo() == 0) {
					treeMap.put(e.getTreeNo(), e);
				} else {
					upperTree = tmpTreeMap.get(e.getUpperTreeNo());
					if (upperTree == null) {
						treeMap.put(e.getTreeNo(), e);
					} else {
						upperTree.getChildren().add(e);
					}
				}

			}
			return treeMap;

		} catch (Exception e) {
			throw e;
		} finally {
			tran.stop();
		}

	}

	// private String getAttrValue(UserTreeEquipVo equip, UserTreeAttrVo attr) {
	// if (attr.getColumnName().equals("TPO_CD")) {
	// return equip.getTpoCd();
	// } else if (attr.getColumnName().equals("LDONG_CD")) {
	// return equip.getLdongCd();
	// } else if (attr.getColumnName().equals("SUP_LDONG_CD")) {
	// return equip.getSupLdongCd();
	// } else if (attr.getColumnName().equals("EQUIP_USG_CD")) {
	// return equip.getEquipUsgCd();
	// } else if (attr.getColumnName().equals("EQUIP_MDL_CD")) {
	// return equip.getEquipMdlCd();
	// } else if (attr.getColumnName().equals("EQUIP_MDL_TYP_CD")) {
	// return equip.getEquipMdlTypCd();
	// } else {
	// return null;
	// }
	// }

	//
	// public void print(Map<Integer, UserTreeVo> map) {
	// for (UserTreeVo tree : map.values()) {
	// System.out.println(tree);
	// print("", tree.getChildren());
	// }
	// }
	//
	// private void print(String tag, List<UserTreeVo> children) {
	// for (UserTreeVo vo : children) {
	// System.out.println(tag + vo);
	// print(tag + "\t", vo.getChildren());
	// }
	// }

	// @SuppressWarnings("unused")
	// private void filter(List<UserTreeEquipVo> equipList, UserTreeVo rootTree)
	// {
	// if (rootTree.getAttrList().size() == 0) {
	// return;
	// }
	//
	// UserTreeEquipVo equip;
	// String equipValue;
	// for (int i = equipList.size() - 1; i >= 0; i--) {
	// equip = equipList.get(i);
	//
	// for (UserTreeAttrVo attr : rootTree.getAttrList()) {
	// equipValue = getAttrValue(equip, attr);
	// if (attr.match(equipValue) == false) {
	// equipList.remove(i);
	// break;
	// }
	// }
	// }
	// }

}
