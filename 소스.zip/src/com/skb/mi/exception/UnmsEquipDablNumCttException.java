package com.skb.mi.exception;

public class UnmsEquipDablNumCttException extends Exception { 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UnmsEquipDablNumCttException() {
		// TODO Auto-generated constructor stub
		////EQUIP_MDL_CD ::0000001049 (SSW-C5,제너스위치인경우)	 EquipDablNumCttNot > 0 
		super("EquipDablNumCtt 가 적합하지않습니다.");
	}
}
