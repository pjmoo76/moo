package com.skb.mi.common;

import java.io.File;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

public class EnvManager {
	
	/*
	 * BASE_HOME : SKB_MI_HOME
	 */

	static public EnvManager env = null;
	
	final private String C_SKB_MI_HOME	= "SKB_MI_HOME";
	final private String C_CFG_FILE		= "CFG_FILE";
	final private String C_LOG_LEVEL	= "LOG_LEVEL";
	
	private String	home = null;
	private String	cfgFile = null;
	private	String	logLevel = null;
	private	boolean	valid = true;
	private	Options options = null;
	private CommandLine commandLine = null;

	public EnvManager(String[] args) {
		this.options = new Options();
		set(args);
		EnvManager.env = this;
	}

	public EnvManager(String[] args, Options options) {
		this.options = options;
		set(args);
		EnvManager.env = this;
	}

	private void set(String[] args) {
		Option homeOption = Option.builder().longOpt(C_SKB_MI_HOME)
				.desc("HOME Directory").hasArg().argName(C_SKB_MI_HOME).build();
		Option cfgFileOption = Option.builder().longOpt(C_CFG_FILE)
				.desc("Config File Name").hasArg().argName(C_CFG_FILE).build();
		Option logLevelOption = Option.builder().longOpt(C_LOG_LEVEL)
				.desc("Log Level").hasArg().argName(C_LOG_LEVEL).required(false).build();
		options.addOption(homeOption);
		options.addOption(cfgFileOption);
		options.addOption(logLevelOption);
		CommandLineParser parser = new DefaultParser();
		try {
			commandLine = parser.parse(options, args);
			if (commandLine.hasOption(C_SKB_MI_HOME)) {
				home = commandLine.getOptionValue(C_SKB_MI_HOME);
			}
			if (home == null || home.isEmpty()) {
				home = System.getProperty(C_SKB_MI_HOME);
				if (home == null) {
					home = System.getenv(C_SKB_MI_HOME);
				}
				if (home == null) {
					valid = false;
				}
			}
			if (commandLine.hasOption(C_CFG_FILE)) {
				cfgFile = commandLine.getOptionValue(C_CFG_FILE);
			} else {
				cfgFile = "mi-service.xml";
			}
			if (commandLine.hasOption(C_LOG_LEVEL)) {
				logLevel = commandLine.getOptionValue(C_LOG_LEVEL);
				MiscUtils.setLogLevel(this.logLevel);
			}
		} catch (Exception e) {
			System.out.println(e);
		}		
	}
	
	public String getHome() {
		return home;
	}

	public String getConf() {
		return home + File.separator + "conf";
	}
	
	public String getLogs() {
		return home + File.separator + "logs";
	}

	public String getCfgFile() {
		return cfgFile;
	}
	
	public String getLogLevel() {
		return logLevel;
	}
	
	public boolean isValid() {
		return this.valid;
	}
	
	public Options getOptions() {
		return this.options;
	}
	
	public String getOptionValue(String name) {
		if (commandLine.hasOption(name)) {
			return commandLine.getOptionValue(name);
		} else {
			return null;
		}
	}
}
