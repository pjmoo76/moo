package com.skb.mi.common;

public class MyLogger {
	public MyLogger() {
		
	}
	
	public void log(Object... objArray) {
		StackTraceElement caller = MyLogger.getCaller();
		if (caller != null) {
			System.out.println("log: " + caller.getClassName() + "." + caller.getMethodName() + " (" + caller.getFileName() + ":" + caller.getLineNumber() + ")");
		}
	}
	
	private static StackTraceElement getCaller() {
		StackTraceElement[] list = Thread.currentThread().getStackTrace();

		for(int i = 1; i < list.length; ++i) {
			if(!list[i].getClassName().equals(MyLogger.class.getName())) {
				return list[i];
			}
		}
		return null;
	}
}
