package com.skb.mi.common;

import java.io.FileInputStream;
import java.util.Calendar;

public class BatchJob {
	final public int 	BUFFER_SIZE = 2048;
	final public byte 	ONE_LINE_IDENTIFIER = 0x0a;
	final public byte	IDENTIFIER = '|';
	
	int					bufferFront;
	int					bufferRear;
	byte [] 			buffer;
	boolean				printYn;
	FileInputStream		fis = null;
	
	public BatchJob () {
		buffer = new byte [BUFFER_SIZE];
		bufferFront = bufferRear = 0;
		printYn = false;
	}
	
	public void close () {
		try {
			fis.close ();
		} catch (Exception e) {
		}
	}

	public boolean openFile (String fileName) {
		boolean ret = true;
		try {
			bufferFront = bufferRear = 0;
			fis = new FileInputStream (fileName);
		} catch (Exception e) {
			System.out.println ("openFile Error : " + e);
			ret = false;
		}
		return ret;
	}
	
	public byte getOneByte () {
        try {
            if (bufferFront == bufferRear) {
                bufferFront = 0;
                bufferRear = fis.read (buffer);
            }
            
            if (bufferRear != -1)
            	return buffer [bufferFront ++];
        } catch (Exception e) {
        	System.out.println ("bufferFront : " + bufferFront + ", bufferRear : " + bufferRear);
        	System.out.println ("getOneByte () Exception : " + e);
        }
        return -1;
    }

    public byte [] getBytes (int number) {
        byte [] bytes = new byte [number];
        byte temp;
        for (int index = 0; index < number; ++ index) {
            temp = getOneByte ();
            if (temp == -1)
                return null;
            
            if (temp == 0x0a || temp == 0x0d)
            	continue;
            
            bytes [index] = temp;
        }
        return bytes;
    }
    
    public String getBytes (byte id) {
    	byte [] bytes = new byte [BUFFER_SIZE];
    	int 	index;
    	byte 	temp;
    	
    	for (index = 0; index < BUFFER_SIZE; ++ index) {
    		temp = getOneByte ();
    		if (temp == -1)
    			return null;
    		else if (temp == id)
    			break;
    		
    		bytes [index] = temp;
    	}
    	if (index == 0)
    		return new String ("");
    	
    	try {
    		String	encode = new String (bytes, 0, index, "MS949");
    		return encode;
    	} catch (Exception e) {	
    		return new String ("");
    	}
    }

    public String getProcessDate (int day) {
		Calendar	cal = Calendar.getInstance();
		
		cal.add (Calendar.DAY_OF_MONTH, day);
		return String.format("%04d%02d%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH));
    }
    
    public String getDate (int day) {
		Calendar	cal = Calendar.getInstance();
		
		cal.add (Calendar.DAY_OF_MONTH, day);
		return String.format("%04d-%02d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH));
    }

    public String getDateHHM (int day) {
		Calendar	cal = Calendar.getInstance();
		
		cal.add (Calendar.DAY_OF_MONTH, day);
		return String.format("%04d%02d%02d%02d%1d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH) 
								, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE) / 10);
    }
    
    public String getDateSecond () {
		Calendar	cal = Calendar.getInstance();
		return String.format("%04d-%02d-%02d %02d:%02d:%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH),
				cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND));
	}
	
	public void print (String str) {
		if (printYn)
			System.out.print (str);
	}
	
	public void println (String str) {
		if (printYn)
			System.out.println (str);
	}

	public boolean isPrintYn() {
		return printYn;
	}

	public void setPrintYn(boolean printYn) {
		this.printYn = printYn;
	}
	
	public int countBuffer (byte compare, String buffer) {
		int count = 0;
		
		for (int index = 0; index < buffer.length(); ++ index)
			if (buffer.charAt(index) == compare)
				++ count;
		return count;
	}
}
