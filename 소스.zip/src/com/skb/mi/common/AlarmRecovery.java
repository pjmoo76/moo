package com.skb.mi.common;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.sql.PreparedStatement;

import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.skb.mi.thread.NMSThread;

public class AlarmRecovery {
	private	String	startTime;
	private	String	endTime;
	private	String	workMode;
	private JSONParser	jsonParser = new JSONParser();
	private	NMSThread	worker;
	
	private	String			dbUrl, userName, password;
	private DBController	dbController;
	
	public AlarmRecovery(String[] args) {
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);

		dbUrl = configManager.getConfig(Constants.ADAMS_DB, Constants.DB_URL);
		userName = configManager.getConfig(Constants.ADAMS_DB, Constants.USER_NAME);
		password = configManager.getConfig(Constants.ADAMS_DB, Constants.PASSWORD);

		String logFile = EnvManager.env.getOptionValue("ALARM_LOG_FILE");
		startTime = EnvManager.env.getOptionValue("START_TIME");
		endTime = EnvManager.env.getOptionValue("END_TIME");
		workMode = EnvManager.env.getOptionValue("WORK_MODE");
		if (workMode == null) workMode = "SHOW";

		worker = new NMSThread(configManager, this.getClass().getName());
		worker.setAuditId("recovery");
		
		connectDb();
		doIt(logFile);
		closeDb();
	}

	public void doIt(String fileName) {
		FileInputStream		fr = null;
		BufferedReader		br = null;

		try {
			fr = new FileInputStream(fileName);
			InputStreamReader ir = new InputStreamReader(fr);
			br = new BufferedReader(ir);
			String strLine;
			while ((strLine = br.readLine()) != null) {
				//Logger.logger.debug(strLine);
				String data = getJsonData(strLine);
				if (data == null) continue;
				JSONObject jsonObject = null;
				try {
					jsonObject = (JSONObject) jsonParser.parse(data);
				} catch (Exception e1) {
					e1.printStackTrace();
					throw e1;
				}
				String logTime = getLogTime(strLine);
				String kindStr = (String) jsonObject.get("kind");
				
				/*
				jsonObject.put("DABL_NM", "TEAMS 장비장애");
				jsonObject.put("DABL_CD", "012001");
				jsonObject.put("DABL_MCL_CD", "01201");
				jsonObject.put("DABL_LCL_CD", "01");
				jsonObject.put("DABL_LCL_NM", "장비장애");
				jsonObject.put("DABL_MCL_NM", "전송망장비장애");
				*/
				
				if ("GEN".equals(kindStr)) {
					if (workMode.equals("SHOW") || workMode.equals("ALL") || workMode.equals("GEN") || workMode.equals("UPT_RCV_DTM")) {
						System.out.println(strLine);
					}
					if (workMode.equals("ALL") || workMode.equals("GEN")) {
						jsonObject.put("OCCR_RCV_DTM", logTime);
						worker.makeGenJSonObject(jsonObject);
					}
					if (workMode.equals("UPT_RCV_DTM")) {
						jsonObject.put("NEW_OCCR_RCV_DTM", logTime);
						updateRcvDtm(jsonObject);
						dbController.getConnection().commit();
					}

				} else if ("CLR".equals(kindStr)) {
					if (workMode.equals("SHOW") || workMode.equals("ALL") || workMode.equals("CLR")) {
						System.out.println(strLine);
					}
					if (workMode.equals("ALL") || workMode.equals("CLR")) {
						worker.makeClrJSonObject(jsonObject);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private String getJsonData(String data) {
		try {
			// 01234567890123456789
			// [2018-07-05 19:06:17.250]
			/*
			String timeStr = data.substring(12,20);
			if (startTime.compareTo(timeStr) <= 0 && endTime.compareTo(timeStr) >= 0) {
				// [2018-10-01 08:18:41.872][Thread-194862]NMSThread.run (NMSThread.java:137) {
				int pos = data.indexOf("NMSThread.java:137"); 
				if (pos == -1) return null;
				pos = data.indexOf('{');
				if (pos == -1) return null;
				return data.substring(pos);
			}
			*/
			int pos = data.indexOf("[EVENT]");
			if (pos > 0) {
				return data.substring(pos+1+7);
			}
			return null;
			
		} catch (Exception e) {
		}
		return null;
	}
	
	private String getLogTime(String data) {
		String logTime = data.substring(1, 20);
		return MiscUtils.getStandardDateFormatString(logTime);
	}
	
	private void connectDb() {
		try {
			dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
			dbController.getConnection().setAutoCommit(false);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void closeDb() {
		try {
			dbController.closeDB();
		} catch (Exception e) {
			
		}
	}

	private void updateRcvDtm(JSONObject jsonObject) throws Exception {
		String query = "UPDATE OMN30100 "
					+  "   SET OCCR_RCV_DTM = TO_DATE(?,'YYYYMMDDHH24MISS')"
					+  "     , AUDIT_ID = 'recovery2'"
					+  " WHERE NMS_DABL_NUM_CTT = ?"
					+  "   AND NMS_CD = ?"
					+  "   AND OCCR_RCV_DTM = TO_DATE(?,'YYYYMMDDHH24MISS')"
					+  "   AND AUDIT_ID = 'recovery'"
					;
		PreparedStatement stmt = dbController.prepareStatement(query);
		String newOccrRcvDtm = MiscUtils.getStandardDateFormatString((String) jsonObject.get("NEW_OCCR_RCV_DTM"));
		stmt.setString(1, newOccrRcvDtm);
		stmt.setString(2, (String) jsonObject.get("NMS_DABL_NUM_CTT"));
		stmt.setString(3, (String) jsonObject.get("NMS_CD"));
		String occrRcvDtm = MiscUtils.getStandardDateFormatString((String) jsonObject.get("OCCR_RCV_DTM"));
		stmt.setString(4, occrRcvDtm);
		System.out.println(String.format("(%s),(%s),(%s),(%s)"
				, newOccrRcvDtm
				, (String) jsonObject.get("NMS_DABL_NUM_CTT")
				, (String) jsonObject.get("NMS_CD")
				, occrRcvDtm));
		stmt.executeQuery();
		stmt.close();

	}
	public static void main(String[] args) {
		Options options = new Options();
		Option alarmLogFileOption = Option.builder().longOpt("ALARM_LOG_FILE")
				.desc("Alarm Log File").hasArg().argName("ALARM_LOG_FILE").required(false).build();
		Option startTimeOption = Option.builder().longOpt("START_TIME")
				.desc("Start Time").hasArg().argName("START_TIME").required(false).build();
		Option endTimeOption = Option.builder().longOpt("END_TIME")
				.desc("End Time").hasArg().argName("END_TIME").required(false).build();
		Option workModeOption = Option.builder().longOpt("WORK_MODE")
				.desc("Work Mode : ALL/GEN/CLR/SHOW(Default)/UPT_RCV_DTM").hasArg().argName("WORK_MODE").optionalArg(true).required(false).build();

		options.addOption(alarmLogFileOption);
		options.addOption(startTimeOption);
		options.addOption(endTimeOption);
		options.addOption(workModeOption);

    	EnvManager envManager = new EnvManager(args, options);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("AlarmRecovery", envManager.getOptions());
    		System.exit(0);
    	}

		new AlarmRecovery(args);
	}
}
