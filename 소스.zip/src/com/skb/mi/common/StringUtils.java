package com.skb.mi.common;

import java.util.ArrayList;
import java.util.Arrays;

public class StringUtils {
	/*
	 * 문자열이 null 이거나 비워져 있는지 체크
	 */
	public static boolean isEmpty(String s) {
		if (s == null) return true;
		return s.isEmpty();
	}

	/*
	 * byte array를 readable 한 문자열로 생성
	 */
	public static String toReadableString(byte[] bytes) {
		return toReadableString(bytes, bytes.length);
	}

	public static String toReadableString(byte[] bytes, int len) {
		int bufLen = len < bytes.length ? len : bytes.length;
		StringBuffer sb = new StringBuffer(bufLen);
		for (int i = 0; i < bufLen; i ++) {
			if (bytes[i] >= 33 && bytes[i] <= 126) {
				sb.append((char)bytes[i]);
			} else {
				sb.append(".");
			}
		}
		return sb.toString();
	}
	
	/*
	 * byte array를 hexa 값으로 표현
	 */

	public static String toHexString(byte[] bytes) {
		return toHexString(bytes, bytes.length);
	}

	public static String toHexString(byte[] bytes, int len) {
		int bufLen = len < bytes.length ? len : bytes.length;
		StringBuffer sb = new StringBuffer(bufLen*2);
		for (int i = 0; i < bufLen; i ++) {
			sb.append(toHex(bytes[i] >> 4));
			sb.append(toHex(bytes[i]));
		}
		return sb.toString();
	}

	public static String toHexString2(byte[] bytes, int len) {
		int bufLen = len < bytes.length ? len : bytes.length;
		StringBuffer sb = new StringBuffer(bufLen*2);
		for (int i = 0; i < bufLen; i ++) {
			if (i > 0 && i % 16 == 0) {
				sb.append("\n");
			} else if (i > 0) {
				sb.append(" ");
			}
			sb.append(toHex(bytes[i] >> 4));
			sb.append(toHex(bytes[i]));
		}
		return sb.toString();
	}

	public static String toHexString(byte[] bytes, int startPos, int len) {
		if (len <= 0) return null;
		int bufLen = (startPos+len) < bytes.length ? len : bytes.length-startPos;
		StringBuffer sb = new StringBuffer(bufLen*2);
		for (int i = startPos; i < (startPos+bufLen); i ++) {
			sb.append(toHex(bytes[i] >> 4));
			sb.append(toHex(bytes[i]));
		}
		return sb.toString();
	}

	private static char toHex(int nibble) {
		final char[] hexDigit = {
			'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'
		};
		return hexDigit[nibble & 0xF];
	}
	
	/*
	 * byte array 에서 특정 위치에서 len 길이만큼 추출
	 */
	public static byte[] getBytes(byte[] src, int pos, int len) {
		byte[] dest = new byte[len];
		System.arraycopy(src, pos, dest, 0, len);
		return dest;
	}
	
	/*
	 * byate array 를 delimiter 기준으로 split 하여 문자열 array 생성
	 */

	public static String[] split(byte[] body, byte delimiter, String charsetName) throws Exception {
		if (body == null || body.length == 0) return null;
		ArrayList<String> strList = new ArrayList<String>();
		int startIndex = 0;
		int nextIndex = 0;
		while (nextIndex < body.length) {
			if (body[nextIndex] == delimiter) {
				if (startIndex == nextIndex) {
					strList.add("");
				} else {
					strList.add(new String (body, startIndex, nextIndex - startIndex, charsetName));
				}
				startIndex = nextIndex + 1;
			}
			nextIndex ++;
		}
		if (startIndex < nextIndex) {
			strList.add(new String (body, startIndex, nextIndex - startIndex, charsetName));
		}
		return strList.toArray(new String[strList.size()]);
	}
	
	/*
	 * byte array 에서 size 들로 잘라내어 문자열 array 생성
	 */

	public static ArrayList<String> getItems(byte[] data, int[] itemLens, String charsetName) throws Exception {
		ArrayList<String> items = new ArrayList<String>();
		int start = 0;
		int end = 0;
		for (int i = 0; i < itemLens.length; i ++) {
			start = end;
			end += itemLens[i];
			try {
				byte[] value = Arrays.copyOfRange(data, start, end);
				items.add(new String(value, charsetName).trim());
			} catch (Exception e) {
				for (int j = 0; j < items.size(); j ++) {
					System.out.println(String.format("[%d][%s]", j, items.get(j)));
				}
				throw e;
			}
		}
		return items;
	}

	/*
	 * 문자열에서 특정 key 값 이후의 값 (key 값 포함하지 않음)
	 */
	public static String getRemainString(String data, String key) {
		int pos = data.indexOf(key);
		if (pos == -1) return null;
		return data.substring(pos+key.length());
	}

	/*
	 * 이름을 Masking 처리
	 */
    public static String maskString(String str) {
    	if (str == null) return null;
    	StringBuilder sb = new StringBuilder();
    	for (int i = 0; i < str.length(); i ++) {
    		if (i == 0) {
    			sb.append(str.charAt(i));
    		} else if (str.length() > 2 && (i == 0 || i == (str.length()-1))) {
    			sb.append(str.charAt(i));
    		} else {
    			sb.append("*");
    		}
    	}
    	return sb.toString();
    }

    /*
     * 문자열에서 특정 문자가 N 번째에 존재하는 위치 찾기
     */
	public static int findPos(String data, char findChar, int matchedNo) {
		int len = data.length();
		int cnt =0;
		for (int i = 0; i < len; i ++) {
			if (findChar == data.charAt(i)) {
				cnt ++;
				if (matchedNo == cnt) {
					return i;
				}
			}
		}
		return -1;
	}
	
	public static String concatenate(String[] items, char delimiter) {
		if (items == null || items.length == 0) return null;
		StringBuffer sb = new StringBuffer();
		boolean isFirst = true;
		for (String item : items) {
			if (isFirst) {
				isFirst = false;
			} else {
				sb.append(delimiter);
			}
			sb.append(item);
		}
		return sb.toString();
	}
	
	public static byte[] hexStringToByteArray(String hex) {
		int l = hex.length();
		byte[] data = new byte[l/2];
		for (int i = 0; i < l; i += 2) {
			data[i/2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4) + Character.digit(hex.charAt(i+1), 16));
		}
		return data;
	}
	
	public static boolean equals(String a, String b) {
		if (a == null && b == null) return true;
		if (a == null && b != null) return false;
		return a.equals(b);
	}
	
	public static String toString(byte[] bytes, int len) {
		int bufLen = len < bytes.length ? len : bytes.length;
		StringBuffer sb = new StringBuffer(bufLen);		
		for (int i = 0; i < bufLen; i ++) {
			sb.append((char)bytes[i]);
		}
		return sb.toString();
	}
	
	public static String null2Empty(String val) {
		if (val == null) return "";
		return val;
	}
	
	public static void setByteArray(byte[] buf, int pos, String data) {
		byte[] srcBuf = data.getBytes();
		for (int i = 0; i < srcBuf.length; i ++) {
			buf[pos+i] = srcBuf[i];
		}
	}
}
