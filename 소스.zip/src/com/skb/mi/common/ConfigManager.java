package com.skb.mi.common;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;

public class ConfigManager {
	private	String	fileName;
	HashMap<String,HashMap<String,String>> serviceMap;

	public ConfigManager(String fileName) {
		this.fileName = fileName;
		serviceMap = new HashMap<String,HashMap<String,String>>();
		try {
			parse();
		} catch (Exception e) {
			
		}
	}
	
	public String getFileName() {
		return this.fileName;
	}
	
	private void parse() throws Exception {
		SAXBuilder builder = new SAXBuilder();
		InputStream is = new FileInputStream(fileName);
		Document document = builder.build(is);
		if (document != null) {
			Element root = document.getRootElement();
			parse(root);
		}
		is.close();
	}
	
	private void parse(Element parent) throws Exception {
		List nodes = parent.getChildren();
		if (nodes != null) {
			Iterator arg8 = nodes.iterator();

			while (arg8.hasNext()) {
				Element node = (Element) arg8.next();
				String name = node.getAttributeValue("name");

				List children = node.getChildren();
				Iterator arg10 = children.iterator();
				
				HashMap<String,String> itemMap = new HashMap<String,String>();
				while (arg10.hasNext()) {
					Element child = (Element) arg10.next();
					itemMap.put(child.getName(), child.getTextTrim());
					//System.out.println(child.getName() + " : " + child.getTextTrim());
				}
				serviceMap.put(name, itemMap);
				//System.out.println(">> " + name);
			}
		}
	}
	
	public HashMap<String,String> getConfigMap(String serviceName) {
		return serviceMap.get(serviceName);
	}
	
	public String getConfig(String serviceName, String itemName) {
		HashMap<String,String> itemMap = getConfigMap(serviceName);
		if (itemMap == null) return null;
		return itemMap.get(itemName);
	}
	
	public boolean set(String serviceName, String itemName, String itemValue) {
		HashMap<String,String> itemMap = getConfigMap(serviceName);
		if (itemMap == null) return false;
		itemMap.put(itemName, itemValue);
		return true;
	}
	
	public void write(String fileName) throws Exception {
		if (fileName == null) fileName = this.fileName;
		;
		Path p = Paths.get(fileName);
		String configName = p.getFileName().toString();
		OutputStream out = new FileOutputStream(fileName, false);
		Writer w = new OutputStreamWriter(out, "UTF-8");
		w.write("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n");
		w.write("<!--\n");
		w.write("	Document : " + configName + "\n");
		w.write("-->\n");
		w.write("<services>\n");
		for (Map.Entry me : serviceMap.entrySet()) {
			w.write("	<service name=\"" + (String) me.getKey() + "\">\n");
			HashMap<String,String> itemMap = (HashMap<String,String>) me.getValue();
			for (Map.Entry me2 : itemMap.entrySet()) {
				w.write("		<" + me2.getKey() + ">" + me2.getValue() + "</" + me2.getKey() + ">\n");
			}
			w.write("	</service>\n");
		}
		w.write("</services>\n");
		w.close();
		out.flush();
		out.close();
	}
	
	public void print() {
		for (Map.Entry me : serviceMap.entrySet()) {
			System.out.println("----- " + me.getKey());
			HashMap<String,String> itemMap = (HashMap<String,String>) me.getValue();
			for (Map.Entry me2 : itemMap.entrySet()) {
				System.out.println(me2.getKey() + " : " + me2.getValue());
			}
		}
	}
	
	public HashMap<String,HashMap<String,String>> getServiceMap() {
		return serviceMap;
	}

	public static void main(String[] args) {
		// for test
		//"C:/projects/skbmi/workspace/dev-skbmi-cm-batch/deploy/conf/mi-service.xml"
		//new ConfigManager();
		Options options = new Options();
		Option file = Option.builder().longOpt("file").desc("Config File").hasArg().required().argName("file").build();
		options.addOption(file);
		CommandLineParser parser = new DefaultParser();
		try {
			String fileName = null;
			CommandLine commandLine = parser.parse(options, args);
			if (commandLine.hasOption("file")) {
				fileName = commandLine.getOptionValue("file");
			}
			ConfigManager cfgMgr = new ConfigManager(fileName);
			cfgMgr.print();
			cfgMgr.set("ADAMS_DB", "password", "!adams19");
			cfgMgr.print();
			cfgMgr.write(fileName + ".new");
		} catch (Exception e) {
			HelpFormatter formatter = new HelpFormatter();
			formatter.printHelp(ConfigManager.class.getName(), options);
		}

	}
}
