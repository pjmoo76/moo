package com.skb.mi.common;

import java.io.File;
import java.sql.SQLRecoverableException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class DbBatchService {
	private Logger		logger;

	class DbBatchNode {
		String		serviceName;
		String		databaseName;
		String		mapper;
		String[]	queries;
		String		healthCheckQuery;
		Cron		cron;
		boolean		runThread;
		
		DbBatchService batchService;
		Thread		worker;
		BlockingQueue<String>	blockingQueue;

		DbBatchNode(DbBatchService batchService) {
			this.batchService = batchService;
			this.runThread = false;
		}
		
		public void run() {
			runThread = true;
			blockingQueue = new LinkedBlockingQueue();
			worker = new Thread(new Runner(this));
			worker.start();
		}
		
		public void add() {
			this.blockingQueue.add(new String());
		}
	}
	
	List<DbBatchNode>	nodeList;
	HashMap<String, SqlSession>	sqlSessionMap;

	public DbBatchService(String[] args) {
		String fileName = EnvManager.env.getOptionValue(Constants.FILE_NAME);
		PerThreadDailyRollingFileAppender.LOG_POSTFIX = fileName.substring(0, fileName.indexOf('.'));
		logger = Logger.getLogger(this.getClass());
		sqlSessionMap = new HashMap<String, SqlSession>();
		loadConfig();
		run();
	}
	
	private void loadConfig() {
		String xmlFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getOptionValue(Constants.FILE_NAME);
		ConfigManager configManager = new ConfigManager(xmlFile);
		configManager.print();
		HashMap<String,HashMap<String,String>> serviceMap = configManager.getServiceMap();
		int idx = 1;
		for (Map.Entry me : serviceMap.entrySet()) {
			DbBatchNode node = new DbBatchNode(this);
			node.serviceName = (String) me.getKey();
			HashMap<String,String> itemMap = (HashMap<String,String>) me.getValue();
			for (Map.Entry me2 : itemMap.entrySet()) {
				if (Constants.DATABASE_NAME.equals(me2.getKey())) {
					node.databaseName = (String) me2.getValue();
				} else if (Constants.MAPPER.equals(me2.getKey())) {
					node.mapper = (String) me2.getValue();
				} else if (Constants.QUERY_LIST.equals(me2.getKey())) {
					String queryList = (String) me2.getValue();
					String[] queries = queryList.split(";");
					node.queries = new String[queries.length];
					for (int i = 0; i < queries.length; i ++) {
						node.queries[i] = queries[i].trim();
					}
					//logger.info("queries:"+ queryList);
				} else if (Constants.HEALTH_CHECK_QUERY.equals(me2.getKey())) {
					node.healthCheckQuery = (String) me2.getValue();
				} else if (Constants.SCHEDULE.equals(me2.getKey())) {
					try {
						node.cron = new Cron();
						node.cron.setCron((String) me2.getValue());
					} catch (Exception e) {
						logger.error(e);
					}
				} else if (Constants.THREAD.equals(me2.getKey())) {
					String value = (String) me2.getValue();
					if (value.equalsIgnoreCase("use")) {
						node.run();
					}
				}
			}
			if (nodeList == null) {
				nodeList = new ArrayList<DbBatchNode>();
			}
			nodeList.add(node);
		}
		for(DbBatchNode node : nodeList) {
			logger.info(String.format("[%s](%s),(%s),(%s),(%s),(%s),(%s)",
					node.serviceName, node.databaseName, node.mapper, StringUtils.concatenate(node.queries, ';'),
					node.healthCheckQuery, node.cron.getCronString(), (node.runThread ? "thread" : "normal")));
		}
	}
		
	private void run() {
		while (true) {
			logger.info("run");
			MiscUtils.sleep(MiscUtils.getNextMinuteMills()); // sleep to next minute
			long mstime = System.currentTimeMillis();
			for (DbBatchNode node : nodeList) {
				try {
					if (node.cron.isOnTime(mstime)) {
						logger.info(String.format("%s (%s)", node.serviceName, node.cron.getCronString()));
						if (node.runThread) {
							node.add();
						} else {
							SqlSession sqlSession = sqlSessionMap.get(node.databaseName);
							doIt(node, sqlSession, true);
						}
					}
				} catch (Exception e) {
					logger.error("Exception", e);
				}
			}
		}
	}
	
	public SqlSession doIt(DbBatchNode node, SqlSession sqlSession, boolean sessionMap) throws Exception {
		if (sqlSession == null) {
			sqlSession = reconnectDb(node.databaseName, sqlSession, sessionMap);
		}
		if (node.healthCheckQuery != null) {
			try {
				String qid = node.mapper + "." + node.healthCheckQuery;
				logger.info(qid);
				sqlSession.selectOne(qid, null);
			} catch (Exception e) {
				sqlSession = reconnectDb(node.databaseName, sqlSession, sessionMap);
			}
		}
		String qid = null;
		try {
			logger.info(node.queries.length);
			for (String query : node.queries) {
				qid = node.mapper + "." + query;
				logger.info(qid);
				long before = System.currentTimeMillis();
				sqlSession.insert(qid);
				long after = System.currentTimeMillis();
				logger.info(String.format("executed %s (elapsed-time: %d)", qid, (after-before)));
			}
			sqlSession.commit();
		} catch (PersistenceException pe) {
			logger.error("Exception ["+qid+"]", pe);
			sqlSession = reconnectDb(node.databaseName, sqlSession, sessionMap);
		} catch (Exception e) {
			throw e;
		}		
		return sqlSession;
	}
	
	private SqlSession reconnectDb(String databaseName, SqlSession sqlSession, boolean sessionMap) throws Exception {
		logger.info("reconnectDb ("+databaseName+"),(" + sessionMap + ")");
		if (sqlSession != null) {
			sqlSession.close();
			sqlSession = null;
		}
		sqlSession = IbatisSessionFactory.openSession(databaseName);
		if (sessionMap) {
			sqlSessionMap.put(databaseName, sqlSession);
		}
		return sqlSession;
	}

	public static void main(String[] args) {
		Options options = new Options();
		Option batchOption = Option.builder().longOpt(Constants.FILE_NAME).optionalArg(true)
				.desc("File Name").hasArg().argName(Constants.FILE_NAME).build();
		options.addOption(batchOption);

		EnvManager envManager = new EnvManager(args, options);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("DbBatchService", envManager.getOptions());
    		System.exit(0);
    	}
    	new DbBatchService(args);
	}

	class Runner implements Runnable {
		DbBatchNode node;
		SqlSession sqlSession;
		
		public Runner(DbBatchNode node) {		
			this.node = node;
		}

		@Override
		public void run() {
			logger.info("runner");
			while (true) {
				try {
					String obj = node.blockingQueue.take();
					logger.info("runner.doIt");
					sqlSession = node.batchService.doIt(node, sqlSession, false);
				} catch (Exception e) {
					logger.error("Exception", e);
				}
			}
		}
		
	}
}
