package com.skb.mi.common;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.StringTokenizer;

public class DBController {
	public	final static	int ORACLE_DB 		= 1;
	public  final static	int MARIA_DB  		= 2;
	public	final static	int INFORMIX_DB   	= 3;
	
	public	final static	int START_PROC		= 0;
	public	final static	int FINISH_PROC		= 1;

	int				dbKind = 0;					// DB 설정이 안되었음.
	String			dbUrl;
	Connection		connection = null ;
	Statement		stmt = null ;

	public DBController (int dbKind, String dbUrl, String loginName, String passwd) throws Exception {
		String	className = "";
		this.dbKind = dbKind;
		switch (dbKind) {
			case ORACLE_DB: 	className = "oracle.jdbc.driver.OracleDriver"; break;
			case MARIA_DB:		className = "org.mariadb.jdbc.Driver"; break;
			case INFORMIX_DB:	className = "com.informix.jdbc.IfxDriver"; break;
			default:			className = ""; break;
		}
		Class.forName(className);
		connection = DriverManager.getConnection(dbUrl, loginName, passwd);
		//stmt = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
		stmt = connection.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
	}

	public DBController (int dbKind, String dbUrl, String loginName, String passwd, int resultSetOpt1, int resultSetOpt2) throws Exception {
		String	className = "";
		this.dbKind = dbKind;
		switch (dbKind) {
			case ORACLE_DB: 	className = "oracle.jdbc.driver.OracleDriver"; break;
			case MARIA_DB:		className = "org.mariadb.jdbc.Driver"; break;
			case INFORMIX_DB:	className = "com.informix.jdbc.IfxDriver"; break;
			default:			className = ""; break;
		}
		Class.forName(className);
		connection = DriverManager.getConnection(dbUrl, loginName, passwd);
		// example
		// ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY
		stmt = connection.createStatement(resultSetOpt1, resultSetOpt2);
	}
	
	public DBController (int dbKind){
		this.dbKind = dbKind;
		if (dbKind == ORACLE_DB) {
			oracleDbController ();
		}
		else if (dbKind == MARIA_DB) {
			mariaDbController ();
		} else if (dbKind == INFORMIX_DB) {
			informixDbController ();
		} else {
			System.out.println ("지원되지 않는 DB입니다.");
		}
	}
	
	public void closeDB () {
		try {
			stmt.close ();
			connection.close ();
		} catch (Exception e) {
		}
	}
	
	public boolean isOpen () { 
		if (dbKind == 0)
			return false;
		return true;
	}
	
	private void oracleDbController () {
		String	dbUrl = "jdbc:oracle:thin:@10.250.212.207:1521:xe";
		String	userId = "iqcsdb" ;
		String	userPass = "white_00" ;
		String	oneLine;
		try {
			FileReader		fileReader = new FileReader ("data" + File.separator + "db.info");
			BufferedReader	bufferedReader = new BufferedReader (fileReader);
			oneLine = bufferedReader.readLine ();
			dbUrl = "jdbc:oracle:thin:@" + oneLine;
			bufferedReader.close ();
			fileReader.close ();
		} catch (Exception e) {
			dbUrl = "jdbc:oracle:thin:@10.250.212.207:1521:xe";
		}

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			System.out.println("oracleDbController:Driver를 찾을 수 없습니다." + e);
		} catch (Exception etc) {
			System.out.println("oracleDbController:" + etc.getMessage());
		}
		
		try {
			connection = DriverManager.getConnection(dbUrl, userId, userPass);
			stmt = connection.createStatement();
		} catch (SQLException e) {
			System.out.println("oracleDbController:SQLException : " + e.getMessage());
		}		
	}
	
	private void mariaDbController () {
		String	dbUrl = "jdbc:mariadb://localhost/networkems?useUnicode=true&characterEncoding=UTF8&jdbcCompliantTruncation=false" ;
		String	userId = "westktx" ;
		String	userPass = "NetworkEms" ;
		try {
			Class.forName("org.mariadb.jdbc.Driver").newInstance();
		} catch (ClassNotFoundException e) {
			System.out.println("mariaDbController:Driver를 찾을 수 없습니다." + e);
		} catch (Exception etc) {
			System.out.println("mariaDbController:" + etc.getMessage());
		}
		
		try {
			connection = DriverManager.getConnection(dbUrl, userId, userPass);
			stmt = connection.createStatement();
		} catch (SQLException e) {
			System.out.println("SmariaDbController:QLException : " + e.getMessage());
		}		
	}
	
	private void informixDbController () {
		String	dbUrl = "jdbc:mariadb://localhost/networkems?useUnicode=true&characterEncoding=UTF8&jdbcCompliantTruncation=false" ;
		String	userId = "westktx" ;
		String	userPass = "NetworkEms" ;
		try {
			Class.forName("org.mariadb.jdbc.Driver").newInstance();
		} catch (ClassNotFoundException e) {
			System.out.println("mariaDbController:Driver를 찾을 수 없습니다." + e);
		} catch (Exception etc) {
			System.out.println("mariaDbController:" + etc.getMessage());
		}
		
		try {
			connection = DriverManager.getConnection(dbUrl, userId, userPass);
			stmt = connection.createStatement();
		} catch (SQLException e) {
			System.out.println("SmariaDbController:QLException : " + e.getMessage());
		}		
	}
	
	public void insertProcessHistory (String pgmId, String clctRsltCtt, String pgmStCd, String clctSussYn) throws Exception {
        String  query;

        if (pgmStCd.equals ("S")) {         // 프로세스 시작
            query = "INSERT INTO OCO30311 ("
                    + "  AUDIT_ID"
                    + ", AUDIT_DTM"
                    + ", PGM_ID"
                    + ", HST_SER_NUM"
                    + ", CLCT_RSLT_CTT"
                    + ", CLCT_SUSS_YN"
                    + ", CLCT_STA_DTM"
                    + " ) VALUES ("
                    + "  'admin'"
                    + ", SYSDATE"
                    + ", '" + pgmId + "'"
                    + ", (SELECT NVL(MAX(HST_SER_NUM) + 1,1) FROM OCO30311)"
                    + ", '" + clctRsltCtt + "'"
                    + ", '" + clctSussYn + "'"
                    + ", SYSDATE"
                    + ")";
        } else {
            query = "UPDATE OCO30311 SET"
                  + "  AUDIT_ID='admin'"
                  + ", AUDIT_DTM=SYSDATE"
                  + ", CLCT_RSLT_CTT='" + clctRsltCtt + "'"
                  + ", CLCT_SUSS_YN='" + clctSussYn + "'"
                  + ", CLCT_END_DTM=SYSDATE"
                  + " WHERE HST_SER_NUM=(SELECT MAX(HST_SER_NUM) FROM OCO30311 "
                  + "                      WHERE PGM_ID='" + pgmId + "')";
        }

        getStmt ().executeUpdate (query);

        query = "UPDATE OCO30310 SET"
              + " PGM_ST_CD='" + pgmStCd + "'"
              + " WHERE PGM_ID='" + pgmId + "'";

        getStmt ().executeUpdate (query);
	}

    public void insertProcessHistory (String processId, String clctStaDtm, String clctEndDtm, String successYn, String clctRsltCtt) {
        String  query, temp;
        query = "INSERT INTO OCO30311 ("
                + "  PGM_ID"
                + ", HST_SER_NUM"
                + ", AUDIT_ID"
                + ", AUDIT_DTM"
                + ", CLCT_RSLT_CTT"
                + ", CLCT_STA_DTM"
                + ", CLCT_END_DTM"
                + ") VALUES ("
                + "'" + processId + "'"
                + ", (SELECT NVL(MAX(HST_SER_NUM) + 1,1) FROM OCO30311)"
                + ", 'admin'"
                + ", SYSDATE"
                + ", '" + clctRsltCtt + "'";

            if (clctStaDtm == null || clctStaDtm.equals (""))
                query += ", SYSDATE";
            else
                query += ", TO_DATE('" + clctStaDtm + "', 'YYYY-MM-DD HH24:MI:SS')";
            if (clctEndDtm == null || clctEndDtm.equals (""))
                query += ", SYSDATE";
            else
                query += ", TO_DATE('" + clctEndDtm + "', 'YYYY-MM-DD HH24:MI:SS')";
            query += ")";
        try {
            getStmt ().executeUpdate (query);
        } catch (Exception e) {
            System.out.println ("insertProcessHistory Exception : " + e);
        }
    }

    public String getPgmId (String className, String ipAddress) {
        try {
            StringTokenizer tokens = new StringTokenizer (className, ".");
            className = tokens.nextToken ();        // com
            className = tokens.nextToken ();        // skb
            className = tokens.nextToken ();        // mi
            className = tokens.nextToken ();        // realtime
            className = tokens.nextToken ();        // className
            String  query = "SELECT PGM_ID FROM OCO30310 WHERE pgm_nm='" + className + "' AND src_ip_addr='" + ipAddress + "'";
            ResultSet   resultSet = getStmt ().executeQuery (query);
            if (resultSet.next ())
                return resultSet.getString (1);
        } catch (Exception e) {
            System.out.println ("getPgmId Exception : " + e);
        }
        return "*****";
    }

	public void executeUpdate (String query) {
		try {
			stmt.executeUpdate (query);
		} catch (Exception e) {
			System.out.println ("executeUpdate:query = " + query);
			System.out.println ("Exception: " + e);
		}
	}
	
	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	public Statement getStmt() {
		return stmt;
	}

	public void setStmt(Statement stmt) {
		this.stmt = stmt;
	}
	
	public PreparedStatement prepareStatement(String sql) throws Exception {
		return connection.prepareStatement(sql);
	}	
}

