package com.skb.mi.common;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.Charset;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.Scanner;

import org.apache.commons.cli.HelpFormatter;

public class SqlRunner {
	boolean				connected = false;
	boolean				impConnected = false;
	DBController		dbController;
	DBController		impDbController;
	String				dbName;
	String				impDbName;
	boolean				spool = false;
	String				spoolFileName;
	FileOutputStream	spoolFw;
	ConfigManager		configManager;
	
	public SqlRunner() {
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		configManager = new ConfigManager(cfgFile);
		try {
			run();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void run() throws Exception {

		Scanner console = new Scanner(System.in);
		System.out.print("SqlRunner> ");
		while (console.hasNextLine()) {
			String cmd = console.nextLine().trim();
			execute(cmd);
		}
		if (spoolFw != null) {
			spoolFw.close();
		}
	}
	
	private boolean execute(String cmd) throws Exception {
		if ("EXIT".equalsIgnoreCase(cmd) || "QUIT".equalsIgnoreCase(cmd) || "BYTE".equalsIgnoreCase(cmd)) {
			return false;
		} else if ("HELP".equalsIgnoreCase(cmd)) {
			System.out.println("connect {databaseName}");
			System.out.println("connect2 {databaseName} (forward only, read only)");
			System.out.println("connect_import {databaseName}");
			System.out.println("spool {fileName}/off");
			System.out.println("disconnect");
			System.out.println("exit");
		} else if ("DISCONNECT".equalsIgnoreCase(cmd)) {
			if (connected) {
				// disconnect DB
				dbController.closeDB();
				System.out.println(String.format("disconnected %s", dbName));
				dbName = null;
				connected = false;
			}
			if (impConnected) {
				// disconnect DB
				impDbController.closeDB();
				System.out.println(String.format("disconnected %s", impDbName));
				impDbName = null;
				impConnected = false;
			}
		} else if ("STATUS".equalsIgnoreCase(cmd)) {
			if (connected) {
				System.out.println(String.format("connected %s", dbName));
			}
			if (impConnected) {
				System.out.println(String.format("connected %s (import)", impDbName));
			}
			if (spool) {
				System.out.println(String.format("spool %s", spoolFileName));
			} else {
				System.out.println("spool off");
			}
		} else {
			String[] tokens = cmd.split("\\s");
			if (tokens.length > 1) {
				if ("CONNECT".equalsIgnoreCase(tokens[0])) {
					if (connected) {
						// disconnect DB
						dbController.closeDB();
						System.out.println(String.format("disconnected %s", dbName));
						connected = false;
					}
					dbName = tokens[1];
					// connect
					String dbUrl = configManager.getConfig(dbName, Constants.DB_URL);
					String userName = configManager.getConfig(dbName, Constants.USER_NAME);
					String password = configManager.getConfig(dbName, Constants.PASSWORD);
					
					if (dbUrl != null && userName != null && password != null) {
						try {
							System.out.println(String.format("connecting %s (%s),(%s),(%s)", dbName, dbUrl, userName, password));
							dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
							System.out.println(String.format("connected %s", dbName));
							connected = true;
						} catch (Exception e) {
							e.printStackTrace();
						}
					} else {
						System.out.println(String.format("failed to get %s (%s,%s,%s)", dbName, dbUrl, userName, password));
					}
				} else if ("CONNECT2".equalsIgnoreCase(tokens[0])) {
						if (connected) {
							// disconnect DB
							dbController.closeDB();
							System.out.println(String.format("disconnected %s", dbName));
							connected = false;
						}
						dbName = tokens[1];
						// connect
						String dbUrl = configManager.getConfig(dbName, Constants.DB_URL);
						String userName = configManager.getConfig(dbName, Constants.USER_NAME);
						String password = configManager.getConfig(dbName, Constants.PASSWORD);
						
						if (dbUrl != null && userName != null && password != null) {
							try {
								System.out.println(String.format("connecting %s (%s),(%s),(%s)", dbName, dbUrl, userName, password));
								dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
								System.out.println(String.format("connected %s", dbName));
								connected = true;
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
				} else if ("CONNECT_IMPORT".equalsIgnoreCase(tokens[0])) {
					if (impConnected) {
						// disconnect DB
						impDbController.closeDB();
						System.out.println(String.format("disconnected %s", dbName));
						impConnected = false;
					}
					impDbName = tokens[1];
					// connect
					String dbUrl = configManager.getConfig(impDbName, Constants.DB_URL);
					String userName = configManager.getConfig(impDbName, Constants.USER_NAME);
					String password = configManager.getConfig(impDbName, Constants.PASSWORD);
					
					if (dbUrl != null && userName != null && password != null) {
						try {
							System.out.println(String.format("connecting %s (%s),(%s),(%s)", impDbName, dbUrl, userName, password));
							impDbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
							//impDbController.getConnection().setAutoCommit(false);
							System.out.println(String.format("connected %s", impDbName));
							impConnected = true;
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				} else if ("SPOOL".equalsIgnoreCase(tokens[0])) {
					if ("OFF".equalsIgnoreCase(tokens[1])) {
						if (spoolFw != null) {
							spoolFw.close();
							spoolFw = null;
						}
						spool = false;
					} else {
						spoolFileName = tokens[1];
						spoolFw = new FileOutputStream(spoolFileName);
						spool = true;
					}
				} else {
					if (connected == false) {
						System.out.println("not connected");
						return true;
					}
					try {
						System.out.println("call: " + cmd);
						dbController.getStmt().setFetchSize(1000);
						ResultSet rs = dbController.getStmt().executeQuery(cmd);
						ResultSetMetaData rsmd = rs.getMetaData();
						int columnCnt = rsmd.getColumnCount();
						if (spool) {
							spoolFw.write("-------------------------------------------------------".getBytes());
							spoolFw.write('\n');
							spoolFw.write(cmd.getBytes(Charset.forName("eucKR")));
							spoolFw.write("-------------------------------------------------------".getBytes());
							spoolFw.write('\n');
							for (int i = 1; i <= columnCnt; i ++) {
								spoolFw.write(rsmd.getColumnName(i).getBytes());
								spoolFw.write('|');
							}
							spoolFw.write('\n');
							spoolFw.write("-------------------------------------------------------".getBytes());
							spoolFw.write('\n');
							int recNo = 0;
							while (rs.next()) {
								for (int i = 1; i <= columnCnt; i ++) {
									String colVal = rs.getString(i);
									if (colVal != null) {
										spoolFw.write(colVal.getBytes(Charset.forName("eucKR")));
									}
									spoolFw.write('|');
								}
								spoolFw.write('\n');
								recNo ++;
								if (recNo % 10000 == 0) {
									System.out.println(String.format("reading %d records ", recNo));
								}
							}
							spoolFw.write("-------------------------------------------------------".getBytes());
							spoolFw.write('\n');
							System.out.println(String.format("read %d records ", recNo));
							
						} else if (impConnected) {
							String tableName = getTableName(cmd);
							String insertQuery = makeInsertQuery(rsmd, tableName);
							System.out.println(insertQuery);
							PreparedStatement stmt = impDbController.prepareStatement(insertQuery);
							int recNo = 0;
							while (rs.next()) {
								for (int i = 1; i <= columnCnt; i ++) {
									stmt.setString(i, rs.getString(i));
								}
								//stmt.executeUpdate();
								stmt.addBatch();
								recNo ++;
								if (recNo % 10000 == 0) {
									System.out.println(String.format("reading %d records ", recNo));
									stmt.executeBatch();
									//impDbController.getConnection().commit();
								}
							}
							stmt.executeBatch();
							//impDbController.getConnection().commit();
							stmt.close();
							System.out.println(String.format("read %d records ", recNo));
						} else {
							if (columnCnt == 0) return true;
							for (int i = 1; i <= columnCnt; i ++) {
								System.out.print(rsmd.getColumnName(i) + " | ");
							}
							System.out.println();
							System.out.println("-------------------------------------------------------");
							int recNo = 0;
							while (rs.next()) {
								System.out.print(String.format("[%8d] ", ++ recNo));
								for (int i = 1; i <= columnCnt; i ++) {
									System.out.print(rs.getString(i) + " | ");
								}
								System.out.println();
							}
							System.out.println("-------------------------------------------------------");
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
		if (connected) {
			System.out.print("SqlRunner:" + dbName + "> ");
		} else {
			System.out.print("SqlRunner> ");
		}
		return true;
	}
	
	private String getTableName(String query) {
		int pos = query.toUpperCase().indexOf("FROM");
		String[] tokens = query.substring(pos+4).trim().split(" ");
		return tokens[0];
	}
	
	private String makeInsertQuery(ResultSetMetaData rsmd, String tableName) throws Exception {
		int columnCnt = rsmd.getColumnCount();
		StringBuilder sb = new StringBuilder();
		sb.append("insert into ");
		sb.append(tableName);
		sb.append(" (");
		for (int i = 1; i <= columnCnt; i ++) {
			if (i == 1) {
				sb.append(rsmd.getColumnName(i));				
			} else {
				sb.append(",");
				sb.append(rsmd.getColumnName(i));
			}
		}
		sb.append(") values (");
		for (int i = 1; i <= columnCnt; i ++) {
			//System.out.println(String.format("(%s),(%d),(%s)", rsmd.getColumnName(i), rsmd.getColumnType(i), rsmd.getColumnTypeName(i)));
			if (i > 1) {
				sb.append(",");
			}
			if ("DATE".equals(rsmd.getColumnTypeName(i))) { // DATE
				sb.append("TO_DATE(?,'YYYY-MM-DD HH24:MI:SS.?')");
			} else {
				sb.append("?");
			}
		}
		sb.append(")");
		return sb.toString();
	}

	public static void main(String[] args) {
		EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("SqlRunner", envManager.getOptions());
    		System.exit(0);
    	}
    	new SqlRunner();
	}

}
