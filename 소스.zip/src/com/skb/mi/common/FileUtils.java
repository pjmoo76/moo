package com.skb.mi.common;

import java.io.File;

public class FileUtils {
	public static boolean mkdir(String dirName) {
		File targetDir = new File(dirName);
		
		if(!targetDir.exists()) {
			if (targetDir.mkdirs() == false) {
				return false;
			}	
		}
		return true;
	}
		
	public static boolean rename(String oldFileName, String newFileName) {
		
		FileUtils.deleteFile(newFileName);
		
		File target = new File(newFileName);
			
		String dirName = target.getParent();
		
		if(dirName != null) {
			File targetDir = new File(dirName);
			
			if(!targetDir.exists()) {
				if (targetDir.mkdirs() == false) {
					return false;
				}	
			}
		}
		
		File file = new File(oldFileName);
		return file.renameTo(new File(newFileName));
	}
	
	public static boolean deleteFile(String FileName) {
		File fl = new File(FileName);
		if(fl.isFile()) {
			return fl.delete();
		}
		return true;
		
	}
}