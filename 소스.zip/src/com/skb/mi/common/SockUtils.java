package com.skb.mi.common;

import java.io.InputStream;

public class SockUtils {
	static public int read(InputStream is, byte[] data, int len) throws Exception {
		int off = 0;
		while (true) {
			int n = is.read(data, off, len-off);
			if (n == -1) {
				break;
			}
			off += n;
			if (off == len) break;
		}
		return off;
	}

	static public byte[] read(InputStream is, byte[] header, int maxDataLen, byte[] tail) throws Exception {
		byte[] buf = new byte[header.length];
		for (int i = 0; i < header.length; i ++) {
			int n = is.read(buf, i, 1);
			if (n <= 0) {
				throw new Exception("failed to read");
			}
			//logger.debug(String.format("(%d), 0x%02X, 0x%02X", i, buf[i], header[i]));
			if (buf[i] != header[i]) {
				throw new Exception("invalid header");
			}
		}
		return read(is, maxDataLen, tail);
	}

	static public byte[] read(InputStream is, int maxDataLen, byte[] tail) throws Exception {
		byte[] buf = new byte[maxDataLen + tail.length];
		for (int i = 0; i < maxDataLen; i ++) {
			int n = is.read(buf, i, 1);
			if (n <= 0) {
				throw new Exception("failed to read");
			}
			//logger.debug(String.format("buf[%d] = 0x%02X", i, buf[i]));
			int off = i - tail.length + 1;
			if (off >= 0) {
				boolean tailMatched = true;
				for (int j = 0; j < tail.length; j ++) {
					//logger.debug(String.format("(%d,%d), 0x%02X, 0x%02X", j, off+j, buf[off+j], tail[j]));
					if (buf[off+j] != tail[j]) {
						tailMatched = false;
						break;
					}
				}
				if (tailMatched) {
					//logger.debug("off=" + off);
					if (off == 0) return null;
					byte[] data = new byte[off];
					System.arraycopy(buf, 0, data, 0, off);
					return data;
				}
			}
		}
		throw new Exception("failed to find tail");
	}
}
