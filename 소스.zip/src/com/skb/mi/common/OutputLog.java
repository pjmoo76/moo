package com.skb.mi.common;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.StringTokenizer;

public class OutputLog {
	// Log 관련 상수
	public	final	String		FILE_EXTENSION 					 = ".log" ;
	public	final	String		DIRECTORY						 = "logs";


	// Log 관련 변수
	private	boolean				fileCheck;
	private String				className;
	private String				directory;
	private FileOutputStream	fileOutputStream ;
	private	Calendar			lastDate;
	private Object				lock;
	
	public OutputLog (boolean fileCheck, String className, String absolutePath) {
		lock = new Object();
		StringTokenizer tokens = new StringTokenizer (className, ".");
		tokens.nextToken ();					// com
		tokens.nextToken ();					// skb
		tokens.nextToken ();					// mi
		tokens.nextToken ();					// realtime
		setClassName (tokens.nextToken ());
		setFileCheck (fileCheck) ;
		setDirectory (absolutePath) ;
		setFileOutputStream ( null ) ;
		
		if ( fileCheck ) {						// 파일 Log가 true일 경우만 검사
			File	fout ;
			fout = new File (directory + File.separator + DIRECTORY);
			if (!fout.exists())
				fout.mkdir();
			openFileStream ();
		}
	}
	
	// Log 메세지를 출력한다.
	public void	write ( String message ) {
		synchronized (lock) {
			Calendar rightNow = Calendar.getInstance();
			StackTraceElement caller = OutputLog.getCaller();
			
			String trace = null;
			if (caller != null) {
				String[] ss = caller.getClassName().split("\\.");
				trace = String.format("[%s]%s.%s (%s:%d)", Thread.currentThread().getName(), ss[ss.length - 1], caller.getMethodName(), caller.getFileName(), caller.getLineNumber());
			}
			String	outputMsg = String.format( "[%04d-%02d-%02d %02d:%02d:%02d.%03d]%s %s\n",
	            	 rightNow.get ( Calendar.YEAR ), 
					 rightNow.get ( Calendar.MONTH ) + 1, 
					 rightNow.get ( Calendar.DAY_OF_MONTH ), 
					 rightNow.get ( Calendar.HOUR_OF_DAY ), 
					 rightNow.get ( Calendar.MINUTE ), 
					 rightNow.get ( Calendar.SECOND ), 
					 rightNow.get(Calendar.MILLISECOND),
					 trace,
					 message ) ;

			if (rightNow.get(Calendar.DAY_OF_MONTH) != lastDate.get(Calendar.DAY_OF_MONTH)) {
				close ();
				openFileStream ();
			}
			
			if ( isFileCheck () )
				outputFileLog (outputMsg) ;
		}
	}
	
	public void write(Exception e) {
		write(getStackTraceString(e));
	}
	
	public void write(String message, Exception e) {
		write(message + ": " + getStackTraceString(e));
	}
	
	private String getStackTraceString(Exception e) {
		if (e == null) return "exception is null";
		StringBuffer sb = new StringBuffer();
		int i = 0;
		sb.append(e.getClass().getName() + ": " + e.getMessage());
		for (StackTraceElement element : e.getStackTrace()) {
			String[] ss = element.getClassName().split("\\.");
			sb.append(String.format("\n[%d] %s.%s(%s:%d)", i, ss[ss.length - 1], element.getMethodName(), element.getFileName(), element.getLineNumber()));
			i ++;
		}
		return sb.toString();
	}

	// FileStream을 Open한다.
	public void openFileStream () {
		lastDate = Calendar.getInstance();
		String	fileName = String.format("%s%s_%04d%02d%02d",
					getClassName (),
					FILE_EXTENSION,
					lastDate.get ( Calendar.YEAR ), 
					lastDate.get ( Calendar.MONTH ) + 1, 
					lastDate.get ( Calendar.DAY_OF_MONTH ));
		try {
			fileOutputStream = new FileOutputStream (directory + File.separator + DIRECTORY + File.separator + fileName, true) ;
		} catch ( FileNotFoundException fe ) {
			System.out.println ( directory + File.separator + className + "을 생성할 수 없습니다.") ;
			setFileCheck ( false ) ;
		} catch ( SecurityException se ) {
			System.out.println ( directory + File.separator + className + "을 다른 프로세스에서 사용하고 있습니다.") ;
			setFileCheck ( false ) ;
		}
	}
	
	// FileStream을 Close한다.
	public void close () {
		// 파일 Close
		try {
			fileOutputStream.close() ;
		} catch ( IOException e ) {
			System.out.println ( directory + File.separator + className + " Close 도중에 에러가 발생되었습니다.") ;
		}

	}
	
	// File에 출력한다.
	public void outputFileLog (String message ) {
		// 파일 오픈 및 Append
		try {
			byte []	tmp = message.getBytes () ;
			fileOutputStream.write( tmp ) ;
		} catch ( FileNotFoundException fe ) {
//			System.out.println ( directory + File.separator + className + "을 생성할 수 없습니다.") ;
			setFileCheck ( false ) ;
		} catch ( SecurityException se ) {
//			System.out.println ( directory + File.separator + className + "을 다른 프로세스에서 사용하고 있습니다.") ;
			setFileCheck ( false ) ;
		} catch ( IOException ioe ) {
//			System.out.println ( directory + File.separator + className + "에 로그 저장시 에러 발생되었습니다.") ;
//			System.out.println( ioe ) ;
		}
	}
	
	/************************************ Getter/Setter 함수들 *****************************************/
	public boolean isFileCheck() {
		return fileCheck;
	}
	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public void setFileCheck(boolean fileCheck) {
		this.fileCheck = fileCheck;
	}

	public String getDirectory() {
		return directory;
	}

	public void setDirectory(String directory) {
		this.directory = directory;
	}

	public FileOutputStream getFileOutputStream() {
		return fileOutputStream;
	}
	public void setFileOutputStream(FileOutputStream fileOutputStream) {
		this.fileOutputStream = fileOutputStream;
	}
	public Calendar getLastDate() {
		return lastDate;
	}
	public void setLastDate(Calendar lastDate) {
		this.lastDate = lastDate;
	}

	private static StackTraceElement getCaller() {
		StackTraceElement[] list = Thread.currentThread().getStackTrace();

		for(int i = 1; i < list.length; ++i) {
			if(!list[i].getClassName().equals(OutputLog.class.getName())) {
				return list[i];
			}
		}
		return null;
	}

}
