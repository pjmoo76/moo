package com.skb.mi.common;

import java.util.Arrays;
import java.util.Calendar;

public class Cron {
	private boolean[] runDays;
	private boolean[] runHours;
	private boolean[] runMinutes;
	private boolean[] runMonths;
	private boolean[] runWeeks;

	private long lastMstime;
	
	private	String	line;

	public Cron() {
		
	}
	
	public String getCronString() {
		return this.line;
	}
	
	public void setCron(String line) throws Exception {
		this.line = line;
		String[] ss = line.split(" ");
		if (ss.length < 5 || ss.length > 6) {
			throw new Exception("WORD IS NOT 6");
		}

		this.runMinutes = new boolean[60];
		this.runHours = new boolean[24];
		this.runDays = new boolean[31];
		this.runMonths = new boolean[12];
		this.runWeeks = new boolean[7];
		Arrays.fill(this.runMinutes, false);
		Arrays.fill(this.runHours, false);
		Arrays.fill(this.runDays, false);
		Arrays.fill(this.runMonths, false);
		Arrays.fill(this.runWeeks, false);

		this.parse(this.runMinutes, ss[0], 0);
		this.parse(this.runHours, ss[1], 0);
		this.parse(this.runDays, ss[2], 1);
		this.parse(this.runMonths, ss[3], 1);
		this.parse(this.runWeeks, ss[4], 0);
	}

	private void parse(boolean[] period, String format, int first_value) throws Exception {
		if (format.equals("*")) {
			Arrays.fill(period, true);
		} else {
			String[] ss = format.split(",");
			String[] arg7 = ss;
			int arg6 = ss.length;
			//System.out.println(String.format("(format=%s),(first_value=%d),(ss.length=%d)", format, first_value, ss.length));

			for (int arg5 = 0; arg5 < arg6; ++arg5) {
				String s = arg7[arg5];
				//System.out.println("arg5="+arg5+",s:"+s+",first_value="+first_value);
				period[Integer.parseInt(s) - first_value] = true;
			}
		}

	}

	public boolean isOnTime(long mstime) {
		boolean ret = false;

		if (this.lastMstime == 0L) {
			this.lastMstime = mstime / 60000L;
			this.lastMstime *= 60000L;
		}

		if (mstime < this.lastMstime + 60000L) {
			return false;
		}

		Calendar nowTime = Calendar.getInstance();
		nowTime.setTimeInMillis(mstime);
		ret = this.runMinutes[nowTime.get(12)]
				&& this.runHours[nowTime.get(11)]
				&& this.runDays[nowTime.get(5) - 1]
				&& this.runMonths[nowTime.get(2)]
				&& this.runWeeks[nowTime.get(7) - 1];

		if (ret) {
			this.lastMstime = mstime / 60000L;
			this.lastMstime *= 60000L;
		}

		return ret;
	}

	public boolean isOnTime2(long mstime) {
		Calendar nowTime = Calendar.getInstance();
		nowTime.setTimeInMillis(mstime);
		boolean ret = this.runMinutes[nowTime.get(12)]
				&& this.runHours[nowTime.get(11)]
				&& this.runDays[nowTime.get(5) - 1]
				&& this.runMonths[nowTime.get(2)]
				&& this.runWeeks[nowTime.get(7) - 1];

		return ret;
	}
	
	static public boolean in(Cron from, Cron to, long mstime) {
		Calendar nowTime = Calendar.getInstance();
		nowTime.setTimeInMillis(mstime);
		
		int minPos = nowTime.get(12);
		int hourPos = nowTime.get(11);
		int dayPos = nowTime.get(5)-1;
		int monthPos = nowTime.get(2);
		int weekPos = nowTime.get(7)-1;
		
		String baseTimeStr = String.format("%02d%02d%02d%02d", (monthPos+1), (dayPos+1), hourPos, minPos);
		
		int fromMinPos = -1;
		int fromHourPos = -1;
		int fromDayPos = -1;
		int fromMonthPos = -1;
		int fromWeekPos = -1;
		
		for (int i = minPos; i >= 0; i --) {
			if (from.runMinutes[i]) {
				fromMinPos = i;
				break;
			}
		}
		if (fromMinPos == -1) {
			for (int i = 59; i > minPos; i --) {
				if (from.runMinutes[i]) {
					fromMinPos = i;
					break;
				}
			}			
		}
		
		for (int i = hourPos; i >= 0; i --) {
			if (from.runHours[i]) {
				fromHourPos = i;
				break;
			}
		}
		if (fromHourPos == -1) {
			for (int i = 23; i > hourPos; i --) {
				if (from.runHours[i]) {
					fromHourPos = i;
					break;
				}
			}
			
		}
		for (int i = dayPos; i >= 0; i --) {
			if (from.runDays[i]) {
				fromDayPos = i;
				break;
			}
		}
		if (fromDayPos == -1) {
			for (int i = 30; i > fromDayPos; i --) {
				if (from.runDays[i]) {
					fromDayPos = i;
					break;
				}
			}			
		}
		for (int i = monthPos; i >= 0; i --) {
			if (from.runMonths[i]) {
				fromMonthPos = i;
				break;
			}
		}
		if (fromMonthPos == -1) {
			for (int i = 11; i > monthPos; i --) {
				if (from.runMonths[i]) {
					fromMonthPos = i;
					break;
				}
			}			
		}
		for (int i = weekPos; i >= 0; i --) {
			if (from.runWeeks[i]) {
				fromWeekPos = i;
				break;
			}
		}
		if (fromWeekPos == -1) {
			for (int i = 6; i > weekPos; i --) {
				if (from.runWeeks[i]) {
					fromWeekPos = i;
					break;
				}
			}			
		}
				
		String fromTimeStr = String.format("%02d%02d%02d%02d", (fromMonthPos+1), (fromDayPos+1)-(weekPos-fromWeekPos), fromHourPos, fromMinPos);

		int toMinPos = -1;
		int toHourPos = -1;
		int toDayPos = -1;
		int toMonthPos = -1;
		int toWeekPos = -1;
		
		for (int i = minPos; i < 60; i ++) {
			if (to.runMinutes[i]) {
				toMinPos = i;
				break;
			}
		}
		if (toMinPos == -1) {
			for (int i = 0; i < minPos; i ++) {
				if (to.runMinutes[i]) {
					toMinPos = i;
					break;
				}
			}
			
		}
		for (int i = hourPos; i < 24; i ++) {
			if (to.runHours[i]) {
				toHourPos = i;
				break;
			}
		}
		if (toHourPos == -1) {
			for (int i = 0; i < hourPos; i ++) {
				if (to.runHours[i]) {
					toHourPos = i;
					break;
				}
			}
			
		}
		for (int i = dayPos; i < 31; i ++) {
			if (to.runDays[i]) {
				toDayPos = i;
				break;
			}
		}
		if (toDayPos == -1) {
			for (int i = 0; i < dayPos; i ++) {
				if (to.runDays[i]) {
					toDayPos = i;
					break;
				}
			}			
		}
		for (int i = monthPos; i < 12; i ++) {
			if (to.runMonths[i]) {
				toMonthPos = i;
				break;
			}
		}
		if (toMonthPos == -1) {
			for (int i = 0; i < monthPos; i ++) {
				if (to.runMonths[i]) {
					toMonthPos = i;
					break;
				}
			}			
		}
		for (int i = weekPos; i < 7; i ++) {
			if (to.runWeeks[i]) {
				toWeekPos = i;
				break;
			}
		}
		if (toWeekPos == -1) {
			for (int i = 0; i < weekPos; i ++) {
				if (to.runWeeks[i]) {
					toWeekPos = i;
					break;
				}
			}			
		}

		String toTimeStr = String.format("%02d%02d%02d%02d", (toMonthPos+1), (toDayPos+1)-(weekPos-toWeekPos), toHourPos, toMinPos);

		/*
		System.out.println("from="+from.getCronString()+",to="+to.getCronString());
		System.out.println("fromMonthPos="+fromMonthPos+",toMonthPos="+toMonthPos);
		System.out.println("fromDayPos="+fromDayPos+",toDayPos="+toDayPos);
		System.out.println("weekPos="+weekPos+",fromWeekPos="+fromWeekPos+",toWeekPos="+toWeekPos);
		System.out.println("fromHourPos="+fromHourPos+",toHourPos="+toHourPos);
		System.out.println("fromMinPos="+fromMinPos+",toMinPos="+toMinPos);
		System.out.println("baseTimeStr=" + baseTimeStr);
		System.out.println("fromTimeStr="+fromTimeStr);
		System.out.println("toTimStr="+toTimeStr);
		*/
		
		if (baseTimeStr.compareTo(fromTimeStr) >= 0 && baseTimeStr.compareTo(toTimeStr) <= 0) {
			return true;
		}
		return false;
	}
	
}
