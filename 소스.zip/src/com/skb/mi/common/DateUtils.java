package com.skb.mi.common;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;

public class DateUtils {
	public static ZonedDateTime getUnixTime(String unixTime) {
		try {
			long time = Long.parseLong(unixTime);
			Instant instant = Instant.ofEpochSecond(time);
			return instant.atZone(ZoneId.of("Asia/Seoul"));
		} catch (Exception e) {
			return ZonedDateTime.now();
		}
	}

	public static String getDate(ZonedDateTime zdTime) {
		return String.format("%04d%02d%02d", zdTime.getYear(), zdTime.getMonthValue(), zdTime.getDayOfMonth());
	}

	public static String getTime(ZonedDateTime zdTime) {
		return String.format("%04d%02d%02d%02d%02d%02d",
				zdTime.getYear(), zdTime.getMonthValue(), zdTime.getDayOfMonth(),
				zdTime.getHour(), zdTime.getMinute(), zdTime.getSecond());
	}
	
	public static long getUnixTimeStamp(String dateTimeFormat, String dateTimeStr) {
		SimpleDateFormat sdFormat = new SimpleDateFormat(dateTimeFormat); 
		Date date = null;
		try {
			date = sdFormat.parse(dateTimeStr);
		} catch (ParseException e) {
			return 0;
		}
		long timestamp = date.getTime();
		return timestamp;
	}
	
	public static String getTimeStampToDateTimeStr(String dateTimeFormat, long timeStamp) {
		Date date = new Date(timeStamp);
		SimpleDateFormat sdFormat = new SimpleDateFormat(dateTimeFormat);
		String formattedDateTimeStr = sdFormat.format(date);
		return formattedDateTimeStr;
	}
	
	public static String getAddedTime(String dateTimeFormat, int addedSec) {
		Date dDate = new Date();
		dDate = new Date(dDate.getTime()+(1000*addedSec));
		SimpleDateFormat dSdf = new SimpleDateFormat(dateTimeFormat);
		return dSdf.format(dDate);
	}

	public static String getAddedTime(String dateTimeFormat, String dateTimeStr, int addedSec) {
		SimpleDateFormat dSdf = new SimpleDateFormat(dateTimeFormat); 
		Date dDate = null;
		try {
			dDate = dSdf.parse(dateTimeStr);
			Date newDate = new Date(dDate.getTime() + (1000*addedSec));
			return dSdf.format(newDate);
		} catch (ParseException e) {
			return null;
		}
	}
	
	public static long getDiffSeconds(String dateTimeFormat, String fromTimeStr, String toTimeStr) {
		try {
			SimpleDateFormat dSdf = new SimpleDateFormat(dateTimeFormat);
			Date fromDate = dSdf.parse(fromTimeStr);
			Date toDate = dSdf.parse(toTimeStr);
			long diffSeconds = (toDate.getTime() - fromDate.getTime()) / 1000;
			return diffSeconds;
		} catch (Exception e) {
			return 0;
		}
	}

	public static void main(String[] args) {
		//Instant instant = Instant.now();
		//long time = instant.getEpochSecond();
		/*
		String unixTime = "1533615600";
		ZonedDateTime zdTime = DateUtils.getUnixTime(unixTime);
		String mntrDt = DateUtils.getDate(zdTime);
		String mntrDtm = DateUtils.getTime(zdTime);
		System.out.println(String.format("(%s),(%s),(%s)", unixTime, mntrDt, mntrDtm));
		*/
		/*
		long unixTime = getUnixTimeStamp("yyyyMMddHHmmss","20210607161102");
		System.out.println(unixTime/1000);
		*/
		long diffSeconds = getDiffSeconds("yyyyMMddHHmmss", "20220725164731", "20220725174932");
		System.out.println(diffSeconds);
	}
}
