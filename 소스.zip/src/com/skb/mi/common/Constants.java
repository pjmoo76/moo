package com.skb.mi.common;

public class Constants {
	public static final String ADAMS_DB		= "ADAMS_DB";
	public static final String ADAMSBS_DB	= "ADAMSBS_DB";
	public static final String UNMS_FAULT	= "UnmsFault";
	public static final String UNMS_FAULT2	= "UnmsFault2";
	public static final String UNMS_PSTN_TRAFFIC	= "UnmsPstnTraffic";
	public static final String UNMS_PSTN_TRAFFIC2	= "UnmsPstnTraffic2";
	public static final String UNMS_VOIP_TRAFFIC2	= "UnmsVoipTraffic2";
	public static final String UNMS_RELAY	= "UnmsRelay";
	public static final String SBNNMS		= "SBNNMS";
	public static final String TEAMS		= "TEAMS";
	public static final String TEAMS1		= "TEAMS1";
	public static final String TEAMS2		= "TEAMS2";
	public static final String TEAMS3		= "TEAMS3";
	public static final String BMS			= "BMS";
	public static final String DAPS			= "DAPS";
	public static final String FOMS			= "FOMS";
	public static final String RMS			= "RMS";
	public static final String MID_KNIGHT	= "MidKnight";
	public static final String MID_KNIGHT_CAPITAL	= "MidKnightCapital";
	public static final String MID_KNIGHT_NON_CAPITAL	= "MidKnightNonCapital";
	public static final String WEB_PUSH		= "WebPush";
	public static final String UNMS_MSG_WEB_PUSH	= "UnmsMsgWebPush";
	public static final String RELAY		= "Relay";
	public static final String RELAY_SERVER	= "RelayServer";
	public static final String NEIF_DB		= "NEIF_DB";
	public static final String CM_BATCH		= "CM_BATCH";
	public static final String SWING_MQ		= "SWING_MQ";
	public static final String VOC_GET		= "VOC_GET";
	public static final String ITMS_VOC_MGR	= "ITMS_VOC_MGR";
	public static final String CCA_GET		= "CCA_GET";
	public static final String FAULT_GET	= "FAULT_GET";
	public static final String TOSS_GET		= "TOSS_GET";
	public static final String UNMS_DABL_V52_PUT	= "UNMS_DABL_V52_PUT";
	public static final String UNMS_DABL_VOIP_PUT	= "UNMS_DABL_VOIP_PUT";
	public static final String SERVER_TYPE	= "SERVER_TYPE";
	public static final String BTV_NMS		= "BtvNms";
	public static final String BTV_WEB_PUSH	= "BtvWebPush";
	
	public static final String DB_URL		= "dbUrl";
	public static final String USER_NAME	= "userName";
	public static final String PASSWORD		= "password";
	public static final String IP_ADDRESS	= "ipAddress";
	public static final String PORT_NO		= "portNo";
	public static final String LISTEN_PORT_NO	= "listenPortNo";
	public static final String USER_ID		= "userId";
	public static final String AUTH_KEY	    = "authKey";

	public static final String NEXT_PASSWORD	= "nextPassword";
	public static final String CB_DB_XML		= "dbXml";
	public static final String CB_CUR_DB_XML	= "curDbXml";
	public static final String CB_NEXT_DB_XML	= "nextDbXml";
	public static final String CB_RESTART_SH	= "restartSh";

	public static final String QUEUE_MANAGER	= "queueManager";
	public static final String QUEUE_NAME		= "queueName";
	public static final String CHANNEL_NAME		= "channelName";
	public static final String CCS_ID			= "ccsId";

	public static final String COLUMN_LIST		= "columnList";
	public static final String ORG_COLUMN_LIST	= "orgColumnList";
	public static final String USER_COLUMN_LIST	= "userColumnList";

	public static final String WEB_CLIENT_LISTEN_PORT_NO	= "webClientListenPortNo";
	public static final String PSTN_IP_ADDRESS	= "pstnIpAddress";
	public static final String PSTN_PORT_NO		= "pstnPortNo";
	public static final String VOIP_IP_ADDRESS	= "voipIpAddress";
	public static final String VOIP_PORT_NO		= "voipPortNo";

	public static final String WFMS_DB		= "WFMS_DB";
	public static final String VERSION		= "version";

	public static final String SERVICE		= "SERVICE";
	public static final String EXEC_MODE	= "EXEC_MODE";
	public static final String FILE_NAME	= "FILE_NAME";

	public static final String SCHEDULE				= "schedule";
	public static final String DATABASE_NAME		= "databaseName";
	public static final String MAPPER				= "mapper";
	public static final String QUERY_LIST			= "queryList";
	public static final String HEALTH_CHECK_QUERY	= "healthCheckQuery";
	public static final String THREAD				= "thread";
	
	public static final String FAULT_ALRAM	= "FAULT_ALRAM";
	
	public static final String URL	= "url";
	
	public static final String TABLE	= "TABLE";

}
