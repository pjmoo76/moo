package com.skb.mi.common;

import java.util.Calendar;

import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class MiscUtils {
    static public String getProcessDate (int day) {
		Calendar	cal = Calendar.getInstance();
		
		cal.add (Calendar.DAY_OF_MONTH, day);
		return String.format("%04d%02d%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH));
    }
    
	static public String getDateTime() {
		Calendar	cal = Calendar.getInstance();
		return String.format("%04d-%02d-%02d %02d:%02d:%02d",
				cal.get(Calendar.YEAR),
				cal.get(Calendar.MONTH) + 1,
				cal.get(Calendar.DAY_OF_MONTH),
				cal.get(Calendar.HOUR_OF_DAY),
				cal.get(Calendar.MINUTE),
				cal.get(Calendar.SECOND));
	}

	static public String getDateTime2() {
		Calendar	cal = Calendar.getInstance();
		return String.format("%04d%02d%02d%02d%02d%02d",
				cal.get(Calendar.YEAR),
				cal.get(Calendar.MONTH) + 1,
				cal.get(Calendar.DAY_OF_MONTH),
				cal.get(Calendar.HOUR_OF_DAY),
				cal.get(Calendar.MINUTE),
				cal.get(Calendar.SECOND));
	}
	
	static public String getAlphaNumeric(String src) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < src.length(); i ++) {
			char ch = src.charAt(i);
			if (Character.isDigit(ch) || Character.isAlphabetic(ch)) {
				sb.append(ch);
			}
		}
		return sb.toString();
	}
	
	public static String getStandardDateFormatString(String src) {
		if (src == null) return null;
		String ret = getNumeric(src);
		// YYYYMMDDHHMISS
		if (ret.length() == 14) return ret;
		return src;
	}
	
	static public String getNumeric(String src) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < src.length(); i ++) {
			char ch = src.charAt(i);
			if (Character.isDigit(ch)) {
				sb.append(ch);
			}
		}
		return sb.toString();
	}
	
	static public void sleep(int milliSeconds) {
		try {
			Thread.sleep (milliSeconds);
		} catch (Exception e) {
		}
	}

	static public void setLogLevel(String logLevel) {
		Logger logger = LogManager.getRootLogger();
		if (logLevel != null) {
			if ("TRACE".equals(logLevel)) {
				logger.setLevel(Level.TRACE);
			} else if ("DEBUG".equals(logLevel)) {
				logger.setLevel(Level.DEBUG);
			} else if ("INFO".equals(logLevel)) {
				logger.setLevel(Level.INFO);
			} else if ("WARN".equals(logLevel)) {
				logger.setLevel(Level.WARN);
			} else if ("ERROR".equals(logLevel)) {
				logger.setLevel(Level.ERROR);
			} 
		}
	}

	static public void setLogLevel(Logger logger, String logLevel) {
		if (logLevel != null) {
			if ("TRACE".equals(logLevel)) {
				logger.setLevel(Level.TRACE);
			} else if ("DEBUG".equals(logLevel)) {
				logger.setLevel(Level.DEBUG);
			} else if ("INFO".equals(logLevel)) {
				logger.setLevel(Level.INFO);
			} else if ("WARN".equals(logLevel)) {
				logger.setLevel(Level.WARN);
			} else if ("ERROR".equals(logLevel)) {
				logger.setLevel(Level.ERROR);
			} 
		}
	}
	
	static public int getNextMinuteMills() {
		long mstime = System.currentTimeMillis();
		return (60 * 1000) - (int) (mstime % (60 * 1000));
	}
}
