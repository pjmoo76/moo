package com.skb.mi.common;

import java.io.File;
import java.util.Vector;

import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.DailyRollingFileAppender;
import org.apache.log4j.spi.LoggingEvent;

public class PerThreadDailyRollingFileAppender extends AppenderSkeleton {
	/*
	 * PropertyConfigurator
	 * ---
	 * append : FileAppender
	 * maxFileSize : RollingFileAppender (x)
	 * maxBackupIndex : RollingFileAppender (x)
	 * file : FileAppender
	 * layout : AppenderSkeleton
	 * conversionPattern :
	 * datePattern : DailyRollingFileAppender
	 */
 
	protected String	path;
	protected String	file;
	protected String	datePattern	= "'.'yyyy-MM-dd";
	protected boolean	fileAppend	= true;
	protected boolean	perThread	= true;
	
	private	ThreadLocal	tls			= new ThreadLocal();
	private	Vector		vecAppender	= new Vector();
	private	DailyRollingFileAppender	drf;
	
	static public String	LOG_POSTFIX	= null;

	public PerThreadDailyRollingFileAppender() {
		
	}

	@Override
	public void close() {
		if (perThread) {
			synchronized(this.vecAppender) {
				for (int i = 0; i < this.vecAppender.size(); i ++) {
					DailyRollingFileAppender drf = (DailyRollingFileAppender) this.vecAppender.get(i);
					drf.close();
				}
			}
		} else {
			if (drf != null) drf.close();
		}
	}

	@Override
	public boolean requiresLayout() {
		return true;
	}

	@Override
	protected void append(LoggingEvent event) {
		if (perThread) {
			drf = (DailyRollingFileAppender) this.tls.get();
			if (drf == null) {
				try {
					drf = new DailyRollingFileAppender();
					drf.setAppend(this.fileAppend);
					drf.setLayout(this.layout);
					drf.setDatePattern(this.datePattern);
					String fileName = "";
					if (LOG_POSTFIX == null) {
						fileName = this.path + File.separator + getMainClassName() + ".log." + Thread.currentThread().getName();
					} else {
						fileName = this.path + File.separator + getMainClassName() + "." + LOG_POSTFIX + ".log." + Thread.currentThread().getName();
					}
					drf.setFile(fileName);
					drf.activateOptions();
					this.tls.set(drf);
					vecAppender.add(drf);
				} catch (Exception e) {
					drf = null;
				}
			}
		} else {
			if (drf == null) {
				drf = new DailyRollingFileAppender();
				drf.setAppend(this.fileAppend);
				drf.setLayout(this.layout);
				drf.setDatePattern(this.datePattern);
				String fileName = "";
				if (LOG_POSTFIX == null) {
					fileName = this.path + File.separator + getMainClassName() + ".log";
				} else {
					fileName = this.path + File.separator + getMainClassName() + "." + LOG_POSTFIX + ".log";
				}
				drf.setFile(fileName);
				drf.activateOptions();
			}
		}
		if (drf != null) {
			drf.append(event);
		}
	}
	
	private String getMainClassName() {
		StackTraceElement[] list = Thread.currentThread().getStackTrace();
		String className = list[list.length-1].getClassName();
		int pos = className.lastIndexOf('.');
		if (pos != -1) {
			className = className.substring(pos+1);
		}
		pos = className.indexOf('$');
		if (pos == -1) {
			return className;
		} else {
			return className.substring(0, pos);
		}
	}

	public void setAppend(boolean flag) {
		this.fileAppend = flag;
	}
	
	public void setDatePattern(String pattern) {
		this.datePattern = pattern;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public void setPerThread(boolean flag) {
		this.perThread = flag;
	}

}
