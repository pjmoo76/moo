package	com.skb.mi.common;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.OutputStream;

import java.net.Socket;

import java.util.Calendar;
import java.util.LinkedList;

import java.sql.Statement;

import com.skb.mi.common.DBController;
import com.skb.mi.vo.FaultVO;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/*
 * BaseAdamsBatch Class
 * -. ADAMS DB 접속 및 사용
 * -. JSON 만들기
 * -. Push Processor와 연동
 * -. log 관리
 */
public class BaseAdamsBatch {
    final public String        ABSOLUTE_PATH = "/home/miuser/kmkang/data";

	// Push Processor 관련 상수
	final public String			GENERATE_EVENT 			= "GEN";
	final public String			CLEAR_EVENT 			= "CLR";
	
	final public String			GENERATED_FAULT_CODE	= "01";
	final public String			CLEARED_FAULT_CODE		= "02";
	final public String			GENERATED_FAULT_NM 		= "장애중";
	final public String			CLEARED_FAULT_NM		= "장애해제";

    final public String         DABL_NET_CL_CD_1 = "1"; // OCO20101, 1:가입자망
    final public String         DABL_NET_CL_CD_2 = "2"; // OCO20101, 2:기간망
    final public String         DABL_NET_CL_CD_3 = "3"; // OCO20101, 3:선로
    final public String         DABL_NET_CL_CD_4 = "4"; // OCO20101, 4:기간망(가입자국소영향)
    final private String        DABL_NET_CL_CD_5 = "5"; // OCO20101, 5:기타

	// errorStatus 값
	final private int			NORMAL 					= 0;
	final private int			ERROR_DB 				= 1;
	final private int			ERROR_PUSH 				= 2;					
	final private int			ERROR_DB_PUSH 			= 3;

	int							errorStatus;
	LinkedList<JSONObject>		notSendJson;

	// DB 정보
	DBController			dbController;
	String						dbUrl;
	String						userName;
	String						password;

	// PUSH Processor 정보
	int							pushPortNo;
	Socket						pushSocket;
	String						pushIpAddress;
	OutputStream				pushOutputStream;

	public BaseAdamsBatch () {
		errorStatus = NORMAL;
		try {
			connectDB ();
		} catch (Exception e) {
			errorStatus = ERROR_DB;
		}

		try {
			connectPush ();
		} catch (Exception e) {
			errorStatus = ERROR_PUSH;
			if (errorStatus == NORMAL)
				dbController.closeDB ();
			else
				errorStatus = ERROR_DB_PUSH;
		}
	}

	public Statement getStatement () {
		return dbController.getStmt ();
	}

	public void close () {
		try {
			dbController.closeDB ();
			pushOutputStream.close ();
			pushSocket.close ();
		} catch (Exception e) {
		}
	}

    public void connectDB () throws Exception {
        FileReader  fileReader = new FileReader (ABSOLUTE_PATH + File.separator + "db.info");
        BufferedReader bufferedReader = new BufferedReader (fileReader);
        dbUrl = bufferedReader.readLine ();
        userName = bufferedReader.readLine ();
        password = bufferedReader.readLine ();
        bufferedReader.close ();
        fileReader.close ();
        System.out.println ("Url : " + dbUrl);
        System.out.println ("userName : " + userName);
        System.out.println ("password : " + password);
        dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
    }

    public void connectPush () throws Exception {
        FileReader  fileReader = new FileReader (ABSOLUTE_PATH + File.separator + "push.info");
        BufferedReader bufferedReader = new BufferedReader (fileReader);
        pushIpAddress = bufferedReader.readLine ();
        pushPortNo = Integer.parseInt (bufferedReader.readLine ());
        bufferedReader.close ();
        fileReader.close ();

		pushSocket = new Socket (pushIpAddress, pushPortNo);
		pushOutputStream = pushSocket.getOutputStream ();
    }


	// Push Processor에 전달할 JSON을 만든다.
    public void makeJsonAndSend (FaultVO faultVo, String faultStatus) {
        JSONObject  obj = new JSONObject ();
        if (faultStatus.equals (GENERATE_EVENT)) {
            obj.put ("DABL_LCL_CD", faultVo.getDablLclCd ());
            obj.put ("DABL_LCL_NM", faultVo.getDablLclNm ());
            obj.put ("DABL_MCL_CD", faultVo.getDablMclCd ());
            obj.put ("DABL_MCL_NM", faultVo.getDablMclNm ());
            obj.put ("DABL_CD", faultVo.getDablCd ());
            obj.put ("DABL_NM", faultVo.getDablNm ());
            obj.put ("DABL_ST_NM", GENERATED_FAULT_NM);
            obj.put ("OCCR_DTM", faultVo.getOccrDtm ());
            obj.put ("OCCR_RCV_DTM", faultVo.getOccrRcvDtm ());
            obj.put ("NMS_CD", faultVo.getNmsCd ());
            obj.put ("NMS_NM", faultVo.getNmsNm ());
            obj.put ("NMS_DABL_NUM_CTT", faultVo.getNmsDablNumCtt ());
            obj.put ("NET_CL_CD", faultVo.getNetClCd ());
            obj.put ("NET_CL_NM", faultVo.getNetClNm());
            obj.put ("DABL_GR_CD", faultVo.getDablGrCd ());
            obj.put ("MKT_DIV_ORG_ID", faultVo.getDivId ());
            obj.put ("MKT_DIV_ORG_NM", faultVo.getDivNm ());
            obj.put ("TEAM_ORG_ID", faultVo.getTeamId ());
            obj.put ("TEAM_ORG_NM", faultVo.getTeamNm ());
            obj.put ("INFO_CNTR_CD", faultVo.getMgmtTpoCd ());
            obj.put ("INFO_CNTR_NM", faultVo.getMgmtTpoNm ());
            obj.put ("DISTB_CNTR_CD", faultVo.getTpoCd ());
            obj.put ("DISTB_CNTR_NM", faultVo.getTpoNm ());
            obj.put ("EQUIP_IP_ADDR", faultVo.getEquipIpAddress ());
            obj.put ("EQUIP_ID", faultVo.getEquipId ());
            obj.put ("EQUIP_NM", faultVo.getEquipNm ());
            obj.put ("EQUIP_TID_VAL", faultVo.getTid ());
            obj.put ("EQUIP_MDL_CD", faultVo.getEquipMdlCd ());
            obj.put ("EQUIP_MDL_NM", faultVo.getEquipMdlNm ());
            obj.put ("DABL_DESC", faultVo.getDablDesc ());
            obj.put ("DABL_DUP_YN", faultVo.getDablDupYn ());
            if (faultVo.getDablLclCd ().equals ("01")) {        // 장비장애
                obj.put ("DABL_OCC_LOC_DESC", faultVo.getDablOccrLocDesc ());
                obj.put ("DABL_DUP_CNT", "1");
                obj.put ("DABL_DUP_CNT_1", "1" );
                obj.put ("DABL_DUP_CNT_2", "1" );
                obj.put ("DABL_DUP_CNT_3", "1" );
                obj.put ("OPER_DABL_YN", faultVo.getOperDablYn ());
                obj.put ("NET_OP_NUM", faultVo.getNoticeId ());
                obj.put ("EQUIP_SET_LOC_DESC", faultVo.getEquipSetLocDesc ());
                obj.put ("DMG_SCRBT_CNT", faultVo.getPingCnt());
                obj.put ("COLUMN_1", "");
                obj.put ("COLUMN_2", "");
                obj.put ("COLUMN_3", "");
                obj.put ("COLUMN_4", "");
                obj.put ("COLUMN_5", "");
                obj.put ("COLUMN_6", "");
                obj.put ("COLUMN_7", "");
                obj.put ("TM_TYP_CD", "");
                obj.put ("TM_CTT", "");
                obj.put ("INCOMM_BIZR_ID", "");
                obj.put ("COLUMN_8", "");
                obj.put ("COLUMN_9", "");
                obj.put ("MODULE_EQUIP_ID", "");
                obj.put ("MSC_MODULE_NM", "");
                obj.put ("COLUMN_10", "");
                obj.put ("ROUT_NUM", "");
                obj.put ("ROUT_NM", "");
                obj.put ("COLUMN_11", "");
                obj.put ("COLUMN_12", "");
                obj.put ("DSST_YN", "");
                obj.put ("DSSTR_YN", "");
            } else if (faultVo.getDablLclCd ().equals ("02")) { // 회선장애
                obj.put ("DABL_OCC_LOC_DESC", faultVo.getDablOccrLocDesc ());
                obj.put ("DABL_DUP_CNT", "1");
                obj.put ("DABL_DUP_CNT_1", "1" );
                obj.put ("DABL_DUP_CNT_2", "1" );
                obj.put ("DABL_DUP_CNT_3", "1" );
                obj.put ("OPER_DABL_YN", faultVo.getOperDablYn ());
                obj.put ("NET_OP_NUM", faultVo.getNoticeId ());
                obj.put ("EQUIP_SET_LOC_DESC", faultVo.getEquipSetLocDesc ());
                obj.put ("DMG_SCRBT_CNT", faultVo.getPingCnt());
                obj.put ("U_ORG_ID", faultVo.getUOrgId ());
                obj.put ("U_ORG_NM", faultVo.getUOrgNm ());
                obj.put ("L_ORG_ID", faultVo.getLOrgId ());
                obj.put ("L_ORG_NM", faultVo.getLOrgNm ());
                obj.put ("COLUMN_13", "");
                obj.put ("COLUMN_14", "");
                obj.put ("CUST_NUM", faultVo.getCustNum ());
                obj.put ("COLUMN_15", "");
                obj.put ("LINE_NUM", faultVo.getLineNum ());
                obj.put ("RING_NUM", faultVo.getRingId ());
                obj.put ("RING_NM", faultVo.getRingNm ());
                obj.put ("COLUMN_16", "");
                obj.put ("COLUMN_17", "");
                obj.put ("COLUMN_18", "");
                obj.put ("COLUMN_19", "");
                obj.put ("COLUMN_20", "");
                obj.put ("COLUMN_21", "");
                obj.put ("COLUMN_22", "");
                obj.put ("DSSTR_YN", "");
            } else {                                            // 트래픽장애
                obj.put ("ASS_NUM", "");
                obj.put ("ROUT_NUM", "");
                obj.put ("ROUT_NM", "");
                obj.put ("INTERFACE_ID", "");
                obj.put ("INTERFACE_NM", "");
                obj.put ("TM_TYP_CD", "");
                obj.put ("TM_CTT", "");
                obj.put ("INCOMM_BIZR_ID", "");
                obj.put ("INCOMM_BIZR_NM", "");
            }
            obj.put ("kind", faultStatus);
        } else {
            obj.put ("RLSE_RCV_DTM", faultVo.getOccrDtm ());
            obj.put ("DABL_ST_NM", CLEARED_FAULT_NM);
            obj.put ("kind", faultStatus);
        }
        obj.put ("DABL_NUM", faultVo.getDablNum ());
        obj.put ("DABL_ST_CD", faultVo.getDablStCd());
        System.out.println (obj.toJSONString());

		sendPush (obj);
	}

    public void sendPush (JSONObject obj) {
        try {
            pushOutputStream.write (obj.toJSONString ().getBytes ());
            pushOutputStream.flush ();
        } catch (Exception e) {
            System.out.println ("============ " + e);
            notSendJson.add (obj);
            sendJson ();
        }
    }

    public void sendJson () {
        JSONObject  obj;
        int size = notSendJson.size ();
        System.out.println ("================ size : " + size);
        try {
            try {
                pushOutputStream.close ();
            } catch (Exception e1) {
            }
            try {
                pushSocket.close ();
            } catch (Exception e2) {
            }
            pushSocket = new Socket ("12.4.96.92", 32771);
            pushOutputStream = pushSocket.getOutputStream ();
            for (int index = 0; index < size; ++ index) {
                obj = notSendJson.get (0);
                pushOutputStream.write (obj.toJSONString ().getBytes ());
                pushOutputStream.flush ();
                System.out.println (obj.toJSONString ());
                notSendJson.remove (0);
                Thread.sleep (100);
            }
            pushOutputStream.flush ();
        } catch (Exception e) {
            System.out.println ("======== sendJson ============ " + e);
        }
    }

    public void printHexaCode (int length, byte[] buffer) {
		int count = 0;
    	for (int index = 0; index < length; ++ index) {
/*
			if (buffer [index] == ESC)
				System.out.println ();
*/
			if (count++ % 20 == 0)
				System.out.println ();
    		System.out.printf ("%02x.", buffer [index]);
		}
    	System.out.println ();
    }

    public String queryEquipInfo (String equipMgmtNum) {
        return  "SELECT "
              + "   a.EQUIP_ID"
              + "   ,a.EQUIP_NM"
              + "   ,a.TPO_NM"
              + "   ,a.EQUIP_IP_ADDR"
              + "   ,a.EQUIP_MDL_CD"
              + "   ,a.EQUIP_MDL_NM"
              + "   ,a.EQUIP_SET_LOC_DESC"
              + "   ,a.TPO_CD"
              + "   ,b.TPO_NM AS MGMT_TPO_NM"
              + "   ,b.TPO_CD AS MGMT_TPO_CD"
              + "   ,c.TEAM_ORG_NM AS TEAM_NM"
              + "   ,c.TEAM_ORG_ID AS TEAM_ID"
              + "   ,c.MKT_DIV_ORG_NM AS DIV_NM"
              + "   ,c.MKT_DIV_ORG_ID AS DIV_ID"
              + " FROM ("
              + "   SELECT "
              + "       a.EQUIP_ID"
              + "       ,a.EQUIP_NM"
              + "       ,a.EQUIP_IP_ADDR"
              + "       ,a.EQUIP_MDL_CD"
              + "       ,a.EQUIP_SET_LOC_DESC"
              + "       ,c.EQUIP_MDL_NM"
              + "       ,b.TPO_CD"
              + "       ,b.TPO_NM"
              + "       ,b.MGMT_TPO_CD"
              + "   FROM OIV10100 a,OIV10300 b,OIV10200 c"
              + "   WHERE a.TPO_CD=b.TPO_CD(+) "
              + "       AND a.EQUIP_MDL_CD=c.EQUIP_MDL_CD"
              + "       AND a.EQUIP_MGMT_NUM='" + equipMgmtNum + "') a"
              + "           , OIV10300 b, OIV10301 c, OES20100 d "
              + "WHERE a.MGMT_TPO_CD=b.TPO_CD(+) "
              + "   AND b.TPO_CD=c.TPO_CD(+)"
              + "   AND c.TEAM_ORG_ID=d.ORG_ID(+)";
    }

    // 오늘 중복 건수 구하는 쿼리
    public String queryDupInfo (String nmsDablNumCtt) {
        String  query = "SELECT "
             + "    count(*) "
             + "FROM OMN30100 "
             + "WHERE TO_CHAR(SYSDATE, 'YYYYMMDD') = SUBSTR (OCCR_DTM, 1, 8)"
             + "      AND NMS_DABL_NUM_CTT = '" + nmsDablNumCtt + "' ";
        query += "GROUP BY EQUIP_ID";
        return query;
    }

    public String queryFaultNum (FaultVO faultVo) {
        return "SELECT DABL_NUM, TO_CHAR(OCCR_RCV_DTM,'YYYYMMDDHH24MISS') FROM OMN30100 WHERE NMS_DABL_NUM_CTT='" + faultVo.getNmsDablNumCtt () + "' AND NMS_CD='" + faultVo.getNmsCd () + "'";
	}

    public String queryEquipFault (FaultVO faultVo) {
        return "MERGE INTO OMN30100 USING DUAL"
             + " ON (NMS_DABL_NUM_CTT='" + faultVo.getNmsDablNumCtt () + "'"
             + "     AND NMS_CD='" + faultVo.getNmsCd () + "')"
//           + " WHEN MATCHED THEN ; "
             + " WHEN NOT MATCHED THEN"
             + "    INSERT ("
             + "          AUDIT_ID"
             + "          , AUDIT_DTM"
             + "          , DABL_NM"
             + "          , NMS_CD"
             + "          , NET_CL_CD"
             + "          , DABL_LCL_CD"
             + "          , DABL_ST_CD"
             + "          , DABL_GR_CD"
             + "          , DABL_RGST_CL_CD"
             + "          , DABL_EXL_YN"
             + "          , DABL_RLSE_MTHD_CD"
             + "          , DABL_OP_ST_CD"
             + "          , DABL_CHECK_YN"
             + "          , INFO_CNTR_CD"
             + "          , DISTB_CNTR_CD"
             + "          , EMCY_DABL_YN"
             + "          , EGOV_DABL_YN"
             + "          , DSSTR_YN"
             + "          , OFD_DABL_YN"
             + "          , BBNT_DABL_YN"
             + "          , OPER_DABL_YN"
             + "          , DABL_NET_CL_CD"
             + "          , DABL_NUM"
             + "          , NMS_DABL_NUM_CTT"
             + "          , OCCR_DTM"
             + "          , OCCR_RCV_DTM"
             + "          , EQUIP_ID"
             + "          , DABL_DESC"
             + "          , DABL_DUP_CNT"
             + "          , DABL_MCL_CD"
             + "          , DABL_CD"
			 + "		  , DABL_OCCR_LOC_DESC"
             + "    ) VALUES ("
             + "          'admin'"
             + "          ,SYSDATE"
             + "          ,'" + faultVo.getDablNm () + "'"
             + "          ,'" + faultVo.getNmsCd () + "'"
             + "          ,'" + faultVo.getNetClCd () + "'"
             + "          ,'" + faultVo.getDablLclCd () + "'"
             + "          ,'" + faultVo.getDablStCd() + "'"
             + "          ,'" + faultVo.getDablGrCd () + "'"
             + "          ,'  '"
             + "          ,'N'"
             + "          ,'N'"
             + "          ,'01'"
             + "          ,'N'"
             + "          ,'" + faultVo.getMgmtTpoCd () + "'"
             + "          ,'" + faultVo.getTpoCd () + "'"
             + "          ,'N'"
             + "          ,'N'"
             + "          ,'N'"
             + "          ,'N'"
             + "          ,'N'"
             + "          ,'" + faultVo.getOperDablYn () + "'"
             + "          ,'" + faultVo.getDablNetClCd () + "'"
             + "          ,(SELECT MAX(DABL_NUM) + 1 FROM OMN30100)"
             + "          ,'" + faultVo.getNmsDablNumCtt () + "'"
             + "          ,'" + faultVo.getOccrDtm () + "'"
             + "          ,SYSDATE"
             + "          ,'" + faultVo.getEquipId () + "'"
             + "          ,'" + faultVo.getDablDesc () + "'"
             + "          ,1"
             + "          ,'" + faultVo.getDablMclCd () + "'"
             + "          ,'" + faultVo.getDablCd () + "'"
             + "          ,'" + faultVo.getDablOccrLocDesc () + "'"
             + "    )";
    }

    public String queryFaultCleared (FaultVO faultVo) {
        return "UPDATE"
             + " OMN30100 SET"
             + " DABL_ST_CD='" + faultVo.getDablStCd() + "'"
             + " , RLSE_DTM='" + faultVo.getOccrDtm () + "'"
             + " , RLSE_RCV_DTM=SYSDATE"
             + ", DABL_RLSE_MTHD_CD='A'"
             + " WHERE NMS_DABL_NUM_CTT='" + faultVo.getNmsDablNumCtt () + "'"
             + "     AND NMS_CD='" + faultVo.getNmsCd () + "'";
    }

    public String getDateSecond () {
        Calendar    calendar = Calendar.getInstance ();
        return String.format ("%04d-%02d-%02d %02d:%02d:%02d",
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH) + 1,
            calendar.get(Calendar.DAY_OF_MONTH),
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            calendar.get(Calendar.SECOND));
    }

    public String getDateSecondString (String date) {
        String  str = date.substring (0, 4);
        str += date.substring (5, 7);
        str += date.substring (8, 10);
        str += date.substring (11, 13);
        str += date.substring (14, 16);
        str += date.substring (17, 19);
        return str;
    }
}
