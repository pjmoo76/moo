package com.skb.mi.realtime;

import org.apache.commons.cli.HelpFormatter;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.EnvManager;
import com.skb.mi.realtime.unms.UnmsIfVerEnum;

public class RealTimeCollectUnmsEquipV2 extends  RealTimeCollectUnmsEquip {

	public RealTimeCollectUnmsEquipV2(String[] args) {
		super(args);
		// TODO Auto-generated constructor stub
	}

	@Override
    protected void setNmsConnInfo(ConfigManager configManager) {
		equipIpAddress = configManager.getConfig(Constants.UNMS_FAULT2, Constants.IP_ADDRESS);
		equipPortNo = Integer.parseInt(configManager.getConfig(Constants.UNMS_FAULT2, Constants.PORT_NO));

    }

	@Override
    protected String getEquipId(String clctEquipNum) throws Exception {
		return clctEquipNum;
    }

	@Override
	public void selectOIV10107() throws Exception {
		// 수집 단에서 ADAMS EQUIP_ID 값으로 올라오기 때문에 별도로 OIV10107 조회할 필요 없음. 
	}
	
	@Override
	public void sendRequestPort() throws Exception {
		// Port 요청 절차 불필요.
	}

	@Override
    protected String getLoginId() {
    	return "*****";
    }
    
	@Override
    protected String getPassword() {
    	return "?????";
    }

	@Override
	protected String getDablGrCd(String str) {
		return str;
	}

	@Override
    protected UnmsIfVerEnum getIfVer() {
    	return UnmsIfVerEnum.Track2;
    }

	public static void main (String [] args) {
    	EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("RealTimeCollectUnmsEquipV2", envManager.getOptions());
    		System.exit(0);
    	}
        new RealTimeCollectUnmsEquipV2(args);
    }

}
