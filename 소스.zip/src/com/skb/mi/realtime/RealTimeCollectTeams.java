package com.skb.mi.realtime;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.sql.SQLException;
import java.sql.SQLRecoverableException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.apache.commons.cli.HelpFormatter;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.common.MiscUtils;
import com.skb.mi.common.StringUtils;
import com.skb.mi.model.OMN30203;
import com.skb.mi.realtime.teams.TeamsCircuitFaultEvent;
import com.skb.mi.realtime.teams.TeamsEquipFaultEvent;
import com.skb.mi.realtime.teams.TeamsEvent;
import com.skb.mi.realtime.teams.TeamsEventFactory;
import com.skb.mi.realtime.teams.TeamsFaultClearEvent;
import com.skb.mi.realtime.teams.TeamsManualClearEvent;
import com.skb.mi.realtime.teams.TeamsRingFaultEvent;
import com.skb.mi.thread.SendJsonThread;

public class RealTimeCollectTeams {
	
	final private int			SOCKET_TIME_OUT	= (1000*60*5);	// Time-Out 5분 설정

    final private String        EQUIP_DABL_LCL_NM   = "장비장애";
    final private String        EQUIP_DABL_MCL_CD   = "01201";
    final private String        EQUIP_DABL_MCL_NM   = "전송망장비장애";
    final private String        EQUIP_DABL_CD       = "012001";
    final private String        EQUIP_DABL_NM       = "TEAMS 장비장애";

    final private String        CIRCUIT_DABL_LCL_NM = "회선장애";
    final private String        CIRCUIT_DABL_MCL_CD = "04201";
    final private String        CIRCUIT_DABL_MCL_NM = "전송망회선장애";
    final private String        CIRCUIT_DABL_CD     = "042001";
    final private String        CIRCUIT_DABL_NM     = "TEAMS 회선장애";

    final private String        RING_DABL_LCL_NM 	= "회선장애";
    final private String        RING_DABL_MCL_CD 	= "04203";
    final private String        RING_DABL_MCL_NM 	= "전송망링장애";
    final private String        RING_DABL_CD     	= "042003";
    final private String        RING_DABL_NM     	= "TEAMS 링장애";

	final private String		NMS_CD 				= "005";	// OCO20101 테이블에 있음.
	final private String		NMS_NM 				= "TEAMS";

	final private String		NET_CL_CD 			= "02";		// 전송망
	final private String		NET_CL_NM 			= "전송망";

	final private String 		EQUIP_FAULT 		= "01";		// 01: 장비 장애
	final private String 		CIRCUIT_FAULT 		= "04"; 	// 04: 회선 장애
	final private String 		TRAFFIC_FAULT 		= "03"; 	// 03: 트래픽 장애

    final private String        GENERATE_EVENT      = "GEN";
    final private String        CLEAR_EVENT         = "CLR";

    final private String        GENERATED_FAULT_NM  = "장애중";
    final private String        CLEARED_FAULT_NM    = "장애해제";

    final private String        GENERATED_FAULT_CD  = "01";
    final private String        CLEARED_FAULT_CD    = "02";

	String						ipAddress;
	int							portNo;
	String						version;

	Socket						socket;
	InputStream					inputStream;
	OutputStream				outputStream;

    String                      pushIpAddress;
    int                         pushPortNo;

	LinkedList<JSONObject>		notSendJson;
	HashMap<String, OMN30203>	omn30203Map;	

    private Logger		logger;
	private	SqlSession	adamsSession;
	private	HashMap<String,String>	sktEquipMap;
	private	SendJsonThread	jsonSender;
	BlockingQueue<TeamsEvent>	blockingQueue;
	int		echoPeriodMin = 3;
	
    /* ics 2020-05-12 blockingQueue size */	    
	final private int		ReStart_Q_SIZE = 1000;
	final private String	START_TIME	= "000000"; 
	final private String	END_TIME	= "060000"; 
		
	/* test용도
	final private int		ReStart_Q_SIZE = 30;
	final private String	START_TIME	= "120000"; 
	final private String	END_TIME	= "180000"; 
	*/

    public RealTimeCollectTeams (String[] args) {
    	logger = LogManager.getLogger(RealTimeCollectTeams.class.getName());
    	logger.info("start");

    	loadConfig();
        notSendJson = new LinkedList<JSONObject>();

        try {
        	jsonSender = new SendJsonThread(pushIpAddress, pushPortNo, false);
			connectNms();

            //run();
			
	        blockingQueue = new LinkedBlockingQueue();	
			Runner runner = new Runner(this);
			runner.start();
			this.runSocketReceiver();
            
            outputStream.close();
            inputStream.close();
            socket.close();
        } catch (Exception e) {
        	logger.error("Exception", e);
        }
    }
    
    public void loadConfig() {
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		ipAddress = configManager.getConfig(Constants.TEAMS, Constants.IP_ADDRESS);
		portNo = Integer.parseInt(configManager.getConfig(Constants.TEAMS, Constants.PORT_NO));
		pushIpAddress = configManager.getConfig(Constants.WEB_PUSH, Constants.IP_ADDRESS);
		pushPortNo = Integer.parseInt(configManager.getConfig(Constants.WEB_PUSH, Constants.PORT_NO));
		version = configManager.getConfig(Constants.TEAMS, Constants.VERSION);

		logger.info("sbnnmsIpAddress : " + ipAddress);
		logger.info("portNo : " + portNo);
		logger.info("pushIpAddress : " + pushIpAddress);
		logger.info("pushPortNo : " + pushPortNo);
		logger.info("version : " + version);
    }

	public void connectNms() {
        boolean check = false;
        while (!check) {
        	try {
        		if (inputStream != null) inputStream.close();
        	} catch (Exception e) {
        	}
        	try {
        		if (inputStream != null) outputStream.close();
        	} catch (Exception e) {
        	}
        	try {
        		if (socket != null) socket.close();
        	} catch (Exception e) {
        	}
            try {
            	logger.info("try connecting " + ipAddress + ":" + portNo);
                socket = new Socket (ipAddress, portNo);
                logger.info("connected " + ipAddress + ":" + portNo);

                inputStream = socket.getInputStream();
                outputStream = socket.getOutputStream ();
				socket.setSoTimeout(SOCKET_TIME_OUT);
				sendLoginPacket ();

                check = true;
            } catch (Exception e) {
                logger.error("Exception", e);
                MiscUtils.sleep(100);            // 0.1초
            }
        }
	}
	
	private void run() {
		logger.info("run");

		long nextEchoTime = (System.currentTimeMillis() / 1000L) + (60*echoPeriodMin);		// 5분마다 send echo packet 
		long nextEchoDBTime = (System.currentTimeMillis() / 1000L) + (60*30);	// 30분마다 keepAliveDB
		long nextSktEqiupsLoadTime = (System.currentTimeMillis() / 1000L) + (60*60);	// 1시간마다 SKB 회선 영향을 주는 SKT 장비정보 재로딩
	
        TeamsEventFactory eventFactory = new TeamsEventFactory();
        TeamsEvent event = null;
        int errContCnt = 0;
		while (true) {
			try {
				if (adamsSession == null) {
					adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
				}
				if (event == null) {
					event = eventFactory.get(inputStream);
					errContCnt = 0;
				} else {
					// retry
					errContCnt ++;
					if (errContCnt > 3) {
						event = null;
						continue;
					}
				}
				if (event != null) {
					process(event);
					event = null;
				}
				long currentTime = System.currentTimeMillis() / 1000L;
				if (nextEchoTime < currentTime) {
					this.sendEchoPacket();
					nextEchoTime = currentTime + (60*echoPeriodMin);
				}
				if (nextEchoDBTime < currentTime) {
					this.keepAliveDB();
					nextEchoDBTime = currentTime + (60*30);
				}
				if (nextSktEqiupsLoadTime < currentTime) {
					this.loadSktEquipMap();
					nextSktEqiupsLoadTime = currentTime + (60*60);
				}

			} catch (SocketTimeoutException ste) {
				logger.error("SocketTimeoutException", ste);
				connectNms();
				nextEchoTime = (System.currentTimeMillis() / 1000L) + (60*echoPeriodMin);
			} catch (SocketException se) {
				logger.error("SocketException", se);
				connectNms();
				nextEchoTime = (System.currentTimeMillis() / 1000L) + (60*echoPeriodMin);
			} catch (SQLException sqle) {
				logger.error("SQLException", sqle);
				adamsSession.close();
				adamsSession = null;
				MiscUtils.sleep(100);
			} catch (PersistenceException pe) {
				logger.error("PersistenceException", pe);
				adamsSession.close();
				adamsSession = null;
				MiscUtils.sleep(100);
			} catch (Exception e) {
				logger.error("Exception", e);
				MiscUtils.sleep(100);
			}
		}
	}
	
	private void runSocketReceiver() {
		logger.info("runSocketReceiver");

		long nextEchoTime = (System.currentTimeMillis() / 1000L) + (60*echoPeriodMin);		// 5분마다 send echo packet 
		
        TeamsEventFactory eventFactory = new TeamsEventFactory();
		while (true) {
			try {
				if (adamsSession == null) {
					adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
				}
//				logger.debug("eventFactory.get(inputStream)");
//				logger.debug("isConnected"+socket.isConnected());
//				logger.debug("isInputShutdown"+socket.isInputShutdown());
//				logger.debug("keepAlive"+socket.getKeepAlive());				
//				logger.debug(inputStream.available());
				TeamsEvent event = eventFactory.get(inputStream);
				if (event != null) {
					blockingQueue.put(event);
				}
				long currentTime = System.currentTimeMillis() / 1000L;
				if (nextEchoTime < currentTime) {
					this.sendEchoPacket();
					nextEchoTime = currentTime + (60*echoPeriodMin);
				}
			} catch (SocketTimeoutException ste) {
				logger.error("SocketTimeoutException", ste);
				connectNms();
				nextEchoTime = (System.currentTimeMillis() / 1000L) + (60*echoPeriodMin);
			} catch (SocketException se) {
				logger.error("SocketException", se);
				connectNms();
				nextEchoTime = (System.currentTimeMillis() / 1000L) + (60*echoPeriodMin);
			} catch (Exception e) {
				logger.error("Exception", e);
				MiscUtils.sleep(100);
			}
		}
	}
	
	public void runEventHandler() {
		logger.info("runEventHandler");

		long nextEchoDBTime = (System.currentTimeMillis() / 1000L) + (60*30);	// 30분마다 keepAliveDB
		long nextSktEqiupsLoadTime = (System.currentTimeMillis() / 1000L) + (60*60);	// 1시간마다 SKB 회선 영향을 주는 SKT 장비정보 재로딩
		long nextTeamsFaultCodeLoadTime = (System.currentTimeMillis() / 1000L) + (60*60);	// 1시간마다 SKB 회선 영향을 주는 SKT 장비정보 재로딩
		
		TeamsEvent event = null;
        int errContCnt = 0;
		while (true) {
			try {
				if (adamsSession == null) {
					adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
				}
				if (event == null) {
					event = blockingQueue.take();
					logger.debug(">size:" + blockingQueue.size());

					/**
					 * 시간 체크 ics
					 * adamsproxyint01에 설정
					 * FOMS의 경우 blockingQueue Size 클경우 새벽에 Restart 한다.
					 * 재기동은 crontab에 정의 되어 있음. mon_adams_daemon.sh
					 */
					if(blockingQueue.size() >= ReStart_Q_SIZE) {
						SimpleDateFormat timeFormat = new SimpleDateFormat("HHmmss");
						Date current_date = new Date(System.currentTimeMillis());
						String curTime = timeFormat.format(current_date);
						
						logger.debug ("[curTime.compareTo(START_TIME)] = " + curTime.compareTo(START_TIME));
						logger.debug ("[curTime.compareTo(END_TIME)] = " + curTime.compareTo(END_TIME));

						if(curTime.compareTo(START_TIME) > 0 && curTime.compareTo(END_TIME) < 0) {
							logger.debug ("[Process exit]");	
							System.exit(0);
						}else {
							//logger.debug ("[Process not exit]");					
						}
					}
					/**/
					
					
					errContCnt = 0;
				} else {
					// retry
					errContCnt ++;
					if (errContCnt > 3) {
						event = null;
						continue;
					}
				}
				if (event != null) {
					process(event);
					event = null;
				}
				long currentTime = System.currentTimeMillis() / 1000L;
				if (nextEchoDBTime < currentTime) {
					this.keepAliveDB();
					nextEchoDBTime = currentTime + (60*30);
				}
				if (nextSktEqiupsLoadTime < currentTime) {
					this.loadSktEquipMap();
					nextSktEqiupsLoadTime = currentTime + (60*60);
				}
				if (nextTeamsFaultCodeLoadTime < currentTime) {
					this.loadTeamsFaultCodeMap();
					nextTeamsFaultCodeLoadTime = currentTime + (60*60);
				}
			} catch (SQLException sqle) {
				logger.error("SQLException", sqle);
				adamsSession.close();
				adamsSession = null;
				MiscUtils.sleep(100);
			} catch (PersistenceException pe) {
				logger.error("PersistenceException", pe);
				adamsSession.close();
				adamsSession = null;
				MiscUtils.sleep(100);
			} catch (Exception e) {
				logger.error("Exception", e);
				MiscUtils.sleep(100);
			}
		}
	}
	
	private void loadSktEquipMap() throws Exception {
		List<Long> sktEquipNums = adamsSession.selectList("RealtimeTeams.selectSktEquipForSKB", null);
		if (sktEquipMap == null) {
			sktEquipMap = new HashMap<String, String>();
		} else {
			sktEquipMap.clear();
		}
		if (sktEquipNums != null) {
			int i = 0;
			for(Long sktEquipNum : sktEquipNums) {
				logger.info(String.format("SktEquipMap[%d]%s", ++i, sktEquipNum.toString()));
				sktEquipMap.put(sktEquipNum.toString(), sktEquipNum.toString());
			}
			logger.info("SktEquipMap size:" + sktEquipNums.size());
		}
	}
	
	private boolean isSktEquipForSkb(String neId) throws Exception {
		if (sktEquipMap == null) {
			loadSktEquipMap();
		}
		String val = sktEquipMap.get(neId);
		if (val != null) {
			return true;
		} else {
			return false;
		}
	}
	
	// TEAMS 관련 장애 코드 조회해서 분류별로 Hashtable에 저장한다.
	private void loadTeamsFaultCodeMap() throws Exception {
		
		if (omn30203Map == null) {
			omn30203Map = new HashMap<String, OMN30203>();
		} else {
			omn30203Map.clear();
		}
		
		// DABL_LCL_CD, DABL_LCL_NM, DABL_MCL_CD, DABL_MCL_NM, DABL_CD, DABL_CD_NM, NMS_DABL_CD
		List<OMN30203> omn30203List = (List) adamsSession.selectList("RealtimeTeams.selectOMN30203", null);
		if (omn30203List != null) {
			int i=0;
			for (OMN30203 omn30203 : omn30203List) {
				++i;
				String key = omn30203.getDablMclNm()+omn30203.getDablCdNm();
				omn30203Map.put(key, omn30203);				
			}
			logger.debug("TEAMS 장애코드 총 : "+i + "건 로딩완료");
		}
	}
	
	@SuppressWarnings("unchecked")
	private void process(TeamsEvent event) throws Exception {
		//logger.debug(String.format("strp01-> getNeId[%s] getMngGroupCd[%s], getTrmsNetMgmtOwnerCd[%s], version[%s]",event.getNeId(),event.getMngGroupCd(), event.getTrmsNetMgmtOwnerCd(), version)); //ics
		if ("Y18".equals(version)) {
			if (!TeamsEvent.SKB.equals(event.getTrmsNetMgmtOwnerCd())) {
				if (isSktEquipForSkb(event.getNeId()) == false) {
					logger.debug(String.format("[%s] neId(%s) is not affected to SKB", event.getMngGroupCd(), event.getNeId()));
					return;
				}
				logger.info(String.format("SKT_SKB [%s] neId(%s) is affected to SKB", event.getMngGroupCd(), event.getNeId()));
			}
			if("-1".equals(event.getNeId())){ /*20200715 ics add*/
				logger.debug(String.format("[%s] neId(%s) is not affected to SKB", event.getMngGroupCd(), event.getNeId()));
				return;
			}
			
		} else {			
			if (!TeamsEvent.SKB.equals(event.getTrmsNetMgmtOwnerCd())) {
				return;
			}
			if (TeamsEvent.RING_FAULT.equals(event.getEventType())) {
				return;
			}
		}
		//logger.debug(String.format("strp02-> getNeId[%s] getMngGroupCd[%s], getTrmsNetMgmtOwnerCd[%s], version[%s]",event.getNeId(),event.getMngGroupCd(), event.getTrmsNetMgmtOwnerCd(), version)); //ics

		if (TeamsEvent.EQUIP_FAULT.equals(event.getEventType())) {
			TeamsEquipFaultEvent equipFaultEvent = (TeamsEquipFaultEvent) event;
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("NMS_CD", NMS_CD);
			jsonObject.put("NMS_NM", NMS_NM);
			jsonObject.put("NET_CL_CD", NET_CL_CD);
			jsonObject.put("NET_CL_NM", NET_CL_NM);
			jsonObject.put("LINE_DABL_TYP_CD", "N");
			jsonObject.put("kind", GENERATE_EVENT);
			jsonObject.put("EQUIP_ID", 	equipFaultEvent.getNeId());
			jsonObject.put("EQUIP_TID_VAL", equipFaultEvent.getTid());
			jsonObject.put("EQUIP_IP_ADDR", equipFaultEvent.getIpAddr());
			jsonObject.put("DABL_GR_CD", 	equipFaultEvent.getDablGrCd());
			jsonObject.put("PORT_DESC", equipFaultEvent.getPortDescr());
			jsonObject.put("DABL_DESC", equipFaultEvent.getReason());
			jsonObject.put("TPO_CD", equipFaultEvent.getOrgId());
			jsonObject.put("TPO_NM", equipFaultEvent.getOrgName());
			jsonObject.put("OCCR_DTM", equipFaultEvent.getOccurTime());
			jsonObject.put("OCCR_RCV_DTM", MiscUtils.getDateTime ());
			jsonObject.put("OPER_DABL_YN", equipFaultEvent.getWorkYn());
			jsonObject.put("NMS_DABL_NUM_CTT", equipFaultEvent.getAlarmNo());
			jsonObject.put("DABL_ST_CD", GENERATED_FAULT_CD);
			jsonObject.put("DABL_ST_NM", GENERATED_FAULT_NM); 
			jsonObject.put("EQUIP_NM", 	equipFaultEvent.getNeName());
			jsonObject.put("EQUIP_MDL_CD", equipFaultEvent.getModelCd());
			jsonObject.put("EQUIP_MDL_NM", equipFaultEvent.getModelName());
			if (omn30203Map == null) {
				loadTeamsFaultCodeMap();
			}
			OMN30203 omn30203 = omn30203Map.get(equipFaultEvent.getModelName()+"장애"+equipFaultEvent.getReason());
			if(omn30203 == null)
			{
				jsonObject.put("DABL_LCL_CD", EQUIP_FAULT);		// 대분류 코드
				jsonObject.put("DABL_LCL_NM", EQUIP_DABL_LCL_NM);	// 대분류 명
				jsonObject.put("DABL_MCL_CD", EQUIP_DABL_MCL_CD);	// 중분류 코드
				jsonObject.put("DABL_MCL_NM", EQUIP_DABL_MCL_NM);	// 중분류 명
				jsonObject.put("DABL_CD", EQUIP_DABL_CD);			// 소분류 코드
				jsonObject.put("DABL_NM", EQUIP_DABL_NM);			// 소분류 명

			}else{
				jsonObject.put("DABL_LCL_CD", EQUIP_FAULT);		// 대분류 코드
				jsonObject.put("DABL_LCL_NM", omn30203.getDablLclNm());	// 대분류 명
				jsonObject.put("DABL_MCL_CD", omn30203.getDablMclCd());	// 중분류 코드
				jsonObject.put("DABL_MCL_NM", omn30203.getDablMclNm());	// 중분류 명
				jsonObject.put("DABL_CD", omn30203.getDablCd());			// 소분류 코드
				jsonObject.put("DABL_NM", omn30203.getDablCdNm());			// 소분류 명
			}
			
			jsonObject.put("DABL_OCCR_LOC_DESC", equipFaultEvent.getLocation());	// 발생 위치
			jsonObject.put("DABL_PORT_DESC", equipFaultEvent.getPortDescr());	// 포트정보
			jsonObject.put("TRMS_NET_MGMT_OWNR_CD", equipFaultEvent.getTrmsNetMgmtOwnerCd());
			jsonObject.put("USE_USG_DESC", equipFaultEvent.getEquipUsage());
			jsonObject.put("TROOM_NM", equipFaultEvent.getTrRoomName());
			jsonSender.put(jsonObject);
		} else if (TeamsEvent.CIRCUIT_FAULT.equals(event.getEventType())) {
			TeamsCircuitFaultEvent circuitFaultEvent = (TeamsCircuitFaultEvent) event;
			HashMap<String, Object> hmap = adamsSession.selectOne("RealtimeTeams.selectCustInfo", circuitFaultEvent.getLineNo());
			if(hmap == null || "08".equals((String) hmap.get("LINE_ST_CD"))) return;
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("NMS_CD", NMS_CD);
			jsonObject.put("NMS_NM", NMS_NM);
			jsonObject.put("NET_CL_CD", NET_CL_CD);
			jsonObject.put("NET_CL_NM", NET_CL_NM);
			jsonObject.put("LINE_DABL_TYP_CD", "N");
			jsonObject.put("kind", GENERATE_EVENT);
			jsonObject.put("NMS_ALARM_NO", circuitFaultEvent.getNmsAlarmNo());
			jsonObject.put("ALARM_NO", circuitFaultEvent.getAlarmNo());
			jsonObject.put("EQUIP_ID", 	circuitFaultEvent.getNeId());
			jsonObject.put("EQUIP_TID_VAL", circuitFaultEvent.getTid());
			jsonObject.put("EQUIP_IP_ADDR", circuitFaultEvent.getIpAddr());
			jsonObject.put("DABL_GR_CD", circuitFaultEvent.getDablGrCd());
			jsonObject.put("PORT_DESC", circuitFaultEvent.getPortDescr());
			jsonObject.put("DABL_DESC", circuitFaultEvent.getReason());
			jsonObject.put("TPO_CD", circuitFaultEvent.getOrgId());
			jsonObject.put("TPO_NM", circuitFaultEvent.getOrgName());
			jsonObject.put("OCCR_DTM", circuitFaultEvent.getOccurTime());
			jsonObject.put("OCCR_RCV_DTM", MiscUtils.getDateTime ());
			jsonObject.put("OPER_DABL_YN", circuitFaultEvent.getWorkYn());
			jsonObject.put("NMS_DABL_NUM_CTT", circuitFaultEvent.getAlarmNo());
			jsonObject.put("DABL_ST_CD", GENERATED_FAULT_CD);
			jsonObject.put("DABL_ST_NM", GENERATED_FAULT_NM);
			jsonObject.put("EQUIP_NM", 	circuitFaultEvent.getNeName());
			jsonObject.put("EQUIP_MDL_CD", circuitFaultEvent.getModelId());
			jsonObject.put("EQUIP_MDL_NM", circuitFaultEvent.getModelName());
			jsonObject.put("DABL_OCCR_LOC_DESC", circuitFaultEvent.getLocation()); // 발생 위치
			jsonObject.put("DABL_PORT_DESC", circuitFaultEvent.getPortDescr());	// 포트정보
			jsonObject.put("DABL_LCL_CD", CIRCUIT_FAULT); // 대분류 코드
			jsonObject.put("DABL_LCL_NM", CIRCUIT_DABL_LCL_NM); // 대분류 명
			jsonObject.put("DABL_MCL_CD", CIRCUIT_DABL_MCL_CD); // 중분류 코드
			jsonObject.put("DABL_MCL_NM", CIRCUIT_DABL_MCL_NM); // 중분류 명
			jsonObject.put("DABL_CD", CIRCUIT_DABL_CD); // 소분류 코드
			jsonObject.put("DABL_NM", CIRCUIT_DABL_NM); // 소분류 명
			jsonObject.put("LINE_NUM", (String) hmap.get("LINE_NUM")); // 회선 번호
			jsonObject.put("CUST_NUM", circuitFaultEvent.getCustNo()); // 고객 번호
			jsonObject.put("CUST_NM", circuitFaultEvent.getCustName());
			jsonObject.put("CHRGR_ID", (String) hmap.get("SALE_CHRGR_ID")); 
			jsonObject.put("CHRGR_NM", (String) hmap.get("SALE_CHRGR_NM"));
			jsonObject.put("LINE_NM", (String) hmap.get("LINE_NM"));
			jsonObject.put("LINE_CL_CD", (String) hmap.get("LINE_CL_CD"));
			jsonObject.put("LINE_CL_NM", (String) hmap.get("LINE_CL_NM"));
			jsonObject.put("SVC_TECH_MTHD_CD", (String) hmap.get("SVC_TECH_MTHD_CD"));
			jsonObject.put("SVC_TECH_MTHD_NM", (String) hmap.get("SVC_TECH_MTHD_NM"));
			jsonObject.put("SUP_TPO_CD", (String) hmap.get("SUP_TPO_CD"));
			jsonObject.put("SUP_TPO_NM", (String) hmap.get("SUP_TPO_NM"));
			jsonObject.put("SUB_TPO_CD", (String) hmap.get("SUB_TPO_CD"));
			jsonObject.put("SUB_TPO_NM", (String) hmap.get("SUB_TPO_NM"));
			jsonObject.put("SPEED_CD", (String) hmap.get("SPEED_CD"));
			jsonObject.put("SPEED_NM", (String) hmap.get("SPEED_NM"));
			jsonObject.put("SVC_MGMT_NUM", (String) hmap.get("SVC_MGMT_NUM"));
			jsonObject.put("CUST_CHRTIC_CD", (String) hmap.get("CUST_CHRTIC_CD"));
			jsonObject.put("CUST_CHRTIC_NM", (String) hmap.get("CUST_CHRTIC_NM"));				
			jsonObject.put("MEMO_CTT1", (String) hmap.get("MEMO_CTT1"));				
			jsonObject.put("MEMO_CTT2", (String) hmap.get("MEMO_CTT2"));				
			jsonObject.put("MEMO_CTT3", (String) hmap.get("MEMO_CTT3"));				

			// sample
			// K0004513|N75088|N00935|A10202|N00935|A10202|N00935|||N
			// C0008708|A10202|A10202|A10202|A10202|A10202|A10202|||Y
			if(StringUtils.isEmpty(circuitFaultEvent.getRasId())) {
				jsonObject.put("LINE_DABL_TYP_CD", "N");
			}else {
				String[] items = circuitFaultEvent.getRasId().split("\\|");
				if(items.length >= 10) {
					jsonObject.put ("LINE_DABL_TYP_CD", items[9]);
				}else {
					jsonObject.put ("LINE_DABL_TYP_CD", "N");
				}
			}
			jsonObject.put("SUP_EQUIP_ID", circuitFaultEvent.getuOrgId());
			jsonObject.put("SUP_EQUIP_NM", circuitFaultEvent.getuOrgName());
			jsonObject.put("SUB_EQUIP_ID", circuitFaultEvent.getlOrgId());
			jsonObject.put("SUB_EQUIP_NM", circuitFaultEvent.getlOrgName());
			jsonObject.put("RING_NM", circuitFaultEvent.getRingName());
			jsonObject.put("DMG_LINE_CNT", "0");
			jsonObject.put("TRMS_NET_MGMT_OWNR_CD", circuitFaultEvent.getTrmsNetMgmtOwnerCd());
			jsonObject.put("USE_USG_DESC", circuitFaultEvent.getEquipUsage());
			jsonObject.put("TROOM_NM", circuitFaultEvent.getTrRoomName());
			jsonObject.put("NET_NUM", circuitFaultEvent.getRingId());
			jsonObject.put("TRUNK_NUM", circuitFaultEvent.getTrunkId());
			jsonObject.put("TRUNK_NM", circuitFaultEvent.getTrunkName());
			jsonSender.put(jsonObject);
		} else if (TeamsEvent.RING_FAULT.equals(event.getEventType())) {
			TeamsRingFaultEvent ringFaultEvent = (TeamsRingFaultEvent) event;
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("NMS_CD", NMS_CD);
			jsonObject.put("NMS_NM", NMS_NM);
			jsonObject.put("NET_CL_CD", NET_CL_CD);
			jsonObject.put("NET_CL_NM", NET_CL_NM);
			jsonObject.put("LINE_DABL_TYP_CD", "N");
			jsonObject.put("NMS_ALARM_NO", ringFaultEvent.getNmsAlarmNo());
			jsonObject.put("ALARM_NO", ringFaultEvent.getAlarmNo());
			jsonObject.put("kind", GENERATE_EVENT);
			jsonObject.put("EQUIP_ID", 	ringFaultEvent.getNeId());
			jsonObject.put("EQUIP_TID_VAL", ringFaultEvent.getTid());
			jsonObject.put("EQUIP_IP_ADDR", ringFaultEvent.getIpAddr());
			jsonObject.put("DABL_GR_CD", ringFaultEvent.getDablGrCd());
			jsonObject.put("PORT_DESC", ringFaultEvent.getPortDescr());
			jsonObject.put("DABL_DESC", ringFaultEvent.getReason());
			jsonObject.put("TPO_CD", ringFaultEvent.getOrgId());
			jsonObject.put("TPO_NM", ringFaultEvent.getOrgName());
			jsonObject.put("OCCR_DTM", ringFaultEvent.getOccurTime());
			jsonObject.put("OCCR_RCV_DTM", MiscUtils.getDateTime());
			jsonObject.put("OPER_DABL_YN", ringFaultEvent.getWorkYn());
			jsonObject.put("NMS_DABL_NUM_CTT", ringFaultEvent.getAlarmNo());
			jsonObject.put("DABL_ST_CD", GENERATED_FAULT_CD);
			jsonObject.put("DABL_ST_NM", GENERATED_FAULT_NM);
			jsonObject.put("EQUIP_NM", 	ringFaultEvent.getNeName());
			jsonObject.put("EQUIP_MDL_CD", ringFaultEvent.getModelId());
			jsonObject.put("EQUIP_MDL_NM", ringFaultEvent.getModelName());
			jsonObject.put("DABL_LCL_CD", CIRCUIT_FAULT);		// 대분류 코드
			jsonObject.put("DABL_LCL_NM", CIRCUIT_DABL_LCL_NM);// 대분류 명
			jsonObject.put("DABL_MCL_CD", RING_DABL_MCL_CD);	// 중분류 코드
			jsonObject.put("DABL_MCL_NM", RING_DABL_MCL_NM);	// 중분류 명
			jsonObject.put("DABL_CD", RING_DABL_CD);			// 소분류 코드
			jsonObject.put("DABL_NM", RING_DABL_NM);			// 소분류 명			
			jsonObject.put("NET_DABL_SRC_CTT", ringFaultEvent.getNetworkAlarmReason());
			jsonObject.put("DABL_OCCR_LOC_DESC", ringFaultEvent.getLocation());
			jsonObject.put("DABL_PORT_DESC", ringFaultEvent.getPortDescr());
			jsonObject.put("NET_NUM", ringFaultEvent.getRingId());
			jsonObject.put("RING_NM", ringFaultEvent.getRingName());
			jsonObject.put("TRUNK_NUM", ringFaultEvent.getTrunkId());
			jsonObject.put("TRUNK_NM", ringFaultEvent.getTrunkName());
			jsonObject.put("TRMS_NET_MGMT_OWNR_CD", ringFaultEvent.getTrmsNetMgmtOwnerCd());
			jsonObject.put("USE_USG_DESC", ringFaultEvent.getEquipUsage());
			jsonObject.put("TROOM_NM", ringFaultEvent.getTrRoomName());
			
			// 링번호 기준으로 회선번호 조회
			/*
			HashMap<String, Object> hmap = adamsSession.selectOne("RealtimeTeams.selectLineInfoByNetNum", ringFaultEvent.getRingId());
			if (hmap != null) {
				jsonObject.put("LINE_NUM", (String) hmap.get("LINE_NUM"));		// 회선 번호
				jsonObject.put("LINE_NM", (String) hmap.get("LINE_NM"));		// 회선명
			}
			*/
			jsonSender.put(jsonObject);
		} else if (TeamsEvent.FAULT_CLEAR.equals(event.getEventType())) {
			TeamsFaultClearEvent clearEvent = (TeamsFaultClearEvent) event;
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("NMS_CD", NMS_CD);
			jsonObject.put("NMS_NM", NMS_NM);
			jsonObject.put("NET_CL_CD", NET_CL_CD);
			jsonObject.put("NET_CL_NM", NET_CL_NM);
			jsonObject.put("NMS_DABL_NUM_CTT", clearEvent.getAlarmNo());	// 장애 번호
			jsonObject.put("DABL_ST_CD", CLEARED_FAULT_CD); 					// 02 : 해제 코드
			jsonObject.put("DABL_ST_NM", CLEARED_FAULT_NM); 
			jsonObject.put("RLSE_DTM", clearEvent.getClearRTime());		// 장애 해제 시간
			jsonObject.put("RLSE_RCV_DTM", MiscUtils.getDateTime());
			jsonObject.put("kind", CLEAR_EVENT);
			jsonSender.put(jsonObject);
		} else if (TeamsEvent.MANUAL_CLEAR.equals(event.getEventType())) {
			TeamsManualClearEvent manualClearEvent = (TeamsManualClearEvent) event;
			ArrayList<TeamsFaultClearEvent> clearEventList = manualClearEvent.getClearEventList();
			for (int i = 0; i < clearEventList.size(); i ++) {
				TeamsFaultClearEvent clearEvent = clearEventList.get(i);
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("NMS_CD", NMS_CD);
				jsonObject.put("NMS_NM", NMS_NM);
				jsonObject.put("NET_CL_CD", NET_CL_CD);
				jsonObject.put("NET_CL_NM", NET_CL_NM);
				jsonObject.put("NMS_DABL_NUM_CTT", clearEvent.getAlarmNo());	// 장애 번호
				jsonObject.put("DABL_ST_CD", CLEARED_FAULT_CD); 					// 02 : 해제 코드
				jsonObject.put("DABL_ST_NM", CLEARED_FAULT_NM); 
				jsonObject.put("RLSE_DTM", clearEvent.getClearRTime());		// 장애 해제 시간
				jsonObject.put("RLSE_RCV_DTM", MiscUtils.getDateTime());
				jsonObject.put("kind", CLEAR_EVENT);
				jsonSender.put(jsonObject);
			}
		}
	}
	
	private String getValue(String value, String defaultValue) {
		if (StringUtils.isEmpty(value)) return defaultValue;
		return value;
	}

	public void sendEchoPacket() throws Exception {
		logger.debug("sendEchoPacket");
		byte [] headerPacket = {0x1b, 0x02, 0x32, 0x30, 0x30, 
						  		0x30, 0x30, 0x30, 0x30, 0x30, 		// 0x30 : ECHO패킷 
						  		0x30, 0x30, 0x30, 0x30, 0x30, 
						  		0x30, 0x30, 0x30, 0x30, 0x30
		};

		outputStream.write(headerPacket);
		outputStream.flush();
		logger.debug("sent EchoPacket");
	}

	private void sendLoginPacket() throws Exception {
		byte [] headerPacket = {0x1b, 0x02, 0x32, 0x30, 0x30, 
						  		0x30, 0x35, 0x30, 0x30, 0x30, 		// 0x35 : 로긴 요청
						  		0x31, 0x30, 0x30, 0x30, 0x30, 
						  		0x30, 0x30, 0x30, 0x32, 0x34
		};
		byte [] bodyPacket;
		String	login = "NmsConnect";

		// BodyPacket : login + 0x1f + login + 0x1f + 0x20 + 0x1f + 0x31 + 0x30;
		byte [] loginPacket;
		byte [] sendPacket = new byte [44];

		int		index = 0;

		loginPacket = login.getBytes();	

		// HeaderPacket 복사
		for (; index < headerPacket.length; ++ index)
			sendPacket [index] = headerPacket [index];

		// login 복사
		for (int i = 0; i < loginPacket.length; ++ i)
			sendPacket [index ++] = loginPacket [i];
		sendPacket [index ++] = TeamsEventFactory.IDENTIFIER; 

		// password 복사
		for (int i = 0; i < loginPacket.length; ++ i)
			sendPacket [index ++] = loginPacket [i];
		sendPacket [index ++] = TeamsEventFactory.IDENTIFIER; 

		// Black 및 '10'복사
//		sendPacket [index ++] = (byte) 0x30;			// 모든 장애 표시
//		sendPacket [index ++] = (byte) 0x30;			// 모든 장애 표시
//		sendPacket [index ++] = (byte) 0x30;			// 모든 장애 표시
//		sendPacket [index ++] = (byte) 0x30;			// 모든 장애 표시
//		sendPacket [index ++] = (byte) 0x30;			// 모든 장애 표시
//
//		sendPacket [index ++] = (byte) 0x30;			// 모든 장애 표시
//		sendPacket [index ++] = (byte) 0x30;			// 모든 장애 표시
//		sendPacket [index ++] = (byte) 0x30;			// 모든 장애 표시
//		sendPacket [index ++] = (byte) 0x30;			// 모든 장애 표시
//		sendPacket [index ++] = (byte) 0x30;			// 모든 장애 표시
		sendPacket [index ++] = TeamsEventFactory.IDENTIFIER;

		sendPacket [index ++] = 0x31;					// '1'
//		sendPacket [index ++] = 0x30;					// '0'

		 StringBuffer st = new StringBuffer();
		 String str = new String(sendPacket);

		
			 	
		
		outputStream.write(sendPacket);
		outputStream.flush();
		logger.info("sended login-packet");
	}

	public void keepAliveDB() throws Exception {
		String curDateStr = adamsSession.selectOne("RealtimeTeams.selectSysdate", null);
		logger.info("keepAliveDB:"+curDateStr);
		adamsSession.clearCache();
	}

    public static void main (String [] args) {
    	EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("RealTimeCollectTeams", envManager.getOptions());
    		System.exit(0);
    	}
        new RealTimeCollectTeams (args);
    }
    
    class Runner extends Thread {
    	
    	RealTimeCollectTeams	parent;
    	public Runner(RealTimeCollectTeams parent) {
    		this.parent = parent;
    	}

		@Override
		public void run() {
			parent.runEventHandler();
		}
    	
    }
}

