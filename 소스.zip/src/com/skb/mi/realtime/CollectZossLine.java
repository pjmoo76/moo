package com.skb.mi.realtime;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.ResultSetMetaData;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.LinkedList;

import org.apache.commons.cli.HelpFormatter;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.DBController;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.OutputLog;

public class CollectZossLine {
	final private int			COLUMN_NUM			= 69;
	final private int			PREPARED_STATEMENT  = 5000;
	final private String		TABLE_NAME			= "ZOSS_LINE";

	DBController				dbController;
	String						dbUrl, userName, password;

	DBController				neifController;
	String						neifUrl, neifUserName, neifPassword;

	String						tableName;
	PreparedStatement			preparedOiv10600;
	PreparedStatement			preparedOiv10602;

	String []					columns;
	String						absolutePath;

    Hashtable<String,String []>    hashTable;
    OutputLog					outputLog;

    public CollectZossLine (String[] args) {
    	outputLog = new OutputLog (true, this.getClass().getName (), EnvManager.env.getLogs());
        hashTable = new Hashtable<String,String []>();
		tableName = TABLE_NAME;
		outputLog.write("NEIFDB 서버에서 수집할 테이블 명 : " + tableName);

		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		dbUrl = configManager.getConfig(Constants.ADAMS_DB, Constants.DB_URL);
		userName = configManager.getConfig(Constants.ADAMS_DB, Constants.USER_NAME);
		password = configManager.getConfig(Constants.ADAMS_DB, Constants.PASSWORD);
		neifUrl = configManager.getConfig(Constants.NEIF_DB, Constants.DB_URL);
		neifUserName = configManager.getConfig(Constants.NEIF_DB, Constants.USER_NAME);
		neifPassword = configManager.getConfig(Constants.NEIF_DB, Constants.PASSWORD);

		outputLog.write(String.format("(dbUrl:%s)", dbUrl));
		outputLog.write(String.format("(userName:%s)", userName));
		outputLog.write(String.format("(password:%s)", password));
		outputLog.write(String.format("(neifUrl:%s)", neifUrl));
		outputLog.write(String.format("(neifUserName:%s)", neifUserName));
		outputLog.write(String.format("(neifPassword:%s)", neifPassword));

		columns = new String [COLUMN_NUM];
		try {
			//readDbInfo ();
			dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
			neifController = new DBController (DBController.ORACLE_DB, neifUrl, neifUserName, neifPassword);
		} catch (Exception e ) {
			outputLog.write(e);
			System.exit (0);
		}	

//		selectColumnType ();
		executeZossLineView ();
		executeZossLine ();
		dbController.closeDB ();
		neifController.closeDB ();
		outputLog.write("Finished");
    }

    /*
	public void readDbInfo () throws Exception {
		String	oneLine;
		FileReader	fileReader = new FileReader (absolutePath + File.separator + "db.info");
		BufferedReader bufferedReader = new BufferedReader (fileReader);
		dbUrl = bufferedReader.readLine ();
		userName = bufferedReader.readLine ();
		password = bufferedReader.readLine ();
		neifUrl = bufferedReader.readLine ();
		neifUserName = bufferedReader.readLine ();
		neifPassword = bufferedReader.readLine ();
		System.out.println ("neifUrl : " + neifUrl);
		System.out.println ("neifUserName : " + neifUserName);
		System.out.println ("neifPassword : " + neifPassword);
		bufferedReader.close ();
		fileReader.close ();
	}*/

    public void executeZossLineView () {
        String      neifQuery = "SELECT"
                              + "  LINE_NUM"
                              + ", CUST_CHRTIC_CD"
                              + ", SPEED_CD"
                              + " FROM NEIFPRD.ZOSS_LINE_01_V";

        // Swing(NEIFPRD.ZOSS_LINE_01_V)에서 조회
        try {
			ResultSet	resultSet = neifController.getStmt ().executeQuery (neifQuery);
			while (resultSet.next ()) {                
					 hashTable.put (resultSet.getString (1), new String[] {resultSet.getString(2),resultSet.getString(3)});
			}
			resultSet.close ();
//            printHashtable ();
        } catch (Exception e) {
        	outputLog.write(e);
            selectAdamsDB ();
        }
    }

    // NEIFPRD.ZOSS_LINE_01_V(Swing) 연동이 안될 경우, ADAMS DB내용으로 유지
    public void selectAdamsDB () {
        String      dbQuery = "SELECT"
                            + " LINE_NUM, CUST_CHRTIC_CD, SPEED_CD"
                            + " FROM OIV10602";

        // Swing(NEIFPRD.ZOSS_LINE_01_V)에서 조회
        try {
			ResultSet	resultSet = dbController.getStmt ().executeQuery (dbQuery);
			while (resultSet.next ()) {
                 if (resultSet.getString (2) != null)
					 hashTable.put (resultSet.getString (1), new String[] {resultSet.getString(2),resultSet.getString(3)});
			}
			resultSet.close ();
//            printHashtable ();
        } catch (Exception e) {
        	outputLog.write(e);
        }
    }

    public void printHashtable () {
        Enumeration<String> hashKey = hashTable.keys ();
        int count = 0;
        String key;
        while (hashKey.hasMoreElements ()) {
            key = hashKey.nextElement ();
            System.out.println ("Key : " + key + ", Value : " + hashTable.get (key));
            ++ count;
        }
        outputLog.write("총 개수 : " + count);
    }
    public void executeZossLine () {
		int			commitCount = 0, columnIndex, index = 1;
		String		neifQuery = "SELECT "
							  + "LINE_NUM"
							  + ", SVC_MGMT_NUM"
							  + ", NVL(LINE_CL_CD, '#')"
							  + ", LINE_NM"
							  + ", NVL(LNSHT_MGMT_CL_CD, '#')"
							  + ", EXLINE_NUM"
							  + ", SVSET_REQ_NUM"
							  + ", CHRGR_ID"
							  + ", NVL(SUP_TPO_CD, '#')"
							  + ", SUP_TPO_ADDR_ID"
							  + ", SUP_STN_EXCHG_QDF_NUM"
							  + ", SUP_STN_TRMS_QDF_NUM"
							  + ", SUP_STN_TIE_NUM"
							  + ", SUP_STN_RENT_LINE_NUM"
							  + ", NVL(SUB_TPO_CD, '#')"
							  + ", SUB_TPO_ADDR_ID"
							  + ", SUB_STN_EXCHG_QDF_NUM"
							  + ", SUB_STN_TRMS_QDF_NUM"
							  + ", SUB_STN_TIE_NUM"
							  + ", SUB_STN_RENT_LINE_NUM"
							  + ", NVL(SPEED_CD, '#')"
							  + ", FR_DLCI_CTT"
							  + ", NVL(LMI_TYP_CD, '#')"
							  + ", NVL(ENCAP_TYP_CD, '#')"
							  + ", ATM_CHRGR_ID"
							  + ", ATM_CHRGR_PHON_NUM"
							  + ", CBL_MODM_DMN_NM"
							  + ", IP_CNT"
							  + ", NDCS_CHRGR_ID"
							  + ", NDCS_CHRGR_PHON_NUM"
							  + ", VLAN_NUM"
							  + ", NVL(RENT_EQUIP_SET_YN, '#')"
							  + ", SUP_STN_EMAIL_ADDR"
							  + ", SUP_STN_MDF_NUM"
							  + ", SUP_STN_IDF_NUM"
							  + ", SUB_STN_EMAIL_ADDR"
							  + ", SUB_STN_MDF_NUM"
							  + ", SUB_STN_IDF_NUM"
							  + ", MGNT_EQUIP_FST_IP_ADDR"
							  + ", MGNT_EQUIP_SCND_IP_ADDR"
							  + ", CO_EQUIP_FST_IP_ADDR"
							  + ", CO_EQUIP_SCND_IP_ADDR"
							  + ", NVL(SVC_TECH_MTHD_CD, '#')"
							  + ", ADD_STA_IP_ADDR"
							  + ", AMD_CMDC_IP_ADDR"
							  + ", AMD_ENET_IP_ADDR"
							  + ", DSLAM_HW_ADDR"
							  + ", DSLAM_EMS_VPC_NUM"
							  + ", EMAIL_ADDR"
							  + ", SCRBR_STA_IP_ADDR"
							  + ", SCRBR_RUTR_IP_ADDR"
							  + ", NET_RUTR_IP_ADDR"
							  + ", FIX_IP_SBNT_ADDR"
							  + ", GW_IP_ADDR"
							  + ", IDF_NUM"
							  + ", HSPD_PT_LINE_NUM"
							  + ", LAN_CBNT_NUM"
							  + ", MDF_NUM"
							  + ", NVL(MNTNC_CO_YN, '#')"
							  + ", STRD_LINE_NUM"
							  + ", RUTR_ENET_IP_ADDR"
							  + ", NVL(RUTR_TYP_CD, '#')"
							  + ", SVC_STA_DT"
							  + ", SER_IP_ADDR"
							  + ", SBNT_MSK_ADDR"
							  + ", SWTCH_HUB_IP_ADDR"
							  + ", SWTCH_HUB_MAC_NUM"
							  + ", NVL(SWTCH_HUB_TYP_CD, '#')"
							  + ", MEMO"
							  + " FROM " + tableName;

		String		query10600 = "MERGE INTO OIV10600 USING DUAL"
							  + " ON (LINE_NUM=?)"
							  + " WHEN MATCHED THEN UPDATE SET"
							  + "  AUDIT_DTM=SYSDATE"
							  + ", SVC_MGMT_NUM=?"
							  + ", LINE_CL_CD=?"
							  + ", LINE_NM=?"
							  + ", LNSHT_MGMT_CL_CD=?"
							  + ", EXLINE_NUM=?"
							  + ", SVSET_REQ_NUM=?"
							  + ", CHRGR_ID=?"
							  + ", SUP_TPO_CD=?"
							  + ", SUP_TPO_ADDR_ID=?"
							  + ", SUP_STN_EXCHG_QDF_NUM=?"
							  + ", SUP_STN_TRMS_QDF_NUM=?"
							  + ", SUP_STN_TIE_NUM=?"
							  + ", SUP_STN_RENT_LINE_NUM=?"
							  + ", SUB_TPO_CD=?"
							  + ", SUB_TPO_ADDR_ID=?"
							  + ", SUB_STN_EXCHG_QDF_NUM=?"
							  + ", SUB_STN_TRMS_QDF_NUM=?"
							  + ", SUB_STN_TIE_NUM=?"
							  + ", SUB_STN_RENT_LINE_NUM=?"
							  + ", SPEED_CD=?"
							  + ", FR_DLCI_CTT=?"
							  + ", LMI_TYP_CD=?"
							  + ", ENCAP_TYP_CD=?"
							  + ", ATM_CHRGR_ID=?"
							  + ", ATM_CHRGR_PHON_NUM=?"
							  + ", CBL_MODM_DMN_NM=?"
							  + ", IP_CNT=?"
							  + ", NDCS_CHRGR_ID=?"
							  + ", NDCS_CHRGR_PHON_NUM=?"
							  + ", VLAN_NUM=?"
							  + ", RENT_EQUIP_SET_YN=?"
							  + ", SUP_STN_EMAIL_ADDR=?"
							  + ", SUP_STN_MDF_NUM=?"
							  + ", SUP_STN_IDF_NUM=?"
							  + ", SUB_STN_EMAIL_ADDR=?"
							  + ", SUB_STN_MDF_NUM=?"
							  + ", SUB_STN_IDF_NUM=?"
							  + ", MGNT_EQUIP_FST_IP_ADDR=?"
							  + ", MGNT_EQUIP_SCND_IP_ADDR=?"
							  + ", CO_EQUIP_FST_IP_ADDR=?"
							  + ", CO_EQUIP_SCND_IP_ADDR=?"
							  + ", SVC_TECH_MTHD_CD=?"
							  + ", ADD_STA_IP_ADDR=?"
							  + ", AMD_CMDC_IP_ADDR=?"
							  + ", AMD_ENET_IP_ADDR=?"
							  + ", DSLAM_HW_ADDR=?"
							  + ", DSLAM_EMS_VPC_NUM=?"
							  + ", EMAIL_ADDR=?"
							  + ", SCRBR_STA_IP_ADDR=?"
							  + ", SCRBR_RUTR_IP_ADDR=?"
							  + ", NET_RUTR_IP_ADDR=?"
							  + ", FIX_IP_SBNT_ADDR=?"
							  + ", GW_IP_ADDR=?"
							  + ", IDF_NUM=?"
							  + ", HSPD_PT_LINE_NUM=?"
							  + ", LAN_CBNT_NUM=?"
							  + ", MDF_NUM=?"
							  + ", MNTNC_CO_YN=?"
							  + ", STRD_LINE_NUM=?"
							  + ", RUTR_ENET_IP_ADDR=?"
							  + ", RUTR_TYP_CD=?"
							  + ", SVC_STA_DT=?"
							  + ", SER_IP_ADDR=?"
							  + ", SBNT_MSK_ADDR=?"
							  + ", SWTCH_HUB_IP_ADDR=?"
							  + ", SWTCH_HUB_MAC_NUM=?"
							  + ", SWTCH_HUB_TYP_CD=?"
							  + ", MEMO=?"
							  + " WHEN NOT MATCHED THEN INSERT ("
							  + "  AUDIT_ID"
							  + ", AUDIT_DTM"
							  + ", LINE_NUM"
							  + ", SVC_MGMT_NUM"
							  + ", LINE_CL_CD"
							  + ", LINE_NM"
							  + ", LNSHT_MGMT_CL_CD"
							  + ", EXLINE_NUM"
							  + ", SVSET_REQ_NUM"
							  + ", CHRGR_ID"
							  + ", SUP_TPO_CD"
							  + ", SUP_TPO_ADDR_ID"
							  + ", SUP_STN_EXCHG_QDF_NUM"
							  + ", SUP_STN_TRMS_QDF_NUM"
							  + ", SUP_STN_TIE_NUM"
							  + ", SUP_STN_RENT_LINE_NUM"
							  + ", SUB_TPO_CD"
							  + ", SUB_TPO_ADDR_ID"
							  + ", SUB_STN_EXCHG_QDF_NUM"
							  + ", SUB_STN_TRMS_QDF_NUM"
							  + ", SUB_STN_TIE_NUM"
							  + ", SUB_STN_RENT_LINE_NUM"
							  + ", SPEED_CD"
							  + ", FR_DLCI_CTT"
							  + ", LMI_TYP_CD"
							  + ", ENCAP_TYP_CD"
							  + ", ATM_CHRGR_ID"
							  + ", ATM_CHRGR_PHON_NUM"
							  + ", CBL_MODM_DMN_NM"
							  + ", IP_CNT"
							  + ", NDCS_CHRGR_ID"
							  + ", NDCS_CHRGR_PHON_NUM"
							  + ", VLAN_NUM"
							  + ", RENT_EQUIP_SET_YN"
							  + ", SUP_STN_EMAIL_ADDR"
							  + ", SUP_STN_MDF_NUM"
							  + ", SUP_STN_IDF_NUM"
							  + ", SUB_STN_EMAIL_ADDR"
							  + ", SUB_STN_MDF_NUM"
							  + ", SUB_STN_IDF_NUM"
							  + ", MGNT_EQUIP_FST_IP_ADDR"
							  + ", MGNT_EQUIP_SCND_IP_ADDR"
							  + ", CO_EQUIP_FST_IP_ADDR"
							  + ", CO_EQUIP_SCND_IP_ADDR"
							  + ", SVC_TECH_MTHD_CD"
							  + ", ADD_STA_IP_ADDR"
							  + ", AMD_CMDC_IP_ADDR"
							  + ", AMD_ENET_IP_ADDR"
							  + ", DSLAM_HW_ADDR"
							  + ", DSLAM_EMS_VPC_NUM"
							  + ", EMAIL_ADDR"
							  + ", SCRBR_STA_IP_ADDR"
							  + ", SCRBR_RUTR_IP_ADDR"
							  + ", NET_RUTR_IP_ADDR"
							  + ", FIX_IP_SBNT_ADDR"
							  + ", GW_IP_ADDR"
							  + ", IDF_NUM"
							  + ", HSPD_PT_LINE_NUM"
							  + ", LAN_CBNT_NUM"
							  + ", MDF_NUM"
							  + ", MNTNC_CO_YN"
							  + ", STRD_LINE_NUM"
							  + ", RUTR_ENET_IP_ADDR"
							  + ", RUTR_TYP_CD"
							  + ", SVC_STA_DT"
							  + ", SER_IP_ADDR"
							  + ", SBNT_MSK_ADDR"
							  + ", SWTCH_HUB_IP_ADDR"
							  + ", SWTCH_HUB_MAC_NUM"
							  + ", SWTCH_HUB_TYP_CD"
							  + ", MEMO"
						      + ") VALUES ("
							  + "  'SWING'"
							  + ", SYSDATE"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ", ?"
							  + ")";

		String		query10602 = "MERGE INTO OIV10602 USING DUAL" 
							   + " ON (LINE_NUM=?)"
							   + " WHEN MATCHED THEN UPDATE SET"
							   + "  AUDIT_DTM=SYSDATE"
							   + ", SVC_MGMT_NUM=?"
							   + ", LINE_NM=?"
							   + ", SUP_TPO_CD=?"
							   + ", SUB_TPO_CD=?"
							   + ", SPEED_CD=?"
							   + ", APPL_SPEED_CD =?"
							   + ", CUST_CHRTIC_CD=?"							   
							   + " WHEN NOT MATCHED THEN"
							   + " INSERT ("
							   + "  AUDIT_ID"
							   + ", AUDIT_DTM"
							   + ", LINE_NUM"
							   + ", SVC_MGMT_NUM"
							   + ", LINE_NM"
							   + ", SUP_TPO_CD"
							   + ", SUB_TPO_CD"
							   + ", SPEED_CD"
							   + ", APPL_SPEED_CD"
							   + ", CUST_CHRTIC_CD"
							   + ") VALUES ("
							   + "  'SWING'"
							   + ", SYSDATE"
							   + ", ?"
							   + ", ?"
							   + ", ?"
							   + ", ?"
							   + ", ?"
							   + ", ?"
							   + ", ?"
							   + ", ?"
							   + ")";
		
		String		lineNum = "";
		String		lineNm = "";
		String		svcMgmtNum = "";
		String		supTpoCd = "";
		String		subTpoCd = "";
		String		speedCd = "";

		try {
			preparedOiv10600 = dbController.getConnection().prepareStatement (query10600);
			preparedOiv10602 = dbController.getConnection().prepareStatement (query10602);
			ResultSet	resultSet = neifController.getStmt ().executeQuery (neifQuery);
			while (resultSet.next ()) {
				lineNum = "";
				lineNm = "";
				svcMgmtNum = "";
				supTpoCd = "";
				subTpoCd = "";
				speedCd = "";
				for (index = 1; index <= COLUMN_NUM; ++ index) {
					columns [index - 1] = resultSet.getString (index);
					switch (index) {
						case	 1: lineNum = resultSet.getString (index); break;
						case	 2: svcMgmtNum = resultSet.getString (index); break;
						case	 4: lineNm = resultSet.getString (index); break;
						case	 9: supTpoCd = resultSet.getString (index); break;
						case	15: subTpoCd = resultSet.getString (index); break;
						case	21: speedCd = resultSet.getString (index); break;
					}
/*
					System.out.println ("Index : " + index + ", string : " + resultSet.getString (index));
*/
				}

				/* OIV10600 테이블 */
				for (index = 1; index <= COLUMN_NUM; ++ index) {
					preparedOiv10600.setString (index, columns [index - 1]);
					preparedOiv10600.setString (index + COLUMN_NUM, columns [index - 1]);
				}
				preparedOiv10600.addBatch();
				
				/* OIV10602 테이블 CUST_CHRTIC_CD, SPEED_CD*/
				String custChrticCd = null;
				String V01speedCd = null ;
				String[] V01 = hashTable.get (lineNum);
				if(V01!=null)
				{
					custChrticCd = V01[0];
					V01speedCd = V01[1];
				}
				
				
				index = 1;
				preparedOiv10602.setString (index ++, lineNum);
				preparedOiv10602.setString (index ++, svcMgmtNum);
				preparedOiv10602.setString (index ++, lineNm);
				preparedOiv10602.setString (index ++, supTpoCd);
				preparedOiv10602.setString (index ++, subTpoCd);
				preparedOiv10602.setString (index ++, speedCd);
				preparedOiv10602.setString (index ++, V01speedCd);				
				preparedOiv10602.setString (index ++, custChrticCd);
				preparedOiv10602.setString (index ++, lineNum);
				preparedOiv10602.setString (index ++, svcMgmtNum);
				preparedOiv10602.setString (index ++, lineNm);
				preparedOiv10602.setString (index ++, supTpoCd);
				preparedOiv10602.setString (index ++, subTpoCd);
				preparedOiv10602.setString (index ++, speedCd);
				preparedOiv10602.setString (index ++, V01speedCd);				
				preparedOiv10602.setString (index ++, custChrticCd);
				preparedOiv10602.addBatch();
				
				++ commitCount;
				if (commitCount % PREPARED_STATEMENT == 0) {
					preparedOiv10600.executeBatch ();
					preparedOiv10602.executeBatch ();
				}
			}
			preparedOiv10600.executeBatch ();
			preparedOiv10602.executeBatch ();
			outputLog.write("전체 건수 : " + commitCount + " 건");
		} catch (Exception e) {
			outputLog.write(e);
		}
    }
    
	public void selectColumnType () {
		try {
			String query = "SELECT * FROM " + tableName;

			ResultSet resultSet = neifController.getStmt ().executeQuery(query);
			ResultSetMetaData	resultSetMetaData = resultSet.getMetaData ();
			int columnCount = resultSetMetaData.getColumnCount();
			columns = new String [columnCount];
			outputLog.write("columnCount : " + columnCount);
			for (int index = 1; index <= columnCount; ++ index) {
				outputLog.write("Column 명 : " + resultSetMetaData.getColumnName (index) + ", Column Type : " + resultSetMetaData.getColumnType (index));
			}
		} catch (Exception e) {
			outputLog.write(e);
		}
	}

	public String getDateSecond () {
		Calendar	calendar = Calendar.getInstance ();

		return String.format ("%04d-%02d-%02d %02d:%02d:%02d",
			calendar.get(Calendar.YEAR),
			calendar.get(Calendar.MONTH) + 1,
			calendar.get(Calendar.DAY_OF_MONTH),
			calendar.get(Calendar.HOUR_OF_DAY),
			calendar.get(Calendar.MINUTE),
			calendar.get(Calendar.SECOND));
	}

    public void sleep (int waitingTime) {
        try {
            Thread.sleep (waitingTime);
        } catch (Exception e) {
        }
    }

    public static void main (String [] args) {
    	EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("CollectZossLine", envManager.getOptions());
    		System.exit(0);
    	}
    
        new CollectZossLine(args);
    }
}

