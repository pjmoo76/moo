package com.skb.mi.realtime;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

import org.apache.commons.cli.HelpFormatter;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.common.MiscUtils;
import com.skb.mi.common.StringUtils;
import com.skb.mi.model.OMN30203;
import com.skb.mi.realtime.foms.FomsEvent;
import com.skb.mi.realtime.foms.FomsFaultEvent;
import com.skb.mi.realtime.foms.FomsNetFaultEvent;
import com.skb.mi.realtime.rms.RmsCatvFaultEvent;
import com.skb.mi.realtime.rms.RmsCircuitFaultEvent;
import com.skb.mi.realtime.rms.RmsEquipFaultEvent;
import com.skb.mi.realtime.rms.RmsEvent;
import com.skb.mi.realtime.teams.TeamsCircuitFaultEvent;
import com.skb.mi.realtime.teams.TeamsEquipFaultEvent;
import com.skb.mi.realtime.teams.TeamsEvent;
import com.skb.mi.realtime.teams.TeamsFaultClearEvent;
import com.skb.mi.realtime.teams.TeamsManualClearEvent;
import com.skb.mi.realtime.teams.TeamsRingFaultEvent;
import com.skb.mi.thread.SendJsonThread;

public class RealTimeCollectTest {
	
	final private String		NET_CL_CD 			= "04";		// OCO20101 테이블
	final private String		NET_CL_NM 			= "HFC";	// OCO20101 테이블
	final private String		NMS_EQUIP_CD 		= "011";	// OCO20101 테이블
	final private String		NMS_EQUIP_NM 		= "RMS";
	
	final private String		ETC_NET_CL_CD 		= "99";
	final private String		ETC_NET_CL_NM 		= "ETC";
	
	final private String		NMS_CD_CATV			= "031";	// OCO20101, NMS_EQUIP_CD로 조회
	final private String		NMS_NM_CATV 		= "FOMS_CATV";	// OCO20101, NMS_EQUIP_CD로 조회

	final private String		NMS_CD_CATV_R		= "032";	// OCO20101, NMS_EQUIP_CD로 조회
	final private String		NMS_NM_CATV_R		= "RMS_CATV";	// OCO20101, NMS_EQUIP_CD로 조회

    final private String  		GENERATE_EVENT 		= "GEN";
    final private String  		CLEAR_EVENT 		= "CLR";

    final private String  		GENERATED_FAULT_NM 	= "장애중";
    final private String  		CLEARED_FAULT_NM 	= "장애해제";

    final private String  		GENERATED_FAULT_CD 	= "01";
    final private String  		CLEARED_FAULT_CD 	= "02";
	
	final private String        RMS_UNKNOWN_FAULT 	= "210";    // 210: 미파악됨
	final private String        RMS_EQUIP_FAULT 	= "303";    // 303: 장비 장애
    final private String        RMS_CIRCUIT_FAULT 	= "501";   	// 501: 회선 장애 

    final private int			SO_TIME_OUT	= (1000*60*5); //5분
    
	// RMS 서버 정보
	Socket						socket;
	InputStream					inputStream;
	OutputStream				outputStream;
	//String []                   arrIpAddress;
	//String						ipAddress;
	int							portNo;

	HashMap<String, OMN30203>	omn30203Map;
	String						pushIpAddress;
	int							pushPortNo;

	Hashtable<String,String>	dablLclCdList;
	Hashtable<String,String>	dablLclNmList;
	Hashtable<String,String>	dablMclCdList;
	Hashtable<String,String>	dablMclNmList;
	Hashtable<String,String>	dablNmList;
	Hashtable<String,String>	dablCdList;
	
	String						version;
	final private String		NMS_CD 				= "005";	// OCO20101 테이블에 있음.
	final private String		NMS_NM 				= "TEAMS";
	final private int			SOCKET_TIME_OUT	= (1000*60*5);	// Time-Out 5분 설정

    final private String        EQUIP_DABL_LCL_NM   = "장비장애";
    final private String        EQUIP_DABL_MCL_CD   = "01201";
    final private String        EQUIP_DABL_MCL_NM   = "전송망장비장애";
    final private String        EQUIP_DABL_CD       = "012001";
    final private String        EQUIP_DABL_NM       = "TEAMS 장비장애";

    final private String        CIRCUIT_DABL_LCL_NM = "회선장애";
    final private String        CIRCUIT_DABL_MCL_CD = "04201";
    final private String        CIRCUIT_DABL_MCL_NM = "전송망회선장애";
    final private String        CIRCUIT_DABL_CD     = "042001";
    final private String        CIRCUIT_DABL_NM     = "TEAMS 회선장애";

    final private String        RING_DABL_LCL_NM 	= "회선장애";
    final private String        RING_DABL_MCL_CD 	= "04203";
    final private String        RING_DABL_MCL_NM 	= "전송망링장애";
    final private String        RING_DABL_CD     	= "042003";
    final private String        RING_DABL_NM     	= "TEAMS 링장애";

	final private String		NMS_CD2 				= "005";	// OCO20101 테이블에 있음.
	final private String		NMS_NM2 				= "TEAMS";
	
	final private String		NMS_CD3 				= "010";	// OCO20101 테이블에 있음.
	final private String		NMS_NM3 				= "FOMS";

	final private String		NET_CL_CD2 			= "02";		// 전송망
	final private String		NET_CL_NM2 			= "전송망";
	
	final private String		NET_CL_CD3 			= "03";		// FTTx
	final private String		NET_CL_NM3 			= "FTTx";
	

	final private String 		EQUIP_FAULT 		= "01";		// 01: 장비 장애
	final private String 		CIRCUIT_FAULT 		= "04"; 	// 04: 회선 장애
	final private String 		TRAFFIC_FAULT 		= "03"; 	// 03: 트래픽 장애

    private Logger		logger;
	private	SendJsonThread	jsonSender;
	private	SqlSession	adamsSession;
	private	HashMap<String,String>	sktEquipMap;
	
	@SuppressWarnings("null")
	public RealTimeCollectTest (String [] args) throws Exception {
		logger = LogManager.getLogger(this.getClass());
    	logger.info("start");
    	
    	loadConfig();
    	
    	if (adamsSession == null) {
			adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
		}
    	
    	try {
			jsonSender = new SendJsonThread(pushIpAddress, pushPortNo, true);
			
			List<String> list = new ArrayList<String>();
			
			SimpleDateFormat dtmFormat = new SimpleDateFormat("yyyyMMddHHmmss");
			Date current_date = new Date(System.currentTimeMillis());
			String curDtm = dtmFormat.format(current_date);
			
			
			//240617 장비/회선장애 8종
//			list.add("{\"DABL_CD\":\"015002\",\"EQUIP_MDL_NM\":\"DSW2624G\",\"OCCR_DTM\":\"20240617141500\",\"EQUIP_IP_ADDR\":\"100.96.103.101\",\"ROUT_NUM\":\"\",\"DABL_DESC\":\"ICMP 응답이 없습니다.\",\"DABL_GR_CD\":\"05\",\"SUP_EQUIP_ID1\":null,\"DABL_MCL_CD\":\"01502\",\"EQUIP_NM\":\"강릉_포남_소라연립주택\",\"MODULE_EQUIP_NM\":\"\",\"MODULE_EQUIP_ID\":\"0\",\"PORT_NO\":\"-1\",\"NMS_NM\":\"B2B\",\"NET_CL_NM\":\"IP\",\"DABL_LCL_NM\":\"장비장애\",\"DABL_ST_CD\":\"01\",\"OCCR_RCV_DTM\":\"20240617141607\",\"SUP_EQUIP_NM\":null,\"DABL_OCCR_LOC_DESC\":\"\",\"EQUIP_TID_VAL\":\"강릉_포남_소라연립주택\",\"EQUIP_MDL_CD\":\"0000000865\",\"MSC_MODULE_NM\":\"\",\"kind\":\"GEN\",\"EQUIP_ID\":\"000000498478\",\"SUP_EQUIP_NM1\":null,\"DABL_MCL_NM\":\"BMS장비장애\",\"DABL_NM\":\"BMS장비장애\",\"NMS_CD\":\"009\",\"NET_CL_CD\":\"05\",\"DABL_LCL_CD\":\"01\",\"NMS_DABL_NUM_CTT\":\"51354154\",\"DABL_ST_NM\":\"장애중\",\"EQUIP_DABL_MSG_CTT\":\"ICMP 응답이 없습니다.\"}");
//			list.add("{\"EQUIP_MDL_NM\":\"DSW3308G\",\"OCCR_DTM\":\"20240617131500\",\"EQUIP_IP_ADDR\":\"100.90.176.98\",\"LINE_CL_CD\":\"A001\",\"LINE_NUM\":\"000001143539\",\"DABL_DESC\":\"ICMP 응답이 없습니다.\",\"DABL_GR_CD\":\"05\",\"CHRGR_NM\":null,\"SUP_EQUIP_ID1\":\"000705824984\",\"DABL_MCL_CD\":\"04501\",\"EQUIP_NM\":\"태광산업(주)\",\"MODULE_EQUIP_ID\":\"0\",\"NMS_NM\":\"B2B\",\"NET_CL_NM\":\"IP\",\"DABL_LCL_NM\":\"회선장애\",\"OCCR_RCV_DTM\":\"20240617131606\",\"MGMT_TPO_NM\":\"대전\\/서\",\"INFO_CNTR_CD\":\"F10100\",\"SUP_EQUIP_NM\":\"DJSEO_FCO14\",\"LINE_CL_NM\":\"일반회선\",\"DABL_OCCR_LOC_DESC\":\"\",\"MSC_MODULE_NM\":\"\",\"SUB_TPO_CD\":\"F10100\",\"kind\":\"GEN\",\"SUP_EQUIP_NM1\":\"DJSEO_FCO14\",\"CUST_NM\":\"태광산업(주)\",\"CHRGR_ID\":\"1000794716\",\"TPO_CD\":\"F10100\",\"DABL_NM\":\"BMS회선장애\",\"NET_CL_CD\":\"05\",\"DABL_LCL_CD\":\"04\",\"CUST_NUM\":\"9900002119\",\"DISTB_CNTR_NM\":\"대전\\/서\",\"DABL_ST_NM\":\"장애중\",\"EQUIP_DABL_MSG_CTT\":\"ICMP 응답이 없습니다.\",\"LINE_NM\":\"태광산업(주)\",\"INFO_CNTR_NM\":\"대전\\/서\",\"DABL_CD\":\"045001\",\"SUB_TPO_NM\":\"대전\\/서\",\"SUP_TPO_CD\":\"F10100\",\"ROUT_NUM\":\"\",\"SPEED_NM\":\"100Mbps\",\"TPO_NM\":\"대전\\/서\",\"MODULE_EQUIP_NM\":\"\",\"PORT_NO\":\"-1\",\"SVC_MGMT_NUM\":\"7314711312\",\"DABL_ST_CD\":\"01\",\"CUST_CHRTIC_CD\":null,\"SVC_TECH_MTHD_NM\":\"프리밴(FTTx)\",\"EQUIP_TID_VAL\":\"\",\"EQUIP_MDL_CD\":\"A000100754\",\"SUP_TPO_NM\":\"대전\\/서\",\"SPEED_CD\":\"K6\",\"EQUIP_ID\":\"000838443548\",\"DABL_MCL_NM\":\"BMS회선장애\",\"NMS_CD\":\"009\",\"CUST_CHRTIC_NM\":\"일반회선\",\"NMS_DABL_NUM_CTT\":\"51354065\",\"SVC_TECH_MTHD_CD\":\"H0011\",\"MGMT_TPO_CD\":\"F10100\"}");
//			list.add("{\"EQUIP_MDL_NM\":\"cBR-8\",\"OCCR_DTM\":\"20240617140509\",\"EQUIP_IP_ADDR\":\"172.23.10.33\",\"DSST_YN\":\"\",\"DABL_GR_CD\":\"02\",\"DABL_DESC\":\"VPN Channel Down[MAC:0002.00BD.7B40][CM IP:10.92.153.58][WAN IP:114.201.52.130][전주번호(청약):신곡간41L3A2][전산화번호(청약):0236X051][전주번호:null][한전본부명:경기북지역본부]\",\"PORT_NUM\":\"\",\"NET_OP_NUM\":\"\",\"DABL_MCL_CD\":\"01415\",\"EQUIP_NM\":\"WB480007\",\"DSSTR_YN\":\"\",\"MODULE_EQUIP_ID\":\"\",\"NMS_NM\":\"RMS\",\"NET_CL_NM\":\"HFC\",\"TOT_VOC_CNT\":\"0\",\"DABL_LCL_NM\":\"장비장애\",\"IPTV_VOC_CNT\":\"0\",\"OCCR_RCV_DTM\":\"2024-06-17 14:07:17\",\"INFO_CNTR_CD\":\"\",\"DABL_DUP_YN\":\"\",\"PHON_VOC_CNT\":\"0\",\"ROUT_NM\":\"\",\"MKT_DIV_ORG_ID\":\"\",\"DABL_OCCR_LOC_DESC\":\"_14__\",\"DMG_SCRBR_CNT\":\"\",\"MSC_MODULE_NM\":\"\",\"kind\":\"GEN\",\"SCARD_NUM_CTT\":\"\",\"GNLPH_DMG_LINE_CNT\":\"0\",\"DABL_NM\":\"VPN Channel State\",\"VOIP_VOC_CNT\":\"0\",\"NET_CL_CD\":\"04\",\"EQUIP_SET_LOC_DESC\":\"\",\"DABL_LCL_CD\":\"01\",\"OPER_DABL_YN\":\"N\",\"DISTB_CNTR_NM\":\"\",\"DABL_ST_NM\":\"장애중\",\"TM_TYP_CD\":\"\",\"CCELL_NUM\":\"14\",\"INFO_CNTR_NM\":\"\",\"DABL_CD\":\"014254\",\"GNRL_IPTV_DMG_LINE_CNT\":\"0\",\"ROUT_NUM\":\"\",\"TEAM_ORG_ID\":\"\",\"SHSPD_VOC_CNT\":\"0\",\"DABL_DUP_CNT_2\":\"1\",\"DABL_DUP_CNT_3\":\"1\",\"DABL_DUP_CNT_1\":\"1\",\"DABL_ST_CD\":\"01\",\"OTX_NUM\":\"\",\"MKT_DIV_ORG_NM\":\"\",\"DISTB_CNTR_CD\":\"\",\"EQUIP_TID_VAL\":\"WB480007\",\"EQUIP_MDL_CD\":\"DCU\",\"SHSPD_INET_DMG_LINE_CNT\":\"0\",\"TEAM_ORG_NM\":\"\",\"DABL_DUP_CNT\":\"\",\"EQUIP_ID\":\"WB480007\",\"DABL_MCL_NM\":\"한전AMI장애\",\"NMS_CD\":\"011\",\"INCOMM_BIZR_ID\":\"\",\"SWING_ANNCE_YN\":\"N\",\"INDPND_IPTV_DMG_LINE_CNT\":\"0\",\"NMS_DABL_NUM_CTT\":\"156159603\",\"TM_CTT\":\"\"}");
//			list.add("{\"EQUIP_MDL_NM\":\"온습도계\",\"DABL_CD\":\"059001\",\"OCCR_DTM\":\"20240617153345\",\"SBNMS_EQUIP_NM\":\"온습도계\",\"DABL_DESC\":\"현재값: 28.1℃ [모듈1]온도의 값이 28℃ 이상입니다.\",\"DABL_GR_CD\":\"03\",\"DABL_LOC_NM\":\"동작\",\"EQUIP_NM\":\"동작_6층_온습도계#2\",\"DABL_MCL_CD\":\"05901\",\"NMS_NM\":\"MIDKNIGHT\",\"NET_CL_NM\":\"ETC\",\"DABL_LCL_NM\":\"환경장애\",\"DABL_ST_CD\":\"01\",\"OCCR_RCV_DTM\":\"20240617153346\",\"SUP_EQUIP_NM\":\"동작_6층_온습도계#2\",\"DABL_OCCR_LOC_DESC\":\"고온 발생\",\"EQUIP_TID_VAL\":\"7174\",\"kind\":\"GEN\",\"SERVER_TYPE\":\"CAPITAL\",\"EQUIP_ID\":\"7174\",\"DABL_MCL_NM\":\"환경장애\",\"DABL_NM\":\"MIDKNIGHT환경장애\",\"NMS_CD\":\"012\",\"NET_CL_CD\":\"99\",\"DABL_LCL_CD\":\"05\",\"NMS_DABL_NUM_CTT\":\"5496360\",\"DABL_ST_NM\":\"장애중\",\"INFO_CNTR_NM\":\"동작\"}");
//			list.add("{\"AFF_IP\":\"218.234.10.73\",\"OCCR_DTM\":\"20240702160645\",\"GRP_ID\":\"\",\"EQUIP_IP_ADDR\":\"\",\"CENTER_NAME\":\"\",\"DABL_GR_CD\":\"01\",\"DAPS_BLOCK_FLAG\":\"0\",\"AREA_CODE\":\"\",\"CUST_MAC\":\"\",\"DEV_AREA_CODE\":\"\",\"DABL_MCL_CD\":\"06501\",\"EQUIP_NM\":null,\"BLOCK_TYPE\":\"\",\"NMS_NM\":\"DAPS\",\"NET_CL_NM\":\"IP\",\"DABL_LCL_NM\":\"기타장애\",\"KEEP_TMS\":\"143\",\"OCCR_RCV_DTM\":\"20240702160911\",\"IMPACT_PPS\":\"36427.0\",\"AREA_NAME\":\"\",\"kind\":\"GEN\",\"GRP_NM\":\"DDoSCZ\",\"EVENT_TIME\":\"2024-07-02 16:06:45\",\"DEV_AREA_NAME\":\"\",\"DABL_NM\":\"이상트래픽\",\"NET_CL_CD\":\"05\",\"CUST_NUM\":\"\",\"DABL_LCL_CD\":\"06\",\"IMPACT_BPS\":\"401588224.0\",\"EVENT_ID\":\"1402139\",\"DABL_ST_NM\":\"장애중\",\"DEV_TEAM_NAME\":\"\",\"DABL_CD\":\"065001\",\"DST_IP\":\"113.217.247.90\\/32\",\"SRC_IP\":\"218.234.10.73\\/32\",\"ASNUM\":\"18175\",\"DEV_IP\":\"\",\"DAPS_BLOCK_FLAG_NM\":\"미차단\",\"DEV_NUM\":\"\",\"DAPS_GRP_NM\":\"\",\"DAPS_INFC_NM\":\"\",\"TEAM_CODE\":\"\",\"DAPS_GROUP_NAME\":\"\",\"DABL_ST_CD\":\"01\",\"GROUP_CODE\":\"\",\"DEV_TEAM_CODE\":\"\",\"EQUIP_TID_VAL\":\"\",\"PROTOCOLS\":\"Total Traffic\",\"CLEAN_BLOCK_FLAG\":\"0\",\"DIRECTION\":\"Incoming\",\"DEV_NAME\":\"\",\"DABL_MCL_NM\":\"이상트래픽\",\"ARBOR_ID\":\"\",\"GROUP_NAME\":\"DDoSCZ\",\"NMS_CD\":\"013\",\"TEAM_NAME\":\"\",\"NMS_DABL_NUM_CTT\":\"1402139\",\"DURATION_TIME\":\"143\",\"ALERT_TYPE\":\"low\"}");
//			list.add("{\"AFF_IP\":\"211.234.202.168\",\"OCCR_DTM\":\"20240702160604\",\"GRP_ID\":\"\",\"EQUIP_IP_ADDR\":\"\",\"CENTER_NAME\":\"\",\"DABL_GR_CD\":\"01\",\"DAPS_BLOCK_FLAG\":\"0\",\"AREA_CODE\":\"\",\"CUST_MAC\":\"\",\"DEV_AREA_CODE\":\"\",\"DABL_MCL_CD\":\"06501\",\"EQUIP_NM\":null,\"BLOCK_TYPE\":\"\",\"NMS_NM\":\"DAPS\",\"NET_CL_NM\":\"IP\",\"DABL_LCL_NM\":\"기타장애\",\"KEEP_TMS\":\"134\",\"OCCR_RCV_DTM\":\"20240702160820\",\"IMPACT_PPS\":\"29252.0\",\"AREA_NAME\":\"기업\",\"kind\":\"GEN\",\"GRP_NM\":\"기업\",\"EVENT_TIME\":\"2024-07-02 16:06:04\",\"DEV_AREA_NAME\":\"\",\"DABL_NM\":\"이상트래픽\",\"NET_CL_CD\":\"05\",\"CUST_NUM\":\"\",\"DABL_LCL_CD\":\"06\",\"IMPACT_BPS\":\"319753696.0\",\"EVENT_ID\":\"1402138\",\"DABL_ST_NM\":\"장애중\",\"DEV_TEAM_NAME\":\"\",\"DABL_CD\":\"065001\",\"DST_IP\":\"\",\"SRC_IP\":\"\",\"ASNUM\":\"9644\",\"DEV_IP\":\"\",\"DAPS_BLOCK_FLAG_NM\":\"미차단\",\"DEV_NUM\":\"\",\"DAPS_GRP_NM\":\"\",\"DAPS_INFC_NM\":\"\",\"TEAM_CODE\":\"\",\"DAPS_GROUP_NAME\":\"\",\"DABL_ST_CD\":\"01\",\"GROUP_CODE\":\"\",\"DEV_TEAM_CODE\":\"\",\"EQUIP_TID_VAL\":\"\",\"PROTOCOLS\":\"TCP SYN\\/ACK Amplification\",\"CLEAN_BLOCK_FLAG\":\"0\",\"DIRECTION\":\"Incoming\",\"DEV_NAME\":\"\",\"DABL_MCL_NM\":\"이상트래픽\",\"ARBOR_ID\":\"\",\"GROUP_NAME\":\"기업\",\"NMS_CD\":\"013\",\"TEAM_NAME\":\"\",\"NMS_DABL_NUM_CTT\":\"1402138\",\"DURATION_TIME\":\"134\",\"ALERT_TYPE\":\"high\"}");
//			list.add("{\"AFF_IP\":\"116.121.24.86\",\"OCCR_DTM\":\"20240617154534\",\"GRP_ID\":\"\",\"EQUIP_IP_ADDR\":\"\",\"CENTER_NAME\":\"\",\"DABL_GR_CD\":\"01\",\"DAPS_BLOCK_FLAG\":\"0\",\"AREA_CODE\":\"\",\"CUST_MAC\":\"\",\"DEV_AREA_CODE\":\"\",\"DABL_MCL_CD\":\"06501\",\"EQUIP_NM\":null,\"BLOCK_TYPE\":\"\",\"NMS_NM\":\"DAPS\",\"NET_CL_NM\":\"IP\",\"DABL_LCL_NM\":\"기타장애\",\"KEEP_TMS\":\"133\",\"OCCR_RCV_DTM\":\"20240617154748\",\"IMPACT_PPS\":\"76277.0\",\"AREA_NAME\":\"\",\"kind\":\"GEN\",\"GRP_NM\":\"DDoSCZ\",\"EVENT_TIME\":\"2024-06-17 15:45:34\",\"DEV_AREA_NAME\":\"\",\"DABL_NM\":\"이상트래픽\",\"NET_CL_CD\":\"05\",\"CUST_NUM\":\"\",\"DABL_LCL_CD\":\"06\",\"IMPACT_BPS\":\"614585472.0\",\"EVENT_ID\":\"1402135\",\"DABL_ST_NM\":\"장애중\",\"DEV_TEAM_NAME\":\"\",\"DABL_CD\":\"065001\",\"DST_IP\":\"211.244.219.188\\/32\",\"SRC_IP\":\"116.121.24.86\\/32\",\"ASNUM\":\"9578\",\"DEV_IP\":\"\",\"DAPS_BLOCK_FLAG_NM\":\"미차단\",\"DEV_NUM\":\"\",\"DAPS_GRP_NM\":\"\",\"DAPS_INFC_NM\":\"\",\"TEAM_CODE\":\"\",\"DAPS_GROUP_NAME\":\"\",\"DABL_ST_CD\":\"01\",\"GROUP_CODE\":\"\",\"DEV_TEAM_CODE\":\"\",\"EQUIP_TID_VAL\":\"\",\"PROTOCOLS\":\"UDP\",\"CLEAN_BLOCK_FLAG\":\"0\",\"DIRECTION\":\"Incoming\",\"DEV_NAME\":\"\",\"DABL_MCL_NM\":\"이상트래픽\",\"ARBOR_ID\":\"\",\"GROUP_NAME\":\"DDoSCZ\",\"NMS_CD\":\"013\",\"TEAM_NAME\":\"\",\"NMS_DABL_NUM_CTT\":\"1402135\",\"DURATION_TIME\":\"133\",\"ALERT_TYPE\":\"high\"}");
//			list.add("{\"DABL_CD\":\"015001\",\"EQUIP_MDL_NM\":\"Alcatel SR 7750\",\"OCCR_DTM\":\"20240617145523\",\"EQUIP_IP_ADDR\":\"124.111.86.2\",\"SBNMS_EQUIP_NM\":\"SLSDM_FBS2\",\"DABL_DESC\":\"출력 Utilization 변동률 장애 발생(477.550\\/200.000)\",\"DABL_GR_CD\":\"04\",\"TEAM_ORG_ID\":\"\",\"DABL_MCL_CD\":\"01501\",\"EQUIP_NM\":\"SLSDM_FBS2\",\"NMS_NM\":\"백본정보망\",\"NET_CL_NM\":\"IP\",\"DABL_LCL_NM\":\"장비장애\",\"DABL_ST_CD\":\"01\",\"OCCR_RCV_DTM\":\"2024-06-17 14:55:23\",\"MGMT_TPO_NM\":\"None\",\"DABL_OCCR_LOC_DESC\":\"9\\/1\\/12\",\"EQUIP_TID_VAL\":\"SLSDM_FBS2\",\"EQUIP_MDL_CD\":\"0000\",\"DMG_SCRBR_CNT\":\"0\",\"kind\":\"GEN\",\"TEAM_ORG_NM\":\"None\",\"DABL_MCL_NM\":\"정보기간망장애\",\"DABL_NM\":\"정보기간망장비장애\",\"NMS_CD\":\"006\",\"NET_CL_CD\":\"05\",\"DABL_LCL_CD\":\"01\",\"PORT_ALS_NM\":\"[cust|media] 7303901649-F\\/B-Media_Can#2_[S][AS:0]FDF[MSPP]_1G\",\"NMS_DABL_NUM_CTT\":\"26667518\",\"DABL_ST_NM\":\"장애중\",\"MGMT_TPO_CD\":\"A30100\"}");
			
//			list.add("{\"DABL_CD\":\"015002\",\"EQUIP_MDL_NM\":\"DSW2624G\",\"OCCR_DTM\":\"20240617141500\",\"EQUIP_IP_ADDR\":\"100.96.103.101\",\"ROUT_NUM\":\"\",\"DABL_DESC\":\"ICMP 응답이 없습니다.\",\"DABL_GR_CD\":\"05\",\"SUP_EQUIP_ID1\":null,\"DABL_MCL_CD\":\"01502\",\"EQUIP_NM\":\"강릉_포남_소라연립주택\",\"MODULE_EQUIP_NM\":\"\",\"MODULE_EQUIP_ID\":\"0\",\"PORT_NO\":\"-1\",\"NMS_NM\":\"B2B\",\"NET_CL_NM\":\"IP\",\"DABL_LCL_NM\":\"장비장애\",\"DABL_ST_CD\":\"01\",\"OCCR_RCV_DTM\":\"20240617141607\",\"SUP_EQUIP_NM\":null,\"DABL_OCCR_LOC_DESC\":\"\",\"EQUIP_TID_VAL\":\"강릉_포남_소라연립주택\",\"EQUIP_MDL_CD\":\"0000000865\",\"MSC_MODULE_NM\":\"\",\"kind\":\"GENVOC\",\"EQUIP_ID\":\"000000498478\",\"SUP_EQUIP_NM1\":null,\"DABL_MCL_NM\":\"BMS장비장애\",\"DABL_NM\":\"BMS장비장애\",\"NMS_CD\":\"009\",\"NET_CL_CD\":\"05\",\"DABL_LCL_CD\":\"01\",\"NMS_DABL_NUM_CTT\":\"51354154\",\"DABL_ST_NM\":\"장애중\",\"EQUIP_DABL_MSG_CTT\":\"ICMP 응답이 없습니다.\"}");
//			list.add("{\"EQUIP_MDL_NM\":\"DSW3308G\",\"OCCR_DTM\":\"20240617131500\",\"EQUIP_IP_ADDR\":\"100.90.176.98\",\"LINE_CL_CD\":\"A001\",\"LINE_NUM\":\"000001143539\",\"DABL_DESC\":\"ICMP 응답이 없습니다.\",\"DABL_GR_CD\":\"05\",\"CHRGR_NM\":null,\"SUP_EQUIP_ID1\":\"000705824984\",\"DABL_MCL_CD\":\"04501\",\"EQUIP_NM\":\"태광산업(주)\",\"MODULE_EQUIP_ID\":\"0\",\"NMS_NM\":\"B2B\",\"NET_CL_NM\":\"IP\",\"DABL_LCL_NM\":\"회선장애\",\"OCCR_RCV_DTM\":\"20240617131606\",\"MGMT_TPO_NM\":\"대전\\/서\",\"INFO_CNTR_CD\":\"F10100\",\"SUP_EQUIP_NM\":\"DJSEO_FCO14\",\"LINE_CL_NM\":\"일반회선\",\"DABL_OCCR_LOC_DESC\":\"\",\"MSC_MODULE_NM\":\"\",\"SUB_TPO_CD\":\"F10100\",\"kind\":\"GENVOC\",\"SUP_EQUIP_NM1\":\"DJSEO_FCO14\",\"CUST_NM\":\"태광산업(주)\",\"CHRGR_ID\":\"1000794716\",\"TPO_CD\":\"F10100\",\"DABL_NM\":\"BMS회선장애\",\"NET_CL_CD\":\"05\",\"DABL_LCL_CD\":\"04\",\"CUST_NUM\":\"9900002119\",\"DISTB_CNTR_NM\":\"대전\\/서\",\"DABL_ST_NM\":\"장애중\",\"EQUIP_DABL_MSG_CTT\":\"ICMP 응답이 없습니다.\",\"LINE_NM\":\"태광산업(주)\",\"INFO_CNTR_NM\":\"대전\\/서\",\"DABL_CD\":\"045001\",\"SUB_TPO_NM\":\"대전\\/서\",\"SUP_TPO_CD\":\"F10100\",\"ROUT_NUM\":\"\",\"SPEED_NM\":\"100Mbps\",\"TPO_NM\":\"대전\\/서\",\"MODULE_EQUIP_NM\":\"\",\"PORT_NO\":\"-1\",\"SVC_MGMT_NUM\":\"7314711312\",\"DABL_ST_CD\":\"01\",\"CUST_CHRTIC_CD\":null,\"SVC_TECH_MTHD_NM\":\"프리밴(FTTx)\",\"EQUIP_TID_VAL\":\"\",\"EQUIP_MDL_CD\":\"A000100754\",\"SUP_TPO_NM\":\"대전\\/서\",\"SPEED_CD\":\"K6\",\"EQUIP_ID\":\"000838443548\",\"DABL_MCL_NM\":\"BMS회선장애\",\"NMS_CD\":\"009\",\"CUST_CHRTIC_NM\":\"일반회선\",\"NMS_DABL_NUM_CTT\":\"51354065\",\"SVC_TECH_MTHD_CD\":\"H0011\",\"MGMT_TPO_CD\":\"F10100\"}");
//			list.add("{\"EQUIP_MDL_NM\":\"cBR-8\",\"OCCR_DTM\":\"20240617140509\",\"EQUIP_IP_ADDR\":\"172.23.10.33\",\"DSST_YN\":\"\",\"DABL_GR_CD\":\"02\",\"DABL_DESC\":\"VPN Channel Down[MAC:0002.00BD.7B40][CM IP:10.92.153.58][WAN IP:114.201.52.130][전주번호(청약):신곡간41L3A2][전산화번호(청약):0236X051][전주번호:null][한전본부명:경기북지역본부]\",\"PORT_NUM\":\"\",\"NET_OP_NUM\":\"\",\"DABL_MCL_CD\":\"01415\",\"EQUIP_NM\":\"WB480007\",\"DSSTR_YN\":\"\",\"MODULE_EQUIP_ID\":\"\",\"NMS_NM\":\"RMS\",\"NET_CL_NM\":\"HFC\",\"TOT_VOC_CNT\":\"0\",\"DABL_LCL_NM\":\"장비장애\",\"IPTV_VOC_CNT\":\"0\",\"OCCR_RCV_DTM\":\"2024-06-17 14:07:17\",\"INFO_CNTR_CD\":\"\",\"DABL_DUP_YN\":\"\",\"PHON_VOC_CNT\":\"0\",\"ROUT_NM\":\"\",\"MKT_DIV_ORG_ID\":\"\",\"DABL_OCCR_LOC_DESC\":\"_14__\",\"DMG_SCRBR_CNT\":\"\",\"MSC_MODULE_NM\":\"\",\"kind\":\"GENVOC\",\"SCARD_NUM_CTT\":\"\",\"GNLPH_DMG_LINE_CNT\":\"0\",\"DABL_NM\":\"VPN Channel State\",\"VOIP_VOC_CNT\":\"0\",\"NET_CL_CD\":\"04\",\"EQUIP_SET_LOC_DESC\":\"\",\"DABL_LCL_CD\":\"01\",\"OPER_DABL_YN\":\"N\",\"DISTB_CNTR_NM\":\"\",\"DABL_ST_NM\":\"장애중\",\"TM_TYP_CD\":\"\",\"CCELL_NUM\":\"14\",\"INFO_CNTR_NM\":\"\",\"DABL_CD\":\"014254\",\"GNRL_IPTV_DMG_LINE_CNT\":\"0\",\"ROUT_NUM\":\"\",\"TEAM_ORG_ID\":\"\",\"SHSPD_VOC_CNT\":\"0\",\"DABL_DUP_CNT_2\":\"1\",\"DABL_DUP_CNT_3\":\"1\",\"DABL_DUP_CNT_1\":\"1\",\"DABL_ST_CD\":\"01\",\"OTX_NUM\":\"\",\"MKT_DIV_ORG_NM\":\"\",\"DISTB_CNTR_CD\":\"\",\"EQUIP_TID_VAL\":\"WB480007\",\"EQUIP_MDL_CD\":\"DCU\",\"SHSPD_INET_DMG_LINE_CNT\":\"0\",\"TEAM_ORG_NM\":\"\",\"DABL_DUP_CNT\":\"\",\"EQUIP_ID\":\"WB480007\",\"DABL_MCL_NM\":\"한전AMI장애\",\"NMS_CD\":\"011\",\"INCOMM_BIZR_ID\":\"\",\"SWING_ANNCE_YN\":\"N\",\"INDPND_IPTV_DMG_LINE_CNT\":\"0\",\"NMS_DABL_NUM_CTT\":\"156159603\",\"TM_CTT\":\"\"}");
//			list.add("{\"EQUIP_MDL_NM\":\"온습도계\",\"DABL_CD\":\"059001\",\"OCCR_DTM\":\"20240617153345\",\"SBNMS_EQUIP_NM\":\"온습도계\",\"DABL_DESC\":\"현재값: 28.1℃ [모듈1]온도의 값이 28℃ 이상입니다.\",\"DABL_GR_CD\":\"03\",\"DABL_LOC_NM\":\"동작\",\"EQUIP_NM\":\"동작_6층_온습도계#2\",\"DABL_MCL_CD\":\"05901\",\"NMS_NM\":\"MIDKNIGHT\",\"NET_CL_NM\":\"ETC\",\"DABL_LCL_NM\":\"환경장애\",\"DABL_ST_CD\":\"01\",\"OCCR_RCV_DTM\":\"20240617153346\",\"SUP_EQUIP_NM\":\"동작_6층_온습도계#2\",\"DABL_OCCR_LOC_DESC\":\"고온 발생\",\"EQUIP_TID_VAL\":\"7174\",\"kind\":\"GENVOC\",\"SERVER_TYPE\":\"CAPITAL\",\"EQUIP_ID\":\"7174\",\"DABL_MCL_NM\":\"환경장애\",\"DABL_NM\":\"MIDKNIGHT환경장애\",\"NMS_CD\":\"012\",\"NET_CL_CD\":\"99\",\"DABL_LCL_CD\":\"05\",\"NMS_DABL_NUM_CTT\":\"5496360\",\"DABL_ST_NM\":\"장애중\",\"INFO_CNTR_NM\":\"동작\"}");
//			list.add("{\"AFF_IP\":\"218.234.10.73\",\"OCCR_DTM\":\"20240617160645\",\"GRP_ID\":\"\",\"EQUIP_IP_ADDR\":\"\",\"CENTER_NAME\":\"\",\"DABL_GR_CD\":\"01\",\"DAPS_BLOCK_FLAG\":\"0\",\"AREA_CODE\":\"\",\"CUST_MAC\":\"\",\"DEV_AREA_CODE\":\"\",\"DABL_MCL_CD\":\"06501\",\"EQUIP_NM\":null,\"BLOCK_TYPE\":\"\",\"NMS_NM\":\"DAPS\",\"NET_CL_NM\":\"IP\",\"DABL_LCL_NM\":\"기타장애\",\"KEEP_TMS\":\"143\",\"OCCR_RCV_DTM\":\"20240617160911\",\"IMPACT_PPS\":\"36427.0\",\"AREA_NAME\":\"\",\"kind\":\"GENVOC\",\"GRP_NM\":\"DDoSCZ\",\"EVENT_TIME\":\"2024-06-17 16:06:45\",\"DEV_AREA_NAME\":\"\",\"DABL_NM\":\"이상트래픽\",\"NET_CL_CD\":\"05\",\"CUST_NUM\":\"\",\"DABL_LCL_CD\":\"06\",\"IMPACT_BPS\":\"401588224.0\",\"EVENT_ID\":\"1402139\",\"DABL_ST_NM\":\"장애중\",\"DEV_TEAM_NAME\":\"\",\"DABL_CD\":\"065001\",\"DST_IP\":\"113.217.247.90\\/32\",\"SRC_IP\":\"218.234.10.73\\/32\",\"ASNUM\":\"18175\",\"DEV_IP\":\"\",\"DAPS_BLOCK_FLAG_NM\":\"미차단\",\"DEV_NUM\":\"\",\"DAPS_GRP_NM\":\"\",\"DAPS_INFC_NM\":\"\",\"TEAM_CODE\":\"\",\"DAPS_GROUP_NAME\":\"\",\"DABL_ST_CD\":\"01\",\"GROUP_CODE\":\"\",\"DEV_TEAM_CODE\":\"\",\"EQUIP_TID_VAL\":\"\",\"PROTOCOLS\":\"Total Traffic\",\"CLEAN_BLOCK_FLAG\":\"0\",\"DIRECTION\":\"Incoming\",\"DEV_NAME\":\"\",\"DABL_MCL_NM\":\"이상트래픽\",\"ARBOR_ID\":\"\",\"GROUP_NAME\":\"DDoSCZ\",\"NMS_CD\":\"013\",\"TEAM_NAME\":\"\",\"NMS_DABL_NUM_CTT\":\"1402139\",\"DURATION_TIME\":\"143\",\"ALERT_TYPE\":\"low\"}");
//			list.add("{\"AFF_IP\":\"211.234.202.168\",\"OCCR_DTM\":\"20240617160604\",\"GRP_ID\":\"\",\"EQUIP_IP_ADDR\":\"\",\"CENTER_NAME\":\"\",\"DABL_GR_CD\":\"01\",\"DAPS_BLOCK_FLAG\":\"0\",\"AREA_CODE\":\"\",\"CUST_MAC\":\"\",\"DEV_AREA_CODE\":\"\",\"DABL_MCL_CD\":\"06501\",\"EQUIP_NM\":null,\"BLOCK_TYPE\":\"\",\"NMS_NM\":\"DAPS\",\"NET_CL_NM\":\"IP\",\"DABL_LCL_NM\":\"기타장애\",\"KEEP_TMS\":\"134\",\"OCCR_RCV_DTM\":\"20240617160820\",\"IMPACT_PPS\":\"29252.0\",\"AREA_NAME\":\"기업\",\"kind\":\"GENVOC\",\"GRP_NM\":\"기업\",\"EVENT_TIME\":\"2024-06-17 16:06:04\",\"DEV_AREA_NAME\":\"\",\"DABL_NM\":\"이상트래픽\",\"NET_CL_CD\":\"05\",\"CUST_NUM\":\"\",\"DABL_LCL_CD\":\"06\",\"IMPACT_BPS\":\"319753696.0\",\"EVENT_ID\":\"1402138\",\"DABL_ST_NM\":\"장애중\",\"DEV_TEAM_NAME\":\"\",\"DABL_CD\":\"065001\",\"DST_IP\":\"\",\"SRC_IP\":\"\",\"ASNUM\":\"9644\",\"DEV_IP\":\"\",\"DAPS_BLOCK_FLAG_NM\":\"미차단\",\"DEV_NUM\":\"\",\"DAPS_GRP_NM\":\"\",\"DAPS_INFC_NM\":\"\",\"TEAM_CODE\":\"\",\"DAPS_GROUP_NAME\":\"\",\"DABL_ST_CD\":\"01\",\"GROUP_CODE\":\"\",\"DEV_TEAM_CODE\":\"\",\"EQUIP_TID_VAL\":\"\",\"PROTOCOLS\":\"TCP SYN\\/ACK Amplification\",\"CLEAN_BLOCK_FLAG\":\"0\",\"DIRECTION\":\"Incoming\",\"DEV_NAME\":\"\",\"DABL_MCL_NM\":\"이상트래픽\",\"ARBOR_ID\":\"\",\"GROUP_NAME\":\"기업\",\"NMS_CD\":\"013\",\"TEAM_NAME\":\"\",\"NMS_DABL_NUM_CTT\":\"1402138\",\"DURATION_TIME\":\"134\",\"ALERT_TYPE\":\"high\"}");
//			list.add("{\"AFF_IP\":\"116.121.24.86\",\"OCCR_DTM\":\"20240617154534\",\"GRP_ID\":\"\",\"EQUIP_IP_ADDR\":\"\",\"CENTER_NAME\":\"\",\"DABL_GR_CD\":\"01\",\"DAPS_BLOCK_FLAG\":\"0\",\"AREA_CODE\":\"\",\"CUST_MAC\":\"\",\"DEV_AREA_CODE\":\"\",\"DABL_MCL_CD\":\"06501\",\"EQUIP_NM\":null,\"BLOCK_TYPE\":\"\",\"NMS_NM\":\"DAPS\",\"NET_CL_NM\":\"IP\",\"DABL_LCL_NM\":\"기타장애\",\"KEEP_TMS\":\"133\",\"OCCR_RCV_DTM\":\"20240617154748\",\"IMPACT_PPS\":\"76277.0\",\"AREA_NAME\":\"\",\"kind\":\"GENVOC\",\"GRP_NM\":\"DDoSCZ\",\"EVENT_TIME\":\"2024-06-17 15:45:34\",\"DEV_AREA_NAME\":\"\",\"DABL_NM\":\"이상트래픽\",\"NET_CL_CD\":\"05\",\"CUST_NUM\":\"\",\"DABL_LCL_CD\":\"06\",\"IMPACT_BPS\":\"614585472.0\",\"EVENT_ID\":\"1402135\",\"DABL_ST_NM\":\"장애중\",\"DEV_TEAM_NAME\":\"\",\"DABL_CD\":\"065001\",\"DST_IP\":\"211.244.219.188\\/32\",\"SRC_IP\":\"116.121.24.86\\/32\",\"ASNUM\":\"9578\",\"DEV_IP\":\"\",\"DAPS_BLOCK_FLAG_NM\":\"미차단\",\"DEV_NUM\":\"\",\"DAPS_GRP_NM\":\"\",\"DAPS_INFC_NM\":\"\",\"TEAM_CODE\":\"\",\"DAPS_GROUP_NAME\":\"\",\"DABL_ST_CD\":\"01\",\"GROUP_CODE\":\"\",\"DEV_TEAM_CODE\":\"\",\"EQUIP_TID_VAL\":\"\",\"PROTOCOLS\":\"UDP\",\"CLEAN_BLOCK_FLAG\":\"0\",\"DIRECTION\":\"Incoming\",\"DEV_NAME\":\"\",\"DABL_MCL_NM\":\"이상트래픽\",\"ARBOR_ID\":\"\",\"GROUP_NAME\":\"DDoSCZ\",\"NMS_CD\":\"013\",\"TEAM_NAME\":\"\",\"NMS_DABL_NUM_CTT\":\"1402135\",\"DURATION_TIME\":\"133\",\"ALERT_TYPE\":\"high\"}");
//			list.add("{\"DABL_CD\":\"015001\",\"EQUIP_MDL_NM\":\"Alcatel SR 7750\",\"OCCR_DTM\":\"20240617145523\",\"EQUIP_IP_ADDR\":\"124.111.86.2\",\"SBNMS_EQUIP_NM\":\"SLSDM_FBS2\",\"DABL_DESC\":\"출력 Utilization 변동률 장애 발생(477.550\\/200.000)\",\"DABL_GR_CD\":\"04\",\"TEAM_ORG_ID\":\"\",\"DABL_MCL_CD\":\"01501\",\"EQUIP_NM\":\"SLSDM_FBS2\",\"NMS_NM\":\"백본정보망\",\"NET_CL_NM\":\"IP\",\"DABL_LCL_NM\":\"장비장애\",\"DABL_ST_CD\":\"01\",\"OCCR_RCV_DTM\":\"2024-06-17 14:55:23\",\"MGMT_TPO_NM\":\"None\",\"DABL_OCCR_LOC_DESC\":\"9\\/1\\/12\",\"EQUIP_TID_VAL\":\"SLSDM_FBS2\",\"EQUIP_MDL_CD\":\"0000\",\"DMG_SCRBR_CNT\":\"0\",\"kind\":\"GENVOC\",\"TEAM_ORG_NM\":\"None\",\"DABL_MCL_NM\":\"정보기간망장애\",\"DABL_NM\":\"정보기간망장비장애\",\"NMS_CD\":\"006\",\"NET_CL_CD\":\"05\",\"DABL_LCL_CD\":\"01\",\"PORT_ALS_NM\":\"[cust|media] 7303901649-F\\/B-Media_Can#2_[S][AS:0]FDF[MSPP]_1G\",\"NMS_DABL_NUM_CTT\":\"26667518\",\"DABL_ST_NM\":\"장애중\",\"MGMT_TPO_CD\":\"A30100\"}");
			
			//240617 장비/회선장애 해제
//			list.add("{\"NMS_CD\":\"009\",\"kind\":\"CLR\",\"DABL_ST_CD\":\"02\",\"RLSE_RCV_DTM\":\"20240617142106\",\"NMS_DABL_NUM_CTT\":\"51354154\",\"DABL_ST_NM\":\"장애해제\",\"RLSE_DTM\":\"20240617142000\"}");
//			list.add("{\"NMS_CD\":\"009\",\"kind\":\"CLR\",\"DABL_ST_CD\":\"02\",\"RLSE_RCV_DTM\":\"20240617132557\",\"NMS_DABL_NUM_CTT\":\"51354065\",\"DABL_ST_NM\":\"장애해제\",\"RLSE_DTM\":\"20240617132500\"}");
//			list.add("{\"NMS_CD\":\"011\",\"NET_CL_CD\":\"04\",\"DABL_LCL_CD\":\"01\",\"NMS_NM\":\"RMS\",\"NET_CL_NM\":\"HFC\",\"kind\":\"CLR\",\"DABL_ST_CD\":\"02\",\"NMS_DABL_NUM_CTT\":\"156159603\",\"RLSE_RCV_DTM\":\"2024-06-17 14:08:06\",\"DABL_ST_NM\":\"장애해제\",\"RLSE_DTM\":\"20240617140509\"}");
//			list.add("{\"EQUIP_MDL_NM\":\"온습도계\",\"DABL_CD\":\"059001\",\"OCCR_DTM\":\"20240702153345\",\"SBNMS_EQUIP_NM\":\"온습도계\",\"DABL_DESC\":\"Minor : 동작_6층_온습도계#2: 현재값: 28.1℃ [모듈1]온도의 값이 28℃ 이상입니다.\",\"DABL_GR_CD\":\"03\",\"RLSE_RCV_DTM\":\"20240702153926\",\"DABL_LOC_NM\":\"동작\",\"EQUIP_NM\":\"동작_6층_온습도계#2\",\"DABL_MCL_CD\":\"05901\",\"NMS_NM\":\"MIDKNIGHT\",\"NET_CL_NM\":\"ETC\",\"DABL_LCL_NM\":\"환경장애\",\"DABL_ST_CD\":\"02\",\"OCCR_RCV_DTM\":\"20240702153926\",\"RLSE_DTM\":\"20240702153345\",\"SUP_EQUIP_NM\":\"동작_6층_온습도계#2\",\"DABL_OCCR_LOC_DESC\":\"고온 발생\",\"EQUIP_TID_VAL\":\"7174\",\"kind\":\"CLR\",\"SERVER_TYPE\":\"CAPITAL\",\"EQUIP_ID\":\"7174\",\"DABL_MCL_NM\":\"환경장애\",\"DABL_NM\":\"MIDKNIGHT환경장애\",\"NMS_CD\":\"012\",\"NET_CL_CD\":\"99\",\"DABL_LCL_CD\":\"05\",\"NMS_DABL_NUM_CTT\":\"5496360\",\"DABL_ST_NM\":\"장애해제\",\"INFO_CNTR_NM\":\"동작\"}");
//			list.add("{\"NMS_CD\":\"006\",\"kind\":\"CLR\",\"DABL_ST_CD\":\"02\",\"RLSE_RCV_DTM\":\"2024-06-17 15:00:22\",\"NMS_DABL_NUM_CTT\":\"26667518\",\"DABL_ST_NM\":\"장애해제\",\"RLSE_DTM\":\"20240617145523\"}");
			
//			for(String jsonStr : list){
//				jsonSender.put(convertJsonObj(jsonStr));
//			}

//			teamsTest(); //teams장비장애
//			teamsLineFault(); //teams회선장애
//			fomsNetTest(); //foms장비장애
//			fomsAmiTest(); //foms장비장애
//			fomsEnvTest(); //foms장비장애
//			fomsSyslogTest();
//			fomsSyslogTest2();
//			fomsBizLevelTest();
			
//			teamsClearFault(); //teams장비장애해제
//			teamsClearLineFault(); //teams회선장애해제
//			fomsClear(); //foms장비장애해제
			
			rmsCatvTest();

		} catch (Exception e ) {
			logger.error("Exception", e);
		} finally {
			System.exit(0);
		}
	}
	
	private void rmsCatvTest() throws Exception {
		
		omn30203Map = new HashMap<String, OMN30203>();
		List<OMN30203> omn30203List = (List) adamsSession.selectList("RealtimeRms.selectOMN30203", null);
		for (OMN30203 omn30203 : omn30203List) {
			String key = omn30203.getClctEvtId() + omn30203.getClctEvtCd();
			omn30203Map.put(key, omn30203);
			logger.debug(String.format("(%s),(%s,%s,%s,%s,%s,%s,%s,%s)",
					key,
					omn30203.getDablLclCd(), omn30203.getDablLclNm(), omn30203.getDablMclCd(), omn30203.getDablMclNm(),
					omn30203.getDablCd(), omn30203.getDablCdNm(), omn30203.getClctEvtId(), omn30203.getClctEvtCd()));
		}
		
		String[] arr = new String[54];
		
		arr[0] = "901";
		arr[1] = "16141613";
		arr[2] = "95";
		arr[3] = "31";
		arr[4] = "0";
		arr[5] = "20250404133504";
		arr[6] = "2";
		arr[7] = "전송망경보";
		arr[8] = "300";
		arr[9] = "부산";
		arr[10] = "O58224";
		arr[11] = "[CATV]서부산_HFC국사";
		arr[12] = "WB750429";
		arr[13] = "172.22.29.68";
		arr[14] = "SBSB_10K_04";
		arr[15] = "2820";
		arr[16] = "W-uBR10";
		arr[17] = "";
		arr[18] = "#M114210";
		arr[19] = "";
		arr[20] = "";
		arr[21] = "(5분전Online:128개 -> Offline:104개발생 offline비율:81.3%) 부산 사하구 하단동";
		arr[22] = "";
		arr[23] = "";
		arr[24] = "";
		arr[25] = "3";
		arr[26] = "11460827";
		arr[27] = "";
		arr[28] = "";
		arr[29] = "";
		arr[30] = "";
		arr[31] = "123";
		arr[32] = "5";
		arr[33] = "5";
		arr[34] = "5";
		arr[35] = "5";
		arr[36] = "5";
		arr[37] = "5";
		arr[38] = "5";
		arr[39] = "5";
		arr[40] = "5";
		arr[41] = "";
		arr[42] = "";
		arr[43] = "";
		arr[44] = "123";
		arr[45] = "5";
		arr[46] = "5";
		arr[47] = "5";
		arr[48] = "5";
		arr[49] = "5";
		arr[50] = "5";
		arr[51] = "5";
		arr[52] = "한빛방송";
		arr[53] = "셀메모정보";
		
		RmsEvent event = new RmsCatvFaultEvent(arr);
		
		rmsSender(event);
		
	}

	public void teamsTest() throws Exception{
		String[] arr = new String[58];
		
		arr[0] = "034001:1225645905:1718598588892";
		arr[1] = "034001";
		arr[2] = "218";
		arr[3] = "FM700";
		arr[4] = "854254";
		arr[5] = "송파_텔레필드_FM700_2링";
		arr[6] = "13-11-1-2-0-0-0-0-0-0";
		arr[7] = "";
		arr[8] = "";
		arr[9] = "5";
		arr[10] = "S5.B-P6";
		arr[11] = "S5.B-6";
		arr[12] = "SDH-MSAIS";
		arr[13] = "222107";
		arr[14] = "송파정보센터";
		arr[15] = "0";
		arr[16] = "1";
		arr[17] = "20240617132948";
		arr[18] = "90384|13-11-1-2-0-0-0-0-0-0|S5.B-6|SDH-MSAIS";
		arr[19] = "N";
		arr[20] = "N";
		arr[21] = "N";
		arr[22] = "N";
		arr[23] = "N";
		arr[24] = "";
		arr[25] = "5F-H4] 송파국사 5층";
		arr[26] = "";
		arr[27] = "";
		arr[28] = "N";
		arr[29] = "N";
		arr[30] = "070000";
		arr[31] = "";
		arr[32] = "003003";
		arr[33] = "N";
		arr[34] = "광장비";
		arr[35] = "";
		arr[36] = "";
		arr[37] = "222107";
		arr[38] = "송파정보센터";
		arr[39] = "11";
		arr[40] = "서울특별시";
		arr[41] = "11710";
		arr[42] = "송파구";
		arr[43] = "20240617132948";
		arr[44] = "C0007872|A10100|A10100";
		arr[45] = "";
		arr[46] = "";
		arr[47] = "";
		arr[48] = "";
		arr[49] = "";
		arr[50] = "";
		arr[51] = "STM1U";
		arr[52] = "N";
		arr[53] = "N";
		arr[54] = "";
		arr[55] = "";
		arr[56] = "128";
		arr[57] = "C";
		
		TeamsEvent e = new TeamsEquipFaultEvent(arr);

		teamsSender(e);
	}
	
	public void teamsLineFault() throws Exception{
		String[] arr = new String[106];
		
		arr[0] = "2024061709:297848145";
		arr[1] = "5";
		arr[2] = "000001720642";
		arr[3] = "국민건강보험공단";
		arr[4] = "9650080219";
		arr[5] = "국민건강보험공단";
		arr[6] = "";
		arr[7] = "7360049056";
		arr[8] = "007009";
		arr[9] = "B기업회선";
		arr[10] = "020P0034";
		arr[11] = "DID/DOD겸용중계선";
		arr[12] = "";
		arr[13] = "013000";
		arr[14] = "NONE";
		arr[15] = "013000";
		arr[16] = "NONE";
		arr[17] = "004000";
		arr[18] = "알수없음";
		arr[19] = "222131";
		arr[20] = "대전/서";
		arr[21] = "";
		arr[22] = "0";
		arr[23] = "";
		arr[24] = "222132";
		arr[25] = "충북/청주";
		arr[26] = "";
		arr[27] = "0";
		arr[28] = "";
		arr[29] = "034001:1225636993:1718584424449";
		arr[30] = "003003";
		arr[31] = "034001";
		arr[32] = "224";
		arr[33] = "UTRANS-3100";
		arr[34] = "908468";
		arr[35] = "충주_지역1링_충주_CWDM_코위버CWDM_S1";
		arr[36] = "12.168.32.243-S1";
		arr[37] = "";
		arr[38] = "";
		arr[39] = "TIU2.B-P1";
		arr[40] = "TIU2.B-C1";
		arr[41] = "(C)LINK-LOS";
		arr[42] = "686995";
		arr[43] = "충주전송국사";
		arr[44] = "20240617093506";
		arr[45] = "125737|12.168.32.243|TIU2.B-C1|(C)LINK-LOS";
		arr[46] = "N";
		arr[47] = "N";
		arr[48] = "N";
		arr[49] = "N";
		arr[50] = "N";
		arr[51] = "";
		arr[52] = "충북/충주";
		arr[53] = "";
		arr[54] = "";
		arr[55] = "N";
		arr[56] = "033SPCXS";
		arr[57] = "기업관리S";
		arr[58] = "-1";
		arr[59] = "43";
		arr[60] = "충청북도";
		arr[61] = "43113";
		arr[62] = "청주시 흥덕구";
		arr[63] = "-1";
		arr[64] = "";
		arr[65] = "";
		arr[66] = "";
		arr[67] = "222131";
		arr[68] = "대전/서";
		arr[69] = "222132";
		arr[70] = "충북/청주";
		arr[71] = "222132";
		arr[72] = "충북/청주";
		arr[73] = "20240617093344";
		arr[74] = "";
		arr[75] = "C0007742|N14151|N01710|F10100|N01710|F10100|N01710|||N";
		arr[76] = "";
		arr[77] = "";
		arr[78] = "";
		arr[79] = "";
		arr[80] = "";
		arr[81] = "";
		arr[82] = "N";
		arr[83] = "222132|222131";
		arr[84] = "충북/청주|대전/서";
		arr[85] = "";
		arr[86] = "";
		arr[87] = "";
		arr[88] = "";
		arr[89] = "";
		arr[90] = "N";
		arr[91] = "";
		arr[92] = "";
		arr[93] = "545842";
		arr[94] = "지역기간망_충주1링_코위버CWDM(충주/감곡RO/음성)[충주_BMSP#01_S3P1<>SKT음성_BMSP#01_S3P1]";
		arr[95] = "CWDM";
		arr[96] = "";
		arr[97] = "A20100";
		arr[98] = "004308700100";
		arr[99] = "";
		arr[100] = "";
		arr[101] = "008AC";
		arr[102] = "사용중";
		arr[103] = "N";
		arr[104] = "1000740381";
		arr[105] = "C";
		
		TeamsEvent e = new TeamsCircuitFaultEvent(arr);

		teamsSender(e);
		
		
		String[] arr2 = new String[106];
		
		arr2[0] = "2024061709:297848146";
		arr2[1] = "5";
		arr2[2] = "000000361029";
		arr2[3] = "금강공업(주)";
		arr2[4] = "9440146019";
		arr2[5] = "금강공업(주)";
		arr2[6] = "";
		arr2[7] = "7235405896";
		arr2[8] = "007009";
		arr2[9] = "B기업회선";
		arr2[10] = "020H0011";
		arr2[11] = "프리밴(FTTx)";
		arr2[12] = "";
		arr2[13] = "013000";
		arr2[14] = "NONE";
		arr2[15] = "013000";
		arr2[16] = "NONE";
		arr2[17] = "004063";
		arr2[18] = "100M";
		arr2[19] = "222132";
		arr2[20] = "충북/청주";
		arr2[21] = "";
		arr2[22] = "0";
		arr2[23] = "";
		arr2[24] = "222132";
		arr2[25] = "충북/청주";
		arr2[26] = "";
		arr2[27] = "0";
		arr2[28] = "";
		arr2[29] = "034001:1225636993:1718584424449";
		arr2[30] = "003003";
		arr2[31] = "034001";
		arr2[32] = "224";
		arr2[33] = "UTRANS-3100";
		arr2[34] = "908468";
		arr2[35] = "충주_지역1링_충주_CWDM_코위버CWDM_S1";
		arr2[36] = "12.168.32.243-S1";
		arr2[37] = "";
		arr2[38] = "";
		arr2[39] = "TIU2.B-P1";
		arr2[40] = "TIU2.B-C1";
		arr2[41] = "(C)LINK-LOS";
		arr2[42] = "686995";
		arr2[43] = "충주전송국사";
		arr2[44] = "20240617093506";
		arr2[45] = "125737|12.168.32.243|TIU2.B-C1|(C)LINK-LOS";
		arr2[46] = "N";
		arr2[47] = "N";
		arr2[48] = "N";
		arr2[49] = "N";
		arr2[50] = "N";
		arr2[51] = "";
		arr2[52] = "충북/충주";
		arr2[53] = "";
		arr2[54] = "";
		arr2[55] = "N";
		arr2[56] = "033006";
		arr2[57] = "일반회선";
		arr2[58] = "-1";
		arr2[59] = "43";
		arr2[60] = "충청북도";
		arr2[61] = "43113";
		arr2[62] = "청주시 흥덕구";
		arr2[63] = "-1";
		arr2[64] = "";
		arr2[65] = "";
		arr2[66] = "";
		arr2[67] = "222132";
		arr2[68] = "충북/청주";
		arr2[69] = "222132";
		arr2[70] = "충북/청주";
		arr2[71] = "222132";
		arr2[72] = "충북/청주";
		arr2[73] = "20240617093344";
		arr2[74] = "";
		arr2[75] = "C0007742|N14151|N01710|N01710|N01710|N01710|N01710|||N";
		arr2[76] = "";
		arr2[77] = "";
		arr2[78] = "";
		arr2[79] = "";
		arr2[80] = "";
		arr2[81] = "";
		arr2[82] = "N";
		arr2[83] = "222132";
		arr2[84] = "충북/청주";
		arr2[85] = "";
		arr2[86] = "";
		arr2[87] = "";
		arr2[88] = "";
		arr2[89] = "";
		arr2[90] = "N";
		arr2[91] = "";
		arr2[92] = "";
		arr2[93] = "545842";
		arr2[94] = "지역기간망_충주1링_코위버CWDM(충주/감곡RO/음성)[충주_BMSP#01_S3P1<>SKT음성_BMSP#01_S3P1]";
		arr2[95] = "CWDM";
		arr2[96] = "N01710";
		arr2[97] = "N01710";
		arr2[98] = "7235405896";
		arr2[99] = "K6";
		arr2[100] = "";
		arr2[101] = "008AC";
		arr2[102] = "사용중";
		arr2[103] = "N";
		arr2[104] = "1002185";
		arr2[105] = "C";
		
		TeamsEvent e2 = new TeamsCircuitFaultEvent(arr2);

		teamsSender(e2);
		
		String[] arr3 = new String[58];
		
		arr3[0] = "034001:1225636993:1718584424449";
		arr3[1] = "034001";
		arr3[2] = "224";
		arr3[3] = "UTRANS-3100";
		arr3[4] = "908468";
		arr3[5] = "충주_지역1링_충주_CWDM_코위버CWDM_S1";
		arr3[6] = "12.168.32.243-S1";
		arr3[7] = "";
		arr3[8] = "";
		arr3[9] = "5";
		arr3[10] = "TIU2.B-P1";
		arr3[11] = "TIU2.B-C1";
		arr3[12] = "(C)LINK-LOS";
		arr3[13] = "686995";
		arr3[14] = "충주전송국사";
		arr3[15] = "2";
		arr3[16] = "1";
		arr3[17] = "20240617093506";
		arr3[18] = "125737|12.168.32.243|TIU2.B-C1|(C)LINK-LOS";
		arr3[19] = "N";
		arr3[20] = "N";
		arr3[21] = "N";
		arr3[22] = "N";
		arr3[23] = "N";
		arr3[24] = "";
		arr3[25] = "충북/충주";
		arr3[26] = "";
		arr3[27] = "";
		arr3[28] = "N";
		arr3[29] = "N";
		arr3[30] = "070000";
		arr3[31] = "";
		arr3[32] = "003003";
		arr3[33] = "N";
		arr3[34] = "CWDM";
		arr3[35] = "";
		arr3[36] = "";
		arr3[37] = "222132";
		arr3[38] = "충북/청주";
		arr3[39] = "43";
		arr3[40] = "충청북도";
		arr3[41] = "43130";
		arr3[42] = "충주시";
		arr3[43] = "20240617093344";
		arr3[44] = "C0007742|N14151|N01710";
		arr3[45] = "";
		arr3[46] = "";
		arr3[47] = "";
		arr3[48] = "";
		arr3[49] = "";
		arr3[50] = "";
		arr3[51] = "";
		arr3[52] = "N";
		arr3[53] = "N";
		arr3[54] = "";
		arr3[55] = "";
		arr3[56] = "64";
		arr3[57] = "C";
		
		TeamsEvent e3 = new TeamsEquipFaultEvent(arr3);

		teamsSender(e3);
	}
	
	public void teamsClearFault() throws Exception{
		String[] arr = new String[16];
		
		arr[0] = "1";
		arr[1] = "BATCHCLEAR";
		arr[2] = "B";
		arr[3] = "20240617155507";
		arr[4] = "0";
		arr[5] = "034001:1225645905:1718598588892";
		arr[6] = "003003";
		arr[7] = "20240617155507";
		arr[8] = "5";
		arr[9] = "222107";
		arr[10] = "218";
		arr[11] = "854254";
		arr[12] = "034001";
		arr[13] = "N";
		arr[14] = "0";
		arr[15] = "20240617132948";
		
		TeamsEvent e = new TeamsFaultClearEvent(arr);

		teamsSender(e);
	}
	
	public void teamsClearLineFault() throws Exception{
		String[] arr = new String[16];
		
		arr[0] = "1";
		arr[1] = "SYSTEM";
		arr[2] = "A";
		arr[3] = "20240617161127";
		arr[4] = "23779";
		arr[5] = "034001:1225636993:1718584424449";
		arr[6] = "003003";
		arr[7] = "20240617161003";
		arr[8] = "5";
		arr[9] = "222132";
		arr[10] = "-1";
		arr[11] = "908468";
		arr[12] = "";
		arr[13] = "N";
		arr[14] = "0";
		arr[15] = "20240617093344";
		
		TeamsEvent e = new TeamsFaultClearEvent(arr);

		teamsSender(e);
	}
	
	public void fomsNetTest() throws Exception{
		String[] arr = new String[69];
		
		SimpleDateFormat dtmFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date current_date = new Date(System.currentTimeMillis());
		String curDtm = dtmFormat.format(current_date);
		
		arr[0] = "501";
		arr[1] = "37636752";
		arr[2] = "4";
		arr[3] = "5";
		arr[4] = "30";
		arr[5] = "35";
		arr[6] = "20250312101239";
		arr[7] = "600";
		arr[8] = "경북(대구)";
		arr[9] = "E20100";
		arr[10] = "대구/달서";
		arr[11] = "M75823";
		arr[12] = "[DP]월배아이파크2차_광랜E";
		arr[13] = "FS330832";
		arr[14] = "월배아이파크2차204동#2";
		arr[15] = "100.89.105.208";
		arr[16] = "";
		arr[17] = "1";
		arr[18] = "4069";
		arr[19] = "H5224G";
		arr[20] = "ONU 3/1/12";
		arr[21] = "3";
		arr[22] = "1";
		arr[23] = "12";
		arr[24] = "2";
		arr[25] = "461728992";
		arr[26] = "<29>OnuStater: %% ONU 3/1/12 state changed from online to poweroff %%";
		arr[27] = "11425050";
		arr[28] = "2";
		arr[29] = "";
		arr[30] = "";
		arr[31] = "";
		arr[32] = "";
		arr[33] = "NR029102";
		arr[34] = "[10G][달서]달서GPON(SG)B#16[pon3/1]";
		arr[35] = "0";
		arr[36] = "0";
		arr[37] = "5";
		arr[38] = "5";
		arr[39] = "0";
		arr[40] = "0";
		arr[41] = "1";
		arr[42] = "5";
		arr[43] = "5";
		arr[44] = "5";
		arr[45] = "0";
		arr[46] = "0";
		arr[47] = "0";
		arr[48] = "0";
		arr[49] = "0";
		arr[50] = "0";
		arr[51] = "0";
		arr[52] = "0";
		arr[53] = "0";
		arr[54] = "0";
		arr[55] = "0";
		arr[56] = "일반가입자망";
		arr[57] = "";
		arr[58] = "";
		arr[59] = "";
		arr[60] = "";
		arr[61] = "";
		arr[62] = "";
		arr[63] = "";
		arr[64] = "";
		arr[65] = "";
		arr[66] = "E201003";
		arr[67] = "대구시 달서구";
		arr[68] = "CATV";
		
		FomsFaultEvent e = new FomsNetFaultEvent(FomsEvent.DETAIL_CMD2_NET_GEN, arr);

		fomsSender(e);
	}
	
	public void fomsAmiTest() throws Exception{
		String[] arr = new String[69];
		
		SimpleDateFormat dtmFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date current_date = new Date(System.currentTimeMillis());
		String curDtm = dtmFormat.format(current_date);
		
		arr[0] = "501";
		arr[1] = "37638702";
		arr[2] = "2";
		arr[3] = "0";
		arr[4] = "05";
		arr[5] = "05";
		arr[6] = "20250312102339";
		arr[7] = "500";
		arr[8] = "부산(경남)";
		arr[9] = "N03029";
		arr[10] = "경남/창원";
		arr[11] = "N32030";
		arr[12] = "SKT남해중심국_1F(기지국)";
		arr[13] = "DGNT16470031";
		arr[14] = "시내선45L3";
		arr[15] = "123.111.121.195";
		arr[16] = "";
		arr[17] = "E";
		arr[18] = "1001";
		arr[19] = "DGNT-2200";
		arr[20] = "1";
		arr[21] = "1";
		arr[22] = "5";
		arr[23] = "1";
		arr[24] = "";
		arr[25] = "";
		arr[26] = "DGNT16470031(4175S6021) LAN Port Down 장애[WAN IP:123.111.121.195]";
		arr[27] = "";
		arr[28] = "";
		arr[29] = "";
		arr[30] = "";
		arr[31] = "";
		arr[32] = "남변_1";
		arr[33] = "NR029341";
		arr[34] = "SKT남해중심국1층_M1_H7K_RC";
		arr[35] = "";
		arr[36] = "";
		arr[37] = "";
		arr[38] = "";
		arr[39] = "";
		arr[40] = "";
		arr[41] = "";
		arr[42] = "";
		arr[43] = "";
		arr[44] = "";
		arr[45] = "";
		arr[46] = "";
		arr[47] = "";
		arr[48] = "N030294";
		arr[49] = "경남 남해군";
		arr[50] = "CATV";
		
		FomsFaultEvent e = new FomsFaultEvent(FomsEvent.DETAIL_CMD2_AMI_GEN, arr);

		fomsSender(e);
	}
	
	public void fomsEnvTest() throws Exception{
		String[] arr = new String[48];
		
		SimpleDateFormat dtmFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date current_date = new Date(System.currentTimeMillis());
		String curDtm = dtmFormat.format(current_date);
		
		arr[0] = "501";
		arr[1] = "37616799";
		arr[2] = "4";
		arr[3] = "0";
		arr[4] = "04";
		arr[5] = "05";
		arr[6] = "20250312072505";
		arr[7] = "600";
		arr[8] = "경북(대구)";
		arr[9] = "E10100";
		arr[10] = "대구/중";
		arr[11] = "E10404";
		arr[12] = "[DP]복현청구";
		arr[13] = "0EE10404";
		arr[14] = "[RACS]복현청구MDF";
		arr[15] = "100.89.117.110";
		arr[16] = "";
		arr[17] = "Z";
		arr[18] = "2001";
		arr[19] = "감시단말시제품";
		arr[20] = "";
		arr[21] = "";
		arr[22] = "";
		arr[23] = "";
		arr[24] = "";
		arr[25] = "";
		arr[26] = "Aircon OFF, 현재습도(41%), 임계치(10% ~ 40%) 벗어남";
		arr[27] = "";
		arr[28] = "";
		arr[29] = "";
		arr[30] = "";
		arr[31] = "";
		arr[32] = "";
		arr[33] = "FS147571";
		arr[34] = "복현청구MDF#1";
		arr[35] = "일반가입자망";
		arr[36] = "";
		arr[37] = "";
		arr[38] = "";
		arr[39] = "";
		arr[40] = "";
		arr[41] = "";
		arr[42] = "";
		arr[43] = "";
		arr[44] = "";
		arr[45] = "E101009";
		arr[46] = "대구시 북구";
		arr[47] = "CATV";
		
		FomsFaultEvent e = new FomsFaultEvent(FomsEvent.DETAIL_CMD2_ENV_GEN, arr);

		fomsSender(e);
	}
	
	public void fomsSyslogTest() throws Exception{
		String[] arr = new String[68];
		
		SimpleDateFormat dtmFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date current_date = new Date(System.currentTimeMillis());
		String curDtm = dtmFormat.format(current_date);
		
		arr[0] = "501";
		arr[1] = "89637821";
		arr[2] = "4";
		arr[3] = "1";
		arr[4] = "30";
		arr[5] = "36";
		arr[6] = "20240617082946";
		arr[7] = "200";
		arr[8] = "수도권남";
		arr[9] = "N00935";
		arr[10] = "경기/팔달";
		arr[11] = "W09491";
		arr[12] = "[T중심]SKT_서동탄중심국";
		arr[13] = "NR037381";
		arr[14] = "[XLB][서동탄중]KGWDT_GPON_11";
		arr[15] = "100.83.67.49";
		arr[16] = "";
		arr[17] = "5";
		arr[18] = "4518";
		arr[19] = "OLT HL7180XG";
		arr[20] = "OLT 3/1";
		arr[21] = "1";
		arr[22] = "3";
		arr[23] = "1";
		arr[24] = "";
		arr[25] = "427786478";
		arr[26] = "<25>GPON: Got LOSS_OF_SIGNAL from OLT 3/1";
		arr[27] = "";
		arr[28] = "";
		arr[29] = "";
		arr[30] = "";
		arr[31] = "";
		arr[32] = "";
		arr[33] = "";
		arr[34] = "[4XAB][서동탄중]KGWDT_L3_03,[4XAB][서동탄중]KGWDT_L3_04[Vlanif207]";
		arr[35] = "0";
		arr[36] = "0";
		arr[37] = "1";
		arr[38] = "0";
		arr[39] = "0";
		arr[40] = "0";
		arr[41] = "1";
		arr[42] = "1";
		arr[43] = "1";
		arr[44] = "0";
		arr[45] = "0";
		arr[46] = "0";
		arr[47] = "0";
		arr[48] = "0";
		arr[49] = "0";
		arr[50] = "0";
		arr[51] = "0";
		arr[52] = "0";
		arr[53] = "0";
		arr[54] = "0";
		arr[55] = "0";
		arr[56] = "주요가입자망";
		arr[57] = "";
		arr[58] = "";
		arr[59] = "";
		arr[60] = "";
		arr[61] = "";
		arr[62] = "";
		arr[63] = "";
		arr[64] = "";
		arr[65] = "";
		arr[66] = "N009356";
		arr[67] = "경기 오산시";
		
		FomsFaultEvent e = new FomsFaultEvent(FomsEvent.DETAIL_CMD2_ENV_GEN, arr);

		fomsSender(e);
		
	}
	
	public void fomsSyslogTest2() throws Exception{
		String[] arr = new String[68];
		
		SimpleDateFormat dtmFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date current_date = new Date(System.currentTimeMillis());
		String curDtm = dtmFormat.format(current_date);
		
		arr[0] = "501";
		arr[1] = "89640742";
		arr[2] = "3";
		arr[3] = "417";
		arr[4] = "30";
		arr[5] = "32";
		arr[6] = "20240617090200";
		arr[7] = "500";
		arr[8] = "부산(경남)";
		arr[9] = "N03029";
		arr[10] = "경남/창원";
		arr[11] = "L65614";
		arr[12] = "SKT창원남양통합국_2F";
		arr[13] = "NR037558";
		arr[14] = "SKT창원남양통합국_XGS-OLT_2";
		arr[15] = "100.64.4.103";
		arr[16] = "";
		arr[17] = "5";
		arr[18] = "4518";
		arr[19] = "OLT HL7180XG";
		arr[20] = "AP 3";
		arr[21] = "";
		arr[22] = "";
		arr[23] = "";
		arr[24] = "";
		arr[25] = "427789009";
		arr[26] = "<28>Monitord: AP 3 AP-CPU Overload Alarm Raised(Total 100%, (pipcc)(100%), (init)(0%), (kthreadd)(0%))";
		arr[27] = "";
		arr[28] = "";
		arr[29] = "";
		arr[30] = "";
		arr[31] = "";
		arr[32] = "";
		arr[33] = "NR037555";
		arr[34] = "SKT창원남양통합국_L3_1,SKT창원남양통합국_L3_2[Vlanif202]";
		arr[35] = "0";
		arr[36] = "0";
		arr[37] = "";
		arr[38] = "";
		arr[39] = "";
		arr[40] = "0";
		arr[41] = "1";
		arr[42] = "";
		arr[43] = "";
		arr[44] = "";
		arr[45] = "";
		arr[46] = "0";
		arr[47] = "0";
		arr[48] = "0";
		arr[49] = "";
		arr[50] = "";
		arr[51] = "";
		arr[52] = "";
		arr[53] = "0";
		arr[54] = "0";
		arr[55] = "0";
		arr[56] = "주요가입자망";
		arr[57] = "";
		arr[58] = "";
		arr[59] = "";
		arr[60] = "";
		arr[61] = "";
		arr[62] = "";
		arr[63] = "";
		arr[64] = "";
		arr[65] = "";
		arr[66] = "N0302916";
		arr[67] = "경남 창원시 진해구";
		
		FomsFaultEvent e = new FomsFaultEvent(FomsEvent.DETAIL_CMD2_ENV_GEN, arr);

		fomsSender(e);
		
	}
	
	public void fomsBizLevelTest() throws Exception{
		String[] arr = new String[68];
		
		SimpleDateFormat dtmFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date current_date = new Date(System.currentTimeMillis());
		String curDtm = dtmFormat.format(current_date);
		
		arr[0] = "501";
		arr[1] = "3529768";
		arr[2] = "4";
		arr[3] = "393";
		arr[4] = "30";
		arr[5] = "41";
		arr[6] = "20240822142129";
		arr[7] = "800";
		arr[8] = "호남(광주)";
		arr[9] = "N02808";
		arr[10] = "제주/신제주";
		arr[11] = "N34675";
		arr[12] = "[T기지]서귀 서귀_H";
		arr[13] = "NR028273";
		arr[14] = "[10G] 서귀_FTTH_V8240_06_RP_1";
		arr[15] = "100.95.0.44";
		arr[16] = "";
		arr[17] = "5";
		arr[18] = "4066";
		arr[19] = "OLT V8240";
		arr[20] = "2/3,8";
		arr[21] = "2";
		arr[22] = "3";
		arr[23] = "8";
		arr[24] = "";
		arr[25] = "437647881";
		arr[26] = "<14>GPON[274]: ONU(2/3,8) DEACTIVATION (Reason: LOFi)";
		arr[27] = "";
		arr[28] = "";
		arr[29] = "";
		arr[30] = "";
		arr[31] = "[SFU][NIU][20G]";
		arr[32] = "";
		arr[33] = "";
		arr[34] = "[10G] 서귀동_L3_S6320_01,[10G] 서귀동_L3_S6320_02[Vlanif206]";
		arr[35] = "0";
		arr[36] = "0";
		arr[37] = "";
		arr[38] = "";
		arr[39] = "";
		arr[40] = "0";
		arr[41] = "1";
		arr[42] = "";
		arr[43] = "";
		arr[44] = "";
		arr[45] = "";
		arr[46] = "0";
		arr[47] = "0";
		arr[48] = "0";
		arr[49] = "";
		arr[50] = "";
		arr[51] = "";
		arr[52] = "";
		arr[53] = "0";
		arr[54] = "0";
		arr[55] = "0";
		arr[56] = "일반가입자망";
		arr[57] = "";
		arr[58] = "S";
		arr[59] = "9570004819";
		arr[60] = "에*케이텔레콤(주)";
		arr[61] = "";
		arr[62] = "";
		arr[63] = "";
		arr[64] = "";
		arr[65] = "";
		arr[66] = "N028081";
		arr[67] = "제주 서귀포시^C";
		
		FomsFaultEvent e = new FomsNetFaultEvent(FomsEvent.DETAIL_CMD2_NET_GEN, arr);

		fomsSender(e);
		
	}
	
	public void fomsClear() throws Exception{
		String[] arr = new String[68];
		
		SimpleDateFormat dtmFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date current_date = new Date(System.currentTimeMillis());
		String curDtm = dtmFormat.format(current_date);
		
		arr[0] = "501";
		arr[1] = "117524749";
		arr[2] = "5";
		arr[3] = "1";
		arr[4] = "13";
		arr[5] = "01";
		arr[6] = "20240617142003";
		arr[7] = "100";
		arr[8] = "강북(성북)";
		arr[9] = "A40100";
		arr[10] = "성북정보센터";
		arr[11] = "L47389";
		arr[12] = "[Mini]{SG}묵동_171-34_FTTH";
		arr[13] = "FS551024";
		arr[14] = "[Mini08]묵동(171-34)";
		arr[15] = "100.79.253.84";
		arr[16] = "";
		arr[17] = "1";
		arr[18] = "4401";
		arr[19] = "H5208G";
		arr[20] = "";
		arr[21] = "";
		arr[22] = "";
		arr[23] = "00000";
		arr[24] = "";
		arr[25] = "";
		arr[26] = "PING 경보(전원경보)";
		arr[27] = "";
		arr[28] = "";
		arr[29] = "";
		arr[30] = "";
		arr[31] = "";
		arr[32] = "";
		arr[33] = "NR025368";
		arr[34] = "[XLB]SLDDM_FTTH_06[12/2]";
		arr[35] = "0";
		arr[36] = "0";
		arr[37] = "0";
		arr[38] = "0";
		arr[39] = "0";
		arr[40] = "0";
		arr[41] = "1";
		arr[42] = "0";
		arr[43] = "0";
		arr[44] = "0";
		arr[45] = "0";
		arr[46] = "0";
		arr[47] = "0";
		arr[48] = "0";
		arr[49] = "0";
		arr[50] = "0";
		arr[51] = "0";
		arr[52] = "0";
		arr[53] = "0";
		arr[54] = "0";
		arr[55] = "0";
		arr[56] = "";
		arr[57] = "";
		arr[58] = "";
		arr[59] = "";
		arr[60] = "";
		arr[61] = "";
		arr[62] = "";
		arr[63] = "";
		arr[64] = "";
		arr[65] = "";
		arr[66] = "A4010061";
		arr[67] = "중랑구 묵동";
		
		FomsFaultEvent e = new FomsFaultEvent(FomsEvent.DETAIL_CMD2_ENV_CLR, arr);

		fomsSender(e);
	}
	
	public JSONObject convertJsonObj(String jsonStr) throws ParseException{
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(jsonStr);
		JSONObject jsonObj = (JSONObject)obj;
		logger.debug("JSON:" + jsonObj.toString());
		return jsonObj;
	}
	
	public void loadConfig() {
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		//arrIpAddress = configManager.getConfig(Constants.RMS, Constants.IP_ADDRESS).split(",");		
		//portNo = Integer.parseInt(configManager.getConfig(Constants.RMS, Constants.PORT_NO));
		pushIpAddress = configManager.getConfig(Constants.WEB_PUSH, Constants.IP_ADDRESS);
		pushPortNo = Integer.parseInt(configManager.getConfig(Constants.WEB_PUSH, Constants.PORT_NO));
		
		//logger.info("ipAddress : " + arrIpAddress[0]);
		//logger.info("portNo : " + portNo);
		logger.info("pushIpAddress : " + pushIpAddress);
		logger.info("pushPortNo : " + pushPortNo);    	
    }
	
	public static void main(String[] args) throws Exception {
		EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("RealTimeCollectTest", envManager.getOptions());
    		System.exit(0);
    	}
        new RealTimeCollectTest (args);
	}
	
	@SuppressWarnings("unchecked")
	private void teamsSender(TeamsEvent event) throws Exception {
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		version = configManager.getConfig(Constants.TEAMS, Constants.VERSION);
		//logger.debug(String.format("strp01-> getNeId[%s] getMngGroupCd[%s], getTrmsNetMgmtOwnerCd[%s], version[%s]",event.getNeId(),event.getMngGroupCd(), event.getTrmsNetMgmtOwnerCd(), version)); //ics
		if ("Y18".equals(version)) {
			if (!TeamsEvent.SKB.equals(event.getTrmsNetMgmtOwnerCd())) {
				if (isSktEquipForSkb(event.getNeId()) == false) {
					logger.debug(String.format("[%s] neId(%s) is not affected to SKB", event.getMngGroupCd(), event.getNeId()));
					return;
				}
				logger.info(String.format("SKT_SKB [%s] neId(%s) is affected to SKB", event.getMngGroupCd(), event.getNeId()));
			}
			if("-1".equals(event.getNeId())){ /*20200715 ics add*/
				logger.debug(String.format("[%s] neId(%s) is not affected to SKB", event.getMngGroupCd(), event.getNeId()));
				return;
			}
			
		} else {			
			if (!TeamsEvent.SKB.equals(event.getTrmsNetMgmtOwnerCd())) {
				return;
			}
			if (TeamsEvent.RING_FAULT.equals(event.getEventType())) {
				return;
			}
		}
		//logger.debug(String.format("strp02-> getNeId[%s] getMngGroupCd[%s], getTrmsNetMgmtOwnerCd[%s], version[%s]",event.getNeId(),event.getMngGroupCd(), event.getTrmsNetMgmtOwnerCd(), version)); //ics

		if (TeamsEvent.EQUIP_FAULT.equals(event.getEventType())) {
			TeamsEquipFaultEvent equipFaultEvent = (TeamsEquipFaultEvent) event;
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("NMS_CD", NMS_CD2);
			jsonObject.put("NMS_NM", NMS_NM2);
			jsonObject.put("NET_CL_CD", NET_CL_CD2);
			jsonObject.put("NET_CL_NM", NET_CL_NM2);
			jsonObject.put("LINE_DABL_TYP_CD", "N");
			jsonObject.put("kind", GENERATE_EVENT);
			jsonObject.put("EQUIP_ID", 	equipFaultEvent.getNeId());
			jsonObject.put("EQUIP_TID_VAL", equipFaultEvent.getTid());
			jsonObject.put("EQUIP_IP_ADDR", equipFaultEvent.getIpAddr());
			jsonObject.put("DABL_GR_CD", 	equipFaultEvent.getDablGrCd());
			jsonObject.put("PORT_DESC", equipFaultEvent.getPortDescr());
			jsonObject.put("DABL_DESC", equipFaultEvent.getReason());
			jsonObject.put("TPO_CD", equipFaultEvent.getOrgId());
			jsonObject.put("TPO_NM", equipFaultEvent.getOrgName());
			jsonObject.put("OCCR_DTM", equipFaultEvent.getOccurTime());
			jsonObject.put("OCCR_RCV_DTM", MiscUtils.getDateTime ());
			jsonObject.put("OPER_DABL_YN", equipFaultEvent.getWorkYn());
			jsonObject.put("NMS_DABL_NUM_CTT", equipFaultEvent.getAlarmNo());
			jsonObject.put("DABL_ST_CD", GENERATED_FAULT_CD);
			jsonObject.put("DABL_ST_NM", GENERATED_FAULT_NM); 
			jsonObject.put("EQUIP_NM", 	equipFaultEvent.getNeName());
			jsonObject.put("EQUIP_MDL_CD", equipFaultEvent.getModelCd());
			jsonObject.put("EQUIP_MDL_NM", equipFaultEvent.getModelName());
			if (omn30203Map == null) {
				loadTeamsFaultCodeMap();
			}
			OMN30203 omn30203 = omn30203Map.get(equipFaultEvent.getModelName()+"장애"+equipFaultEvent.getReason());
			if(omn30203 == null)
			{
				jsonObject.put("DABL_LCL_CD", EQUIP_FAULT);		// 대분류 코드
				jsonObject.put("DABL_LCL_NM", EQUIP_DABL_LCL_NM);	// 대분류 명
				jsonObject.put("DABL_MCL_CD", EQUIP_DABL_MCL_CD);	// 중분류 코드
				jsonObject.put("DABL_MCL_NM", EQUIP_DABL_MCL_NM);	// 중분류 명
				jsonObject.put("DABL_CD", EQUIP_DABL_CD);			// 소분류 코드
				jsonObject.put("DABL_NM", EQUIP_DABL_NM);			// 소분류 명

			}else{
				jsonObject.put("DABL_LCL_CD", EQUIP_FAULT);		// 대분류 코드
				jsonObject.put("DABL_LCL_NM", omn30203.getDablLclNm());	// 대분류 명
				jsonObject.put("DABL_MCL_CD", omn30203.getDablMclCd());	// 중분류 코드
				jsonObject.put("DABL_MCL_NM", omn30203.getDablMclNm());	// 중분류 명
				jsonObject.put("DABL_CD", omn30203.getDablCd());			// 소분류 코드
				jsonObject.put("DABL_NM", omn30203.getDablCdNm());			// 소분류 명
			}
			
			jsonObject.put("DABL_OCCR_LOC_DESC", equipFaultEvent.getLocation());	// 발생 위치
			jsonObject.put("DABL_PORT_DESC", equipFaultEvent.getPortDescr());	// 포트정보
			jsonObject.put("TRMS_NET_MGMT_OWNR_CD", equipFaultEvent.getTrmsNetMgmtOwnerCd());
			jsonObject.put("USE_USG_DESC", equipFaultEvent.getEquipUsage());
			jsonObject.put("TROOM_NM", equipFaultEvent.getTrRoomName());
			jsonSender.put(jsonObject);
			logger.debug("JSON:" + jsonObject.toString());
		} else if (TeamsEvent.CIRCUIT_FAULT.equals(event.getEventType())) {
			TeamsCircuitFaultEvent circuitFaultEvent = (TeamsCircuitFaultEvent) event;
			HashMap<String, Object> hmap = adamsSession.selectOne("RealtimeTeams.selectCustInfo", circuitFaultEvent.getLineNo());
			if(hmap == null || "08".equals((String) hmap.get("LINE_ST_CD"))) return;
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("NMS_CD", NMS_CD2);
			jsonObject.put("NMS_NM", NMS_NM2);
			jsonObject.put("NET_CL_CD", NET_CL_CD2);
			jsonObject.put("NET_CL_NM", NET_CL_NM2);
			jsonObject.put("LINE_DABL_TYP_CD", "N");
			jsonObject.put("kind", GENERATE_EVENT);
			jsonObject.put("NMS_ALARM_NO", circuitFaultEvent.getNmsAlarmNo());
			jsonObject.put("ALARM_NO", circuitFaultEvent.getAlarmNo());
			jsonObject.put("EQUIP_ID", 	circuitFaultEvent.getNeId());
			jsonObject.put("EQUIP_TID_VAL", circuitFaultEvent.getTid());
			jsonObject.put("EQUIP_IP_ADDR", circuitFaultEvent.getIpAddr());
			jsonObject.put("DABL_GR_CD", circuitFaultEvent.getDablGrCd());
			jsonObject.put("PORT_DESC", circuitFaultEvent.getPortDescr());
			jsonObject.put("DABL_DESC", circuitFaultEvent.getReason());
			jsonObject.put("TPO_CD", circuitFaultEvent.getOrgId());
			jsonObject.put("TPO_NM", circuitFaultEvent.getOrgName());
			jsonObject.put("OCCR_DTM", circuitFaultEvent.getOccurTime());
			jsonObject.put("OCCR_RCV_DTM", MiscUtils.getDateTime ());
			jsonObject.put("OPER_DABL_YN", circuitFaultEvent.getWorkYn());
			jsonObject.put("NMS_DABL_NUM_CTT", circuitFaultEvent.getAlarmNo());
			jsonObject.put("DABL_ST_CD", GENERATED_FAULT_CD);
			jsonObject.put("DABL_ST_NM", GENERATED_FAULT_NM);
			jsonObject.put("EQUIP_NM", 	circuitFaultEvent.getNeName());
			jsonObject.put("EQUIP_MDL_CD", circuitFaultEvent.getModelId());
			jsonObject.put("EQUIP_MDL_NM", circuitFaultEvent.getModelName());
			jsonObject.put("DABL_OCCR_LOC_DESC", circuitFaultEvent.getLocation()); // 발생 위치
			jsonObject.put("DABL_PORT_DESC", circuitFaultEvent.getPortDescr());	// 포트정보
			jsonObject.put("DABL_LCL_CD", CIRCUIT_FAULT); // 대분류 코드
			jsonObject.put("DABL_LCL_NM", CIRCUIT_DABL_LCL_NM); // 대분류 명
			jsonObject.put("DABL_MCL_CD", CIRCUIT_DABL_MCL_CD); // 중분류 코드
			jsonObject.put("DABL_MCL_NM", CIRCUIT_DABL_MCL_NM); // 중분류 명
			jsonObject.put("DABL_CD", CIRCUIT_DABL_CD); // 소분류 코드
			jsonObject.put("DABL_NM", CIRCUIT_DABL_NM); // 소분류 명
			jsonObject.put("LINE_NUM", (String) hmap.get("LINE_NUM")); // 회선 번호
			jsonObject.put("CUST_NUM", circuitFaultEvent.getCustNo()); // 고객 번호
			jsonObject.put("CUST_NM", circuitFaultEvent.getCustName());
			jsonObject.put("CHRGR_ID", (String) hmap.get("SALE_CHRGR_ID")); 
			jsonObject.put("CHRGR_NM", (String) hmap.get("SALE_CHRGR_NM"));
			jsonObject.put("LINE_NM", (String) hmap.get("LINE_NM"));
			jsonObject.put("LINE_CL_CD", (String) hmap.get("LINE_CL_CD"));
			jsonObject.put("LINE_CL_NM", (String) hmap.get("LINE_CL_NM"));
			jsonObject.put("SVC_TECH_MTHD_CD", (String) hmap.get("SVC_TECH_MTHD_CD"));
			jsonObject.put("SVC_TECH_MTHD_NM", (String) hmap.get("SVC_TECH_MTHD_NM"));
			jsonObject.put("SUP_TPO_CD", (String) hmap.get("SUP_TPO_CD"));
			jsonObject.put("SUP_TPO_NM", (String) hmap.get("SUP_TPO_NM"));
			jsonObject.put("SUB_TPO_CD", (String) hmap.get("SUB_TPO_CD"));
			jsonObject.put("SUB_TPO_NM", (String) hmap.get("SUB_TPO_NM"));
			jsonObject.put("SPEED_CD", (String) hmap.get("SPEED_CD"));
			jsonObject.put("SPEED_NM", (String) hmap.get("SPEED_NM"));
			jsonObject.put("SVC_MGMT_NUM", (String) hmap.get("SVC_MGMT_NUM"));
			jsonObject.put("CUST_CHRTIC_CD", (String) hmap.get("CUST_CHRTIC_CD"));
			jsonObject.put("CUST_CHRTIC_NM", (String) hmap.get("CUST_CHRTIC_NM"));				
			jsonObject.put("MEMO_CTT1", (String) hmap.get("MEMO_CTT1"));				
			jsonObject.put("MEMO_CTT2", (String) hmap.get("MEMO_CTT2"));				
			jsonObject.put("MEMO_CTT3", (String) hmap.get("MEMO_CTT3"));				

			// sample
			// K0004513|N75088|N00935|A10202|N00935|A10202|N00935|||N
			// C0008708|A10202|A10202|A10202|A10202|A10202|A10202|||Y
			if(StringUtils.isEmpty(circuitFaultEvent.getRasId())) {
				jsonObject.put("LINE_DABL_TYP_CD", "N");
			}else {
				String[] items = circuitFaultEvent.getRasId().split("\\|");
				if(items.length >= 10) {
					jsonObject.put ("LINE_DABL_TYP_CD", items[9]);
				}else {
					jsonObject.put ("LINE_DABL_TYP_CD", "N");
				}
			}
			jsonObject.put("SUP_EQUIP_ID", circuitFaultEvent.getuOrgId());
			jsonObject.put("SUP_EQUIP_NM", circuitFaultEvent.getuOrgName());
			jsonObject.put("SUB_EQUIP_ID", circuitFaultEvent.getlOrgId());
			jsonObject.put("SUB_EQUIP_NM", circuitFaultEvent.getlOrgName());
			jsonObject.put("RING_NM", circuitFaultEvent.getRingName());
			jsonObject.put("DMG_LINE_CNT", "0");
			jsonObject.put("TRMS_NET_MGMT_OWNR_CD", circuitFaultEvent.getTrmsNetMgmtOwnerCd());
			jsonObject.put("USE_USG_DESC", circuitFaultEvent.getEquipUsage());
			jsonObject.put("TROOM_NM", circuitFaultEvent.getTrRoomName());
			jsonObject.put("NET_NUM", circuitFaultEvent.getRingId());
			jsonObject.put("TRUNK_NUM", circuitFaultEvent.getTrunkId());
			jsonObject.put("TRUNK_NM", circuitFaultEvent.getTrunkName());
			jsonSender.put(jsonObject);
			logger.debug("JSON:" + jsonObject.toString());
		} else if (TeamsEvent.RING_FAULT.equals(event.getEventType())) {
			TeamsRingFaultEvent ringFaultEvent = (TeamsRingFaultEvent) event;
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("NMS_CD", NMS_CD2);
			jsonObject.put("NMS_NM", NMS_NM2);
			jsonObject.put("NET_CL_CD", NET_CL_CD2);
			jsonObject.put("NET_CL_NM", NET_CL_NM2);
			jsonObject.put("LINE_DABL_TYP_CD", "N");
			jsonObject.put("NMS_ALARM_NO", ringFaultEvent.getNmsAlarmNo());
			jsonObject.put("ALARM_NO", ringFaultEvent.getAlarmNo());
			jsonObject.put("kind", GENERATE_EVENT);
			jsonObject.put("EQUIP_ID", 	ringFaultEvent.getNeId());
			jsonObject.put("EQUIP_TID_VAL", ringFaultEvent.getTid());
			jsonObject.put("EQUIP_IP_ADDR", ringFaultEvent.getIpAddr());
			jsonObject.put("DABL_GR_CD", ringFaultEvent.getDablGrCd());
			jsonObject.put("PORT_DESC", ringFaultEvent.getPortDescr());
			jsonObject.put("DABL_DESC", ringFaultEvent.getReason());
			jsonObject.put("TPO_CD", ringFaultEvent.getOrgId());
			jsonObject.put("TPO_NM", ringFaultEvent.getOrgName());
			jsonObject.put("OCCR_DTM", ringFaultEvent.getOccurTime());
			jsonObject.put("OCCR_RCV_DTM", MiscUtils.getDateTime());
			jsonObject.put("OPER_DABL_YN", ringFaultEvent.getWorkYn());
			jsonObject.put("NMS_DABL_NUM_CTT", ringFaultEvent.getAlarmNo());
			jsonObject.put("DABL_ST_CD", GENERATED_FAULT_CD);
			jsonObject.put("DABL_ST_NM", GENERATED_FAULT_NM);
			jsonObject.put("EQUIP_NM", 	ringFaultEvent.getNeName());
			jsonObject.put("EQUIP_MDL_CD", ringFaultEvent.getModelId());
			jsonObject.put("EQUIP_MDL_NM", ringFaultEvent.getModelName());
			jsonObject.put("DABL_LCL_CD", CIRCUIT_FAULT);		// 대분류 코드
			jsonObject.put("DABL_LCL_NM", CIRCUIT_DABL_LCL_NM);// 대분류 명
			jsonObject.put("DABL_MCL_CD", RING_DABL_MCL_CD);	// 중분류 코드
			jsonObject.put("DABL_MCL_NM", RING_DABL_MCL_NM);	// 중분류 명
			jsonObject.put("DABL_CD", RING_DABL_CD);			// 소분류 코드
			jsonObject.put("DABL_NM", RING_DABL_NM);			// 소분류 명			
			jsonObject.put("NET_DABL_SRC_CTT", ringFaultEvent.getNetworkAlarmReason());
			jsonObject.put("DABL_OCCR_LOC_DESC", ringFaultEvent.getLocation());
			jsonObject.put("DABL_PORT_DESC", ringFaultEvent.getPortDescr());
			jsonObject.put("NET_NUM", ringFaultEvent.getRingId());
			jsonObject.put("RING_NM", ringFaultEvent.getRingName());
			jsonObject.put("TRUNK_NUM", ringFaultEvent.getTrunkId());
			jsonObject.put("TRUNK_NM", ringFaultEvent.getTrunkName());
			jsonObject.put("TRMS_NET_MGMT_OWNR_CD", ringFaultEvent.getTrmsNetMgmtOwnerCd());
			jsonObject.put("USE_USG_DESC", ringFaultEvent.getEquipUsage());
			jsonObject.put("TROOM_NM", ringFaultEvent.getTrRoomName());
			
			// 링번호 기준으로 회선번호 조회
			/*
			HashMap<String, Object> hmap = adamsSession.selectOne("RealtimeTeams.selectLineInfoByNetNum", ringFaultEvent.getRingId());
			if (hmap != null) {
				jsonObject.put("LINE_NUM", (String) hmap.get("LINE_NUM"));		// 회선 번호
				jsonObject.put("LINE_NM", (String) hmap.get("LINE_NM"));		// 회선명
			}
			*/
			jsonSender.put(jsonObject);
			logger.debug("JSON:" + jsonObject.toString());
		} else if (TeamsEvent.FAULT_CLEAR.equals(event.getEventType())) {
			TeamsFaultClearEvent clearEvent = (TeamsFaultClearEvent) event;
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("NMS_CD", NMS_CD2);
			jsonObject.put("NMS_NM", NMS_NM2);
			jsonObject.put("NET_CL_CD", NET_CL_CD2);
			jsonObject.put("NET_CL_NM", NET_CL_NM2);
			jsonObject.put("NMS_DABL_NUM_CTT", clearEvent.getAlarmNo());	// 장애 번호
			jsonObject.put("DABL_ST_CD", CLEARED_FAULT_CD); 					// 02 : 해제 코드
			jsonObject.put("DABL_ST_NM", CLEARED_FAULT_NM); 
			jsonObject.put("RLSE_DTM", clearEvent.getClearRTime());		// 장애 해제 시간
			jsonObject.put("RLSE_RCV_DTM", MiscUtils.getDateTime());
			jsonObject.put("kind", CLEAR_EVENT);
			jsonSender.put(jsonObject);
			logger.debug("JSON:" + jsonObject.toString());
		} else if (TeamsEvent.MANUAL_CLEAR.equals(event.getEventType())) {
			TeamsManualClearEvent manualClearEvent = (TeamsManualClearEvent) event;
			ArrayList<TeamsFaultClearEvent> clearEventList = manualClearEvent.getClearEventList();
			for (int i = 0; i < clearEventList.size(); i ++) {
				TeamsFaultClearEvent clearEvent = clearEventList.get(i);
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("NMS_CD", NMS_CD2);
				jsonObject.put("NMS_NM", NMS_NM2);
				jsonObject.put("NET_CL_CD", NET_CL_CD2);
				jsonObject.put("NET_CL_NM", NET_CL_NM2);
				jsonObject.put("NMS_DABL_NUM_CTT", clearEvent.getAlarmNo());	// 장애 번호
				jsonObject.put("DABL_ST_CD", CLEARED_FAULT_CD); 					// 02 : 해제 코드
				jsonObject.put("DABL_ST_NM", CLEARED_FAULT_NM); 
				jsonObject.put("RLSE_DTM", clearEvent.getClearRTime());		// 장애 해제 시간
				jsonObject.put("RLSE_RCV_DTM", MiscUtils.getDateTime());
				jsonObject.put("kind", CLEAR_EVENT);
				jsonSender.put(jsonObject);
				logger.debug("JSON:" + jsonObject.toString());
			}
		}
	}
	
	private void fomsSender(FomsFaultEvent event) throws Exception {
		
		if (omn30203Map == null) {
			readFomsFaultCode();
		}
		
		String swingAnnceYn = "N";

		JSONObject jsonObject = new JSONObject();
		if("CATV".equals(event.getNetType())){
			jsonObject.put("NMS_CD", NMS_CD_CATV);
			jsonObject.put("NMS_NM", NMS_NM_CATV);
		}else{
			jsonObject.put("NMS_CD", NMS_CD3);
			jsonObject.put("NMS_NM", NMS_NM3);
		}
		
		jsonObject.put("NMS_DABL_NUM_CTT", event.getEvtSerialNo());
		jsonObject.put("DABL_GR_CD", event.getDablGrCd());
		jsonObject.put("PING_CNT", event.getPingCnt());
		String key = event.getEvtId() + event.getEvtCode();
		OMN30203 omn30203 = omn30203Map.get(key);
		if (omn30203 != null) {
			jsonObject.put("DABL_LCL_CD", omn30203.getDablLclCd());
			jsonObject.put("DABL_LCL_NM", omn30203.getDablLclNm());
			jsonObject.put("DABL_MCL_CD", omn30203.getDablMclCd());
			jsonObject.put("DABL_MCL_NM", omn30203.getDablMclNm());
			jsonObject.put("DABL_CD", omn30203.getDablCd());
			jsonObject.put("DABL_NM", omn30203.getDablCdNm());
			// 가입자망 장애의 경우 : 포트번호(syslog장애, ftth cell장애일 시 : port_no, 이외 : 피해회선수(매스+비즈))
			// 그 외 AMI 장애, 환경감시 장애 : 포트번호
			if (FomsEvent.DETAIL_CMD2_NET_GEN == event.getDetailCmd2()) {
				// 01305: SYSLOG 장애, 01312: L2SYSLOG장애, 01314: OLT포트 장애 
				if ("01305".equals(omn30203.getDablMclCd()) || "01312".equals(omn30203.getDablMclCd()) || "01314".equals(omn30203.getDablMclCd())) {
					jsonObject.put("PORT_NUM", event.getPortNo());
				} else {
					jsonObject.put("DMG_SCRBR_CNT", event.getPortNo());
				}
			} else {
				jsonObject.put("PORT_NUM", event.getPortNo());
			}
		} else {
			jsonObject.put("DABL_LCL_CD", "*");
			jsonObject.put("DABL_LCL_NM", "*");			
			jsonObject.put("DABL_MCL_CD", "*");
			jsonObject.put("DABL_MCL_NM", "*");
			jsonObject.put("DABL_CD", "*");
			jsonObject.put("DABL_NM", "*");
		}
		jsonObject.put("OCCR_DTM", event.getEvtGenTime());
		jsonObject.put("OCCR_RCV_DTM", MiscUtils.getDateTime ());
		jsonObject.put("RSLE_DTM", event.getEvtGenTime());
		jsonObject.put("EQUIP_ID", event.getTid());
		jsonObject.put("EQUIP_TID_VAL", event.getTid());
		jsonObject.put("EQUIP_IP_ADDR", event.getDeviceIp());
		jsonObject.put("DABL_DESC", event.getEvtContent());
		jsonObject.put("DHCP_LNKG_EQUIP_CL_CD", event.getDevGroup());
		
		if (omn30203 != null) {
			if ("013016".equals(omn30203.getDablCd()) /* 전송망 장애 */
					|| "013017".equals(omn30203.getDablCd()) /* 전원 장애 */
					|| "013018".equals(omn30203.getDablCd()) /* 미확인 망장애 */
					|| "013009".equals(omn30203.getDablCd())) { /* Ping 장애 */
				swingAnnceYn = "Y";
				logger.debug("dablDesc : " + event.getEvtContent() + ", indexOf : " + event.getEvtContent().indexOf ("Off("));
				if (0 <= event.getEvtContent().indexOf ("Off(")) {
					String one = event.getEvtContent().substring(event.getEvtContent().indexOf ("Off(") + 4);
	                logger.debug("Off (" + one + ", length : " + one.length ());
					if (one != null) {
						String two = null;
						for (int index = 0; index < one.length (); ++ index) {
							if ('0' <= one.charAt(index) && one.charAt (index) <= '9') {
								if (two == null) {
									two = "" + one.charAt(index);
								} else {
									two += one.charAt(index);
								}
							} else {
								break;
							}
						}
						jsonObject.put("DMG_SCRBR_CNT", two);
					}
				}
			}
		}
		jsonObject.put("SWING_ANNCE_YN", swingAnnceYn);
		jsonObject.put("NOTICE_ID", event.getNoticeId());
		jsonObject.put("CCELL_NUM", event.getCellNo());
		jsonObject.put("OPER_DABL_YN", "N");
		if ("2".equals(event.getNoticeType())) {
			jsonObject.put("OPER_DABL_YN", "Y");
		}
		jsonObject.put("CUST_CHRTIC_CD", event.getBizCustLevel());  //240709.고객등급 추가.김준
		System.out.println("event.getBizCustLevel() >>> " + event.getBizCustLevel());
		if (FomsEvent.DETAIL_CMD2_NET_CLR == event.getDetailCmd2()) {	// 가입자망 실시간 장애 해제
			jsonObject.put("NET_CL_CD", NET_CL_CD3);
			jsonObject.put("NET_CL_NM", NET_CL_NM3);
			jsonObject.put("DABL_ST_CD", CLEARED_FAULT_CD);
			jsonObject.put("RLSE_DTM", event.getEvtGenTime());
			jsonObject.put("RLSE_RCV_DTM", MiscUtils.getDateTime ());
			jsonObject.put("kind", CLEAR_EVENT);
		} else if (FomsEvent.DETAIL_CMD2_NET_GEN == event.getDetailCmd2()) {	// 가입자망 실시간 장애
			FomsNetFaultEvent netFaultEvent = (FomsNetFaultEvent) event;
			jsonObject.put("NET_CL_CD", NET_CL_CD3);
			jsonObject.put("NET_CL_NM", NET_CL_NM3);
			jsonObject.put("DABL_ST_CD", GENERATED_FAULT_CD);
			jsonObject.put("kind", GENERATE_EVENT);
			jsonObject.put("SHSPD_VOC_CNT", netFaultEvent.getNetVocCnt());
			jsonObject.put("IPTV_VOC_CNT", netFaultEvent.getIptvVocCnt());
			jsonObject.put("SHSPD_INET_DMG_LINE_CNT", netFaultEvent.getNetAlarmCnt());
			jsonObject.put("GNRL_IPTV_DMG_LINE_CNT", netFaultEvent.getIptvAlarmCnt());
			jsonObject.put("GNLPH_DMG_LINE_CNT", netFaultEvent.getPhoneAlarmCnt());
			jsonObject.put("VOIP_VOC_CNT", netFaultEvent.getVoipVocCnt());
			jsonObject.put("PHON_VOC_CNT", "0");
			int totVocCnt = 0;
			try {
				totVocCnt += Integer.parseInt(netFaultEvent.getNetVocCnt());
			} catch (Exception e1) {
			}
			try {
				totVocCnt += Integer.parseInt(netFaultEvent.getIptvVocCnt());
			} catch (Exception e1) {
			}
			try {
				totVocCnt += Integer.parseInt(netFaultEvent.getVoipVocCnt());
			} catch (Exception e1) {
			}
			jsonObject.put("TOT_VOC_CNT", "" + totVocCnt);
			jsonObject.put("MASS_CO_CL_CD", netFaultEvent.getDevAlarmType());
			jsonObject.put("MASS_DMG_SCRBR_CNT", netFaultEvent.getmAlarmCnt());
			jsonObject.put("MASS_SHSPD_DMG_LINE_CNT", netFaultEvent.getmNetAlarmCnt());
			jsonObject.put("MASS_IPTV_DMG_LINE_CNT", netFaultEvent.getmIptvAlarmCnt());
			jsonObject.put("MASS_PHON_DMG_LINE_CNT", netFaultEvent.getmPhoneAlarmCnt());
			jsonObject.put("MASS_SHSPD_INET_VOC_CNT", netFaultEvent.getmNetVocCnt());
			jsonObject.put("MASS_IPTV_VOC_CNT", netFaultEvent.getmIptvVocCnt());
			jsonObject.put("MASS_VOIP_VOC_CNT", netFaultEvent.getmVoipVocCnt());
			jsonObject.put("CO_DMG_SCRBR_CNT", netFaultEvent.getbAlarmCnt());
			jsonObject.put("CO_SHSPD_DMG_LINE_CNT", netFaultEvent.getbNetAlarmCnt());
			jsonObject.put("CO_IPTV_DMG_LINE_CNT", netFaultEvent.getbIptvAlarmCnt());
			jsonObject.put("CO_PHON_DMG_LINE_CNT", netFaultEvent.getbPhoneAlarmCnt());
			jsonObject.put("CO_SHSPD_INET_VOC_CNT", netFaultEvent.getbNetVocCnt());
			jsonObject.put("CO_IPTV_VOC_CNT", netFaultEvent.getbIptvVocCnt());
			jsonObject.put("CO_VOIP_VOC_CNT", netFaultEvent.getbVoipVocCnt());
			jsonObject.put("DABL_OBJ_CL_CD", netFaultEvent.getDevAlarmType());

			// 피해가입자수는 (매스 피해고객수) + (비즈 피해고객수)를 사용하여 계산
			int massDmgScrbrCnt = 0;
			try {
				massDmgScrbrCnt = Integer.parseInt(netFaultEvent.getmAlarmCnt());
			} catch (Exception e) {
				;
			}
			int coDmgScrbrCnt = 0;
			try {
				coDmgScrbrCnt = Integer.parseInt(netFaultEvent.getbAlarmCnt());
			} catch (Exception e) {
				;
			}
			jsonObject.put("DMG_SCRBR_CNT", (massDmgScrbrCnt+coDmgScrbrCnt)+"");
		} else if (FomsEvent.DETAIL_CMD2_AMI_GEN == event.getDetailCmd2() || FomsEvent.DETAIL_CMD2_ENV_GEN == event.getDetailCmd2()) {
			// AMI 실시간 장애, 환경감시단말 실시간 장애
			jsonObject.put("NET_CL_CD", NET_CL_CD3);
			jsonObject.put("NET_CL_NM", NET_CL_NM3);
			jsonObject.put("DABL_ST_CD", GENERATED_FAULT_CD);
			jsonObject.put("kind", GENERATE_EVENT);
		} else if (FomsEvent.DETAIL_CMD2_AMI_CLR == event.getDetailCmd2() || FomsEvent.DETAIL_CMD2_ENV_CLR == event.getDetailCmd2()) {
			// AMI 실시간 장애 해제, 환경감시단말 장애 해제
			jsonObject.put("NET_CL_CD", NET_CL_CD3);
			jsonObject.put("NET_CL_NM", NET_CL_NM3);
			jsonObject.put("DABL_ST_CD", CLEARED_FAULT_CD);
			jsonObject.put("RLSE_DTM", event.getEvtGenTime());
			jsonObject.put("RLSE_RCV_DTM", MiscUtils.getDateTime ());
			jsonObject.put("kind", CLEAR_EVENT);
		}
		logger.debug("JSON:" + jsonObject.toString());
		jsonSender.put(jsonObject);
	}
	

	
    private void rmsSender(RmsEvent event) throws Exception {
    	
    	//if (omn30203Map == null) {
			readRmsFaultCode();
		//}
    	
    	if ("04".equals(event.getEvtId()) && "90".equals(event.getEvtCode())) return;

    	JSONObject jsonObject = new JSONObject();    	
    	jsonObject.put("DABL_LCL_CD", event.getDablLclCd());
    	jsonObject.put("NMS_CD", NMS_EQUIP_CD);
    	jsonObject.put("NMS_NM", NMS_EQUIP_NM);
    	jsonObject.put("NMS_DABL_NUM_CTT", "" + event.getSerialNo());
    	jsonObject.put("NET_CL_CD", NET_CL_CD);
    	jsonObject.put("NET_CL_NM", NET_CL_NM);
    	
    	String key = event.getEvtId() + event.getEvtCode();
		OMN30203 omn30203 = omn30203Map.get(key);
		if("Y".equals(omn30203.getNmsCatvYn())){
			jsonObject.put("NMS_CD", NMS_CD_CATV_R);
	    	jsonObject.put("NMS_NM", NMS_NM_CATV_R);
		}

    	if ("0".equals(event.getSeverity())) { // 장애해제
    		jsonObject.put("RLSE_DTM", event.getGenTime());
    		jsonObject.put("RLSE_RCV_DTM", MiscUtils.getDateTime());
    		jsonObject.put("DABL_ST_CD", CLEARED_FAULT_CD);
    		jsonObject.put("DABL_ST_NM", CLEARED_FAULT_NM);
    		jsonObject.put("NMS_CD", NMS_EQUIP_CD);
    		jsonObject.put("kind", CLEAR_EVENT);
    	} else { // 장애    		
			jsonObject.put("DABL_ST_CD", GENERATED_FAULT_CD);
    		jsonObject.put("DABL_ST_NM", GENERATED_FAULT_NM);

    		String swingAnnceYn = "N";
    		if (omn30203 == null) {
    			jsonObject.put("DABL_LCL_CD", "*");
    			jsonObject.put("DABL_LCL_NM", "*");
    			jsonObject.put("DABL_MCL_CD", "*"); 
    			jsonObject.put("DABL_MCL_NM", "*");
    			jsonObject.put("DABL_CD", "*");
    			jsonObject.put("DABL_NM", "*");
    		} else {
    			
    			jsonObject.put("DABL_LCL_CD", omn30203.getDablLclCd());
    			jsonObject.put("DABL_LCL_NM", omn30203.getDablLclNm());
    			jsonObject.put("DABL_MCL_CD", omn30203.getDablMclCd());
    			jsonObject.put("DABL_MCL_NM", omn30203.getDablMclNm());
    			jsonObject.put("DABL_CD", omn30203.getDablCd());
    			jsonObject.put("DABL_NM", omn30203.getDablCdNm());
				if (omn30203.getDablCd().equals ("014035")
						|| omn30203.getDablCd().equals ("074006")
						|| omn30203.getDablCd().equals ("074007")
						|| omn30203.getDablCd().equals ("074008")) {
					swingAnnceYn = "Y";
					/* Circuit 장애 규격에 DAMAGE_CUST_CNT 항목 추가됨 (2018.12.17)
					String dmgScrbrCnt = null;
					if (0 <= event.getContent().indexOf ("Offline:")) {
						String	one = event.getContent().substring (event.getContent().indexOf ("Offline:") + 8);
						if (one != null) {
							if (0 <= event.getContent().indexOf ("Offline:")) {
								for (int index = 0; index < one.length (); ++ index) {
									if ('0' <= one.charAt (index) && one.charAt (index) <= '9')
										dmgScrbrCnt += one.charAt (index);
									else
										break;
								}	
							}
						}
					}
					*/
				}
    		}
			jsonObject.put("SWING_ANNCE_YN", swingAnnceYn);
    		jsonObject.put("OCCR_DTM", event.getGenTime());
    		jsonObject.put("OCCR_RCV_DTM", MiscUtils.getDateTime());    		
    		jsonObject.put("DABL_GR_CD", event.getDablGrCd());
    		jsonObject.put("MKT_DIV_ORG_ID", "");
    		jsonObject.put("MKT_DIV_ORG_NM", "");
    		jsonObject.put("TEAM_ORG_ID", "");
    		jsonObject.put("TEAM_ORG_NM", "");
    		jsonObject.put("INFO_CNTR_CD", "");
    		jsonObject.put("INFO_CNTR_NM", "");
    		jsonObject.put("DISTB_CNTR_CD", "");
    		jsonObject.put("DISTB_CNTR_NM", "");
    		jsonObject.put("EQUIP_ID", event.getTid());
    		jsonObject.put("EQUIP_TID_VAL", event.getTid());
    		jsonObject.put("EQUIP_IP_ADDR", event.getSysId());
    		jsonObject.put("EQUIP_NM", event.getSysName());
    		jsonObject.put("EQUIP_MDL_CD", event.getDevType());
			jsonObject.put("DABL_DUP_YN", "");
			// OTX_NUM, CCELL_NUM 값이 || 를 구분자로 2개 이상 들어올 경우, 첫번째 값만 저장
			String otxNum = event.getOtxNo();
			if(otxNum == null || "".equals(otxNum)) {
				logger.info("[SPLIT] (skip) otxNum is null or blank");
			} else {
				logger.info("[SPLIT] (before) otxNum = " + otxNum);
				otxNum = otxNum.split("\\|\\|")[0];
				logger.info("[SPLIT] (after) otxNum = " + otxNum);
			}
			jsonObject.put("OTX_NUM", otxNum);
			
			String ccellNum = event.getCellNo();
			if(ccellNum == null || "".equals(ccellNum)) {
				logger.info("[SPLIT] (skip) ccellNum is null or blank");
			} else {
				logger.info("[SPLIT] (before) ccellNum = " + ccellNum);
				ccellNum = ccellNum.split("\\|\\|")[0];
				logger.info("[SPLIT] (after) ccellNum = " + ccellNum);
			}
			jsonObject.put("CCELL_NUM", ccellNum);
			jsonObject.put("SCARD_NUM_CTT", event.getCardNo());
			try {
				int portNo = Integer.parseInt(event.getPortNo());
				jsonObject.put("PORT_NUM", event.getPortNo());
			} catch (Exception e) {
				jsonObject.put("PORT_NUM", "");
			}
			jsonObject.put("DABL_DESC", event.getContent());

			jsonObject.put("SHSPD_VOC_CNT", ""+event.getVocCount());
			jsonObject.put("SHSPD_INET_DMG_LINE_CNT", ""+event.getInternetCnt());
			jsonObject.put("GNRL_IPTV_DMG_LINE_CNT", ""+event.getCommIptvCnt());
			jsonObject.put("INDPND_IPTV_DMG_LINE_CNT", ""+event.getOnlyIptvCnt());
			jsonObject.put("GNLPH_DMG_LINE_CNT", ""+event.getVoiceCnt());
			jsonObject.put("IPTV_VOC_CNT", ""+event.getIptvVocCnt());
			jsonObject.put("PHON_VOC_CNT", ""+event.getVoiceVocCnt());
			jsonObject.put("TOT_VOC_CNT", ""+event.getTotalVocCnt());
			jsonObject.put("VOIP_VOC_CNT", "0");
			jsonObject.put("OPER_DABL_YN", ""+event.getOperDablYn());

			if (RmsEvent.EVT_EQUIP_FAULT.equals(event.getEvtKind())) {
				RmsEquipFaultEvent equipFaultEvent = (RmsEquipFaultEvent) event;

				jsonObject.put("EQUIP_MDL_NM", equipFaultEvent.getDevTypeName());
				jsonObject.put("DABL_DUP_CNT", "");
				jsonObject.put("DABL_DUP_CNT_1", "1" );
				jsonObject.put("DABL_DUP_CNT_2", "1" );
				jsonObject.put("DABL_DUP_CNT_3", "1" );
				
				jsonObject.put("NET_OP_NUM", "");
				jsonObject.put("EQUIP_SET_LOC_DESC", "");
				jsonObject.put("DMG_SCRBR_CNT", "");
				jsonObject.put("TM_TYP_CD", "");
				jsonObject.put("TM_CTT", "");
				jsonObject.put("INCOMM_BIZR_ID", "");
				jsonObject.put("MODULE_EQUIP_ID", "");
				jsonObject.put("MSC_MODULE_NM", "");
				jsonObject.put("ROUT_NUM", "");
				jsonObject.put("ROUT_NM", "");
				jsonObject.put("DSST_YN", "");
				jsonObject.put("DSSTR_YN", "");
				
			} else if (RmsEvent.EVT_CATV_FAULT.equals(event.getEvtKind())) {
				/* 2022-09-30 CATV 장애 추가  강대윤*/
				
				RmsCatvFaultEvent catvFaultEvent = (RmsCatvFaultEvent) event;
				
				jsonObject.put("EQUIP_MDL_NM", catvFaultEvent.getDevTypeName());
				jsonObject.put("DABL_DUP_CNT", "");
				jsonObject.put("DABL_DUP_CNT_1", "1" );
				jsonObject.put("DABL_DUP_CNT_2", "1" );
				jsonObject.put("DABL_DUP_CNT_3", "1" );
				
				jsonObject.put("NET_OP_NUM", "");
				jsonObject.put("EQUIP_SET_LOC_DESC", "");
				//2025.11.04 김준수정 CATV도 피해고객수 적용
				jsonObject.put("DMG_SCRBR_CNT", catvFaultEvent.getDmgTotalCustCount()+""); //피해고객수(전체)
				jsonObject.put("TM_TYP_CD", "");
				jsonObject.put("TM_CTT", "");
				jsonObject.put("INCOMM_BIZR_ID", "");
				jsonObject.put("MODULE_EQUIP_ID", "");
				jsonObject.put("MSC_MODULE_NM", "");
				jsonObject.put("ROUT_NUM", "");
				jsonObject.put("ROUT_NM", "");
				jsonObject.put("DSST_YN", "");
				jsonObject.put("DSSTR_YN", "");
				//2025.11.04 김준 수정 CATV도 수용고객수 항목에 값 생성
				jsonObject.put ("SCRBR_CNT", ""+catvFaultEvent.getCustTotalCount()+""); //수용고객수(전체)
				// 2025.04.22 실시간 장애규격변경
				// - CATV 피해 고객/회선수 관련 항목 추가
				jsonObject.put ("CM_STB_CNT", catvFaultEvent.getCmStbCount());
				jsonObject.put ("TOT_LINE_CNT", catvFaultEvent.getLineTotalCnt());
				jsonObject.put ("INET_LINE_CNT", catvFaultEvent.getLineInternetCount());
				jsonObject.put ("QAM_LINE_CNT", catvFaultEvent.getLineQamCount());
				jsonObject.put ("VSB8_LINE_CNT", catvFaultEvent.getLine8vsbCount());
				jsonObject.put ("TOT_DMG_LINE_CNT", catvFaultEvent.getDmgTotalLineCount());
				jsonObject.put ("INET_DMG_LINE_CNT", catvFaultEvent.getDmgInternetLineCount());
				jsonObject.put ("QAM_DMG_LINE_CNT", catvFaultEvent.getDmgQamLineCount());
				jsonObject.put ("VSB8_DMG_LINE_CNT", catvFaultEvent.getDmg8vsbLineCount());
				jsonObject.put ("TOT_VOC_CNT", catvFaultEvent.getTotalVocCnt());
				jsonObject.put ("TOT_CUST_CNT", catvFaultEvent.getCustTotalCount());
				jsonObject.put ("INET_CUST_CNT", catvFaultEvent.getCustInternetCount());
				jsonObject.put ("QAM_CUST_CNT", catvFaultEvent.getCustQamCount());
				jsonObject.put ("VSB8_CUST_CNT", catvFaultEvent.getCust8vsbCount());
				jsonObject.put ("TOT_DMG_CUST_CNT", catvFaultEvent.getDmgTotalCustCount());
				jsonObject.put ("INET_DMG_CUST_CNT", catvFaultEvent.getDmgInternetCustCount());
				jsonObject.put ("QAM_DMG_CUST_CNT", catvFaultEvent.getDmgQamCustCount());
				jsonObject.put ("VSB8_DMG_CUST_CNT", catvFaultEvent.getDmg8vsbCustCount());
				jsonObject.put ("TB_SO_NM", catvFaultEvent.getCatvSoName());
				jsonObject.put ("CELL_MEMO", catvFaultEvent.getCellMemo());

			} else if (RmsEvent.EVT_CIRCUIT_FAULT.equals(event.getEvtKind())) {
				RmsCircuitFaultEvent circuitFaultEvent = (RmsCircuitFaultEvent) event;

				jsonObject.put("EQUIP_MDL_NM", "*");
	        	jsonObject.put ("DABL_DUP_CNT", "");
	        	jsonObject.put ("DABL_DUP_CNT_1", "1" );
	        	jsonObject.put ("DABL_DUP_CNT_2", "1" );
	        	jsonObject.put ("DABL_DUP_CNT_3", "1" );
	        	
	        	jsonObject.put ("NET_OP_NUM", "");
	        	jsonObject.put ("EQUIP_SET_LOC_DESC", "");
	        	jsonObject.put ("DMG_SCRBR_CNT", ""+circuitFaultEvent.getDamageCustCnt());
	        	jsonObject.put ("U_ORG_ID", "");
				jsonObject.put ("U_ORG_NM", "");
				jsonObject.put ("L_ORG_ID", "");
				jsonObject.put ("L_ORG_NM", "");
				jsonObject.put ("CUST_NUM", "");
				jsonObject.put ("LINE_NUM", "");
				jsonObject.put ("RING_NUM", "");
				jsonObject.put ("RING_NM", "");
				jsonObject.put ("DSSTR_YN", "");
				// 2018.12.17 실시간 장애규격변경
				// - 장애별 피해 고객/회선수 관련 항목 추가
				// - 2018.12.27 20:00 운용 적용
				jsonObject.put ("SCRBR_CNT", ""+circuitFaultEvent.getTotalCustCnt());
				jsonObject.put ("SHSPD_ACEPT_LINE_CNT", ""+circuitFaultEvent.getInternetLineCnt());
				jsonObject.put ("GNRL_IPTV_ACEPT_LINE_CNT", ""+circuitFaultEvent.getCommIptvLineCnt());
				jsonObject.put ("INDPND_IPTV_ACEPT_LINE_CNT", ""+circuitFaultEvent.getOnlyIptvLineCnt());
				jsonObject.put ("PHON_ACEPT_LINE_CNT", ""+circuitFaultEvent.getVoiceLineCnt());
				jsonObject.put ("DMG_SCRBR_CNT", ""+circuitFaultEvent.getDamageCustCnt());
				jsonObject.put ("DABL_RMK", circuitFaultEvent.getMemo());
				jsonObject.put ("RING_NUM", circuitFaultEvent.getRingId());
				jsonObject.put ("FDF_LINE_NUM", circuitFaultEvent.getFdf());
				jsonObject.put ("CBL_DIST", circuitFaultEvent.getCableDistance());
				
			}
			jsonObject.put ("kind", GENERATE_EVENT);
			jsonObject.put ("DABL_OCCR_LOC_DESC", 
						event.getOtxNo()
						+ "_" + event.getCellNo()
						+ "_" + event.getCardNo()
						+ "_" + event.getPortNo());

    	}
    	logger.debug("JSON:" + jsonObject.toString());
		jsonSender.put(jsonObject);
    }
	
	private boolean isSktEquipForSkb(String neId) throws Exception {
		if (sktEquipMap == null) {
			loadSktEquipMap();
		}
		String val = sktEquipMap.get(neId);
		if (val != null) {
			return true;
		} else {
			return false;
		}
	}
	
	// TEAMS 관련 장애 코드 조회해서 분류별로 Hashtable에 저장한다.
		private void loadTeamsFaultCodeMap() throws Exception {
			
			if (omn30203Map == null) {
				omn30203Map = new HashMap<String, OMN30203>();
			} else {
				omn30203Map.clear();
			}
			
			// DABL_LCL_CD, DABL_LCL_NM, DABL_MCL_CD, DABL_MCL_NM, DABL_CD, DABL_CD_NM, NMS_DABL_CD
			List<OMN30203> omn30203List = (List) adamsSession.selectList("RealtimeTeams.selectOMN30203", null);
			if (omn30203List != null) {
				int i=0;
				for (OMN30203 omn30203 : omn30203List) {
					++i;
					String key = omn30203.getDablMclNm()+omn30203.getDablCdNm();
					omn30203Map.put(key, omn30203);				
				}
				logger.debug("TEAMS 장애코드 총 : "+i + "건 로딩완료");
			}
		}
		
		private void loadSktEquipMap() throws Exception {
			List<Long> sktEquipNums = adamsSession.selectList("RealtimeTeams.selectSktEquipForSKB", null);
			if (sktEquipMap == null) {
				sktEquipMap = new HashMap<String, String>();
			} else {
				sktEquipMap.clear();
			}
			if (sktEquipNums != null) {
				int i = 0;
				for(Long sktEquipNum : sktEquipNums) {
					logger.info(String.format("SktEquipMap[%d]%s", ++i, sktEquipNum.toString()));
					sktEquipMap.put(sktEquipNum.toString(), sktEquipNum.toString());
				}
				logger.info("SktEquipMap size:" + sktEquipNums.size());
			}
		}
		
		// FOMS 관련 장애 코드 조회해서 분류별로 Hashtable에 저장한다.
		public void readFomsFaultCode() throws Exception {
			omn30203Map = new HashMap<String, OMN30203>();
			// DABL_LCL_CD, DABL_LCL_NM, DABL_MCL_CD, DABL_MCL_NM, DABL_CD, DABL_CD_NM, CLCT_EVT_ID, CLCT_EVT_CD
			List<OMN30203> omn30203List = (List) adamsSession.selectList("RealtimeFoms.selectOMN30203", null);
			for (OMN30203 omn30203 : omn30203List) {
				String key = omn30203.getClctEvtId() + omn30203.getClctEvtCd();
				omn30203Map.put(key, omn30203);
				logger.debug(String.format("(%s),(%s,%s,%s,%s,%s,%s,%s,%s)",
						key,
						omn30203.getDablLclCd(), omn30203.getDablLclNm(), omn30203.getDablMclCd(), omn30203.getDablMclNm(),
						omn30203.getDablCd(), omn30203.getDablCdNm(), omn30203.getClctEvtId(), omn30203.getClctEvtCd()));
			}
		}
		
		// RMS 관련 장애 코드 조회해서 분류별로 Hashtable에 저장한다.
		public void readRmsFaultCode () throws Exception {
			omn30203Map = new HashMap<String, OMN30203>();
			// DABL_LCL_CD, DABL_LCL_NM, DABL_MCL_CD, DABL_MCL_NM, DABL_CD, DABL_CD_NM, CLCT_EVT_ID, CLCT_EVT_CD
			List<OMN30203> omn30203List = (List) adamsSession.selectList("RealtimeRms.selectOMN30203", null);
			for (OMN30203 omn30203 : omn30203List) {
				String key = omn30203.getClctEvtId() + omn30203.getClctEvtCd();
				omn30203Map.put(key, omn30203);
				logger.debug(String.format("(%s),(%s,%s,%s,%s,%s,%s,%s,%s)",
						key,
						omn30203.getDablLclCd(), omn30203.getDablLclNm(), omn30203.getDablMclCd(), omn30203.getDablMclNm(),
						omn30203.getDablCd(), omn30203.getDablCdNm(), omn30203.getClctEvtId(), omn30203.getClctEvtCd(), omn30203.getNmsCatvYn()));
			}
		}

}
