package com.skb.mi.realtime;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.sql.ResultSet;

// JSON
import	org.json.simple.JSONObject;
import	org.json.simple.parser.JSONParser;

// WebSocket
import	org.java_websocket.WebSocketImpl;
import	org.java_websocket.client.WebSocketClient;
import	org.java_websocket.drafts.Draft;
import	org.java_websocket.drafts.Draft_6455;
import	org.java_websocket.handshake.ServerHandshake;

import  com.skb.mi.common.DBController;
import	com.skb.mi.thread.SmsClientThread;					// 1분마다 SMS발송 VIP List를 Update

public class SmsClient extends WebSocketClient {

	public static String ALL_SVC_MGMT_NUM = "9999999999";

	JSONParser	   jsonParser;
    DBController   dbController;
    String         dbUrl, userName, password; 

    String         absolutePath;

	Hashtable<String,String>	faultList;

	// 1분마다 SMS 발송 VIP List를 Update하는 Thread
	SmsClientThread				smsClientThread;

	private WebSocketClient webSocketClient;

	public SmsClient (String absolutePath, URI url, Draft draft) {
		super (url, draft);
        this.absolutePath = absolutePath;
		jsonParser = new JSONParser ();

		faultList = new Hashtable<String,String> ();

        try {
//			System.out.println ("before readDbInfo ()");
            readDbInfo ();
//			System.out.println ("before dbOpen ()");
			dbOpen ();
//			System.out.println ("before create Thread");
			smsClientThread = new SmsClientThread (dbController.getStmt ());
			smsClientThread.start ();
        } catch (Exception e) {
             System.out.println ("SmsClient 생성 Exception : " + e);
        } 
	}

	public void readDbInfo () throws Exception {
		String  oneLine;
		FileReader      fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + "db.info");
		BufferedReader bufferedReader = new BufferedReader (fileReader);
		dbUrl = bufferedReader.readLine ();
		userName = bufferedReader.readLine ();
		password = bufferedReader.readLine ();
		bufferedReader.close ();
		fileReader.close ();
	}

	public void dbOpen () {
        try {
             dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
        } catch (Exception e) {
             System.out.println ("SmsClient DB Exception : " + e);
             System.exit (1);                                        // DB접속 에러시 종료
        } 
	}

	@Override
	public void onOpen (ServerHandshake serverHandshake) {
//		System.out.println ("opend connection....");
		String	message = "{\"kind\":\"ID\",\"ID\":\"gildong\",\"recvMessage\":\"GEN|CLR\"}";
		send (message);
	}

	@Override
	public void onMessage (String message) {
//        System.out.println ("\nonMessage : " + message);
        String dablNum, equipId, dablCd;
		try {
			JSONObject	jsonObject = (JSONObject) jsonParser.parse (message);
			String		kind = jsonObject.get ("kind").toString ();
			if (kind != null ) {
				if (kind.equals ("GEN")) {			// 장애 발생
					equipId = jsonObject.get ("EQUIP_ID").toString ();
					dablCd = jsonObject.get ("DABL_CD").toString ();
					dablNum = jsonObject.get ("DABL_NUM").toString ();
					String nmsCd = jsonObject.get ("NMS_CD").toString ();
					String dablLclCd = jsonObject.get ("DABL_LCL_CD").toString ();
					String dablMclCd = jsonObject.get ("DABL_MCL_CD").toString ();
//					System.out.println ("[" + getDateSecond () + "] DABL_NUM : " + dablNum)
//					System.out.println ("\n\nTEAMS 장애 : " + (String) jsonObject.toString ());
					if (nmsCd.equals ("005") && dablLclCd.equals ("04") && dablMclCd.equals ("04201"))		// TEAMS & 회선장애 & 전송망회선장애 
						checkSms (jsonObject);
				} else if (kind.equals ("CLR")) {							// 장애 해제
					System.out.println ("해제 : " + jsonObject.toString ());
					sendClearSms (jsonObject.get ("NMS_DABL_NUM_CTT").toString ()
								, jsonObject.get ("RLSE_RCV_DTM").toString ());
				}
			}
			jsonObject = null;
		} catch (Exception e) {
			System.out.println ("[" + getDateSecond () + "] " + "=========== Exception ==========");
			System.out.println ("[" + getDateSecond () + "] " + "Received : " + message);
			System.out.println ("[" + getDateSecond () + "] " + "jsonParser : " + jsonParser);
			System.out.println ("[" + getDateSecond () + "] " + "Exception : " + e);
			System.out.println ("[" + getDateSecond () + "] " + "================================\n");
		}
	}

	public void checkSms (JSONObject jsonObject) {
		String	svcMgmtNum = jsonObject.get ("SVC_MGMT_NUM").toString ();
		String	occrRcvDtm = jsonObject.get ("OCCR_RCV_DTM").toString ();
		String	lineNum = jsonObject.get ("OCCR_RCV_DTM").toString ();
		String	equipNm = jsonObject.get ("EQUIP_NM").toString ();
		String	dablPortDesc = jsonObject.get ("DABL_PORT_DESC").toString ();
		String	dablDesc = jsonObject.get ("DABL_DESC").toString ();

		String	vipList = smsClientThread.getVipList (svcMgmtNum);
		String	alarmKind = smsClientThread.getAlarmKind (svcMgmtNum);	
		String	lineUsg = smsClientThread.getLineUsg (svcMgmtNum);
		String	equipMdl = "SKB_" + smsClientThread.getEquipMdl (svcMgmtNum);

		// 모든 회선과 모든 종류를 저장
		String	allTelNo = smsClientThread.getVipList (ALL_SVC_MGMT_NUM);
		String	allAlarmKind = smsClientThread.getAlarmKind (ALL_SVC_MGMT_NUM);
 
		System.out.println ("\n\n 회선장애 : " + jsonObject.toString ());
		System.out.println ("--------------------------");
		System.out.print (" vipList : ");
		if (vipList == null)
			System.out.println (" 등록 없음");
		else
			System.out.println (vipList);
		System.out.print (" alarmKind : ");
		if (alarmKind == null)
			System.out.println (" 등록 없음");
		else
			System.out.println (alarmKind);
		System.out.println ("--------------------------\n");

		StringTokenizer	tokens;
		StringTokenizer telTokens;
		String 	query;
		String	token = "";
		String	rcvTelNo;

		occrRcvDtm = occrRcvDtm.substring (0,5);
		if ((vipList != null) && (alarmKind != null)) {
			tokens = new StringTokenizer (alarmKind, ",");
			telTokens = new StringTokenizer (vipList, ",");
			
			while (tokens.hasMoreTokens ()) {
				token = tokens.nextToken ();
				if (0 <= dablDesc.indexOf (token)) {
					while (telTokens.hasMoreTokens ()) {
						rcvTelNo = telTokens.nextToken ();
						query = makeQuery ("[발생] ", token, occrRcvDtm, svcMgmtNum, equipMdl, lineUsg, rcvTelNo);	
						dbController.executeUpdate (query);
					}
					faultList.put (jsonObject.get ("NMS_ALARM_NO").toString (), vipList + "|" + token + "|" + svcMgmtNum + "|" + equipMdl + "|" + lineUsg);
				}
			}
		}
	}

	public void sendClearSms (String key, String rlseRcvDtm) {		// Key : NMS_ALAMR_NO
		if (faultList.get (key) != null) {
			String occrRcvDtm = rlseRcvDtm.substring (0,5);

			StringTokenizer	tokens = new StringTokenizer (faultList.get (key), "|");
			String vipList = tokens.nextToken ();
			String alarmKind = tokens.nextToken ();
			String svcMgmtNum = tokens.nextToken ();
			String equipMdl = tokens.nextToken ();
			String lineUsg = tokens.nextToken ();
			String rcvTelNo, query;

			tokens = new StringTokenizer (vipList, ",");
			while (tokens.hasMoreTokens ()) {
				rcvTelNo = tokens.nextToken ();
				query = makeQuery ("[복구] ", alarmKind, occrRcvDtm, svcMgmtNum, equipMdl, lineUsg, rcvTelNo);	
				dbController.executeUpdate (query);
			}
			faultList.remove (key);
		}
	}

	@Override
	public void onClose (int code, String reason, boolean remote) {
		System.out.println ("[" + getDateSecond () + "] " + "Connection closed by " + (remote ? "remote peer" : "us"));
        dbController.closeDB ();
	}

	@Override
	public void onError (Exception e) {
		System.out.println ("[" + getDateSecond () + "] " + "onError : " + e);
        dbController.closeDB ();
	}

	public String makeQuery (String kind
							 , String alarmKind
							 , String occrRcvDtm
							 , String svcMgmtNum
							 , String equipMdl
							 , String lineUsg
							 , String rcvTelNo) {
		String	query = "INSERT INTO TBL_SUBMIT_QUEUE"
					  + " ( CMP_MSG_ID "
					  + " , CMP_MSG_GROUP_ID"
					  + " , USR_ID"
					  + " , SMS_GB"
					  + " , USED_CD"
					  + " , CONTENT_CNT"
					  + " , CONTENT_MIME_TYPE"
					  + " , RESERVED_FG"
					  + " , RESERVED_DTTM"
					  + " , SAVED_FG"
					  + " , RCV_PHN_ID"
					  + " , SND_PHN_ID"
					  + " , NAT_CD"
					  + " , ASSIGN_CD"
					  + " , SND_MSG)" 
					  + " VALUES "
					  + " (MI_APP.TBL_SUBMIT_QUEUE_SEQ.NEXTVAL"
					  + " , 'VIP_CIRCUIT'"
					  + " , '5464'"
					  + " , '1'"
					  + " , '10'"
                      + " , '1'"
                      + " , 'text/plain'"
					  + " , 'I'"
					  + " , TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS')"
					  + " , '1'"
					  + " , REPLACE ('" + rcvTelNo + "', '-', '')"
					  + " , '07078051228'"
					  + " , '82'"
					  + " , '00000'"
					  + ", 'SKB 기업회선 경보"
					  + "\n\r" + kind + occrRcvDtm + ", " + equipMdl
					  + "\n\r[회선번호] " + svcMgmtNum
					  + "\n\r[용도] " + lineUsg
					  + "\n\r[경보내용]" + alarmKind
					  + "')";

		System.out.println ("발생 쿼리 : " + query);
		return query;
	}

	public String queryString (String str) {
        String ret = "";
        for (int index = 0; index < str.length (); ++ index) {
            if (str.charAt (index) == '\'')
                ret += '\'';
            ret += str.charAt (index);
        }
        return ret;
	}

	public String getDateSecond () {
		Calendar        calendar = Calendar.getInstance ();

		return String.format ("%04d-%02d-%02d %02d:%02d:%02d",
				calendar.get(Calendar.YEAR),
				calendar.get(Calendar.MONTH) + 1,
				calendar.get(Calendar.DAY_OF_MONTH),
				calendar.get(Calendar.HOUR_OF_DAY),
				calendar.get(Calendar.MINUTE),
				calendar.get(Calendar.SECOND));
	}

	public static void main (String [] args) throws URISyntaxException {
        if (args.length != 2) {
             System.out.println ("사용법 : java SmsClient 절대패스 URI");
             System.exit(0);
        }
		SmsClient webSocketClientTest = new SmsClient (
//			new URI ("ws://12.4.96.92:59768"), new Draft_6455 ());		
			args[0], new URI (args [1]), new Draft_6455 ());		
		webSocketClientTest.connect ();
	}
}
