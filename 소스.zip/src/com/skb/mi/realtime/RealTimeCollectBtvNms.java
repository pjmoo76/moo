package com.skb.mi.realtime;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import java.util.Map;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.MiscUtils;
import com.skb.mi.realtime.bnms.BnmsEventFactory;
import com.skb.mi.thread.SendJsonThread;

import org.apache.commons.cli.HelpFormatter;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

public class RealTimeCollectBtvNms {
	
	final private int			SO_TIME_OUT	= (1000*60*5);	// Time-Out 5분 설정

	protected String			equipIpAddress;
	protected int				equipPortNo;

	// BNMS Equip 실시간 장애 수집
	Socket						equipSocket;
	InputStream					equipInputStream;
	OutputStream				equipOutputStream;

	// Push Process 정보
    String                      pushIpAddress;
    int                         pushPortNo;

    JSONObject                  jsonObject;

    private Logger				logger;
	private	SendJsonThread		jsonSender;
	private	BnmsEventFactory	factory;
	
	public RealTimeCollectBtvNms (String[] args) {
    	logger = LogManager.getLogger(this.getClass());

    	loadConfig();
    	jsonSender = new SendJsonThread(pushIpAddress, pushPortNo, true);
		factory = new BnmsEventFactory();
		
		try {
			connectNms();
			run();
        } catch (Exception e) {
        	logger.error("Exception", e);
        }
    }
    
	public void loadConfig() {
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		setNmsConnInfo(configManager);
		pushIpAddress = configManager.getConfig(Constants.BTV_WEB_PUSH, Constants.IP_ADDRESS);
		pushPortNo = Integer.parseInt(configManager.getConfig(Constants.BTV_WEB_PUSH, Constants.PORT_NO));
		
		logger.info("equipIpAddress : " + equipIpAddress);
		logger.info("equipPortNo : " + equipPortNo);
		logger.info("pushIpAddress : " + pushIpAddress);
		logger.info("pushPortNo : " + pushPortNo);

	}

	protected void setNmsConnInfo(ConfigManager configManager) {
		equipIpAddress = configManager.getConfig(Constants.BTV_NMS, Constants.IP_ADDRESS);
		equipPortNo = Integer.parseInt(configManager.getConfig(Constants.BTV_NMS, Constants.PORT_NO));
    }

	public void connectNms () {
		logger.info("connectNms");
        boolean check = false;
        while (!check) {
        	try {
        		if (equipInputStream != null) equipInputStream.close();
        	} catch (Exception e) {
        		logger.error("Exception", e);
        	}
        	try {
        		if (equipOutputStream != null) equipOutputStream.close();
        	} catch (Exception e) {
        		logger.error("Exception", e);
        	}
        	try {
        		if (equipSocket != null) equipSocket.close();
        	} catch (Exception e) {
        		logger.error("Exception", e);
        	}
            try {
            	logger.info("try connecting " + equipIpAddress + ":" + equipPortNo);
            	equipSocket = new Socket (equipIpAddress, equipPortNo);
                equipSocket.setSoTimeout(SO_TIME_OUT);  //ics 20200506 주석 해제
                equipInputStream = equipSocket.getInputStream();
                equipOutputStream = equipSocket.getOutputStream ();

				sendLoginPacket();
				
				logger.info("connected " + equipIpAddress + ":" + equipPortNo);

                check = true;
            } catch (Exception e) {
                logger.error("Exception", e);
                MiscUtils.sleep(100);            // 0.1초
            }
        }
	}
	
	
	private void run() {
		int btvErrCnt = 0; // BnmsEvent err 카운트 2020-03-17 추가
		
		JSONObject jsonObject = new JSONObject();
		int errContCnt = 0;
		int socketExceptionCnt = 0;
		Map<String, Long> errMsg = new HashMap<String, Long>();
		
		while (true) {
	    	try {
	    		//* Test
	    		if (jsonObject == null) {
	    			jsonObject = factory.get(equipInputStream);
					errContCnt = 0;
					btvErrCnt = 0;

				} else {
					// retry
					errContCnt ++;
					if (errContCnt > 3) {
						jsonObject = null;
						continue;
					}
				}
				if (jsonObject != null) {
					process(jsonObject); 
					jsonObject = null;
				}
				
				socketExceptionCnt = 0;
				
			} catch (SocketTimeoutException ste) {
				logger.error("SocketTimeoutException", ste);
				socketExceptionCnt++;
				socketExceptionSleep(socketExceptionCnt);
				connectNms();
			} catch (SocketException se) {
				logger.error("SocketException", se);
				socketExceptionCnt++;
				socketExceptionSleep(socketExceptionCnt);
				connectNms();
			} catch (Exception e) {
				
				if(errMsg == null || errMsg.size() == 0 || errMsg.get(e.getMessage()) == null || 
						errMsg.get(e.getMessage()) + (60*1000) < System.currentTimeMillis()) {
						logger.error("Exception", e);
						btvErrCnt++;
						errMsg.put(e.getMessage(), System.currentTimeMillis());
						
						// <-- 2020-03-18 btvErrCnt가 10이상 잡힐때, 로그 실행뒤  종료되게 설정.
						if(btvErrCnt > 9){
							logger.debug("[INFO] Btvnms Process is reConnect!");
							btvErrCnt = 0;
							connectNms();
						}
						// -->
				} else {
					// pass
				}
	    	}
	    	
	    	if(errMsg.size() > 1000) {
	    		errMsg.clear();
	    	}
        }
	}
	
	private void socketExceptionSleep(int socketExceptionCnt) {
		if (socketExceptionCnt >= 10) {
			MiscUtils.sleep(10000);	// 10 초
		} else {
			MiscUtils.sleep(1000*socketExceptionCnt);	// 1*socketExceptionCnt 초
		}
	}
	
	
	
	public void process(JSONObject jsonObject) throws Exception {
		jsonSender.put(jsonObject);
    }
	
	public void sendLoginPacket() throws Exception {
		logger.info("sendLoginPacket");
		int		count = 0;
		
		byte [] headerPacket = {0x1b, 0x02  //start(2)
				, 0x32 						//pdutype(1)
				, 0x32 ,0x30 ,0x30 ,0x32 	//opcode(4)
				, 0x30 ,0x30 				//serialno(2)
				, 0x30 						//tbctype(1)
				, 0x31 						//anstype(1)
				, 0x30 ,0x30 ,0x30 ,0x30 	//reserved(4) 
				//, 0x30 ,0x30 ,0x30 ,0x33 ,0x37 datasize(5) + data
		};
		
		
		//byte [] bodyPacket;
		String id = this.getLoginId();
		
		byte [] bytes;
		int bodySize = id.length();
		
		byte [] sendPacket = new byte [headerPacket.length + 5 + bodySize];
		byte [] recvPacket = new byte [100];
		
		int		index = 0;

		// HeaderPacket 복사
		for (; index < headerPacket.length; ++ index)
			sendPacket [index] = headerPacket [index];
		
		// Body Size 복사
		bytes = String.format("%05d", bodySize).getBytes();
		for (int i = 0; i < bytes.length; ++ i)
			sendPacket [index ++] = bytes [i];
    	
		// login 복사
		bytes = id.getBytes ();
    	for (int i = 0; i < bytes.length; ++ i)
			sendPacket [index ++] = bytes [i];

		String send = new String(sendPacket);
		logger.info(send);
		
		equipOutputStream.write (sendPacket);
		equipOutputStream.flush();

		count = equipInputStream.read (recvPacket);
		
	}
    
    protected String getLoginId() {
    	String id = "_NPRISM_1567128017201"; 
    	
    	jsonObject = new JSONObject();
    	jsonObject.put("sessionId", id);
    	String loginId = jsonObject.toJSONString();
		
    	return loginId;
    }
   
    public static void main (String [] args) {
    	EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("RealTimeCollectBtvNms", envManager.getOptions());
    		System.exit(0);
    	}
        new RealTimeCollectBtvNms (args);
    }
}

