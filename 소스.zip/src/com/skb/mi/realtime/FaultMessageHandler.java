package com.skb.mi.realtime;

import java.math.BigDecimal;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.concurrent.BlockingQueue;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.drafts.Draft;
import org.java_websocket.drafts.Draft_6455;
import org.java_websocket.handshake.ServerHandshake;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;

public class FaultMessageHandler extends Thread{
	SmsSender		smsSender;	
	Logger		    logger;
	String          serverUri;  
	JSONParser	    jsonParser;
	FaultReceiver   faultReceiver;
	SqlSession		adamsSession;
	
	BlockingQueue<JSONObject> blockingQueue;
	Hashtable<String, String>	circuitPhoneList;
	Hashtable<String, String>	equipPhoneList;
	Hashtable<String, Object>	vipPhoneList;
	Hashtable<String, Object>	vipEquipPhoneList;
	Hashtable<String, Object>	bizPhoneList;
	Hashtable<String, Object>	bizCenterPhoneList;	
	Hashtable<String, Object>	faultList;
	
	
	
	public FaultMessageHandler (SmsSender smsSender, ConfigManager configManager) {
		super ();
		this.smsSender = smsSender;
		this.logger = smsSender.logger;
		
		this.blockingQueue = smsSender.blockingQueue;
		this.adamsSession = smsSender.adamsSession;
		serverUri = configManager.getConfig(Constants.FAULT_ALRAM, Constants.URL);
	    jsonParser = new JSONParser();
	    circuitPhoneList =  new Hashtable<String, String>();
	    equipPhoneList =  new Hashtable<String, String>();
	    vipPhoneList =  new Hashtable<String, Object>();
	    vipEquipPhoneList = new Hashtable<String, Object>();
	    bizPhoneList =  new Hashtable<String, Object>();
	    bizCenterPhoneList =  new Hashtable<String, Object>();
	    faultList =  new Hashtable<String, Object>();
	    
	    
	    //SMS설정정보얻기
	    SmsInfoDistribution smsInfoDistribution = new SmsInfoDistribution(this);
	    
	    smsInfoDistribution.start();
	   
		
	    logger.info("faultReceiver connecting ::" + serverUri); 
		try {
			faultReceiver = new FaultReceiver(new URI (serverUri),  new Draft_6455 ());
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			logger.error("URISyntaxException"+e);
			//e.printStackTrace();
		}
		faultReceiver.connect();
		
		
	}
	
	class FaultReceiver extends WebSocketClient {

		public FaultReceiver(URI serverUri, Draft protocolDraft) {
			super(serverUri, protocolDraft);
			logger.info("faultReceiver connecting ::" + serverUri + protocolDraft);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onClose(int arg0, String arg1, boolean arg2) {
			logger.info("onClose");
			
		}

		@Override
		public void onError(Exception arg0) {
			logger.error("onError ::"+arg0);
			
			arg0.printStackTrace();
			
		}

		@Override
		public void onMessage(String message) {			
			//장애 처리 및 mq에 넣고 장애상태 업데이트
			try {
				JSONObject	jsonObject = (JSONObject) jsonParser.parse (message);
				String		kind = jsonObject.get ("kind").toString ();
				
				if("GEN".equals(kind))
				{
					processFalut(jsonObject);
				}else if("CLR".equals(kind))
				{
					processClear(jsonObject);
				}
				
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				logger.error(e);
			}catch (Exception e) {
				logger.error(e);
				logger.debug(message);
				e.printStackTrace();
			
			}
			
			//logger.info(message);
			
			
			
			
		}

		@Override
		public void onOpen(ServerHandshake arg0) {
			logger.info("on open");
			String	message = "{\"kind\":\"ID\",\"ID\":\"smsSender\",\"recvMessage\":\"GEN|CLR\"}";
			send (message);
			//최초 접속시 새로운 sms 설정정보얻어오기
			
		}
		
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		logger.info("FaultMessageHandler Start");

		long nextSocketCheckTime = (System.currentTimeMillis() / 1000L) + (10); //10초
		long nextFaultListCheckTime = (System.currentTimeMillis() / 1000L) + (60*60*24); //하루
		
		try {
			
			while(true){
			
				 try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						logger.error("Thread sleep Error",e);
					}
				 
				long currentTime = System.currentTimeMillis() / 1000L;	
				
				if(nextSocketCheckTime < currentTime){					
					if (!faultReceiver.getConnection().getReadyState().equals(org.java_websocket.WebSocket.READYSTATE.OPEN)) {
						logger.info("try reconnecting");
						faultReceiver = new FaultReceiver(new URI (serverUri),  new Draft_6455 ());
						faultReceiver.connect();
					}
					nextSocketCheckTime = currentTime + (10);				
				}else if(nextFaultListCheckTime < currentTime){
					nextFaultListCheckTime = currentTime + (60*60*24);
					clearFaultAfter7Day();
				}
				
			}
		} catch (URISyntaxException uriE) {
			// TODO Auto-generated catch block
			logger.error(uriE);
		}catch (Exception e){
			logger.error(e);
		}
		
	}	

	public void processFalut (JSONObject json) {
		
		String 	dablLclCd = json.get ("DABL_LCL_CD").toString ();
		String 	nmsCd = json.get ("NMS_CD").toString ();
		String dablMclCd = json.get ("DABL_MCL_CD").toString ();
		
		//모든 장애 대상 2023-12-12
		
		//TEAMS 장애이면서 회선장애/TEAMS 회선장애
		if("005".equals(nmsCd) && "04".equals(dablLclCd) && "04201".equals(dablMclCd))
		{
			processVip(json);
			processVipEquip(json);
			processCircuit(json);
			
			//장비장애 인경우 
		}else if("01".equals(dablLclCd)){
			processEquip(json);
			processBiz(json);
			processBizCenter(json);
			
		}		
		
	    
	}
	public void processEquip (JSONObject json) {
		String equipId = (String) json.get ("EQUIP_ID");
		String dablGrCd = (String) json.get ("DABL_GR_CD");
		String dablCd = (String) json.get ("DABL_CD");
		String rcvPhonNum = null;
		synchronized (equipPhoneList) {
			rcvPhonNum = equipPhoneList.get(equipId+","+dablGrCd+","+dablCd);
		
			String dablNum = (String) json.get ("DABL_NUM");
			JSONObject fault = (JSONObject) faultList.get(dablNum+",FAULT_EQUIP");
			
			//같은 타입 같은 장애인경우 처리하지않음
			if(fault != null ){
				return ;
			}
			
			if(rcvPhonNum==null)
			{
				
				rcvPhonNum = equipPhoneList.get(equipId+","+dablGrCd+",null");
				
				
			}
		}
		if(rcvPhonNum!=null)
		{
			//deepCopy 
			JSONObject falut = new JSONObject();
			falut.putAll(json);
			falut.put("FAULT_TYPE", "FAULT_EQUIP");			
			falut.put("RCV_PHON_NUMS", rcvPhonNum);
			
			//장애리스트에 등록				
			faultList.put((String) json.get("DABL_NUM")+",FAULT_EQUIP", falut);				
			
			//MQ에 등록하여 SEND처리 
			blockingQueue.add((JSONObject) falut);
			logger.info("faultList :: "+faultList.size());
		}
	}
	public void processCircuit (JSONObject json) {
		String lineNum = (String) json.get ("LINE_NUM");
		String dablGrCd = (String) json.get ("DABL_GR_CD");
		String rcvPhonNum = null;
		synchronized (circuitPhoneList) {
			rcvPhonNum = circuitPhoneList.get(lineNum+","+dablGrCd);
		}
		String dablNum = (String) json.get ("DABL_NUM");
		JSONObject fault = (JSONObject) faultList.get(dablNum+",FAULT_CIRCUIT");
		//같은 타입 같은 장애인경우 처리하지않음
		if(fault != null ){
			return ;
		}
		if(rcvPhonNum!=null)
		{
			//deepCopy 
			JSONObject falut = new JSONObject();
			falut.putAll(json);
			falut.put("FAULT_TYPE", "FAULT_CIRCUIT");			
			falut.put("RCV_PHON_NUMS", rcvPhonNum);
			
			//장애리스트에 등록				
			faultList.put((String) json.get("DABL_NUM")+",FAULT_CIRCUIT", falut);	
			//MQ에 등록하여 SEND처리 
			blockingQueue.add((JSONObject) falut);
			logger.info("faultList :: "+faultList.size());
			logger.info((String) json.get("DABL_NUM")+",FAULT_CIRCUIT");
		}
	}	
	
	@SuppressWarnings("unchecked")
	public void processVip (JSONObject json) {
				
		String svcMgmtNum = (String) json.get ("SVC_MGMT_NUM");
		if(svcMgmtNum == null)
		{
			return;
		}
		String dablNum = (String) json.get ("DABL_NUM");
		HashMap<String, String> vip = null;
		synchronized (vipPhoneList) {
			vip = (HashMap<String, String>)vipPhoneList.get(svcMgmtNum);
		}
		
		JSONObject fault = (JSONObject) faultList.get(dablNum+",VIP_CIRCUIT");
		//같은 타입 같은 장애인경우 처리하지않음
		if(fault != null ){
			return ;
		}
		if(vip!=null )		
		{
			String dablSetMsgCtt = vip.get("DABL_SET_MSG_CTT");
			String dablDesc = (String) json.get("DABL_DESC"); 
						
			StringTokenizer tokens = new StringTokenizer (dablSetMsgCtt, ",");
			
			while (tokens.hasMoreTokens ()) {
				String	token = tokens.nextToken ();
				//해당하는 장애가 존재함
				if(token.equals(dablDesc))
				{
					//deepCopy 
					JSONObject falut = new JSONObject();
					falut.putAll(json);
					falut.put("FAULT_TYPE", "VIP_CIRCUIT");
					falut.put("LINE_USG_CTT", vip.get("LINE_USG_CTT"));
					falut.put("EQUIP_TYP_CL_CD", vip.get("EQUIP_TYP_CL_CD"));
					falut.put("RCV_PHON_NUMS", vip.get("RCV_PHON_NUMS"));
					
					
					
					//장애리스트에 등록				
					faultList.put((String) json.get("DABL_NUM")+",VIP_CIRCUIT", falut);					
					
					logger.info("VIP_CIRCUIT "+ falut.toJSONString());
					//MQ에 등록하여 SEND처리 
					blockingQueue.add((JSONObject) falut);
					
					//이메일전송
					falut.put("RCV_EMAIL_ADDR", vip.get("RCV_EMAIL_ADDR"));
					sendEmail(fault);
					
					logger.info("faultList :: "+faultList.size());
				}		
				
			}
		}	
	}
	
	@SuppressWarnings("unchecked")
	private void sendEmail(JSONObject fault) {
		
		ArrayList<String> emailList = new ArrayList<>();
		String[] list = String.valueOf(fault.get("RCV_EMAIL_ADDR")).split(",");
		if(list.length > 0){
			for(String email : list){
				emailList.add(email);
			}
		}else{ //테스트데이터
			emailList.add("kimjun@thingspire.com");
		}
		
		for(String email : emailList){
		
			StringBuffer email_txt = new StringBuffer("");
			email_txt.append("<table cellpadding='0' cellspacing='0' style='width:760px;margin:0 auto;'>");
			
			email_txt.append("<tr>");
				email_txt.append("<td style='padding:0;margin:0;height:58px;'>");
				email_txt.append("<img src='https://adams.skbroadband.com/web/styles/images/had.jpg' alt='' />");
				email_txt.append("</td>");
			email_txt.append("</tr>");
			
			
			email_txt.append("<tr>");
				email_txt.append("<td style='padding:100px 0 100px 0;margin:0;'>");
				email_txt.append("<p style='padding:0;margin:0;line-height:26px;font-size:16px;color:#3a3428;text-align:center;font-family:나눔고딕,Malgun Gothic;'>");
				email_txt.append("<strong style='color:#e86632;'>"+fault.get("EQUIP_NM")+"("+fault.get("EQUIP_ID")+")</strong> 장비 고장 발생.");
				email_txt.append("</p>");
				email_txt.append("<p style='padding:0;margin:0;line-height:26px;font-size:16px;color:#3a3428;text-align:center;font-family:나눔고딕,Malgun Gothic;'>");
				email_txt.append("[장비명] " + fault.get("EQUIP_NM")+"("+fault.get("EQUIP_ID")+")");
				email_txt.append("</p>");
				email_txt.append("<p style='padding:0;margin:0;line-height:26px;font-size:16px;color:#3a3428;text-align:center;font-family:나눔고딕,Malgun Gothic;'>");
				email_txt.append("[장비명] " + fault.get("EQUIP_TID_VAL"));
				email_txt.append("</p>");
				email_txt.append("<p style='padding:0;margin:0;line-height:26px;font-size:16px;color:#3a3428;text-align:center;font-family:나눔고딕,Malgun Gothic;'>");
				email_txt.append("[장애명] " + fault.get("EQUIP_NM"));
				email_txt.append("</p>");
				email_txt.append("</td>");
			email_txt.append("</tr>");
			
			email_txt.append("</table>");
			
			fault.put("EMAIL_TITLE_NM",  "[ADAMS] 장비경보 ");
			fault.put("EMAIL_PHRS",  email_txt.toString());
			
			fault.put("RCV_EMAIL_ADDR", email);
			try{
				adamsSession.insert("smsSender.SEND_VIP_EMAIL", fault);
			}catch(Exception e){
				logger.info("Email Send Error : "+ e.getMessage());
			}
			
			
		}
		
		 
	}

	@SuppressWarnings("unchecked")
	public void processVipEquip (JSONObject json) {
				
		String equipId = (String) json.get ("EQUIP_ID");
		if(equipId == null)
		{
			return;
		}
		String dablNum = (String) json.get ("DABL_NUM");
		HashMap<String, String> vip = null;
		synchronized (vipEquipPhoneList) {
			vip = (HashMap<String, String>)vipEquipPhoneList.get(equipId);
		}
		
		JSONObject fault = (JSONObject) faultList.get(dablNum+",VIP_EQUIP");
		//같은 타입 같은 장애인경우 처리하지않음
		if(fault != null ){
			return ;
		}
		if(vip!=null )		
		{
			String dablSetMsgCtt = vip.get("DABL_SET_MSG_CTT");
			String dablDesc = (String) json.get("DABL_DESC"); 
						
			StringTokenizer tokens = new StringTokenizer (dablSetMsgCtt, ",");
			
			while (tokens.hasMoreTokens ()) {
				String	token = tokens.nextToken ();
				//해당하는 장애가 존재함
				if(token.equals(dablDesc))
				{
					//deepCopy 
					JSONObject falut = new JSONObject();
					falut.putAll(json);
					falut.put("FAULT_TYPE", "VIP_EQUIP");
					falut.put("EQUIP_USG_CTT", vip.get("EQUIP_USG_CTT"));
					falut.put("EQUIP_TYP_CL_CD", vip.get("EQUIP_TYP_CL_CD"));
					falut.put("RCV_PHON_NUMS", vip.get("RCV_PHON_NUMS"));
					
					
					
					//장애리스트에 등록				
					faultList.put((String) json.get("DABL_NUM")+",VIP_EQUIP", falut);					
					
					logger.info("VIP_EQUIP "+ falut.toJSONString());
					//MQ에 등록하여 SEND처리 
					blockingQueue.add((JSONObject) falut);
					logger.info("faultList :: "+faultList.size());
				}		
				
			}
		}	
	}
	
	@SuppressWarnings("unchecked")
	public void processBiz (JSONObject json) {
				
	
		String dablNum = (String) json.get ("DABL_NUM");
		String equipId = (String) json.get("EQUIP_ID");
		String dablCd = (String) json.get("DABL_CD");
		
		List biz = null;
		synchronized (bizPhoneList) {
			biz = (List)bizPhoneList.get(equipId+","+dablCd);
		}
		
		JSONObject fault = (JSONObject) faultList.get(dablNum+",BIZ");
		//같은 타입 같은 장애인경우 처리하지않음
		if(fault != null ){
			return ;
		}
		if(biz!=null )		
		{
						
			//MQ에 등록하여 SEND처리 
			for(int i=0;biz.size()>i;i++)
			{
			
				HashMap<String, String> map = (HashMap<String, String>) biz.get(i);
				//deepCopy 
				JSONObject falut = new JSONObject();
				falut.putAll(json);
				falut.put("FAULT_TYPE", "BIZ");			
				//falut.put("RCV_PHON_NUMS", biz.get("RCV_PHON_NUMS"));
				falut.put("BIZ_LIST", biz);
																
				//장애리스트에 등록				
				faultList.put((String) json.get("DABL_NUM")+",BIZ", falut);	
				falut.put("RCV_PHON_NUMS", map.get("RCV_PHON_NUMS"));
				falut.put("SVC_MGMT_NUM", map.get("SVC_MGMT_NUM"));
				falut.put("CUST_NM", map.get("CUST_NM"));
				
				logger.info("BIZ "+ falut.toJSONString());
				
				blockingQueue.add((JSONObject) falut);
			}
			
			
			logger.info("faultList :: "+faultList.size());
			
		}	
	}
	
	@SuppressWarnings("unchecked")
	public void processBizCenter (JSONObject json) {
				
	
		String dablNum = (String) json.get ("DABL_NUM");
		String equipId = (String) json.get("EQUIP_ID");
		String dablCd = (String) json.get("DABL_CD");
		
		List biz = null;
		synchronized (bizCenterPhoneList) {
			biz = (List)bizCenterPhoneList.get(equipId+","+dablCd);
		}
		
		JSONObject fault = (JSONObject) faultList.get(dablNum+",BIZCENTER");
		//같은 타입 같은 장애인경우 처리하지않음
		if(fault != null ){
			return ;
		}
		if(biz!=null )		
		{
						
			//MQ에 등록하여 SEND처리 
			for(int i=0;biz.size()>i;i++)
			{
			
				HashMap<String, String> map = (HashMap<String, String>) biz.get(i);
				//deepCopy 
				JSONObject falut = new JSONObject();
				falut.putAll(json);
				falut.put("FAULT_TYPE", "BIZ_CENTER");			

				falut.put("BIZ_LIST", biz);
																
				//장애리스트에 등록				
				faultList.put((String) json.get("DABL_NUM")+",BIZCENTER", falut);	
				falut.put("RCV_PHON_NUMS", map.get("RCV_PHON_NUMS"));
				falut.put("SVC_MGMT_NUM", map.get("SVC_MGMT_NUM"));
				falut.put("CNT", map.get("CNT"));
				falut.put("CUST_CHRTIC_NM", map.get("CUST_CHRTIC_NM"));
				falut.put("TPO_NM", map.get("TPO_NM"));				
				
				logger.info("BIZ_CENTER "+ falut.toJSONString());
				
				blockingQueue.add((JSONObject) falut);
			}
			
			
			logger.info("faultList :: "+faultList.size());
			
		}	
	}
	
	public void processClear (JSONObject json) {		

		String 	dablNum = json.get ("DABL_NUM").toString ();
		JSONObject vipFalut = (JSONObject) faultList.get(dablNum+",VIP_CIRCUIT");
		JSONObject equipFalut = (JSONObject) faultList.get(dablNum+",FAULT_EQUIP");
		JSONObject circuitFalut = (JSONObject) faultList.get(dablNum+",FAULT_CIRCUIT");
		JSONObject bizFalut = (JSONObject) faultList.get(dablNum+",BIZ");
		JSONObject bizCenterFalut = (JSONObject) faultList.get(dablNum+",BIZCENTER");
			
		
		if(vipFalut != null){
			//deepCopy 
			JSONObject falut = new JSONObject();
			falut.putAll(json);
			
			falut.put("FAULT_TYPE", (String) vipFalut.get("FAULT_TYPE"));
			falut.put("OCCR_RCV_DTM", (String) vipFalut.get("OCCR_RCV_DTM"));
			falut.put("EQUIP_TYP_CL_CD", (String) vipFalut.get("EQUIP_TYP_CL_CD"));
			falut.put("SVC_MGMT_NUM", (String) vipFalut.get("SVC_MGMT_NUM"));
			falut.put("LINE_USG_CTT", (String) vipFalut.get("LINE_USG_CTT"));
			falut.put("DABL_DESC", (String) vipFalut.get("DABL_DESC"));
			falut.put("RCV_PHON_NUMS", vipFalut.get("RCV_PHON_NUMS"));
			falut.put("CUST_NM", (String)vipFalut.get("CUST_NM"));
			
			faultList.remove(dablNum+",VIP_CIRCUIT");
			blockingQueue.add((JSONObject) falut);
			
			
		}
		if(equipFalut != null ){
			//deepCopy 
			JSONObject falut = new JSONObject();
			falut.putAll(json);
			falut.put("FAULT_TYPE", (String) equipFalut.get("FAULT_TYPE"));
			falut.put("OCCR_RCV_DTM", (String) equipFalut.get("OCCR_RCV_DTM"));
			falut.put("EQUIP_NM", (String) equipFalut.get("EQUIP_NM"));
			falut.put("EQUIP_TID_VAL", (String) equipFalut.get("EQUIP_TID_VAL"));
			falut.put("DABL_NM", (String) equipFalut.get("DABL_NM"));
			falut.put("DABL_CD_NM", (String) equipFalut.get("DABL_CD_NM"));
			falut.put("DABL_DESC", (String) equipFalut.get("DABL_DESC"));
			falut.put("RCV_PHON_NUMS", equipFalut.get("RCV_PHON_NUMS"));
			faultList.remove(dablNum+",FAULT_EQUIP");
			blockingQueue.add((JSONObject) falut);
			
		}
		if(circuitFalut != null){
			//deepCopy 
			JSONObject falut = new JSONObject();
			falut.putAll(json);
			falut.put("FAULT_TYPE", (String) circuitFalut.get("FAULT_TYPE"));
			falut.put("OCCR_RCV_DTM", (String) circuitFalut.get("OCCR_RCV_DTM"));
			falut.put("CUST_NM", (String) circuitFalut.get("CUST_NM"));
			falut.put("CUST_NUM", (String) circuitFalut.get("CUST_NUM"));
			falut.put("EQUIP_NM", (String) circuitFalut.get("EQUIP_NM"));
			falut.put("LINE_NUM", (String) circuitFalut.get("LINE_NUM"));
			falut.put("LINE_NM", (String) circuitFalut.get("LINE_NM"));
			falut.put("DABL_NM", (String) circuitFalut.get("DABL_NM"));
			falut.put("DABL_DESC", (String) circuitFalut.get("DABL_DESC"));
			falut.put("RCV_PHON_NUMS", circuitFalut.get("RCV_PHON_NUMS"));
			faultList.remove(dablNum+",FAULT_CIRCUIT");
			blockingQueue.add((JSONObject) falut);
			
			
		}
		if(bizFalut != null){
			//deepCopy 
			
			List biz = (List) bizFalut.get("BIZ_LIST");
			logger.info("BIZ_LIST:"+biz.size());
			//MQ에 등록하여 SEND처리 
			for(int i=0;biz.size()>i;i++)
			{
				HashMap<String, Object> map = (HashMap<String, Object>) biz.get(i);
				JSONObject falut = new JSONObject();
				falut.putAll(json);
				
				falut.put("FAULT_TYPE", (String) bizFalut.get("FAULT_TYPE"));				
				falut.put("OCCR_RCV_DTM", (String) bizFalut.get("OCCR_RCV_DTM"));				
				falut.put("SVC_MGMT_NUM", (BigDecimal) map.get("SVC_MGMT_NUM"));				
				falut.put("DABL_DESC", (String) bizFalut.get("DABL_DESC"));
				falut.put("RCV_PHON_NUMS", map.get("RCV_PHON_NUMS"));
				falut.put("CUST_NM", (String)map.get("CUST_NM"));
				falut.put("NMS_NM", (String)bizFalut.get("NMS_NM"));
				falut.put("EQUIP_TID_VAL", (String)bizFalut.get("EQUIP_TID_VAL"));
				blockingQueue.add((JSONObject) falut);
			}
			
			
			//종료처리 
			faultList.remove(dablNum+",BIZ");
			logger.info("faultList :: "+faultList.size());
			
			
		}
		
		if(bizCenterFalut != null){
			//deepCopy 
			
			List biz = (List) bizCenterFalut.get("BIZ_LIST");
			logger.info("BIZ_LIST:"+biz.size());
			//MQ에 등록하여 SEND처리 
			for(int i=0;biz.size()>i;i++)
			{
				HashMap<String, Object> map = (HashMap<String, Object>) biz.get(i);
				JSONObject falut = new JSONObject();
				falut.putAll(json);
				
				falut.put("FAULT_TYPE", (String) bizCenterFalut.get("FAULT_TYPE"));				
				falut.put("OCCR_RCV_DTM", (String) bizCenterFalut.get("OCCR_RCV_DTM"));				
				falut.put("SVC_MGMT_NUM", (String) map.get("SVC_MGMT_NUM"));				
				falut.put("DABL_DESC", (String) bizCenterFalut.get("DABL_DESC"));
				falut.put("RCV_PHON_NUMS", map.get("RCV_PHON_NUMS"));				
				falut.put("NMS_NM", (String)bizCenterFalut.get("NMS_NM"));
				falut.put("CNT", (BigDecimal)map.get("CNT"));
				falut.put("CUST_CHRTIC_NM", (String)map.get("CUST_CHRTIC_NM"));
				falut.put("TPO_NM", (String)map.get("TPO_NM"));
				falut.put("EQUIP_TID_VAL", (String)bizCenterFalut.get("EQUIP_TID_VAL"));
				
				blockingQueue.add((JSONObject) falut);
			}
			
			
			//종료처리 
			faultList.remove(dablNum+",BIZCENTER");
			logger.info("faultList :: "+faultList.size());			
			
		}
					
	}
	public void clearFaultAfter7Day () throws java.text.ParseException {	
		
		
		int today;
		Date date = new Date();
		Set<Entry<String, Object>> entrySet = faultList.entrySet();
  	    Iterator<Entry<String, Object>> entryIterator = entrySet.iterator();

		while(entryIterator.hasNext()) {

		    Entry<String, Object> entry = entryIterator.next();
		    String key = entry.getKey();
		    JSONObject json = (JSONObject) entry.getValue();
		    String occrDtm = json.get("OCCR_DTM").toString().substring(0, 8);
		    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			Date occrDt = sdf.parse(occrDtm);
			long diff = occrDt.getTime() - date.getTime();
			long diffDays = Math.abs(diff / 0x5265c00L);
			
			if(diffDays >= 7 ){
				logger.info(String.format("remove Fault :: %s diffDay :: %s", key,diffDays+""));
				faultList.remove("key"); //이게 제대로 동작 하나..?
			}

	   }

	}
	
}

