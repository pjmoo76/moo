package com.skb.mi.realtime;

import java.sql.ResultSet;
import java.util.Hashtable;

import org.json.simple.JSONObject;

import com.skb.mi.common.DBController;
import com.skb.mi.vo.FaultVO;

import java.net.Socket;

import java.io.OutputStream;
import java.util.LinkedList;

public class SaveRealtimeFault {
	
	final	String	GENERATE_EVENT = "GEN";
	final	String	CLEAR_EVENT = "CLR";
	
	final	String	GENERATED_FAULT_NM = "장애중";
	final	String	CLEARED_FAULT_NM = "장애해제";
	
	final 	String	GENERATED_FAULT_CD = "01";
	final	String	CLEARED_FAULT_CD = "02";
	
	DBController	dbController;
	
	Socket			socket;
	OutputStream	outputStream;

	LinkedList<JSONObject>	notSendJson;

	public SaveRealtimeFault (DBController dbController) {
		this.dbController = dbController;
		notSendJson = new LinkedList<JSONObject> ();
		try {
			socket = new Socket ("12.4.96.92", 32771);
			outputStream = socket.getOutputStream ();
		} catch (Exception e) {
			System.out.println ("SaveRealtimeFault socket exception : " + e);
		}
	}
	
	public void processFaultGenerated (FaultVO faultVo) {
		String query = "";
		
//		System.out.println ("processFaultGenerated.............");
		faultVo.setDablStCd(GENERATED_FAULT_CD);
		try {
			// 
			query = queryEquipInfo (faultVo.getTid());
			ResultSet resultSet = dbController.getStmt ().executeQuery (query);
			faultVo.setDablDupYn ("N");
			if (resultSet.next ()) {
				faultVo.setEquipId (resultSet.getString (1));
				faultVo.setEquipNm (resultSet.getString (2));
				faultVo.setTpoNm (resultSet.getString (3));
				faultVo.setEquipIpAddress (resultSet.getString (4));
				faultVo.setEquipMdlCd (resultSet.getString (5));
				faultVo.setEquipMdlNm (resultSet.getString (6));
				faultVo.setEquipSetLocDesc (resultSet.getString (7));
				faultVo.setTpoCd (resultSet.getString (8));
				faultVo.setMgmtTpoNm (resultSet.getString (9));
				faultVo.setMgmtTpoCd (resultSet.getString (10));
				faultVo.setTeamNm (resultSet.getString (11));
				faultVo.setTeamId (resultSet.getString (12));
				faultVo.setDivNm (resultSet.getString (13));
				faultVo.setDivId (resultSet.getString (14));

                // 작업 여부 조회
                faultVo.setOperDablYn ("N");
                if (faultVo.getEquipId () != null
                 || faultVo.getEquipId ().equals ("")) {
                    query = queryEquipWorkYn (faultVo.getEquipId ());
                    if (resultSet.next ()) {
                        if (0 < resultSet.getInt (1))
                            faultVo.setOperDablYn ("Y");
                    }
                }
			} else {
				faultVo.setDivNm ("");
				faultVo.setDivId ("");
				faultVo.setTpoCd ("#");
				faultVo.setMgmtTpoCd ("#");
			}	
            // 중복 건수 구하기
            faultVo.setDablDupYn ("N");
            faultVo.setDablDupCnt ("1");
            if (faultVo.getEquipId () != null) {
                query = queryDupInfo (faultVo.getEquipId (), faultVo.getDablOccrLocDesc (), faultVo.getDablDesc ());
                resultSet = dbController.getStmt ().executeQuery (query);
                if (resultSet.next ()) {
                    faultVo.setDablDupCnt (resultSet.getString (1));
                    if (1 < resultSet.getInt (1))
                        faultVo.setDablDupYn ("Y");
                }
            }
            
			// OMN30100 
			query = queryEquipFault (faultVo);
			try {
				dbController.getStmt ().executeUpdate (query);
			} catch (Exception e) {
				try {
					dbController.getStmt ().executeUpdate (query);
				} catch (Exception ie) {
					System.out.println ("query : " + query);
					System.out.println ("processFaultGenerated : Exception : "  + ie);
				}
			}

			// OMN30100
			query = queryFaultNum (faultVo);	
			ResultSet rs = dbController.getStmt ().executeQuery (query);
			if (rs.next ()) {
				faultVo.setDablNum (rs.getString (1));
				faultVo.setOccrRcvDtm (rs.getString (2));
			} else {
				faultVo.setDablNum (faultVo.getNmsDablNumCtt ());
				faultVo.setOccrRcvDtm (faultVo.getOccrDtm());
			}
			
			// JSON
			makeJsonAndSend (faultVo, GENERATE_EVENT);
			
		} catch (Exception e) {
			System.out.println ("query : " + query);
			System.out.println ("processFaultGenerated : Exception : "  + e);
		}
	}
	
	public void processFaultCleared (FaultVO faultVo) {
		String query = "";
		
//		System.out.println ("processFaultCleared.............");
		faultVo.setDablStCd(CLEARED_FAULT_CD);
		try {
			query = queryFaultNum (faultVo);
			ResultSet rs = dbController.getStmt ().executeQuery (query);
			if (rs.next ()) {
				faultVo.setDablNum (rs.getString (1));
				faultVo.setOccrRcvDtm (rs.getString (2));
			} else {
				faultVo.setDablNum (faultVo.getNmsDablNumCtt ());
				faultVo.setOccrRcvDtm (faultVo.getOccrDtm());
			}
			
			// OMN30100
			query = queryFaultCleared (faultVo);	
			dbController.getStmt ().executeUpdate (query);

			// JSON
			makeJsonAndSend (faultVo, CLEAR_EVENT);
			
		} catch (Exception e) {
			System.out.println ("Query : " + query);
			System.out.println ("processFaultCleared : Exception : "  + e);
		}
	}
	
	// JSON 
	public void makeJsonAndSend (FaultVO faultVo, String faultStatus) {
		JSONObject	obj = new JSONObject ();
		if (faultStatus.equals (GENERATE_EVENT)) {
//			System.out.println ("DABL_LCL_CD : " + faultVo.getDablLclCd ());
//			System.out.println ("DABL_LCL_NM : " + faultVo.getDablLclNm ());
//			System.out.println ("DABL_MCL_CD : " + faultVo.getDablMclCd ());
//			System.out.println ("DABL_MCL_NM : " + faultVo.getDablMclNm ());
			obj.put ("DABL_LCL_CD", faultVo.getDablLclCd ());
			obj.put ("DABL_LCL_NM", faultVo.getDablLclNm ());
			obj.put ("DABL_MCL_CD", faultVo.getDablMclCd ());
			obj.put ("DABL_MCL_NM", faultVo.getDablMclNm ());
			obj.put ("DABL_CD", faultVo.getDablCd ());
			obj.put ("DABL_NM", faultVo.getDablNm ());
			obj.put ("DABL_ST_NM", GENERATED_FAULT_NM);
			obj.put ("OCCR_DTM", changeDateFormat (faultVo.getOccrDtm ()));
			obj.put ("OCCR_RCV_DTM", changeDateFormat (faultVo.getOccrRcvDtm ()));
			obj.put ("NMS_CD", faultVo.getNmsCd ());
			obj.put ("NMS_NM", faultVo.getNmsNm ());
			obj.put ("NMS_DABL_NUM_CTT", faultVo.getNmsDablNumCtt ());
			obj.put ("NET_CL_CD", faultVo.getNetClCd ());
			obj.put ("NET_CL_NM", faultVo.getNetClNm());
			obj.put ("DABL_GR_CD", faultVo.getDablGrCd ());
			obj.put ("MKT_DIV_ORG_ID", faultVo.getDivId ());
			obj.put ("MKT_DIV_ORG_NM", faultVo.getDivNm ());
			obj.put ("TEAM_ORG_ID", faultVo.getTeamId ());
			obj.put ("TEAM_ORG_NM", faultVo.getTeamNm ());
			obj.put ("INFO_CNTR_CD", faultVo.getMgmtTpoCd ());
			obj.put ("INFO_CNTR_NM", faultVo.getMgmtTpoNm ());
			obj.put ("DISTB_CNTR_CD", faultVo.getTpoCd ());
			obj.put ("DISTB_CNTR_NM", faultVo.getTpoNm ());
			obj.put ("EQUIP_IP_ADDR", faultVo.getEquipIpAddress ());
			obj.put ("EQUIP_ID", faultVo.getEquipId ());
			obj.put ("EQUIP_NM", faultVo.getEquipNm ());
			obj.put ("EQUIP_TID_VAL", faultVo.getTid ());
			obj.put ("EQUIP_MDL_CD", faultVo.getEquipMdlCd ());
			obj.put ("EQUIP_MDL_NM", faultVo.getEquipMdlNm ());
			obj.put ("DABL_DESC", faultVo.getDablDesc ());
			obj.put ("DABL_DUP_YN", faultVo.getDablDupYn ());
			if (faultVo.getDablLclCd ().equals ("01")) {		// 장비장애
				obj.put ("DABL_OCC_LOC_DESC", "");
				obj.put ("DABL_DUP_CNT", "1");
				obj.put ("DABL_DUP_CNT_1", "1" );
				obj.put ("DABL_DUP_CNT_2", "1" );
				obj.put ("DABL_DUP_CNT_3", "1" );
				obj.put ("OPER_DABL_YN", faultVo.getOperDablYn ());
				obj.put ("NET_OP_NUM", faultVo.getNoticeId ());
				obj.put ("EQUIP_SET_LOC_DESC", faultVo.getEquipSetLocDesc ());
				obj.put ("DMG_SCRBT_CNT", faultVo.getPingCnt());
				obj.put ("COLUMN_1", "");
				obj.put ("COLUMN_2", "");
				obj.put ("COLUMN_3", "");
				obj.put ("COLUMN_4", "");
				obj.put ("COLUMN_5", "");
				obj.put ("COLUMN_6", "");
				obj.put ("COLUMN_7", "");
				obj.put ("TM_TYP_CD", "");
				obj.put ("TM_CTT", "");
				obj.put ("INCOMM_BIZR_ID", "");
				obj.put ("COLUMN_8", "");
				obj.put ("COLUMN_9", "");
				obj.put ("MODULE_EQUIP_ID", "");
				obj.put ("MSC_MODULE_NM", "");
				obj.put ("COLUMN_10", "");
				obj.put ("ROUT_NUM", "");
				obj.put ("ROUT_NM", "");
				obj.put ("COLUMN_11", "");
				obj.put ("COLUMN_12", "");
				obj.put ("DSST_YN", "");
				obj.put ("DSSTR_YN", "");
			} else if (faultVo.getDablLclCd ().equals ("02")) {	// 회선장애
				obj.put ("DABL_OCC_LOC_DESC", "");
				obj.put ("DABL_DUP_CNT", "1");
				obj.put ("DABL_DUP_CNT_1", "1" );
				obj.put ("DABL_DUP_CNT_2", "1" );
				obj.put ("DABL_DUP_CNT_3", "1" );
				obj.put ("OPER_DABL_YN", faultVo.getOperDablYn ());
				obj.put ("NET_OP_NUM", faultVo.getNoticeId ());
				obj.put ("EQUIP_SET_LOC_DESC", faultVo.getEquipSetLocDesc ());
				obj.put ("DMG_SCRBT_CNT", faultVo.getPingCnt());
				obj.put ("U_ORG_ID", faultVo.getUOrgId ());
				obj.put ("U_ORG_NM", faultVo.getUOrgNm ());
				obj.put ("L_ORG_ID", faultVo.getLOrgId ());
				obj.put ("L_ORG_NM", faultVo.getLOrgNm ());
				obj.put ("COLUMN_13", "");
				obj.put ("COLUMN_14", "");
				obj.put ("CUST_NUM", faultVo.getCustNum ());
				obj.put ("COLUMN_15", "");
				obj.put ("LINE_NUM", faultVo.getLineNum ());
				obj.put ("RING_NUM", faultVo.getRingId ());
				obj.put ("RING_NM", faultVo.getRingNm ());
				obj.put ("COLUMN_16", "");
				obj.put ("COLUMN_17", "");
				obj.put ("COLUMN_18", "");
				obj.put ("COLUMN_19", "");
				obj.put ("COLUMN_20", "");
				obj.put ("COLUMN_21", "");
				obj.put ("COLUMN_22", "");
				obj.put ("DSSTR_YN", "");
			} else {											// 트래픽장애
				obj.put ("ASS_NUM", "");
				obj.put ("ROUT_NUM", "");
				obj.put ("ROUT_NM", "");
				obj.put ("INTERFACE_ID", "");
				obj.put ("INTERFACE_NM", "");
				obj.put ("TM_TYP_CD", "");
				obj.put ("TM_CTT", "");
				obj.put ("INCOMM_BIZR_ID", "");
				obj.put ("INCOMM_BIZR_NM", "");
			}
			obj.put ("kind", faultStatus);
		} else {
			obj.put ("RLSE_RCV_DTM", faultVo.getOccrDtm ());
			obj.put ("DABL_ST_NM", CLEARED_FAULT_NM);
			obj.put ("kind", faultStatus);
		}
		obj.put ("DABL_NUM", faultVo.getDablNum ());
		obj.put ("DABL_ST_CD", faultVo.getDablStCd());
//		System.out.println (obj.toJSONString());
		try {
			outputStream.write (obj.toJSONString ().getBytes ());
			outputStream.flush ();
		} catch (Exception e) {
			System.out.println ("============ " + e); 
			notSendJson.add (obj);
			sendJson ();
		}
	}

	public void sendJson () {
		JSONObject	obj;
		int	size = notSendJson.size ();
		System.out.println ("================ size : " + size);
		try {
			try {
				outputStream.close ();
			} catch (Exception e1) {
			}
			try {
				socket.close ();
			} catch (Exception e2) {
			}
			socket = new Socket (pushIpAddress, pushPortNo);
			outputStream = socket.getOutputStream ();
			for (int index = 0; index < size; ++ index) {	
				obj = notSendJson.get (0);
				outputStream.write (obj.toJSONString ().getBytes ());
				outputStream.flush ();
				System.out.println (obj.toJSONString ());
				notSendJson.remove (0);
				Thread.sleep (100);
			}
			outputStream.flush ();
		} catch (Exception e) {
			System.out.println ("======== sendJson ============ " + e); 
		}
	}
	
	public String queryFaultNum (FaultVO faultVo) {
		return "SELECT DABL_NUM, TO_CHAR(OCCR_RCV_DTM,'YYYYMMDDHH24MISS') FROM OMN30100 WHERE NMS_DABL_NUM_CTT='" + faultVo.getNmsDablNumCtt () + "' AND NMS_CD='" + faultVo.getNmsCd () + "'";
	}

	public String queryEquipFault (FaultVO faultVo) {
		return "MERGE INTO OMN30100 USING DUAL"
			 + " ON (NMS_DABL_NUM_CTT='" + faultVo.getNmsDablNumCtt () + "'"
			 + " 	 AND NMS_CD='" + faultVo.getNmsCd () + "')"
//			 + " WHEN MATCHED THEN ; "
			 + " WHEN NOT MATCHED THEN"
			 + "	INSERT ("
			 + "	      AUDIT_ID"
			 + "          , AUDIT_DTM"
			 + "          , DABL_NM"
			 + "          , NMS_CD"
			 + "		  , NET_CL_CD"
			 + "          , DABL_LCL_CD"
			 + "          , DABL_ST_CD"
			 + "          , DABL_GR_CD"
			 + "		  , DABL_RGST_CL_CD"
			 + "          , DABL_EXL_YN"
			 + "          , DABL_RLSE_MTHD_CD"
			 + "          , DABL_OP_ST_CD"
			 + "          , DABL_CHECK_YN"
			 + "          , INFO_CNTR_CD"
			 + "          , DISTB_CNTR_CD"
			 + "          , EMCY_DABL_YN"
			 + "          , EGOV_DABL_YN"
			 + "          , DSSTR_YN"
			 + "          , OFD_DABL_YN"
			 + "          , BBNT_DABL_YN"
			 + "          , OPER_DABL_YN"
			 + "		  , DABL_NET_CL_CD"
			 + "		  , DABL_NUM"
			 + "		  , NMS_DABL_NUM_CTT"
			 + "		  , OCCR_DTM"
			 + "		  , OCCR_RCV_DTM"
			 + "		  , EQUIP_ID"
			 + "		  , DABL_DESC"
			 + "		  , DABL_DUP_CNT"
			 + "		  , DABL_MCL_CD"
			 + "		  , DABL_CD"
			 + "	) VALUES ("
			 + "		  'admin'"
			 + "		  ,SYSDATE"
			 + "		  ,'" + faultVo.getDablNm () + "'"
			 + "		  ,'" + faultVo.getNmsCd () + "'"
			 + "		  ,'" + faultVo.getNetClCd () + "'"
			 + "		  ,'" + faultVo.getDablLclCd () + "'"
			 + "          ,'" + faultVo.getDablStCd() + "'"
			 + "          ,'" + faultVo.getDablGrCd () + "'"
			 + "          ,'  '"
			 + "          ,'N'"
			 + "          ,'N'"
			 + "          ,'01'"
			 + "          ,'N'"
			 + "          ,'" + faultVo.getMgmtTpoCd () + "'"
			 + "          ,'" + faultVo.getTpoCd () + "'"
			 + "          ,'N'"
			 + "          ,'N'"
			 + "          ,'N'"
			 + "          ,'N'"
			 + "          ,'N'"
			 + "          ,'" + faultVo.getOperDablYn () + "'"
			 + "          ,'" + faultVo.getDablNetClCd () + "'"
			 + "		  ,(SELECT MAX(DABL_NUM) + 1 FROM OMN30100)"
			 + "		  ,'" + faultVo.getNmsDablNumCtt () + "'"
			 + "		  ,'" + faultVo.getOccrDtm () + "'"
			 + "		  ,SYSDATE"
			 + "		  ,'" + faultVo.getEquipId () + "'"
			 + "		  ,'" + faultVo.getDablDesc () + "'"
			 + "		  ,1"
			 + "		  ,'" + faultVo.getDablMclCd () + "'"
			 + "		  ,'" + faultVo.getDablCd () + "'"
			 + "	)";
	}
	
	public String queryFaultCleared (FaultVO faultVo) {
		return "UPDATE"
			 + " OMN30100 SET"
			 + " DABL_ST_CD='" + faultVo.getDablStCd() + "'"
			 + " , RLSE_DTM='" + faultVo.getOccrDtm () + "'"
			 + " , RLSE_RCV_DTM=SYSDATE"
			 + " , KEEP_TMS=24*60*60*(SYSDATE-TO_DATE('" + faultVo.getOccrRcvDtm ()+ "','YYYYMMDDHH24MISS'))"
			 + " , DABL_RLSE_MTHD_CD='A'"
			 + " WHERE NMS_DABL_NUM_CTT='" + faultVo.getNmsDablNumCtt () + "'"
			 + " 	 AND NMS_CD='" + faultVo.getNmsCd () + "'";
	}
	
	public String queryFaultCode (String dablNm) {
		return "SELECT" 
			 + " DABL_LCL_CD"
			 + ", DABL_LCL_NM"
			 + ", DABL_MCL_CD"
			 + ", DABL_MC_NM"
			 + ", DABL_NM"
			 + " FROM OMN30203" 
			 + " WHERE DABL_CD='" + dablNm + "'";
	}


	public String queryEquipInfo (String tid) {
		return  "SELECT "
			  + "	a.EQUIP_ID"
			  + "	,a.EQUIP_NM"
			  + "	,a.TPO_NM"
			  + "	,a.EQUIP_IP_ADDR"
			  + "	,a.EQUIP_MDL_CD"
			  + "	,a.EQUIP_MDL_NM"
		      + "   ,a.EQUIP_SET_LOC_DESC"
			  + "	,a.TPO_CD"
			  + "	,b.TPO_NM AS MGMT_TPO_NM"
			  + "	,b.TPO_CD AS MGMT_TPO_CD"
			  + "	,c.TEAM_ORG_NM AS TEAM_NM"
			  + "	,c.TEAM_ORG_ID AS TEAM_ID"
			  + "	,c.MKT_DIV_ORG_NM AS DIV_NM"
			  + "	,c.MKT_DIV_ORG_ID AS DIV_ID"
			  + " FROM ("
			  + "	SELECT "
			  + "		a.EQUIP_ID"
			  + "		,a.EQUIP_NM"
			  + "		,a.EQUIP_IP_ADDR"
			  + "		,a.EQUIP_MDL_CD"
		      + "       ,a.EQUIP_SET_LOC_DESC"
			  + "		,c.EQUIP_MDL_NM"
			  + "		,b.TPO_CD"
		      + "		,b.TPO_NM"
			  + "		,b.MGMT_TPO_CD" 
			  + " 	FROM OIV10100 a,OIV10300 b,OIV10200 c"
			  + " 	WHERE a.TPO_CD=b.TPO_CD(+) "
			  + "		AND a.EQUIP_MDL_CD=c.EQUIP_MDL_CD"
			  + " 		AND a.EQUIP_TID_VAL='" + tid + "') a"
			  + "			, OIV10300 b, OIV10301 c, OES20100 d "
			  + "WHERE a.MGMT_TPO_CD=b.TPO_CD(+) "
			  + "	AND b.TPO_CD=c.TPO_CD(+)"
			  + " 	AND c.TEAM_ORG_ID=d.ORG_ID(+)";
	}

    public String queryEquipWorkYn (String equipId) {
        return "SELECT "
/**
             + "  a.net_op_num"
             + " ,a.oper_ctt"
             + " ,b.equip_id"
             + " ,a.oper_sta_dtm"
             + " ,a.oper_fnsh_dtm"
 **/
             + " COUNT(*)"
             + "FROM onm10100 a, onm10101 b"
             + "WHERE a.net_op_num = b.net_op_num"
             + "AND b.equip_id='" + equipId + "'"
             + "AND sysdate BETWEEN a.oper_sta_dtm AND a.oper_fnsh_dtm";
    }

    // 오늘 중복 건수 구하는 쿼리
    public String queryDupInfo (String equipId, String dablOccrLocDesc, String dablDesc) {
        String  query = "SELECT "
             + "    count(*) "
             + "FROM OMN30100 "
             + "WHERE TO_CHAR(SYSDATE, 'YYYYMMDD') = SUBSTR (OCCR_DTM, 1, 8)"
             + "      AND EQUIP_ID = '" + equipId + "' ";
        if (dablOccrLocDesc != null)
             query += "   AND DABL_OCCR_LOC_DESC = '" + dablOccrLocDesc + "' ";
        if (dablDesc != null)
             query += "   AND DABL_DESC = '" + dablDesc + "' ";
        query += "GROUP BY EQUIP_ID";
        return query;
    }
 
    // date format : YYYYMMDDHHMMDD
    public String changeDateFormat (String date) {
        String  year = date.substring (0, 4);
        String  month = date.substring (4, 6);
        String  day = date.substring (6, 8);
        String  hour = date.substring (8, 10);
        String  minute = date.substring (10, 12);
        String  second = date.substring (12, 14);

        return hour + ":" + minute + ":" + second + " "
            + month + "/" + day + "/" + year;
    }
}
