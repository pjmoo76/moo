package com.skb.mi.realtime;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;

import com.skb.mi.common.DBController;
import com.skb.mi.common.OutputLog;
import com.skb.mi.thread.KeepAliveUnmsVoipTraffic;

import org.json.simple.JSONObject;
import java.util.Calendar;

public class RealTimeCollectUnmsVoipTraffic {
	
	final private int 			BUFFER_SIZE = 16384 * 3;
	final private int 			ESC = 0x1b;
	final private int 			STX = 0x02;
	final private byte 			ETX = 0x03;
	final private byte 			IDENTIFIER = 0x1f;
	final private byte			NULL = 0x00;	

	final private String		PNMS_NMS_CD 		= "002";	// OCO20101 테이블에 있음.
	final private String		PNMS_NMS_NM 		= "PNMS";

	final private String		VOIP_NMS_CD 		= "007";	// OCO20101 테이블에 있음.
	final private String		VOIP_NMS_NM 		= "VOIP(AGW)";

	final private String		NET_CL_CD 			= "01";		// 교환망 또는 VOIP
	final private String		NET_CL_NM 			= "교환망";	// 교환망

	final private String 		EQUIP_FAULT 		= "01";		// 01: 장비 장애
	final private String 		TRAFFIC_FAULT 		= "03"; 	// 03: 트래픽 장애

    final private String        GENERATE_EVENT      = "GEN";
    final private String        CLEAR_EVENT         = "CLR";

    final private String        GENERATED_FAULT_NM  = "장애중";
    final private String        CLEARED_FAULT_NM    = "장애해제";

    final private String        GENERATED_FAULT_CD  = "01";
    final private String        CLEARED_FAULT_CD    = "02";
    
    final private int			SO_TIME_OUT	= (1000*60*5);	// Time-Out 5분 설정

	String						equipIpAddress;
	int							equipPortNo;

	DBController				dbController;
	String						dbUrl, userName, password;

	byte []						buffer;
	int							bufferFront, bufferRear;
	int							maxColumn;

	// UNMS Equip 실시간 장애 수집
	Socket						equipSocket;
	InputStream					equipInputStream;
	OutputStream				equipOutputStream;

	// Push Process 정보
    Socket                      pushSocket;
    InputStream                 pushInputStream;
    OutputStream                pushOutputStream;
    String                      pushIpAddress;
    int                         pushPortNo;

	Hashtable<String,String>	alarmColumn;	

    LinkedList<JSONObject>      notSendJson;
    JSONObject                  jsonObject;

	String						pgmId;
	String						absolutePath;

	OutputLog					outputLog;
    KeepAliveUnmsVoipTraffic    keepAliveUnmsVoipTraffic;

	PreparedStatement			preparedStatement20301;
	PreparedStatement			preparedStatement20305;
    String []                   pstnMapping;

    String                      query20301, query20305;
    String                      tpoCd, equipId;
    String						mntrDt, mntrDtm;
	String						equipSysNm;

    public RealTimeCollectUnmsVoipTraffic (String[] args) {
		absolutePath = args [0];

		try {
			outputLog = new OutputLog (true, this.getClass ().getName (), absolutePath);
			outputLog.write ("Start !!!");
			readUnmsEquipInfo ();
			readPushInfo ();
//            readPstnMapping ();
		} catch (Exception e ) {
			System.out.println ("ReadUNMSInfo Error : " + e);
			System.exit (0);
		}

		notSendJson = new LinkedList<JSONObject> ();
		alarmColumn = new Hashtable<String,String> ();

        try {
            readDbInfo ();
            dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
			preparedStatement20301 = dbController.getConnection ().prepareStatement (queryStatement (20301));
			preparedStatement20305 = dbController.getConnection ().prepareStatement (queryStatement (20305));
/**
            InetAddress local = InetAddress.getLocalHost ();
            String  ip = local.getHostAddress ();
            ResultSet resultSet = dbController.selectProgramInfo (this.getClass().getName (), ip);

            if (resultSet.next ()) {
                pgmId = resultSet.getString (1);
                String  pgmUseYn = resultSet.getString (2);
                String  pgmStCd = resultSet.getString (3);

                outputLog.write ("pgmId : " + pgmId + ", pgmUseYn : " + pgmUseYn + ", pgmStCd : " + pgmStCd);
                // 프로세스 Use Y/N 검사
                if (pgmUseYn.equals ("N"))
                    exitProcess (false, "");
                // 프로세스 동작중인지 검사
                if (pgmStCd.equals ("S"))       // 동작중이면 바로 종료
                    exitProcess (false, "");
                else                            // 동작이 종료되어 있는 경우
                    dbController.insertProcessHistory(pgmId, "프로세스가 시작되었습니다", "S", "Y");
                    outputLog.write ("프로세스가 시작되었습니다.");
            } else {
                dbController.insertProcessHistory(pgmId, "프로세스가 시작되었습니다", "S", "Y");
                exitProcess (true, "프로세스를 찾을 수 없습니다.");
            }
			resultSet.close ();
*/
        } catch (Exception e ) {
            exitProcess (true, "DB 정보를 읽는 도중에 에러발생되었습니다.");
        }

        try {
			buffer = new byte [BUFFER_SIZE];
			bufferFront = bufferRear = 0;

			equipInputStream = null;
			equipOutputStream = null;

			connectNms ();

/*
            pushSocket = new Socket (pushIpAddress, pushPortNo);
            pushOutputStream = pushSocket.getOutputStream ();
*/

/**
            outputLog.write ("new KeepAliveUnmsTraffic");

            keepAliveUnmsVoipTraffic = new KeepAliveUnmsVoipTraffic (equipOutputStream, this);
            keepAliveUnmsVoipTraffic.start ();
**/

			realTimeCollect ();
            
            equipOutputStream.close ();
            equipInputStream.close ();
            equipSocket.close ();
            
			dbController.closeDB ();
        } catch (Exception e) {
            exitProcess (true, "Socket Open Error ");
        }
		exitProcess (true, "Finish.");
    }

    public void exitProcess (boolean check, String clctRsltCtt) {
        if (check) {
            try {
                dbController.insertProcessHistory(pgmId, clctRsltCtt, "F", "Y");
            } catch (Exception e) {
                outputLog.write ("exitProcess () Exception : " + e);
            }
        }
        outputLog.write (clctRsltCtt);
        outputLog.close ();
        try {
            equipOutputStream.close ();
            equipInputStream.close ();
            equipSocket.close ();
			pushInputStream.close ();
			pushOutputStream.close ();
			pushSocket.close ();
        } catch (Exception e) {
        }
        dbController.closeDB ();
        outputLog.write ("Finish.");
        System.exit (0);
    }

	public void connectNms () {
        boolean check = false;
        while (!check) {
            try {
                equipSocket = new Socket (equipIpAddress, equipPortNo);
                equipInputStream = equipSocket.getInputStream();
                equipOutputStream = equipSocket.getOutputStream ();
                bufferFront = bufferRear = 0;
                equipSocket.setSoTimeout(SO_TIME_OUT);
                
				sendRequestPort ();
				sendLoginPacket ();

                check = true;
            } catch (Exception e) {
				outputLog.write ("equipIpAddress : " + equipIpAddress + ", equipPortNo : " + equipPortNo);
                outputLog.write ("[" + getDateSecond () + "] connectNms ():Socket Open Error : " + e);
                sleep (10000);            // 0.1초
            }
        }
	}

	public void readDbInfo () throws Exception {
		String	oneLine;
		FileReader	fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + "db.info");
		BufferedReader bufferedReader = new BufferedReader (fileReader);
		dbUrl = bufferedReader.readLine ();
		userName = bufferedReader.readLine ();
		password = bufferedReader.readLine ();
		bufferedReader.close ();
		fileReader.close ();
//		System.out.println ("Url : " + dbUrl);
//		System.out.println ("userName : " + userName);
//		System.out.println ("password : " + password);
	}

	public void readUnmsEquipInfo () throws Exception {
		String	oneLine;
		FileReader	fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + "equipFault.info");
		BufferedReader bufferedReader = new BufferedReader (fileReader);
		equipIpAddress = bufferedReader.readLine ();
		equipPortNo = Integer.parseInt (bufferedReader.readLine ());	
		bufferedReader.close ();
		fileReader.close ();
	}

    // Push Processor IP Address와 포트 정보 조회
    public void readPushInfo () throws Exception {
        FileReader  fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + "push.info");
        BufferedReader bufferedReader = new BufferedReader (fileReader);
        pushIpAddress = bufferedReader.readLine ();
        pushPortNo = Integer.parseInt (bufferedReader.readLine ());
        bufferedReader.close ();
        fileReader.close ();
    }

    // VOIP Mapping 정보 조회
    public void readPstnMapping () throws Exception {
        FileReader  fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + "pstnMapping.info");
        BufferedReader bufferedReader = new BufferedReader (fileReader);
        String oneLine;
        int total = Integer.parseInt (bufferedReader.readLine ().trim ());
        query20301 = "MERGE INTO OMN20301 USING DUAL "
                   + " ON (DATA_SRC_CL_CD=? AND MNTR_CYCL_CD=? AND EQUIP_ID=? AND ROUT_NUM_CTT=?)";
        query20305 = "MERGE INTO OMN20305 USING DUAL "
                   + " ON (DATA_SRC_CL_CD=? AND MNTR_CYCL_CD=? AND EQUIP_ID=? AND ROUT_NUM_CTT=? AND MNTR_DTM=?)";
        String whenMatched, whenNotMatched, values20301, values20305;
        whenMatched = " WHEN MATCHED THEN UPDATE SET"
                    + "  AUDIT_ID='adams'"
                    + ", AUDIT_DTM=SYSDATE"
                    + ", EXCHG_EQUIP_CL_CD='P'";
        whenNotMatched = " WHEN NOT MATCHED THEN INSERT("
                       + "  AUDIT_ID"
                       + ", AUDIT_DTM"
                       + ", EXCHG_EQUIP_CL_CD";
        values20301 = ") VALUES ("
               + "  'adams'"
               + ", SYSDATE"
               + ", 'P'";
        values20305 = ") VALUES ("
               + "  'adams'"
               + ", SYSDATE"
               + ", 'P'";

        pstnMapping = new String [total + 1];
        for (int index = 1; index <= total; ++ index) {
             oneLine = bufferedReader.readLine ();
             if (oneLine.equals ("null"))
                  pstnMapping [index] = null;
             else {
                  pstnMapping [index] = oneLine;
                  if (5 < index)
					  whenMatched += ", " + oneLine + "=?";
                  whenNotMatched += ", " + oneLine;
                  values20301 += ", ?";
                  values20305 += ", ?";
             }
        }
        whenMatched += ", MNTR_DTM=?";
        whenNotMatched += ", MNTR_DTM";
        whenNotMatched += ", MNTR_NUM";
        values20301 += ", ?";
        values20305 += ", ?";
        values20301 += ", ?)";
        values20305 += ", ?)";
        query20301 += whenMatched + whenNotMatched + values20301;
        query20305 += whenMatched + whenNotMatched + values20305;
		outputLog.write ("20301 : " + query20305);
		outputLog.write ("20305 : " + query20305);
        bufferedReader.close ();
        fileReader.close ();
    }

	public void write (String message) {
		outputLog.write (message);
	}

    public void realTimeCollect () {
		int		index, messageLength, messageOrder, maxColumn, psIndex, intValue;
		float	floatValue;
		byte	oneByte;
		byte []	tempBytes;
		Date	date = new Date ();
		String	token, nmsType, serviceCode;
    	while (true) {
            psIndex = 1;
			jsonObject = new JSONObject ();
			try {

				/* ESC 검사 */
/*
				if (getOneByte () != ESC)
					continue;
*/

				/* STX 검사 */
				if (getOneByte () != STX)
					continue;
			
				/* PDU 종류 검사 */
				oneByte = getOneByte ();
				if (oneByte != '1'
				 && oneByte != '2'
				 && oneByte != '3'){	/* '1'은 Event, '2'는 Request, '3'은 Response */
					continue;
				}
			
				/* 서비스 코드 검사 */
				tempBytes = getBytes (4);
				if (tempBytes == null)
					continue;
				serviceCode = new String (tempBytes);
				outputLog.write ("Service Code : " + serviceCode);

				tempBytes = null;
			
				/* 메시지 일련번호 검사 */
				tempBytes = getBytes (2);
				if (tempBytes == null)
					continue;
				messageOrder = Integer.parseInt (new String (tempBytes));
				tempBytes = null;
			
				getOneByte ();		/* 마지막 메시지 검사는 Skip */
			
				/* 응답 결과 검사  */
				oneByte = getOneByte ();
				if (oneByte != '0' && oneByte != '1')
					continue;

				tempBytes = getBytes (4);		/* 확장 영역 Skip */
				tempBytes = null;
			
				/* 메시지 데이터 길이 */
				tempBytes = getBytes (5);
				messageLength = Integer.parseInt(new String (tempBytes));
				tempBytes = null;
			
				byte [] temp = new byte [messageLength];
				int tempIndex = 0;
				int	columnCount = 1;
				String	tempString;
//				outputLog.write (">>> messageLength : " + messageLength);
				for (index = 0; index < messageLength; ++ index) {
					byte ch = getOneByte ();
					if (ch == ESC)
						break;
					if (ch == IDENTIFIER) {
						tempString = new String (temp, 0, tempIndex, "EUC-KR");
//						System.out.println ("Field" + columnCount + ", value : " + tempString);
						tempIndex = 0;
						if (columnCount == 2) {
                            if (tempString.equals ("l"))
                                tempString = "L";
                            else if (tempString.equals ("c"))
                                tempString = "C";
                            else 
                                tempString = "";
						} else if (columnCount == 3) {		// E_PERIOD
							if (tempString.equals ("5"))
								tempString = "02";
                        } else if (columnCount == 4) {      // NE_ID
                            selectEquipId (tempString);
//                            selectTpoCd (equipId);
						} else if (columnCount == 24) {		// E_EVENT_DATE_ZONE
							date = getUnixTime (tempString);
							mntrDtm = getTime (date);
							mntrDt = getDate (date);
                        }
						alarmColumn.put ("Field" + columnCount, tempString);
						++ columnCount;
					}
					else
						temp [tempIndex ++] = ch;
				}
 
				if (!alarmColumn.get ("Field3").equals ("02"))
					continue;
				outputLog.write ("mntrDtm : " + mntrDtm + ", mntrDt : " + mntrDt);
				assignValue ();

                if (bufferFront == bufferRear || bufferRear == -1) {
                    outputLog.write ("---------- executeBatch");
                    preparedStatement20301.executeBatch ();
                    outputLog.write ("---------- executeBatch20301");
                    preparedStatement20305.executeBatch ();
                    outputLog.write ("---------- executeBatch20305");
					outputLog.write ("mntrDtm : " + mntrDtm + ", mntrDt : " + mntrDt);
                }


/*
				try {
					pushOutputStream.write (makeSendBuffer (jsonObject.toString ().getBytes ()));
					pushOutputStream.flush ();
				} catch (Exception e) {
					outputLog.write ("============ " + e);
					notSendJson.add (jsonObject);
					sendJson ();
				}
*/
			} catch (Exception e) {
				outputLog.write ("---------------------------------------");
				for (index = 1; index < 51; ++ index)
					outputLog.write ("Field" + index + " : " + alarmColumn.get ("Field" + index));
				outputLog.write ("---------------------------------------");
				outputLog.write ("realTimeCollect Error : " + e);
			}
			alarmColumn.clear ();
            mntrDt = mntrDtm = "";
		}
    }

    public void sendJson () {
        JSONObject  obj;
        int size = notSendJson.size ();
        outputLog.write ("Push 프로세스에게 전달할 JSON크기 : " + size);
        try {
            try {
                pushOutputStream.close ();
            } catch (Exception e1) {
            }
            try {
                pushSocket.close ();
            } catch (Exception e2) {
            }
            pushSocket = new Socket (pushIpAddress, pushPortNo);
            pushOutputStream = pushSocket.getOutputStream ();
            for (int index = 0; index < size; ++ index) {
                obj = notSendJson.get (0);
				pushOutputStream.write (makeSendBuffer (obj.toString ().getBytes ()));
                pushOutputStream.flush ();
                System.out.println (obj.toJSONString ());
                notSendJson.remove (0);
                Thread.sleep (100);
            }
            pushOutputStream.flush ();
        } catch (Exception e) {
            outputLog.write ("Push 프로세스와 연결이 끊겼습니다.");
        }
    }

    public byte[] makeSendBuffer (byte [] temp) {
        byte [] sendBuffer = new byte [temp.length + 1];
        int index = 0;
        for (; index < temp.length; ++ index)
            sendBuffer [index] = temp [index];
        sendBuffer [index] = ETX;
        return sendBuffer;
    }

	public byte getOneByte () {
        while (true) {
            try {
                if (bufferFront == bufferRear) {
                    bufferFront = 0;
                    bufferRear = equipInputStream.read (buffer);
//					printHexaCode (bufferRear, buffer);
                }
                if (bufferRear != -1) {
					return buffer [bufferFront ++];
				} else {
                    outputLog.write ("getOneByte () Else : " + bufferFront);
                    equipInputStream.close ();
                    equipOutputStream.close ();
                    equipSocket.close ();
                    connectNms ();
				}
            } catch (Exception e) {
                try {
                    outputLog.write ("getOneByte () Exception'catch " + e);
                    equipInputStream.close ();
                    equipOutputStream.close ();
                    equipSocket.close ();
                    connectNms ();

                    outputLog.write ("---------- executeBatch");
                    preparedStatement20301.executeBatch ();
                    outputLog.write ("---------- executeBatch20301");
                    preparedStatement20305.executeBatch ();
                    outputLog.write ("---------- executeBatch20305");

                } catch (Exception ee) {
                    outputLog.write ("getOneByte () Catch Exception : " + ee);
                }
            }
        }
	}

	public byte [] getBytes (int number) {
		byte [] bytes = new byte [number];
		byte temp;
		for (int index = 0; index < number; ++ index) {
			temp = getOneByte ();
			if (temp == -1)
				return null;	
			bytes [index] = temp;
		}
		return bytes;
	}

	public String getBytes () {
		byte [] bytes = new byte [BUFFER_SIZE];
		byte temp;
		int	index;
		for (index = 0; ; ++ index) {
			temp = getOneByte ();
			if (temp == -1)
				return null;	
			if (temp == IDENTIFIER)
				break;
			if (temp == ESC)
				break;
			bytes [index] = temp;
		}
		try {
			return new String (bytes, 0, index, "EUC-KR");
		} catch (Exception e) {
			outputLog.write ("getBytes : new String : Exception : " + e);
			return null;
		}
	}

	public String getDateSecond () {
		Calendar	calendar = Calendar.getInstance ();

		return String.format ("%04d-%02d-%02d %02d:%02d:%02d",
			calendar.get(Calendar.YEAR),
			calendar.get(Calendar.MONTH) + 1,
			calendar.get(Calendar.DAY_OF_MONTH),
			calendar.get(Calendar.HOUR_OF_DAY),
			calendar.get(Calendar.MINUTE),
			calendar.get(Calendar.SECOND));
	}

    public void printHexaCode (int length, byte[] buffer) {
		int count = 0;
		outputLog.write ("length : " + length + " ------------------");
		String	tmp = "";
    	for (int index = 0; index < length; ++ index) {
/*
			if (buffer [index] == ESC)
				outputLog.write ("\n");
*/
			if (count++ % 20 == 0) {
				outputLog.write (tmp + "\n");
				tmp = "";
			}
			tmp += String.format ("%02x.", buffer [index]);
		}
		outputLog.write (tmp + "\n");

		try {
			outputLog.write (new String (buffer, 0, length, "EUC-KR"));
		} catch (Exception e) {
			System.out.println ("printHexaCode : new String : Exception : " + e);
		}
    }
    
	public void sendLoginPacket () {
		int		count = 0;
		byte [] headerPacket = {0x1b
							  , 0x02
							  , 0x32
							  , 0x30, 0x34, 0x30, 0x30
							  , 0x39, 0x39
							  , 0x30
							  , 0x31
							  , 0x30, 0x30, 0x30, 0x30
							  , 0x30, 0x30, 0x31, 0x33, 0x39
		};
		byte [] bodyPacket;
		String	login =    "daims_test";
//		String	login = "NmsConnect";
		// password : qwer1234!@
		String	password = "5fbbbd91ecb1cbe2a726b1f53b8fd51b9becfa9e0a4758f21948a363714fc57c1342abdd9300ba51e49c2f1870ed864814275a4085b63d1302adaf2939954d0c";


		// BodyPacket : login + 0x1f + login + 0x1f + 0x20 + 0x1f + 0x31 + 0x30;
		byte [] loginPacket;
		byte [] sendPacket = new byte [159];
		byte [] recvPacket = new byte [100];

		outputLog.write ("[" + getDateSecond () + "] Send Login/Password --------------------");
		int		index = 0;

		loginPacket = login.getBytes ();	

		// HeaderPacket 복사
		for (; index < headerPacket.length; ++ index)
			sendPacket [index] = headerPacket [index];

		// login 복사
		for (int i = 0; i < loginPacket.length; ++ i)
			sendPacket [index ++] = loginPacket [i];
		sendPacket [index ++] = IDENTIFIER; 

		loginPacket = password.getBytes ();
		// password 복사
		for (int i = 0; i < loginPacket.length; ++ i)
			sendPacket [index ++] = loginPacket [i];

/**
		sendPacket [index ++] = IDENTIFIER; 

		// Black 및 '10'복사
		sendPacket [index ++] = (byte) 0x31;			// 모든 장애 표시
		sendPacket [index ++] = IDENTIFIER;

		sendPacket [index ++] = 0x31;					// '1'
		sendPacket [index ++] = 0x30;					// '0'
**/
		printHexaCode (sendPacket.length, sendPacket);
		try {
			equipOutputStream.write (sendPacket);
			count = equipInputStream.read (recvPacket);
		} catch (Exception e) {
			outputLog.write ("sendLoginPacket Error : " + e);
		}
		printHexaCode (count, recvPacket);
	}
	
	public void sendRequestPort () {
		int		count;
		byte [] headerPacket = {0x1b						// ESC
								, 0x02						// STX
								, 0x32						// Request	
								, 0x30, 0x33, 0x30, 0x32	// PDU_SVCD_TRAFFIC_PORT(302)
								, 0x39, 0x39				// Don't care
								, 0x30						// 마지막 응답 메시지
						  		, 0x31						// Success
								, 0x30, 0x30, 0x32, 0x31 	// Don't care
								, 0x30, 0x30, 0x30, 0x31, 0x30
		};
		byte [] bodyPacket;
		String	login = "daims_test";
//		String	login = "NmsConnect";
		String	port;

		// BodyPacket : login
		byte [] loginPacket;
		byte [] sendPacket = new byte [30];
		byte [] recvPacket = new byte [100];

		outputLog.write ("[" + getDateSecond () + "] Send Request Port --------------------");
		int		index = 0;

		loginPacket = login.getBytes ();	

		// HeaderPacket 복사
		for (; index < headerPacket.length; ++ index)
			sendPacket [index] = headerPacket [index];

		// login 복사
		for (int i = 0; i < loginPacket.length; ++ i)
			sendPacket [index ++] = loginPacket [i];

		try {
			equipOutputStream.write (sendPacket);
//			printHexaCode (count, recvPacket);
			count = equipInputStream.read (recvPacket);
			printHexaCode (count, recvPacket);
			
			port = new String (recvPacket, 20, 4);	
			equipOutputStream.close ();
			equipInputStream.close ();
			equipSocket.close ();

			outputLog.write ("ipAddress : " + equipIpAddress + ".....");
			outputLog.write ("port : " + port + ".....");

			equipSocket = new Socket (equipIpAddress, Integer.parseInt (port));
			equipInputStream = equipSocket.getInputStream ();
			equipOutputStream = equipSocket.getOutputStream ();
		} catch (Exception e) {
			outputLog.write ("sendRequestPacket Error : " + e);
		}
//		printHexaCode (sendPacket.length, sendPacket);
	}

    public void selectEquipId (String neId) {
		String query = "SELECT A.EQUIP_ID, B.EQUIP_SYS_NM, B.TPO_CD FROM "
					 + " (SELECT EQUIP_ID FROM OIV10107 WHERE CLCT_NMS_CL_CD='007' AND CLCT_EQUIP_NUM='" + neId + "') A, OIV10100 B"
					 + " WHERE A.EQUIP_ID=B.EQUIP_ID";
		tpoCd = "*";
		equipSysNm = "";
        try {
            ResultSet resultSet = dbController.getStmt ().executeQuery (query);
            if (resultSet.next ()) {
                equipId = resultSet.getString (1);
                equipSysNm = resultSet.getString (2);
                tpoCd = resultSet.getString (3);
				outputLog.write ("equipId : " + equipId + ", equipSysNm : " + equipSysNm + ", tpoCd : " + tpoCd);
            } else
				equipId = neId;
            resultSet.close ();
        } catch (Exception e) {
            outputLog.write ("selectTpoCd'Exception : " + e);
        }
    }

    public int select20301 () {
        int returnVal = -1;
        try {
            ResultSet resultSet = dbController.getStmt ().executeQuery ("SELECT OMN20301_S1.nextval FROM DUAL");
            if (resultSet.next ())
                 returnVal = resultSet.getInt (1);
            resultSet.close ();
        } catch (Exception e) {
            outputLog.write ("select20301'Exception : " + e);
        }
        outputLog.write ("select20301 : " + returnVal);
        return returnVal;
    }

    public int select20305 () {
        int returnVal = -1;
        try {
            ResultSet resultSet = dbController.getStmt ().executeQuery ("SELECT OMN20305_S1.nextval FROM DUAL");
            if (resultSet.next ())
                 returnVal = resultSet.getInt (1);
            resultSet.close ();
        } catch (Exception e) {
            outputLog.write ("select20305'Exception : " + e);
        }
        outputLog.write ("select20305 : " + returnVal);
        return returnVal;
    }

	public String queryString (String query) {
		if (query == null)
            return "''";
        query = query.replaceAll ("'", "''");
        return query;
	}

	public int queryInt (String value) {
        int intValue = 0;
		if (value == null)
            return intValue;
		try {
			intValue = Integer.parseInt (value);
		} catch (Exception e) {
		}
        return intValue;
	}

	public Float queryFloat (String value) {
		float floatValue = 0;
		if (value == null)
            return floatValue;
		try {
			floatValue = Float.parseFloat (value);
		} catch (Exception e) {
		}
        return floatValue;
	}

    public void sleep (int waitingTime) {
        try {
            Thread.sleep (waitingTime);
        } catch (Exception e) {
        }
    }

    public String getDateTime () {
        Calendar    calendar = Calendar.getInstance ();

        return String.format ("%04d-%02d-%02d %02d:%02d:%02d",
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH) + 1,
            calendar.get(Calendar.DAY_OF_MONTH),
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            calendar.get(Calendar.SECOND));
    }

	public String getDate (Date date) {
		SimpleDateFormat	simpleDateFormat = new SimpleDateFormat ("yyyyMMdd");
		return (simpleDateFormat.format (date));
	}

	public String getTime (Date date) {
		SimpleDateFormat	simpleDateFormat = new SimpleDateFormat ("yyyyMMddHHmmss");
		return (simpleDateFormat.format (date));
	}

	public Date getUnixTime (String unixTime) {
		try {
			long time = Long.parseLong (unixTime);
			time *= 1000;
			return new Date (time);
		} catch (Exception e) {
			return new Date ();
		}
	}

    public void assignValue () {
		int mntrNum, index1 = 1, index2 = 1;
        try {
			preparedStatement20301.setString (index1++, alarmColumn.get ("Field2"));
			preparedStatement20305.setString (index2++, alarmColumn.get ("Field2"));
			preparedStatement20301.setString (index1++, alarmColumn.get ("Field3"));
			preparedStatement20305.setString (index2++, alarmColumn.get ("Field3"));
			preparedStatement20301.setString (index1++, equipId);
			preparedStatement20305.setString (index2++, equipId);
			preparedStatement20301.setString (index1++, alarmColumn.get ("Field5"));
			preparedStatement20305.setString (index2++, alarmColumn.get ("Field5"));

			preparedStatement20305.setString (index2++, mntrDtm); 
			preparedStatement20305.setString (index2++, mntrDt); 

            // UPDATE
			preparedStatement20301.setString (index1++, alarmColumn.get ("Field7"));
			preparedStatement20305.setString (index2++, alarmColumn.get ("Field7"));

			preparedStatement20301.setString (index1++, alarmColumn.get ("Field8"));
			preparedStatement20305.setString (index2++, alarmColumn.get ("Field8"));

			preparedStatement20301.setString (index1++, alarmColumn.get ("Field13"));
			preparedStatement20305.setString (index2++, alarmColumn.get ("Field13"));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field14")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field14")));

			preparedStatement20301.setString (index1++, queryString (alarmColumn.get ("Field16")));
			preparedStatement20305.setString (index2++, queryString (alarmColumn.get ("Field16")));

			preparedStatement20301.setString (index1++, queryString (alarmColumn.get ("Field18")));
			preparedStatement20305.setString (index2++, queryString (alarmColumn.get ("Field18")));

			preparedStatement20301.setString (index1++, alarmColumn.get ("Field20"));
			preparedStatement20305.setString (index2++, alarmColumn.get ("Field20"));

			preparedStatement20301.setString (index1++, queryString (alarmColumn.get ("Field22")));
			preparedStatement20305.setString (index2++, queryString (alarmColumn.get ("Field22")));

			preparedStatement20301.setString (index1++, queryString (alarmColumn.get ("Field23")));
			preparedStatement20305.setString (index2++, queryString (alarmColumn.get ("Field23")));

//			preparedStatement20301.setString (index1++, queryString (mntrDt));
//			preparedStatement20305.setString (index2++, queryString (mntrDt));

			preparedStatement20301.setString (index1++, queryString (alarmColumn.get ("Field25")));
			preparedStatement20305.setString (index2++, queryString (alarmColumn.get ("Field25")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field27")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field27")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field28")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field28")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field29")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field29")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field30")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field30")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field31")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field31")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field32")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field32")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field33")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field33")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field34")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field34")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field35")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field35")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field36")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field36")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field37")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field37")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field38")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field38")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field39")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field39")));

			preparedStatement20301.setFloat (index1++, queryFloat (alarmColumn.get ("Field40")));
			preparedStatement20305.setFloat (index2++, queryFloat (alarmColumn.get ("Field40")));

			preparedStatement20301.setFloat (index1++, queryFloat (alarmColumn.get ("Field41")));
			preparedStatement20305.setFloat (index2++, queryFloat (alarmColumn.get ("Field41")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field42")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field42")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field43")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field43")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field44")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field44")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field46")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field46")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field47")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field47")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field49")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field49")));

			preparedStatement20301.setString (index1++, queryString (alarmColumn.get ("Field51")));
			preparedStatement20305.setString (index2++, queryString (alarmColumn.get ("Field51")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field53")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field53")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field54")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field54")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field55")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field55")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field58")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field58")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field59")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field59")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field60")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field60")));

			preparedStatement20301.setFloat (index1++, queryFloat (alarmColumn.get ("Field62")));
			preparedStatement20305.setFloat (index2++, queryFloat (alarmColumn.get ("Field62")));

			preparedStatement20301.setFloat (index1++, queryFloat (alarmColumn.get ("Field63")));
			preparedStatement20305.setFloat (index2++, queryFloat (alarmColumn.get ("Field63")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field76")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field76")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field77")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field77")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field78")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field78")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field79")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field79")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field80")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field80")));

			preparedStatement20301.setInt (index1++,  queryInt (alarmColumn.get ("Field81")));
			preparedStatement20305.setInt (index2++,  queryInt (alarmColumn.get ("Field81")));

			preparedStatement20301.setString (index1++, queryString (tpoCd));
			preparedStatement20305.setString (index2++, queryString (tpoCd));

			preparedStatement20301.setString (index1++, queryString (mntrDtm));
//			preparedStatement20305.setString (index2++, queryString (mntrDtm));

            // INSERT
			preparedStatement20301.setString (index1++, queryString (alarmColumn.get ("Field2")));
			preparedStatement20305.setString (index2++, queryString (alarmColumn.get ("Field2")));

			preparedStatement20301.setString (index1++, queryString (alarmColumn.get ("Field3")));
			preparedStatement20305.setString (index2++, queryString (alarmColumn.get ("Field3")));

			preparedStatement20301.setString (index1++, queryString (equipId));
			preparedStatement20305.setString (index2++, queryString (equipId));

			preparedStatement20301.setString (index1++, queryString (alarmColumn.get ("Field5")));
			preparedStatement20305.setString (index2++, queryString (alarmColumn.get ("Field5")));

			preparedStatement20301.setString (index1++, queryString (alarmColumn.get ("Field7")));
			preparedStatement20305.setString (index2++, queryString (alarmColumn.get ("Field7")));

			preparedStatement20301.setString (index1++, queryString (alarmColumn.get ("Field8")));
			preparedStatement20305.setString (index2++, queryString (alarmColumn.get ("Field8")));

			preparedStatement20301.setString (index1++, queryString (alarmColumn.get ("Field13")));
			preparedStatement20305.setString (index2++, queryString (alarmColumn.get ("Field13")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field14")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field14")));

			preparedStatement20301.setString (index1++, queryString (alarmColumn.get ("Field16")));
			preparedStatement20305.setString (index2++, queryString (alarmColumn.get ("Field16")));

			preparedStatement20301.setString (index1++, queryString (alarmColumn.get ("Field18")));
			preparedStatement20305.setString (index2++, queryString (alarmColumn.get ("Field18")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field20")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field20")));

			preparedStatement20301.setString (index1++, queryString (alarmColumn.get ("Field22")));
			preparedStatement20305.setString (index2++, queryString (alarmColumn.get ("Field22")));

			preparedStatement20301.setString (index1++, queryString (alarmColumn.get ("Field23")));
			preparedStatement20305.setString (index2++, queryString (alarmColumn.get ("Field23")));

			preparedStatement20301.setString (index1++, queryString (mntrDt));
			preparedStatement20305.setString (index2++, queryString (mntrDt));

			preparedStatement20301.setString (index1++, queryString (alarmColumn.get ("Field25")));
			preparedStatement20305.setString (index2++, queryString (alarmColumn.get ("Field25")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field27")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field27")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field28")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field28")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field29")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field29")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field30")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field30")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field31")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field31")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field32")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field32")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field33")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field33")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field34")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field34")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field35")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field35")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field36")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field36")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field37")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field37")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field38")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field38")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field39")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field39")));

			preparedStatement20301.setFloat (index1++, queryFloat (alarmColumn.get ("Field40")));
			preparedStatement20305.setFloat (index2++, queryFloat (alarmColumn.get ("Field40")));

			preparedStatement20301.setFloat (index1++, queryFloat (alarmColumn.get ("Field41")));
			preparedStatement20305.setFloat (index2++, queryFloat (alarmColumn.get ("Field41")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field42")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field42")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field43")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field43")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field44")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field44")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field46")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field46")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field47")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field47")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field49")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field49")));

			preparedStatement20301.setString (index1++, queryString (alarmColumn.get ("Field51")));
			preparedStatement20305.setString (index2++, queryString (alarmColumn.get ("Field51")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field53")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field53")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field54")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field54")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field55")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field55")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field58")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field58")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field59")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field59")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field60")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field60")));

			preparedStatement20301.setFloat (index1++, queryFloat (alarmColumn.get ("Field62")));
			preparedStatement20305.setFloat (index2++, queryFloat (alarmColumn.get ("Field62")));

			preparedStatement20301.setFloat (index1++, queryFloat (alarmColumn.get ("Field63")));
			preparedStatement20305.setFloat (index2++, queryFloat (alarmColumn.get ("Field63")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field76")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field76")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field77")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field77")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field78")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field78")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field79")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field79")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field80")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field80")));

			preparedStatement20301.setInt (index1++, queryInt (alarmColumn.get ("Field81")));
			preparedStatement20305.setInt (index2++, queryInt (alarmColumn.get ("Field81")));

			preparedStatement20301.setString (index1++, queryString (tpoCd));
			preparedStatement20305.setString (index2++, queryString (tpoCd));

			preparedStatement20301.setString (index1++, queryString (mntrDtm));
			preparedStatement20305.setString (index2++, queryString (mntrDtm));

			preparedStatement20301.setString (index1++, queryString (equipSysNm));
			preparedStatement20305.setString (index2++, queryString (equipSysNm));

			preparedStatement20301.addBatch ();
			preparedStatement20305.addBatch ();
        } catch (Exception e) {
			outputLog.write ("index1 : " + index1 + ", index2 : " + index2);
			outputLog.write ("assignValue'Exception : " + e);
        }
    }

    public String queryStatement (int tableNum) {
		int mntrNum;
        String query = "MERGE ";
		if (tableNum == 20305) 
			query += "/*+ INDEX(OMN20305 OMN20305_N1) */";

		query += " INTO OMN" + tableNum + " USING DUAL "
              + " ON (DATA_SRC_CL_CD=?"
              + " AND MNTR_CYCL_CD=?"
              + " AND EQUIP_ID=?"                          // equipId
              + " AND ROUT_NUM_CTT=?";

        if (tableNum == 20305) {
            query += " AND MNTR_DTM=?";
            query += " AND MNTR_DT=?";
		}
        query += ")"
              + " WHEN MATCHED THEN UPDATE SET"
              + "  AUDIT_ID='adams'"
              + ", AUDIT_DTM=SYSDATE"
              + ", EXCHG_EQUIP_CL_CD='V'"
              + ", ROUT_USG_CTT=?"                         // Field7
              + ", EXG_NUM=?"                              // Field8
              + ", PHON_SVC_CD=?"                          // Field13
              + ", BIZR_ID=?"                              // Field14
              + ", PHON_SVC_NUM=?"                         // Field16
              + ", PORT_NUM=?"                             // Field18
              + ", PRI_BIZR_ID=?"                          // Field20
              + ", CONN_CL_CD=?"                           // Field22
              + ", ROUT_DIRN_CD=?"                         // Field23
//              + ", MNTR_DT=?"                              // mntrDt
              + ", DABL_YN=?"                              // Field25
              + ", IT_CALL_CNT=?"                          // Field27
              + ", ICALL_FNSH_CALL_CNT=?"                  // Field28
              + ", OT_CALL_CNT=?"                          // Field29
              + ", OCALL_FNSH_CALL_CNT=?"                  // Field30
              + ", TRUNK_CNT=?"                            // Field31
              + ", ICALL_TC_TMS=?"                         // Field32
              + ", OCALL_TC_TMS=?"                         // Field33
              + ", OCALL_NUM_TM_TRY_CALL_CNT=?"            // Field34
              + ", OCALL_NUM_TM_FNSH_CALL_CNT=?"           // Field35
              + ", OCALL_NUM_TM_TC_TMS=?"                  // Field36
              + ", ICALL_NUM_TM_TRY_CALL_CNT=?"            // Field37
              + ", ICALL_NUM_TM_FNSH_CALL_CNT=?"           // Field38
              + ", ICALL_NUM_TM_TC_TMS=?"                  // Field39
              + ", AVG_RSV_TMS=?"                          // Field40
              + ", ERLANG_VAL=?"                           // Field41
              + ", SCRBR_ERR_CNT=?"                        // Field42
              + ", ROUT_ERR_CNT=?"                         // Field43
              + ", NUM_CONV_ERR_CNT=?"                     // Field44
              + ", TRUNK_ERR_CNT=?"                        // Field46
              + ", ETC_NCMPL_CALL_CNT=?"                   // Field47
              + ", DOEXG_BIZR_ID=?"                        // Field49
              + ", VIP_CUST_YN=?"                          // Field51
              + ", NY_OCCR_DC_OCCR_CNT=?"                  // Field53
              + ", FNSH_RT_DC_OCCR_CNT=?"                  // Field54
              + ", EXFLU_RT_DC_OCCR_CNT=?"                 // Field55
              + ", IT_CALL_EXFLU_DC_OCCR_CNT=?"            // Field58
              + ", OT_CALL_EXFLU_RT_DC_OCCR_CNT=?"         // Field59
              + ", LINE_USE_RT_DC_OCCR_CNT=?"              // Field60
              + ", IT_CALL_EXFLU_RT=?"                     // Field62
              + ", OT_CALL_EXFLU_RT=?"                     // Field63
              + ", TEST_OT_CALL_CNT=?"                     // Field76
              + ", TEST_OCALL_FNSH_CALL_CNT=?"             // Field77
              + ", TEST_OCALL_TC_TMS=?"                    // Field78
              + ", TEST_IT_CALL_CNT=?"                     // Field79
              + ", TEST_ICALL_FNSH_CALL_CNT=?"             // Field80
              + ", TEST_ICALL_TC_TMS=?"                    // Field81
              + ", TPO_CD=?";                               // tpoCd
        if (tableNum == 20301) {
            query += ", MNTR_DTM=?";
		}
        query +=" WHEN NOT MATCHED THEN INSERT("
              + "  AUDIT_ID"
              + ", AUDIT_DTM"
              + ", EXCHG_EQUIP_CL_CD"
              + ", MNTR_NUM"
              + ", DATA_SRC_CL_CD"
              + ", MNTR_CYCL_CD"
              + ", EQUIP_ID"
              + ", ROUT_NUM_CTT"
              + ", ROUT_USG_CTT"
              + ", EXG_NUM"
              + ", PHON_SVC_CD"
              + ", BIZR_ID"
              + ", PHON_SVC_NUM"
              + ", PORT_NUM"
              + ", PRI_BIZR_ID"
              + ", CONN_CL_CD"
              + ", ROUT_DIRN_CD"
              + ", MNTR_DT"
              + ", DABL_YN"
              + ", IT_CALL_CNT"
              + ", ICALL_FNSH_CALL_CNT"
              + ", OT_CALL_CNT"
              + ", OCALL_FNSH_CALL_CNT"
              + ", TRUNK_CNT"
              + ", ICALL_TC_TMS"
              + ", OCALL_TC_TMS"
              + ", OCALL_NUM_TM_TRY_CALL_CNT"
              + ", OCALL_NUM_TM_FNSH_CALL_CNT"
              + ", OCALL_NUM_TM_TC_TMS"
              + ", ICALL_NUM_TM_TRY_CALL_CNT"
              + ", ICALL_NUM_TM_FNSH_CALL_CNT"
              + ", ICALL_NUM_TM_TC_TMS"
              + ", AVG_RSV_TMS"
              + ", ERLANG_VAL"
              + ", SCRBR_ERR_CNT"
              + ", ROUT_ERR_CNT"
              + ", NUM_CONV_ERR_CNT"
              + ", TRUNK_ERR_CNT"
              + ", ETC_NCMPL_CALL_CNT"
              + ", DOEXG_BIZR_ID"
              + ", VIP_CUST_YN"
              + ", NY_OCCR_DC_OCCR_CNT"
              + ", FNSH_RT_DC_OCCR_CNT"
              + ", EXFLU_RT_DC_OCCR_CNT"
              + ", IT_CALL_EXFLU_DC_OCCR_CNT"
              + ", OT_CALL_EXFLU_RT_DC_OCCR_CNT"
              + ", LINE_USE_RT_DC_OCCR_CNT"
              + ", IT_CALL_EXFLU_RT"
              + ", OT_CALL_EXFLU_RT"
              + ", TEST_OT_CALL_CNT"
              + ", TEST_OCALL_FNSH_CALL_CNT"
              + ", TEST_OCALL_TC_TMS"
              + ", TEST_IT_CALL_CNT"
              + ", TEST_ICALL_FNSH_CALL_CNT"
              + ", TEST_ICALL_TC_TMS"
              + ", TPO_CD"
              + ", MNTR_DTM"
              + ", EQUIP_SYS_NM"
              + ") VALUES ("
              + "  'adams'"
              + ", SYSDATE"
              + ", 'V'";
        if (tableNum == 20305)
            query += ", OMN20305_S1.nextval";
		else
            query += ", OMN20301_S1.nextval";
        query += ", ?"                                           // Field2
              + ", ?"                                            // Field3
              + ", ?"                                            // equipId            
              + ", ?"                                            // Field5
              + ", ?"                                            // Field7
              + ", ?"                                            // Field8
              + ", ?"                                            // Field13
              + ", ?"                                            // Field14
              + ", ?"                                            // Field16
              + ", ?"                                            // Field18
              + ", ?"                                            // Field20
              + ", ?"                                            // Field22
              + ", ?"                                            // Field23
              + ", ?"                                            // mntrDt
              + ", ?"                                            // Field25
              + ", ?"                                            // Field27
              + ", ?"                                            // Field28
              + ", ?"                                            // Field29
              + ", ?"                                            // Field30
              + ", ?"                                            // Field31
              + ", ?"                                            // Field32
              + ", ?"                                            // Field33
              + ", ?"                                            // Field34
              + ", ?"                                            // Field35
              + ", ?"                                            // Field36
              + ", ?"                                            // Field37
              + ", ?"                                            // Field38
              + ", ?"                                            // Field39
              + ", ?"                                            // Field40
              + ", ?"                                            // Field41
              + ", ?"                                            // Field42
              + ", ?"                                            // Field43
              + ", ?"                                            // Field44
              + ", ?"                                            // Field46
              + ", ?"                                            // Field47
              + ", ?"                                            // Field49
              + ", ?"                                            // Field51
              + ", ?"                                            // Field53
              + ", ?"                                            // Field54
              + ", ?"                                            // Field55
              + ", ?"                                            // Field58
              + ", ?"                                            // Field59
              + ", ?"                                            // Field60
              + ", ?"                                            // Field62
              + ", ?"                                            // Field63
              + ", ?"                                            // Field76
              + ", ?"                                            // Field77
              + ", ?"                                            // Field78
              + ", ?"                                            // Field79
              + ", ?"                                            // Field80
              + ", ?"                                            // Field81
              + ", ?"                                            // tpoCd
              + ", ?"                                            // mntrDtm
              + ", ?"                                            // equipSysNm
              + ")";
        return query;
    }

    public static void main (String [] args) {
		if (args.length != 1) {
			System.out.println ("Usage : RealTimeCollectUnmsVoipTraffic directory");
			System.exit(0);
		}
        new RealTimeCollectUnmsVoipTraffic (args);
    }
}

