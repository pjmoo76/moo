package	com.skb.mi.realtime;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.util.Properties;
import java.sql.Clob;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import oracle.sql.CLOB;

import com.skb.mi.common.DBController;

public class SendMail {
	DBController	dbController;
	String	username = "relay.adams";
	String 	sendUsername = "adams@skbroadband.com";
	final 	String 	password = "adams!qwer";
	String 			host = "58.123.195.93";			// Broadband mail어드레스
	int 			port=25;
	String 			rcvEmailAddr = "seonghun.k@sk.com";
	String 			emailTitleNm = "ADAMS Mail Test";
	String 			strEmailPhrs = "adams@skbroadband.com testing.......";
	Clob            clobEmailPhrs;
	String			emailSndSerNum;
	String			auditDtm;

	String			dbUrl, userName, passWord;
	String			absolutePath;

	Properties		props;
	Statement		twoStmt;

	public SendMail (String [] args) {
		
		absolutePath = args [0];
		try {			
			readDbInfo ();
	
			dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, passWord);
			twoStmt = dbController.getConnection ().createStatement ();
			String		query = selectMail ();
			String ocallDmnNm = "";
			System.out.println ("selectMail : " + query);
			ResultSet	resultSet = dbController.getStmt ().executeQuery (query);
			while (resultSet.next ()) {
				StringBuffer stb = new StringBuffer();
				emailSndSerNum = resultSet.getString (1);
				rcvEmailAddr = resultSet.getString (2);
				emailTitleNm = resultSet.getString (3);
				// emailPhrs = resultSet.getString (4);
				clobEmailPhrs = resultSet.getClob(4);
				auditDtm = resultSet.getString (5);
				ocallDmnNm = resultSet.getString (6);
				
				if(ocallDmnNm!= null){
					sendUsername = ocallDmnNm.toLowerCase()+"@skbroadband.com";
				}else{
					sendUsername = "adams@skbroadband.com";
				}
				
				BufferedReader br = new BufferedReader(clobEmailPhrs.getCharacterStream());
				String str = "";
								
				while((str = br.readLine())!= null)
				{
					stb.append(str);
				}				
				
				strEmailPhrs = stb.toString();
				
				System.out.println (emailSndSerNum + ", " + rcvEmailAddr + ", " + emailTitleNm + ", " + strEmailPhrs + ", " + auditDtm + " , "+username);

				try {
					sendMail ();
					query = updateMail ();
					System.out.println ("updateMail : " + query);
					twoStmt.executeUpdate (query);
				} catch (Exception e) {
					System.out.println (""
							+ " : " + rcvEmailAddr + ", emailTitleNm : " + emailTitleNm);
					System.out.println ("Exception : " + e);
					
					
				}
			}
			resultSet.close ();
			twoStmt.close ();
			dbController.closeDB ();
		} catch (Exception e) {
            System.out.println ("SendMail Error : " + e);
            if (dbController != null)
                dbController.closeDB ();
            System.out.println ("Finish : " + getDateSecond ());
            System.exit (1);
		}
	}

    public void readDbInfo () throws Exception {
        FileReader  fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + "db.info");
        BufferedReader bufferedReader = new BufferedReader (fileReader);
        dbUrl = bufferedReader.readLine ();
        userName = bufferedReader.readLine ();
        passWord = bufferedReader.readLine ();
        bufferedReader.close ();
        fileReader.close ();
    }

	public String updateMail () {
		return "UPDATE OCO40222 SET"
			 + " EMAIL_SND_YN='Y'"
			 + " WHERE EMAIL_SND_SER_NUM='" + emailSndSerNum + "'";
	}

	public void	sendMail () throws Exception {
          
		props = new Properties ();
		props.put("mail.smtp.auth", "true");

		Session	session = Session.getDefaultInstance (props);
		MimeMessage	msg = new MimeMessage (session);

		msg.setSubject (emailTitleNm);
//		msg.setText (emailPhrs);
		msg.setContent (strEmailPhrs, "text/html;charset=euc-kr");
//     msg.setContent (emailPhrs, "text/html");
		msg.addRecipient (Message.RecipientType.TO, new InternetAddress (rcvEmailAddr));
		//msg.addRecipient (Message.RecipientType.CC, new InternetAddress ("donghoon8.kim@sk.com"));
		//msg.addRecipient (Message.RecipientType.CC, new InternetAddress ("mdjj@sk.com"));
		msg.setFrom (new InternetAddress (sendUsername));

        session.setDebug(false); //for debug

		Transport	transport = session.getTransport ("smtp");
		transport.connect (host, username, password);

		transport.sendMessage (msg, msg.getAllRecipients ());
		transport.close ();
    }

	public String selectMail () {
		return "SELECT "
			+  " EMAIL_SND_SER_NUM"
			+  " , RCV_EMAIL_ADDR"
			+  " , EMAIL_TITLE_NM"
			+  " , EMAIL_PHRS"
			+  " , TO_CHAR(AUDIT_DTM, 'YYYYMMDDHH24MISS')"
			+  " , OCALL_DMN_NM"
			+  " FROM OCO40222"
			+  " WHERE EMAIL_SND_YN='N'";
	}

    public String getDateSecond () {
        Calendar    calendar = Calendar.getInstance ();

        return String.format ("%04d-%02d-%02d %02d:%02d:%02d",
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH) + 1,
            calendar.get(Calendar.DAY_OF_MONTH),
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            calendar.get(Calendar.SECOND));
    }

    public static void main(String args[]) throws MessagingException{
		if (args.length != 1) {
			System.out.println ("사용법 : java SendMail 절대패스");
			System.exit (1);
		}
		new SendMail (args);


	}
}

