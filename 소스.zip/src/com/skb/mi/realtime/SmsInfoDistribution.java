package com.skb.mi.realtime;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.skb.mi.common.Constants;
import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.common.MiscUtils;

public class SmsInfoDistribution extends Thread {
	
	Logger		    logger;
	SqlSession	    adamsSession;
	FaultMessageHandler faultMessageHandler;
	
	public SmsInfoDistribution(FaultMessageHandler faultMessageHandler) {
		// TODO Auto-generated constructor stub
		super ();
		
		this.faultMessageHandler = faultMessageHandler;
		this.logger = faultMessageHandler.logger;
		 //설정정보 얻기
	    getSmsCircuitInfo();	
		getSmsEquipInfo();
		getSmsVipInfo();
		getSmsVipEquipInfo();
		getSmsBizInfo();
		getSmsBizCenterInfo();
	}
	
	public void getSmsCircuitInfo() {
		logger.info("start getSmsCircuitInfo");
		try {
			if(this.adamsSession == null)
			{			
				adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
			}
			String		lineNum, dablGrCd, key, value, rcvPhonNum;			
			Hashtable <String,String> phoneListTemp = new Hashtable <String,String>();
			adamsSession.clearCache();
			List<HashMap<String, String>> circuitList = (List) adamsSession.selectList("smsSender.selectCircuitList");
			int circuitListSize = circuitList.size();
			
			for(int i=0;circuitListSize>i;i++)
			{
				HashMap<String, String> circuit = circuitList.get(i);
				rcvPhonNum = circuit.get("RCV_PHON_NUM");
				dablGrCd = circuit.get("DABL_GR_CD");
				lineNum = circuit.get("LINE_NUM");
				
				key = lineNum + "," + dablGrCd;				// 회선번호 적용
				putPhoneList (key, rcvPhonNum,phoneListTemp);
				if ("04".equals(dablGrCd)) {				// 장애 등급이 Major인 경우
					key = lineNum + "," + "05";				// Critical도 추가
					putPhoneList (key, rcvPhonNum,phoneListTemp);
				} else if ("03".equals(dablGrCd)) {		// 장애 등급이 Minor인 경우
					key = lineNum + "," + "04";				// Major도 추가
					putPhoneList (key, rcvPhonNum,phoneListTemp);
					key = lineNum + "," + "05";				// Critical도 추가
					putPhoneList (key, rcvPhonNum,phoneListTemp);
				}
			}
			synchronized (faultMessageHandler.circuitPhoneList) {
				faultMessageHandler.circuitPhoneList = null;
				faultMessageHandler.circuitPhoneList = phoneListTemp;
			}
			logger.info("CircuitphoneList.size : " + faultMessageHandler.circuitPhoneList.size());
			
		} catch (SQLException sqle) {
			logger.error("SQLException", sqle);
			adamsSession.close();
			adamsSession = null;
			MiscUtils.sleep(100);
		} catch (PersistenceException pe) {
			logger.error("PersistenceException", pe);
			adamsSession.close();
			adamsSession = null;
			MiscUtils.sleep(100);
		} catch (Exception e) {
			logger.error("Exception", e);
	   	}		
		
	}
	public void getSmsVipInfo() {
		logger.info("start getSmsVipInfo");
		try {
			if(this.adamsSession == null)
			{			
				adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
			}
			Hashtable <String,Object> phoneListTemp = new Hashtable <String,Object>();
			adamsSession.clearCache();
			//vip 관련 설정 정보 얻기
			List<HashMap<String, String>> vipList = (List) adamsSession.selectList("smsSender.selectVipList", null);
			int vipListSize = vipList.size();
			for(int i=0;vipListSize>i;i++)
			{
				HashMap<String, String> vip = vipList.get(i);
				String svcMgmtNum = String.valueOf(vip.get("SVC_MGMT_NUM"));
				
				phoneListTemp.put(svcMgmtNum, vip);
				
			}
			logger.info("vipPhoneList.size : " + phoneListTemp.size() + "vipListSize : " + vipListSize );
			synchronized (faultMessageHandler.vipPhoneList) {
				faultMessageHandler.vipPhoneList = null;
				faultMessageHandler.vipPhoneList = phoneListTemp;
			}
			logger.info("vipPhoneList.size : " + faultMessageHandler.vipPhoneList.size());
		} catch (SQLException sqle) {
			logger.error("SQLException", sqle);
			adamsSession.close();
			adamsSession = null;
			MiscUtils.sleep(100);
		} catch (PersistenceException pe) {
			logger.error("PersistenceException", pe);
			adamsSession.close();
			adamsSession = null;
			MiscUtils.sleep(100);
		} catch (Exception e) {
			logger.error("Exception", e);
	   	}		
		
	}
	
	public void getSmsVipEquipInfo() {
		logger.info("start getSmsVipEquipInfo");
		try {
			if(this.adamsSession == null)
			{			
				adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
			}
			Hashtable <String,Object> phoneListTemp = new Hashtable <String,Object>();
			adamsSession.clearCache();
			//vip 관련 설정 정보 얻기
			List<HashMap<String, String>> vipEquipList = (List) adamsSession.selectList("smsSender.selectVipEquipList", null);
			int vipEquipListSize = vipEquipList.size();
			for(int i=0;vipEquipListSize>i;i++)
			{
				HashMap<String, String> vip = vipEquipList.get(i);
				String equip_id = String.valueOf(vip.get("EQUIP_ID"));
				
				phoneListTemp.put(equip_id, vip);
				
			}
			logger.info("vipPhoneList.size : " + phoneListTemp.size() + "vipEquipListSize : " + vipEquipListSize );
			synchronized (faultMessageHandler.vipEquipPhoneList) {
				faultMessageHandler.vipEquipPhoneList = null;
				faultMessageHandler.vipEquipPhoneList = phoneListTemp;
			}
			logger.info("vipEquipPhoneList.size : " + faultMessageHandler.vipEquipPhoneList.size());
		} catch (SQLException sqle) {
			logger.error("SQLException", sqle);
			adamsSession.close();
			adamsSession = null;
			MiscUtils.sleep(100);
		} catch (PersistenceException pe) {
			logger.error("PersistenceException", pe);
			adamsSession.close();
			adamsSession = null;
			MiscUtils.sleep(100);
		} catch (Exception e) {
			logger.error("Exception", e);
	   	}		
		
	}
	
	public void getSmsEquipInfo() {
		logger.info("start getSmsEquipInfo");
		try {
			if(this.adamsSession == null)
			{			
				adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
			}
			String		equipId, dablGrCd, key,  rcvPhonNum,dablCd;		
			Hashtable <String,String> phoneListTemp = new Hashtable <String,String>();
			adamsSession.clearCache();
			List<HashMap<String, String>> equipList = (List) adamsSession.selectList("smsSender.selectEquipList");
			int equipListSize = equipList.size();
			
			for(int i=0;equipListSize>i;i++)
			{
				HashMap<String, String> equip = equipList.get(i);
				rcvPhonNum = equip.get("RCV_PHON_NUM");
				dablGrCd = equip.get("DABL_GR_CD");
				equipId = equip.get("EQUIP_ID");
				dablCd = equip.get("DABL_CD");
				
				key = equipId + "," + dablGrCd + "," + dablCd;		
				
				putPhoneList (key, rcvPhonNum,phoneListTemp);
				if ("04".equals(dablGrCd)) {				// 장애 등급이 Major인 경우
					key = equipId + "," + "04"+ "," + dablCd;					// Major도 추가
					putPhoneList (key, rcvPhonNum,phoneListTemp);
					key = equipId + "," + "05"+ "," + dablCd;					// Critical도 추가
					putPhoneList (key, rcvPhonNum,phoneListTemp);
				} else if ("03".equals(dablGrCd)) {		// 장애 등급이 Minor인 경우
					key = equipId + "," + "03"+ "," + dablCd;				// Minor도 추가
					putPhoneList (key, rcvPhonNum,phoneListTemp);
					key = equipId + "," + "04"+ "," + dablCd;				// Major도 추가
					putPhoneList (key, rcvPhonNum,phoneListTemp);
					key = equipId + "," + "05"+ "," + dablCd;				// Critical도 추가
					putPhoneList (key, rcvPhonNum,phoneListTemp);
				}else if(dablGrCd == null){
					key = equipId + "," + "03"+ "," + dablCd;				// Minor도 추가
					putPhoneList (key, rcvPhonNum,phoneListTemp);
					key = equipId + "," + "04"+ "," + dablCd;				// Major도 추가
					putPhoneList (key, rcvPhonNum,phoneListTemp);
					key = equipId + "," + "05"+ "," + dablCd;				// Critical도 추가
					putPhoneList (key, rcvPhonNum,phoneListTemp);
				}
			}
			synchronized (faultMessageHandler.equipPhoneList) {
				faultMessageHandler.equipPhoneList = null;
				faultMessageHandler.equipPhoneList = phoneListTemp;
			}
			logger.info("EquipPhoneList.size : " + faultMessageHandler.equipPhoneList.size());
		} catch (SQLException sqle) {
			logger.error("SQLException", sqle);
			adamsSession.close();
			adamsSession = null;
			MiscUtils.sleep(100);
		} catch (PersistenceException pe) {
			logger.error("PersistenceException", pe);
			adamsSession.close();
			adamsSession = null;
			MiscUtils.sleep(100);
		} catch (Exception e) {
			logger.error("Exception", e);
	   	}		
		
	}
	
	public void getSmsBizInfo() {
		logger.info("start getSmsBizInfo");
		try {
			if(this.adamsSession == null)
			{			
				adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
			}
			Hashtable <String,Object> phoneListTemp = new Hashtable <String,Object>();
			adamsSession.clearCache();
			//biz 관련 설정 정보 얻기
			List<HashMap<String, String>> bizList = (List) adamsSession.selectList("smsSender.selectBizList", null);
			int bizListSize = bizList.size();
			for(int i=0;bizListSize>i;i++)
			{
				HashMap<String, String> biz = bizList.get(i);
				String equipId = String.valueOf(biz.get("EQUIP_ID"));
				String dablCd = String.valueOf(biz.get("DABL_CD"));
				
				List list = (List) phoneListTemp.get(equipId+","+dablCd);
				
				if(list == null)
				{
					List list2 =  new ArrayList<Object>();
					list2.add(biz);
					phoneListTemp.put(equipId+","+dablCd, list2);
					
				}else{
					list.add(biz);
					
				}				
				
			}
			logger.info("bizPhoneList.size : " + phoneListTemp.size() + "bizListSize : " + bizListSize );
			synchronized (faultMessageHandler.bizPhoneList) {
				faultMessageHandler.bizPhoneList = null;
				faultMessageHandler.bizPhoneList = phoneListTemp;
			}
			logger.info("bizPhoneList.size : " + faultMessageHandler.bizPhoneList.size());
			
		} catch (SQLException sqle) {
			logger.error("SQLException", sqle);
			adamsSession.close();
			adamsSession = null;
			MiscUtils.sleep(100);
		} catch (PersistenceException pe) {
			logger.error("PersistenceException", pe);
			adamsSession.close();
			adamsSession = null;
			MiscUtils.sleep(100);
		} catch (Exception e) {
			logger.error("Exception", e);
	   	}		
		
	}
	
	public void getSmsBizCenterInfo() {
		logger.info("start getSmsBizCenterInfo");
		try {
			if(this.adamsSession == null)
			{			
				adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
			}
			Hashtable <String,Object> phoneListTemp = new Hashtable <String,Object>();
			adamsSession.clearCache();
			//bizCenter 관련 설정 정보 얻기
			List<HashMap<String, String>> bizCenterList = (List) adamsSession.selectList("smsSender.selectBizCenterList", null);
			int bizCenterListSize = bizCenterList.size();
			for(int i=0;bizCenterListSize>i;i++)
			{
				HashMap<String, String> biz = bizCenterList.get(i);
				String equipId = String.valueOf(biz.get("EQUIP_ID"));
				String dablCd = String.valueOf(biz.get("DABL_CD"));
				
				List list = (List) phoneListTemp.get(equipId+","+dablCd);
				
				if(list == null)
				{
					List list2 =  new ArrayList<Object>();
					list2.add(biz);
					phoneListTemp.put(equipId+","+dablCd, list2);
					
				}else{
					list.add(biz);
					
				}				
				
			}
			
			
			logger.info("bizCenterPhoneList.size : " + phoneListTemp.size() + "bizCenterListSize : " + bizCenterListSize );
			synchronized (faultMessageHandler.bizCenterPhoneList) {
				faultMessageHandler.bizCenterPhoneList = null;
				faultMessageHandler.bizCenterPhoneList = phoneListTemp;
			}
			logger.info("bizCenterPhoneList.size : " + faultMessageHandler.bizCenterPhoneList.size());
			
		} catch (SQLException sqle) {
			logger.error("SQLException", sqle);
			adamsSession.close();
			adamsSession = null;
			MiscUtils.sleep(100);
		} catch (PersistenceException pe) {
			logger.error("PersistenceException", pe);
			adamsSession.close();
			adamsSession = null;
			MiscUtils.sleep(100);
		} catch (Exception e) {
			logger.error("Exception", e);
	   	}		
		
	}
	public void putPhoneList (String key, String rcvPhonNum,Hashtable<String, String> phoneList) {
        String value = phoneList.get (key);
        if (value == null)
            value = rcvPhonNum;
        else {
            if (value.indexOf (rcvPhonNum) < 0)
                value += "," + rcvPhonNum;
        }
        
        phoneList.put (key, value);        
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		logger.info("SmsInfoDistribution Start");
		long nextGetSmsInfoTime = (System.currentTimeMillis() / 1000L) + (60*10);
		long nextGetSmsVipInfoTime = (System.currentTimeMillis() / 1000L) + (10*5);		
		
		while(true){
		
			//10분에 한번 장비,회선 설정정보 얻기, BIZ센터정보 업데이트
			long currentTime = System.currentTimeMillis() / 1000L;						
			if (nextGetSmsInfoTime < currentTime) {			
				getSmsCircuitInfo();	
				getSmsEquipInfo();
				getSmsBizCenterInfo();
				nextGetSmsInfoTime = currentTime + (60*10);
			
			}//5분에 한번 VIP,BIZ정보 업데이트
			 else if(nextGetSmsVipInfoTime < currentTime){
				getSmsVipInfo();
				getSmsVipEquipInfo();
				getSmsBizInfo();
				nextGetSmsVipInfoTime = (System.currentTimeMillis() / 1000L) + (10*5);
			}
		}
		
	}	

}
