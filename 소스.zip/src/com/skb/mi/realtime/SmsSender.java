package com.skb.mi.realtime;

import java.io.File;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.common.MiscUtils;

public class SmsSender extends Thread{
	BlockingQueue<JSONObject>	blockingQueue;
	Logger		logger;
	SqlSession	adamsSession;
	
	public SmsSender (ConfigManager configManager){
		super ();
		
		logger = LogManager.getLogger(SmsSender.class.getName());
		blockingQueue = new LinkedBlockingQueue<JSONObject>();
		
		try {
			adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.info("adamsSession error"+e);
		}
		
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		logger.info("SmsSender Start");
		
		JSONObject event = null;
        int errContCnt = 0;
        
		//mq에 있는데이터 db저장 
		while (true) {
			try {
				if (adamsSession == null) {
					adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
				}
				if (event == null) {
					event = blockingQueue.take();
					logger.debug("size:" + blockingQueue.size());
					logger.debug ("[EVENT] " + event.toJSONString ());
					errContCnt = 0;
				} else {
					// retry
					errContCnt ++;
					if (errContCnt > 3) {
						event = null;
						continue;
					}
				}
				if (event != null) {
					sendSms(event);
					event = null;
				}				
				
			} catch (SQLException sqle) {
				logger.error("SQLException", sqle);
				adamsSession.close();
				adamsSession = null;
				MiscUtils.sleep(100);
			} catch (PersistenceException pe) {
				logger.error("PersistenceException", pe);
				adamsSession.close();
				adamsSession = null;
				MiscUtils.sleep(100);
			} catch (Exception e) {
				logger.error("Exception", e);
				MiscUtils.sleep(100);
			}
		}
		
	}	
	
	private void sendSms(JSONObject event){
		
		String faultType = (String)event.get("FAULT_TYPE");
		String kind = (String)event.get("kind");

		SimpleDateFormat sdf = new SimpleDateFormat();		
		
		logger.info("faultType,kind : "+faultType+","+kind);
		
		
		if("GEN".equals(kind)){
			event.put("KIND_NM", "[발생]");			
			Date parseDate2;
			String occrDtm = "";
			try {
				
				sdf.applyPattern("HH:mm:ss MM/dd/yyyy");
				parseDate2 = sdf.parse(event.get("OCCR_RCV_DTM").toString());
				if("VIP_CIRCUIT".equals(faultType)){	
					sdf.applyPattern("HH:mm");
				}else if("BIZ".equals(faultType)|| "BIZ_CENTER".equals(faultType)){
					sdf.applyPattern("yyyy/MM/dd HH:mm:ss");
				}else{
					sdf.applyPattern("HH:mm:ss ");	
				}
				
				occrDtm = sdf.format(parseDate2);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				occrDtm = event.get("OCCR_RCV_DTM").toString();
				
			}				
			event.put("OCCR_RCV_DTM",occrDtm );
			
		}else if("CLR".equals(kind)){
			event.put("KIND_NM", "[복구]");		
			Date parseDate;
			String rlseDtm = "";
			try {
				sdf.applyPattern("yyyyMMddHHmmss");
				parseDate = sdf.parse(event.get("RLSE_RCV_DTM").toString());
				if("VIP_CIRCUIT".equals(faultType)){	
					sdf.applyPattern("HH:mm");
				}else if("BIZ".equals(faultType)|| "BIZ_CENTER".equals(faultType)){
					sdf.applyPattern("yyyy/MM/dd HH:mm:ss");
				}else{
					sdf.applyPattern("HH:mm:ss");	
				}
				rlseDtm = sdf.format(parseDate);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				rlseDtm = event.get("RLSE_RCV_DTM").toString();
				
			}
			if("BIZ".equals(faultType) || "BIZ_CENTER".equals(faultType)){	
				event.put("RLSE_RCV_DTM",rlseDtm );
				
			}else{
				event.put("OCCR_RCV_DTM",rlseDtm );
			}
								
		}
		
		if("VIP_CIRCUIT".equals(faultType)){			
			
			
			//VIP SMS 전송 내역 기록 
			adamsSession.insert("OQA80230_MERGE",event);
			
			String rcvPhonNums = (String)event.get("RCV_PHON_NUMS");
			
			StringTokenizer tokens = new StringTokenizer (rcvPhonNums, ",");
			
			
			while (tokens.hasMoreTokens ()) {
				String	token = tokens.nextToken ();
				event.put("RCV_PHON_NUM", token);
				adamsSession.insert("sendVipSms",event);
			}
		}else if("VIP_EQUIP".equals(faultType)){
			
			//VIP EQUIP SMS 전송내역 기록
			//기존 VIP회선 전송내역은 사용하는데가 없긴 함.
			//adamsSession.insert("OQA80240_MERGE",event);
			
			String rcvPhonNums = (String)event.get("RCV_PHON_NUMS");
			
			StringTokenizer tokens = new StringTokenizer (rcvPhonNums, ",");
			
			
			while (tokens.hasMoreTokens ()) {
				String	token = tokens.nextToken ();
				event.put("RCV_PHON_NUM", token);
				adamsSession.insert("sendVipEquipSms",event);
			}
			
		}else if("FAULT_EQUIP".equals(faultType)){
			
			String rcvPhonNums = (String)event.get("RCV_PHON_NUMS");
			
			StringTokenizer tokens = new StringTokenizer (rcvPhonNums, ",");
			
			while (tokens.hasMoreTokens ()) {
				String	token = tokens.nextToken ();
				event.put("RCV_PHON_NUM", token);
				adamsSession.insert("sendEquipSms",event);
			}
			
		}else if("FAULT_CIRCUIT".equals(faultType)){
			
			String rcvPhonNums = (String)event.get("RCV_PHON_NUMS");
			
			StringTokenizer tokens = new StringTokenizer (rcvPhonNums, ",");
			
			while (tokens.hasMoreTokens ()) {
				String	token = tokens.nextToken ();
				event.put("RCV_PHON_NUM", token);
				adamsSession.insert("sendCircuitSms",event);
			}
		//2023-12-12 BIZ 인터넷 추가 	
		}else if("BIZ".equals(faultType)){
			String rcvPhonNums = (String)event.get("RCV_PHON_NUMS");
			
			StringTokenizer tokens = new StringTokenizer (rcvPhonNums, ",");
			
			while (tokens.hasMoreTokens ()) {
				String	token = tokens.nextToken ();
				event.put("RCV_PHON_NUM", token);
				if("CLR".equals(kind)){
					adamsSession.insert("sendBizRlseSms",event);
				}else{
					adamsSession.insert("sendBizSms",event);
				}
				
			}
		//2024-03-27 BIZ CENTER 감시 추가  		
		}else if("BIZ_CENTER".equals(faultType)){
			String rcvPhonNums = (String)event.get("RCV_PHON_NUMS");
			
			StringTokenizer tokens = new StringTokenizer (rcvPhonNums, ",");
			
			while (tokens.hasMoreTokens ()) {
				String	token = tokens.nextToken ();
				event.put("RCV_PHON_NUM", token);
				if("CLR".equals(kind)){
					adamsSession.insert("sendBizCenterRlseSms",event);
				}else{
					adamsSession.insert("sendBizCenterSms",event);
				}
				
			}
		}
		
		adamsSession.commit();
		
	}
	
	public static void main(String[] args) throws ParseException{

		Options options = new Options();
		EnvManager envManager = new EnvManager(args, options);		
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("SmsSender", envManager.getOptions());
    		System.exit(0);
    	}
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		
		SmsSender smsSender = new SmsSender(configManager);
		//SMS 저장처리
		smsSender.start();
				
		//장애 메세지 처리 
		FaultMessageHandler faultMessageHandler = new FaultMessageHandler(smsSender,configManager);		
		faultMessageHandler.start();		
		
	}
}

