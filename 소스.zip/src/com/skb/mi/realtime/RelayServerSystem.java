package com.skb.mi.realtime;

import java.io.File;
import java.net.InetSocketAddress;
import java.util.Collection;
import java.util.Hashtable;

import org.apache.commons.cli.HelpFormatter;
import org.java_websocket.WebSocket;
import org.java_websocket.framing.Framedata;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;
import org.json.simple.JSONObject;

import com.skb.mi.thread.RelayThread;
import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.OutputLog;

public class RelayServerSystem extends WebSocketServer {
	public static int		REALTIME_PORT = 59769;
	
	Hashtable<String,RelayThread> hashTable;

	OutputLog		outputLog;
	String			unmsRelayIpAddress;
	int				unmsRelayPortNo;

	public RelayServerSystem(String[] args) {
		super(new InetSocketAddress(REALTIME_PORT));
		
		outputLog = new OutputLog(true, this.getClass().getName (), EnvManager.env.getLogs());
		outputLog.write("Start !!!");

		hashTable = new Hashtable<String,RelayThread> ();
	}

	public void setUnmsRelay(String ipAddress, int portNo) {
		this.unmsRelayIpAddress = ipAddress;
		this.unmsRelayPortNo = portNo;
	}

	@Override
	public void onOpen(WebSocket conn, ClientHandshake handshake ) {
		outputLog.write(conn.getRemoteSocketAddress().getAddress().getHostAddress() + " entered the room!" );
		RelayThread relayThread = new RelayThread(conn, unmsRelayIpAddress, unmsRelayPortNo, outputLog);
		relayThread.start();
		hashTable.put(conn.toString(), relayThread);
		Collection<WebSocket> con = connections();
		outputLog.write("Client 수 : "  + con.size());
	}

	@Override
	public void onMessage(WebSocket conn, String message) {
		try {
			outputLog.write(conn + ": " + message);
			if (hashTable.get(conn.toString ()) != null) {
				RelayThread relayThread = hashTable.get (conn.toString());
				relayThread.send(message);
			}
		} catch (Exception e) {
			outputLog.write(e);
		}
	}

	@Override
	public void onFragment(WebSocket conn, Framedata fragment ) {
	}

	public static void main(String[] args) {
    	EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("RelayServerSystem", envManager.getOptions());
    		System.exit(0);
    	}
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		try {
			int portNo = Integer.parseInt(configManager.getConfig(Constants.RELAY_SERVER, Constants.PORT_NO));
			RelayServerSystem.REALTIME_PORT = portNo;
		} catch (Exception e) {
			e.printStackTrace();
		}

		RelayServerSystem s = null;
		try {
			s = new RelayServerSystem(args);
			String ipAddress = configManager.getConfig(Constants.UNMS_RELAY, Constants.IP_ADDRESS);
			int portNo = Integer.parseInt(configManager.getConfig(Constants.UNMS_RELAY, Constants.PORT_NO));
			s.setUnmsRelay(ipAddress, portNo);
			s.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onClose(WebSocket conn, int code, String reason, boolean remote) {
		outputLog.write(String.format("%s is closed. (%d),(%s),(%s)", conn, code, reason, remote));
		if (hashTable.get(conn.toString()) != null)
			hashTable.remove(conn.toString());
		Collection<WebSocket> con = connections();
		outputLog.write("Client 수 : "  + con.size());
	}
	
	@Override
	public void onError(WebSocket conn, Exception ex) {
		outputLog.write(ex);
	}

	@Override
	public void onStart() {
	}

	/**
	 * Sends <var>text</var> to all currently connected WebSocket clients.
	 * 
	 * @param text
	 *            The String to send across the network.
	 * @throws InterruptedException
	 *             When socket related I/O errors occur.
	 */
	public void sendToAll(WebSocket source, String text) {
	}

	public void sendToAll(String text, JSONObject jsonObject) {
		Collection<WebSocket> con = connections();
		synchronized(con) {
			for(WebSocket c : con) {
				c.send(text);
			}
		}
	}	
}
