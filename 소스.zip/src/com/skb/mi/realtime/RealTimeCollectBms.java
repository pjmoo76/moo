package com.skb.mi.realtime;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.LinkedList;

import org.apache.commons.cli.HelpFormatter;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.DBController;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.OutputLog;

public class RealTimeCollectBms {
	final private byte			IDENTIFIER		  		= 0x1f;
	final private byte			ESC		  				= 0x1b;
	final private byte			STX		  				= 0x02;
	final private byte			ETX		  				= 0x03;
	final private int 			EVENT_CODE 				= 'E';
	final private int 			CLEAR_CODE 				= 'U';
	final private int 			BUFFER_SIZE 			= 16386;
	final private int			MAX_COLUMN				= 39;

    final private String        SERVICE_CODE_0411   	= "0411"; // 0415: 장비 장애
    final private String        SERVICE_CODE_0413   	= "0413"; // 0413: 장애 해제
    final private String        SERVICE_CODE_0415   	= "0415"; // 0415: 회선 장애
    final private String        SERVICE_CODE_0416   	= "0416"; // 0416: 링 장애
    final private String        SERVICE_CODE_0450   	= "0450"; // 0450: 수동 해제

	final private String		NMS_CD 					= "009";	// OCO20101 테이블에 있음.
	final private String		NMS_NM 					= "B2B"; //BMS(IP) -> B2B

	final private String		NET_CL_CD 				= "05";		// IP
	final private String		NET_CL_NM 				= "IP";	// IP

	final private String		EQUIP_FAULT				= "01";
    final private String        EQUIP_DABL_LCL_NM   	= "장비장애";
    final private String        EQUIP_DABL_MCL_CD   	= "01502"; // 01202 --> 01502
    final private String        EQUIP_DABL_MCL_NM   	= "BMS장비장애";
    final private String        EQUIP_DABL_CD       	= "015002"; // 012002 --> 015002
    final private String        EQUIP_DABL_NM       	= "BMS장비장애";

	final private String		TRANS_FAULT				= "04";
    final private String        TRANS_DABL_LCL_NM   	= "회선장애";
    final private String        TRANS_DABL_MCL_CD   	= "04501"; // 04202 --> 04501
    final private String        TRANS_DABL_MCL_NM   	= "BMS회선장애";
    final private String        TRANS_DABL_CD       	= "045001"; // 042002 --> 045001
    final private String        TRANS_DABL_NM       	= "BMS회선장애";

    final private String        GENERATE_EVENT      	= "GEN";
    final private String        CLEAR_EVENT         	= "CLR";

    final private String        GENERATED_FAULT_NM  	= "장애중";
    final private String        CLEARED_FAULT_NM    	= "장애해제";

    final private String        GENERATED_FAULT_CD  	= "01";
    final private String        CLEARED_FAULT_CD    	= "02";

	final private int			SO_TIME_OUT	= (1000*60*10);	// Time-Out 10분 설정

	String						ipAddress;
	int							portNo;

	DBController				dbController;
	String						dbUrl, userName, password;

	byte []						buffer;
	int							bufferFront, bufferRear;
	int							maxColumn;
    
	int                         smsChkCnt; //timeout check count
	
	Socket						socket;
	InputStream					inputStream;
	OutputStream				outputStream;

    // Push Processore 정보
	Socket                      pushSocket;
    InputStream                 pushInputStream;
    OutputStream                pushOutputStream;
    String                      pushIpAddress;
    int                         pushPortNo;

    LinkedList<JSONObject>      notSendJson;
    JSONObject                  jsonObject;

	Hashtable<String,String>	hashTable;

	String						absolutePath;
	String						pgmId;

	OutputLog					outputLog;
	
	long 						OriginTime;

    public RealTimeCollectBms (String[] args) {
		absolutePath = EnvManager.env.getHome();

        outputLog = new OutputLog (true, this.getClass ().getName (), EnvManager.env.getLogs());
		outputLog.write ("Start : " + getDateSecond ());
		outputLog.write ("Commit Version : 2020-11-19 commit");

        notSendJson = new LinkedList<JSONObject>();
		hashTable = new Hashtable<String,String>();
		OriginTime = System.currentTimeMillis()/(1000*60);
		try {
			//readDbInfo ();
			
			String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
			ConfigManager configManager = new ConfigManager(cfgFile);
			dbUrl = configManager.getConfig(Constants.ADAMS_DB, Constants.DB_URL);
			userName = configManager.getConfig(Constants.ADAMS_DB, Constants.USER_NAME);
			password = configManager.getConfig(Constants.ADAMS_DB, Constants.PASSWORD);
			ipAddress = configManager.getConfig(Constants.BMS, Constants.IP_ADDRESS);
			portNo = Integer.parseInt(configManager.getConfig(Constants.BMS, Constants.PORT_NO));
			pushIpAddress = configManager.getConfig(Constants.WEB_PUSH, Constants.IP_ADDRESS);
			pushPortNo = Integer.parseInt(configManager.getConfig(Constants.WEB_PUSH, Constants.PORT_NO));

			outputLog.write("dbUrl : " + dbUrl);
			outputLog.write("userName : " + userName);
			outputLog.write("password : " + password);
			outputLog.write("ipAddress : " + ipAddress);
			outputLog.write("portNo : " + portNo);
			outputLog.write("pushIpAddress : " + pushIpAddress);
			outputLog.write("pushPortNo : " + pushPortNo);

/**
			dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
            InetAddress local = InetAddress.getLocalHost ();
            String  ip = local.getHostAddress ();
			ResultSet resultSet = dbController.selectProgramInfo (this.getClass().getName (), ip);
			if (resultSet.next ()) {
				pgmId = resultSet.getString (1);
                String  pgmUseYn = resultSet.getString (2);
                String  pgmStCd = resultSet.getString (3);
                resultSet.close ();

                outputLog.write ("pgmId : " + pgmId + ", pgmUseYn : " + pgmUseYn + ", pgmStCd : " + pgmStCd);
                // 프로세스 Use Y/N 검사
                if (pgmUseYn.equals ("N"))
                    exitProcess (false, "");
                // 프로세스 동작중인지 검사
               	 if (pgmStCd.equals ("S"))       // 동작중이면 바로 종료
                    exitProcess (false, "");
                else                            // 동작이 종료되어 있는 경우
                    dbController.insertProcessHistory(pgmId, "프로세스가 시작되었습니다", "S", "Y");
                outputLog.write ("프로세스가 시작되었습니다.");
            } else {
                dbController.insertProcessHistory(pgmId, "프로세스가 시작되었습니다", "S", "Y");
                exitProcess (true, "프로세스를 찾을 수 없습니다.");
            }
**/
        } catch (Exception e ) {
			outputLog.write (e);
        }

		/*
		try {
			readBmsEquipInfo ();
			readPushInfo ();
		} catch (Exception e ) {
			outputLog.write ("ReadBMSInfo Error : " + e);
			exitProcess (true, "BMS정보를 읽을 수 없습니다");
		}
		*/

        try {
			buffer = new byte [BUFFER_SIZE];

			inputStream = null;
			outputStream = null;

			connectNms ();

/*
			KeepAliveBms keepAliveBms = new KeepAliveBms (outputStream, this);
			keepAliveBms.start ();
*/
			//TEST 2022-11-22 강대윤
//			String json = "{\"SUP_EQUIP_NM1\":\"000651217108\",\"SUP_EQUIP_ID1\":\"000651217108\",\"EQUIP_MDL_NM\":\"NP-2000\",\"OCCR_DTM\":\"20221121171000\",\"EQUIP_IP_ADDR\":\"118.221.227.118\",\"LINE_CL_CD\":\"A001\",\"LINE_NUM\":\"000000225333\",\"DABL_DESC\":\"인터페이스 링크 Down\",\"DABL_GR_CD\":\"05\",\"CHRGR_NM\":\"박*원\",\"DABL_MCL_CD\":\"04501\",\"EQUIP_NM\":\"주식회사 신한은행\",\"MODULE_EQUIP_ID\":\"0\",\"NMS_NM\":\"B2B\",\"NET_CL_NM\":\"IP\",\"DABL_LCL_NM\":\"회선장애\",\"OCCR_RCV_DTM\":\"20221122095548\",\"MGMT_TPO_NM\":\"제주 신제주\",\"INFO_CNTR_CD\":\"N02808\",\"LINE_CL_NM\":\"기업관리A\",\"DABL_OCCR_LOC_DESC\":\"port4\",\"MSC_MODULE_NM\":\"\",\"SUB_TPO_CD\":\"N02808\",\"kind\":\"GEN\",\"CUST_NM\":\"주식회사 신한은행\",\"CHRGR_ID\":\"1002457\",\"TPO_CD\":\"N02808\",\"DABL_NM\":\"BMS회선장애\",\"NET_CL_CD\":\"05\",\"DABL_LCL_CD\":\"04\",\"CUST_NUM\":\"9880000219\",\"DISTB_CNTR_NM\":\"제주 신제주\",\"DABL_ST_NM\":\"장애중\",\"EQUIP_DABL_MSG_CTT\":\"인터페이스 링크 Down\",\"LINE_NM\":\"(주)신한 은행\",\"INFO_CNTR_NM\":\"제주 신제주\",\"DABL_CD\":\"045001\",\"SUB_TPO_NM\":\"제주 신제주\",\"SUP_TPO_CD\":\"N02808\",\"ROUT_NUM\":\"\",\"SPEED_NM\":\"10Mbps\",\"TPO_NM\":\"제주 신제주\",\"MODULE_EQUIP_NM\":\"\",\"PORT_NO\":\"-1\",\"SVC_MGMT_NUM\":\"7133005738\",\"DABL_ST_CD\":\"01\",\"CUST_CHRTIC_CD\":\"SPCXA\",\"SVC_TECH_MTHD_NM\":\"프리밴(FTTx)\",\"EQUIP_TID_VAL\":\"\",\"EQUIP_MDL_CD\":\"A000100721\",\"SUP_TPO_NM\":\"제주 신제주\",\"SPEED_CD\":\"I5\",\"EQUIP_ID\":\"000637937332\",\"DABL_MCL_NM\":\"BMS회선장애\",\"NMS_CD\":\"009\",\"CUST_CHRTIC_NM\":\"기업관리A\",\"NMS_DABL_NUM_CTT\":\"41517537\",\"SVC_TECH_MTHD_CD\":\"H0011\",\"MGMT_TPO_CD\":\"N02808\"}";
//	    	JSONParser jsonParser = new JSONParser();
//	    	JSONObject jsonObject = (JSONObject) jsonParser.parse(json);
//	    	
//	    	notSendJson.add(jsonObject);
//	    	outputLog.write("send : " + jsonObject);
	    	//sendJson();
			realTimeCollect ();
            
            outputStream.close ();
            inputStream.close ();
            socket.close ();
        } catch (Exception e) {
			exitProcess (true, "Socket Open Exception : " + e);
        }
		exitProcess (true, "Finish : " + getDateSecond ());
    }

    public void exitProcess (boolean check, String clctRsltCtt) {
        if (check) {
            try {
                dbController.insertProcessHistory(pgmId, clctRsltCtt, "F", "Y");
            } catch (Exception e) {
                outputLog.write ("exitProcess () Exception : " + e);
            }
        }
        outputLog.write (clctRsltCtt);
        outputLog.close ();
        dbController.closeDB ();
        try {
            outputStream.close ();
            inputStream.close ();
            socket.close ();
        } catch (Exception e) {
        }
        outputLog.write ("Finish : " + getDateSecond ());
        System.exit (0);
    }

	public void connectNms () {
		outputLog.write ("connecting NMS");
        boolean check = false;
        while (!check) {
            try {
            	try {
            		if (inputStream != null) {
            			inputStream.close();
                    	inputStream = null;            		
            		}
            	} catch (Exception e) {
                	inputStream = null;            		
            	}
            	try {
            		if (socket != null) socket.close();
                	socket = null;            		
            	} catch (Exception e) {
                	socket = null;            		
            	}

            	socket = new Socket (ipAddress, portNo);
                socket.setSoTimeout(SO_TIME_OUT);
                inputStream = socket.getInputStream();
                outputStream = socket.getOutputStream ();
                bufferFront = bufferRear = 0;

//				check = sendLoginPacket ();

				check = true;

            } catch (Exception e) {
                outputLog.write ("[" + getDateSecond () + "] Socket Open Error : " + e);
                sleep (100);            // 0.1초
            }
        }
        outputLog.write ("connected NMS");
	}

	/*
	public void readDbInfo () throws Exception {
		String	oneLine;
		FileReader	fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + "db.info");
		BufferedReader bufferedReader = new BufferedReader (fileReader);
		dbUrl = bufferedReader.readLine ();
		userName = bufferedReader.readLine ();
		password = bufferedReader.readLine ();
		bufferedReader.close ();
		fileReader.close ();
//		outputLog.write ("Url : " + dbUrl);
//		outputLog.write ("userName : " + userName);
//		outputLog.write ("password : " + password);
	}

	public void readBmsEquipInfo () throws Exception {
		String	oneLine;
		FileReader	fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + "bms.info");
		BufferedReader bufferedReader = new BufferedReader (fileReader);
		ipAddress = bufferedReader.readLine ();
		portNo = Integer.parseInt (bufferedReader.readLine ());	
		bufferedReader.close ();
		fileReader.close ();
	}

    // Push Processor IP Address와 포트 정보 조회
    public void readPushInfo () throws Exception {
        FileReader  fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + "push.info");
        BufferedReader bufferedReader = new BufferedReader (fileReader);
        pushIpAddress = bufferedReader.readLine ();
        pushPortNo = Integer.parseInt (bufferedReader.readLine ());
        bufferedReader.close ();
        fileReader.close ();
    }
    */

    public void realTimeCollect () {
		int		count, index, messageLength, messageOrder;
		byte	oneByte;
		byte []	tempBytes;
		String	token, nmsType, serviceCode;
		smsChkCnt = 0;
    	while (true) {
			jsonObject = new JSONObject ();
			try {
                /* ESC 검사  */
				outputLog.write ("ESC.....");
                if (getOneByte () != ESC)
                    continue;

                /* STX 검사 */
				outputLog.write ("STX.....");
                if (getOneByte () != STX)
                    continue;

                /* PDU 종류 검사 */
				outputLog.write ("PDU Kind.....");
                oneByte = getOneByte ();
                if (oneByte != '1'
                 && oneByte != '2'
                 && oneByte != '3'){    /* '1'은 Event, '2'는 Request, '3'은 Response */
                    continue;
                }

                /* 서비스 코드 검사 */
				outputLog.write ("Service Code.....");
                tempBytes = getBytes (4);
                if (tempBytes == null)
                    continue;
                serviceCode = new String (tempBytes);
                tempBytes = null;

                /* 메시지 일련번호 검사 */
				outputLog.write ("Message Serial.....");
                tempBytes = getBytes (2);
                if (tempBytes == null)
                    continue;
                messageOrder = Integer.parseInt (new String (tempBytes));
//				outputLog.write ("messageOrder : " + messageOrder);
                tempBytes = null;

				outputLog.write ("Skip.....");
                getOneByte ();      /* 마지막 메시지 검사는 Skip */

                /* 응답 결과 검사  */
				outputLog.write ("Response Test.....");
                oneByte = getOneByte ();
                if (oneByte != '0' && oneByte != '1')
                    continue;

				outputLog.write ("Expand Area.....");
                tempBytes = getBytes (4);       /* 확장 영역 Skip */
                tempBytes = null;

                /* 메시지 데이터 길이 */
                tempBytes = getBytes (5);
                messageLength = Integer.parseInt(new String (tempBytes));
                tempBytes = null;
				outputLog.write ("messageLength : " + messageLength);

				/* 메시지 데이터 */
				for (count = 1; count <= MAX_COLUMN; ++ count) {
					token = getBytes ();
					if (token == null)
						break;
					token = token.trim ();
					outputLog.write ("Count : " + count + ", token : " + token + ".....");
					hashTable.put ("Field" + count, token);
				}
				outputLog.write ("");
				outputLog.write ("");
				outputLog.write ("");

				outputLog.write ("ServiceCode : " + serviceCode);
				jsonObject.put ("NMS_CD", NMS_CD);
				if (serviceCode.equals (SERVICE_CODE_0413)) {			// 장애 해제
					jsonObject.put ("kind", CLEAR_EVENT);
                    jsonObject.put ("DABL_ST_CD", CLEARED_FAULT_CD);
                    jsonObject.put ("DABL_ST_NM", CLEARED_FAULT_NM);
                    jsonObject.put ("RLSE_DTM", hashTable.get ("Field1"));
                    jsonObject.put ("RLSE_RCV_DTM", getDateTime ());
                    jsonObject.put ("NMS_DABL_NUM_CTT", hashTable.get ("Field2"));
				} else if (serviceCode.equals (SERVICE_CODE_0411)) {
					dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
					jsonObject.put ("EQUIP_ID", "*****");
                    jsonObject.put ("DABL_OCCR_LOC_DESC", hashTable.get ("Field19"));                         
                    jsonObject.put ("kind", GENERATE_EVENT);
                    jsonObject.put ("DABL_ST_CD", GENERATED_FAULT_CD);
                    jsonObject.put ("DABL_ST_NM", GENERATED_FAULT_NM);
                    jsonObject.put ("NMS_NM", NMS_NM);
                    jsonObject.put ("NMS_DABL_NUM_CTT", hashTable.get ("Field1"));
                    jsonObject.put ("EQUIP_TID_VAL", hashTable.get ("Field3"));
                    
                    // 2022-11-21 B2B 상위장비,장비 매핑  
					
                    String query = selectB2bDabl (hashTable.get ("Field1"));
					ResultSet resultSet = dbController.getStmt ().executeQuery (query);
					if (resultSet.next ()) {
						jsonObject.put ("EQUIP_ID", resultSet.getString (1));
						jsonObject.put ("SUP_EQUIP_ID1", resultSet.getString (2));
						jsonObject.put ("SUP_EQUIP_NM1", resultSet.getString (3));							
						jsonObject.put ("SUP_EQUIP_NM", resultSet.getString (3));						
					}
					
					resultSet.close ();	
					String field39 = hashTable.get ("Field39");
					outputLog.write ("Field39 : " + field39 + "...........");
					if (field39 == null || field39.equals ("")) {
						jsonObject.put ("DABL_LCL_CD", EQUIP_FAULT);
						jsonObject.put ("DABL_LCL_NM", EQUIP_DABL_LCL_NM);
						jsonObject.put ("DABL_MCL_CD", EQUIP_DABL_MCL_CD);
						jsonObject.put ("DABL_MCL_NM", EQUIP_DABL_MCL_NM);
						jsonObject.put ("DABL_CD", EQUIP_DABL_CD);
						jsonObject.put ("DABL_NM", EQUIP_DABL_NM);
					} else {
						
						// Field39 값이 null, 공백이 아니면서 문자열 M 으로 시작할 때, M->9 치환해서 저장함
						// 2020-11-16
						if (field39.indexOf("M") > 0) {
							outputLog.write ("[예외발생. 첫 자리가 아닌 곳에 문자열 M 발생.]Field39 : " + field39 + "...........");
						} else if (field39.indexOf("M") == 0) {
							// M -> 9 치환해서 저장
							hashTable.put("Field39", field39.replace("M", "9"));
							outputLog.write ("[변경]Field39 : " + hashTable.get ("Field39") + "...........");
						}
						
						jsonObject.put ("DABL_LCL_CD", TRANS_FAULT);
						jsonObject.put ("DABL_LCL_NM", TRANS_DABL_LCL_NM);
						jsonObject.put ("DABL_MCL_CD", TRANS_DABL_MCL_CD);
						jsonObject.put ("DABL_MCL_NM", TRANS_DABL_MCL_NM);
						jsonObject.put ("DABL_CD", TRANS_DABL_CD);
						jsonObject.put ("DABL_NM", TRANS_DABL_NM);
						query = selectCustInfo ();
						outputLog.write ("selectCustInfo : " + query);
						resultSet = dbController.getStmt ().executeQuery (query);
						if (resultSet.next ()) {
							jsonObject.put ("LINE_NUM", resultSet.getString (1));
							jsonObject.put ("LINE_CL_CD", resultSet.getString (2));
							jsonObject.put ("LINE_CL_NM", resultSet.getString (3));
							jsonObject.put ("SVC_TECH_MTHD_CD", resultSet.getString (4));
							jsonObject.put ("SVC_TECH_MTHD_NM", resultSet.getString (5));
							jsonObject.put ("SUP_TPO_CD", resultSet.getString (6));
							jsonObject.put ("SUP_TPO_NM", resultSet.getString (7));
							jsonObject.put ("SUB_TPO_CD", resultSet.getString (8));
							jsonObject.put ("SUB_TPO_NM", resultSet.getString (9));
							jsonObject.put ("SPEED_CD", resultSet.getString (10));
							jsonObject.put ("SPEED_NM", resultSet.getString (11));
							jsonObject.put ("LINE_NM", resultSet.getString (12));
							jsonObject.put ("CUST_CHRTIC_CD", resultSet.getString (13));
							jsonObject.put ("CUST_CHRTIC_NM", resultSet.getString (14));
							jsonObject.put ("CUST_NUM", resultSet.getString (15));
						} else {
							jsonObject.put ("LINE_CL_NM", "일반회선");
                        }
						resultSet.close ();
						
						query = selectAmInfo ();
						outputLog.write ("selectAmInfo : " + query);
						resultSet = dbController.getStmt ().executeQuery (query);
						if (resultSet.next ()) {
							jsonObject.put ("CHRGR_ID", resultSet.getString (1));
							jsonObject.put ("CHRGR_NM", resultSet.getString (2));							
						}
						
						resultSet.close ();
						
						jsonObject.put ("SVC_MGMT_NUM", hashTable.get ("Field39"));
						if (hashTable.get ("Field5") == null)
							jsonObject.put ("CUST_NM", hashTable.get ("***"));
						else
							jsonObject.put ("CUST_NM", hashTable.get ("Field5"));
						query = selectInfoCntrCd (hashTable.get ("Field32"));
						resultSet = dbController.getStmt ().executeQuery (query);
						jsonObject.put ("MGMT_TPO_NM", hashTable.get ("Field32"));
						jsonObject.put ("TPO_NM", hashTable.get ("Field32"));
						jsonObject.put ("INFO_CNTR_NM", hashTable.get ("Field32"));
						jsonObject.put ("DISTB_CNTR_NM", hashTable.get ("Field32"));
						jsonObject.put ("TPO_NM", hashTable.get ("Field32"));
						jsonObject.put ("MGMT_TPO_CD", "");
						jsonObject.put ("TPO_CD", "");
						if (resultSet.next ()) {
							jsonObject.put ("MGMT_TPO_CD", resultSet.getString (1));
							jsonObject.put ("TPO_CD", resultSet.getString (1));
							jsonObject.put ("INFO_CNTR_CD", resultSet.getString (1));
							resultSet.close ();
						}
						
						
						
						
					}
					
				
					
					
                    jsonObject.put ("EQUIP_IP_ADDR", hashTable.get ("Field4"));
                    jsonObject.put ("EQUIP_NM", hashTable.get ("Field5"));
                    jsonObject.put ("EQUIP_MDL_CD", hashTable.get ("Field6"));
                    jsonObject.put ("EQUIP_MDL_NM", hashTable.get ("Field7"));
                    jsonObject.put ("DABL_OCCR_LOC_DESC", hashTable.get ("Field8"));
                    jsonObject.put ("DABL_DESC", hashTable.get ("Field9"));
                    jsonObject.put ("EQUIP_DABL_MSG_CTT", hashTable.get ("Field10"));
                    jsonObject.put ("MSC_MODULE_NM", hashTable.get ("Field16"));
                    jsonObject.put ("MODULE_EQUIP_ID", hashTable.get ("Field17"));
                    jsonObject.put ("MODULE_EQUIP_NM", hashTable.get ("Field18"));
                    jsonObject.put ("PORT_NO", hashTable.get ("Field20"));
                    jsonObject.put ("ROUT_NUM", hashTable.get ("Field24"));
                    jsonObject.put ("OCCR_DTM", hashTable.get ("Field27"));
                    jsonObject.put ("OCCR_RCV_DTM", getDateTime ());
                    jsonObject.put ("NET_CL_CD", NET_CL_CD);
                    jsonObject.put ("NET_CL_NM", NET_CL_NM);

					token = hashTable.get ("Field13");
					if (token.equals ("1"))				// Critical
						token = "05";					// Adams Critical
					else if (token.equals ("2"))		// Major
						token = "04";					// Adams Major
					else if (token.equals ("3"))		// minor	
						token = "03";					// Adams minor
					else if (token.equals ("4"))		// warning
						token = "02";					// Adams warning
					else
						token = "01";					// Adams Info
					jsonObject.put ("DABL_GR_CD", token);
                    dbController.closeDB ();
				}
				outputLog.write (jsonObject.toJSONString ());

				notSendJson.add (jsonObject);

				smsChkCnt = 0;
				
				sendJson ();

			} catch (Exception e) {
				outputLog.write (e);
			}
			hashTable.clear ();
    	}
    }

	public String selectInfoCntrCd (String tpoNm) {
		return  "SELECT "
			  + " TPO_CD "
			  + " FROM OIV10300"
			  + " WHERE TPO_NM='" + tpoNm + "'"
			  + " ORDER BY TPO_TYP_CD ";
		
	}
	
	public String selectB2bDabl (String dablNum) {
		return  "SELECT "
			  + " A.EQUIP_ID , A.LINK_EQUIP_ID, B.EQUIP_NM "
			  + " FROM OMN33702 A "
			  + " , OIV10100 B "			  
			  + " WHERE A.LINK_EQUIP_ID = B.EQUIP_ID(+) AND  B2B_DABL_NUM='" + dablNum + "'";
			 
		
	}

	public String selectCustInfo () {
		return   "SELECT"
			   + "    A.LINE_NUM"
			   + "	, A.LINE_CL_CD"
			   + "  , NVL((SELECT COMM_CD_VAL_NM FROM OCO20101 WHERE COMM_CD='CUST_CHRTIC_CD' AND COMM_CD_VAL=F.CUST_CHRTIC_CD), '일반회선')"
			   + "	, A.SVC_TECH_MTHD_CD AS SVC_TECH_MTHD_CD"
			   + "	, C.SVC_TECH_MTHD_NM AS SVC_TECH_MTHD_NM"
			   + "	, A.SUP_TPO_CD AS SUP_TPO_CD"
			   + "	, D.TPO_NM AS SUP_TPO_NM"
			   + "	, A.SUB_TPO_CD AS SUB_TPO_CD"
			   + "	, E.TPO_NM AS SUP_TPO_NM"
			   + "	, F.APPL_SPEED_CD AS SPEED_CD"
			   + "	, (SELECT B.COMM_CD_VAL_NM FROM OCO20101 B WHERE F.APPL_SPEED_CD = B.COMM_CD_VAL AND B.COMM_CD = 'SPEED_CD') AS SPEED_CD_NM"
			   + "	, A.LINE_NM AS LINE_NM"
			   + "	, F.CUST_CHRTIC_CD"
			   + "	, NVL((SELECT COMM_CD_VAL_NM FROM OCO20101 WHERE COMM_CD='CUST_CHRTIC_CD' AND COMM_CD_VAL=F.CUST_CHRTIC_CD), '일반회선') AS CUST_CHRTIC_NM"
			   + "	, NVL((SELECT TO_NUMBER(SUBSTR(MAX(TO_CHAR(M.AUDIT_DTM, 'YYYYMMDD') || M.CUST_NUM), -10)) FROM OES10101 M WHERE M.SVC_MGMT_NUM = A.SVC_MGMT_NUM),(SELECT M.CUST_NUM FROM OES10103 M WHERE M.SVC_MGMT_NUM = A.SVC_MGMT_NUM)) AS CUST_NUM"
			   + "	FROM OIV10600 A, OCO20101 B, OES10400 C, OIV10300 D, OIV10300 E, OIV10602 F"
			   + "	WHERE A.SVC_MGMT_NUM = " + hashTable.get ("Field39")
			   + "	AND   A.LINE_NUM = F.LINE_NUM(+)"
			   + "	AND   A.LINE_CL_CD = B.COMM_CD_VAL(+)"
			   + "	AND   B.COMM_CD = 'LINE_CL_CD'"
			   + "	AND   A.SVC_TECH_MTHD_CD = C.SVC_TECH_MTHD_CD(+)"
			   + "	AND   A.SUP_TPO_CD = D.TPO_CD(+)"
			   + "	AND   A.SUP_TPO_CD = E.TPO_CD(+)";
	}
	public String selectAmInfo () {
		return "SELECT" 
			  +"  A.AM_ID  AS CHRGR_ID"
			  +" ,SUBSTR(USER_NM,1,1) || LPAD('*',LENGTH(USER_NM)-2,'*') || SUBSTR(USER_NM, LENGTH(USER_NM), 1) AS CHRGR_NM"
		      +"  FROM OQA80232 A"
		      +"      ,OCO10108 B"
		      +"  WHERE A.AM_ID = B.SWING_USER_ID(+)"
		      +"    AND A.SVC_MGMT_NUM = " + hashTable.get ("Field39");
	}
	
	//ics
    public PreparedStatement saveSmsErrMsgInfo(String errMsg) throws Exception {
        String	query;
    	query = "merge into TBL_SUBMIT_QUEUE t "
		       + "using ( "
		       + "SELECT	TBL.* "
		       + "	,	(CASE WHEN LENGTHB(TBL.SND_MSG)<80 THEN '00' ELSE '10'  END) as USED_CD "
		       + "	,	(CASE WHEN LENGTHB(TBL.SND_MSG)<80 THEN 0 ELSE 1  END) as CONTENT_CNT "
		       + "FROM ( "
		       + "select null as CMP_MSG_ID "
		       + "  ,  'CO' as CMP_MSG_GROUP_ID "
		       + "  , '5464' as USR_ID "
		       + "  , '1' as SMS_GB "
		       /*+ "  , '00' as USED_CD "*/
		       + "  , 'I' as RESERVED_FG "
		       + "  , to_char(sysdate,'YYYYMMDDHH24MISS') as RESERVED_DTTM "
		       + "  , '0' as SAVED_FG "
		       + "  , replace(a.PHON_NUM,'-','') as RCV_PHN_ID "
		       + "  , '07078051228' as SND_PHN_ID "
		       + "  , '82' as NAT_CD "
		       + "  , '00000' as ASSIGN_CD "
		       + "  , 'text/plain' as CONTENT_MIME_TYPE "
		       + "  , '[ADAMS][W]'||CHR(10)"
		       + "	||'[발생시각] '||TO_CHAR(SYSDATE, 'YYYY/MM/DD HH24:MI')||CHR(10)"
		       + "	||'[장애내용] '|| ? ||CHR(10)"
		       + "	||'[장애조치] 연속 발생시 로그 및 프로세스 확인'||CHR(10)"
		       + "	||'※관련 운용자는 확인 후 신속한 대응(장애대응 단톡방 운영) 바랍니다.' as SND_MSG "
		       + "from ( "
		       + "     SELECT USER_NM AS NM, USER_PHON_NUM AS PHON_NUM	FROM OCO40291 "
		       + "     WHERE MSG_TRMS_ID IN ('DEFTL001', 'DEFTL004','DEFTL020') AND USER_TYP_CD = 'RCV' "		       
		       + "   ) a "
		       + "   ) TBL "
		       + ") s "
		       + "on (t.CMP_MSG_ID = s.CMP_MSG_ID) "
		       + "when not matched then "
			   + " INSERT ("
			   + "  CMP_MSG_ID"
			   + ", CMP_MSG_GROUP_ID"
			   + ", USR_ID"
			   + ", SMS_GB"
			   + ", USED_CD"
			   + ", RESERVED_FG"
			   + ", RESERVED_DTTM"
			   + ", SAVED_FG"
			   + ", RCV_PHN_ID"
			   + ", SND_PHN_ID"
			   + ", NAT_CD"
			   + ", ASSIGN_CD"
			   + ", CONTENT_CNT"
			   + ", CONTENT_MIME_TYPE"
			   + ", SND_MSG"
			   + ") VALUES ("
			   + "  MI_APP.TBL_SUBMIT_QUEUE_SEQ.NEXTVAL"
			   + ", s.CMP_MSG_GROUP_ID"
			   + ", s.USR_ID"
			   + ", s.SMS_GB"
			   + ", s.USED_CD"
			   + ", s.RESERVED_FG"
			   + ", s.RESERVED_DTTM"
			   + ", s.SAVED_FG"
			   + ", s.RCV_PHN_ID"
			   + ", s.SND_PHN_ID"
			   + ", s.NAT_CD"
			   + ", s.ASSIGN_CD"
			   + ", s.CONTENT_CNT"
			   + ", s.CONTENT_MIME_TYPE"
			   + ", s.SND_MSG )"
         ;
    	outputLog.write ("query=" + query);
    	
    	PreparedStatement stmt = dbController.prepareStatement(query);
    	stmt.setString(1, errMsg);
    	
    	return stmt;
    }
	
    public byte[] makeSendBuffer (byte [] temp) {
    	
    	byte[] sendBuffer = new byte[temp.length + 1];
		System.arraycopy(temp, 0, sendBuffer, 0, temp.length);
		sendBuffer[temp.length] = ETX;
		return sendBuffer;
		
        
    }

    public void sendJson () {
        JSONObject  obj;
        int size = notSendJson.size ();
        outputLog.write ("sendJson () ================ 보내야할 JSON 수 : " + size);
        try {
        	if (pushOutputStream == null) {
        		 pushSocket = new Socket (pushIpAddress, pushPortNo);
                 pushOutputStream = pushSocket.getOutputStream ();
        	}
           
            for (int index = 0; index < size; ++ index) {
                obj = notSendJson.get (0);
                pushOutputStream.write (makeSendBuffer (obj.toJSONString().getBytes()));
                //pushOutputStream.flush ();                
                outputLog.write (obj.toJSONString ());
                notSendJson.remove (0);
				sleep (50);
            }
            //pushOutputStream.flush ();
        } catch (Exception e) {
            outputLog.write ("sendJson () ======== sendJson 연결 에러 ============ " + e);
            closePushSocket();
			
        }finally{
        	
        }
		
    }

	public String getDateSecond () {
		Calendar	calendar = Calendar.getInstance ();

		return String.format ("%04d-%02d-%02d %02d:%02d:%02d",
			calendar.get(Calendar.YEAR),
			calendar.get(Calendar.MONTH) + 1,
			calendar.get(Calendar.DAY_OF_MONTH),
			calendar.get(Calendar.HOUR_OF_DAY),
			calendar.get(Calendar.MINUTE),
			calendar.get(Calendar.SECOND));
	}

    public void printHexaCode (int length, byte[] buffer) {
		int count = 0;
		outputLog.write ("[" + getDateSecond () + "] length = " + length);
    	for (int index = 0; index < length; ++ index) {
/*
			if (buffer [index] == ESC)
				outputLog.write ();
*/
			if (count++ % 20 == 0)
				outputLog.write ("\n");
    		System.out.printf ("%02x.", buffer [index]);
		}
    	outputLog.write ("\n");
    }
    
/*
	public boolean sendLoginPacket () {
		int		count;
		byte [] bodyPacket;
		byte [] login = {'N', 'm', 's', 'C', 'o', 'n', 'n', 'e', 'c', 't'};
		byte [] password = {'N', 'm', 's', 'C', 'o', 'n', 'n', 'e', 'c', 't'};

		byte [] loginPacket = new byte [1 + 1 + 4 + login.length + password.length];
		byte [] recvPacket = new byte [100];

		boolean check = false;

		outputLog.write ("[" + getDateSecond () + "] Send Login/Password --------------------");
		int		index = 0;

		loginPacket [index ++] = 0x00;				// Version
		loginPacket [index ++] = 'A';				// 인증 요청

		// Body 길이
		loginPacket [index ++] = 0x00;
		loginPacket [index ++] = 0x00;
		loginPacket [index ++] = 0x00;
		loginPacket [index ++] = 0x42;				// login길이(21) + password길이(21)

		// login 복사
		for (int i = 0; i < login.length; ++ i)
			loginPacket [index ++] = login [i];

		// password 복사
		for (int i = 0; i < password.length; ++ i)
			loginPacket [index ++] = password [i];

		try {
			outputStream.write (loginPacket);
			printHexaCode (loginPacket.length, loginPacket);
			count = inputStream.read (recvPacket);
			printHexaCode (count, recvPacket);
			check = true;
			outputLog.write ("recvPacket [1] = " + recvPacket [1]);
			if (recvPacket [1] == 'a') {			// 인증 응답
				// 응답이 200인 경우만 성공한 것임.
			}
		} catch (Exception e) {
			outputLog.write ("sendLoginPacket Error : " + e);
			check = false;
		}
		return check;
	}
*/
    public byte getOneByte () {
        while (true) {
            try {
                if (bufferRear <= bufferFront) {
                    bufferFront = 0;
                    bufferRear = inputStream.read (buffer);
                }
                if (bufferRear != -1) {
                    return buffer [bufferFront ++];
                } else {
                    outputLog.write ("getOneByte () Exception : length = " + bufferFront);
                    inputStream.close ();
                    outputStream.close ();
                    socket.close ();
                    connectNms ();
                }
            } catch (Exception e) {
                try {
                    outputLog.write ("getOneByte () Exception : " + e);
                    
                    long time = System.currentTimeMillis()/(1000*60);
                	
                		//15분이내로 발생시 메세지 발송
                		if (time-OriginTime <= 15) {
                			/*msg 보내기*/
                			dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
    	        			PreparedStatement stmt = saveSmsErrMsgInfo("RealTimeCollectBms : Read timed out 발생");
    	        			stmt.executeQuery();
    	        			stmt.close();
    	        			dbController.closeDB ();                			
                		}
                		
                		OriginTime = System.currentTimeMillis()/(1000*60);
                    
                		/*
                    smsChkCnt++;
                    if(smsChkCnt==2){
	                    dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
	        			PreparedStatement stmt = saveSmsErrMsgInfo("RealTimeCollectBms : Read timed out 발생");
	        			stmt.executeQuery();
	        			stmt.close();
	        			dbController.closeDB ();
	        			smsChkCnt=0;
                    }*/
                    
                    inputStream.close ();
                    outputStream.close ();
                    socket.close ();
                    connectNms ();
                } catch (Exception ee) {
                    outputLog.write ("getOneByte () Catch Exception : " + ee);
                }
            }
        }
    }

    public byte [] getBytes (int number) {
        byte [] bytes = new byte [number];
        byte temp;
        for (int index = 0; index < number; ++ index) {
            temp = getOneByte ();
            if (temp == -1)
                return null;
            bytes [index] = temp;
        }
        return bytes;
    }

    public String getBytes () {
        byte [] bytes = new byte [BUFFER_SIZE];
        byte temp;
        int index;
        for (index = 0; ; ++ index) {
            temp = getOneByte ();
            if (temp == -1)
                return null;
            if (temp == IDENTIFIER)
                break;
            bytes [index] = temp;
        }
        try {
            return new String (bytes, 0, index, "EUC-KR");
        } catch (Exception e) {
            outputLog.write ("getBytes : new String : Exception : " + e);
            return null;
        }
    }
	
    public boolean sendLoginPacketTmp () {
        byte [] headerPacket = {0x1b, 0x02, 0x32, 0x30, 0x30,
                                0x30, 0x35, 0x30, 0x30, 0x30,       // 0x35 : 로긴 요청
                                0x31, 0x30, 0x30, 0x30, 0x30,
                                0x30, 0x30, 0x30, 0x32, 0x36
        };
        byte [] bodyPacket;
        String  login = "mpls";

        // BodyPacket : login + 0x1f + login + 0x1f + 0x20 + 0x1f + 0x31 + 0x30;
         byte [] loginPacket;
        byte [] sendPacket = new byte [46];

        outputLog.write ("[" + getDateSecond () + "] Send Login/Password --------------------");
        int     index = 0;

        loginPacket = login.getBytes ();

        // HeaderPacket 복사
         for (; index < headerPacket.length; ++ index)
            sendPacket [index] = headerPacket [index];

        // login 복사
         for (int i = 0; i < loginPacket.length; ++ i)
            sendPacket [index ++] = loginPacket [i];
        sendPacket [index ++] = IDENTIFIER;

        // password 복사
         for (int i = 0; i < loginPacket.length; ++ i)
            sendPacket [index ++] = loginPacket [i];
        sendPacket [index ++] = IDENTIFIER;

        // Black 및 '10'복사
        sendPacket [index ++] = (byte) 0x31;            // 모든 장애 표시
        sendPacket [index ++] = IDENTIFIER;

        sendPacket [index ++] = 0x31;                   // '1'
        sendPacket [index ++] = 0x30;                   // '0'

        try {
            outputStream.write (sendPacket);
        } catch (Exception e) {
            outputLog.write ("sendLoginPacket Error : " + e);
			return false;
        }
        printHexaCode (sendPacket.length, sendPacket);
		return true;
    }

    public boolean sendLoginPacket () {
        byte [] headerPacket = {0x30, 'A', 0x00, 0x00, 0x00, 0x2a};
        byte [] bodyPacket;
        String  login = "mpls";

        // BodyPacket : login + 0x1f + login + 0x1f + 0x20 + 0x1f + 0x31 + 0x30;
		byte [] loginPacket = new byte [21];
        byte [] sendPacket = new byte [48];

        outputLog.write ("[" + getDateSecond () + "] Send Login/Password --------------------");
        int     index = 0;

		for (index = 0; index < loginPacket.length; ++ index)
			switch (index) {
				case 0 : loginPacket [index] = 'm'; break;
				case 1 : loginPacket [index] = 'p'; break;
				case 2 : loginPacket [index] = 'l'; break;
				case 3 : loginPacket [index] = 's'; break;
				default: loginPacket [index] = 0x00; break;
			}	

        // HeaderPacket 복사
        for (index = 0; index < headerPacket.length; ++ index)
            sendPacket [index] = headerPacket [index];

        // login 복사
        for (int i = 0; i < loginPacket.length; ++ i)
            sendPacket [index ++] = loginPacket [i];

        // password 복사
         for (int i = 0; i < loginPacket.length; ++ i)
            sendPacket [index ++] = loginPacket [i];

        try {
            outputStream.write (sendPacket);
        } catch (Exception e) {
            outputLog.write ("sendLoginPacket Error : " + e);
			return false;
        }
        printHexaCode (sendPacket.length, sendPacket);
		return true;
    }

    public void checkProcess () {
        String query = "SELECT PGM_USE_YN FROM oco30310 WHERE PGM_ID='" + pgmId + "'";
        try {
            ResultSet resultSet = dbController.getStmt ().executeQuery (query);
            if (resultSet.next ()) {
                if (resultSet.getString (1).equals ("N")) {
                    exitProcess (true, "프로세스가 동작 중지 되었습니다.");
                }
            } else {
                exitProcess (true, "PgmId : " + pgmId + "를 찾을 수 없습니다.");
            }
        } catch (Exception e) {
            exitProcess (true, "checkProcess 함수에서 에러가 발생되었습니다.");
        }
    }

    public void keepAlive () {
        try {
            dbController.getStmt ().executeQuery ("SELECT SYSDATE FROM DUAL");
        } catch (Exception e) {
            outputLog.write (" keepAlive Exception : " + e);
        }
    }

	public void write (String message) {
		outputLog.write (message);
	}

    public void sleep (int waitingTime) {
        try {
            Thread.sleep (waitingTime);
        } catch (Exception e) {
        }
    }

    public String getDateTime () {
        Calendar    calendar = Calendar.getInstance ();

        return String.format ("%04d%02d%02d%02d%02d%02d",
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH) + 1,
            calendar.get(Calendar.DAY_OF_MONTH),
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            calendar.get(Calendar.SECOND));
    }
    
	public void closePushSocket() {
		try {
			if (pushOutputStream != null) pushOutputStream.close();
		} catch (Exception e) {
		}
		try {
			if (pushSocket != null) pushSocket.close();
		} catch (Exception e) {
		}
		pushOutputStream = null;
		pushSocket = null;
	}
	

    public static void main (String [] args) throws ParseException {
//        if (args.length != 1) {
//            System.out.println ("사용법 : ./run RealtimeCollectBms 절대path");
//            System.exit (0);
//        }    	
    	
    	
    	EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("RealTimeCollectBms", envManager.getOptions());
    		System.exit(0);
    	}
        new RealTimeCollectBms (args);
    }
}

