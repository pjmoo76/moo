package com.skb.mi.realtime;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.ResultSetMetaData;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.LinkedList;

import com.skb.mi.common.DBController;

public class CollectUnmsMq {
	final private int			PREPARED_STATEMENT  = 1;
	final private String		ABSOLUTE_PATH 		= "/home/miuser/adams/data";
	final private String		VOIP_TABLE_NAME		= "commstsdb@oltp_voip:sts_voip_chorus_work";
	final private String		V52_TABLE_NAME		= "commstsdb@oltp_voip:sts_ess_work_v52";
	final private String		UNMS_PSTN			= "002";
	final private String		UNMS_VOIP			= "007";

	DBController				unmsController;
	DBController				dbController;
	String						dbUrl, userId, passwd, query;

    public CollectUnmsMq (String[] args) {
		System.out.println ("Start : " + getDateSecond ());
		String		query = "";
		try {
			readUnmsDb ();
			unmsController = new DBController (DBController.INFORMIX_DB, dbUrl, userId, passwd);
			readAdamsDb ();
			dbController = new  DBController (DBController.ORACLE_DB, dbUrl, userId, passwd);
		} catch (Exception e ) {
			System.out.println ("dbUrl : " + dbUrl);
			System.out.println ("userId : " + userId);
			System.out.println ("passwd : " + passwd);
			System.out.println ("DB Exception : " + e);
			System.exit (0);
		}	
		selectUnmsVoip ();
		selectUnmsV52 ();
		unmsController.closeDB ();
		dbController.closeDB ();
		System.out.println ("Finish : " + getDateSecond ());
	}

	public void selectUnmsVoip () {
		String	temp;
		int		count = 0;
		try {
			String	tid, neId, tpoCd, mgmtTpoCd, portNum, scardNumCtt, dablNetClCd, netOpNum, equipId, routNum, subsNo;
			int	no = 1;
			Calendar	cal = Calendar.getInstance ();
			query = readQuery (VOIP_TABLE_NAME, lastUpdateTime (0), lastUpdateTime (1));
			System.out.println ("selectUnmsVoip : " + query);
			ResultSet resultSet = unmsController.getStmt ().executeQuery (query);
			while (resultSet.next ()) {
				++ count;	
				System.out.print ("No " + String.format ("%05d", no ++) + " --------- ");
				dablNetClCd = resultSet.getString (5);
				netOpNum = resultSet.getString (1);
				query = insertONM10100 (netOpNum, UNMS_VOIP);				// UNMS VOIP
				for (int index = 1; index <= 17; ++ index) {
					System.out.println ("Field" + index + " : " + resultSet.getString (index));
					query += "	,'" + resultSet.getString (index) + "'";
				}
				query += "	,'" + resultSet.getString (21) + "'";		// OPER_FNSH_DTM

				tid = resultSet.getString (18);
				System.out.println ("Field18 : " + resultSet.getString (18));
				scardNumCtt = resultSet.getString (22);
				System.out.println ("Field22 : " + resultSet.getString (22));
				subsNo = resultSet.getString (23);
				System.out.println ("Field23 : " + resultSet.getString (23));
				routNum = resultSet.getString (25);
				System.out.println ("Field23 : " + resultSet.getString (25));
				subsNo = resultSet.getString (26);
				System.out.println ("Field23 : " + resultSet.getString (26));

				temp = selectEquip (tid);
				System.out.println ("selectEquip : " + temp);
				ResultSet tempResultSet = dbController.getStmt ().executeQuery (temp);

				System.out.println ("tempExecuteQuery..........");
				if (tempResultSet.next ()) {
					System.out.println ("In If....");
					equipId = tempResultSet.getString (1);
					tpoCd = tempResultSet.getString (2);
//				tpoNm = resultSet.getString (3);
					mgmtTpoCd = tempResultSet.getString (4);

					query += "	, '" + tpoCd + "')";
					System.out.println ("insertONM10100Voip query : " + query);
					dbController.getStmt ().executeUpdate (query);

					query = insertONM10101Voip (dablNetClCd, netOpNum, equipId, scardNumCtt, subsNo, routNum, subsNo);
					System.out.println ("insertONM10101Voip query : " + query);
					dbController.getStmt ().executeUpdate (query);
					tempResultSet.close ();
				}
			}
			System.out.println ("------------------ " + count + " ------------");
			resultSet.close ();
		} catch (Exception e) {
			System.out.println ("Exception : " + e);
		}
    }

	public void selectUnmsV52 () {
		String	temp;
		try {
			String	tid, neId, tpoCd, mgmtTpoCd, custNum, scardNumCtt, dablNetClCd, netOpNum, equipId, v52IfId, subsNo;
			int	no = 1;
			int	count = 0;
			query = readQuery (V52_TABLE_NAME, lastUpdateTime (0), lastUpdateTime (1));
			System.out.println ("selectUnmsV52 : " + query);
			ResultSet resultSet = unmsController.getStmt ().executeQuery (query);
			while (resultSet.next ()) {
				++ count;
				System.out.print ("No " + String.format ("%05d", no ++) + " --------- ");
				dablNetClCd = resultSet.getString (5);
				netOpNum = resultSet.getString (1);
				query = insertONM10100 (netOpNum, UNMS_PSTN);				// UNMS PSTN
				for (int index = 1; index <= 17; ++ index) {
					System.out.println ("Field" + index + " : " + resultSet.getString (index));
					query += "	,'" + resultSet.getString (index) + "'";
				}
				query += "	,'" + resultSet.getString (21) + "'";		// OPER_FNSH_DTM

				tid = resultSet.getString (18);
				System.out.println ("Field18 : " + resultSet.getString (18));
				v52IfId = resultSet.getString (19);
				System.out.println ("Field19 : " + resultSet.getString (19));
				subsNo = resultSet.getString (22);
				System.out.println ("Field22 : " + resultSet.getString (22));

				temp = selectEquip (tid);
				System.out.println ("selectEquip : " + temp);
				ResultSet tempResultSet = dbController.getStmt ().executeQuery (temp);

				System.out.println ("tempExecuteQuery..........");
				if (tempResultSet.next ()) {
					System.out.println ("In If....");
					equipId = tempResultSet.getString (1);
					tpoCd = tempResultSet.getString (2);
//				tpoNm = resultSet.getString (3);
					mgmtTpoCd = tempResultSet.getString (4);

					query += "	, '" + tpoCd + "')";
					System.out.println ("insertONM10100 query : " + query);
					dbController.getStmt ().executeUpdate (query);

					query = insertONM10101V52 (dablNetClCd, netOpNum, equipId, subsNo, v52IfId);
					System.out.println ("insertONM10101V52 query : " + query);
					dbController.getStmt ().executeUpdate (query);
					tempResultSet.close ();
				}
			}
			System.out.println ("------------------ " + count + " ------------");
			resultSet.close ();
		} catch (Exception e) {
			System.out.println ("Exception : " + e);
		}
    }

	public void readUnmsDb () throws Exception {
		String	oneLine;
		FileReader	fileReader = new FileReader (ABSOLUTE_PATH + File.separator + "informix.info");
		BufferedReader bufferedReader = new BufferedReader (fileReader);
		dbUrl = bufferedReader.readLine ();
		userId = bufferedReader.readLine ();
		passwd = bufferedReader.readLine ();
		bufferedReader.close ();
		fileReader.close ();
	}

	public void readAdamsDb () throws Exception {
		String	oneLine;
		FileReader	fileReader = new FileReader (ABSOLUTE_PATH + File.separator + "db.info");
		BufferedReader bufferedReader = new BufferedReader (fileReader);
		dbUrl = bufferedReader.readLine ();
		userId = bufferedReader.readLine ();
		passwd = bufferedReader.readLine ();
		bufferedReader.close ();
		fileReader.close ();
	}

	public String insertONM10100 (String netOpNum, String nmsCd) {
		return "MERGE INTO ONM10210 USING DUAL"
			 + " ON (NET_OP_NUM='" + netOpNum + "')"
			 + " WHEN NOT MATCHED THEN"
		     + " INSERT ("
			 + "	AUDIT_ID"
			 + "	, AUDIT_DTM"
			 + "	, SWING_LNKG_YN"
			 + "	, NMS_CD"
			 + "	, NET_OP_NUM"
			 + "	, DABL_OPER_CL_CD"	
			 + "	, IF_CL_CD"	
			 + "	, NET_OP_ST_CD"	
			 + "	, NET_CL_CD"	
			 + "	, OPER_STA_DTM"	
			 + "	, EXPT_OPER_FNSH_DTM"	
			 + "	, SVC_INFLU_TYP_CD"	
			 + "	, SVC_INFLU_YN"	
			 + "	, NET_OP_TYP_CD"	
			 + "	, OPER_INFLU_AREA_DESC"	
			 + "	, OPER_RSN_CTT"	
			 + "	, RGST_DTM"	
			 + "	, RGSTR_ID"	
			 + "	, RGSTR_NM"	
			 + "	, RGSTR_POST_CTT"	
			 + "	, RGSTR_PHON_NUM"	
			 + "	, OPER_FNSH_DTM"	
			 + "	, TPO_CD"
			 + " ) VALUES ("
			 + "	'SWING'"
			 + "	, SYSDATE"
			 + "	, 'Y'"
			 + "	, '" + nmsCd + "'";
	}

	public String insertONM10101V52 (String dablNetClCd, String netOpNum, String equipId, String subsNo, String v52IfId) {
		return "INSERT INTO ONM10211 ("
			 + " NET_OPER_EQUIP_SER_NUM"
			 + ", AUDIT_ID"
			 + ", AUDIT_DTM"
			 + ", DABL_NET_CL_CD"
			 + ", NET_OP_NUM"
			 + ", EQUIP_ID"
			 + ", PORT_NUM"
			 + ", V52_IF_ID"
			 + ") VALUES ("
			 + "(SELECT NVL(MAX(NET_OPER_EQUIP_SER_NUM) + 1,1) FROM ONM10211)"
			 + ", 'SWING'"
			 + ", SYSDATE"
			 + ", '" + dablNetClCd + "'"
			 + ", '" + netOpNum + "'"
			 + ", '" + equipId + "'"
			 + ", '" + subsNo + "'"
			 + ", '" + v52IfId + "')";
	}

	public String insertONM10101Voip (String dablNetClCd, String netOpNum, String equipId, String scardNumCtt, String subsCnt, String routNum, String subsNo) {
		return "INSERT INTO ONM10211 ("
			 + " NET_OPER_EQUIP_SER_NUM"
			 + ", AUDIT_ID"
			 + ", AUDIT_DTM"
			 + ", DABL_NET_CL_CD"
			 + ", NET_OP_NUM"
			 + ", EQUIP_ID"
			 + ", SCARD_NUM_CTT"
			 + ", DMG_LINE_CNT"
			 + ", ROUT_NUM"
			 + ", PORT_NUM"
			 + ") VALUES ("
			 + "(SELECT NVL(MAX(NET_OPER_EQUIP_SER_NUM) + 1,1) FROM ONM10211)"
			 + ", 'SWING'"
			 + ", SYSDATE"
			 + ", '" + dablNetClCd + "'"
			 + ", '" + netOpNum + "'"
			 + ", '" + equipId + "'"
			 + ", '" + scardNumCtt + "'"
			 + ", " + subsCnt + ""
			 + ", '" + routNum + "'"
			 + ", '" + subsNo + "')";
	}

	public String selectEquip (String tid) {
		return "SELECT" 
             + " a.EQUIP_ID"
             + ",b.TPO_CD"
             + ",b.TPO_NM"
             + ",b.MGMT_TPO_CD"
             + " FROM OIV10100 a,OIV10300 b"
             + " WHERE a.TPO_CD=b.TPO_CD(+)"
             + " AND a.EQUIP_TID_VAL='" + tid + "'";
	}

	public String readQuery (String tableName, String startTime, String finishTime) {
		return "SELECT * FROM " + tableName +
//			   " WHERE last_update_time BETWEEN '20171216000000' AND '20171228235959'";
			   " WHERE last_update_time BETWEEN '" + startTime + "' AND '" + finishTime + "'";
	}

/*
	public void selectColumnType () {
		try {
			String query = "SELECT * FROM " + tableName;

			ResultSet resultSet = unmsController.getStmt ().executeQuery(query);
			ResultSetMetaData	resultSetMetaData = resultSet.getMetaData ();
			int columnCount = resultSetMetaData.getColumnCount();
//			columnType = new int [columnCount];
			columns = new String [columnCount];
			System.out.println ("columnCount : " + columnCount);
			for (int index = 1; index <= columnCount; ++ index) {
			//	columnType [index] = resultSetMetaData.getColumnType(index);
				System.out.println ("Column 명 : " + resultSetMetaData.getColumnName (index) + ", Column Type : " + resultSetMetaData.getColumnType (index));
			}
			resultSet.close ();
		} catch (Exception e) {
			System.out.println ("selectColumnType Exception : " + e);
		}
	}
*/

/*
	public void changeValue (int index, int columnType, String columnValue) throws Exception {
		switch (columnType) {
			case Types.NUMERIC: 
			case Types.INTEGER: preparedOiv10208.setInt(index, Integer.valueOf(columnValue));
				break;
			case Types.FLOAT: preparedOiv10208.setFloat(index, Float.valueOf(columnValue));
				break;
			case Types.DOUBLE: preparedOiv10208.setDouble (index, Double.valueOf(columnValue));
				break;
			default :
				if (columnValue == null)
					columnValue = "";
				preparedOiv10208.setString(index, columnValue);
		}
	}
*/

	public String getDateSecond () {
		Calendar	calendar = Calendar.getInstance ();

		return String.format ("%04d-%02d-%02d %02d:%02d:%02d",
			calendar.get(Calendar.YEAR),
			calendar.get(Calendar.MONTH) + 1,
			calendar.get(Calendar.DAY_OF_MONTH),
			calendar.get(Calendar.HOUR_OF_DAY),
			calendar.get(Calendar.MINUTE),
			calendar.get(Calendar.SECOND));
	}

	public String lastUpdateTime (int index) {
		Calendar	calendar = Calendar.getInstance ();
		int			second = 0;

		if (index != 0)
			second = 59;
		return String.format ("%04d%02d%02d%02d%02d%02d",
			calendar.get(Calendar.YEAR),
			calendar.get(Calendar.MONTH) + 1,
			calendar.get(Calendar.DAY_OF_MONTH),
			calendar.get(Calendar.HOUR_OF_DAY),
			calendar.get(Calendar.MINUTE), second);
	}

    public void sleep (int waitingTime) {
        try {
            Thread.sleep (waitingTime);
        } catch (Exception e) {
        }
    }

    public static void main (String [] args) {
        new CollectUnmsMq (args);
    }
}

