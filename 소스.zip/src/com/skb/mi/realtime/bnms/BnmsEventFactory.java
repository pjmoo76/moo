package com.skb.mi.realtime.bnms;

import java.io.InputStream;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.skb.mi.common.SockUtils;
import com.skb.mi.common.StringUtils;

public class BnmsEventFactory {
	final int	HEADER_LEN	= 20;
	final byte	ESC = 0x1b;
	final byte	STX = 0x02;				// Start of Text
	final char	PDU_EVENT		= '1';	// 0x31
	final char	PDU_REQUEST		= '2';	// 0x32
	final char	PDU_RESPONSE	= '3';	// 0x33

	static public final byte 	IDENTIFIER	= 0x1f;
	//final String	CHARSET_NAME	= "EUC-KR";
	final String	CHARSET_NAME	= "UTF8";

	private	Logger	logger;
	private	byte[]	header;
	
	public BnmsEventFactory() {
		this.logger = LogManager.getLogger(this.getClass());
		this.header = new byte[HEADER_LEN];
	}

	public JSONObject get(InputStream is) throws Exception {
		/*
		 * ESC				: 1 byte
		 * STX				: 1 byte
		 * PduType			: 1 byte (1: Event, 2: Request, 3: Response)
		 * ServiceCode		: 4 byte
		 * messageSerialNo	: 2 byte
		 * lastYn			: 1 byte
		 * responseResult	: 1 byte
		 * extendArea		: 4 byte
		 * bodyLength		: 5 byte
		 */
		int len = SockUtils.read(is, header, header.length);
		if (len != HEADER_LEN) {
			throw new Exception(String.format("failed to read header (%d,%d)", HEADER_LEN, len));
		}
		if (header[0] != ESC) {
			throw new Exception("header[0] is not ESC");
		}
		if (header[1] != STX) {
			throw new Exception("header[1] is not STX");
		}
		char pduType = (char) header[2];
		if (pduType != PDU_EVENT && pduType != PDU_REQUEST && pduType != PDU_RESPONSE) {
			throw new Exception("invalid pduType : " + pduType);
		}
		String serviceCode = new String(StringUtils.getBytes(header, 3, 4));
		int bodyLength = Integer.parseInt(new String(StringUtils.getBytes(header, 15, 5)));

		byte[] body = new byte[bodyLength];
		len = SockUtils.read(is, body, body.length);
		if (len != bodyLength) {
			throw new Exception(String.format("failed to read body (%d,%d)", bodyLength, len));
		}
		
		String[] items = StringUtils.split(body, IDENTIFIER, CHARSET_NAME);
		JSONObject jsonObject = new JSONObject();
		
		if ("2001".equals(serviceCode)) {
			logger.debug("serviceCode:" + serviceCode);
			for (int i = 0; i < items.length; i ++) {
				logger.debug(String.format("[%d]%s", i, items[i]));
			}
			
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject)jsonParser.parse(items[0]);
			jsonObject.put("NMS_CD", "025");	//BTV NMS
			
			//0:unknown 1:add 2:change 3:delete 4:nothing
			Long beanStatus = (Long)jsonObject.get("beanStatus");
			
			if((Boolean)jsonObject.get("addInfo"))
			{
				jsonObject.put("addInfo", "Y");
			}else{
				jsonObject.put("addInfo", "N");
			}	
			
			if((Boolean)jsonObject.get("readOnly"))
			{
				jsonObject.put("readOnly", "Y");
			}else{
				jsonObject.put("readOnly", "N");
			}
			
			if(1 == beanStatus || 2 == beanStatus || 3 == beanStatus){
				jsonObject.put("kind", "BTV");
			}else{
				jsonObject = null;
			}
		}else{
			logger.debug("invalid serviceCode:" + serviceCode);
			jsonObject = null;
		}
		 
		return jsonObject;
	}
}
/************Sample***********
btvCategoryNo;	//No.
chnId;			//채널
position;		//발생위치
alarmGroup;		//장애그룹
alarmLevel;		//등급(1:CRI 2:MAJ 3:MIN)
alarmMsg;		//장애내용
alarmName;		//장애명
categoryName;	//용도
deviceTypeName;	//장비종류
hstimeAck;		//확인여부(0이상이면 확인)
hstimeReg;		//발생일시	
ipAddress;		//IP주소	
locationName;	//설치장소
moNameNode;		//장비
serviceCode;		//관제분류
beanStatus;		//0:unknown 1:add 2:change 3:delete 4:nothing

addInfo;
alarmCode;
alarmKey;
alarmNo;
categoryNo;
clearNo;
clearType;
deviceType;
hstimeChg;
hstimeClear;
hstimePerf;
hstimeReason;
uxtimeReg;
hstimeRegNode;
instance;
jobNo;
locationNo;
moAlias;
moClass;
modelName;
modelNo;
moName;
moNo;
moNoNode;
mstimeElapse;
perfNo;
readOnly;
reasonNo;
regAckSec;
SIZE_MSG;
treatNo;
userGroupNo;
userNo;
userNoAck;
userNoClear;
userNoReason;
valComp;
valGet;
************Sample***********/

