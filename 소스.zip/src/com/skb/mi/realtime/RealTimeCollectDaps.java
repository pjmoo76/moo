package	com.skb.mi.realtime;

import	java.io.FileReader;
import	java.io.BufferedReader;
import	java.io.File;
import	java.io.OutputStream;
import	java.net.InetAddress;
import	java.net.Socket;
import	java.net.ServerSocket;
import	java.net.SocketTimeoutException;
import	java.sql.ResultSet;
import	java.util.Calendar;
import	java.util.LinkedList;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import	com.skb.mi.common.DBController;
import com.skb.mi.common.EnvManager;
import	com.skb.mi.common.OutputLog;
import	com.skb.mi.thread.RealTimeCollectDapsThread;

import org.apache.commons.cli.HelpFormatter;
import	org.json.simple.JSONObject;

public class	RealTimeCollectDaps {
	String              		dbUrl, userName, password;
	LinkedList<JSONObject>		notSendJson;

	int							listenPortNo;
	// Push Processor 정보
	String						pushIpAddress;
	int							pushPortNo;

	Socket						pushSocket;
	OutputStream				outputStream;

	String						absolutePath;
	String						pgmId;

	OutputLog					outputLog;

	DBController				dbController;

	public RealTimeCollectDaps (String [] args) {
		int				count;
		byte []			buffer = new byte [10240];
		RealTimeCollectDapsThread	thread;

		absolutePath = EnvManager.env.getHome();
        outputLog = new OutputLog (true, this.getClass ().getName (), EnvManager.env.getLogs());
        outputLog.write ("Start : " + getDateSecond ());

		ServerSocket	serverSocket = null;
		notSendJson = new LinkedList<JSONObject> ();
		try {
			String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
			ConfigManager configManager = new ConfigManager(cfgFile);
			dbUrl = configManager.getConfig(Constants.ADAMS_DB, Constants.DB_URL);
			userName = configManager.getConfig(Constants.ADAMS_DB, Constants.USER_NAME);
			password = configManager.getConfig(Constants.ADAMS_DB, Constants.PASSWORD);
			listenPortNo = Integer.parseInt(configManager.getConfig(Constants.DAPS, Constants.LISTEN_PORT_NO));
			pushIpAddress = configManager.getConfig(Constants.WEB_PUSH, Constants.IP_ADDRESS);
			pushPortNo = Integer.parseInt(configManager.getConfig(Constants.WEB_PUSH, Constants.PORT_NO));

			outputLog.write("dbUrl : " + dbUrl);
			outputLog.write("userName : " + userName);
			outputLog.write("password : " + password);
			outputLog.write("listenPortNo : " + listenPortNo);
			outputLog.write("pushIpAddress : " + pushIpAddress);
			outputLog.write("pushPortNo : " + pushPortNo);

/**
			readDbInfo ();
            dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
            InetAddress local = InetAddress.getLocalHost ();
            String  ip = local.getHostAddress ();
            ResultSet resultSet = dbController.selectProgramInfo (this.getClass().getName (), ip);
            if (resultSet.next ()) {
                pgmId = resultSet.getString (1);
                String  pgmUseYn = resultSet.getString (2);
                String  pgmStCd = resultSet.getString (3);
                resultSet.close ();

                outputLog.write ("pgmId : " + pgmId + ", pgmUseYn : " + pgmUseYn + ", pgmStCd : " + pgmStCd);
                // 프로세스 Use Y/N 검사
                if (pgmUseYn.equals ("N"))
                	exitProcess (false, "");
                // 프로세스 동작중인지 검사
                if (pgmStCd.equals ("S"))       // 동작중이면 바로 종료
                	exitProcess (false, "");
                else                            // 동작이 종료되어 있는 경우
                	dbController.insertProcessHistory(pgmId, "프로세스가 시작되었습니다", "S", "Y");
                outputLog.write ("프로세스가 시작되었습니다.");
            } else {
                dbController.insertProcessHistory(pgmId, "프로세스가 시작되었습니다", "S", "Y");
                exitProcess (true, "프로세스를 찾을 수 없습니다.");
            }
**/
			serverSocket = new ServerSocket (listenPortNo);
//			serverSocket.setSoTimeout (1000 * 10);							// 10초
		} catch (Exception e) {
			outputLog.write ("RealTimeCollectDaps:ServerSocket Exception : " + e);
            exitProcess (true, "DB 정보를 읽는 도중에 에러발생되었습니다.");
		}
//        dbController.closeDB ();
		/*
        try {
			readPushInfo ();
        } catch (Exception e) {
            outputLog.write ("RealTimeCollectDaps:readPushInfo'Exception : " + e);
            try {
				serverSocket.close ();
            } catch (Exception ee) {
            }
            System.exit (1);
        }
        */
		while (true) {
			try {
				Socket socket = serverSocket.accept ();
				outputLog.write ("Daps 연결 요청......" + socket);

				thread = new RealTimeCollectDapsThread (socket, pushIpAddress, pushPortNo, this);
				thread.start ();

//			} catch (SocketTimeoutException e) {
//				checkProcess ();
			} catch (Exception e) {
				outputLog.write ("RealTimeCollectDaps Exception : " + e);
			}
		}
	}

    public void exitProcess (boolean check, String clctRsltCtt) {
/**
        if (check) {
            try {
                dbController.insertProcessHistory(pgmId, clctRsltCtt, "F", "Y");
            } catch (Exception e) {
                outputLog.write ("exitProcess () Exception : " + e);
            }
        }
        outputLog.write (clctRsltCtt);
        outputLog.close ();
        dbController.closeDB ();
        try {
            outputStream.close ();
			pushSocket.close ();
        } catch (Exception e) {
        }
        outputLog.write ("Finish : " + getDateSecond ());
        System.exit (0);
**/
    }

    /*
    public void readPushInfo () throws Exception {
        FileReader  fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + "push.info");
        BufferedReader bufferedReader = new BufferedReader (fileReader);
        ipAddress = bufferedReader.readLine ();
        portNo = Integer.parseInt (bufferedReader.readLine ());
        outputLog.write ("Push IP Address : " + ipAddress);
        outputLog.write ("Push Port : " + portNo);
        bufferedReader.close ();
        fileReader.close ();
    }
    */

    public void printHexaCode (int length, byte[] buffer) {
        int count = 0;
        for (int index = 0; index < length; ++ index) {
            if (count++ % 20 == 0)
                System.out.println ();
            System.out.printf ("%02x.", buffer [index]);
        }
        System.out.println ();
    }

/*
	public void sendPush (JSONObject obj) {
        try {
            outputStream.write (obj.toJSONString ().getBytes ());
            outputStream.flush ();
        } catch (Exception e) {
            outputLog.write ("============ " + e);
            notSendJson.add (obj);
            sendJson ();
        }
	}

    public void sendJson () {
        JSONObject  obj;
        int size = notSendJson.size ();
        outputLog.write ("================ size : " + size);
        try {
            try {
                outputStream.close ();
            } catch (Exception e1) {
            }
            try {
                pushSocket.close ();
            } catch (Exception e2) {
            }
            pushSocket = new Socket (ipAddress, portNo);
            outputStream = pushSocket.getOutputStream ();
            for (int index = 0; index < size; ++ index) {
                obj = notSendJson.get (0);
                outputStream.write (obj.toJSONString ().getBytes ());
                outputStream.flush ();
                System.out.println (obj.toJSONString ());
                notSendJson.remove (0);
                Thread.sleep (100);
            }
            outputStream.flush ();
        } catch (Exception e) {
            outputLog.write ("======== sendJson ============ " + e);
        }
    }
*/

	public String getAbsolutePath () {
		return absolutePath;
	}

    public String getDateSecond () {
        Calendar    calendar = Calendar.getInstance ();

        return String.format ("%04d-%02d-%02d %02d:%02d:%02d",
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH) + 1,
            calendar.get(Calendar.DAY_OF_MONTH),
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            calendar.get(Calendar.SECOND));
    }

    public void checkProcess () {
        String query = "SELECT PGM_USE_YN FROM oco30310 WHERE PGM_ID='" + pgmId + "'";
        try {
            ResultSet resultSet = dbController.getStmt ().executeQuery (query);
            if (resultSet.next ()) {
                if (resultSet.getString (1).equals ("N")) {
                    exitProcess (true, "프로세스가 동작 중지 되었습니다.");
                }
            } else {
                exitProcess (true, "PgmId : " + pgmId + "를 찾을 수 없습니다.");
            }
        } catch (Exception e) {
            exitProcess (true, "checkProcess 함수에서 에러가 발생되었습니다.");
        }
    }

	public void write (String message) {
		outputLog.write (message);
	}

	/*
    // ADAMS DB정보 조회
    public void readDbInfo () throws Exception {
        FileReader  fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + "db.info");
        BufferedReader bufferedReader = new BufferedReader (fileReader);
        dbUrl = bufferedReader.readLine ();
        userName = bufferedReader.readLine ();
        password = bufferedReader.readLine ();
        bufferedReader.close ();
        fileReader.close ();
	}
	*/

	public static void main (String args []) throws Exception {
//        if (args.length != 1) {
//            System.out.println ("사용법 : ./run RealtimeCollectDaps 절대path");
//            System.exit (0);
//        }
    	EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("RealTimeCollectDaps", envManager.getOptions());
    		System.exit(0);
    	}
		new RealTimeCollectDaps (args);
	}
}
