package com.skb.mi.realtime;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

import org.apache.commons.cli.HelpFormatter;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.common.MiscUtils;
import com.skb.mi.model.OMN30203;
import com.skb.mi.realtime.rms.RmsCatvFaultEvent;
import com.skb.mi.realtime.rms.RmsCircuitFaultEvent;
import com.skb.mi.realtime.rms.RmsEquipFaultEvent;
import com.skb.mi.realtime.rms.RmsEvent;
import com.skb.mi.realtime.rms.RmsEventFactory;
import com.skb.mi.thread.SendJsonThread;


public class RealTimeCollectRms {
	final private String		NET_CL_CD 			= "04";		// OCO20101 테이블
	final private String		NET_CL_NM 			= "HFC";	// OCO20101 테이블
	final private String		NMS_EQUIP_CD 		= "011";	// OCO20101 테이블
	final private String		NMS_EQUIP_NM 		= "RMS";
	
	final private String		NMS_CD_CATV 		= "032";	// OCO20101 테이블
	final private String		NMS_NM_CATV 		= "RMS_CATV";
	
	final private String		ETC_NET_CL_CD 		= "99";
	final private String		ETC_NET_CL_NM 		= "ETC";

    final private String  		GENERATE_EVENT 		= "GEN";
    final private String  		CLEAR_EVENT 		= "CLR";

    final private String  		GENERATED_FAULT_NM 	= "장애중";
    final private String  		CLEARED_FAULT_NM 	= "장애해제";

    final private String  		GENERATED_FAULT_CD 	= "01";
    final private String  		CLEARED_FAULT_CD 	= "02";
	
	final private String        RMS_UNKNOWN_FAULT 	= "210";    // 210: 미파악됨
	final private String        RMS_EQUIP_FAULT 	= "303";    // 303: 장비 장애
    final private String        RMS_CIRCUIT_FAULT 	= "501";   	// 501: 회선 장애

    final private int			SO_TIME_OUT	= (1000*60*5); //5분
    
	// RMS 서버 정보
	Socket						socket;
	InputStream					inputStream;
	OutputStream				outputStream;
	String []                   arrIpAddress;
	String						ipAddress;
	int							portNo;

	HashMap<String, OMN30203>	omn30203Map;
	String						pushIpAddress;
	int							pushPortNo;

	Hashtable<String,String>	dablLclCdList;
	Hashtable<String,String>	dablLclNmList;
	Hashtable<String,String>	dablMclCdList;
	Hashtable<String,String>	dablMclNmList;
	Hashtable<String,String>	dablNmList;
	Hashtable<String,String>	dablCdList;

    private Logger		logger;
	private	SqlSession	adamsSession;
	private	SendJsonThread	jsonSender;

    public RealTimeCollectRms (String [] args) {
    	logger = LogManager.getLogger(this.getClass());
    	logger.info("start");
    	
    	loadConfig();

		try {
			adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
			readRmsFaultCode();

			jsonSender = new SendJsonThread(pushIpAddress, pushPortNo, false);
			connectNms();
			run();

			outputStream.close ();
            inputStream.close ();
            socket.close ();

		} catch (Exception e ) {
			logger.error("Exception", e);
		}
    }
    
    public void loadConfig() {
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		arrIpAddress = configManager.getConfig(Constants.RMS, Constants.IP_ADDRESS).split(",");		
		portNo = Integer.parseInt(configManager.getConfig(Constants.RMS, Constants.PORT_NO));
		pushIpAddress = configManager.getConfig(Constants.WEB_PUSH, Constants.IP_ADDRESS);
		pushPortNo = Integer.parseInt(configManager.getConfig(Constants.WEB_PUSH, Constants.PORT_NO));
		
		logger.info("ipAddress : " + arrIpAddress[0]);
		logger.info("portNo : " + portNo);
		logger.info("pushIpAddress : " + pushIpAddress);
		logger.info("pushPortNo : " + pushPortNo);    	
    }

	public void connectNms() {
        boolean check = false;
        while (!check) {
        	try {
        		if (inputStream != null) inputStream.close();
        	} catch (Exception e) {
        	}
        	try {
        		if (outputStream != null) outputStream.close();
        	} catch (Exception e) {
        	}
        	try {
        		if (socket != null) socket.close();
        	} catch (Exception e) {
        	}
            try {
            	int arrIpAddressLength = arrIpAddress.length;
            	
            	for(int i=0;arrIpAddressLength>i;i++){
            		String tmpPushIpAddress = arrIpAddress[i];
            		if(ipAddress == null)
            		{
            			ipAddress = arrIpAddress[0];
            			break;
            		}else if(ipAddress.equals(tmpPushIpAddress)){
            			
            			if(i==arrIpAddressLength-1)
            			{
            				ipAddress = arrIpAddress[0];
            				break;            				
            			}else{
            				ipAddress = arrIpAddress[i+1];
            				break;
            			}            			
            		}
            	}
            	
            	
            	logger.info("try connecting " + ipAddress + ":" + portNo);
                socket = new Socket (ipAddress, portNo);
                socket.setSoTimeout(SO_TIME_OUT);
                logger.info("connected " + ipAddress + ":" + portNo);

                inputStream = socket.getInputStream();
                outputStream = socket.getOutputStream ();
                
                check = true;
            } catch (Exception e) {
                logger.error("Exception", e);
                MiscUtils.sleep(100);            // 0.1초
            }
        }
	}

	// RMS 관련 장애 코드 조회해서 분류별로 Hashtable에 저장한다.
	public void readRmsFaultCode () throws Exception {
		omn30203Map = new HashMap<String, OMN30203>();
		// DABL_LCL_CD, DABL_LCL_NM, DABL_MCL_CD, DABL_MCL_NM, DABL_CD, DABL_CD_NM, CLCT_EVT_ID, CLCT_EVT_CD
		List<OMN30203> omn30203List = (List) adamsSession.selectList("RealtimeRms.selectOMN30203", null);
		for (OMN30203 omn30203 : omn30203List) {
			String key = omn30203.getClctEvtId() + omn30203.getClctEvtCd();
			omn30203Map.put(key, omn30203);
			logger.debug(String.format("(%s),(%s,%s,%s,%s,%s,%s,%s,%s,%s)",
					key,
					omn30203.getDablLclCd(), omn30203.getDablLclNm(), omn30203.getDablMclCd(), omn30203.getDablMclNm(),
					omn30203.getDablCd(), omn30203.getDablCdNm(), omn30203.getClctEvtId(), omn30203.getClctEvtCd(), omn30203.getNmsCatvYn()));
		}
	}
	
    private void run() {
    	RmsEventFactory	eventFactory = new RmsEventFactory();
    	RmsEvent event = null;
        int errContCnt = 0;
        
		while (true) {
	    	try {
	    		if (adamsSession == null) {
	    			adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
	    		}
				if (event == null) {
					event = eventFactory.get(inputStream);
					errContCnt = 0;
				} else {
					// retry
					errContCnt ++;
					if (errContCnt > 3) {
						event = null;
						continue;
					}
				}
				if (event != null) {
					process(event);
					event = null;
				}
			} catch (SocketTimeoutException ste) {
				logger.error("SocketTimeoutException", ste);
				connectNms();
			} catch (SocketException se) {
				logger.error("SocketException", se);
				connectNms();
			} catch (SQLException sqle) {
				logger.error("SQLException", sqle);
				adamsSession.close();
				adamsSession = null;
				MiscUtils.sleep(100);
			} catch (PersistenceException pe) {
				logger.error("PersistenceException", pe);
				adamsSession.close();
				adamsSession = null;
				MiscUtils.sleep(100);
			} catch (Exception e) {
				logger.error("Exception", e);
				// 2023-02-20 Song (infinite loop...)
				if ("failed to read".equals(e.getMessage())) {
					MiscUtils.sleep(1000);
					connectNms();
				}
				MiscUtils.sleep(100);
	    	}
        }
    }

    private void process(RmsEvent event) throws Exception {
    	
    	if ("04".equals(event.getEvtId()) && "90".equals(event.getEvtCode())) return;

    	JSONObject jsonObject = new JSONObject();    	
    	jsonObject.put("DABL_LCL_CD", event.getDablLclCd());
    	jsonObject.put("NMS_CD", NMS_EQUIP_CD);
    	jsonObject.put("NMS_NM", NMS_EQUIP_NM);
    	jsonObject.put("NMS_DABL_NUM_CTT", "" + event.getSerialNo());
    	jsonObject.put("NET_CL_CD", NET_CL_CD);
    	jsonObject.put("NET_CL_NM", NET_CL_NM);
    	String key = event.getEvtId() + event.getEvtCode();
		OMN30203 omn30203 = omn30203Map.get(key);
		//CATV일경우 NMS_CD 032 설정
		if("Y".equals(omn30203.getNmsCatvYn())){
			jsonObject.put("NMS_CD", NMS_CD_CATV);
	    	jsonObject.put("NMS_NM", NMS_NM_CATV);
		}

    	if ("0".equals(event.getSeverity())) { // 장애해제
    		jsonObject.put("RLSE_DTM", event.getGenTime());
    		jsonObject.put("RLSE_RCV_DTM", MiscUtils.getDateTime());
    		jsonObject.put("DABL_ST_CD", CLEARED_FAULT_CD);
    		jsonObject.put("DABL_ST_NM", CLEARED_FAULT_NM);
    		jsonObject.put("NMS_CD", NMS_EQUIP_CD);
    		jsonObject.put("kind", CLEAR_EVENT);
    	} else { // 장애    		
			jsonObject.put("DABL_ST_CD", GENERATED_FAULT_CD);
    		jsonObject.put("DABL_ST_NM", GENERATED_FAULT_NM);
    		String swingAnnceYn = "N";
    		if (omn30203 == null) {
    			jsonObject.put("DABL_LCL_CD", "*");
    			jsonObject.put("DABL_LCL_NM", "*");
    			jsonObject.put("DABL_MCL_CD", "*"); 
    			jsonObject.put("DABL_MCL_NM", "*");
    			jsonObject.put("DABL_CD", "*");
    			jsonObject.put("DABL_NM", "*");
    		} else {
    			
    			jsonObject.put("DABL_LCL_CD", omn30203.getDablLclCd());
    			jsonObject.put("DABL_LCL_NM", omn30203.getDablLclNm());
    			jsonObject.put("DABL_MCL_CD", omn30203.getDablMclCd());
    			jsonObject.put("DABL_MCL_NM", omn30203.getDablMclNm());
    			jsonObject.put("DABL_CD", omn30203.getDablCd());
    			jsonObject.put("DABL_NM", omn30203.getDablCdNm());
				if (omn30203.getDablCd().equals ("014035")
						|| omn30203.getDablCd().equals ("074006")
						|| omn30203.getDablCd().equals ("074007")
						|| omn30203.getDablCd().equals ("074008")) {
					swingAnnceYn = "Y";
					/* Circuit 장애 규격에 DAMAGE_CUST_CNT 항목 추가됨 (2018.12.17)
					String dmgScrbrCnt = null;
					if (0 <= event.getContent().indexOf ("Offline:")) {
						String	one = event.getContent().substring (event.getContent().indexOf ("Offline:") + 8);
						if (one != null) {
							if (0 <= event.getContent().indexOf ("Offline:")) {
								for (int index = 0; index < one.length (); ++ index) {
									if ('0' <= one.charAt (index) && one.charAt (index) <= '9')
										dmgScrbrCnt += one.charAt (index);
									else
										break;
								}	
							}
						}
					}
					*/
				}
    		}
			jsonObject.put("SWING_ANNCE_YN", swingAnnceYn);
    		jsonObject.put("OCCR_DTM", event.getGenTime());
    		jsonObject.put("OCCR_RCV_DTM", MiscUtils.getDateTime());    		
    		jsonObject.put("DABL_GR_CD", event.getDablGrCd());
    		jsonObject.put("MKT_DIV_ORG_ID", "");
    		jsonObject.put("MKT_DIV_ORG_NM", "");
    		jsonObject.put("TEAM_ORG_ID", "");
    		jsonObject.put("TEAM_ORG_NM", "");
    		jsonObject.put("INFO_CNTR_CD", "");
    		jsonObject.put("INFO_CNTR_NM", "");
    		jsonObject.put("DISTB_CNTR_CD", "");
    		jsonObject.put("DISTB_CNTR_NM", "");
    		jsonObject.put("EQUIP_ID", event.getTid());
    		jsonObject.put("EQUIP_TID_VAL", event.getTid());
    		jsonObject.put("EQUIP_IP_ADDR", event.getSysId());
    		jsonObject.put("EQUIP_NM", event.getSysName());
    		jsonObject.put("EQUIP_MDL_CD", event.getDevType());
			jsonObject.put("DABL_DUP_YN", "");
			// OTX_NUM, CCELL_NUM 값이 || 를 구분자로 2개 이상 들어올 경우, 첫번째 값만 저장
			String otxNum = event.getOtxNo();
			if(otxNum == null || "".equals(otxNum)) {
				logger.info("[SPLIT] (skip) otxNum is null or blank");
			} else {
				logger.info("[SPLIT] (before) otxNum = " + otxNum);
				otxNum = otxNum.split("\\|\\|")[0];
				logger.info("[SPLIT] (after) otxNum = " + otxNum);
			}
			jsonObject.put("OTX_NUM", otxNum);
			
			String ccellNum = event.getCellNo();
			if(ccellNum == null || "".equals(ccellNum)) {
				logger.info("[SPLIT] (skip) ccellNum is null or blank");
			} else {
				logger.info("[SPLIT] (before) ccellNum = " + ccellNum);
				ccellNum = ccellNum.split("\\|\\|")[0];
				logger.info("[SPLIT] (after) ccellNum = " + ccellNum);
			}
			jsonObject.put("CCELL_NUM", ccellNum);
			jsonObject.put("SCARD_NUM_CTT", event.getCardNo());
			try {
				int portNo = Integer.parseInt(event.getPortNo());
				jsonObject.put("PORT_NUM", event.getPortNo());
			} catch (Exception e) {
				jsonObject.put("PORT_NUM", "");
			}
			jsonObject.put("DABL_DESC", event.getContent());

			jsonObject.put("SHSPD_VOC_CNT", ""+event.getVocCount());
			jsonObject.put("SHSPD_INET_DMG_LINE_CNT", ""+event.getInternetCnt());
			jsonObject.put("GNRL_IPTV_DMG_LINE_CNT", ""+event.getCommIptvCnt());
			jsonObject.put("INDPND_IPTV_DMG_LINE_CNT", ""+event.getOnlyIptvCnt());
			jsonObject.put("GNLPH_DMG_LINE_CNT", ""+event.getVoiceCnt());
			jsonObject.put("IPTV_VOC_CNT", ""+event.getIptvVocCnt());
			jsonObject.put("PHON_VOC_CNT", ""+event.getVoiceVocCnt());
			jsonObject.put("TOT_VOC_CNT", ""+event.getTotalVocCnt());
			jsonObject.put("VOIP_VOC_CNT", "0");
			jsonObject.put("OPER_DABL_YN", ""+event.getOperDablYn());

			if (RmsEvent.EVT_EQUIP_FAULT.equals(event.getEvtKind())) {
				RmsEquipFaultEvent equipFaultEvent = (RmsEquipFaultEvent) event;

				jsonObject.put("EQUIP_MDL_NM", equipFaultEvent.getDevTypeName());
				jsonObject.put("DABL_DUP_CNT", "");
				jsonObject.put("DABL_DUP_CNT_1", "1" );
				jsonObject.put("DABL_DUP_CNT_2", "1" );
				jsonObject.put("DABL_DUP_CNT_3", "1" );
				
				jsonObject.put("NET_OP_NUM", "");
				jsonObject.put("EQUIP_SET_LOC_DESC", "");
				jsonObject.put("DMG_SCRBR_CNT", "");
				jsonObject.put("TM_TYP_CD", "");
				jsonObject.put("TM_CTT", "");
				jsonObject.put("INCOMM_BIZR_ID", "");
				jsonObject.put("MODULE_EQUIP_ID", "");
				jsonObject.put("MSC_MODULE_NM", "");
				jsonObject.put("ROUT_NUM", "");
				jsonObject.put("ROUT_NM", "");
				jsonObject.put("DSST_YN", "");
				jsonObject.put("DSSTR_YN", "");
				
			} else if (RmsEvent.EVT_CATV_FAULT.equals(event.getEvtKind())) {
				/* 2022-09-30 CATV 장애 추가  강대윤*/
				
				RmsCatvFaultEvent catvFaultEvent = (RmsCatvFaultEvent) event;
				
				jsonObject.put("EQUIP_MDL_NM", catvFaultEvent.getDevTypeName());
				jsonObject.put("DABL_DUP_CNT", "");
				jsonObject.put("DABL_DUP_CNT_1", "1" );
				jsonObject.put("DABL_DUP_CNT_2", "1" );
				jsonObject.put("DABL_DUP_CNT_3", "1" );
				
				jsonObject.put("NET_OP_NUM", "");
				jsonObject.put("EQUIP_SET_LOC_DESC", "");
				//2025.11.04 김준수정 CATV도 피해고객수 적용
				jsonObject.put("DMG_SCRBR_CNT", catvFaultEvent.getDmgTotalCustCount()+""); //피해고객수(전체)
				jsonObject.put("TM_TYP_CD", "");
				jsonObject.put("TM_CTT", "");
				jsonObject.put("INCOMM_BIZR_ID", "");
				jsonObject.put("MODULE_EQUIP_ID", "");
				jsonObject.put("MSC_MODULE_NM", "");
				jsonObject.put("ROUT_NUM", "");
				jsonObject.put("ROUT_NM", "");
				jsonObject.put("DSST_YN", "");
				jsonObject.put("DSSTR_YN", "");
				//2025.11.04 김준 수정 CATV도 수용고객수 항목에 값 생성
				jsonObject.put ("SCRBR_CNT", ""+catvFaultEvent.getCustTotalCount()+""); //수용고객수(전체)
				// 2025.04.22 실시간 장애규격변경
				// - CATV 피해 고객/회선수 관련 항목 추가
				jsonObject.put ("CM_STB_CNT", catvFaultEvent.getCmStbCount());
				jsonObject.put ("TOT_LINE_CNT", catvFaultEvent.getLineTotalCnt());
				jsonObject.put ("INET_LINE_CNT", catvFaultEvent.getLineInternetCount());
				jsonObject.put ("QAM_LINE_CNT", catvFaultEvent.getLineQamCount());
				jsonObject.put ("VSB8_LINE_CNT", catvFaultEvent.getLine8vsbCount());
				jsonObject.put ("TOT_DMG_LINE_CNT", catvFaultEvent.getDmgTotalLineCount());
				jsonObject.put ("INET_DMG_LINE_CNT", catvFaultEvent.getDmgInternetLineCount());
				jsonObject.put ("QAM_DMG_LINE_CNT", catvFaultEvent.getDmgQamLineCount());
				jsonObject.put ("VSB8_DMG_LINE_CNT", catvFaultEvent.getDmg8vsbLineCount());
				jsonObject.put ("TOT_VOC_CNT", catvFaultEvent.getTotalVocCnt());
				jsonObject.put ("TOT_CUST_CNT", catvFaultEvent.getCustTotalCount());
				jsonObject.put ("INET_CUST_CNT", catvFaultEvent.getCustInternetCount());
				jsonObject.put ("QAM_CUST_CNT", catvFaultEvent.getCustQamCount());
				jsonObject.put ("VSB8_CUST_CNT", catvFaultEvent.getCust8vsbCount());
				jsonObject.put ("TOT_DMG_CUST_CNT", catvFaultEvent.getDmgTotalCustCount());
				jsonObject.put ("INET_DMG_CUST_CNT", catvFaultEvent.getDmgInternetCustCount());
				jsonObject.put ("QAM_DMG_CUST_CNT", catvFaultEvent.getDmgQamCustCount());
				jsonObject.put ("VSB8_DMG_CUST_CNT", catvFaultEvent.getDmg8vsbCustCount());
				jsonObject.put ("TB_SO_NM", catvFaultEvent.getCatvSoName());
				jsonObject.put ("CELL_MEMO", catvFaultEvent.getCellMemo());

			} else if (RmsEvent.EVT_CIRCUIT_FAULT.equals(event.getEvtKind())) {
				RmsCircuitFaultEvent circuitFaultEvent = (RmsCircuitFaultEvent) event;

				jsonObject.put("EQUIP_MDL_NM", "*");
	        	jsonObject.put ("DABL_DUP_CNT", "");
	        	jsonObject.put ("DABL_DUP_CNT_1", "1" );
	        	jsonObject.put ("DABL_DUP_CNT_2", "1" );
	        	jsonObject.put ("DABL_DUP_CNT_3", "1" );
	        	
	        	jsonObject.put ("NET_OP_NUM", "");
	        	jsonObject.put ("EQUIP_SET_LOC_DESC", "");
	        	jsonObject.put ("DMG_SCRBR_CNT", ""+circuitFaultEvent.getDamageCustCnt());
	        	jsonObject.put ("U_ORG_ID", "");
				jsonObject.put ("U_ORG_NM", "");
				jsonObject.put ("L_ORG_ID", "");
				jsonObject.put ("L_ORG_NM", "");
				jsonObject.put ("CUST_NUM", "");
				jsonObject.put ("LINE_NUM", "");
				jsonObject.put ("RING_NUM", "");
				jsonObject.put ("RING_NM", "");
				jsonObject.put ("DSSTR_YN", "");
				// 2018.12.17 실시간 장애규격변경
				// - 장애별 피해 고객/회선수 관련 항목 추가
				// - 2018.12.27 20:00 운용 적용
				jsonObject.put ("SCRBR_CNT", ""+circuitFaultEvent.getTotalCustCnt());
				jsonObject.put ("SHSPD_ACEPT_LINE_CNT", ""+circuitFaultEvent.getInternetLineCnt());
				jsonObject.put ("GNRL_IPTV_ACEPT_LINE_CNT", ""+circuitFaultEvent.getCommIptvLineCnt());
				jsonObject.put ("INDPND_IPTV_ACEPT_LINE_CNT", ""+circuitFaultEvent.getOnlyIptvLineCnt());
				jsonObject.put ("PHON_ACEPT_LINE_CNT", ""+circuitFaultEvent.getVoiceLineCnt());
				jsonObject.put ("DMG_SCRBR_CNT", ""+circuitFaultEvent.getDamageCustCnt());
				jsonObject.put ("DABL_RMK", circuitFaultEvent.getMemo());
				jsonObject.put ("RING_NUM", circuitFaultEvent.getRingId());
				jsonObject.put ("FDF_LINE_NUM", circuitFaultEvent.getFdf());
				jsonObject.put ("CBL_DIST", circuitFaultEvent.getCableDistance());
				
			}
			jsonObject.put ("kind", GENERATE_EVENT);
			jsonObject.put ("DABL_OCCR_LOC_DESC", 
						event.getOtxNo()
						+ "_" + event.getCellNo()
						+ "_" + event.getCardNo()
						+ "_" + event.getPortNo());

    	}
    	logger.debug("JSON:" + jsonObject.toString());
		jsonSender.put(jsonObject);
    }

	public static void main (String [] args) {
//		if (args.length != 1) {
//			System.out.println ("사용법 : ./run RealtimeCollectRms 절대path");
//			System.exit (0);
//		}
		
		
    	EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("RealTimeCollectRms", envManager.getOptions());
    		System.exit(0);
    	}
        new RealTimeCollectRms (args);
    }
}
