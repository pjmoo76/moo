package com.skb.mi.realtime;

import java.io.FileReader;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.sql.PreparedStatement;
import java.util.Calendar;

import org.apache.commons.cli.HelpFormatter;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.DBController;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.OutputLog;

public class CollectVocCode {
	final private	int PREPARED_STATEMENT_MAX = 10000;
	final private	int BUFFER_SIZE            = 1024;
	final private	String	ABSOLUTE_PATH      = "/app/swing/batch/subscriber";
	int 			bufferFront, bufferRear;
	byte [] 		buffer;
	FileInputStream	fis = null;
	
	String dbUrl, userName, password;
	DBController	dbController;
	OutputLog					outputLog;

	public CollectVocCode (String[] args) {
		int	readData = -1, count = 0, index = 0, rowCount = 0;
		byte [] procCnt 		= new byte [5];
		byte [] cnslCdSeq 		= new byte [7]; // O
		byte [] supCnslCdSeq 	= new byte [7]; // O
		byte [] mainCnslCd 		= new byte [8]; // O
		byte [] subCnslCd 		= new byte [8]; // O
		byte [] typCnslCd 		= new byte [8]; // O
		byte [] itmCnslCd 		= new byte [8]; 
		byte [] dtlCnslCd		= new byte [8];
		
		byte [] mainCnslCdNm	= new byte [100]; // O
		byte [] subCnslCdNm		= new byte [100]; // O
		byte [] typCnslCdNm		= new byte [100]; // O
		byte [] itmCnslCdNm		= new byte [100]; 
		byte [] dtlCnslCdNm		= new byte [100];
		
		byte [] lastCdLvl		= new byte [11]; // O 
		byte [] rgstDt			= new byte [8];
		byte [] dsatClCd		= new byte [2];
		byte []	actYn			= new byte [2]; 
		byte []	coClCd			= new byte [2];

		String scnslCdSeq;
		String ssupCnslCdSeq;
		String smainCnslCd;
		String ssubCnslCd;
		String stypCnslCd;
		String smainCnslCdNm;
		String ssubCnslCdNm;
		String stypCnslCdNm;
		String slastCdLvl; 
		
		PreparedStatement		preparedStatement = null;
				
		int						sortSeq = 1;

		outputLog = new OutputLog (true, this.getClass().getName (), EnvManager.env.getLogs());
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		dbUrl = configManager.getConfig(Constants.ADAMS_DB, Constants.DB_URL);
		userName = configManager.getConfig(Constants.ADAMS_DB, Constants.USER_NAME);
		password = configManager.getConfig(Constants.ADAMS_DB, Constants.PASSWORD);

		outputLog.write(String.format("(dbUrl:%s)", dbUrl));
		outputLog.write(String.format("(userName:%s)", userName));
		outputLog.write(String.format("(password:%s)", password));

		try {
            //readDbInfo ();
            dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
        } catch (Exception e ) {
            outputLog.write(e);
            if (dbController != null)
                dbController.closeDB ();
            outputLog.write("Finished");
            System.exit (0);
        }

		buffer = new byte [BUFFER_SIZE];
		bufferFront = bufferRear = 0;
		
		String	query;
		String processDate = getProcessDate (0);

		
//		query = "MERGE INTO OMN50101 USING DUAL"
//			  + " ON (CNSL_SER_NUM=?)"
//			  + " WHEN MATCHED THEN"
		query = "INSERT INTO OMN50111 (AUDIT_ID" 
				+ ", AUDIT_DTM"
				+ ", SORT_SEQ"
				+ ", VOC_TYP_CL_CD"
				+ ", SUP_VOC_TYP_CL_CD"
				+ ", MAX_VOC_TYP_CL_CD"
				+ ", MCL_VOC_TYP_CL_CD"
			    + ", SCL_VOC_TYP_CL_CD"
			    + ", MAX_VOC_TYP_CL_CD_NM"
			    + ", MCL_VOC_TYP_CL_CD_NM"
			    + ", SCL_VOC_TYP_CL_CD_NM"
			    + ", VOC_TYP_CL_CD_DEPTH_CNT"
				+ ", KPI_CHG_FUNC_ADD_YN"
				+ ", CO_CL_CD"
			    + ")"
			  + " VALUES ('admin', SYSDATE"
			    + ",?"
			    + ",?"
			    + ",?"
			    + ",?"
			    + ",?"
			    + ",?"
			    + ",?"
			    + ",?"
			    + ",?"
			    + ",?"
			    + ",?"
			    + ",?"
				+ ")";
		try {
			preparedStatement = dbController.getConnection().prepareStatement (query);
			fis = new FileInputStream (ABSOLUTE_PATH + File.separator + "zinbbcns04010-" + processDate + ".dat");
			query = "DELETE FROM OMN50111";
			dbController.getStmt ().executeUpdate(query);
			while (true) {
				index = 1;
				procCnt = getBytes (5);
				if (procCnt == null)
					break;
				print (new String (procCnt) + " | ");
//				preparedStatement.setString(index ++, new String (procCnt));
				
				cnslCdSeq = getBytes (7);
				if (cnslCdSeq == null)
					break;
				scnslCdSeq = new String (cnslCdSeq).trim ();
				print (scnslCdSeq + " | ");
				
				supCnslCdSeq = getBytes (7);
				if (supCnslCdSeq == null)
					break;
				ssupCnslCdSeq = new String (supCnslCdSeq).trim ();				
				print (ssupCnslCdSeq + " | ");

				mainCnslCd = getBytes (8);
				if (mainCnslCd == null)
					break;
				smainCnslCd = new String (mainCnslCd).trim ();
//				System.out.println ("smainCnslcd : " + smainCnslCd);
				print (smainCnslCd + " | ");
//				System.out.println ("smainCnslCd : " + smainCnslCd);
				
/**				if (smainCnslCd.equals("28069") 
				 || smainCnslCd.equals("28145") 
				 || smainCnslCd.equals("29925") 
				 || smainCnslCd.equals("38805") 
				 || smainCnslCd.equals("39351") 
				 || smainCnslCd.equals("39484")) {
**/				
					subCnslCd = getBytes (8);
					if (subCnslCd == null)
						break;
					ssubCnslCd = new String (subCnslCd).trim ();
					print (ssubCnslCd + " | ");
					
					typCnslCd = getBytes (8);
					if (typCnslCd == null)
						break;
					stypCnslCd = new String (typCnslCd).trim ();
					print (stypCnslCd + " | ");
					
					itmCnslCd = getBytes (8);
					if (itmCnslCd == null)
						break;
					print (new String (itmCnslCd) + " | ");
	//				preparedStatement.setString(index ++, new String (itmCnslCd));
					
					dtlCnslCd = getBytes (8);
					if (dtlCnslCd == null)
						break;
					print (new String (dtlCnslCd) + " | ");
	//				preparedStatement.setString(index ++, new String (dtlCnslCd));
					
					mainCnslCdNm = getBytes (100);
					if (mainCnslCdNm == null)
						break;
					smainCnslCdNm = new String (mainCnslCdNm, 0, mainCnslCdNm.length, "MS949").trim ();
					print (smainCnslCdNm + " | ");
					
					subCnslCdNm = getBytes (100);
					if (subCnslCdNm == null)
						break;
					ssubCnslCdNm = new String (subCnslCdNm, 0, subCnslCdNm.length, "MS949").trim ();
					print (ssubCnslCdNm + " | ");
					
					typCnslCdNm = getBytes (100);
					if (typCnslCdNm == null)
						break;
					stypCnslCdNm = new String (typCnslCdNm, 0, typCnslCdNm.length, "MS949").trim ();
					print (stypCnslCdNm + " | ");
	
					itmCnslCdNm = getBytes (100);
					if (itmCnslCdNm == null)
						break;
					print (new String (itmCnslCdNm, 0, itmCnslCdNm.length, "MS949").trim () + " | ");
	//				preparedStatement.setString(index ++, new String (itmCnslCdNm));
					
					dtlCnslCdNm = getBytes (100);
					if (dtlCnslCdNm == null)
						break;
					print (new String (dtlCnslCdNm, 0, dtlCnslCdNm.length, "MS949").trim () + " | ");
	//				preparedStatement.setString(index ++, new String (dtlCnslCdNm));
					
					lastCdLvl = getBytes (11);
					if (lastCdLvl == null)
						break;
					slastCdLvl = new String (lastCdLvl).trim ();
					print (slastCdLvl + " | ");
					
					dsatClCd [0] = getOneByte ();
					if (dsatClCd [0] == -1)
						break;
					print (new String (dsatClCd) + " | ");
	//				preparedStatement.setString (index ++, new String (dsatClCd, 0 ,1));
					
					actYn [0] = getOneByte ();
					if (actYn [0]== -1)
						break;
					print (new String (actYn, 0, 1) + " | ");
//					preparedStatement.setString (index ++, new String (actYn, 0, 1));
					
					rgstDt = getBytes (8);
					if (rgstDt == null)
						break;
					print (new String (rgstDt) + " | ");
	//				preparedStatement.setString (index ++, new String (rgstDt));
					
					coClCd [0] = getOneByte ();
					if (coClCd [0] == -1)
						break;
					println (new String (coClCd, 0, 1) + " | ");
//					preparedStatement.setString (index ++, new String (coClCd, 0, 1));
					
					preparedStatement.setInt(index ++, sortSeq++);
					preparedStatement.setString(index ++, scnslCdSeq);
					preparedStatement.setString(index ++, ssupCnslCdSeq);
					preparedStatement.setString(index ++, smainCnslCd);
					preparedStatement.setString(index ++, ssubCnslCd);
					preparedStatement.setString(index ++, stypCnslCd);
					preparedStatement.setString(index ++, smainCnslCdNm);
					preparedStatement.setString(index ++, ssubCnslCdNm);
					preparedStatement.setString(index ++, stypCnslCdNm);
					preparedStatement.setString(index ++, slastCdLvl);
					preparedStatement.setString(index ++, new String (actYn, 0, 1));
					preparedStatement.setString(index ++, new String (coClCd, 0, 1));
					preparedStatement.addBatch();
					++ rowCount;
					if (rowCount % PREPARED_STATEMENT_MAX == 0)
						preparedStatement.executeBatch ();
						
					while ((readData = getOneByte ()) != -1) {
						if (readData == 0x0a)
							break;
						
						outputLog.write(String.format("%02x.", readData));
					}
					++ count;
				}
//			}
		} catch (Exception e) {
			outputLog.write(e); 
		} finally {
			try {
				fis.close ();
			} catch (Exception e) {
			}
		}
		try {	
			preparedStatement.executeBatch ();
			preparedStatement.close ();
			fis.close ();
		} catch (Exception e) {
		}
		dbController.closeDB ();
		outputLog.write("총 건수 : " + count);
		
		dbController.closeDB ();
	}

	public byte getOneByte () {
        try {
            if (bufferFront == bufferRear) {
                bufferFront = 0;
                bufferRear = fis.read (buffer);
            }
            
            if (bufferRear != -1)
            	return buffer [bufferFront ++];
        } catch (Exception e) {
        	outputLog.write(e);
        }
        return -1;
    }

    public byte [] getBytes (int number) {
        byte [] bytes = new byte [number];
        byte temp;
        for (int index = 0; index < number; ++ index) {
            temp = getOneByte ();
            if (temp == -1)
                return null;
            bytes [index] = temp;
        }
        return bytes;
    }

    /*
    public void readDbInfo () throws Exception {
        String  oneLine;
        FileReader  fileReader = new FileReader (absolutePath + File.separator + "db.info");
        BufferedReader bufferedReader = new BufferedReader (fileReader);
        dbUrl = bufferedReader.readLine ();
        userName = bufferedReader.readLine ();
        password = bufferedReader.readLine ();
        bufferedReader.close ();
        fileReader.close ();
    }*/

	public String getDateSecond () {
		Calendar	cal = Calendar.getInstance();
		return String.format("%04d-%02d-%02d %02d:%02d:%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH),
				cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND));
	}
	
	public void print (String str) {
//		System.out.print (str);
	}
	
	public void println (String str) {		
//		System.out.println (str);
	}

	public String getProcessDate (int day) {
		Calendar	cal = Calendar.getInstance();
		
		cal.add (Calendar.DAY_OF_MONTH, day);
		return String.format("%04d%02d%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH));
	}

	public static void main(String[] args) {
		EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("CollectVocCode", envManager.getOptions());
    		System.exit(0);
    	}
		new CollectVocCode (args);
	}
}
