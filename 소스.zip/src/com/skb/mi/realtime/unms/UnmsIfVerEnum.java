package com.skb.mi.realtime.unms;

public enum UnmsIfVerEnum {
	V1, Track2, Outct;
}
