package com.skb.mi.realtime.unms;

public class UnmsLongCallClrEvent extends UnmsEvent {
	
	private	String	nmsMgmtNum;
	private	String	actDtm;
	
	public UnmsLongCallClrEvent(String[] items) {
		super(UnmsServiceTypeEnum.SERVICE_LONG_CALL_CLR);
		set(items);
	}

	/*
	 * Sample
	 * 
0 :		20180805002000
1 :		2932524
	 */

	public String getNmsMgmtNum() {
		return nmsMgmtNum;
	}

	public String getActDtm() {
		return actDtm;
	}

	private void set(String[] items) {
		this.actDtm = items[0];
		this.nmsMgmtNum = items[1];
	}

	@Override
	public String debugString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("[ServiceCode=%s]\n", this.getServiceCode().toString()));
		sb.append(String.format("(nmsMgmtNum=%s)\n", nmsMgmtNum));
		sb.append(String.format("(actDtm=%s)", actDtm));
		return sb.toString();
	}

}
