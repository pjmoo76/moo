package com.skb.mi.realtime.unms;


public class UnmsEvent {
	private	UnmsServiceTypeEnum	serviceCode;
	protected	String	nmsType;	/* NMS유형 */
	protected	String	nmsCd;
	
	// 장애이벤트 NMS명과 현재메시지 NMS명 통일
	static public final String	NMS_PSTN_CD	= "4101";
	//static public final String	NMS_PSTN_NM	= "시내전화망";
	static public final String	NMS_PSTN_NM	= "PSTN";

	static public final String	NMS_VOIP_BB_CD	= "4201";
	//static public final String	NMS_VOIP_BB_NM	= "디지털기간망";
	static public final String	NMS_VOIP_BB_NM	= "VoIP_기간망";
	
	static public final String	NMS_VOIP_SN_CD	= "4301";
	//static public final String	NMS_VOIP_SN_NM	= "디지털가입자망";
	static public final String	NMS_VOIP_SN_NM	= "VoIP_가입자망";
	//시외전화망
	static public final String	NMS_OUTCT_SN_CD	= "4501";
	static public final String	NMS_OUTCT_SN_NM	= "시외망";

	static protected final String	NMS_CD_PSTN				= "002";
	static protected final String	NMS_CD_VOIP				= "007";
	static protected final String	NMS_CD_UNMS_OUTCT		= "019";
	static protected final String	NMS_CD_IOMC				= "020";
	static protected final String	NMS_CD_PSTN_AUTO_SVC_GW	= "021";
	static protected final String	NMS_CD_VOIP_AUTO_SVC_GW	= "022";

	public UnmsEvent(UnmsServiceTypeEnum serviceCode) {
		this.serviceCode = serviceCode;
	}
	
	public UnmsServiceTypeEnum getServiceCode() {
		return serviceCode;
	}

	public String getNmsCd() {
		if (isUnms()) {
			if ("0".equals(nmsType) || NMS_PSTN_CD.equals(nmsType)) {
				return NMS_PSTN_CD;
			} else if ("1".equals(nmsType) || NMS_VOIP_BB_CD.equals(nmsType)) {
				return NMS_VOIP_BB_CD;
			} else if ( NMS_OUTCT_SN_CD.equals(nmsType) || NMS_CD_UNMS_OUTCT.equals(nmsType)) {
				return NMS_OUTCT_SN_CD;
			}else {
				return NMS_VOIP_SN_CD;
			}
		} else {
			return nmsCd;
		}
	}

	// WebPush에서 UNMS 실시간 장애 처리 시 "002"(PSTN), "007"(VOIP) 기준으로 하고 있음.
	// 따라서, 장애발생/장애해지 이벤트의 경우 NMS_CD 값은 getOrgNmsCd()를 통해 처리해야 함
	public String getOrgNmsCd() {
		if (isUnms()) {
			if ("0".equals(nmsType) || NMS_PSTN_CD.equals(nmsType)) {
				return NMS_CD_PSTN;
			} else {
				return NMS_CD_VOIP;
			}
		} else {
			if (NMS_CD_PSTN_AUTO_SVC_GW.equals(nmsCd)) { // 
				return NMS_CD_PSTN;
			} else if (NMS_CD_VOIP_AUTO_SVC_GW.equals(nmsCd)) {
				return NMS_CD_VOIP;
			} else {
				return nmsCd;
			}
		}
	}
	
	public String getNmsName() {
		if (isUnms()) {
			if ("0".equals(nmsType) || NMS_PSTN_CD.equals(nmsType)) {
				return NMS_PSTN_NM;
			} else if ("1".equals(nmsType) || NMS_VOIP_BB_CD.equals(nmsType)) {
				return NMS_VOIP_BB_NM;
			} else if ( NMS_OUTCT_SN_CD.equals(nmsType)) {
				return NMS_OUTCT_SN_NM;
			}else {
				return NMS_VOIP_SN_NM;
			}
		} else {
			if (NMS_CD_UNMS_OUTCT.equals(nmsCd))
			{
				return NMS_OUTCT_SN_NM;
			}else{
				return null;
			}
			
		}
	}
	
	private boolean isUnms() {
		if (NMS_CD_UNMS_OUTCT.equals(nmsCd) || NMS_CD_IOMC.equals(nmsCd) || NMS_CD_PSTN_AUTO_SVC_GW.equals(nmsCd) || NMS_CD_VOIP_AUTO_SVC_GW.equals(nmsCd)) {
			return false;
		} else {
			return true;
		}
	}
	
	public String debugString() {
		return null;
	}
}
