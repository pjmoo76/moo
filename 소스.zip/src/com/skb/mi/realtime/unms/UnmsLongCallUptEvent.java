package com.skb.mi.realtime.unms;

public class UnmsLongCallUptEvent extends UnmsEvent {

	private	String	nmsMgmtNum;
	private	String	actDtm;
	private	String	keepTms;

	public UnmsLongCallUptEvent(String[] items) {
		super(UnmsServiceTypeEnum.SERVICE_LONG_CALL_UPT);
		set(items);
	}

	public String getNmsMgmtNum() {
		return nmsMgmtNum;
	}

	public String getActDtm() {
		return actDtm;
	}

	public String getKeepTms() {
		return keepTms;
	}

	/*
	 * Sample
	 * 
0 :		2909616
1 :		20180805000501
2 :		17938993
	 */
	private void set(String[] items) {
		this.nmsMgmtNum = items[0];
		this.actDtm = items[1];
		this.keepTms = items[2];
	}

	@Override
	public String debugString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("[ServiceCode=%s]\n", this.getServiceCode().toString()));
		sb.append(String.format("(nmsMgmtNum=%s)\n", nmsMgmtNum));
		sb.append(String.format("(actDtm=%s)\n", actDtm));
		sb.append(String.format("(keepTms=%s)", keepTms));
		return sb.toString();
	}
}
