package com.skb.mi.realtime.unms;

public class UnmsLongCallGenEvent extends UnmsEvent {

	private	String	nmsMgmtNum;
	private	String	neId;
	private	String	occrDtm;
	private	String	ocallNum;
	private	String	icallNum;
	private	String	routInInfo;
	private	String	routOutInfo;
	private	String	tcStaDtm;
	private	String	keepTms;
	private	String	ltmCallActClCd;
	
	public UnmsLongCallGenEvent(String[] items) {
		super(UnmsServiceTypeEnum.SERVICE_LONG_CALL_GEN);
		set(items);
	}
	
	public String getNmsMgmtNum() {
		return nmsMgmtNum;
	}

	public String getNeId() {
		return neId;
	}

	public String getOccrDtm() {
		return occrDtm;
	}

	public String getOcallNum() {
		return ocallNum;
	}

	public String getIcallNum() {
		return icallNum;
	}

	public String getRoutInInfo() {
		return routInInfo;
	}

	public String getRoutOutInfo() {
		return routOutInfo;
	}

	public String getTcStaDtm() {
		return tcStaDtm;
	}

	public String getKeepTms() {
		return keepTms;
	}

	public String getLtmCallActClCd() {
		return ltmCallActClCd;
	}

	/*
	 * Sample
	 * 
00 :	2932542
01 :	0
02 :	30
03 :	경기고양단국1
04 :	0_2
05 :	STAREX-TX1A
06 :	20180805000001
07 :	13708611201000000000000000h0  (SSP=SSP000, LINE=327051504027528201000000000156613708611201000000000000000h0
08 :	051504027528201000000000156613708611201000000000000000h0
09 :	000h0
10 :	90  (SSP=SSP100, LINE=472)
11 :	20170317085516
12 :	43686285
13 :	N
14 :	53
15 :	15/53
16 :	경기/고양
	 */
	private void set(String[] items) {
		this.nmsMgmtNum = items[0];
		this.neId = items[2];
		this.occrDtm = items[6];
		this.ocallNum = items[7];
		this.icallNum = items[8];
		this.routInInfo = items[9];
		this.routOutInfo = items[10];
		this.tcStaDtm = items[11];
		this.keepTms = items[12];
		this.ltmCallActClCd = items[13];
	}

	@Override
	public String debugString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("[ServiceCode=%s]\n", this.getServiceCode().toString()));
		sb.append(String.format("(nmsMgmtNum=%s)\n", nmsMgmtNum));
		sb.append(String.format("(neId=%s)\n", neId));
		sb.append(String.format("(occrDtm=%s)\n", occrDtm));
		sb.append(String.format("(ocallNum=%s)\n", ocallNum));
		sb.append(String.format("(icallNum=%s)\n", icallNum));
		sb.append(String.format("(routInInfo=%s)\n", routInInfo));
		sb.append(String.format("(routOutInfo=%s)\n", routOutInfo));
		sb.append(String.format("(tcStaDtm=%s)\n", tcStaDtm));
		sb.append(String.format("(keepTms=%s)\n", keepTms));
		sb.append(String.format("(ltmCallActClCd=%s)", ltmCallActClCd));
		return sb.toString();
	}

}
