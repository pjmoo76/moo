package com.skb.mi.realtime.unms;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;

import org.apache.log4j.Logger;

import com.skb.mi.common.SockUtils;
import com.skb.mi.common.StringUtils;

public class UnmsHeader {
	final private int	HEADER_LEN	= 20;

	private	char	pduType;
	private	String	serviceCode;
	private String	messageSerialNo;
	private	char	lastYn;
	private	char	responseResult;
	private String	extendArea;
	private	int		bodyLength;
	
	private	byte[]	header;
	private	Logger	logger;
	
	public UnmsHeader() {
		this.logger = Logger.getLogger(this.getClass());
		header = new byte[HEADER_LEN];
	}
	
	public void setPduType(char pduType) {
		this.pduType = pduType;
	}
	
	public String getServiceCode() {
		return this.serviceCode;
	}

	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}
	
	public void setMessageSerialNo(String messageSerialNo) {
		this.messageSerialNo = messageSerialNo;
	}
	
	public void setLastYn(char lastYn) {
		this.lastYn = lastYn;
	}
	
	public void setResponseResult(char responseResult) {
		this.responseResult = responseResult;
	}
	
	public void setExtendArea(String extendArea) {
		this.extendArea = extendArea;
	}
	
	public int getBodyLength() {
		return this.bodyLength;
	}

	public void setBodyLength(int bodyLength) {
		this.bodyLength = bodyLength;
	}

	/*
	 * ESC				1 byte	0
	 * STX				1 byte	1
	 * PduType			1 byte	2
	 * ServiceCode		4 byte	3
	 * messageSerialNo	2 byte	7		// 99
	 * lastYn			1 byte	9
	 * responseResult	1 byte	10		// 0 | 1
	 * extendArea		4 byte	11		// 0021
	 * bodyLength		5 byte	15
	 */

	public static final byte 	ESC = 0x1b;
	public static final byte 	STX = 0x02;				// Start of Text
	public static final char	PDU_EVENT		= '1';	// 0x31
	public static final char	PDU_REQUEST		= '2';	// 0x32
	public static final char	PDU_RESPONSE	= '3';	// 0x33
	public static final String	MSN_BLANK		= "00";	//
	public static final String	MSN_DONT_CARE	= "99";	// Don't care
	public static final char	LAST_Y			= '1';
	public static final char	LAST_N			= '0';
	public static final char	RESPONSE_FAIL	= '0';
	public static final char	RESPONSE_SUCC	= '1';
	public static final String	EA_BLANK		= "0000";
	public static final String	EA_DONT_CARE	= "0021";	// Don't Care
	
	public static final String	SVCD_ECHO			= "0000";
	public static final String	SVCD_EVENT_PORT		= "0301";
	public static final String	SVCD_TRAFFIC_PORT	= "0302";
	public static final String	SVCD_LOGIN			= "0400";

	public boolean read(InputStream is) throws Exception {
		int len = SockUtils.read(is, header, header.length);
		if (len != HEADER_LEN) {
			logger.error(String.format("invalid header len (%d:%d)", HEADER_LEN, len));
			return false;
		}

		//logger.debug(StringUtils.toHexString(header));
		//logger.debug(StringUtils.toReadableString(header));

		if (header[0] != ESC) return false;
		if (header[1] != STX) return false;
		pduType = (char) header[2];
		if (pduType != PDU_EVENT && pduType != PDU_REQUEST && pduType != PDU_RESPONSE) return false;
		serviceCode = new String(getBytes(header, 3, 4));
		if (header[10] != RESPONSE_FAIL && header[10] != RESPONSE_SUCC) return false;
		bodyLength = Integer.parseInt(new String(getBytes(header, 15, 5)));
		
		return true;
	}
	
	public void write(OutputStream os) throws Exception {
		Arrays.fill(header, (byte) 0x00);
		header[0] = ESC;
		header[1] = STX;
		header[2] = (byte) this.pduType;
		System.arraycopy(serviceCode.getBytes(), 0, header, 3, serviceCode.length());
		System.arraycopy(messageSerialNo.getBytes(), 0, header, 7, messageSerialNo.length());
		header[9] = (byte) this.lastYn;
		header[10] = (byte) this.responseResult;
		System.arraycopy(extendArea.getBytes(), 0, header, 11, extendArea.length());
		String tmp = String.format("%05d", bodyLength);
		System.arraycopy(tmp.getBytes(), 0, header, 15, tmp.length());

		logger.debug(StringUtils.toHexString(header));
		logger.debug(StringUtils.toReadableString(header));

		os.write(header);
	}
	
	private byte[] getBytes(byte[] src, int pos, int len) {
		byte[] dest = new byte[len];
		System.arraycopy(src, pos, dest, 0, len);
		return dest;
	}
}
