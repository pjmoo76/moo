package com.skb.mi.realtime.unms;

public class UnmsFaultEvent extends UnmsEvent {
	private	String	alarmNo;	/* 장애번호 */
	private	String	neId;		/* 장비ID */
	private	String	neIp;		/* 장비IP */
	private	String	neName;		/* 장비명 */
	private	String	neSysName;	/* 장비SYS명 (Track2) */
	private	String	neModelId;	/* 장비모델ID */
	private	String	neModelName;	/* 장비모델명 */
	private	String	location;		/* 장애발생위치 */
	private	String	reason;			/* 장애발생사유 */
	private	String	inform;			/* 장애상세정보 */
	private	String	alarmClass;		/* 장애분류 */
	private	String	alarmType;		/* 장애세부유형 */
	private	String	alarmLevel;		/* 장애등급 */
	private	String	alarmCode;		/* 장애코드 */
	private	String	moduleType;		/* 모듈코드 */
	private	String	moduleName;		/* 모듈명 (VoIP Alarm) */
	private	String	moduleNeId;		/* 모듈장비ID */
	private	String	moduleNeName;	/* 모듈장비명 */
	private	String	moduleNeIp;		/* 모듈장비IP (Track2) */
	private	String	slotNo;			/* 슬롯번호 */
	private	String	portNo;			/* 포트번호 */
	private	String	portIndex;		/* 포트Index */
	private	String	portConnType;	/* 포트유형 */
	private	String	portDescr;		/* 포트설명 */
	private	String	routes;			/* 루트번호 */
	private String	mainProc;
	private	String	subProc;
	private	String	occrTime;		/* 장애발생시각 */
	private	String	workMode;		/* 작업중여부 */
	private	String	workEndTime;	/* 작업종료시각 */
	private	String	neNodeId;		/* 장비소속노드ID */
	private	String	neNodeIds;		/* 장비소속 노드 코드들 */
	private	String	neNodeNames;	/* 장비소속 노드명들 */
	private	String	equipDablNumCtt;	/* 장비장애번호내용 (Track2) */
	private	String	etc;			/* 기타사항 */
	private	String	vip;
	private	int		subsCnt;		/* 가입자수 */
	private	String	tmId;
	private	String	carrierName;
	private String  svcMgmtNum;
	private	String	numEvent;

	public UnmsFaultEvent(UnmsIfVerEnum ifVer, String[] items) {
		super(UnmsServiceTypeEnum.SERVICE_CODE_FAULT);
		set(ifVer, items);
	}

	public String getAlarmNo() {
		return alarmNo;
	}

	public String getNmsType() {
		return nmsType;
	}

	public String getNeId() {
		return neId;
	}

	public String getNeIp() {
		return neIp;
	}

	public String getNeName() {
		return neName;
	}

	public String getNeSysName() {
		return neSysName;
	}

	public String getNeModelId() {
		return neModelId;
	}

	public String getNeModelName() {
		return neModelName;
	}

	public String getLocation() {
		return location;
	}

	public String getReason() {
		return reason;
	}

	public String getInform() {
		return inform;
	}

	public String getAlarmClass() {
		return alarmClass;
	}

	public String getAlarmType() {
		return alarmType;
	}

	public String getAlarmLevel() {
		return alarmLevel;
	}

	public String getAlarmCode() {
		return alarmCode;
	}

	public String getModuleType() {
		return moduleType;
	}

	public String getModuleName() {
		return moduleName;
	}

	public String getModuleNeId() {
		return moduleNeId;
	}

	public String getModuleNeName() {
		return moduleNeName;
	}

	public String getModuleNeIp() {
		return moduleNeIp;
	}

	public String getSlotNo() {
		return slotNo;
	}

	public String getPortNo() {
		return portNo;
	}

	public String getPortIndex() {
		return portIndex;
	}

	public String getPortConnType() {
		return portConnType;
	}

	public String getPortDescr() {
		return portDescr;
	}

	public String getRoutes() {
		return routes;
	}

	public String getMainProc() {
		return mainProc;
	}

	public String getSubProc() {
		return subProc;
	}

	public String getOccrTime() {
		return occrTime;
	}

	public String getWorkMode() {
		return workMode;
	}

	public String getWorkEndTime() {
		return workEndTime;
	}

	public String getNeNodeId() {
		return neNodeId;
	}

	public String getNeNodeIds() {
		return neNodeIds;
	}

	public String getNeNodeNames() {
		return neNodeNames;
	}

	public String getEtc() {
		return etc;
	}

	public String getVip() {
		return vip;
	}

	public int getSubsCnt() {
		return subsCnt;
	}

	public String getTmId() {
		return tmId;
	}

	public String getCarrierName() {
		return carrierName;
	}

	public String getNumEvent() {
		return numEvent;
	}
	
	public String getEquipDablNumCtt() {
		return equipDablNumCtt;
	}
	
	public String getSvcMgmtNum() {
		return svcMgmtNum;
	}

	private void set(UnmsIfVerEnum ifVer, String[] items) {
		if (ifVer == UnmsIfVerEnum.V1) {
			this.setV1(items);
		} else if (ifVer == UnmsIfVerEnum.Track2 || ifVer == UnmsIfVerEnum.Outct) {
			this.setTrack2(items);
		}
	}
	
	/*
	 * Sample
	 * 
00 : 60520606
01 : 0
02 : 24
03 : 12.16.180.121
04 : 서울강남단국1
05 : 0_1
06 : SDX-200
07 : LOC : ASS110/ASPP1/UNIT00/LINK05
08 : PRI LINK  FAIL
09 : INF : ASP     LN      LN_TYPE  DN_RTE
             ASP110  00065   PRI_T    1924
       ADT : 2018-08-04 23:59:54
10 : 0
11 : 0
12 : 2
13 : A6031
14 : 3
15 : ASS110
16 :
17 :
18 :
19 :
20 :
21 :
22 :
23 :
24 : ASP110
25 : ASPP1
26 : 20180804235955
27 : N
28 :
29 : 51
30 : 6/51
31 : 서울/강남
32 : +++ SLKNML1 2018-08-04 23:59:55 SAT
   * A6031 PRI LINK  FAIL
       LOC : ASS110/ASPP1/UNIT00/LINK05
       INF : ASP     LN      LN_TYPE  DN_RTE
             ASP110  00065   PRI_T    1924
       ADT : 2018-08-04 23:59:54
     COMPLETED
33 :
34 :
35 : 0
36 :
	 */
	private void setV1(String[] items) {
		this.alarmNo = items[0];
		this.nmsType = items[1];
		this.neId = items[2];
		this.neIp = items[3];
		this.neName = items[4];
		this.neModelId = items[5];
		this.neModelName = items[6];
		this.location = items[7];
		this.reason = items[8];
		this.inform = items[9];
		this.alarmClass = items[10];
		this.alarmType = items[11];
		this.alarmLevel = items[12];
		this.alarmCode = items[13];
		this.moduleType = items[14];
		this.moduleName = items[15];
		this.moduleNeId = items[16];
		this.moduleNeName = items[17];
		this.slotNo = items[18];
		this.portNo = items[19];
		this.portIndex = items[20];
		this.portConnType = items[21];
		this.portDescr = items[22];
		this.routes = items[23];
		this.mainProc = items[24];
		this.subProc = items[25];
		this.occrTime = items[26];
		this.workMode = items[27];
		this.workEndTime = items[28];
		this.neNodeId = items[29];
		this.neNodeIds = items[30];
		this.neNodeNames = items[31];
		this.etc = items[32] + items[33];	/* etc1 + etc2 */
		this.vip = items[34];
		try {
			this.subsCnt = Integer.parseInt(items[35]);
			if (this.subsCnt < 0) this.subsCnt = 0;
		} catch (Exception e) {
			this.subsCnt = 0;
		}
		this.tmId = items[36];
		if (items.length > 37) {
			this.carrierName = items[37];
		}
		if (items.length > 38) {
			this.numEvent = items[38];
		}
	}
	
	private void setTrack2(String[] items) {
		this.alarmNo = items[0];
		this.nmsType = items[1];
		this.neId = items[2];
		this.neIp = items[3];
		this.neName = items[4];
		this.neSysName = items[5];
		this.neModelId = items[6];
		this.neModelName = items[7];
		this.location = items[8];
		this.reason = items[9];
		this.inform = items[10];
		this.alarmClass = items[11];
		this.alarmType = items[12];
		this.alarmLevel = items[13];
		this.alarmCode = items[14];
		this.moduleType = items[15];
		this.moduleName = items[16];
		this.moduleNeId = items[17];
		this.moduleNeName = items[18];
		this.moduleNeIp = items[19];
		this.slotNo = items[20];
		this.portNo = items[21];
		this.portIndex = items[22];
		this.portConnType = items[23];
		this.portDescr = items[24];
		this.routes = items[25];
		this.mainProc = items[26];
		this.subProc = items[27];
		this.occrTime = items[28];
		this.workMode = items[29];
		this.workEndTime = items[30];
		this.neNodeId = items[31];
		this.neNodeIds = items[32];
		this.neNodeNames = items[33];
		this.equipDablNumCtt = items[34];
		this.etc = items[35];
		this.vip = items[36];
		try {
			this.subsCnt = Integer.parseInt(items[37]);
			if (this.subsCnt < 0) this.subsCnt = 0;
		} catch (Exception e) {
			this.subsCnt = 0;
		}
		if (items.length > 38) {
			this.tmId = items[38];
		}
		if (items.length > 39) {
			this.carrierName = items[39];
		}
		if (items.length > 40) {
			this.nmsCd = items[40];
		}
		if (items.length > 41) {
			this.svcMgmtNum = items[41];
		}
		if (items.length > 42) {
			this.numEvent = items[42];
		}
	}

	@Override
	public String debugString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("[ServiceCode=%s]\n", this.getServiceCode().toString()));
		sb.append(String.format("(alarmNo=%s)\n", alarmNo));
		sb.append(String.format("(nmsType=%s)\n", nmsType));
		sb.append(String.format("(neId=%s)\n", neId));
		sb.append(String.format("(neIp=%s)\n", neIp));
		sb.append(String.format("(neName=%s)\n", neName));
		sb.append(String.format("(neSysName=%s)\n", neSysName));
		sb.append(String.format("(neModelId=%s)\n", neModelId));
		sb.append(String.format("(neModelName=%s)\n", neModelName));
		sb.append(String.format("(location=%s)\n", location));
		sb.append(String.format("(reason=%s)\n", reason));
		sb.append(String.format("(inform=%s)\n", inform));
		sb.append(String.format("(alarmClass=%s)\n", alarmClass));
		sb.append(String.format("(alarmType=%s)\n", alarmType));
		sb.append(String.format("(alarmLevel=%s)\n", alarmLevel));
		sb.append(String.format("(alarmCode=%s)\n", alarmCode));
		sb.append(String.format("(moduleType=%s)\n", moduleType));
		sb.append(String.format("(moduleName=%s)\n", moduleName));
		sb.append(String.format("(moduleNeId=%s)\n", moduleNeId));
		sb.append(String.format("(moduleNeName=%s)\n", moduleNeName));
		sb.append(String.format("(moduleNeIp=%s)\n", moduleNeIp));
		sb.append(String.format("(slotNo=%s)\n", slotNo));
		sb.append(String.format("(portNo=%s)\n", portNo));
		sb.append(String.format("(portIndex=%s)\n", portIndex));
		sb.append(String.format("(portConnType=%s)\n", portConnType));
		sb.append(String.format("(portDescr=%s)\n", portDescr));
		sb.append(String.format("(routes=%s)\n", routes));
		sb.append(String.format("(mainProc=%s)\n", mainProc));
		sb.append(String.format("(subProc=%s)\n", subProc));
		sb.append(String.format("(occrTime=%s)\n", occrTime));
		sb.append(String.format("(workMode=%s)\n", workMode));
		sb.append(String.format("(workEndTime=%s)\n", workEndTime));
		sb.append(String.format("(neNodeId=%s)\n", neNodeId));
		sb.append(String.format("(neNodeIds=%s)\n", neNodeIds));
		sb.append(String.format("(neNodeNames=%s)\n", neNodeNames));
		sb.append(String.format("(equipDablNumCtt=%s)\n", equipDablNumCtt));
		sb.append(String.format("(etc=%s)\n", etc));
		sb.append(String.format("(vip=%s)\n", vip));
		sb.append(String.format("(subsCnt=%d)\n", subsCnt));
		sb.append(String.format("(tmId=%s)\n", tmId));
		sb.append(String.format("(carrierName=%s)\n", carrierName));
		sb.append(String.format("(nmsCd=%s)\n", nmsCd));
		sb.append(String.format("(svcMgmtNum=%s)", svcMgmtNum));
		sb.append(String.format("(numEvent=%s)", numEvent));
		return sb.toString();
	}

}
