package com.skb.mi.realtime.unms;

public enum UnmsServiceTypeEnum {
	SERVICE_CODE_FAULT("0411"),
	SERVICE_CODE_CLEAR("0413"),
	SERVICE_MESSAGE("0430"),
	SERVICE_LONG_CALL_GEN("0421"),
	SERVICE_LONG_CALL_UPT("0422"),
	SERVICE_LONG_CALL_CLR("0423")
	;

	private	final String	eventType;

	UnmsServiceTypeEnum(String eventType) {
		this.eventType = eventType;
	}
	
	public String getEventType() {
		return this.eventType;
	}

	public static void main (String [] args) {
		UnmsServiceTypeEnum message = UnmsServiceTypeEnum.SERVICE_MESSAGE;
		if ("0430".equals(UnmsServiceTypeEnum.SERVICE_MESSAGE.getEventType())) {
			System.out.println("matched");
		} else {
			System.out.println("not matched");
		}
	}
}
