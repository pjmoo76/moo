package com.skb.mi.realtime.unms;

import java.io.InputStream;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.skb.mi.common.SockUtils;
import com.skb.mi.common.StringUtils;

public class UnmsEventFactory {
	final int	HEADER_LEN	= 20;
	final byte	ESC = 0x1b;
	final byte	STX = 0x02;				// Start of Text
	final char	PDU_EVENT		= '1';	// 0x31
	final char	PDU_REQUEST		= '2';	// 0x32
	final char	PDU_RESPONSE	= '3';	// 0x33

	static public final byte 	IDENTIFIER	= 0x1f;
	final String	CHARSET_NAME	= "EUC-KR";

	private	Logger	logger;
	private	UnmsIfVerEnum ifVer;
	private	byte[]	header;
	
	public UnmsEventFactory(UnmsIfVerEnum ifVer) {
		this.logger = LogManager.getLogger(this.getClass());
		this.ifVer = ifVer;
		this.header = new byte[HEADER_LEN];
	}

	public UnmsEvent get(InputStream is) throws Exception {
		/*
		 * ESC				: 1 byte
		 * STX				: 1 byte
		 * PduType			: 1 byte (1: Event, 2: Request, 3: Response)
		 * ServiceCode		: 4 byte
		 * messageSerialNo	: 2 byte
		 * lastYn			: 1 byte
		 * responseResult	: 1 byte
		 * extendArea		: 4 byte
		 * bodyLength		: 5 byte
		 */
		int len = SockUtils.read(is, header, header.length);
		if (len != HEADER_LEN) {
			throw new Exception(String.format("failed to read header (%d,%d)", HEADER_LEN, len));
		}
		if (header[0] != ESC) {
			throw new Exception("header[0] is not ESC");
		}
		if (header[1] != STX) {
			throw new Exception("header[1] is not STX");
		}
		char pduType = (char) header[2];
		if (pduType != PDU_EVENT && pduType != PDU_REQUEST && pduType != PDU_RESPONSE) {
			throw new Exception("invalid pduType : " + pduType);
		}
		String serviceCode = new String(StringUtils.getBytes(header, 3, 4));
		int bodyLength = Integer.parseInt(new String(StringUtils.getBytes(header, 15, 5)));

		byte[] body = new byte[bodyLength];
		len = SockUtils.read(is, body, body.length);
		if (len != bodyLength) {
			throw new Exception(String.format("failed to read body (%d,%d)", bodyLength, len));
		}
		
		//logger.debug(StringUtils.toReadableString(body));
		//logger.debug(StringUtils.toHexString(body));
		
		logger.debug("serviceCode:" + serviceCode);
		String[] items = StringUtils.split(body, IDENTIFIER, CHARSET_NAME);
		//시외망 프로세스
		if (this.ifVer == UnmsIfVerEnum.Outct) {
			
			if("0411".equals(serviceCode))
			{
				
				if("4501".equals(items[1])){
					logger.debug("0411GEN4501");
					for (int i = 0; i < items.length; i ++) {
						logger.debug(String.format("[%d]%s", i, items[i]));
						
					}
				}
			}else if ("0413".equals(serviceCode)){
				if("4501".equals(items[8]) || "019".equals(items[8])){
					for (int i = 0; i < items.length; i ++) {
						logger.debug(String.format("[%d]%s", i, items[i]));
						
					}
				}
			}else if ("0430".equals(serviceCode)){
				if("4501".equals(items[0])){
					for (int i = 0; i < items.length; i ++) {
						logger.debug(String.format("[%d]%s", i, items[i]));
						
					}
				}
			}
		}else{
			logger.debug("serviceCode:" + serviceCode);
			for (int i = 0; i < items.length; i ++) {
				logger.debug(String.format("[%d]%s", i, items[i]));
				
			}
		}
		
		
		UnmsEvent event = null;
		if (serviceCode.equals(UnmsServiceTypeEnum.SERVICE_CODE_FAULT.getEventType())) {
			event = new UnmsFaultEvent(ifVer, items);
		} else if (serviceCode.equals(UnmsServiceTypeEnum.SERVICE_CODE_CLEAR.getEventType())) {
			event = new UnmsClearEvent(ifVer, items);
		} else if (serviceCode.equals(UnmsServiceTypeEnum.SERVICE_LONG_CALL_GEN.getEventType())) {
			event = new UnmsLongCallGenEvent(items);
		} else if (serviceCode.equals(UnmsServiceTypeEnum.SERVICE_LONG_CALL_UPT.getEventType())) {
			event = new UnmsLongCallUptEvent(items);
		} else if (serviceCode.equals(UnmsServiceTypeEnum.SERVICE_LONG_CALL_CLR.getEventType())) {
			event = new UnmsLongCallClrEvent(items);
		} else if (serviceCode.equals(UnmsServiceTypeEnum.SERVICE_MESSAGE.getEventType())) {
			event = new UnmsMessageEvent(items);
		} else {
			logger.error("invalid serviceCode : " + serviceCode);
		}
		if (this.ifVer == UnmsIfVerEnum.Outct) {
			
			if("0411".equals(serviceCode))
			{
				
				if("4501".equals(items[1])){
					logger.debug("0411GEN4501 nmsCd"+event.getNmsCd());
				}
			}else if ("0413".equals(serviceCode)){
				if("4501".equals(items[8]) || "019".equals(items[8])){
					logger.debug("0413CLR4501 nmsCd"+event.getNmsCd()+"nmsType : "+event.nmsType);
				}
			}
		}
		return event;
	}
}
