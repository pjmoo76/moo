package com.skb.mi.realtime.unms;

public class UnmsMessageEvent extends UnmsEvent {
	
	private	String	neId;
	private	String	mntrDtm;
	private	String	msgStCd;
	private	String	msgNm;
	private	String	msgCtt;

	public UnmsMessageEvent(String[] items) {
		super(UnmsServiceTypeEnum.SERVICE_MESSAGE);
		set(items);
	}
	
	public String getNeId() {
		return neId;
	}

	public String getMntrDtm() {
		return mntrDtm;
	}

	public String getMsgStCd() {
		return msgStCd;
	}

	public String getMsgNm() {
		return msgNm;
	}

	public String getMsgCtt() {
		return msgCtt;
	}

	/*
	 * Sample
	 * 
0 :		0
1 :		30
2 :		경기고양단국1
3 :		0_2
4 :		KGGYNL1
5 :		20180805000000
6 : 	S7610
7 :		NETWORK SYNCHRONIZATION STATUS HOURLY REPORT
8 :		+++ KGGYNL1 2018-08-05 00:00:00 SUN
		     S7610 NETWORK SYNCHRONIZATION STATUS HOURLY REPORT
		       HOST
		       MSTR   LOCK_MD    DACW    REF_TYPE    REF_NO  SLIP_CNT
		       0      NORM       H'83ae  DOTS        1              0
		     COMPLETED
	 */
	private void set(String[] items) {
		this.nmsType = items[0];
		this.neId = items[1];
		this.mntrDtm = items[5];
		this.msgStCd = items[6];
		this.msgNm = items[7];
		this.msgCtt = items[8];
	}

	@Override
	public String debugString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("[ServiceCode=%s]\n", this.getServiceCode().toString()));
		sb.append(String.format("(neId=%s)\n", neId));
		sb.append(String.format("(mntrDtm=%s)\n", mntrDtm));
		sb.append(String.format("(msgStCd=%s)\n", msgStCd));
		sb.append(String.format("(msgNm=%s)\n", msgNm));
		sb.append(String.format("(msgCtt=%s)", msgCtt));
		return sb.toString();
	}

}
