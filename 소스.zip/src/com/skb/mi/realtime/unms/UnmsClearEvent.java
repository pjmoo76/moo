package com.skb.mi.realtime.unms;

public class UnmsClearEvent extends UnmsEvent {

	private String	rlseDtm;			/* 해지시간 */
	private	String	alarmNo;			/* 장애번호 */
	private	String	equipId;			/* 장비ID : Track 2 */
	private	String	dablOccrLocDesc;	/* 장애 발생 위치 : Track2 */
	private	String	dablNm;				/* 장애명 : Track2 - 2018.12.05 장애내용에서 장애명으로 변경 */
	private	String	nmsDablCd;			/* 장애코드 */
	private	String	clctNmsClCd;
	private	String	equipDablNumCtt;

	
	
	public String getEquipDablNumCtt() {
		return equipDablNumCtt;
	}

	public void setEquipDablNumCtt(String equipDablNumCtt) {
		this.equipDablNumCtt = equipDablNumCtt;
	}

	private	UnmsIfVerEnum ifVer;
	/*
	 * Track2
	 * 해제는 발생된 장애 OMN30100 에서 DABL_RLSE_MTHD_CD​ = 'N', 전달받은 EQUIP_ID, DABL_OCCR_LOC_DESC, DABL_DESC 이 같은 경우 해제 장애로 판단한다.
	 */

	public UnmsClearEvent(UnmsIfVerEnum ifVer, String[] items) {
		super(UnmsServiceTypeEnum.SERVICE_CODE_CLEAR);
		this.ifVer = ifVer;
		set(items);
	}

	public String getRlseDtm() {
		return rlseDtm;
	}

	public String getAlarmNo() {
		return alarmNo;
	}

	public String getEquipId() {
		return equipId;
	}

	public String getDablOccrLocDesc() {
		return dablOccrLocDesc;
	}

	public String getDablNm() {
		return dablNm;
	}
	
	public String getNmsDablCd() {
		return this.nmsDablCd;
	}
	
	public String getClctNmsClCd() {
		return this.clctNmsClCd;
	}

	private void set(String[] items) {
		if (ifVer == UnmsIfVerEnum.V1) {
			this.setV1(items);
		} else if (ifVer == UnmsIfVerEnum.Track2 || ifVer == UnmsIfVerEnum.Outct) {
			this.setTrack2(items);
		}
	}

	/*
	 * Sample 
	 * 
0 :		20180804235954
1 :		60520604
2 :		2
3 :		51
4 :		24
	 */
	private void setV1(String[] items) {
		this.rlseDtm = items[0];
		this.alarmNo = items[1];
	}

	/*
	 * Sample 
	 * 
0 :		20181205105912			: 장애해제시간	E_RLSE_DTM
1 :		0						: 장애번호	E_DABL_NUM	
2 :		01						: 장애등급	E_DABL_GR_CD
3 :		B20100					: 국사코드	E_EQUIP_TPO_CD
4 :		000000061285			: 장비ID		E_EQUIP_ID
5 :		LOC : CCS/SDU2(DAT)		: 장애발생위치	E_DABL_OCCR_LOC_DESC
6 :		SDU FUNCTION FAIL ALARM	: 장애명	    E_DABL_NM
7 :		A6301					: 장애코드              
8 :    002                      : NMS_CD
9 :                             : EQUIP_DABL_NUM_CTT
	 */
	private void setTrack2(String[] items) {
		this.rlseDtm = items[0];
		this.equipId = items[4];
		this.dablOccrLocDesc = items[5];
		this.dablNm = items[6];
		this.nmsDablCd = items[7];
		this.clctNmsClCd = items[8];
		this.nmsCd = items[8];
		this.nmsType = items[8];
		
		if(items.length == 10){
			this.equipDablNumCtt = items[9];
		}
	}

	@Override
	public String debugString() {
		StringBuilder sb = new StringBuilder();
		if (ifVer == UnmsIfVerEnum.V1) {
			sb.append(String.format("[ServiceCode=%s]\n", this.getServiceCode().toString()));
			sb.append(String.format("(rlseDtm=%s)\n", rlseDtm));
			sb.append(String.format("(alarmNo=%s)", alarmNo));
		} else {
			sb.append(String.format("[ServiceCode=%s]\n", this.getServiceCode().toString()));
			sb.append(String.format("(rlseDtm=%s)\n", rlseDtm));
			sb.append(String.format("(equipId=%s)\n", equipId));
			sb.append(String.format("(dablOccrLocDesc=%s)\n", dablOccrLocDesc));
			sb.append(String.format("(dablNm=%s)", dablNm));
			sb.append(String.format("(nmsDablCd=%s)", nmsDablCd));
			sb.append(String.format("(clctNmsClCd=%s)", clctNmsClCd));
			sb.append(String.format("(equipDablNumCtt=%s)", equipDablNumCtt));
		}
		return sb.toString();
	}
}
