package com.skb.mi.realtime.unms;

public enum PduEssTrfMsgEnum {
	E_EQUIP_USG_CD(0),	/* NMS 타입 : "4101"= PSTN ESS, "4201"=VoIP 기간망, "4301"=VoIP 가입자망 장비 */
	E_DATA_SRC_CL_CD(1), /* 메시지 소스 타입 : 'C'=voip&pstn cdr, 'L"=voip clog, 'M'=pstn clog */
	E_MNTR_CYCL_CD(2), /* 성능 감시 주기, '02'=5분, '07'=15분, '04'=30분, '05'=60분 */
	E_EQUIP_ID(3),
	E_ROUT_NUM(4), /* routNumCtt */
	E_ROUT_NM(5),
	E_ROUT_USG_CTT(6), /* routUsgCtt */
	E_ROUT_CONN_DIRN_CD(7), /* routDirnCd */
	E_ASSASP_NUM(8),
	E_ROUT_CONN_TYP_CD(9), /* connClCd */
	E_DOEXG_BIZR_ID(10), /* doexgBizrId */
	E_DOEXG_BIZR_NM(11),
	E_DOEXG_CUST_NM(12),
	E_EVENT_DATE(13),
	E_IS_ALARM(14), /* dablYn */
	E_ALARM(15),
	E_INTRA_ATT(16), /* ioexgTryCallCnt */
	E_INTRA_ANS(17), /* ioexgFnshCallCnt */
	E_INC_ATT(18), /* itCallCnt */
	E_INC_ANS(19), /* icallFnshCallCnt */
	E_OUT_ATT(20), /* otCallCnt */
	E_OUT_ANS(21), /* ocallFnshCallCnt */
	E_A_TM_ATT(22), /* ocallNumTmTryCallCnt */
	E_A_TM_ANS(23), /* ocallNumTmFnshCallCnt */
	E_B_TM_ATT(24), /* icallNumTmTryCallCnt */
	E_B_TM_ANS(25), /* icallNumTmFnshCallCnt */
	E_AHDT(26), /* avgRsvTms : Average 통화 시간 (DID:MSG, 나머지 CDR) */
	E_EQP_TRK(27), /* trunkCnt : 실장회선 (MSG에서 구함) */
	E_ERLANG(28), /* erlangVal : erlang (MSG에서 구함) */
	E_OOS(29), /* ovrCallCnt : OOS (MSG에서 구함) */
	E_RTEUSG(30), /* 회선 이용율 (15:MSG, 30/60:CDR (???)) */
	E_OVFL(31), /* Overflow (MSG에서 구함) */
	E_VAR_ATT_RATIO(32), /* allTryCallExfluRt : 과다 변동율 (DID:MSG, 나머지:CDR) */
	E_VAR_IATT_RATIO(33), /* itCallExfluRt */
	E_VAR_OATT_RATIO(34), /* otCallExfluRt */
	E_CONN_NUM_NO_ATT(35), /* nyOccrDcOccrCnt : 연속 미발생 횟수 (DID:MSG, 나머지:CDR) */
	E_CONN_NUM_ANSR(36), /* fnshRtDcOccrCnt */
	E_CONN_NUM_OOS(37), /* oosRtDcOccrCnt */
	E_CONN_NUM_RTEUSG(38), /* lineUseRtDcOccrCnt */
	E_CONN_NUM_OVFL(39), /* ovrCallRtDcOccrCnt */
	E_CONN_NUM_VAR_ATT(40), /* exfluRtDcOccrCnt */
	E_CONN_NUM_IANSR(41), /* icallFnshRtDcOccrCnt */
	E_CONN_NUM_OANSR(42), /* ocallFnshRtDcOccrCnt */
	E_CONN_NUM_IVAR_ATT(43), /* itCallExfluDcOccrCnt */
	E_CONN_NUM_OVAR_ATT(44), /* otCallExfluRtDcOccrCnt */
	E_INCOMPL_1(45), /* scrbrErrCnt : 가입자 오류 (CDR) */
	E_INCOMPL_2(46), /* sysErrCnt : 시스템 오류 (CDR) */
	E_INCOMPL_3(47), /* nwErrCnt : 네트웍 오류 (CDR) */
	E_INCOMPL_4(48), /* svcErrCnt : 서비스 오류 (CDR) */
	E_CONN_NUM_ATT(49), /* tryCallDcOccrCnt */
	E_TM_TYP_CD_NM(50),
	E_BIZR_NM(51),
	NUM_EVENT(52)
	;
	
	private	final int	index;

	PduEssTrfMsgEnum(int index) {
		this.index = index;
	}
	
	public int getIndex() {
		return index;
	}
}
