package	com.skb.mi.realtime;

import	java.net.Socket;
import	java.net.SocketTimeoutException;
import	java.net.InetAddress;
import	java.io.BufferedReader;
import	java.io.FileReader;
import	java.io.File;
import	java.io.InputStream;
import	java.io.OutputStream;
import	java.sql.ResultSet;
import	java.util.Calendar;
import	java.util.StringTokenizer;
import	java.util.LinkedList;

import	com.skb.mi.common.BaseAdamsBatch;
import	com.skb.mi.vo.FaultVO;
import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import	com.skb.mi.common.DBController;
import com.skb.mi.common.EnvManager;
import	com.skb.mi.common.OutputLog;
import	com.skb.mi.thread.KeepAliveMidKnight;

import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import	org.json.simple.JSONObject;

public class	RealTimeCollectMidKnight {
    final private int           BUFFER_SIZE         = 16386;
	final private byte			STX					= 0x02;
	final private byte			ETX					= 0x03;
    final private String        NMS_CD 				= "012";   // OCO20101 테이블에 있음. NMS_EQUIP_CD로 조회
    final private String        NMS_NM 				= "MIDKNIGHT";

    final private String        NET_CL_CD 			= "99";
    final private String        NET_CL_NM 			= "ETC";

    final private String        DABL_LCL_CD 		= "05";
    final private String        DABL_MCL_CD 		= "05901";
    final private String        DABL_CD 			= "059001";
    final private String        DABL_LCL_NM 		= "환경장애";
    final private String        DABL_MCL_NM 		= "환경장애";
    final private String        DABL_NM 			= "MIDKNIGHT환경장애";

    final private String        GENERATE_EVENT      = "GEN";
    final private String        CLEAR_EVENT         = "CLR";

    final private String        GENERATED_FAULT_NM  = "장애중";
    final private String        CLEARED_FAULT_NM    = "장애해제";

    final private String        GENERATED_FAULT_CD  = "01";
    final private String        CLEARED_FAULT_CD    = "02";

    final private int			SO_TIME_OUT	= (1000*60*5);	// Time-Out 5분 설정

    // MidKnight 서버 정보
	String						ipAddress;
	int							portNo;

	byte []                     buffer;
    int                         bufferFront, bufferRear;
    
	// MidKnight 서버 Socket
	Socket						socket = null;
	InputStream					inputStream = null;
	OutputStream				outputStream = null;

	// Push Processor 정보
    Socket                      pushSocket;
    InputStream                 pushInputStream;
    OutputStream                pushOutputStream;
    String                      pushIpAddress;
    int                         pushPortNo;

	LinkedList<JSONObject>		notSendJson;
	JSONObject					jsonObject;

	String						dbUrl, userName, password;

	String						absolutePath;

	OutputLog					outputLog;

	DBController				dbController;

	String						pgmId;

    KeepAliveMidKnight          keepAliveMidKnight;
    
    String                      serverType;

	public RealTimeCollectMidKnight (String [] args) {
		int				count, index, sendCount = 0;
		byte [] 		packet = new byte [1024];
		String			onePacket, token, serialNo = null, faultStatus = null;
		String			query = "";
		boolean 		check = false;
		ResultSet		resultSet;

		StringTokenizer	tokens;

		serverType = EnvManager.env.getOptionValue(Constants.SERVER_TYPE);
		absolutePath = EnvManager.env.getHome();
        
        	
		try {
			String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
			ConfigManager configManager = new ConfigManager(cfgFile);
			dbUrl = configManager.getConfig(Constants.ADAMS_DB, Constants.DB_URL);
			userName = configManager.getConfig(Constants.ADAMS_DB, Constants.USER_NAME);
			password = configManager.getConfig(Constants.ADAMS_DB, Constants.PASSWORD);
			if("NON_CAPITAL".equals(serverType))
			{
				ipAddress = configManager.getConfig(Constants.MID_KNIGHT_NON_CAPITAL, Constants.IP_ADDRESS);
				portNo = Integer.parseInt(configManager.getConfig(Constants.MID_KNIGHT_NON_CAPITAL, Constants.PORT_NO));
				outputLog = new OutputLog (true, this.getClass().getName()+"_NonCapatal", EnvManager.env.getLogs());
		        
			}else{
				ipAddress = configManager.getConfig(Constants.MID_KNIGHT_CAPITAL, Constants.IP_ADDRESS);				
				portNo = Integer.parseInt(configManager.getConfig(Constants.MID_KNIGHT_CAPITAL, Constants.PORT_NO));				
				outputLog = new OutputLog (true, this.getClass().getName()+"_Capatal", EnvManager.env.getLogs());
			}
				
			
	        outputLog.write ("Start : " + getDateSecond ());
			pushIpAddress = configManager.getConfig(Constants.WEB_PUSH, Constants.IP_ADDRESS);
			pushPortNo = Integer.parseInt(configManager.getConfig(Constants.WEB_PUSH, Constants.PORT_NO));

			outputLog.write("dbUrl : " + dbUrl);
			outputLog.write("userName : " + userName);
			outputLog.write("password : " + password);
			outputLog.write("ipAddress : " + ipAddress);
			outputLog.write("portNo : " + portNo);
			outputLog.write("pushIpAddress : " + pushIpAddress);
			outputLog.write("pushPortNo : " + pushPortNo);
			
			//readDbInfo ();
//            dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
/**
            InetAddress local = InetAddress.getLocalHost ();
            String  ip = local.getHostAddress ();
            resultSet = dbController.selectProgramInfo (this.getClass().getName (), ip);

            if (resultSet.next ()) {
                pgmId = resultSet.getString (1);
                String  pgmUseYn = resultSet.getString (2);
                String  pgmStCd = resultSet.getString (3);
                resultSet.close ();

                outputLog.write ("pgmId : " + pgmId + ", pgmUseYn : " + pgmUseYn + ", pgmStCd : " + pgmStCd);
                // 프로세스 Use Y/N 검사
               	if (pgmUseYn.equals ("N"))
                    exitProcess (false, "");
                // 프로세스 동작중인지 검사
                if (pgmStCd.equals ("S"))       // 동작중이면 바로 종료
                    exitProcess (false, "");
                else                            // 동작이 종료되어 있는 경우
                    dbController.insertProcessHistory(pgmId, "프로세스가 시작되었습니다", "S", "Y");
                    outputLog.write ("프로세스가 시작되었습니다.");
            } else {
                dbController.insertProcessHistory(pgmId, "프로세스가 시작되었습니다", "S", "Y");
                exitProcess (true, "프로세스를 찾을 수 없습니다.");
            }
**/
//			dbController.closeDB ();
        } catch (Exception e ) {
        	e.printStackTrace();
            exitProcess (true, "DB 정보를 읽는 도중에 에러발생되었습니다.");
        }

        buffer = new byte [BUFFER_SIZE];
        bufferFront = bufferRear = 0;

        try {
			//readMidKnightInfo ();
			//readPushInfo ();
        	
			socket = new Socket (ipAddress, portNo);
			inputStream = socket.getInputStream ();
			outputStream = socket.getOutputStream ();
			
			check = true;
            sendAck ();
		} catch (Exception e) {
			
            exitProcess (true, "readMidKnightInfo Error : " + e);
		}
        
        keepAliveMidKnight = new KeepAliveMidKnight (this);
        
        keepAliveMidKnight.start ();
        
		notSendJson = new LinkedList<JSONObject> ();
		
		pushSocket = null;
		pushOutputStream = null;
		
		while (check) {
			jsonObject = new JSONObject ();
			try {
				index = 0;
//				count = inputStream.read (packet);
                if (getOneByte () != STX)
                    continue;

                onePacket = getBytes ();
                if (onePacket == null) 
                    connectNms ();

				tokens = new StringTokenizer (onePacket, "|^|");
				index = 1;
				jsonObject.put ("NMS_CD", NMS_CD);
				jsonObject.put ("NMS_NM", NMS_NM);
				jsonObject.put ("SERVER_TYPE", serverType);
				jsonObject.put ("OCCR_RCV_DTM", getDateTime ());
				while (tokens.hasMoreTokens ()) {
					token = tokens.nextToken ();
					token = token.trim ();
					outputLog.write ("Field" + index + " : " + token);
					
					// 인지 장애는 SKIP 되도록 변경. 250617 김준
					if(index == 10 && token.equals ("1")){
						break;
					}
					
					switch (index) {
						case  1: 	serialNo = token; break;
						case  2:	jsonObject.put ("NMS_DABL_NUM_CTT", token); break;
//							case  3:	jsonObject.put ("DABL_DESC", token); break;
						case  4:	jsonObject.put ("DABL_OCCR_LOC_DESC", token); break;
						case  5:	jsonObject.put ("DABL_DESC", token);
									break;
						case  6:	jsonObject.put ("SUP_EQUIP_NM", token); 
									jsonObject.put ("EQUIP_NM", token);
									break;
						case  7:	jsonObject.put ("EQUIP_ID", token); 
									jsonObject.put ("EQUIP_TID_VAL", token);
									break;
						case  8:	if (token.equals ("20"))
										token = "02";				// Warning	
									else if (token.equals ("30"))
										token = "03";				// Minor
									else if (token.equals ("40"))
										token = "05";				// Critical
									else if (token.equals ("50"))
										token = "07";				// Fatal
									else if (token.equals ("10"))	// Normal.
										token = "01";				// Info
									else
										token = "";
									jsonObject.put ("DABL_GR_CD", token); 
									break;
						case  9:	jsonObject.put ("OCCR_DTM", token); break;
						case  10:   if (token.equals ("0") 			// 발생
									   || token.equals ("1")) {		// 인지
										jsonObject.put ("kind", GENERATE_EVENT);
										jsonObject.put ("DABL_ST_CD", GENERATED_FAULT_CD);
										jsonObject.put ("DABL_ST_NM", GENERATED_FAULT_NM);
									} else if (token.equals ("2")) {	// 종료
										jsonObject.put ("kind", CLEAR_EVENT);
										jsonObject.put ("DABL_ST_CD", CLEARED_FAULT_CD);
										jsonObject.put ("DABL_ST_NM", CLEARED_FAULT_NM);
										jsonObject.put ("RLSE_DTM", (String) jsonObject.get ("OCCR_DTM"));
										jsonObject.put ("RLSE_RCV_DTM", getDateTime ());
										String nmsDablNumCtt = jsonObject.get ("NMS_DABL_NUM_CTT").toString ();
										nmsDablNumCtt = nmsDablNumCtt.substring (0, nmsDablNumCtt.length () - 1) + "0";
										jsonObject.put ("NMS_DABL_NUM_CTT", nmsDablNumCtt);
										outputLog.write ("해제 : " + nmsDablNumCtt);
									}
									break;
/*
						case 10:	faultVo.setNmsDablNumCtt (token); break;
						case 11:	faultVo.setNmsDablNumCtt (token); break;
*/
						case 12:	jsonObject.put ("DABL_LOC_NM", token); 
									jsonObject.put ("INFO_CNTR_NM", token);
									break;
						case 14:	jsonObject.put ("SBNMS_EQUIP_NM", token);
									jsonObject.put ("EQUIP_MDL_NM", token);
									break;
					}
					++ index;
					if (index == 15) {
						// 응답 전송
						if (10 < index) {
							sendResponse (serialNo, (String) jsonObject.get ("NMS_DABL_NUM_CTT"));
							jsonObject.put ("DABL_LCL_CD", DABL_LCL_CD);  // 대분류 코드
							jsonObject.put ("DABL_LCL_NM", DABL_LCL_NM);  // 대분류 명
							jsonObject.put ("DABL_MCL_CD", DABL_MCL_CD);  // 중분류 코드
							jsonObject.put ("DABL_MCL_NM", DABL_MCL_NM);  // 중분류 명
							jsonObject.put ("DABL_CD", DABL_CD);         // 소분류 코드
							jsonObject.put ("DABL_NM", DABL_NM);         // 소분류 명
							jsonObject.put("NET_CL_CD", NET_CL_CD);
							jsonObject.put ("NET_CL_NM", NET_CL_NM);

							// JSON 송신
							try {
								outputLog.write (jsonObject.toJSONString ());
								if (pushSocket == null) {
									pushSocket = new Socket (pushIpAddress, pushPortNo);
									pushOutputStream = pushSocket.getOutputStream ();
								}
								pushOutputStream.write (makeSendBuffer (jsonObject.toString ().getBytes ()));
								pushOutputStream.flush ();
                                //pushOutputStream.close ();
                                //pushSocket.close ();
							} catch (Exception e) {
								outputLog.write(e);
//								notSendJson.add (jsonObject);
//								sendJson ();
								try {
									if (pushOutputStream != null) pushOutputStream.close();
								} catch (Exception e1) {
								}
								try {
									if (pushSocket != null) pushSocket.close();
								} catch (Exception e1) {
								}
								pushOutputStream = null;
								pushSocket = null;
							}
						}
						index = 1;
					}
				}
			} catch (Exception e) {
				outputLog.write ("jsonObject : " + jsonObject);
				outputLog.write ("Exception : " + e);
			}
		}
		try {
			outputStream.close ();
			inputStream.close ();
			socket.close ();

			pushOutputStream.close ();
			pushSocket.close ();
		} catch (Exception e) {
		}
	}

    public void connectNms () {
        outputLog.write ("connecting NMS");
        boolean check = false;
        while (!check) {
			try {
				try {
	                if (inputStream != null) {
	                     inputStream.close ();
	                     inputStream = null;
	                }
				} catch (Exception e) {
                    inputStream = null;					
				}
				try {
	                if (socket != null) {
	                     socket.close ();
	                     socket = null;
	                }
				} catch (Exception e) {
					socket = null;
				}
				socket = new Socket (ipAddress, portNo);
				socket.setSoTimeout(SO_TIME_OUT);
				inputStream = socket.getInputStream ();
				outputStream = socket.getOutputStream ();
                bufferFront = bufferRear = 0;
				check = true;
			} catch (Exception e) {
                outputLog.write ("connectNms'Exception : " + e);
                sleep (1000);
			}
        }
        outputLog.write ("connected NMS");
    }

    public void exitProcess (boolean check, String clctRsltCtt) {
        if (check) {
            try {
				dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
                dbController.insertProcessHistory(pgmId, clctRsltCtt, "F", "Y");
            } catch (Exception e) {
                outputLog.write ("exitProcess () Exception : " + e);
            }
        }
        outputLog.write (clctRsltCtt);
        outputLog.close ();
        dbController.closeDB ();
        try {
            outputStream.close ();
            inputStream.close ();
            socket.close ();
        } catch (Exception e) {
        }
        outputLog.write ("Finish : " + getDateSecond ());
        System.exit (0);
    }

    /*
    public void readDbInfo () throws Exception {
        String  oneLine;
        FileReader  fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + "db.info");
        BufferedReader bufferedReader = new BufferedReader (fileReader);
        dbUrl = bufferedReader.readLine ();
        userName = bufferedReader.readLine ();
        password = bufferedReader.readLine ();
        bufferedReader.close ();
        fileReader.close ();
    }

    public void readMidKnightInfo () throws Exception {
        FileReader  fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + "midKnight.info");
        BufferedReader bufferedReader = new BufferedReader (fileReader);
        ipAddress = bufferedReader.readLine ();
        portNo = Integer.parseInt (bufferedReader.readLine ());
        bufferedReader.close ();
        fileReader.close ();
    }

    public void readPushInfo () throws Exception {
        FileReader  fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + "push.info");
        BufferedReader bufferedReader = new BufferedReader (fileReader);
        pushIpAddress = bufferedReader.readLine ();
        pushPortNo = Integer.parseInt (bufferedReader.readLine ());
        bufferedReader.close ();
        fileReader.close ();
    }
    */

    public void sendJson () {
        JSONObject  obj;
        int size = notSendJson.size ();
        outputLog.write ("Push 프로세스에게 전달할 JSON크기 : " + size);

        try {
            try {
                pushOutputStream.close ();
            } catch (Exception e1) {
            }
            try {
                pushSocket.close ();
            } catch (Exception e2) {
            }
            pushSocket = new Socket (pushIpAddress, pushPortNo);
            pushOutputStream = pushSocket.getOutputStream ();
            for (int index = 0; index < size; ++ index) {
                obj = notSendJson.get (0);
                pushOutputStream.write (makeSendBuffer (obj.toString ().getBytes ()));
                pushOutputStream.flush ();
                outputLog.write (obj.toJSONString ());
                notSendJson.remove (0);
                sleep (100);
            }
            pushOutputStream.flush ();
            pushOutputStream.close ();
            pushSocket.close ();
        } catch (Exception e) {
            outputLog.write ("Push 프로세스와 연결이 끊겼습니다.");
        }
    }

    public void sendKeepAlive () {
        JSONObject json = new JSONObject ();
        json.put ("kind", "DBC");
        json.put ("NMS_CD", "012");
        json.put ("NMS_NM", "MIDKNIGHT");
        outputLog.write ("----- sendKeepAliveToWebSocket......");
        try {
			pushOutputStream.write (makeSendBuffer (json.toString ().getBytes ()));
			pushOutputStream.flush ();
        } catch (Exception e) {
            outputLog.write ("sendKeepAlive'Exception : " + e); 
        }
    }

    public byte[] makeSendBuffer (byte [] temp) {
        byte [] sendBuffer = new byte [temp.length + 1];
        int index = 0;
        for (; index < temp.length; ++ index)
            sendBuffer [index] = temp [index];
        sendBuffer [index] = ETX;
        return sendBuffer;
    }

	public void sendResponse (String serialNo, String alarmNo) {
		int		index = 0;
		String	response = serialNo + "|^|" + alarmNo; 
		String	total = String.format ("|^|%d|^|", response.length ()) + response + "|^|";
		byte []	buffer = new byte [total.length () + 2];
		byte []	temp = total.getBytes ();
		buffer [0] = 0x02;
	
		for (index = 1; index < (buffer.length - 1); ++ index)
			buffer [index] = temp [index - 1];

		buffer [buffer.length - 1] = 0x03;

        outputLog.write (">>>>> sendResponse : " ) ;
        outputLog.write ("---- SerialNo : " + serialNo + ", alarmNo : " + alarmNo);
		printHexaCode (buffer.length, buffer);
        outputLog.write ("<<<<< sendResponse : " ) ;
		try {
			outputStream.write (buffer);
			outputStream.flush ();
		} catch (Exception e) {
			outputLog.write ("sendResponse : OutputStream : Exception : " + e);
		}
	}

	public void sendAck () {
		byte []	buffer = {0x02, '|', '^', '|', 0x31,  '|', '^', '|', 0x30, '|', '^', '|', 0x03};
		try {
			outputStream.write (buffer);
			outputStream.flush ();
			outputLog.write (">>>>>>>>> sendAck");
		} catch (Exception e) {
			outputLog.write ("sendAck : OutputStream : Exception : " + e);
		}
	}

    public void printHexaCode (int length, byte[] buffer) {
        int count = 0;
        String temp = "";
        for (int index = 0; index < length; ++ index) {
            if (count++ % 20 == 0) {
                outputLog.write (temp);
                temp = "";
            }
            temp += String.format ("%02x.", buffer [index]);
        }
        outputLog.write (temp);
    }

    public byte getOneByte () {    	
        while (true) {
            try {
            	
                if (bufferRear <= bufferFront) {
                    bufferFront = 0;
                    bufferRear = inputStream.read (buffer);                 
                    printHexaCode (bufferRear, buffer);
                }
                if (bufferRear != -1) {
                    return buffer [bufferFront ++];
                } else {
                    outputLog.write ("getOneByte () Exception : length = " + bufferFront);
                    inputStream.close ();
                    outputStream.close ();
                    socket.close ();
                    connectNms ();
                }
            } catch (Exception e) {
                try {
                    outputLog.write ("getOneByte () Exception : " + e);
                    inputStream.close ();
                    outputStream.close ();
                    socket.close ();
                    connectNms ();
                } catch (Exception ee) {
                    outputLog.write ("getOneByte () Catch Exception : " + ee);
                }
            }
        }
    }

    public String getBytes () {
        byte [] bytes = new byte [BUFFER_SIZE];
        byte temp;
        int index;
        for (index = 0; ; ++ index) {
            temp = getOneByte ();
            if (temp == -1)
                return null;
            if (temp == ETX)                  // 0x03
                break;
            bytes [index] = temp;
        }
        try {
            return new String (bytes, 0, index);
        } catch (Exception e) {
            outputLog.write ("getBytes : new String : Exception : " + e);
            return null;
        }
    }

    public String getDateSecond () {
        Calendar    calendar = Calendar.getInstance ();

        return String.format ("%04d-%02d-%02d %02d:%02d:%02d",
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH) + 1,
            calendar.get(Calendar.DAY_OF_MONTH),
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            calendar.get(Calendar.SECOND));
    }

    public String getDateTime () {
        Calendar    calendar = Calendar.getInstance ();

        return String.format ("%04d%02d%02d%02d%02d%02d",
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH) + 1,
            calendar.get(Calendar.DAY_OF_MONTH),
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            calendar.get(Calendar.SECOND));
    }

    public void sleep (int waitingTime) {
        try {
            Thread.sleep (waitingTime);
        } catch (Exception e) {
        }
    }

	public static void main (String [] args) {

		Options options = new Options();
		Option serverType = Option.builder().longOpt(Constants.SERVER_TYPE)
				.desc("SERVER_TYPE (CAPITAL or NON_CAPITAL)").hasArg().argName(Constants.SERVER_TYPE).build();
		
		options.addOption(serverType);	
		
    	EnvManager envManager = new EnvManager(args,options);
    	
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("RealTimeCollectMidKnight", envManager.getOptions());
    		System.exit(0);
    	}

		new RealTimeCollectMidKnight (args);
	}
}
