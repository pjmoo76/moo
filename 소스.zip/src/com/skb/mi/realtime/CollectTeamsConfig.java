package com.skb.mi.realtime;

import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.sql.Types;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.StringTokenizer;

import com.skb.mi.common.BatchJob;
import com.skb.mi.common.DBController;
import com.skb.mi.common.MiscUtils;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

public class CollectTeamsConfig {
	final private	int 	PREPARED_STATEMENT_MAX = 5000;
	
	// CollectTeamsConfig 관련 변수
	PreparedStatement 		preparedStatement = null;
	int []					columnType;
	
	String					ipAddress;
	int						portNo;

	String					dbUrl, userName, password;
	DBController			dbController;

	String					absolutePath;
	String					targetDirectory;

	Hashtable<String,String>	hashTable;	

	public CollectTeamsConfig (String [] args) {
		absolutePath = args [0];
		targetDirectory = args [1];
/*
		if (!getHour ().equals ("06")) {
			System.out.println ("06시가 아니어서 종료함.......");
			System.exit (1);
		}
*/
		System.out.println (this.getClass().getName() + " 프로그램 시작 : " + getDateSecond());

		String	oneLine, token, debugToken;
		StringTokenizer	tokens;
		int				batch = 1;
		try {
			readDbInfo ();
			dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
			File	file = new File (targetDirectory +  File.separator + getDate () + ".teams_dev");
			BufferedReader bufferedReader = new BufferedReader (new InputStreamReader (new FileInputStream (file), "euc-kr"));
			hashTable = new Hashtable<String,String>();
			preparedStatement = dbController.getConnection ().prepareStatement (getMergeOIV10981 ());
			while ((oneLine = bufferedReader.readLine ()) != null) {
				token = "";
				for (int index = 0; index < oneLine.length (); ++ index) {
					if (oneLine.charAt (index) == '\'')
						token += "'";
					token += oneLine.charAt (index);
					if (oneLine.charAt (index) == '|') {
						if (index == (oneLine.length () - 1))
							token += " ";
						else if (oneLine.charAt (index + 1) == '|')
							token += " ";
					}
				}
				debugToken = token;
				tokens = new StringTokenizer (token, "|");
//				System.out.println (token);
				int	count = 1;
				while (tokens.hasMoreTokens ()) {
					token = tokens.nextToken ().trim ();
					if (count == 12) {		// REF_ID(UKEY의 eqp_id)
						if (token == null || token.equals (""))
							token = hashTable.get ("Field1");
					}		
					hashTable.put ("Field" + count, token);	
					++ count;
				}	
				mergeOIV10981 ();
				hashTable.clear ();
				if (batch % PREPARED_STATEMENT_MAX == 0) {
					try {
						preparedStatement.executeBatch ();
					} catch (Exception e1) {
						System.out.println ("ExceuteBatch Exception : " + e1);
						System.out.println (debugToken);
					}
					System.out.println ("처리 수 : " + batch);
				}
				++ batch;
			}
			preparedStatement.executeBatch ();
			bufferedReader.close ();
		} catch (Exception e) {
			System.out.println ("CollectTeamsConfig Exception : " + e);
		}
		
		dbController.closeDB();
		
		System.out.println ("프로그램 종료 : " + MiscUtils.getDateTime());
	}
	
    public void readDbInfo () throws Exception {
        FileReader  fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + "db.info");
        BufferedReader bufferedReader = new BufferedReader (fileReader);
        dbUrl = bufferedReader.readLine ();
        userName = bufferedReader.readLine ();
        password = bufferedReader.readLine ();
        bufferedReader.close ();
        fileReader.close ();
    }

	public String getMergeOIV10981 () {
		return           "MERGE INTO OIV10981 USING DUAL "
					  +  " ON (CLCT_EQUIP_NUM=?)"
					  +  " WHEN MATCHED THEN"
					  +  "  UPDATE SET"
					  +  "   AUDIT_ID='admin'"
					  +  "   , AUDIT_DTM=SYSDATE"
					  +  "   , EQUIP_TYP_CD=?"
					  +  "   , EQUIP_MDL_CD=?"
					  +  "   , EQUIP_MDL_NM=?"
					  +  "   , MFACT_NM=?"
					  +  "   , TEAMS_EQUIP_NM=?"
					  +  "   , TEAMS_EQUIP_TID_VAL=?"
					  +  "   , EQUIP_IP_ADDR=?"
					  +  "   , TEAMS_SW_VER_INFO=?"
					  +  "   , FW_VER_INFO=?"
					  +  "   , TPO_CD=?"
					  +  " WHEN NOT MATCHED THEN"
					  +  "  INSERT ("
					  +  "   AUDIT_ID"
					  +  "   , AUDIT_DTM"
					  +  "   , CLCT_EQUIP_NUM"
					  +  "   , EQUIP_TYP_CD"
					  +  "   , EQUIP_MDL_CD"
					  +  "   , EQUIP_MDL_NM"
					  +  "   , MFACT_NM"
					  +  "   , TEAMS_EQUIP_ID"
					  +  "   , TEAMS_EQUIP_NM"
					  +  "   , TEAMS_EQUIP_TID_VAL"
					  +  "   , EQUIP_IP_ADDR"
					  +  "   , TEAMS_SW_VER_INFO"
					  +  "   , FW_VER_INFO"
					  +  "   , TPO_CD"
					  +  "   , RGST_DTM"
					  +  " ) VALUES ("
					  +  "   'admin'"
					  +  "   , SYSDATE"
					  +  "   , ?"
					  +  "   , ?"
					  +  "   , ?"
					  +  "   , ?"
					  +  "   , ?"
					  +  "   , ?"
					  +  "   , ?"
					  +  "   , ?"
					  +  "   , ?"
					  +  "   , ?"
					  +  "   , ?"
					  +  "   , ?"
					  +  "   , SYSDATE"
					  +  " )";
	}

	public void mergeOIV10981 () {
		int	index = 1;
		try {
			preparedStatement.setString (index ++, hashTable.get ("Field12"));
			preparedStatement.setString (index ++, hashTable.get ("Field13"));
			preparedStatement.setString (index ++, hashTable.get ("Field2"));
			preparedStatement.setString (index ++, hashTable.get ("Field3"));
			preparedStatement.setString (index ++, hashTable.get ("Field4"));
			preparedStatement.setString (index ++, hashTable.get ("Field5"));
			preparedStatement.setString (index ++, hashTable.get ("Field6"));
			preparedStatement.setString (index ++, hashTable.get ("Field10"));
			preparedStatement.setString (index ++, hashTable.get ("Field14"));
			preparedStatement.setString (index ++, hashTable.get ("Field11"));
			preparedStatement.setString (index ++, hashTable.get ("Field7"));

			preparedStatement.setString (index ++, hashTable.get ("Field12"));
			preparedStatement.setString (index ++, hashTable.get ("Field13"));
			preparedStatement.setString (index ++, hashTable.get ("Field2"));
			preparedStatement.setString (index ++, hashTable.get ("Field3"));
			preparedStatement.setString (index ++, hashTable.get ("Field4"));
			preparedStatement.setString (index ++, hashTable.get ("Field1"));
			preparedStatement.setString (index ++, hashTable.get ("Field5"));
			preparedStatement.setString (index ++, hashTable.get ("Field6"));
			preparedStatement.setString (index ++, hashTable.get ("Field10"));
			preparedStatement.setString (index ++, hashTable.get ("Field14"));
			preparedStatement.setString (index ++, hashTable.get ("Field11"));
			preparedStatement.setString (index ++, hashTable.get ("Field7"));
			preparedStatement.addBatch ();
		} catch (Exception e) {
			System.out.println ("mergeOIV10981 Exception : " + e);
		}		
	}

    public String getDateSecond () {
        Calendar    calendar = Calendar.getInstance ();

        return String.format ("%04d-%02d-%02d %02d:%02d:%02d",
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH) + 1,
            calendar.get(Calendar.DAY_OF_MONTH),
			calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            calendar.get(Calendar.SECOND));
    }

    public String getHour () {
        Calendar    calendar = Calendar.getInstance ();

        return String.format ("%02d", calendar.get(Calendar.HOUR_OF_DAY));
    }

    public String getDate () {
        Calendar    calendar = Calendar.getInstance ();

        return String.format ("%04d%02d%02d",
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH) + 1,
            calendar.get(Calendar.DAY_OF_MONTH));
    }

	public static void main(String[] args) {
		if (args.length != 2) {
			System.out.println ("Usage : java CollectTeamsConfig 절대패스 대상디렉토리");
			System.exit (1);
		}
		new CollectTeamsConfig (args);
	}
}
