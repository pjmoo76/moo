package com.skb.mi.realtime;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.common.MiscUtils;
import com.skb.mi.model.OMN30203;
import com.skb.mi.realtime.foms.FomsEvent;
import com.skb.mi.realtime.foms.FomsEventFactory;
import com.skb.mi.realtime.foms.FomsFaultEvent;
import com.skb.mi.realtime.foms.FomsNetFaultEvent;
import com.skb.mi.thread.SendJsonThread;

import org.apache.commons.cli.HelpFormatter;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

public class RealTimeCollectFoms {
	
	final private int			SOCKET_TIME_OUT	= (1000*60*5);	// Time-Out 5분 설정
	
	final private String		NMS_CD 				= "010";	// OCO20101, NMS_EQUIP_CD로 조회
	final private String		NMS_NM 				= "FOMS";	// OCO20101, NMS_EQUIP_CD로 조회
	
	final private String		NMS_CD_CATV			= "031";	// OCO20101, NMS_EQUIP_CD로 조회
	final private String		NMS_NM_CATV 		= "FOMS_CATV";	// OCO20101, NMS_EQUIP_CD로 조회
	
	final private String		NET_CL_CD 			= "03";		// OCO20101, NET_CLC_CD로 조회
	final private String		NET_CL_NM 			= "FTTx";	// OCO20101, NET_CLC_CD로 조회
	
    final private String        GENERATE_EVENT      = "GEN";
    final private String        CLEAR_EVENT         = "CLR";

    final private String        GENERATED_FAULT_CD  = "01";
    final private String        CLEARED_FAULT_CD    = "02";

	String						ipAddress;
	String []                   arrIpAddress;
	int							portNo;
	String						userId;
	String						authKey;
	
	Socket						socket;
	InputStream					inputStream;
	OutputStream				outputStream;

	HashMap<String, OMN30203>	omn30203Map;	
    String                      pushIpAddress;    
    int                         pushPortNo;

    private Logger		logger;
	private	SqlSession	adamsSession;
	private	SendJsonThread	jsonSender;

    public RealTimeCollectFoms (String [] args) {
    	logger = LogManager.getLogger(this.getClass());
    	logger.info("start");

		loadConfig();
		try {
			adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
			readFomsFaultCode();

            jsonSender = new SendJsonThread(pushIpAddress, pushPortNo, true);
			connectNms();
			run();
	            
            outputStream.close ();
            inputStream.close ();
            socket.close ();
            
        } catch (Exception e) {
        	logger.error("Exception", e);
        }
    }

    public void loadConfig() {
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		arrIpAddress = configManager.getConfig(Constants.FOMS, Constants.IP_ADDRESS).split(",");
		portNo = Integer.parseInt(configManager.getConfig(Constants.FOMS, Constants.PORT_NO));
		pushIpAddress = configManager.getConfig(Constants.WEB_PUSH, Constants.IP_ADDRESS);
		pushPortNo = Integer.parseInt(configManager.getConfig(Constants.WEB_PUSH, Constants.PORT_NO));
		userId = configManager.getConfig(Constants.FOMS, Constants.USER_ID);
		authKey = configManager.getConfig(Constants.FOMS, Constants.AUTH_KEY);
		
		
		
		logger.info("ipAddress : " + arrIpAddress[0]);
		logger.info("portNo : " + portNo);
		logger.info("pushIpAddress : " + pushIpAddress);
		logger.info("pushPortNo : " + pushPortNo);    	
    }
    
    private void run() {
    	long nextPollingTime = (System.currentTimeMillis() / 1000L) + (60*5);		// 5분마다 polling packet 전송 (sendPollingPacket)

    	FomsEventFactory eventFactory = new FomsEventFactory();
    	FomsFaultEvent event = null;
        int errContCnt = 0;
        
		while (true) {
	    	try {
	    		if (adamsSession == null) {
	    			adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
	    		}
	    		
				if (event == null) {
					event = eventFactory.get(inputStream);
					errContCnt = 0;
				} else {
					// retry
					errContCnt ++;
					if (errContCnt > 3) {
						event = null;
						continue;
					}
				}
				if (event != null) {
					process(event);
					event = null;
				}
				long currentTime = System.currentTimeMillis() / 1000L;
				if (nextPollingTime < currentTime) {
					this.sendPollingPacket();
					nextPollingTime = currentTime + (60*5);
				}
	
			} catch (SocketTimeoutException ste) {
				logger.error("SocketTimeoutException", ste);
				connectNms();
			} catch (SocketException se) {
				logger.error("SocketException", se);
				connectNms();
			} catch (SQLException sqle) {
				logger.error("SQLException", sqle);
				adamsSession.close();
				adamsSession = null;
				MiscUtils.sleep(100);
			} catch (PersistenceException pe) {
				logger.error("PersistenceException", pe);
				adamsSession.close();
				adamsSession = null;
				MiscUtils.sleep(100);
			} catch (Exception e) {
				logger.error("Exception", e);
	    	}
        }
    }

	public void connectNms() {
        boolean check = false;
        while (!check) {
        	try {
        		if (inputStream != null) inputStream.close();
        	} catch (Exception e) {
        	}
        	try {
        		if (outputStream != null) outputStream.close();
        	} catch (Exception e) {
        	}
        	try {
        		if (socket != null) socket.close();
        	} catch (Exception e) {
        	}
            try {
            	int arrIpAddressLength = arrIpAddress.length;
            	
            	for(int i=0;arrIpAddressLength>i;i++){
            		String tmpPushIpAddress = arrIpAddress[i];
            		if(ipAddress == null)
            		{
            			ipAddress = arrIpAddress[0];
            			break;
            		}else if(ipAddress.equals(tmpPushIpAddress)){
            			
            			if(i==arrIpAddressLength-1)
            			{
            				ipAddress = arrIpAddress[0];
            				break;            				
            			}else{
            				ipAddress = arrIpAddress[i+1];
            				break;
            			}            			
            		}
            	}
            	
            	logger.info("try connecting " + ipAddress + ":" + portNo);
                socket = new Socket (ipAddress, portNo);
                logger.info("connected " + ipAddress + ":" + portNo);
                
                inputStream = socket.getInputStream();
                outputStream = socket.getOutputStream ();
                
                socket.setSoTimeout(SOCKET_TIME_OUT);

                sendInit();

                check = true;
            } catch (Exception e) {
                logger.error("Exception", e);
                MiscUtils.sleep(100);            // 0.1초
            }
        }
	}

	// FOMS 관련 장애 코드 조회해서 분류별로 Hashtable에 저장한다.
	public void readFomsFaultCode() throws Exception {
		omn30203Map = new HashMap<String, OMN30203>();
		// DABL_LCL_CD, DABL_LCL_NM, DABL_MCL_CD, DABL_MCL_NM, DABL_CD, DABL_CD_NM, CLCT_EVT_ID, CLCT_EVT_CD
		List<OMN30203> omn30203List = (List) adamsSession.selectList("RealtimeFoms.selectOMN30203", null);
		for (OMN30203 omn30203 : omn30203List) {
			String key = omn30203.getClctEvtId() + omn30203.getClctEvtCd();
			omn30203Map.put(key, omn30203);
			logger.debug(String.format("(%s),(%s,%s,%s,%s,%s,%s,%s,%s)",
					key,
					omn30203.getDablLclCd(), omn30203.getDablLclNm(), omn30203.getDablMclCd(), omn30203.getDablMclNm(),
					omn30203.getDablCd(), omn30203.getDablCdNm(), omn30203.getClctEvtId(), omn30203.getClctEvtCd()));
		}
	}
	
	private void process(FomsFaultEvent event) throws Exception {
		String swingAnnceYn = "N";

		JSONObject jsonObject = new JSONObject();
		if("CATV".equals(event.getNetType())){
			jsonObject.put("NMS_CD", NMS_CD_CATV);
			jsonObject.put("NMS_NM", NMS_NM_CATV);
		}else{
			jsonObject.put("NMS_CD", NMS_CD);
			jsonObject.put("NMS_NM", NMS_NM);
		}
		jsonObject.put("NMS_DABL_NUM_CTT", event.getEvtSerialNo());
		jsonObject.put("DABL_GR_CD", event.getDablGrCd());
		jsonObject.put("PING_CNT", event.getPingCnt());
		String key = event.getEvtId() + event.getEvtCode();
		OMN30203 omn30203 = omn30203Map.get(key);
		if (omn30203 != null) {
			jsonObject.put("DABL_LCL_CD", omn30203.getDablLclCd());
			jsonObject.put("DABL_LCL_NM", omn30203.getDablLclNm());
			jsonObject.put("DABL_MCL_CD", omn30203.getDablMclCd());
			jsonObject.put("DABL_MCL_NM", omn30203.getDablMclNm());
			jsonObject.put("DABL_CD", omn30203.getDablCd());
			jsonObject.put("DABL_NM", omn30203.getDablCdNm());
			// 가입자망 장애의 경우 : 포트번호(syslog장애, ftth cell장애일 시 : port_no, 이외 : 피해회선수(매스+비즈))
			// 그 외 AMI 장애, 환경감시 장애 : 포트번호
			if (FomsEvent.DETAIL_CMD2_NET_GEN == event.getDetailCmd2()) {
				// 01305: SYSLOG 장애, 01312: L2SYSLOG장애, 01314: OLT포트 장애 
				if ("01305".equals(omn30203.getDablMclCd()) || "01312".equals(omn30203.getDablMclCd()) || "01314".equals(omn30203.getDablMclCd())) {
					jsonObject.put("PORT_NUM", event.getPortNo());
				} else {
					jsonObject.put("DMG_SCRBR_CNT", event.getPortNo());
				}
			} else {
				jsonObject.put("PORT_NUM", event.getPortNo());
			}
		} else {
			jsonObject.put("DABL_LCL_CD", "*");
			jsonObject.put("DABL_LCL_NM", "*");			
			jsonObject.put("DABL_MCL_CD", "*");
			jsonObject.put("DABL_MCL_NM", "*");
			jsonObject.put("DABL_CD", "*");
			jsonObject.put("DABL_NM", "*");
		}
		jsonObject.put("OCCR_DTM", event.getEvtGenTime());
		jsonObject.put("OCCR_RCV_DTM", MiscUtils.getDateTime ());
		jsonObject.put("RSLE_DTM", event.getEvtGenTime());
		jsonObject.put("EQUIP_ID", event.getTid());
		jsonObject.put("EQUIP_TID_VAL", event.getTid());
		jsonObject.put("EQUIP_IP_ADDR", event.getDeviceIp());
		jsonObject.put("DABL_DESC", event.getEvtContent());
		jsonObject.put("DHCP_LNKG_EQUIP_CL_CD", event.getDevGroup());
		
		if (omn30203 != null) {
			if ("013016".equals(omn30203.getDablCd()) /* 전송망 장애 */
					|| "013017".equals(omn30203.getDablCd()) /* 전원 장애 */
					|| "013018".equals(omn30203.getDablCd()) /* 미확인 망장애 */
					|| "013009".equals(omn30203.getDablCd())) { /* Ping 장애 */
				swingAnnceYn = "Y";
				logger.debug("dablDesc : " + event.getEvtContent() + ", indexOf : " + event.getEvtContent().indexOf ("Off("));
				if (0 <= event.getEvtContent().indexOf ("Off(")) {
					String one = event.getEvtContent().substring(event.getEvtContent().indexOf ("Off(") + 4);
	                logger.debug("Off (" + one + ", length : " + one.length ());
					if (one != null) {
						String two = null;
						for (int index = 0; index < one.length (); ++ index) {
							if ('0' <= one.charAt(index) && one.charAt (index) <= '9') {
								if (two == null) {
									two = "" + one.charAt(index);
								} else {
									two += one.charAt(index);
								}
							} else {
								break;
							}
						}
						jsonObject.put("DMG_SCRBR_CNT", two);
					}
				}
			}
		}
		jsonObject.put("SWING_ANNCE_YN", swingAnnceYn);
		jsonObject.put("NOTICE_ID", event.getNoticeId());
		jsonObject.put("CCELL_NUM", event.getCellNo());
		jsonObject.put("OPER_DABL_YN", "N");
		if ("2".equals(event.getNoticeType())) {
			jsonObject.put("OPER_DABL_YN", "Y");
		}
		jsonObject.put("CUST_CHRTIC_CD", event.getBizCustLevel());  //240709.고객등급 추가.김준
		
		if (FomsEvent.DETAIL_CMD2_NET_CLR == event.getDetailCmd2()) {	// 가입자망 실시간 장애 해제
			jsonObject.put("NET_CL_CD", NET_CL_CD);
			jsonObject.put("NET_CL_NM", NET_CL_NM);
			jsonObject.put("DABL_ST_CD", CLEARED_FAULT_CD);
			jsonObject.put("RLSE_DTM", event.getEvtGenTime());
			jsonObject.put("RLSE_RCV_DTM", MiscUtils.getDateTime ());
			jsonObject.put("kind", CLEAR_EVENT);
		} else if (FomsEvent.DETAIL_CMD2_NET_GEN == event.getDetailCmd2()) {	// 가입자망 실시간 장애
			FomsNetFaultEvent netFaultEvent = (FomsNetFaultEvent) event;
			jsonObject.put("NET_CL_CD", NET_CL_CD);
			jsonObject.put("NET_CL_NM", NET_CL_NM);
			jsonObject.put("DABL_ST_CD", GENERATED_FAULT_CD);
			jsonObject.put("kind", GENERATE_EVENT);
			jsonObject.put("SHSPD_VOC_CNT", netFaultEvent.getNetVocCnt());
			jsonObject.put("IPTV_VOC_CNT", netFaultEvent.getIptvVocCnt());
			jsonObject.put("SHSPD_INET_DMG_LINE_CNT", netFaultEvent.getNetAlarmCnt());
			jsonObject.put("GNRL_IPTV_DMG_LINE_CNT", netFaultEvent.getIptvAlarmCnt());
			jsonObject.put("GNLPH_DMG_LINE_CNT", netFaultEvent.getPhoneAlarmCnt());
			jsonObject.put("VOIP_VOC_CNT", netFaultEvent.getVoipVocCnt());
			jsonObject.put("PHON_VOC_CNT", "0");
			int totVocCnt = 0;
			try {
				totVocCnt += Integer.parseInt(netFaultEvent.getNetVocCnt());
			} catch (Exception e1) {
			}
			try {
				totVocCnt += Integer.parseInt(netFaultEvent.getIptvVocCnt());
			} catch (Exception e1) {
			}
			try {
				totVocCnt += Integer.parseInt(netFaultEvent.getVoipVocCnt());
			} catch (Exception e1) {
			}
			jsonObject.put("TOT_VOC_CNT", "" + totVocCnt);
			jsonObject.put("MASS_CO_CL_CD", netFaultEvent.getDevAlarmType());
			jsonObject.put("MASS_DMG_SCRBR_CNT", netFaultEvent.getmAlarmCnt());
			jsonObject.put("MASS_SHSPD_DMG_LINE_CNT", netFaultEvent.getmNetAlarmCnt());
			jsonObject.put("MASS_IPTV_DMG_LINE_CNT", netFaultEvent.getmIptvAlarmCnt());
			jsonObject.put("MASS_PHON_DMG_LINE_CNT", netFaultEvent.getmPhoneAlarmCnt());
			jsonObject.put("MASS_SHSPD_INET_VOC_CNT", netFaultEvent.getmNetVocCnt());
			jsonObject.put("MASS_IPTV_VOC_CNT", netFaultEvent.getmIptvVocCnt());
			jsonObject.put("MASS_VOIP_VOC_CNT", netFaultEvent.getmVoipVocCnt());
			jsonObject.put("CO_DMG_SCRBR_CNT", netFaultEvent.getbAlarmCnt());
			jsonObject.put("CO_SHSPD_DMG_LINE_CNT", netFaultEvent.getbNetAlarmCnt());
			jsonObject.put("CO_IPTV_DMG_LINE_CNT", netFaultEvent.getbIptvAlarmCnt());
			jsonObject.put("CO_PHON_DMG_LINE_CNT", netFaultEvent.getbPhoneAlarmCnt());
			jsonObject.put("CO_SHSPD_INET_VOC_CNT", netFaultEvent.getbNetVocCnt());
			jsonObject.put("CO_IPTV_VOC_CNT", netFaultEvent.getbIptvVocCnt());
			jsonObject.put("CO_VOIP_VOC_CNT", netFaultEvent.getbVoipVocCnt());
			jsonObject.put("DABL_OBJ_CL_CD", netFaultEvent.getDevAlarmType());

			// 피해가입자수는 (매스 피해고객수) + (비즈 피해고객수)를 사용하여 계산
			int massDmgScrbrCnt = 0;
			try {
				massDmgScrbrCnt = Integer.parseInt(netFaultEvent.getmAlarmCnt());
			} catch (Exception e) {
				;
			}
			int coDmgScrbrCnt = 0;
			try {
				coDmgScrbrCnt = Integer.parseInt(netFaultEvent.getbAlarmCnt());
			} catch (Exception e) {
				;
			}
			jsonObject.put("DMG_SCRBR_CNT", (massDmgScrbrCnt+coDmgScrbrCnt)+"");
		} else if (FomsEvent.DETAIL_CMD2_AMI_GEN == event.getDetailCmd2() || FomsEvent.DETAIL_CMD2_ENV_GEN == event.getDetailCmd2()) {
			// AMI 실시간 장애, 환경감시단말 실시간 장애
			jsonObject.put("NET_CL_CD", NET_CL_CD);
			jsonObject.put("NET_CL_NM", NET_CL_NM);
			jsonObject.put("DABL_ST_CD", GENERATED_FAULT_CD);
			jsonObject.put("kind", GENERATE_EVENT);
		} else if (FomsEvent.DETAIL_CMD2_AMI_CLR == event.getDetailCmd2() || FomsEvent.DETAIL_CMD2_ENV_CLR == event.getDetailCmd2()) {
			// AMI 실시간 장애 해제, 환경감시단말 장애 해제
			jsonObject.put("NET_CL_CD", NET_CL_CD);
			jsonObject.put("NET_CL_NM", NET_CL_NM);
			jsonObject.put("DABL_ST_CD", CLEARED_FAULT_CD);
			jsonObject.put("RLSE_DTM", event.getEvtGenTime());
			jsonObject.put("RLSE_RCV_DTM", MiscUtils.getDateTime ());
			jsonObject.put("kind", CLEAR_EVENT);
		}
		
		jsonSender.put(jsonObject);
	}

	public void sendInit() throws Exception {
		byte [] headPacket = {0x41,0x53,0x56,0x47
				 ,0x34
				 ,0x00
				 ,0x2b
				 ,0x51
				 ,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
				 ,0x00,0x00
				 ,0x00
				 ,0x00
				 ,0x00,0x00,0x00     
		 };
		 
		 byte [] userId = this.userId.getBytes();
		 byte [] dataPacket1 ={
				 0x1f //userid				 
				 ,'0',0x1f                 //usertype
				 ,0x20,0x1f                //teamcode_data
				 ,0x20,0x1f                //k_top_cd_data
		 };
		 byte [] authKey = this.authKey.getBytes();
		 byte [] dataPacket2 ={
				  0x1f
				 ,0x20,0x1f
				 ,0x20,0x1f
				 ,0x20,0x1f
				 ,0x20,0x1f
				 ,0x03};
		 
		 int dataPacketSize = userId.length+dataPacket1.length+authKey.length+dataPacket2.length;
		 byte [] dataPacket = new byte[dataPacketSize];
		 int dataIndex = 0;
		 
		 for(;dataIndex<userId.length;dataIndex++)
		 {
			 dataPacket[dataIndex] =  userId[dataIndex];			 
		 }
		 for(int i=0;i<dataPacket1.length;i++)
		 {
			 dataPacket[dataIndex++] =  dataPacket1[i];			 
		 }
		 for(int i=0;i<authKey.length;i++)
		 {
			 dataPacket[dataIndex++] =  authKey[i];
		 }
		 for(int i=0;i<dataPacket2.length;i++)
		 {
			 dataPacket[dataIndex++] =  dataPacket2[i];			 
		 }
		 
		 byte [] sendPacket = new byte[dataIndex+headPacket.length+1] ;
		 
		 int sendIndex = 0;
		 
		 for(;sendIndex<headPacket.length;sendIndex++)
		 {
			 sendPacket[sendIndex] =  headPacket[sendIndex];
		 }
		 //dataSize
		 sendPacket[sendIndex++] = (byte) dataIndex;
		    
		 for(int i=0;i<dataPacket.length;i++)
		 {
			 sendPacket[sendIndex++] =  dataPacket[i];
		 }
		
		
		outputStream.write(sendPacket);
		logger.info("send init packet");
	}
    
    public void sendPollingPacket() throws Exception {
        byte [] packet = {0x41, 0x53, 0x56, 0x47
                         ,0x34
                         ,0x00
                         ,0x2b
                         ,(byte) 0xff
                         ,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
                         ,0x00,0x00
                         ,0x00
                         ,0x00
                         ,0x00,0x00,0x00,0x00};
		outputStream.write(packet);
		outputStream.flush();
		logger.info("send polling packet");
    }

    public static void main (String [] args) {
//        if (args.length != 1) {
//            System.out.println ("사용법 : ./run RealTimeCollectFoms 절대path");
//            System.exit (0);
//        }
    	EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("RealTimeCollectFoms", envManager.getOptions());
    		System.exit(0);
    	}

        new RealTimeCollectFoms (args);
    }
}

