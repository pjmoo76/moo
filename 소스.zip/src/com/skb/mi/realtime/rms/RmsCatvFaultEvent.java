package com.skb.mi.realtime.rms;

public class RmsCatvFaultEvent extends RmsEvent {
	private	String	areaName;
	private	String	devTypeName;

	public RmsCatvFaultEvent(String[] items) {
		set(items);
	}

	public String getAreaName() {
		return areaName;
	}

	public String getDevTypeName() {
		return devTypeName;
	}

	private void set(String[] items) {
		this.evtKind = RmsEvent.EVT_CATV_FAULT;
		try {
			this.serialNo = Integer.parseInt(items[1]);
		} catch (Exception e) {
			this.serialNo = 0;
		}
		this.evtId = items[2].trim();
		this.evtCode = items[3].trim();
		this.severity = items[4].trim();
		this.genTime = items[5].trim();
		this.areaNo = items[6].trim();
		this.areaName = items[7].trim();
		this.jisaNo = items[8].trim();
		this.jisaName = items[9].trim();
		this.stationNo = items[10].trim();
		this.stationName = items[11].trim();
		this.tid = items[12].trim();
		this.sysId = items[13].trim();
		this.sysName = items[14].trim();
		this.devType = items[15].trim();
		this.devTypeName = items[16].trim();
		this.otxNo = items[17].trim();
		this.cellNo = items[18].trim();
		this.cardNo = items[19].trim();
		this.portNo = items[20].trim();
		this.content = items[21].trim();
		this.description = items[22].trim();
		this.alias = items[23].trim();
		this.evtType = items[24].trim();
		this.mangType = items[25].trim();
		this.noticeId = items[26].trim();
		this.upperEquipId = items[27].trim();
		this.upperEquipName = items[28].trim();
		this.upperEquipIfPort = items[29].trim();
		this.upperEquipIfAlias = items[30].trim();
		
		try {
			this.cmStbCount = Integer.parseInt(items[31]);
		} catch (Exception e) {
			this.cmStbCount = 0;
		}
		
		try {
			this.lineTotalCnt = Integer.parseInt(items[32]);
		} catch (Exception e) {
			this.lineTotalCnt = 0;
		}
		
		try {
			this.lineInternetCount = Integer.parseInt(items[33]);
		} catch (Exception e) {
			this.lineInternetCount = 0;
		}
		
		try {
			this.lineQamCount = Integer.parseInt(items[34]);
		} catch (Exception e) {
			this.lineQamCount = 0;
		}
		
		try {
			this.line8vsbCount = Integer.parseInt(items[35]);
		} catch (Exception e) {
			this.line8vsbCount = 0;
		}
		
		try {
			this.dmgTotalLineCount = Integer.parseInt(items[36]);
		} catch (Exception e) {
			this.dmgTotalLineCount = 0;
		}
		
		try {
			this.dmgInternetLineCount = Integer.parseInt(items[37]);
		} catch (Exception e) {
			this.dmgInternetLineCount = 0;
		}
		
		try {
			this.dmgQamLineCount = Integer.parseInt(items[38]);
		} catch (Exception e) {
			this.dmgQamLineCount = 0;
		}
		
		try {
			this.dmg8vsbLineCount = Integer.parseInt(items[39]);
		} catch (Exception e) {
			this.dmg8vsbLineCount = 0;
		}
		
		try {
			this.vocTotalCount = Integer.parseInt(items[40]);
		} catch (Exception e) {
			this.vocTotalCount = 0;
		}
		
		try {
			this.vocInternetCount = Integer.parseInt(items[41]);
		} catch (Exception e) {
			this.vocInternetCount = 0;
		}
		
		try {
			this.vocQamCount = Integer.parseInt(items[42]);
		} catch (Exception e) {
			this.vocQamCount = 0;
		}
		
		try {
			this.voc8vsbCount = Integer.parseInt(items[43]);
		} catch (Exception e) {
			this.voc8vsbCount = 0;
		}
		
		try {
			this.custTotalCount = Integer.parseInt(items[44]);
		} catch (Exception e) {
			this.custTotalCount = 0;
		}
		
		try {
			this.custInternetCount = Integer.parseInt(items[45]);
		} catch (Exception e) {
			this.custInternetCount = 0;
		}
		
		try {
			this.custQamCount = Integer.parseInt(items[46]);
		} catch (Exception e) {
			this.custQamCount = 0;
		}
		
		try {
			this.cust8vsbCount = Integer.parseInt(items[47]);
		} catch (Exception e) {
			this.cust8vsbCount = 0;
		}
		
		try {
			this.dmgTotalCustCount = Integer.parseInt(items[48]);
		} catch (Exception e) {
			this.dmgTotalCustCount = 0;
		}
		
		try {
			this.dmgInternetCustCount = Integer.parseInt(items[49]);
		} catch (Exception e) {
			this.dmgInternetCustCount = 0;
		}
		
		try {
			this.dmgQamCustCount = Integer.parseInt(items[50]);
		} catch (Exception e) {
			this.dmgQamCustCount = 0;
		}
		
		try {
			this.dmg8vsbCustCount = Integer.parseInt(items[51]);
		} catch (Exception e) {
			this.dmg8vsbCustCount = 0;
		}
		
		try {
			this.catvSoName = items[52];
		} catch (Exception e) {
			this.catvSoName = "";
		}
		
		try {
			this.cellMemo = items[53];
		} catch (Exception e) {
			this.cellMemo = "";
		}
		
		if(!"".equals(this.noticeId)){
			this.operDablYn = "Y";
		}else{
			this.operDablYn = "N";
		}
		
	}

	@Override
	public String getDablLclCd() {
		return "01";	// DABL_LCL_CD : 장비장애
	}
}
