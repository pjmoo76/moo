package com.skb.mi.realtime.rms;

public class RmsEquipFaultEvent extends RmsEvent {
	private	String	areaName;
	private	String	devTypeName;

	public RmsEquipFaultEvent(String[] items) {
		set(items);
	}

	public String getAreaName() {
		return areaName;
	}

	public String getDevTypeName() {
		return devTypeName;
	}

	private void set(String[] items) {
		this.evtKind = RmsEvent.EVT_EQUIP_FAULT;
		try {
			this.serialNo = Integer.parseInt(items[1]);
		} catch (Exception e) {
			this.serialNo = 0;
		}
		this.evtId = items[2].trim();
		this.evtCode = items[3].trim();
		this.severity = items[4].trim();
		this.genTime = items[5].trim();
		this.areaNo = items[6].trim();
		this.areaName = items[7].trim();
		this.jisaNo = items[8].trim();
		this.jisaName = items[9].trim();
		this.stationNo = items[10].trim();
		this.stationName = items[11].trim();
		this.tid = items[12].trim();
		this.sysId = items[13].trim();
		this.sysName = items[14].trim();
		this.devType = items[15].trim();
		this.devTypeName = items[16].trim();
		this.otxNo = items[17].trim();
		this.cellNo = items[18].trim();
		this.cardNo = items[19].trim();
		this.portNo = items[20].trim();
		this.content = items[21].trim();
		this.description = items[22].trim();
		this.alias = items[23].trim();
		this.evtType = items[24].trim();
		this.mangType = items[25].trim();
		this.noticeId = items[26].trim();
		this.upperEquipId = items[27].trim();
		this.upperEquipName = items[28].trim();
		this.upperEquipIfPort = items[29].trim();
		this.upperEquipIfAlias = items[30].trim();
		try {
			this.macCount = Integer.parseInt(items[31]);
		} catch (Exception e) {
			this.macCount = 0;
		}
		try {
			this.vocCount = Integer.parseInt(items[32]);
		} catch (Exception e) {
			this.vocCount = 0;
		}
		try {
			this.internetCnt = Integer.parseInt(items[33]);
		} catch (Exception e) {
			this.internetCnt = 0;
		}
		try {
			this.commIptvCnt = Integer.parseInt(items[34]);
		} catch (Exception e) {
			this.commIptvCnt = 0;
		}
		try {
			this.onlyIptvCnt = Integer.parseInt(items[35]);
		} catch (Exception e) {
			this.onlyIptvCnt = 0;
		}
		try {
			this.voiceCnt = Integer.parseInt(items[36]);
		} catch (Exception e) {
			this.voiceCnt = 0;
		}
		try {
			this.iptvVocCnt = Integer.parseInt(items[37]);
		} catch (Exception e) {
			this.iptvVocCnt = 0;
		}
		try {
			this.voiceVocCnt = Integer.parseInt(items[38]);
		} catch (Exception e) {
			this.voiceVocCnt = 0;
		}
		try {
			this.totalVocCnt = Integer.parseInt(items[39]);
		} catch (Exception e) {
			this.totalVocCnt = 0;
		}
		
		if(!"".equals(this.noticeId)){
			this.operDablYn = "Y";
		}else{
			this.operDablYn = "N";
		}
	}

	@Override
	public String getDablLclCd() {
		return "01";	// DABL_LCL_CD : 장비장애
	}
}
