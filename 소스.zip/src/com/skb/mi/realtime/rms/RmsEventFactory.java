package com.skb.mi.realtime.rms;

import java.io.InputStream;

import org.apache.log4j.Logger;

import com.skb.mi.common.SockUtils;
import com.skb.mi.common.StringUtils;

public class RmsEventFactory {
	
	private	Logger	logger;
	private	byte[]	HEADER			= {0x1b, 0x02};
	private	byte[]	TAIL			= {0x1b, 0x03};
	private	byte	DELIMITER		= 0x1f;
	private	String	CHARSET_NAME	= "EUC-KR";
	private	int		MAX_DATA_SIZE	= 20000;
	
	private	boolean	 initEnd = false;
	
	public boolean getInitEnd() {
		return this.initEnd;
	}
	

	public RmsEventFactory() {
		this.logger = Logger.getLogger(this.getClass());
	}
	
	public RmsEvent get(InputStream is) throws Exception {
		/*
		 * header : 0x1b, 0x02
		 * evtKind : char(3) - 장비장애:303, 회선장애:501, 
		 * ...
		 * tail : 0x1b, 0x03
		 * ----------
		 * delimiter : 0x1f
		 */
		byte[] data = SockUtils.read(is, HEADER, MAX_DATA_SIZE, TAIL);
		logger.debug("size=" + data.length);
		logger.debug(StringUtils.toReadableString(data));
		String[] items = StringUtils.split(data, DELIMITER, CHARSET_NAME);
		
		if (items == null || items.length == 0) {
			return null;
		}
		for (int i = 0; i < items.length; i ++) {
			logger.debug(String.format("[%d] %s", i, items[i]));
		}
		RmsEvent event = null;
		//303
		if (RmsEvent.EVT_EQUIP_FAULT.equals(items[0])) {
			event = new RmsEquipFaultEvent(items);
		//501
		} else if (RmsEvent.EVT_CIRCUIT_FAULT.equals(items[0])) {
			event = new RmsCircuitFaultEvent(items);
		//901	
		} else if (RmsEvent.EVT_CATV_FAULT.equals(items[0])) {
			event = new RmsCatvFaultEvent(items);
		//ALM	
		} else if (RmsEvent.EVT_ETC.equals(items[0])) {
			if("END".equals(items[1])){
				logger.debug("INIT END!!");
				initEnd = true;
				return null;
			}else{
				logger.debug("FAIL!!");
				return null;
			}
		} else {
			logger.debug("unsupported event: " + items[0]);
			return null;
		}
		return event;
	}


}
