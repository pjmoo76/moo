package com.skb.mi.realtime.rms;

public class RmsCircuitFaultEvent extends RmsEvent {
	private	String	poleNo;
	private	int		totalCustCnt;
	private	int		internetLineCnt;
	private	int		commIptvLineCnt;
	private	int		onlyIptvLineCnt;
	private	int		voiceLineCnt;
	private	int		damageCustCnt;
	private	String	memo;
	private String ringId;
	private String fdf;
	private String cableDistance;

	public RmsCircuitFaultEvent(String[] items) {
		set(items);
	}

	public String getPoleNo() {
		return poleNo;
	}

	public int getTotalCustCnt() {
		return totalCustCnt;
	}

	public int getInternetLineCnt() {
		return internetLineCnt;
	}

	public int getCommIptvLineCnt() {
		return commIptvLineCnt;
	}

	public int getOnlyIptvLineCnt() {
		return onlyIptvLineCnt;
	}

	public int getVoiceLineCnt() {
		return voiceLineCnt;
	}

	public int getDamageCustCnt() {
		return damageCustCnt;
	}
	
	public String getMemo() {
		return this.memo;
	}
	
	

	public String getRingId() {
		return ringId;
	}

	public void setRingId(String ringId) {
		this.ringId = ringId;
	}

	public String getFdf() {
		return fdf;
	}

	public void setFdf(String fdf) {
		this.fdf = fdf;
	}

	public String getCableDistance() {
		return cableDistance;
	}

	public void setCableDistance(String cableDistance) {
		this.cableDistance = cableDistance;
	}

	private void set(String[] items) {
		this.evtKind = RmsEvent.EVT_CIRCUIT_FAULT;
		try {
			this.serialNo = Integer.parseInt(items[1]);
		} catch (Exception e) {
			this.serialNo = 0;
		}
		this.evtId = items[2].trim();
		this.evtCode = items[3].trim();
		this.severity = items[4].trim();
		this.genTime = items[5].trim();
		this.areaNo = items[6].trim();
		this.devType = items[7].trim();
		this.jisaNo = items[8].trim();
		this.jisaName = items[9].trim();
		this.stationNo = items[10].trim();
		this.stationName = items[11].trim();
		this.tid = items[12].trim();
		this.sysId = items[13].trim();
		this.sysName = items[14].trim();
		this.otxNo = items[15].trim();
		this.cellNo = items[16].trim();
		this.cardNo = items[17].trim();
		this.portNo = items[18].trim();
		try {
			this.macCount = Integer.parseInt(items[19]);
		} catch (Exception e) {
			this.macCount = 0;
		}
		this.content = items[20].trim();
		this.evtType = items[21].trim();
		this.mangType = items[22].trim();
		this.noticeId = items[23].trim();
		this.upperEquipId = items[24].trim();
		this.upperEquipName = items[25].trim();
		this.upperEquipIfPort = items[26].trim();
		this.upperEquipIfAlias = items[27].trim();
		try {
			this.vocCount = Integer.parseInt(items[28]);
		} catch (Exception e) {
			this.vocCount = 0;
		}
		this.poleNo = items[29];
		try {
			this.internetCnt = Integer.parseInt(items[30]);
		} catch (Exception e) {
			this.internetCnt = 0;
		}
		try {
			this.commIptvCnt = Integer.parseInt(items[31]);
		} catch (Exception e) {
			this.commIptvCnt = 0;
		}
		try {
			this.onlyIptvCnt = Integer.parseInt(items[32]);
		} catch (Exception e) {
			this.onlyIptvCnt = 0;
		}
		try {
			this.voiceCnt = Integer.parseInt(items[33]);
		} catch (Exception e) {
			this.voiceCnt = 0;
		}
		try {
			this.iptvVocCnt = Integer.parseInt(items[34]);
		} catch (Exception e) {
			this.iptvVocCnt = 0;
		}
		try {
			this.voiceVocCnt = Integer.parseInt(items[35]);
		} catch (Exception e) {
			this.voiceVocCnt = 0;
		}
		try {
			this.totalVocCnt = Integer.parseInt(items[36]);
		} catch (Exception e) {
			this.totalVocCnt = 0;
		}
		try {
			this.totalCustCnt = Integer.parseInt(items[37]);
		} catch (Exception e) {
			this.totalCustCnt = 0;
		}
		try {
			this.internetLineCnt = Integer.parseInt(items[38]);
		} catch (Exception e) {
			this.internetLineCnt = 0;
		}
		try {
			this.commIptvLineCnt = Integer.parseInt(items[39]);
		} catch (Exception e) {
			this.commIptvLineCnt = 0;
		}
		try {
			this.onlyIptvLineCnt = Integer.parseInt(items[40]);
		} catch (Exception e) {
			this.onlyIptvLineCnt = 0;
		}
		try {
			this.voiceLineCnt = Integer.parseInt(items[41]);
		} catch (Exception e) {
			this.voiceLineCnt = 0;
		}
		try {
			this.damageCustCnt = Integer.parseInt(items[42]);
		} catch (Exception e) {
			this.damageCustCnt = 0;
		}
		if (items.length > 43) {
			this.memo = items[43];
		}
		/* 2023-05-03 추가 필드 */
		this.ringId = items[44].trim();
		this.fdf = items[45].trim();
		this.cableDistance = items[46].trim();
		
		if(!"".equals(this.noticeId)){
			this.operDablYn = "Y";
		}else{
			this.operDablYn = "N";
		}
		
	}

	@Override
	public String getDablLclCd() {
		return "04";	// DABL_LCL_CD : 회선장애
	}
}
