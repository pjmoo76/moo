package com.skb.mi.realtime.rms;

public abstract class RmsEvent {
	static public String	EVT_EQUIP_FAULT		= "303";
	static public String	EVT_CIRCUIT_FAULT	= "501";
	static public String	EVT_CATV_FAULT		= "901";
	static public String	EVT_ETC				= "ALM";

	protected	String	evtKind;
	protected	int		serialNo;
	protected	String	evtId;
	protected	String	evtCode;
	protected	String	severity;
	protected	String	genTime;
	protected	String	areaNo;
	protected	String	jisaNo;
	protected	String	jisaName;
	protected	String	stationNo;
	protected	String	stationName;
	protected	String	tid;
	protected	String	sysId;
	protected	String	sysName;
	protected	String	devType;
	protected	String	otxNo;
	protected	String	cellNo;
	protected	String	cardNo;
	protected	String	portNo;
	protected	String	content;
	protected	String	description;
	protected	String	alias;
	protected	String	evtType;
	protected	String	mangType;
	protected	String	noticeId;
	protected	String	upperEquipId;
	protected	String	upperEquipName;
	protected	String	upperEquipIfPort;
	protected	String	upperEquipIfAlias;
	protected	int		macCount;
	protected	int		vocCount;
	protected	int		internetCnt;
	protected	int		commIptvCnt;
	protected	int		onlyIptvCnt;
	protected	int		voiceCnt;
	protected	int		iptvVocCnt;
	protected	int		voiceVocCnt;
	protected	int		totalVocCnt;
	protected	String	operDablYn;
	
	/*RMS-CATV 추가 250414*/
	protected	int		cmStbCount;
	protected	int		lineTotalCnt;
	protected	int		lineInternetCount;
	protected	int		lineQamCount;
	protected	int		line8vsbCount;
	protected	int		dmgTotalLineCount;
	protected	int		dmgInternetLineCount;
	protected	int		dmgQamLineCount;
	protected	int		dmg8vsbLineCount;
	protected	int		vocTotalCount;
	protected	int		vocInternetCount;
	protected	int		vocQamCount;
	protected	int		voc8vsbCount;
	protected	int		custTotalCount;
	protected	int		custInternetCount;
	protected	int		custQamCount;
	protected	int		cust8vsbCount;
	protected	int		dmgTotalCustCount;
	protected	int		dmgInternetCustCount;
	protected	int		dmgQamCustCount;
	protected	int		dmg8vsbCustCount;
	protected	String	catvSoName;
	protected	String	cellMemo;
	
	

	public RmsEvent() { 
	}

	public String getEvtKind() {
		return this.evtKind;
	}

	public int getSerialNo() {
		return serialNo;
	}

	public String getEvtId() {
		return evtId;
	}

	public String getEvtCode() {
		return evtCode;
	}

	public String getSeverity() {
		return severity;
	}

	public String getGenTime() {
		return genTime;
	}

	public String getAreaNo() {
		return areaNo;
	}

	public String getJisaNo() {
		return jisaNo;
	}

	public String getJisaName() {
		return jisaName;
	}

	public String getStationNo() {
		return stationNo;
	}

	public String getStationName() {
		return stationName;
	}

	public String getTid() {
		return tid;
	}

	public String getSysId() {
		return sysId;
	}

	public String getSysName() {
		return sysName;
	}

	public String getDevType() {
		return devType;
	}

	public String getOtxNo() {
		return otxNo;
	}

	public String getCellNo() {
		return cellNo;
	}

	public String getCardNo() {
		return cardNo;
	}

	public String getPortNo() {
		return portNo;
	}

	public String getContent() {
		return content;
	}

	public String getDescription() {
		return description;
	}

	public String getAlias() {
		return alias;
	}

	public String getEvtType() {
		return evtType;
	}

	public String getMangType() {
		return mangType;
	}

	public String getNoticeId() {
		return noticeId;
	}

	public String getUpperEquipId() {
		return upperEquipId;
	}

	public String getUpperEquipName() {
		return upperEquipName;
	}

	public String getUpperEquipIfPort() {
		return upperEquipIfPort;
	}

	public String getUpperEquipIfAlias() {
		return upperEquipIfAlias;
	}

	public int getMacCount() {
		return macCount;
	}

	public int getVocCount() {
		return vocCount;
	}

	public int getInternetCnt() {
		return internetCnt;
	}

	public int getCommIptvCnt() {
		return commIptvCnt;
	}

	public int getOnlyIptvCnt() {
		return onlyIptvCnt;
	}

	public int getVoiceCnt() {
		return voiceCnt;
	}

	public int getIptvVocCnt() {
		return iptvVocCnt;
	}

	public int getVoiceVocCnt() {
		return voiceVocCnt;
	}

	public int getTotalVocCnt() {
		return totalVocCnt;
	}
	

	public String getOperDablYn() {
		return operDablYn;
	}

	public void setOperDablYn(String operDablYn) {
		this.operDablYn = operDablYn;
	}
	
	public int getCmStbCount() {
		return cmStbCount;
	}

	public void setCmStbCount(int cmStbCount) {
		this.cmStbCount = cmStbCount;
	}

	public int getLineTotalCnt() {
		return lineTotalCnt;
	}

	public void setLineTotalCnt(int lineTotalCnt) {
		this.lineTotalCnt = lineTotalCnt;
	}

	public int getLineInternetCount() {
		return lineInternetCount;
	}

	public void setLineInternetCount(int lineInternetCount) {
		this.lineInternetCount = lineInternetCount;
	}

	public int getLineQamCount() {
		return lineQamCount;
	}

	public void setLineQamCount(int lineQamCount) {
		this.lineQamCount = lineQamCount;
	}

	public int getLine8vsbCount() {
		return line8vsbCount;
	}

	public void setLine8vsbCount(int line8vsbCount) {
		this.line8vsbCount = line8vsbCount;
	}

	public int getDmgTotalLineCount() {
		return dmgTotalLineCount;
	}

	public void setDmgTotalLineCount(int dmgTotalLineCount) {
		this.dmgTotalLineCount = dmgTotalLineCount;
	}

	public int getDmgInternetLineCount() {
		return dmgInternetLineCount;
	}

	public void setDmgInternetLineCount(int dmgInternetLineCount) {
		this.dmgInternetLineCount = dmgInternetLineCount;
	}

	public int getDmgQamLineCount() {
		return dmgQamLineCount;
	}

	public void setDmgQamLineCount(int dmgQamLineCount) {
		this.dmgQamLineCount = dmgQamLineCount;
	}

	public int getDmg8vsbLineCount() {
		return dmg8vsbLineCount;
	}

	public void setDmg8vsbLineCount(int dmg8vsbLineCount) {
		this.dmg8vsbLineCount = dmg8vsbLineCount;
	}

	public int getVocTotalCount() {
		return vocTotalCount;
	}

	public void setVocTotalCount(int vocTotalCount) {
		this.vocTotalCount = vocTotalCount;
	}

	public int getVocInternetCount() {
		return vocInternetCount;
	}

	public void setVocInternetCount(int vocInternetCount) {
		this.vocInternetCount = vocInternetCount;
	}

	public int getVocQamCount() {
		return vocQamCount;
	}

	public void setVocQamCount(int vocQamCount) {
		this.vocQamCount = vocQamCount;
	}

	public int getVoc8vsbCount() {
		return voc8vsbCount;
	}

	public void setVoc8vsbCount(int voc8vsbCount) {
		this.voc8vsbCount = voc8vsbCount;
	}

	public int getCustTotalCount() {
		return custTotalCount;
	}

	public void setCustTotalCount(int custTotalCount) {
		this.custTotalCount = custTotalCount;
	}

	public int getCustInternetCount() {
		return custInternetCount;
	}

	public void setCustInternetCount(int custInternetCount) {
		this.custInternetCount = custInternetCount;
	}

	public int getCustQamCount() {
		return custQamCount;
	}

	public void setCustQamCount(int custQamCount) {
		this.custQamCount = custQamCount;
	}

	public int getCust8vsbCount() {
		return cust8vsbCount;
	}

	public void setCust8vsbCount(int cust8vsbCount) {
		this.cust8vsbCount = cust8vsbCount;
	}

	public int getDmgTotalCustCount() {
		return dmgTotalCustCount;
	}

	public void setDmgTotalCustCount(int dmgTotalCustCount) {
		this.dmgTotalCustCount = dmgTotalCustCount;
	}

	public int getDmgInternetCustCount() {
		return dmgInternetCustCount;
	}

	public void setDmgInternetCustCount(int dmgInternetCustCount) {
		this.dmgInternetCustCount = dmgInternetCustCount;
	}

	public int getDmgQamCustCount() {
		return dmgQamCustCount;
	}

	public void setDmgQamCustCount(int dmgQamCustCount) {
		this.dmgQamCustCount = dmgQamCustCount;
	}

	public int getDmg8vsbCustCount() {
		return dmg8vsbCustCount;
	}

	public void setDmg8vsbCustCount(int dmg8vsbCustCount) {
		this.dmg8vsbCustCount = dmg8vsbCustCount;
	}

	public String getCatvSoName() {
		return catvSoName;
	}

	public void setCatvSoName(String catvSoName) {
		this.catvSoName = catvSoName;
	}

	public String getCellMemo() {
		return cellMemo;
	}

	public void setCellMemo(String cellMemo) {
		this.cellMemo = cellMemo;
	}
	
	abstract public String getDablLclCd();
	
	public String getDablGrCd() {
		if ("1".equals(severity)) return "02";	// warning
		if ("2".equals(severity)) return "03";	// minor
		if ("3".equals(severity)) return "04";	// major
		if ("4".equals(severity)) return "05";	// warning
		return null;
	}
}
