package com.skb.mi.realtime;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.sql.ResultSet;

// JSON
import	org.json.simple.JSONObject;
import	org.json.simple.parser.JSONParser;

// WebSocket
import	org.java_websocket.WebSocketImpl;
import	org.java_websocket.client.WebSocketClient;
import	org.java_websocket.drafts.Draft;
import	org.java_websocket.drafts.Draft_6455;
import	org.java_websocket.handshake.ServerHandshake;

import  com.skb.mi.common.DBController;
import	com.skb.mi.thread.SmsClientEquipThread;				// 10분마다 SMS발송 VIP List를 Update

public class SmsClientEquip extends WebSocketClient {

	public static String ALL_SVC_MGMT_NUM = "9999999999";

	public static String	TEAMS			= "005";		// NMS_CD
	public static String	FAULT_EQUIP		= "01";			// 장비 장애

	JSONParser	   jsonParser;
    DBController   dbController;
    String         dbUrl, userName, password; 

    String         absolutePath;

	Hashtable<String,String>	faultList;

	// 10분마다 SMS 발송 VIP List를 Update하는 Thread
	SmsClientEquipThread		smsClientEquipThread;

	private WebSocketClient webSocketClient;

	public SmsClientEquip (String absolutePath, URI url, Draft draft) {
		super (url, draft);
        this.absolutePath = absolutePath;
		jsonParser = new JSONParser ();

		faultList = new Hashtable<String,String>();
        try {
            readDbInfo ();
			dbOpen ();
			smsClientEquipThread = new SmsClientEquipThread (dbController.getStmt ());
			smsClientEquipThread.start ();
        } catch (Exception e) {
             System.out.println ("SmsClientEquipThread 생성 Exception : " + e);
        } 
	}

	public void readDbInfo () throws Exception {
		String  oneLine;
		FileReader      fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + "db.info");
		BufferedReader bufferedReader = new BufferedReader (fileReader);
		dbUrl = bufferedReader.readLine ();
		userName = bufferedReader.readLine ();
		password = bufferedReader.readLine ();
		bufferedReader.close ();
		fileReader.close ();
	}

	public void dbOpen () {
        try {
             dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
        } catch (Exception e) {
             System.out.println ("SmsClientEquip DB Exception : " + e);
             System.exit (1);                                        // DB접속 에러시 종료
        } 
	}

	@Override
	public void onOpen (ServerHandshake serverHandshake) {
		System.out.println ("opend connection....");
		String	message = "{\"kind\":\"ID\",\"ID\":\"gildong\",\"recvMessage\":\"GEN|CLR\"}";
		send (message);
	}

	@Override
	public void onMessage (String message) {
//        System.out.println ("\nonMessage : " + message);
        String dablNum, equipId, dablCd;
		try {
			JSONObject	jsonObject = (JSONObject) jsonParser.parse (message);
			String		kind = jsonObject.get ("kind").toString ();
			if (kind != null) {
				if (kind.equals ("GEN") || kind.equals ("CLR")) {
					checkSms (jsonObject);
				}
			}
			jsonObject = null;
		} catch (Exception e) {
			System.out.println ("[" + getDateSecond () + "] " + "=========== Exception ==========");
			System.out.println ("[" + getDateSecond () + "] " + "Received : " + message);
			System.out.println ("[" + getDateSecond () + "] " + "jsonParser : " + jsonParser);
			System.out.println ("[" + getDateSecond () + "] " + "Exception : " + e);
			System.out.println ("[" + getDateSecond () + "] " + "================================\n");
		}
	}

	public void checkSms (JSONObject jsonObject) {
		String	dablLclCd = jsonObject.get ("DABL_LCL_CD").toString ();
		String	nmsCd = jsonObject.get ("NMS_CD").toString ();

		if (nmsCd.equals (TEAMS) && dablLclCd.equals (FAULT_EQUIP)) {	// TEAMS && 장비장애
			String	rcvTelNo, query, token;

			StringTokenizer	telTokens;

			String kind = jsonObject.get ("kind").toString ();
			if (kind.equals ("GEN")) {					// 장애 발생
				String	occrDtm = jsonObject.get ("OCCR_DTM").toString ();
				String	equipNm = jsonObject.get ("EQUIP_NM").toString ();
				String	dablDesc = jsonObject.get ("DABL_DESC").toString ();
				String	equipId = jsonObject.get ("EQUIP_ID").toString ();
				String	dablNm = jsonObject.get ("DABL_NM").toString ();
				String	dablCd = jsonObject.get ("DABL_CD").toString ();
				String	phoneList = smsClientEquipThread.getPhoneList (equipId, dablCd);
				System.out.println ("\n\r phoneList : " + phoneList);
				if (phoneList != null) {
					System.out.println ("EQUIP 장애 : " + jsonObject);
					telTokens = new StringTokenizer (phoneList, ",");
					while (telTokens.hasMoreTokens ()) {
						rcvTelNo = telTokens.nextToken ();
						query = makeQuery ("발생", occrDtm, equipNm, dablNm, dablDesc, rcvTelNo);	
						dbController.executeUpdate (query);
					}
					faultList.put (jsonObject.get ("DABL_NUM").toString (), phoneList + "$" + equipNm + "$" + dablNm + "$" + dablDesc);
				}
			} else if (kind.equals ("CLR")) {				// 장애 해제
				System.out.println ("해제 : " + jsonObject.toString ());
				sendClearSms (jsonObject.get ("DABL_NUM").toString ()
							, jsonObject.get ("RLSE_RCV_DTM").toString ());
			}
			System.out.println ("---------> faultList'size : " + faultList.size ());
		}
	}

	public void sendClearSms (String key, String rlseRcvDtm) {		// Key : NMS_ALAMR_NO
		if (faultList.get (key) != null) {
			System.out.println ("key : " + faultList.get (key));

			StringTokenizer	tokens = new StringTokenizer (faultList.get (key), "$");
			String phoneList = tokens.nextToken ();
			String equipNm = tokens.nextToken ();
			String dablNm = tokens.nextToken ();
			String dablDesc = tokens.nextToken ();
			String rcvTelNo, query;

			tokens = new StringTokenizer (phoneList, ",");
			while (tokens.hasMoreTokens ()) {
				rcvTelNo = tokens.nextToken ();
				query = makeQuery ("복구", rlseRcvDtm, equipNm, dablNm, dablDesc, rcvTelNo);	
				dbController.executeUpdate (query);
			}
			faultList.remove (key);
		}
	}

	@Override
	public void onClose (int code, String reason, boolean remote) {
		System.out.println ("[" + getDateSecond () + "] " + "Connection closed by " + (remote ? "remote peer" : "us"));
        dbController.closeDB ();
		System.exit (0);
	}

	@Override
	public void onError (Exception e) {
		System.out.println ("[" + getDateSecond () + "] " + "onError : " + e);
        dbController.closeDB ();
		System.exit (0);
	}

	public String makeQuery (String kind
							 , String occrDtm
							 , String equipNm
							 , String dablNm
							 , String dablDesc
							 , String rcvTelNo) {
		String	msg = "※관련 운용자는 확인 후 신속한 대응 바랍니다.";
		if (kind.equals ("복구"))
			msg = "장애 복구되었습니다.";
		String	query = "INSERT INTO TBL_SUBMIT_QUEUE"
					  + " ( CMP_MSG_ID "
					  + " , CMP_MSG_GROUP_ID"
					  + " , USR_ID"
					  + " , SMS_GB"
					  + " , USED_CD"
					  + " , CONTENT_CNT"
					  + " , CONTENT_MIME_TYPE"
					  + " , RESERVED_FG"
					  + " , RESERVED_DTTM"
					  + " , SAVED_FG"
					  + " , RCV_PHN_ID"
					  + " , SND_PHN_ID"
					  + " , NAT_CD"
					  + " , ASSIGN_CD"
					  + " , SND_MSG)" 
					  + " VALUES "
					  + " (MI_APP.TBL_SUBMIT_QUEUE_SEQ.NEXTVAL"
					  + " , 'FAULT_EQUIP'"
					  + " , '5464'"
					  + " , '1'"
					  + " , '10'"
                      + " , '1'"
                      + " , 'text/plain'"
					  + " , 'I'"
					  + " , TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS')"
					  + " , '1'"
					  + " , REPLACE ('" + rcvTelNo + "', '-', '')"
					  + " , '07078051228'"
					  + " , '82'"
					  + " , '00000'"
					  + ", '[ADAMS-Web발신]"
					  + "\r\n●[" + kind + "시각] " + occrDtm
					  + "\r\n●[장비명] " + equipNm
					  + "\r\n●[장애종류] " + dablNm
					  + "\r\n●[장애내용] " + dablDesc
					  + "\r\n" + msg + "')";

		System.out.println ("발생 쿼리 : " + query);
		return query;
	}

	public String queryString (String str) {
        String ret = "";
        for (int index = 0; index < str.length (); ++ index) {
            if (str.charAt (index) == '\'')
                ret += '\'';
            ret += str.charAt (index);
        }
        return ret;
	}

	public String getDateSecond () {
		Calendar        calendar = Calendar.getInstance ();

		return String.format ("%04d-%02d-%02d %02d:%02d:%02d",
				calendar.get(Calendar.YEAR),
				calendar.get(Calendar.MONTH) + 1,
				calendar.get(Calendar.DAY_OF_MONTH),
				calendar.get(Calendar.HOUR_OF_DAY),
				calendar.get(Calendar.MINUTE),
				calendar.get(Calendar.SECOND));
	}

	public static void main (String [] args) throws URISyntaxException {
        if (args.length != 2) {
             System.out.println ("사용법 : java SmsClientEquip 절대패스 URI");
             System.exit(0);
        }
		SmsClientEquip webSocketClientTest = new SmsClientEquip (
//			new URI ("ws://12.4.96.92:59768"), new Draft_6455 ());		
			args[0], new URI (args [1]), new Draft_6455 ());		
		webSocketClientTest.connect ();
	}
}
