package com.skb.mi.realtime;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.cli.HelpFormatter;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.DBController;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;

public class CollectLinCall {
	private Logger logger;

	private	SqlSession	adamsSession;
	private	SqlSession	wfmsSession;

	final private String	START_TIME	= "000000"; 
	final private String	END_TIME	= "000400"; 
	
	//send massage
	int                         smsChkCnt; //timeout check count
	DBController				dbController;
	String						dbUrl, userName, password;
	
	public CollectLinCall() {
		logger = LogManager.getLogger(CollectLinCall.class.getName()); 
		try {
			logger.info (">>>Run 2021-08-23");
			
			//send massage
			smsChkCnt = 0;
			String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
			ConfigManager configManager = new ConfigManager(cfgFile);
			dbUrl = configManager.getConfig(Constants.ADAMS_DB, Constants.DB_URL);
			userName = configManager.getConfig(Constants.ADAMS_DB, Constants.USER_NAME);
			password = configManager.getConfig(Constants.ADAMS_DB, Constants.PASSWORD);

			adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
			logger.info("made sqlSession for ADAMS_DB");
			wfmsSession = IbatisSessionFactory.openSession(Constants.WFMS_DB);
			logger.info("made sqlSession for WFMS_DB");
			//recovery();
			run();
			
		} catch (Exception e) {
			logger.error("init error", e);
		}
	}
	

	public void run() {
		try{
			while (true) {
				WfmsLinCall("M"); /*매스*/
				WfmsLinCall("B"); /*기업*/
				try {
					/*20211230 10초로 변경 강대윤 */
					Thread.sleep(1000*10);	// sleep 10 seconds
				} catch (Exception e) {
					;
				}
			}
		}catch(Exception e){
			SmsSendMessage("CollectLinCall-Exception 발생");
			System.exit(0);
		}
	}
	
	public void WfmsLinCall(String kind) throws Exception {
		try {
			String  strWfmsLinCallQ1 = "";
			String  strWfmsLinCallQ2 = "";
			String  strWfmsLinCallQ3 = "";
			String  strWfmsLinCallQ4 = "";
			
			if(kind.equals("M")){
				strWfmsLinCallQ1 = "WfmsLinCall.selectWfmsCskill";
			}else{				
				strWfmsLinCallQ1 = "WfmsLinCall.selectWfmsCskillB";
			}
			
			wfmsSession.clearCache();
			
			HashMap<String, Object> hmap = wfmsSession.selectOne(strWfmsLinCallQ1, null);
			String gubun = (String) hmap.get("GUBUN");
			Object incallsObj = hmap.get("INCALLS");
			Object acdcallsObj = hmap.get("ACDCALLS");
			Object abncallsObj = hmap.get("ABNCALLS");
			Object waitcallsObj = hmap.get("WAITCALLS");
			if (incallsObj != null && acdcallsObj != null && abncallsObj != null && waitcallsObj != null) {
				int curLinCalllCnt = ((BigDecimal)incallsObj).intValue();
				int curRpsCallCnt = ((BigDecimal)acdcallsObj).intValue();
				int curGvupCallCnt = ((BigDecimal)abncallsObj).intValue();
				int curWaitCallCnt = ((BigDecimal)waitcallsObj).intValue();
				String mntrDtm =(String) hmap.get("MNTR_DTM");
								
				logger.info(String.format("(KIND=%s),(GUBUN=%s),(INCALLS=%d),(ACDCALLS=%d),(ABNCALLS=%d),(WAITCALLS=%d),(MNTR_DTM=%s)",kind, gubun, curLinCalllCnt, curRpsCallCnt, curGvupCallCnt, curWaitCallCnt, mntrDtm));
				
				if(kind.equals("M")){
					strWfmsLinCallQ2 = "WfmsLinCall.selectOMN50305";
				}else{				
					strWfmsLinCallQ2 = "WfmsLinCall.selectOMN50307";
				}
				
				hmap = adamsSession.selectOne(strWfmsLinCallQ2, null);
				
				int befLinCallCnt = 0;
				try {
					befLinCallCnt = ((BigDecimal)(hmap.get("LIN_CALL_CNT"))).intValue();
				} catch (Exception e) {
				}
				int befRpsCallCnt = 0;
				try {
					befRpsCallCnt = ((BigDecimal)(hmap.get("RPS_CALL_CNT"))).intValue();
				} catch (Exception e) {
				}
				int befGvupCallCnt = 0;
				try {
					befGvupCallCnt = ((BigDecimal)(hmap.get("GVUP_CALL_CNT"))).intValue();
				} catch (Exception e) {
				}
				
				SimpleDateFormat timeFormat = new SimpleDateFormat("HHmmss");
				Date current_date = new Date(System.currentTimeMillis());
				//2023-02-24 실행하는 서버 기준이 아닌 쿼리 하는 서버 기준으로 시간 을 변경 
				String curTime = mntrDtm.substring(8);
				
				
				logger.info(String.format("(KIND=%s),(befLinCallCnt=%d),(befRpsCallCnt=%d),(befGvupCallCnt=%d)", kind, befLinCallCnt, befRpsCallCnt, befGvupCallCnt));
				
				if(curTime.compareTo(START_TIME) >= 0 && curTime.compareTo(END_TIME) < 0) {
					logger.info (">>>[TIME] = " + curTime + ", mntrDtm="+mntrDtm);
					if(curLinCalllCnt > 50 || curRpsCallCnt > 50 || curGvupCallCnt > 50){
						logger.info ("[Process_return]");	
						return;
					}else{
						//logger.info ("[Process_ok]");
					}
					
				}
				
				int chgLinCallCnt = curLinCalllCnt - befLinCallCnt;		// 인입호
				int chaRpsCallCnt = curRpsCallCnt - befRpsCallCnt;		// 응대호
				int chaGvupCallCnt = curGvupCallCnt - befGvupCallCnt;	// 포기호
				int chaWaitCallCnt = curWaitCallCnt;					// 대기호
				
				if (chgLinCallCnt < 0) chgLinCallCnt = 0;
				if (chaRpsCallCnt < 0) chaRpsCallCnt = 0;
				if (chaGvupCallCnt < 0) chaGvupCallCnt = 0;
				if (chaWaitCallCnt < 0) chaWaitCallCnt = 0;

				logger.info(String.format("(KIND=%s),(chgLinCallCnt=%d),(chaRpsCallCnt=%d),(chaGvupCallCnt=%d)", kind, chgLinCallCnt, chaRpsCallCnt, chaGvupCallCnt));

				HashMap<String, String> hmap2 = new HashMap<String, String>();
				hmap2.put("mntrDtm", mntrDtm);
				hmap2.put("gubun", gubun);
				hmap2.put("linCallCnt", ""+chgLinCallCnt);
				hmap2.put("rpsCallCnt", ""+chaRpsCallCnt);
				hmap2.put("gvupCallCnt", ""+chaGvupCallCnt);
				hmap2.put("waitCallCnt", ""+chaWaitCallCnt);
				
				if(kind.equals("M")){
					strWfmsLinCallQ3 = "WfmsLinCall.insertOMN50305_B";
					strWfmsLinCallQ4 = "WfmsLinCall.insertOMN50305_T";
				}else{				
					strWfmsLinCallQ3 = "WfmsLinCall.insertOMN50307_B";
					strWfmsLinCallQ4 = "WfmsLinCall.insertOMN50307_T";
				}
				adamsSession.insert(strWfmsLinCallQ3, hmap2);
				adamsSession.insert(strWfmsLinCallQ4, hmap2);
				
				adamsSession.commit();
				
				smsChkCnt = 0;
			} else {
				logger.info("KIND="+kind+":invalid value...");
				//20220127 로그만 찍도록 변경 
                //throw new Exception();
			}

		} catch (Exception e) {
			SmsSendMessage("CollectLinCall-Exception 발생");
			logger.error("run", e);
			adamsSession.close();
			wfmsSession.close();
			try {
				adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
				wfmsSession = IbatisSessionFactory.openSession(Constants.WFMS_DB);
			} catch (Exception e1) {
				logger.error("KIND="+kind+":re-connect", e1);
				throw e1;
			}
		}		
	}
	
	public static void main(String[] args) {
		EnvManager envManager = new EnvManager(args);
		
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("CollectLinCall", envManager.getOptions());
    		System.exit(0);
    	}
    	new CollectLinCall();
	}

	public void run_bak() {
		while (true) {
			try {
				HashMap<String, Object> hmap = wfmsSession.selectOne("WfmsLinCall.selectWfmsCskill", null);
				String gubun = (String) hmap.get("GUBUN");
				Object incallsObj = hmap.get("INCALLS");
				Object acdcallsObj = hmap.get("ACDCALLS");
				Object abncallsObj = hmap.get("ABNCALLS");
				Object waitcallsObj = hmap.get("WAITCALLS");
				if (incallsObj != null && acdcallsObj != null && abncallsObj != null && waitcallsObj != null) {
					int curLinCalllCnt = ((BigDecimal)incallsObj).intValue();
					int curRpsCallCnt = ((BigDecimal)acdcallsObj).intValue();
					int curGvupCallCnt = ((BigDecimal)abncallsObj).intValue();
					int curWaitCallCnt = ((BigDecimal)waitcallsObj).intValue();
					String mntrDtm =(String) hmap.get("MNTR_DTM");
					wfmsSession.clearCache();
					
					logger.info(String.format("(GUBUN=%s),(INCALLS=%d),(ACDCALLS=%d),(ABNCALLS=%d),(WAITCALLS=%d),(MNTR_DTM=%s)", gubun, curLinCalllCnt, curRpsCallCnt, curGvupCallCnt, curWaitCallCnt, mntrDtm));
					
					hmap = adamsSession.selectOne("WfmsLinCall.selectOMN50305", null);
					int befLinCallCnt = 0;
					try {
						befLinCallCnt = ((BigDecimal)(hmap.get("LIN_CALL_CNT"))).intValue();
					} catch (Exception e) {
					}
					int befRpsCallCnt = 0;
					try {
						befRpsCallCnt = ((BigDecimal)(hmap.get("RPS_CALL_CNT"))).intValue();
					} catch (Exception e) {
					}
					int befGvupCallCnt = 0;
					try {
						befGvupCallCnt = ((BigDecimal)(hmap.get("GVUP_CALL_CNT"))).intValue();
					} catch (Exception e) {
					}
					
					logger.info(String.format("(befLinCallCnt=%d),(befRpsCallCnt=%d),(befGvupCallCnt=%d)", befLinCallCnt, befRpsCallCnt, befGvupCallCnt));
					
					int chgLinCallCnt = curLinCalllCnt - befLinCallCnt;		// 인입호
					int chaRpsCallCnt = curRpsCallCnt - befRpsCallCnt;		// 응대호
					int chaGvupCallCnt = curGvupCallCnt - befGvupCallCnt;	// 포기호
					int chaWaitCallCnt = curWaitCallCnt;					// 대기호
					
					if (chgLinCallCnt < 0) chgLinCallCnt = 0;
					if (chaRpsCallCnt < 0) chaRpsCallCnt = 0;
					if (chaGvupCallCnt < 0) chaGvupCallCnt = 0;
					if (chaWaitCallCnt < 0) chaWaitCallCnt = 0;

					logger.info(String.format("(chgLinCallCnt=%d),(chaRpsCallCnt=%d),(chaGvupCallCnt=%d)", chgLinCallCnt, chaRpsCallCnt, chaGvupCallCnt));

					HashMap<String, String> hmap2 = new HashMap<String, String>();
					hmap2.put("mntrDtm", mntrDtm);
					hmap2.put("gubun", gubun);
					hmap2.put("linCallCnt", ""+chgLinCallCnt);
					hmap2.put("rpsCallCnt", ""+chaRpsCallCnt);
					hmap2.put("gvupCallCnt", ""+chaGvupCallCnt);
					hmap2.put("waitCallCnt", ""+chaWaitCallCnt);
					
					adamsSession.insert("WfmsLinCall.insertOMN50305_B", hmap2);
					adamsSession.insert("WfmsLinCall.insertOMN50305_T", hmap2);
					
					adamsSession.commit();
				} else {
					throw new Exception("invalid value...");
				}

			} catch (Exception e) {
				logger.error("run", e);
				adamsSession.close();
				wfmsSession.close();
				try {
					adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
					wfmsSession = IbatisSessionFactory.openSession(Constants.WFMS_DB);
				} catch (Exception e1) {
					logger.error("re-connect", e1);
				}
			}
			try {
				Thread.sleep(1000*20);	// sleep 20 seconds
			} catch (Exception e) {
				;
			}
		}
	}

	
	//send message
	public void SmsSendMessage(String sndMsg) {
		try {
			smsChkCnt++;
			logger.info(sndMsg);

			if(true){ //smsChkCnt > 5 메세지 발송 회차 설정
                dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
    			PreparedStatement stmt = saveSmsErrMsgInfo(sndMsg);
    			stmt.executeQuery();
    			stmt.close();
    			dbController.closeDB ();
    			smsChkCnt=0;
            }				
		}catch(Exception e){				
		}
	}
	
	
    public PreparedStatement saveSmsErrMsgInfo(String errMsg) throws Exception {
        String	query;
    	query = "merge into TBL_SUBMIT_QUEUE t "
		       + "using ( "
		       + "SELECT	TBL.* "
		       + "	,	(CASE WHEN LENGTHB(TBL.SND_MSG)<80 THEN '00' ELSE '10'  END) as USED_CD "
		       + "	,	(CASE WHEN LENGTHB(TBL.SND_MSG)<80 THEN 0 ELSE 1  END) as CONTENT_CNT "
		       + "FROM ( "
		       + "select null as CMP_MSG_ID "
		       + "  ,  'CO' as CMP_MSG_GROUP_ID "
		       + "  , '5464' as USR_ID "
		       + "  , '1' as SMS_GB "
		       /*+ "  , '00' as USED_CD "*/
		       + "  , 'I' as RESERVED_FG "
		       + "  , to_char(sysdate,'YYYYMMDDHH24MISS') as RESERVED_DTTM "
		       + "  , '0' as SAVED_FG "
		       + "  , replace(a.PHON_NUM,'-','') as RCV_PHN_ID "
		       + "  , '07078051228' as SND_PHN_ID "
		       + "  , '82' as NAT_CD "
		       + "  , '00000' as ASSIGN_CD "
		       + "  , 'text/plain' as CONTENT_MIME_TYPE "
		       + "  , '[ADAMS][W]'||CHR(10)"
		       + "	||'[발생시각] '||TO_CHAR(SYSDATE, 'YYYY/MM/DD HH24:MI')||CHR(10)"
		       + "	||'[장애내용] '|| ? ||CHR(10)"
		       + "	||'[장애조치] 로그 및 프로세스  확인'||CHR(10)"
		       + "	||'※관련 운용자는 확인 후 신속한 대응(장애대응 단톡방 운영) 바랍니다.' as SND_MSG "
		       + "from ( "
		       + "     SELECT USER_NM AS NM, USER_PHON_NUM AS PHON_NUM	FROM OCO40291 "
		       + "     WHERE MSG_TRMS_ID IN ('DEFTL001') AND USER_TYP_CD = 'RCV' "		       
		       + "   ) a "
		       + "   ) TBL "
		       + ") s "
		       + "on (t.CMP_MSG_ID = s.CMP_MSG_ID) "
		       + "when not matched then "
			   + " INSERT ("
			   + "  CMP_MSG_ID"
			   + ", CMP_MSG_GROUP_ID"
			   + ", USR_ID"
			   + ", SMS_GB"
			   + ", USED_CD"
			   + ", RESERVED_FG"
			   + ", RESERVED_DTTM"
			   + ", SAVED_FG"
			   + ", RCV_PHN_ID"
			   + ", SND_PHN_ID"
			   + ", NAT_CD"
			   + ", ASSIGN_CD"
			   + ", CONTENT_CNT"
			   + ", CONTENT_MIME_TYPE"
			   + ", SND_MSG"
			   + ") VALUES ("
			   + "  MI_APP.TBL_SUBMIT_QUEUE_SEQ.NEXTVAL"
			   + ", s.CMP_MSG_GROUP_ID"
			   + ", s.USR_ID"
			   + ", s.SMS_GB"
			   + ", s.USED_CD"
			   + ", s.RESERVED_FG"
			   + ", s.RESERVED_DTTM"
			   + ", s.SAVED_FG"
			   + ", s.RCV_PHN_ID"
			   + ", s.SND_PHN_ID"
			   + ", s.NAT_CD"
			   + ", s.ASSIGN_CD"
			   + ", s.CONTENT_CNT"
			   + ", s.CONTENT_MIME_TYPE"
			   + ", s.SND_MSG )"
         ;
    	logger.info ("query=" + query);
    	
    	PreparedStatement stmt = dbController.prepareStatement(query);
    	stmt.setString(1, errMsg);
    	
    	return stmt;
    }	
    
    public void recovery() throws Exception {
    	
    	File recoveryFile = new File("E://20230222//a.txt");
    	System.out.println(recoveryFile.canRead());
    	FileInputStream fr = new FileInputStream(recoveryFile);
		InputStreamReader ir = new InputStreamReader(fr, "eucKR");
		BufferedReader br = new BufferedReader(ir);
		String strLine;
		int mBefLinCallCnt = 0;
		int mBefRpsCallCnt = 0;
		int mBefGvupCallCnt = 0;
		int bBefLinCallCnt = 0;
		int bBefRpsCallCnt = 0;
		int bBefGvupCallCnt = 0;
		while ((strLine = br.readLine()) != null) {
			
			logger.debug(strLine);
			
			strLine = strLine.substring(strLine.lastIndexOf("-")+1).replaceAll("\\(", "").replaceAll("\\)", "").trim();
			
			String [] parts = strLine.split(",");
			Map<String,String> map = new HashMap<String, String>(); 
			System.out.println(parts[0]);
			for(String part: parts)
			{
				String[] keyValue = part.split("=");
				map.put(keyValue[0], keyValue[1]);
				
						
						
			}
			String kind =  (String) map.get("KIND");
			
			System.out.println(map.get("INCALLS"));
			int curLinCalllCnt = Integer.parseInt(map.get("INCALLS"));
			int curRpsCallCnt = Integer.parseInt(map.get("ACDCALLS"));
			int curGvupCallCnt = Integer.parseInt(map.get("ABNCALLS"));
			int curWaitCallCnt = Integer.parseInt(map.get("WAITCALLS"));
			
			int chgLinCallCnt = curLinCalllCnt - mBefLinCallCnt;		// 인입호
			int chaRpsCallCnt = curRpsCallCnt - mBefRpsCallCnt;		// 응대호
			int chaGvupCallCnt = curGvupCallCnt - mBefGvupCallCnt;	// 포기호
			int chaWaitCallCnt = curWaitCallCnt;					// 대기호
			
			String mntrDtm =(String) map.get("MNTR_DTM");
			String gubun =(String) map.get("GUBUN");
			
			if("M".equals(kind))
			{
				chgLinCallCnt = curLinCalllCnt - mBefLinCallCnt;		// 인입호
				chaRpsCallCnt = curRpsCallCnt - mBefRpsCallCnt;		// 응대호
				chaGvupCallCnt = curGvupCallCnt - mBefGvupCallCnt;	// 포기호
				chaWaitCallCnt = curWaitCallCnt;					// 대기호
				
				mBefLinCallCnt = curLinCalllCnt;
				mBefRpsCallCnt = curRpsCallCnt;
				mBefGvupCallCnt = curGvupCallCnt;
			}else if("B".equals(kind))
			{
				chgLinCallCnt = curLinCalllCnt - bBefLinCallCnt;		// 인입호
				chaRpsCallCnt = curRpsCallCnt - bBefRpsCallCnt;		// 응대호
				chaGvupCallCnt = curGvupCallCnt - bBefGvupCallCnt;	// 포기호
				chaWaitCallCnt = curWaitCallCnt;					// 대기호
				
				bBefLinCallCnt = curLinCalllCnt;
				bBefRpsCallCnt = curRpsCallCnt;
				bBefGvupCallCnt = curGvupCallCnt;
								
			}
			
			HashMap<String, String> hmap2 = new HashMap<String, String>();
			hmap2.put("mntrDtm", mntrDtm);
			hmap2.put("gubun", gubun);
			hmap2.put("linCallCnt", ""+chgLinCallCnt);
			hmap2.put("rpsCallCnt", ""+chaRpsCallCnt);
			hmap2.put("gvupCallCnt", ""+chaGvupCallCnt);
			hmap2.put("waitCallCnt", ""+chaWaitCallCnt);
			
			String strWfmsLinCallQ3 = "";
			String strWfmsLinCallQ4 = "";
			
			if(kind.equals("M")){
				strWfmsLinCallQ3 = "WfmsLinCall.insertOMN50305_B";
				strWfmsLinCallQ4 = "WfmsLinCall.insertOMN50305_T";
			}else{				
				strWfmsLinCallQ3 = "WfmsLinCall.insertOMN50307_B";
				strWfmsLinCallQ4 = "WfmsLinCall.insertOMN50307_T";
			}
			adamsSession.insert(strWfmsLinCallQ3, hmap2);
			adamsSession.insert(strWfmsLinCallQ4, hmap2);
			
			adamsSession.commit();
			
			
			
		}
		
    }
    
    
}
