package com.skb.mi.realtime;

import java.io.File;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Calendar;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Hashtable;
import java.util.Iterator;

import org.apache.commons.cli.HelpFormatter;
import org.java_websocket.WebSocket;
import org.java_websocket.WebSocketImpl;
import org.java_websocket.framing.Framedata;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.DBController;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.OutputLog;
import com.skb.mi.thread.BTVThread;
import com.skb.mi.thread.BtvCheckSendThread;

public class BtvWebSocketServerSystem extends WebSocketServer {
	final static byte		IDENTIFIER = 0x1f;
	
	Hashtable<String,BtvCheckSendThread> hashtable;

	DBController			dbController;
	String					dbUrl, userName, password;

	OutputLog				outputLog;

	String []				equipFault;
	String []				circuitFault;
	String []				trafficFault;

	public BtvWebSocketServerSystem(int port, String [] args) {
		super(new InetSocketAddress(port));
//		absolutePath = args [0];
		outputLog = new OutputLog (true, this.getClass().getName (), EnvManager.env.getLogs());
        outputLog.write ("[Ver 2020.12.09] Start : " + getDateSecond ());

		hashtable = new Hashtable<String,BtvCheckSendThread> ();
		try {
			String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
			ConfigManager configManager = new ConfigManager(cfgFile);
			dbUrl = configManager.getConfig(Constants.ADAMS_DB, Constants.DB_URL);
			userName = configManager.getConfig(Constants.ADAMS_DB, Constants.USER_NAME);
			password = configManager.getConfig(Constants.ADAMS_DB, Constants.PASSWORD);
			
			outputLog.write("dbUrl : " + dbUrl);
			outputLog.write("userName : " + userName);
			outputLog.write("password : " + password);

			dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
		} catch (Exception e) {
			outputLog.write (e);
		}
	}

	public void closeDB () {
		dbController.closeDB ();
	}	

	public DBController getDbController () { 
		return dbController; 
	}

	public static void main(String[] args) {

    	EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("BtvWebSocketServerSystem", envManager.getOptions());
    		System.exit(0);
    	}
    	
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		int webClientPortNo = Integer.parseInt(configManager.getConfig(Constants.BTV_WEB_PUSH, Constants.WEB_CLIENT_LISTEN_PORT_NO));
		int realtimePortNo = Integer.parseInt(configManager.getConfig(Constants.BTV_WEB_PUSH, Constants.PORT_NO));


		WebSocketImpl.DEBUG = false;
		JSONObject	temp;

		OutputLog		outputLog;
        outputLog = new OutputLog (true, "com.skb.mi.realtime.BtvWebSocketServerSystem", EnvManager.env.getLogs());
        outputLog.write ("Start ! ");

		ServerSocket	serverSocket = null;
		BtvWebSocketServerSystem s = null;
		try {
			s = new BtvWebSocketServerSystem(webClientPortNo, args);
			s.start();
		} catch (Exception e) {
			outputLog.write ("WebSocket Exception : " + e);
		}

		int index = 0;
		String	message = "";
		temp = null;
		try {
			serverSocket = new ServerSocket (realtimePortNo);
		} catch (Exception e) {
			try {
				s.stop ();
			} catch (Exception e1) {
			}
			outputLog.write (realtimePortNo+"");
			outputLog.write ("Realtime Port Exception : " + e);
			outputLog.close ();
			s.closeDB ();
			System.exit (0);
		}

		while ( true ) {
			try {
				Socket socket = serverSocket.accept ();
				outputLog.write ("-----> IP Address : " + socket.getInetAddress ());

				BTVThread btvThread = new BTVThread (socket, s, configManager);
				btvThread.start ();
			} catch (Exception e) {
				outputLog.write(e);
			}
		}
//		dbController.closeDB ();
	}

	@Override
	public void onOpen( WebSocket conn, ClientHandshake handshake ) {
		outputLog.write("onOpen()");
		String ipAddress = null;
		try {
			ipAddress = conn.getRemoteSocketAddress().getAddress().getHostAddress();
		} catch (Exception e) {
			outputLog.write(e);
		}
		outputLog.write (ipAddress  + " entered the room!" );
		Collection<WebSocket> con = connections ();
		outputLog.write ("Client 수 : "  + con.size ());
	}

	@Override
	public void onMessage(WebSocket conn, String message) {
		try {
			JSONParser 	jsonParser = new JSONParser();
			JSONObject jsonObject = (JSONObject) jsonParser.parse (message);
			String	kind = jsonObject.get ("kind").toString ();
			if (kind.equals("ID")) {
				String id = jsonObject.get ("ID").toString ();
				if (id != null && (!id.equals ("null"))) {
					// Client에 CheckSendThread Thread 할당
					String rcv = null;
					try {
						rcv = jsonObject.get ("recvMessage").toString ();
					} catch (Exception e) {
						rcv = "ALL";
					}
					BtvCheckSendThread btvCheckSend = new BtvCheckSendThread (conn, id, rcv, DBController.ORACLE_DB, dbUrl, userName, password);
					hashtable.put (conn.toString (), btvCheckSend);
					outputLog.write ("----- ID : " + (String) jsonObject.get("ID") + ", Kind : " + jsonObject.get("kind").toString () + ", RCV : " + rcv + ", hashtable.size () : " + hashtable.size());
					btvCheckSend.start ();
				} else {
					outputLog.write ("id is null...");
				}
			}
			
			this.sendToAll(jsonObject);
			outputLog.write ( conn + ": " + message );
		} catch (Exception e) {
			outputLog.write ("onMessage : " + message, e);
		}
	}

	@Override
	public void onFragment( WebSocket conn, Framedata fragment ) {
		outputLog.write ( "received fragment: " + fragment );
	}

	@Override
	public void onClose( WebSocket conn, int code, String reason, boolean remote ) {
		String hostAddress = null;
		try {
			hostAddress = conn.getRemoteSocketAddress().getAddress().getHostAddress();
		} catch (Exception e) {
			outputLog.write(e);
		}
		outputLog.write(String.format("%s has left (%d:%s)", hostAddress, code, reason));
		
		// CheckSendThread Thread 종료 처리
		if (conn != null) {
			String connStr = conn.toString();
			BtvCheckSendThread btvCheckSend = hashtable.get(connStr);
			if (btvCheckSend != null) {
				hashtable.remove (connStr);
				btvCheckSend.interrupt ();
				outputLog.write (hostAddress + ":BtvCheckSendThread : " + connStr + " exit");
			}
		}
		Collection<WebSocket> con = connections ();
		outputLog.write ("Client 수 : "  + con.size ());
	}
	
	@Override
	public void onError( WebSocket conn, Exception ex ) {
		outputLog.write(ex);
		if( conn != null ) {
			outputLog.write ("onError", ex);
			// CheckSendThread Thread 종료 처리
			BtvCheckSendThread btvCheckSend = hashtable.get (conn.toString ());
			if (btvCheckSend != null) {
				hashtable.remove (conn.toString ());
				btvCheckSend.setThreadExit (true);
			}
			Collection<WebSocket> con = connections ();
			outputLog.write ("Client 수 : "  + con.size ());
		}
	}

	@Override
	public void onStart() {
		outputLog.write ("Server started!");
	}

	/**
	 * Sends <var>text</var> to all currently connected WebSocket clients.
	 * 
	 * @param text
	 *            The String to send across the network.
	 * @throws InterruptedException
	 *             When socket related I/O errors occur.
	 */
	public void sendToAll( WebSocket source, String text ) {
		Collection<WebSocket> con = connections();
		synchronized ( con ) {
			for(WebSocket c : con) {
				if (c != source)
					c.send( text );
			}
		}
	}

	public void sendToAll(JSONObject jsonObject) {
		Collection<WebSocket> con = connections();
		WebSocket w =  null;
		
			BtvCheckSendThread	btvCheckSend;	
			try{
				
				Iterator<WebSocket> ci =  con.iterator();
				while(ci.hasNext())
				{
					w = ci.next();
					btvCheckSend = hashtable.get (w.toString ());
					
					if (btvCheckSend != null) {
							
						btvCheckSend.addQueue(jsonObject);
					}
				}				
				
			}catch (ConcurrentModificationException cme){
				outputLog.write ("ConcurrentModificationException "  );
			}
			
	}
	
	public void sendToAll(String text, JSONObject jsonObject) {
		Collection<WebSocket> con = connections();
		
			BtvCheckSendThread	btvCheckSend;	
			for( WebSocket c : con ) {
				btvCheckSend = hashtable.get (c.toString ());
				outputLog.write (c.toString ());
				if (btvCheckSend != null) {
					outputLog.write ("addQueue");
					btvCheckSend.addQueue(jsonObject);
				}
			}
	}
	
	public void printHexa (String message) {
		byte[]	hexa = message.getBytes();
		for (int index = 0; index < hexa.length; ++ index) {
			System.out.printf("%02x.", hexa [index]);
		}
	}

	public String getDateSecond () {
		Calendar	calendar = Calendar.getInstance ();

		return String.format ("%04d-%02d-%02d %02d:%02d:%02d",
			calendar.get(Calendar.YEAR),
			calendar.get(Calendar.MONTH) + 1,
			calendar.get(Calendar.DAY_OF_MONTH),
			calendar.get(Calendar.HOUR_OF_DAY),
			calendar.get(Calendar.MINUTE),
			calendar.get(Calendar.SECOND));
	}


	public String [] getEquipFault () {
		return equipFault;
	}

	public String [] getCircuitFault () {
		return circuitFault;
	}

	public String [] getTrafficFault () {
		return trafficFault;
	}

	public synchronized void executeUpdate (String query) throws Exception {
		dbController.getStmt ().executeUpdate (query);
	}
	
	public void writeLog(String msg) {
		outputLog.write(msg);
	}
}

