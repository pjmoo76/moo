package	com.skb.mi.realtime;

import	java.io.FileReader;
import	java.io.BufferedReader;
import	java.io.File;
import	java.io.InputStream;
import	java.io.OutputStream;
import	java.net.InetAddress;
import	java.net.Socket;
import	java.net.ServerSocket;
import	java.sql.ResultSet;
import	java.util.Calendar;
import	java.util.LinkedList;
import	java.util.StringTokenizer;

import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.EnvManager;

public class	UnmsClient {
	static final public String C_TARGET_IP_ADDR	= "TARGET_IP_ADDR";
	// Push Processor 정보
	String						ipAddress = "12.4.108.53";
	int							portNo = 61092;

	Socket						pushSocket;
	InputStream					inputStream;
	OutputStream				outputStream;

	String						absolutePath;
	byte[]						buffer;

	public UnmsClient (String [] args) {
		int				count;
		buffer = new byte [10240];
		
		String targetIpAddr = EnvManager.env.getOptionValue(C_TARGET_IP_ADDR);

		// PING/Telnet에서 사용
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		String ipAddress = configManager.getConfig(Constants.UNMS_RELAY, Constants.IP_ADDRESS);
		int portNo = Integer.parseInt(configManager.getConfig(Constants.UNMS_RELAY, Constants.PORT_NO));

		System.out.println ("ipAddress : " + ipAddress);
		System.out.println ("PortNo : " + portNo);
		try {
			pushSocket = new Socket (ipAddress, portNo);
			outputStream = pushSocket.getOutputStream ();
			inputStream = pushSocket.getInputStream ();
		} catch (Exception e) {
			e.printStackTrace();
		}

		sendPingRequest (targetIpAddr, 10);
	}

	public void sendPingRequest (String ipAddress, int count) {
		String	sendMessage = "PNG" + "|" + "ADAMS" + "|" + ipAddress + "|" + String.valueOf (count);
		StringTokenizer			tokens;
		try {
			String	result, lastYn, message, resultMessage;
			outputStream.write (sendMessage.getBytes());
			while (true) {
				int length = inputStream.read (buffer);
				if (length == -1)
					break;
				resultMessage = new String (buffer);
				System.out.println ("수신된 데이터 : " + resultMessage);
				tokens = new StringTokenizer (resultMessage, "|");
	
				result = tokens.nextToken ();
				lastYn = tokens.nextToken ();
				resultMessage = tokens.nextToken ();
				System.out.println ("Result : " + result);
				System.out.println ("LastYn : " + lastYn);
				System.out.println ("Message : " + resultMessage);
				if (lastYn.equals ("Y"))
					break;
				printHexaCode (length, buffer);
			}
			inputStream.close ();
			outputStream.close ();
			pushSocket.close ();
		} catch (Exception e) {
			System.out.println ("sendPingRequest : " + e);
		}
	}

    public void printHexaCode (int length, byte[] buffer) {
        int count = 0;
		System.out.println ();
		System.out.println (new String (buffer));
		System.out.println ();
        for (int index = 0; index < length; ++ index) {
            if (count++ % 20 == 0)
                System.out.println ();
            System.out.printf ("%02x.", buffer [index]);
        }
        System.out.println ();
    }

    public String getDateSecond () {
        Calendar    calendar = Calendar.getInstance ();

        return String.format ("%04d-%02d-%02d %02d:%02d:%02d",
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH) + 1,
            calendar.get(Calendar.DAY_OF_MONTH),
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            calendar.get(Calendar.SECOND));
    }

	public void sleep (int waitingTime) {
		try {
			Thread.sleep (waitingTime);
		} catch (Exception e) {
		}
	}	

	public static void main (String args []) throws Exception {
		Options options = new Options();
		Option targetIpAddr = Option.builder().longOpt(C_TARGET_IP_ADDR)
				.desc("TARGET IP ADDRESS").hasArg().argName(C_TARGET_IP_ADDR).build();
		options.addOption(targetIpAddr);

		EnvManager envManager = new EnvManager(args, options);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("UnmsClient", envManager.getOptions());
    		System.exit(0);
    	}

		new UnmsClient (args);
	}
}
