package com.skb.mi.realtime;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.File;
import java.io.FileReader;
import java.net.URL;
import java.sql.PreparedStatement;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Calendar;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.skb.mi.common.DBController;

public class CollectERC {
	JSONObject	jsonObject;
	JSONParser	jsonParser = new JSONParser ();

	DBController	dbController;
	String			dbUrl, userName, password;

	String			absolutePath;
	
//	PreparedStatement	preparedStatement;
	
	public CollectERC (String [] args) {
		absolutePath = args [0];
		collectErc ();
	}
	
	public void collectErc () {
//		String				sUrl = "http://150.2.181.64:8181/explorer/searchQuery";
		String				codeUrl = "https://169.56.66.149/dpump/strdterm/_codelist/58f9a4408f04cf1c2bbb0b10/58f9b33e8f04cf1c2bbb212d";
		String				listUrl = "https://169.56.66.149/dpump/strdterm/_list/58f9a4408f04cf1c2bbb0b10/58f9b33e8f04cf1c2bbb212d";
//		String				codeUrl = "https://www.nexcore-erc.com/dpump/strdterm/_codelist/58f9a4408f04cf1c2bbb0b10/58f9b33e8f04cf1c2bbb212d";
//		String				listUrl = "https://www.nexcore-erc.com/dpump/strdterm/_list/58f9a4408f04cf1c2bbb0b10/58f9b33e8f04cf1c2bbb212d";
        System.out.println ("프로그램 시작 : " + getDateSecond ());		
		try {
			readDbInfo ();
			dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
		} catch (Exception e) {
			System.out.println ("DB연결 Exception : " + e);
			System.exit (1);
		}
		selectCommonList (listUrl);
		selectCommonCode (codeUrl);
		dbController.closeDB ();
        System.out.println ("프로그램 끝 : " + getDateSecond ());		
	}

    public void readDbInfo () throws Exception {
        String  oneLine;
        FileReader  fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + "db.info");
        BufferedReader bufferedReader = new BufferedReader (fileReader);
        dbUrl = bufferedReader.readLine ();
        userName = bufferedReader.readLine ();
        password = bufferedReader.readLine ();
        bufferedReader.close ();
        fileReader.close ();
    }

	public void selectCommonCode (String urlString) {
		URL 				url = null;
		BufferedReader		bufferedReader = null;
		StringTokenizer		tokens;
		HostnameVerifier hv = new HostnameVerifier () {
			public boolean verify (String urlHostName, SSLSession session) {
				System.out.println ("Warning : URL Host : " + urlHostName + " vs. " + session.getPeerPort ());
				return true;
			};
		};
		
		try {
			trustAllHttpsCertificates ();
			HttpsURLConnection.setDefaultHostnameVerifier(hv);
			
			url = new URL (urlString);

			bufferedReader = new BufferedReader (new InputStreamReader (url.openStream(), "UTF-8"));
			String jsonString = "";
			JSONObject	jsonObject;
			JSONParser	jsonParser = new JSONParser ();
//			while ((oneLine = bufferedReader.readLine ()) != null) {
			int	count, total = 0;
			char [] buffer = new char [4096];
			while (true) {
				count = bufferedReader.read(buffer);
				if (count == -1)
					break;
				jsonString += new String (buffer, 0, count);
				total += count;
//				System.out.println("count : " + count + ", total : " + total);
			}
//			System.out.println("jsonString : " + jsonString);
//			System.out.println("jsonString'length : " + jsonString.length ());

			jsonObject = (JSONObject) jsonParser.parse (jsonString);
			Set<String> keys = jsonObject.keySet();
			System.out.println("keys'size : " + keys.size());
			JSONObject	one = new JSONObject ();
			JSONArray jsonArray = new JSONArray ();
			String		codeId, query;
			count = 0;
			for (String key : keys) {
				++ count;
//				System.out.println("key : " + key);
				one = (JSONObject) jsonObject.get((Object) key);
				codeId = one.get("physical_term_name").toString ();
				query = updateOCO20100 (codeId, one);
//				System.out.println("UPDATE_OCO20100 : " + query);
				try {
					dbController.getStmt ().executeUpdate (query);
				} catch (Exception e) {
					System.out.println ("---------------------------------");
					System.out.println ("query : " + query);
					System.out.println ("UPDATE_OCO20100 Exception : " + e);
					System.out.println ();
				}
				try {
					jsonArray = (JSONArray) one.get("code_instances");
				} catch (Exception e) {
					System.out.println ("---------------------------------");
					System.out.println ("query : " + query);
					System.out.println ("jsonArray Exception : " + e);
					System.out.println ();
				}
//				System.out.println("code_instances'length : " + jsonArray.size());
				for (int i = 0; i < jsonArray.size(); ++ i) {
					JSONObject sub = (JSONObject) jsonArray.get(i);
					query = mergeOCO20101 (codeId, sub);
//					System.out.println(sub.toJSONString());
					try {
						dbController.getStmt ().executeUpdate (query);
					} catch (Exception e) {
						System.out.println ("---------------------------------");
						System.out.println ("query : " + query);
						System.out.println ("MERGE_OCO20101 Exception : " + e);
						System.out.println ();
					}
				}
			}
			
			bufferedReader.close ();
			System.out.println("Code 수 : " + count);
			
//			countJSON1(jsonString);
		} catch (Exception e) {
			System.out.println ("collectErc : " + e);
		}
	}

	public void countJSON (String jsonString) {
		char	ch = 0x00;
		int		count = 0;
		String	oneJson = "";
//		System.out.println("jsonString'length : " + jsonString.length ());
		for (int i = 1; i < jsonString.length(); ++ i) {
			ch = jsonString.charAt(i);
			if (ch == '}') {
				int index = oneJson.indexOf("{");
				if (0 < index) {
					oneJson = oneJson.substring(oneJson.indexOf("{"));
					try {
						jsonObject = (JSONObject) jsonParser.parse (oneJson + "}");
					} catch (Exception e) {
						System.out.println("JSONParse Error : " + oneJson);
						System.out.println(e);
					}
					
//					System.out.println(oneJson + "}");
					++ count;
					oneJson = "";
				}
			} else if (ch != ' ')
				oneJson += ch;
		}
		System.out.println("Code 수 : " + count);
	}

	public void countJSON1 (String jsonString) {
		char	ch = 0x00;
		int		count = 0;
		String	oneJson = "";
		jsonString = jsonString.substring(1);
//		System.out.println("jsonString'length : " + jsonString.length ());
		for (int i = 0; i < jsonString.length();) {
			i = jsonString.indexOf("]}");
			if (0 <= i) {
				oneJson = jsonString.substring(0, i) + "]}";
				oneJson = oneJson.substring(oneJson.indexOf("{"));
				jsonString = jsonString.substring(i + 2);
				try {
					jsonObject = (JSONObject) jsonParser.parse (oneJson);
//					System.out.println(jsonObject.toJSONString());
				} catch (Exception e) {
					System.out.println("JSONParse Error : " + oneJson);
					System.out.println(e);
				}
//				System.out.println(oneJson);
				++ count;
			} else
				break;
		}
		System.out.println("Code 수 : " + count);
	}

	public String mergeList (JSONObject jsonObject) {
		return "MERGE INTO OCO20100 USING DUAL"
			+  " ON (COMM_CD='" + jsonObject.get ("physical_term_name").toString () + "')"
			+  " WHEN MATCHED THEN"
			+  "     UPDATE SET"
			+  "        AUDIT_ID = 'admin'"
			+  "        , AUDIT_DTM = SYSDATE"
			+  "        , CD_LENG = " + jsonObject.get ("_data_type")
			+  "        , COMM_CD_NM = '" + jsonObject.get("term_name").toString () + "'"
			+  " WHEN NOT MATCHED THEN"
			+  "     INSERT ("
			+  "        AUDIT_ID"
			+  "        , AUDIT_DTM"
			+  "        , USE_YN"
			+  "        , SORT_SEQ"
			+  "        , CD_LENG"
			+  "        , COMM_CD"
			+  "        , COMM_CD_NM"
			+  "     ) VALUES ("
			+  "        'admin'"
			+  "        , SYSDATE"
			+  "        , 'Y'"
			+  "        , 1"
			+  "        , " + jsonObject.get("_data_type")
			+  "        , '" + jsonObject.get("physical_term_name") + "'"
			+  "        , '" + jsonObject.get("term_name") + "'"
			+  "     )";
	}
	
	public String updateOCO20100 (String codeId, JSONObject jsonObject) {
		return "UPDATE OCO20100 SET"
			+  " AUDIT_ID='admin'"
			+  " , AUDIT_DTM=SYSDATE"
			+  " , COMM_CD_DESC = '" + jsonObject.get("term_definition").toString() + "'"
			+  " , EFF_STA_DTM = '" + jsonObject.get("code_from").toString () + "'"
			+  " , EFF_END_DTM = '" + jsonObject.get("code_to").toString () + "'"
			+  " , USE_YN = CASE WHEN TO_CHAR(SYSDATE, 'YYYYMMDD') BETWEEN '" + jsonObject.get("code_from").toString () 
			+  " '   AND '" + jsonObject.get("code_to").toString () + "'"
			+  "   THEN 'Y' ELSE 'N' END"
			+  " WHERE COMM_CD='" + codeId + "'";
	}
	
	public String mergeOCO20101 (String codeId, JSONObject jsonObject) {
		return "MERGE INTO OCO20101 USING DUAL"
			+  " ON(COMM_CD='" + codeId + "' AND COMM_CD_VAL='" + jsonObject.get("inst_value").toString() + "')"
			+  " WHEN MATCHED THEN "
			+  "   UPDATE SET "
			+  "   AUDIT_ID='admin'"
			+  "   , AUDIT_DTM=SYSDATE"
			+  "   , COMM_CD_VAL_NM='" + jsonObject.get("inst_definition").toString () + "'"
			+  "   , COMM_CD_VAL_DESC='" + jsonObject.get("inst_description").toString () + "'"
			+  "   , SORT_SEQ=" + jsonObject.get("inst_seq").toString ()
			+  "   , EFF_STA_DTM='" + jsonObject.get("inst_from").toString () + "'"
			+  "   , EFF_END_DTM='" + jsonObject.get("inst_to").toString () + "'"
			+  " WHEN NOT MATCHED THEN"
			+  "   INSERT ("
			+  "     AUDIT_ID"
			+  "   , AUDIT_DTM"
			+  "   , COMM_CD"
			+  "   , COMM_CD_VAL"
			+  "   , COMM_CD_VAL_NM"
			+  "   , COMM_CD_VAL_DESC"
			+  "   , SORT_SEQ"
			+  "   , EFF_STA_DTM"
			+  "   , EFF_END_DTM"
			+  "   ) VALUES ("
			+  "   'admin'"
			+  "   , SYSDATE"
			+  "   , '" + codeId + "'"
			+  "   , '" + jsonObject.get("inst_value").toString() + "'"
			+  "   , '" + jsonObject.get("inst_definition").toString() + "'"
			+  "   , '" + jsonObject.get("inst_description").toString() + "'"
			+  "   , '" + jsonObject.get("inst_seq").toString() + "'"
			+  "   , '" + jsonObject.get("inst_from").toString() + "'"
			+  "   , '" + jsonObject.get("inst_to").toString() + "'"
			+  "   )";
	}
	
	public void selectCommonList (String urlString) {
		String				query;
		URL 				url = null;
		BufferedReader		bufferedReader = null;
		JSONObject			one = new JSONObject ();
		HostnameVerifier hv = new HostnameVerifier () {
				public boolean verify (String urlHostName, SSLSession session) {
					System.out.println ("Warning : URL Host : " + urlHostName + " vs. " + session.getPeerPort ());
					return true;
				};
		};
		
		try {
			trustAllHttpsCertificates ();
			HttpsURLConnection.setDefaultHostnameVerifier(hv);
			
			url = new URL (urlString);

			bufferedReader = new BufferedReader (new InputStreamReader (url.openStream(), "UTF-8"));
			String jsonString = "";
			JSONObject	jsonObject;
			JSONParser	jsonParser = new JSONParser ();
//			while ((oneLine = bufferedReader.readLine ()) != null) {
			int	count, total = 0;
			char [] buffer = new char [4096];
			while (true) {
				count = bufferedReader.read(buffer);
				if (count == -1)
					break;
				jsonString += new String (buffer, 0, count);
				total += count;
//				System.out.println("count : " + count + ", total : " + total);
			}
//			System.out.println("jsonString : " + jsonString);
			
			System.out.println("jsonString'length : " + jsonString.length ());
			jsonObject = (JSONObject) jsonParser.parse (jsonString);
			jsonObject.containsValue(jsonObject);
			Set<String> keys = jsonObject.keySet();
			one = new JSONObject ();
			count = 0;
			for (String key : keys) {
//				System.out.println("key : " + key);
				one = (JSONObject) jsonObject.get((Object) key);
//				System.out.println ("-------- _data_type : " + one.get("_data_type").toString ()); 
				if (one.get("_data_type") == null)
					one.put("_data_type", "0");
				else if (one.get("_data_type").toString ().indexOf("(") < 0)
					one.put("_data_type", "12");
				else
					one.put("_data_type", getNumber (one.get("_data_type").toString ()));
//				System.out.println (">>>>>>>> _data_type : " + one.get("_data_type").toString ()); 
				query = mergeList (one);
//				System.out.println(query);
				++ count;
				try {
					dbController.getStmt ().executeUpdate (query);
				} catch (Exception e) {
					System.out.println ("---------------------------------");
					System.out.println ("query : " + query);
					System.out.println ("mergeList Exception : " + e);
					System.out.println ();
				}
			}
			System.out.println("List 수 : " + count);
			bufferedReader.close ();
			
//			countJSON(jsonString);
		} catch (Exception e) {
			System.out.println("JSON ----> " + one.toString ());
			System.out.println ("collectErc : " + e);
		}
	}
	
	public String getNumber (String str) {
		StringTokenizer	tokens = new StringTokenizer (str, "(,");
		String			number = "";
		tokens.nextToken ();
		number = tokens.nextToken ();
		if (number.charAt (number.length () - 1) == ')')
			number = number.substring(0, number.length () - 1);
		return number;
	}
	
	public void trustAllHttpsCertificates () throws Exception {
		javax.net.ssl.TrustManager [] trustAllCerts = new javax.net.ssl.TrustManager [1];
		
		javax.net.ssl.TrustManager tm = new miTM();
		trustAllCerts [0] = tm;
		
		javax.net.ssl.SSLContext sc = javax.net.ssl.SSLContext.getInstance("SSL");
		sc.init(null, trustAllCerts, null);
		javax.net.ssl.HttpsURLConnection.setDefaultSSLSocketFactory (sc.getSocketFactory());
	}
	
	public class miTM implements javax.net.ssl.TrustManager, javax.net.ssl.X509TrustManager {
		public java.security.cert.X509Certificate [] getAcceptedIssuers () {
			return null;
		}
		
		public boolean isServerTrusted (java.security.cert.X509Certificate [] certs) {
			return true;
		}
		public boolean isClientTrusted (java.security.cert.X509Certificate [] certs) {
			return true;
		}
		public void checkServerTrusted (java.security.cert.X509Certificate [] certs, String authType) throws java.security.cert.CertificateException {
			return;
		}
		public void checkClientTrusted (java.security.cert.X509Certificate [] certs, String authType) throws java.security.cert.CertificateException {
			return;
		}
	}
	
    public String getDateSecond () {
        Calendar    calendar = Calendar.getInstance ();

        return String.format ("%04d-%02d-%02d %02d:%02d:%02d",
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH) + 1,
            calendar.get(Calendar.DAY_OF_MONTH),
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            calendar.get(Calendar.SECOND));
    }

	public static void main(String[] args) {
		if (args.length != 1) {
			System.out.println ("Usage : java CollectERC 절대패스");
			System.exit (1);
		}
		new CollectERC (args);
	}

}
