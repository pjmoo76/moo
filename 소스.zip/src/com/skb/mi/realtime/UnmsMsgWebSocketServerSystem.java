package com.skb.mi.realtime;

import java.io.File;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Hashtable;
import java.util.Iterator;

import org.apache.commons.cli.HelpFormatter;
import org.java_websocket.WebSocket;
import org.java_websocket.WebSocketImpl;
import org.java_websocket.framing.Framedata;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.DBController;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.OutputLog;
import com.skb.mi.thread.UnmsMsgCheckSendThread;
import com.skb.mi.thread.UnmsMsgThread;

public class UnmsMsgWebSocketServerSystem extends WebSocketServer {
//	final static int		REALTIME_PORT = 59768;
//	final static int		REALTIME_PORT = 32771;
	final static byte		IDENTIFIER = 0x1f;
//	final static String		IDENTIFIER = "||";
	final static String		GENERATE_EVENT = "GEN";
	final static String		CLEAR_EVENT = "CLR";
	final static String		CONFIRM_EVENT = "CNF";
	final static String		MANUAL_CLEAR_EVENT = "MNC";
	
	Hashtable<String,UnmsMsgCheckSendThread> hashtable;

	DBController			dbController;
	String					dbUrl, userName, password;

	OutputLog				outputLog;

//	String					absolutePath;

	String []				equipFault;
	String []				circuitFault;
	String []				trafficFault;

	public UnmsMsgWebSocketServerSystem(int port, String [] args) {
		super(new InetSocketAddress(port));
//		absolutePath = args [0];
		outputLog = new OutputLog (true, this.getClass().getName (), EnvManager.env.getLogs());
        outputLog.write ("[Ver 2021.06.18] Start : " + getDateSecond ());

		hashtable = new Hashtable<String,UnmsMsgCheckSendThread> ();
		try {
			String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
			ConfigManager configManager = new ConfigManager(cfgFile);
			dbUrl = configManager.getConfig(Constants.ADAMS_DB, Constants.DB_URL);
			userName = configManager.getConfig(Constants.ADAMS_DB, Constants.USER_NAME);
			password = configManager.getConfig(Constants.ADAMS_DB, Constants.PASSWORD);
			
			outputLog.write("dbUrl : " + dbUrl);
			outputLog.write("userName : " + userName);
			outputLog.write("password : " + password);

			dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
		} catch (Exception e) {
			outputLog.write (e);
		}
	}

	public void closeDB () {
		dbController.closeDB ();
	}	

	public DBController getDbController () { 
		return dbController; 
	}

	public static void main(String[] args) {

    	EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("UnmsMsgWebSocketServerSystem", envManager.getOptions());
    		System.exit(0);
    	}
    	
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		int webClientPortNo = Integer.parseInt(configManager.getConfig(Constants.UNMS_MSG_WEB_PUSH, Constants.WEB_CLIENT_LISTEN_PORT_NO));
		int realtimePortNo = Integer.parseInt(configManager.getConfig(Constants.UNMS_MSG_WEB_PUSH, Constants.PORT_NO));


		WebSocketImpl.DEBUG = false;
		JSONObject	temp;
		//int port = 59768; 					// 843 flash policy port

//		System.out.println ("port : " + webClientPortNo + ", args [0] = " + args [0]);
//		if (args.length != 1) {
//			System.out.println ("Usage : UnmsMsgWebSocketServerSystem directory");
//			System.exit (0);
//		}
		OutputLog		outputLog;
        outputLog = new OutputLog (true, "com.skb.mi.realtime.UnmsMsgWebMain", EnvManager.env.getLogs());
        outputLog.write ("Start ! ");

		ServerSocket	serverSocket = null;
		UnmsMsgWebSocketServerSystem s = null;
		try {
			s = new UnmsMsgWebSocketServerSystem(webClientPortNo, args);
			s.start();
		} catch (Exception e) {
			outputLog.write ("WebSocket Exception : " + e);
		}

		int index = 0;
		String	message = "";
		temp = null;
		try {
			serverSocket = new ServerSocket (realtimePortNo);
		} catch (Exception e) {
			try {
				s.stop ();
			} catch (Exception e1) {
			}
			outputLog.write ("Realtime Port Exception : " + e);
			outputLog.close ();
			s.closeDB ();
			System.exit (0);
		}

		while ( true ) {
			try {
				Socket socket = serverSocket.accept ();
				outputLog.write ("-----> IP Address : " + socket.getInetAddress ());

				UnmsMsgThread unmsMsgThread = new UnmsMsgThread (socket, s, configManager);
				unmsMsgThread.start ();
			} catch (Exception e) {
				outputLog.write(e);
			}
		}
//		dbController.closeDB ();
	}

	@Override
	public void onOpen( WebSocket conn, ClientHandshake handshake ) {
		outputLog.write("onOpen()");
		String ipAddress = null;
		try {
			ipAddress = conn.getRemoteSocketAddress().getAddress().getHostAddress();
		} catch (Exception e) {
			outputLog.write(e);
		}
		outputLog.write (ipAddress  + " entered the room!" );
		Collection<WebSocket> con = connections ();
		outputLog.write ("Client 수 : "  + con.size ());
	}

	@Override
	public void onMessage(WebSocket conn, String message) {
		try {
			JSONParser 	jsonParser = new JSONParser();
			JSONObject jsonObject = (JSONObject) jsonParser.parse (message);
			String	kind = jsonObject.get ("kind").toString ();
			if (kind.equals("ID")) {
//				System.out.println ("JSON : " + jsonObject.toString ());
//				System.out.println ( conn.getRemoteSocketAddress().getAddress().getHostAddress() + " entered the room!" );
				String id = jsonObject.get ("ID").toString ();
				//outputLog.write ("ID : " + id);
				if (id != null && (!id.equals ("null"))) {
					// Client에 CheckSendThread Thread 할당
					String rcv = null;
					try {
						rcv = jsonObject.get ("recvMessage").toString ();
					} catch (Exception e) {
						rcv = "ALL";
					}
					UnmsMsgCheckSendThread checkSend = new UnmsMsgCheckSendThread (conn, id, rcv, DBController.ORACLE_DB, dbUrl, userName, password);
					hashtable.put (conn.toString (), checkSend);
					outputLog.write ("----- ID : " + (String) jsonObject.get("ID") + ", Kind : " + jsonObject.get("kind").toString () + ", RCV : " + rcv + ", hashtable.size () : " + hashtable.size());
					checkSend.start ();
				} else {
					outputLog.write ("id is null...");
				}
			}
			else if (kind.equals("CLR")) {
				
				executeFaultMenualCleared(jsonObject);
				outputLog.write ("----- CLR ----- " + jsonObject.get("DABL_NUM"));
				message = jsonObject.toJSONString();
			} else if (kind.equals("CNF")) {
				outputLog.write ("----- CNF ----- " + jsonObject.get("DABL_NUM"));
			}
			//this.sendToAll(message, jsonObject);
			this.sendToAll(jsonObject);
			outputLog.write ( conn + ": " + message );
		} catch (Exception e) {
			outputLog.write ("onMessage : " + message, e);
		}
	}

	@Override
	public void onFragment( WebSocket conn, Framedata fragment ) {
		outputLog.write ( "received fragment: " + fragment );
	}

	@Override
	public void onClose( WebSocket conn, int code, String reason, boolean remote ) {
//		this.sendToAll( conn + " has left the room!" );
		String hostAddress = null;
		try {
			hostAddress = conn.getRemoteSocketAddress().getAddress().getHostAddress();
		} catch (Exception e) {
			outputLog.write(e);
		}
		outputLog.write(String.format("%s has left (%d:%s)", hostAddress, code, reason));
		
		// CheckSendThread Thread 종료 처리
		if (conn != null) {
			String connStr = conn.toString();
			UnmsMsgCheckSendThread checkSend = hashtable.get(connStr);
			if (checkSend != null) {
				hashtable.remove (connStr);
//				checkSend.setThreadExit (true);
	            checkSend.interrupt ();
				outputLog.write (hostAddress + ":CheckSendThread : " + connStr + " exit");
			}
		}
		Collection<WebSocket> con = connections ();
		outputLog.write ("Client 수 : "  + con.size ());
	}
	
	public JSONObject makeClearEvent () {
		JSONObject obj = new JSONObject ();
		obj.put("kind", "CLR");
		return obj;
	}
	
	@Override
	public void onError( WebSocket conn, Exception ex ) {
		outputLog.write(ex);
		if( conn != null ) {
			outputLog.write ("onError", ex);
			// CheckSendThread Thread 종료 처리
			UnmsMsgCheckSendThread checkSend = hashtable.get (conn.toString ());
			if (checkSend != null) {
				hashtable.remove (conn.toString ());
				checkSend.setThreadExit (true);
			}
			Collection<WebSocket> con = connections ();
			outputLog.write ("Client 수 : "  + con.size ());
		}
	}

	@Override
	public void onStart() {
		outputLog.write ("Server started!");
	}

	/**
	 * Sends <var>text</var> to all currently connected WebSocket clients.
	 * 
	 * @param text
	 *            The String to send across the network.
	 * @throws InterruptedException
	 *             When socket related I/O errors occur.
	 */
	public void sendToAll( WebSocket source, String text ) {
		Collection<WebSocket> con = connections();
		synchronized ( con ) {
			for(WebSocket c : con) {
				if (c != source)
					c.send( text );
			}
		}
	}

	public void sendToAll(JSONObject jsonObject) {
		Collection<WebSocket> con = connections();
		WebSocket w =  null;
		//동기화 제거 2019-08-22
		//synchronized ( con ) {
		
			UnmsMsgCheckSendThread	checkSend;	
			try{
				
				Iterator<WebSocket> ci =  con.iterator();
				while(ci.hasNext())
				{
					w = ci.next();
					checkSend = hashtable.get (w.toString ());
					
					if (checkSend != null) {
//						System.out.println ("UI : " + jsonObject.toString ());
							
						checkSend.addQueue(jsonObject);
					}
				}				
					
					
//				c.send (jsonObject.toString ());
				
				
			}catch (ConcurrentModificationException cme){
				//con.remove(w);
				outputLog.write ("ConcurrentModificationException "  );
			}
			
		//}
	}
	
	public void sendToAll(String text, JSONObject jsonObject) {
		Collection<WebSocket> con = connections();
		//동기화 제거 2019-08-22
		//synchronized ( con ) {
		
			UnmsMsgCheckSendThread	checkSend;	
			for( WebSocket c : con ) {
//				c.send (jsonObject.toString ());
				checkSend = hashtable.get (c.toString ());
				outputLog.write (c.toString ());
				if (checkSend != null) {
//					System.out.println ("UI : " + jsonObject.toString ());
					outputLog.write ("addQueue");
					checkSend.addQueue(jsonObject);
				}
			}
		//}
	}
	
	public void printHexa (String message) {
		byte[]	hexa = message.getBytes();
		for (int index = 0; index < hexa.length; ++ index) {
			System.out.printf("%02x.", hexa [index]);
		}
	}

	public String getDateSecond () {
		Calendar	calendar = Calendar.getInstance ();

		return String.format ("%04d-%02d-%02d %02d:%02d:%02d",
			calendar.get(Calendar.YEAR),
			calendar.get(Calendar.MONTH) + 1,
			calendar.get(Calendar.DAY_OF_MONTH),
			calendar.get(Calendar.HOUR_OF_DAY),
			calendar.get(Calendar.MINUTE),
			calendar.get(Calendar.SECOND));
	}

    // ADAMS DB정보 조회
//    public void readDbInfo () throws Exception {
//        FileReader  fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + "db.info");
//        BufferedReader bufferedReader = new BufferedReader (fileReader);
//        dbUrl = bufferedReader.readLine ();
//        userName = bufferedReader.readLine ();
//        password = bufferedReader.readLine ();
//        bufferedReader.close ();
//        fileReader.close ();
//    }

	// Equip Fault 정보 조회
/*
    public void readEquipFault () throws Exception {
        FileReader  fileReader = new FileReader (ABSOLUTE_PATH + File.separator + "equipFault.dat");
        BufferedReader bufferedReader = new BufferedReader (fileReader);
		String		oneLine;
		oneLine = bufferedReader.readLine ();
		int			count = Integer.parseInt (oneLine);
		equipFault = new String [count];
		for (int index = 0; index < count; ++ index) {
			oneLine = bufferedReader.readLine ();
			if (oneLine == null)
				break;
			equipFault [index] = oneLine;
		}
        bufferedReader.close ();
        fileReader.close ();
	}

	// Circuit Fault 정보 조회
    public void readCircuitFault () throws Exception {
        FileReader  fileReader = new FileReader (ABSOLUTE_PATH + File.separator + "circuitFault.dat");
        BufferedReader bufferedReader = new BufferedReader (fileReader);
		String		oneLine;
		oneLine = bufferedReader.readLine ();
		int			count = Integer.parseInt (oneLine);
		circuitFault = new String [count];
		for (int index = 0; index < count; ++ index) {
			oneLine = bufferedReader.readLine ();
			if (oneLine == null)
				break;
			circuitFault [index] = oneLine;
		}
        bufferedReader.close ();
        fileReader.close ();
	}

	// Traffic Fault 정보 조회
    public void readTrafficFault () throws Exception {
        FileReader  fileReader = new FileReader (ABSOLUTE_PATH + File.separator + "trafficFault.dat");
        BufferedReader bufferedReader = new BufferedReader (fileReader);
		String		oneLine;
		oneLine = bufferedReader.readLine ();
		int			count = Integer.parseInt (oneLine);
		trafficFault = new String [count];
		for (int index = 0; index < count; ++ index) {
			oneLine = bufferedReader.readLine ();
			if (oneLine == null)
				break;
			trafficFault [index] = oneLine;
		}
        bufferedReader.close ();
        fileReader.close ();
	}
*/
	public String [] getEquipFault () {
		return equipFault;
	}

	public String [] getCircuitFault () {
		return circuitFault;
	}

	public String [] getTrafficFault () {
		return trafficFault;
	}

	public synchronized void executeUpdate (String query) throws Exception {
//		long before = System.currentTimeMillis ();
		dbController.getStmt ().executeUpdate (query);
//		long after = System.currentTimeMillis ();
	}
	
	public void writeLog(String msg) {
		outputLog.write(msg);
	}
	
	public void executeFaultMenualCleared(JSONObject jsonObject) {
		PreparedStatement stmt=null;
		
		
		try {
			ResultSet resultSet;
			try {
				stmt = dbController.prepareStatement("SELECT TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS') FROM DUAL");
	            resultSet = stmt.executeQuery();
			} catch (Exception e) {
				dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
				stmt = dbController.prepareStatement("SELECT TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS') FROM DUAL");
	            resultSet = stmt.executeQuery();				
			}
						
			if (resultSet.next()) {
				jsonObject.put ("RLSE_DTM", resultSet.getString (1));
				jsonObject.put ("RLSE_RCV_DTM", resultSet.getString (1));
			}
			
			resultSet.close();
			stmt.close();
			String faultType= (String) jsonObject.get("FAULT_TYPE");
			
			//트래픽 장애 해제 처리 
			if("TRAFFIC".equals(faultType)){
				String query = "UPDATE "
			    	      + " OMN30131 SET"			    	     
			    	      + "   RLSE_DTM=? "												    /* 1. RLSE_DTM */
			    	      + " , RLSE_RCV_DTM=TO_DATE(?,'YYYYMMDDHH24MISS')"					    /* 2. RLSE_RCV_DTM */
			    	      + " , KEEP_TMS=24*60*60*(SYSDATE-TO_DATE(?,'YYYYMMDDHH24MISS'))"	    /* 3. OCCR_RCV_DTM */
			    	      + ", DABL_RLSE_MTHD_CD=?"
			    	      + ", DABL_RLSR_ID=?"
			    	      + " WHERE DABL_NUM=?";												/* 4. DABL_NUM */
			    	stmt = dbController.prepareStatement(query);
			    	
			    	stmt.setString(1, (String) jsonObject.get("RLSE_DTM"));
			    	stmt.setString(2, (String) jsonObject.get("RLSE_DTM"));
			    	stmt.setString(3, (String) jsonObject.get("OCCR_RCV_DTM"));
					stmt.setString(4, (String) jsonObject.get("DABL_RLSE_MTHD_CD"));
					stmt.setString(5, (String) jsonObject.get("DABL_RLSR_ID"));
					stmt.setString(6, (String) jsonObject.get("DABL_NUM"));
				
				outputLog.write ("[TRAFFIC] "+(String)jsonObject.get("DABL_RLSE_MTHD_CD") + (String)jsonObject.get("DABL_RLSR_ID")+"DABL_NUM::"+(String) jsonObject.get("DABL_NUM"));
			}else{
				String query = "UPDATE /*+ INDEX(A OMN30100_PK) */ "
			    	      + " OMN30100 A SET"
			    	      + " DABL_ST_CD='02' "													/* 1. DABL_ST_CD */
			    	      + " , RLSE_DTM=? "												    /* 2. RLSE_DTM */
			    	      + " , RLSE_RCV_DTM=TO_DATE(?,'YYYYMMDDHH24MISS')"					    /* 3. RLSE_RCV_DTM */
			    	      + " , KEEP_TMS=24*60*60*(SYSDATE-TO_DATE(?,'YYYYMMDDHH24MISS'))"	    /* 4. OCCR_RCV_DTM */
			    	      + ", DABL_RLSE_MTHD_CD=?"
			    	      + ", DABL_RLSR_ID=?"
			    	      + " WHERE DABL_NUM=?";												/* 5. DABL_NUM */
			    	stmt = dbController.prepareStatement(query);
					
			    	stmt.setString(1, (String) jsonObject.get("RLSE_DTM"));
			    	stmt.setString(2, (String) jsonObject.get("RLSE_DTM"));
			    	stmt.setString(3, (String) jsonObject.get("OCCR_RCV_DTM"));
					stmt.setString(4, (String) jsonObject.get("DABL_RLSE_MTHD_CD"));
					stmt.setString(5, (String) jsonObject.get("DABL_RLSR_ID"));
					stmt.setString(6, (String) jsonObject.get("DABL_NUM"));
					outputLog.write ("[EQUIP]"+(String)jsonObject.get("DABL_RLSE_MTHD_CD") + (String)jsonObject.get("DABL_RLSR_ID")+"DABL_NUM::"+(String) jsonObject.get("DABL_NUM"));
			}
	    	
			/* ***로 변경  */
			jsonObject.put("DABL_RLSR_ID","***");
			stmt.executeUpdate();
			stmt.close();
				
		if (stmt != null) stmt.close();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			outputLog.write ("-----------------------------------------");
			outputLog.write (e);
			outputLog.write ("JSON : " + jsonObject);			
			outputLog.write ("-----------------------------------------\n");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			outputLog.write ("-----------------------------------------");
			outputLog.write (e);
			outputLog.write ("JSON : " + jsonObject);			
			outputLog.write ("-----------------------------------------\n");
		}
	}
}

