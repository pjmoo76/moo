package com.skb.mi.realtime;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Calendar;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLRecoverableException;
import java.sql.Statement;

import com.skb.adams.cm.util.StringUtils;
import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.DBController;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.common.MiscUtils;
import com.skb.mi.common.OutputLog;
import com.skb.mi.model.OMN30203;
import com.skb.mi.realtime.unms.UnmsClearEvent;
import com.skb.mi.realtime.unms.UnmsEvent;
import com.skb.mi.realtime.unms.UnmsEventFactory;
import com.skb.mi.realtime.unms.UnmsFaultEvent;
import com.skb.mi.realtime.unms.UnmsHeader;
import com.skb.mi.realtime.unms.UnmsIfVerEnum;
import com.skb.mi.realtime.unms.UnmsLongCallClrEvent;
import com.skb.mi.realtime.unms.UnmsLongCallGenEvent;
import com.skb.mi.realtime.unms.UnmsLongCallUptEvent;
import com.skb.mi.realtime.unms.UnmsMessageEvent;
import com.skb.mi.realtime.unms.UnmsServiceTypeEnum;
import com.skb.mi.thread.KeepAliveUnmsEquip;
import com.skb.mi.thread.SendJsonThread;

import org.apache.commons.cli.HelpFormatter;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

public class RealTimeCollectUnmsEquip {

	final private String NET_CL_CD = "01"; // 교환망 또는 VOIP
	final private String NET_CL_NM = "교환망"; // 교환망

	final private String GENERATE_EVENT = "GEN";
	final private String CLEAR_EVENT = "CLR";

	final private String CIRCUIT_DABL_LCL_NM = "회선장애";
	final private String CIRCUIT_DABL_MCL_CD = "04101";
	final private String CIRCUIT_DABL_MCL_NM = "교환망회선장애";
	final private String CIRCUIT_DABL_CD = "041001";
	final private String CIRCUIT_DABL_NM = "UNMS회선장애";

	final private String GENERATED_FAULT_NM = "장애중";
	final private String CLEARED_FAULT_NM = "장애해제";

	final private String GENERATED_FAULT_CD = "01";
	final private String CLEARED_FAULT_CD = "02";

	final private int SO_TIME_OUT = (1000 * 60 * 5); // Time-Out 5분 설정

	protected String equipIpAddress;
	protected int equipPortNo;

	// UNMS Equip 실시간 장애 수집
	Socket equipSocket;
	InputStream equipInputStream;
	OutputStream equipOutputStream;

	//Unms Msg WebPush
	String pushIpAddress;
	int pushPortNo;
	
    //Unms Msg Web용
	String pushIpAddress2;
	int pushPortNo2;

	JSONObject jsonObject;

	private Logger logger;
	private SqlSession adamsSession;
	private SendJsonThread jsonSender;
	//Unms Msg WebPush
	private SendJsonThread jsonSenderMsg;

	private UnmsEventFactory factory;

	private HashMap<String, String> nmsCdMap;

	private String[] track2Filter;

	public RealTimeCollectUnmsEquip(String[] args) {
		logger = LogManager.getLogger(this.getClass());
		logger.info("start");
		logger.info(">>> commit svn 2021-07-07 ver");

		loadConfig();
		jsonSender = new SendJsonThread(pushIpAddress, pushPortNo, true);
		//Unms Msg WebPush
		jsonSenderMsg = new SendJsonThread(pushIpAddress2, pushPortNo2, true); //ics
		factory = new UnmsEventFactory(getIfVer());

		// TRACK2에서 들어오는 장비 목록
		track2Filter = new String[] { "000000632958", "000000633025",
				"000000633057", "000000633068", "000000633072", "000000633079",
				"000000633081", "000000633099", "000000633112", "000000633115",
				"000000633176", "000000633184", "000000633194", "000000633195",
				"000000633221", "10076265", "10076266", "10076267", "10076268",
				"10076269", "10076270", "10076271", "10076272", "10076273",
				"10076274", "10076275", "10076276", "10076277", "10076278",
				"138643942", "138643943", "21891418", "000000632980" };

		try {
			connectNms();
			run();
		} catch (Exception e) {
			logger.error("Exception", e);
		}
	}

	public RealTimeCollectUnmsEquip(SqlSession sqlSession) {
		logger = LogManager.getLogger(this.getClass());
		this.adamsSession = sqlSession;
	}

	public void loadConfig() {
		String cfgFile = EnvManager.env.getConf() + File.separator
				+ EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		setNmsConnInfo(configManager);
		pushIpAddress = configManager.getConfig(Constants.WEB_PUSH,
				Constants.IP_ADDRESS);
		pushPortNo = Integer.parseInt(configManager.getConfig(
				Constants.WEB_PUSH, Constants.PORT_NO));
		//Unms Msg WebPush
		pushIpAddress2 = configManager.getConfig(Constants.UNMS_MSG_WEB_PUSH,
				Constants.IP_ADDRESS);
		pushPortNo2 = Integer.parseInt(configManager.getConfig(
				Constants.UNMS_MSG_WEB_PUSH, Constants.PORT_NO));

		
		logger.info("equipIpAddress : " + equipIpAddress);
		logger.info("equipPortNo : " + equipPortNo);
		logger.info("pushIpAddress : " + pushIpAddress);
		logger.info("pushPortNo : " + pushPortNo);

		logger.info("pushIpAddress2 : " + pushIpAddress2);
		logger.info("pushPortNo2 : " + pushPortNo2);

	}

	protected void setNmsConnInfo(ConfigManager configManager) {
		equipIpAddress = configManager.getConfig(Constants.UNMS_FAULT,
				Constants.IP_ADDRESS);
		equipPortNo = Integer.parseInt(configManager.getConfig(
				Constants.UNMS_FAULT, Constants.PORT_NO));

	}

	public void connectNms() {
		boolean check = false;
		while (!check) {
			try {
				if (equipInputStream != null)
					equipInputStream.close();
			} catch (Exception e) {
				logger.error("Exception", e);
			}
			try {
				if (equipOutputStream != null)
					equipOutputStream.close();
			} catch (Exception e) {
				logger.error("Exception", e);
			}
			try {
				if (equipSocket != null)
					equipSocket.close();
			} catch (Exception e) {
				logger.error("Exception", e);
			}
			try {
				logger.info("try connecting " + equipIpAddress + ":"
						+ equipPortNo);
				equipSocket = new Socket(equipIpAddress, equipPortNo);
				equipSocket.setSoTimeout(SO_TIME_OUT);
				equipInputStream = equipSocket.getInputStream();
				equipOutputStream = equipSocket.getOutputStream();

				sendRequestPort();
				sendLoginPacket();

				logger.info("connected " + equipIpAddress + ":" + equipPortNo);

				check = true;
			} catch (Exception e) {
				logger.error("Exception", e);
				MiscUtils.sleep(100); // 0.1초
			}
		}
	}

	private void loadNmsCd() throws Exception {
		if (nmsCdMap == null) {
			nmsCdMap = new HashMap<String, String>();
		}
		List<HashMap<String, Object>> objList = (List) adamsSession.selectList(
				"RealtimeUnms.selectNmsCdList", null);
		for (HashMap<String, Object> obj : objList) {
			logger.debug(String.format("(%s),(%s)", (String) obj.get("NMS_CD"),
					(String) obj.get("NMS_NM")));
			nmsCdMap.put((String) obj.get("NMS_CD"), (String) obj.get("NMS_NM"));
		}
	}

	private void run() {
		long nextEchoTime = (System.currentTimeMillis() / 1000L) + (60 * 10); // 10분마다
																				// sendEchoPacket
		long nextEchoDBTime = (System.currentTimeMillis() / 1000L) + (60 * 60); // 60분마다
																				// keepAlive

		UnmsEvent event = null;
		int errContCnt = 0;

		while (true) {
			try {
				if (adamsSession == null) {
					adamsSession = IbatisSessionFactory
							.openSession(Constants.ADAMS_DB);
					if (nmsCdMap == null || nmsCdMap.size() == 0) {
						loadNmsCd();
					}
				}
				if (event == null) {
					event = factory.get(equipInputStream);
					errContCnt = 0;
				} else {
					// retry
					errContCnt++;
					if (errContCnt > 3) {
						event = null;
						continue;
					}
				}
				if (event != null) {
					process(event);
					event = null;
				}
				long currentTime = System.currentTimeMillis() / 1000L;
				if (nextEchoTime < currentTime) {
					this.sendEchoPacket();
					nextEchoTime = currentTime + (60 * 10);
				}
				if (nextEchoDBTime < currentTime) {
					this.keepAliveDB();
					nextEchoDBTime = currentTime + (60 * 60);
				}
			} catch (SocketTimeoutException ste) {
				logger.error("SocketTimeoutException", ste);
				connectNms();
			} catch (SocketException se) {
				logger.error("SocketException", se);
				connectNms();
			} catch (SQLException sqle) {
				logger.error("SQLException", sqle);
				adamsSession.close();
				adamsSession = null;
				MiscUtils.sleep(100);
			} catch (PersistenceException pe) {
				logger.error("PersistenceException", pe);
				adamsSession.close();
				adamsSession = null;
				MiscUtils.sleep(100);
			} catch (Exception e) {
				logger.error("Exception", e);
			}
		}
	}

	public void process(UnmsEvent event) throws Exception {
		jsonObject = new JSONObject();
		// 시외망 프로세스
		if (this.getIfVer() == UnmsIfVerEnum.Outct) {
			String nmsCd = event.getNmsCd();

			if ("4501".equals(nmsCd) || "019".equals(nmsCd)) {
				logger.info("시외망장애");
			} else {
				return;
			}
		}
		// track1 장시간호의 경우 nmsCd를 특정할수없어 장비정보의 equip_usg_cd로 필터링
		// 장시간호 업데이트, 해제 메세지는 nmsCd와 장비정보를 알수없음 pass
		if (this.getIfVer() == UnmsIfVerEnum.V1) {
			String nmsCd = event.getNmsCd();

			if ("4101".equals(nmsCd)) {
				logger.info("PSTN 처리하지않음");
				return;
			}
		}
		if (event.getServiceCode() == UnmsServiceTypeEnum.SERVICE_CODE_FAULT
				|| event.getServiceCode() == UnmsServiceTypeEnum.SERVICE_CODE_CLEAR) {
			processFaultEvent(event);
			logger.debug("JSON_OBEJCT:" + jsonObject.toString());
			// 지정된 장비 필터링 처리
			if (this.getIfVer() == UnmsIfVerEnum.V1) {
				String equipId = (String) jsonObject.get("EQUIP_ID");
				boolean flag = false;
				// 해지 메세지의 경우 PSTN과 지정된 장비 필터링
				if (event.getServiceCode() == UnmsServiceTypeEnum.SERVICE_CODE_CLEAR) {
					String equipUsgCd = (String) jsonObject.get("EQUIP_USG_CD");
					flag = filterMessage(equipId);
					if ("4101".equals(equipUsgCd)) {
						logger.info("PSTN 처리하지않음");
						flag = true;
					}
				} else {
					flag = filterMessage(equipId);
				}

				if (flag) {
					return;
				}

			}
		} else if (event.getServiceCode() == UnmsServiceTypeEnum.SERVICE_MESSAGE
				|| event.getServiceCode() == UnmsServiceTypeEnum.SERVICE_LONG_CALL_GEN) {
			String equipId = null;
			if (event.getServiceCode() == UnmsServiceTypeEnum.SERVICE_MESSAGE) {
				UnmsMessageEvent messageEvent = (UnmsMessageEvent) event;
				equipId = this.getEquipId(messageEvent.getNeId());
			} else {
				UnmsLongCallGenEvent longCallGenEvent = (UnmsLongCallGenEvent) event;
				equipId = this.getEquipId(longCallGenEvent.getNeId());
			}
			String equipNm = "";
			String equipMdlCd = "";
			String equipMdlNm = "";
			String infoCntrCd = "";
			String infoCntrNm = "";
			String equipUsgCd = "";
			if (equipId != null) {
				HashMap<String, Object> retMap = adamsSession.selectOne(
						"RealtimeUnms.selectEquipInfo", equipId);
				if (retMap != null) {
					/*
					 * Iterator it = retMap.entrySet().iterator(); while
					 * (it.hasNext()) { Map.Entry pair = (Map.Entry)it.next();
					 * logger.debug(pair.getKey() + " = " + pair.getValue());
					 * it.next(); }
					 */
					// equipNm = (String) retMap.get("equipNm");
					// equipMdlCd = (String) retMap.get("equipMdlCd");
					// equipMdlNm = (String) retMap.get("equipMdlNm");
					// infoCntrCd = (String) retMap.get("mgmtTpoCd");
					// infoCntrNm = (String) retMap.get("mgmtTpoNm");
					equipNm = (String) retMap.get("EQUIP_NM");
					equipMdlCd = (String) retMap.get("EQUIP_MDL_CD");
					equipMdlNm = (String) retMap.get("EQUIP_MDL_NM");
					infoCntrCd = (String) retMap.get("MGMT_TPO_CD");
					infoCntrNm = (String) retMap.get("MGMT_TPO_NM");
					equipUsgCd = (String) retMap.get("EQUIP_USG_CD");
					logger.debug(String
							.format("(equipNm=%s),(equipMdlCd=%s),(equipMdlNm=%s),(infoCntrCd=%s),(infoCntrNm=%s),(equipUsgCd=%s)",
									equipNm, equipMdlCd, equipMdlNm,
									infoCntrCd, infoCntrNm, equipUsgCd));
				}
			}

			if (this.getIfVer() == UnmsIfVerEnum.V1) {

				boolean flag = false;
				// 해지 메세지의 경우 PSTN과 지정된 장비 필터링
				flag = filterMessage(equipId);
				if ("4101".equals(equipUsgCd)) {
					logger.info("PSTN 처리하지않음");
					flag = true;
				}

				if (flag) {
					return;
				}
			}
			if (event.getServiceCode() == UnmsServiceTypeEnum.SERVICE_MESSAGE) {
				saveCurrentMessage((UnmsMessageEvent) event, infoCntrCd,
						infoCntrNm, equipId, equipNm, equipMdlCd, equipMdlNm);
			} else {
				saveLongCallGen((UnmsLongCallGenEvent) event, infoCntrCd,
						infoCntrNm, equipId, equipNm, equipMdlCd, equipMdlNm);
			}
		} else if (event.getServiceCode() == UnmsServiceTypeEnum.SERVICE_LONG_CALL_UPT) {
			saveLongCallUpt((UnmsLongCallUptEvent) event);
		} else if (event.getServiceCode() == UnmsServiceTypeEnum.SERVICE_LONG_CALL_CLR) {
			saveLongCallClr((UnmsLongCallClrEvent) event);
		} else {
			return;
		}

		// NMS_CD가 NULL 인경우 로그파일기록을 위해 NMS_CD를 UNMS로 넣어주기
		String nmsCd = (String) jsonObject.get("NMS_CD");
		if ("".equals(nmsCd) || nmsCd == null) {
			jsonObject.put("NMS_CD", "UNMS");
		}
		//jsonSender.put(jsonObject); ics
		if (event.getServiceCode() == UnmsServiceTypeEnum.SERVICE_CODE_FAULT
				|| event.getServiceCode() == UnmsServiceTypeEnum.SERVICE_CODE_CLEAR) {
			jsonSender.put(jsonObject);
			logger.debug("event.getServiceCode:" + event.getServiceCode());
		}else {
			jsonSenderMsg.put(jsonObject);
			logger.debug("event.getServiceCode:" + event.getServiceCode());
			
		}
		
	}

	// UnmsAlarmJsonMaker 에서 alarm 복구를 위한 json stirng 생성 시 사용
	public void resetJsonObject() {
		jsonObject = new JSONObject();
	}

	public JSONObject processFaultEvent(UnmsEvent event) throws Exception {
		jsonObject.put("NET_CL_CD", NET_CL_CD);
		jsonObject.put("NET_CL_NM", NET_CL_NM);

		if (event.getServiceCode() == UnmsServiceTypeEnum.SERVICE_CODE_CLEAR) {
			UnmsClearEvent clearEvent = (UnmsClearEvent) event;
			jsonObject.put("RLSE_DTM", clearEvent.getRlseDtm()); // 발생 시각
			jsonObject.put("RLSE_RCV_DTM", MiscUtils.getDateTime());
			jsonObject.put("kind", CLEAR_EVENT);
			jsonObject.put("DABL_ST_CD", CLEARED_FAULT_CD);
			jsonObject.put("DABL_ST_NM", CLEARED_FAULT_NM);
			jsonObject.put("NMS_CD", clearEvent.getOrgNmsCd());
			if (this.getIfVer() == UnmsIfVerEnum.V1) {

				String nmsDablNumCtt = clearEvent.getAlarmNo();
				jsonObject.put("NMS_DABL_NUM_CTT", nmsDablNumCtt);
				HashMap<String, Object> retMap = adamsSession.selectOne(
						"RealtimeUnms.selectClearEquipInfo", nmsDablNumCtt);
				jsonObject.put("EQUIP_ID", retMap.get("EQUIP_ID"));
				jsonObject.put("EQUIP_USG_CD", retMap.get("EQUIP_USG_CD"));

			} else {
				jsonObject.put("EQUIP_ID", clearEvent.getEquipId());
				jsonObject.put("DABL_OCCR_LOC_DESC",
						clearEvent.getDablOccrLocDesc());
				jsonObject.put("DABL_NM", clearEvent.getDablNm());
				jsonObject.put("NMS_DABL_CD", clearEvent.getNmsDablCd());
				jsonObject.put("EQUIP_DABL_NUM_CTT",
						clearEvent.getEquipDablNumCtt());
				jsonObject.put("NMS_CD", clearEvent.getClctNmsClCd());
			}
		} else {
			UnmsFaultEvent faultEvent = (UnmsFaultEvent) event;
			jsonObject.put("NMS_CD", faultEvent.getOrgNmsCd());
			jsonObject.put("NMS_NM", getNmsName(faultEvent));
			jsonObject.put("NMS_DABL_NUM_CTT", faultEvent.getAlarmNo());
			jsonObject.put("kind", GENERATE_EVENT);
			jsonObject.put("DABL_ST_CD", GENERATED_FAULT_CD);
			jsonObject.put("DABL_ST_NM", GENERATED_FAULT_NM);
			jsonObject.put("EQUIP_ID", faultEvent.getNeId()); // 장비 아이디
			jsonObject.put("EQUIP_TID_VAL", faultEvent.getNeId()); // 장비 TID
			jsonObject.put("EQUIP_IP_ADDR", faultEvent.getNeIp()); // 장비 IP
			jsonObject.put("EQUIP_NM", faultEvent.getNeName()); // 장비 이름
			jsonObject.put("EQUIP_MDL_CD", faultEvent.getNeModelId()); // 장비 모델
																		// 아이디
			jsonObject.put("EQUIP_MDL_NM", faultEvent.getNeModelName()); // 장비
																			// 모델
																			// 이름
			jsonObject.put("DABL_OCCR_LOC_DESC", faultEvent.getLocation()); // 장애
																			// 발생
																			// 위치
			jsonObject.put("DABL_DESC", faultEvent.getInform()); // 장애 발생 사유
			// jsonObject.put("EQUIP_DABL_MSG_CTT", faultEvent.getInform()); //
			// 장애 상세 정보
			jsonObject.put("ALARM_CLASS", faultEvent.getAlarmClass()); // 장애 분류
			jsonObject.put("ALARM_TYPE", faultEvent.getAlarmType()); // 장애 세부 유형
			jsonObject.put("DABL_GR_CD",
					getDablGrCd(faultEvent.getAlarmLevel())); // 장애 등급
			jsonObject.put("DABL_NM", faultEvent.getReason()); // 장애 발생 사유
			jsonObject.put("NMS_DABL_CD", faultEvent.getAlarmCode()); // NMS장애코드
			jsonObject.put("MSC_MODULE_TYPE_CD", faultEvent.getModuleType()); // 모듈
																				// 코드
			jsonObject.put("MSC_MODULE_NM", faultEvent.getModuleName()); // 모듈 명
			jsonObject.put("MODULE_EQUIP_ID", faultEvent.getModuleNeId()); // 모듈
																			// 장비
																			// ID
			jsonObject.put("MODULE_EQUIP_NM", faultEvent.getModuleNeName()); // 모듈
																				// 장비
																				// 명
			jsonObject.put("SLOT_NUM", faultEvent.getSlotNo()); // SLOT 번호
			jsonObject.put("PORT_NUM", faultEvent.getPortNo()); // 포트 번호
			jsonObject.put("PORT_INDEX", faultEvent.getPortIndex()); // 포트 INDEX
			jsonObject.put("ROUT_NUM", faultEvent.getRoutes()); // 루트 번호
			jsonObject.put("MAIN_PROC", faultEvent.getMainProc()); // 주 프로세스
			jsonObject.put("SUB_PROC", faultEvent.getSubProc()); // 서브 프로세스
			jsonObject.put("OCCR_DTM", faultEvent.getOccrTime()); // 발생 시각
			jsonObject.put("OCCR_RCV_DTM", MiscUtils.getDateTime());
			jsonObject.put("OPER_DABL_YN", faultEvent.getWorkMode()); // 작업 여부
			jsonObject.put("NE_NODE_ID", faultEvent.getNeNodeId()); // 장비 소속 노드
																	// ID
			jsonObject.put("NE_NODE_IDS", faultEvent.getNeNodeIds()); // 장비 소속
																		// 노드
																		// 코드들
			jsonObject.put("NE_NODE_NAMES", faultEvent.getNeNodeNames()); // 장비
																			// 소속
																			// 노드
																			// 명들
			jsonObject.put("EQUIP_DABL_MSG_CTT", faultEvent.getEtc()); // 장비 발생
																		// 메시지
			jsonObject.put("CO_VIP_CUST_YN", faultEvent.getVip()); // VIP 여부
			jsonObject.put("V52_USE_SUBS_CNT", "" + faultEvent.getSubsCnt()); // 가입자수
			jsonObject.put("DMG_SCRBR_CNT", "" + faultEvent.getSubsCnt()); // 피해가입자수
			jsonObject.put("TM_ID", faultEvent.getTmId()); // TM ID
			jsonObject.put("CARRIER_NAME", faultEvent.getCarrierName()); // CARRIER
																			// NAME
			jsonObject.put("NUM_EVENT", faultEvent.getNumEvent()); // Event수
			jsonObject.put("OPER_END_DTM", faultEvent.getWorkEndTime()); // 작업종료일시
			jsonObject.put("EQUIP_DABL_NUM_CTT",
					faultEvent.getEquipDablNumCtt()); // 장비장애번호
			selectOIV10107();
			selectOIV10400();
			selectOIV10121();
			// 장애코드
			selectOMN30203(faultEvent.getAlarmCode());

			// 회선장애 회선정보 ,장애코드
			String strSvcMgmtNum = faultEvent.getSvcMgmtNum();
			// 서비스관리번호가 있는경우 회선장애로 판단
			if (strSvcMgmtNum != null) {
				
				logger.info(CIRCUIT_DABL_LCL_NM +":: " +strSvcMgmtNum);
				
				jsonObject.put("DABL_LCL_CD", "04");
				jsonObject.put("DABL_LCL_NM", CIRCUIT_DABL_LCL_NM);
				jsonObject.put("DABL_MCL_CD", CIRCUIT_DABL_MCL_CD);
				jsonObject.put("DABL_MCL_NM", CIRCUIT_DABL_MCL_NM);
				jsonObject.put("DABL_CD", CIRCUIT_DABL_CD);
				jsonObject.put("DABL_CD_NM", CIRCUIT_DABL_NM);

				// 회선정보 조회
				HashMap<String, Object> hmap = adamsSession.selectOne(
						"RealtimeUnms.selectLineInfo", strSvcMgmtNum);
				if (hmap != null) {

					jsonObject.put("LINE_NM", (String) hmap.get("LINE_NM"));
					jsonObject.put("LINE_NUM", (String) hmap.get("LINE_NUM"));
					jsonObject.put("LINE_CL_CD",(String) hmap.get("LINE_CL_CD"));
					jsonObject.put("LINE_CL_NM",(String) hmap.get("LINE_CL_NM"));
					jsonObject.put("CUST_CHRTIC_CD",(String) hmap.get("CUST_CHRTIC_CD"));
					jsonObject.put("CUST_CHRTIC_NM",(String) hmap.get("LINE_CL_NM"));
					jsonObject.put("SVC_TECH_MTHD_CD",
							(String) hmap.get("SVC_TECH_MTHD_CD"));
					jsonObject.put("SVC_TECH_MTHD_NM",
							(String) hmap.get("SVC_TECH_MTHD_NM"));
					jsonObject.put("SUP_TPO_CD",
							(String) hmap.get("SUP_TPO_CD"));
					jsonObject.put("SUP_TPO_NM",
							(String) hmap.get("SUP_TPO_NM"));
					jsonObject.put("SUB_TPO_CD",
							(String) hmap.get("SUB_TPO_CD"));
					jsonObject.put("SUB_TPO_NM",
							(String) hmap.get("SUB_TPO_NM"));
					jsonObject.put("SPEED_CD", (String) hmap.get("SPEED_CD"));
					jsonObject.put("SPEED_NM", (String) hmap.get("SPEED_NM"));
					jsonObject.put("SVC_MGMT_NUM", strSvcMgmtNum);
					

				} else {
					jsonObject.put("LINE_NM", "*");
					jsonObject.put("LINE_CL_CD", "*");
					jsonObject.put("LINE_CL_NM", "일반회선");
					jsonObject.put("CUST_CHRTIC_CD","*");
					jsonObject.put("CUST_CHRTIC_NM","일반회선");
					jsonObject.put("SVC_TECH_MTHD_CD", "*");
					jsonObject.put("SVC_TECH_MTHD_NM", "*");
					jsonObject.put("SUP_TPO_CD", "*");
					jsonObject.put("SUP_TPO_NM", "*");
					jsonObject.put("SUB_TPO_CD", "*");
					jsonObject.put("SUB_TPO_NM", "*");
					jsonObject.put("SPEED_CD", "*");
					jsonObject.put("SPEED_NM", "*");
					// 서비스관리번호 처리 2022-04-19 강대윤
					jsonObject.put("SVC_MGMT_NUM", strSvcMgmtNum);

				}
				
				// 고객명 조회 (+ CUST_NUM 고객번호 조회 (2020.10.13 추가))
				HashMap<String, Object> hmap2 = adamsSession.selectOne("RealtimeUnms.selectCustInfo", strSvcMgmtNum);
				
				if (hmap2 != null) {
					
					jsonObject.put("CUST_NM",(String) hmap2.get("CUST_NM"));
					jsonObject.put("CUST_NUM",(String) hmap2.get("CUST_NUM"));
				} else {					
					jsonObject.put("CUST_NM","*");
					jsonObject.put("CUST_NUM","0");
				}
				
				//회선정보에 등급정보가 없을시 고객의 등급정보를 넣어주기
				String lineClCd = (String)jsonObject.get("LINE_CL_CD");
				String lineClNm = (String)jsonObject.get("LINE_CL_NM");
				
				if("*".equals(lineClCd)|| "일반회선".equals(lineClNm) ||"*".equals(lineClNm) )
				{
					
					HashMap<String, Object> hmap3 = adamsSession.selectOne("RealtimeUnms.selectCustInfo", strSvcMgmtNum);
					
					if (hmap3 != null) {
						jsonObject.put("LINE_CL_CD",(String) hmap3.get("CUST_CHRTIC_CD"));
						jsonObject.put("CUST_CHRTIC_CD",(String) hmap3.get("CUST_CHRTIC_CD"));
						jsonObject.put("LINE_CL_NM",(String) hmap3.get("LINE_CL_NM"));
						jsonObject.put("CUST_CHRTIC_NM",(String) hmap3.get("LINE_CL_NM"));
					}else{
						jsonObject.put("LINE_CL_CD", "*");
						jsonObject.put("CUST_CHRTIC_CD", "*");
						jsonObject.put("LINE_CL_NM", "일반회선");
						jsonObject.put("CUST_CHRTIC_NM","일반회선");
					}
				}	
				//서비스 기술방식 코드가 회선 정보에 없을시 넣어주기			
				
				String svcTechMthdNm = (String)jsonObject.get("SVC_TECH_MTHD_NM");
			
				if("*".equals(svcTechMthdNm))
				{
					HashMap<String, Object> hmap4 = adamsSession.selectOne("RealtimeUnms.selectSvcTechMthd", strSvcMgmtNum);
					if (hmap4 != null) {
						jsonObject.put("SVC_TECH_MTHD_CD",
								(String) hmap4.get("SVC_TECH_MTHD_CD"));
						jsonObject.put("SVC_TECH_MTHD_NM",
								(String) hmap4.get("SVC_TECH_MTHD_NM"));
					}else{
						jsonObject.put("SVC_TECH_MTHD_CD", "*");
						jsonObject.put("SVC_TECH_MTHD_NM", "*");
					}
				}
				
				// 담당 AM 조회 
				HashMap<String, Object> hmap5 = adamsSession.selectOne("RealtimeUnms.selectAmInfo",strSvcMgmtNum);
				if (hmap5 != null) {
					jsonObject.put("CHRGR_ID",(String) hmap5.get("CHRGR_ID"));
					jsonObject.put("CHRGR_NM",(String) hmap5.get("CHRGR_NM"));
				}
			}

		}
		logger.info(jsonObject);
		return jsonObject;
	}

	protected String getEquipId(String clctEquipNum) throws Exception {
		logger.debug("clctEquipNum:" + clctEquipNum);
		return (String) adamsSession.selectOne("RealtimeUnms.selectEquipId",
				clctEquipNum);
	}

	public void saveCurrentMessage(UnmsMessageEvent messageEvent,
			String infoCntrCd, String infoCntrNm, String equipId,
			String equipNm, String equipMdlCd, String equipMdlNm)
			throws Exception {
		// JSON 생성
		jsonObject.put("kind", "MSG");
		jsonObject.put("NMS_CD", messageEvent.getNmsCd());
		jsonObject.put("NMS_NM", getNmsName(messageEvent));
		jsonObject.put("INFO_CNTR_CD", infoCntrCd);
		jsonObject.put("INFO_CNTR_NM", infoCntrNm);
		jsonObject.put("EQUIP_ID", equipId);
		jsonObject.put("EQUIP_NM", equipNm);
		jsonObject.put("EQUIP_MDL_CD", equipMdlCd);
		jsonObject.put("EQUIP_MDL_NM", equipMdlNm);
		jsonObject.put("MNTR_DTM", messageEvent.getMntrDtm());
		jsonObject.put("MSG_ST_CD", messageEvent.getMsgStCd());
		jsonObject.put("MSG_NM", messageEvent.getMsgNm());
		jsonObject.put("MSG_CTT", messageEvent.getMsgCtt());

		// DB저장
		saveOMN20310();

		// 장애발생위치, 장애발생사유
		jsonObject.put("DABL_OCCR_LOC_DESC",
				getDablOccrLocDesc(messageEvent.getMsgCtt())); // 장애 발생 위치
		jsonObject.put("DABL_DESC", getDablDesc(messageEvent.getMsgCtt())); // 장애
																			// 발생
																			// 사유
	}

	private String getDablOccrLocDesc(String msgCtt) {
		// "LOC : " 문자열이 존재하는지 체크한다.
		int pos = msgCtt.indexOf("LOC : ");
		if (pos == -1) {
			pos = msgCtt.indexOf("LOC *: ");
			if (pos == -1)
				return null;
		}
		// "LOC : " 문자열이 존재하면 그 라인까지만 추출한다.
		int pos2 = msgCtt.indexOf('\n', pos);
		if (pos2 != -1) {
			return msgCtt.substring(pos, pos2).trim();
		}
		// '\n' 값이 존재하지 않는다면 "COMPLETED" 문자열 전까지만 추출한다.
		pos2 = msgCtt.indexOf("COMPLETED", pos);
		if (pos2 != -1) {
			return msgCtt.substring(pos, pos2).trim();
		}
		return msgCtt.substring(pos).trim();
	}

	private String getDablDesc(String msgCtt) {
		// 추출 순서
		// 1. "LNK : " 영역 추출. "INF : ", "ADT : " 문자열 전까지
		// 2. "INF : " 영역 추출. "COMPLETED" 문자열 전까지
		int pos = msgCtt.indexOf("LNK : ");
		if (pos != -1) {
			int pos2 = msgCtt.indexOf("INF : ", pos);
			if (pos2 != -1 && pos < pos2) {
				return msgCtt.substring(pos, pos2).trim();
			}
			pos2 = msgCtt.indexOf("ADT : ", pos);
			if (pos2 != -1 && pos < pos2) {
				return msgCtt.substring(pos, pos2).trim();
			}
			pos2 = msgCtt.indexOf("COMPLETED", pos);
			if (pos2 != -1) {
				return msgCtt.substring(pos, pos2).trim();
			}
			return msgCtt.substring(pos).trim();
		} else {
			pos = msgCtt.indexOf("INF : ");
			if (pos == -1) {
				pos = msgCtt.indexOf("INF *: *");
				if (pos == -1)
					return null;
			}
			int pos2 = msgCtt.indexOf("COMPLETED", pos);
			if (pos2 != -1) {
				return msgCtt.substring(pos, pos2).trim();
			}
			return msgCtt.substring(pos).trim();
		}
	}

	public void saveLongCallUpt(UnmsLongCallUptEvent longCallUptEvent)
			throws Exception {
		jsonObject.put("kind", "LCU");
		jsonObject.put("NMS_MGMT_NUM", longCallUptEvent.getNmsMgmtNum());
		jsonObject.put("ACT_DTM", longCallUptEvent.getActDtm());
		jsonObject.put("KEEP_TMS", longCallUptEvent.getKeepTms());

		// DB저장
		if (getIfVer() == UnmsIfVerEnum.V1) {
			updateOMN20302();
		}
	}

	public void saveLongCallClr(UnmsLongCallClrEvent longCallClrEvent)
			throws Exception {
		// JSON 생성
		jsonObject.put("kind", "LCC");
		jsonObject.put("ACT_DTM", longCallClrEvent.getActDtm());
		jsonObject.put("NMS_MGMT_NUM", longCallClrEvent.getNmsMgmtNum());

		// DB저장
		if (getIfVer() == UnmsIfVerEnum.V1) {
			clearOMN20302();
		}
	}

	public void saveLongCallGen(UnmsLongCallGenEvent longCallEvent,
			String infoCntrCd, String infoCntrNm, String equipId,
			String equipNm, String equipMdlCd, String equipMdlNm)
			throws Exception {
		// JSON 생성
		jsonObject.put("kind", "LCG");
		jsonObject.put("NMS_CD", longCallEvent.getNmsCd());
		jsonObject.put("NMS_NM", getNmsName(longCallEvent));
		jsonObject.put("INFO_CNTR_CD", infoCntrCd);
		jsonObject.put("INFO_CNTR_NM", infoCntrNm);
		jsonObject.put("EQUIP_ID", equipId);
		jsonObject.put("EQUIP_NM", equipNm);
		jsonObject.put("EQUIP_MDL_CD", equipMdlCd);
		jsonObject.put("EQUIP_MDL_NM", equipMdlNm);
		jsonObject.put("NMS_MGMT_NUM", longCallEvent.getNmsMgmtNum());
		jsonObject.put("OCCR_DTM", longCallEvent.getOccrDtm());
		jsonObject.put("OCALL_NUM", longCallEvent.getOcallNum());
		jsonObject.put("ICALL_NUM", longCallEvent.getIcallNum());
		jsonObject.put("ROUT_IN_INFO", longCallEvent.getRoutInInfo());
		jsonObject.put("ROUT_OUT_INFO", longCallEvent.getRoutOutInfo());
		jsonObject.put("TC_STA_DTM", longCallEvent.getTcStaDtm());
		jsonObject.put("KEEP_TMS", longCallEvent.getKeepTms());
		jsonObject.put("LTM_CALL_ACT_CL_CD", longCallEvent.getLtmCallActClCd());

		// DB저장
		if (getIfVer() == UnmsIfVerEnum.V1) {
			insertOMN20302();
		}
	}

	public void selectOMN30203(String nmsDablCd) throws Exception {
		OMN30203 omn30203 = adamsSession.selectOne(
				"RealtimeUnms.selectOMN30203", nmsDablCd);
		if (omn30203 != null) {
			jsonObject.put("DABL_LCL_CD", omn30203.getDablLclCd());
			jsonObject.put("DABL_LCL_NM", omn30203.getDablLclNm());
			jsonObject.put("DABL_MCL_CD", omn30203.getDablMclCd());
			jsonObject.put("DABL_MCL_NM", omn30203.getDablMclNm());
			jsonObject.put("DABL_CD", omn30203.getDablCd());
			jsonObject.put("DABL_CD_NM", omn30203.getDablCdNm());
			
			if(jsonObject.get("DABL_NM") == null || "".equals(jsonObject.get("DABL_NM"))) {
				// DABL_NM 값이 없는경우 OMN30203 데이터를 사용한다. 2021-06-23 배포
				jsonObject.put("DABL_NM", omn30203.getDablCdNm());
				logger.info("[DABL_NM] UPDATE. 기존 NULL or 공백 -> [" + jsonObject.get("DABL_NM") + "]");
			}
			
		} else {
			if (nmsDablCd == null || nmsDablCd.equals("")) {
				nmsDablCd = "A****";
			}
			jsonObject.put("DABL_LCL_CD", "01");
			jsonObject.put("DABL_LCL_NM", nmsDablCd);
			jsonObject.put("DABL_MCL_CD", nmsDablCd);
			jsonObject.put("DABL_MCL_NM", nmsDablCd);
			jsonObject.put("DABL_CD", nmsDablCd);
			jsonObject.put("DABL_CD_NM", nmsDablCd);
		}
	}

	public void selectOIV10107() throws Exception {
		String equipId = adamsSession.selectOne("RealtimeUnms.selectOIV10107",
				jsonObject.get("EQUIP_ID"));
		if (equipId != null) {
			jsonObject.put("EQUIP_ID", equipId);
			jsonObject.put("EQUIP_TID_VAL", equipId);
		}
	}

	public void selectOIV10400() throws Exception {
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("equipId", (String) jsonObject.get("EQUIP_ID"));
		hmap.put("portNum", (String) jsonObject.get("PORT_NUM"));
		HashMap<String, Object> retMap = adamsSession.selectOne(
				"RealtimeUnms.selectOIV10400", hmap);
		if (retMap != null) {
			// jsonObject.put("PORT_DESC", retMap.get("portAlsNm"));
			// jsonObject.put("PORT_TYP_CD", retMap.get("portTypCd"));
			jsonObject.put("PORT_DESC", retMap.get("PORT_ALS_NM"));
			jsonObject.put("PORT_TYP_CD", retMap.get("PORT_TYP_CD"));
		} else {
			jsonObject.put("PORT_DESC", "");
			jsonObject.put("PORT_TYP_CD", "");
		}
	}

	public void selectOIV10121() throws Exception {
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("equipId", (String) jsonObject.get("EQUIP_ID"));
		hmap.put("routNum", (String) jsonObject.get("ROUT_NUM"));
		String routNm = adamsSession.selectOne("RealtimeUnms.selectOIV10121",
				hmap);
		if (routNm != null) {
			jsonObject.put("ROUT_NM", routNm);
		} else {
			jsonObject.put("ROUT_NM", "");
		}
	}

	/*
	 * private void selectOMN30100() throws Exception { String nmsCd =
	 * adamsSession.selectOne("RealtimeUnms.selectOMN30100",
	 * jsonObject.get("NMS_DABL_NUM_CTT")); if (nmsCd != null) {
	 * jsonObject.put("NMS_CD", nmsCd); } else { jsonObject.put("NMS_CD",
	 * VOIP_NMS_CD); } }
	 */

	private void saveOMN20310() throws Exception {
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("mntrDt", jsonObject.get("MNTR_DTM").toString()
				.substring(0, 8));
		hmap.put("nmsCd", jsonObject.get("NMS_CD").toString());
		hmap.put("infoCntrCd", (String) jsonObject.get("INFO_CNTR_CD"));
		hmap.put("equipId", (String) jsonObject.get("EQUIP_ID"));
		hmap.put("equipMdlCd", (String) jsonObject.get("EQUIP_MDL_CD"));
		hmap.put("mntrDtm", jsonObject.get("MNTR_DTM").toString());
		hmap.put("msgStCd", jsonObject.get("MSG_ST_CD").toString());
		hmap.put("msgNm", jsonObject.get("MSG_NM").toString());
		hmap.put("exchgSysMsgCtt", jsonObject.get("MSG_CTT").toString());
		adamsSession.insert("RealtimeUnms.insertOMN20310", hmap);
		adamsSession.commit();
	}

	private void updateOMN20302() throws Exception {
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("actDtm", jsonObject.get("ACT_DTM").toString());
		hmap.put("keepTms", jsonObject.get("KEEP_TMS").toString());
		hmap.put("nmsMgmtNum", jsonObject.get("NMS_MGMT_NUM").toString());
		adamsSession.update("RealtimeUnms.updateOMN20302", hmap);
		adamsSession.commit();
	}

	private void clearOMN20302() throws Exception {
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("actDtm", jsonObject.get("ACT_DTM").toString());
		hmap.put("nmsMgmtNum", jsonObject.get("NMS_MGMT_NUM").toString());
		adamsSession.update("RealtimeUnms.clearOMN20302", hmap);
		adamsSession.commit();
	}

	private void insertOMN20302() throws Exception {
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("mntrDt", jsonObject.get("OCCR_DTM").toString()
				.substring(0, 8));
		hmap.put("mntrDtm", jsonObject.get("OCCR_DTM").toString());
		hmap.put("equipId", jsonObject.get("EQUIP_ID").toString());
		hmap.put("occrDtm", jsonObject.get("OCCR_DTM").toString());
		hmap.put("ocallNum", jsonObject.get("OCALL_NUM").toString());
		hmap.put("icallNum", jsonObject.get("ICALL_NUM").toString());
		hmap.put("routInInfo", jsonObject.get("ROUT_IN_INFO").toString());
		hmap.put("routOutInfo", jsonObject.get("ROUT_OUT_INFO").toString());
		hmap.put("tcStaDtm", jsonObject.get("TC_STA_DTM").toString());
		hmap.put("keepTms", jsonObject.get("KEEP_TMS").toString());
		hmap.put("ltmCallActClCd", jsonObject.get("LTM_CALL_ACT_CL_CD")
				.toString());
		hmap.put("nmsMgmtNum", jsonObject.get("NMS_MGMT_NUM").toString());
		adamsSession.insert("RealtimeUnms.insertOMN20302", hmap);
		adamsSession.commit();
	}

	public void sendLoginPacket() throws Exception {
		logger.info("sendLoginPacket");
		int count = 0;
		byte[] headerPacket = { 0x1b, 0x02, 0x32, 0x30, 0x34, 0x30, 0x30, 0x39,
				0x39, 0x30, 0x31, 0x30, 0x30, 0x30, 0x30
		// , 0x30, 0x30, 0x31, 0x33, 0x39 // body size
		};
		byte[] bodyPacket;
		// String login = "daims_test";
		// password : qwer1234!@
		// String password =
		// "5fbbbd91ecb1cbe2a726b1f53b8fd51b9becfa9e0a4758f21948a363714fc57c1342abdd9300ba51e49c2f1870ed864814275a4085b63d1302adaf2939954d0c";

		String login = this.getLoginId();
		String password = this.getPassword();

		// 20 + 10 + 1 + 128 = 159

		// BodyPacket : login + 0x1f + login + 0x1f + 0x20 + 0x1f + 0x31 + 0x30;
		byte[] bytes;
		int bodySize = login.length() + 1 + password.length() + 1;
		byte[] sendPacket = new byte[headerPacket.length + 5 + bodySize];
		byte[] recvPacket = new byte[100];

		int index = 0;

		// HeaderPacket 복사
		for (; index < headerPacket.length; ++index)
			sendPacket[index] = headerPacket[index];

		// Body Size 복사
		bytes = String.format("%05d", bodySize).getBytes();
		for (int i = 0; i < bytes.length; ++i)
			sendPacket[index++] = bytes[i];

		// login 복사
		bytes = login.getBytes();
		for (int i = 0; i < bytes.length; ++i)
			sendPacket[index++] = bytes[i];
		sendPacket[index++] = UnmsEventFactory.IDENTIFIER;

		// password 복사
		bytes = password.getBytes();
		for (int i = 0; i < bytes.length; ++i)
			sendPacket[index++] = bytes[i];
		sendPacket[index++] = UnmsEventFactory.IDENTIFIER;

		// logger.debug(StringUtils.toHexString(sendPacket));

		equipOutputStream.write(sendPacket);
		equipOutputStream.flush();

		count = equipInputStream.read(recvPacket);
	}

	public void sendLoginPacket2() throws Exception {
		logger.info("sendLoginPacket");

		int bodySize = this.getLoginId().length() + 1
				+ this.getPassword().length() + 1;

		UnmsHeader header = new UnmsHeader();
		header.setPduType(UnmsHeader.PDU_REQUEST);
		header.setServiceCode(UnmsHeader.SVCD_LOGIN);
		header.setMessageSerialNo(UnmsHeader.MSN_DONT_CARE);
		header.setLastYn(UnmsHeader.LAST_N);
		header.setResponseResult(UnmsHeader.RESPONSE_SUCC);
		header.setExtendArea(UnmsHeader.EA_BLANK);
		header.setBodyLength(bodySize);

		header.write(equipOutputStream);

		byte[] body = new byte[bodySize];
		System.arraycopy(this.getLoginId().getBytes(), 0, body, 0, this
				.getLoginId().length());
		body[this.getLoginId().length()] = UnmsEventFactory.IDENTIFIER;
		System.arraycopy(this.getPassword().getBytes(), 0, body, this
				.getLoginId().length() + 1, this.getPassword().length());
		body[this.getLoginId().length() + 1 + this.getPassword().length()] = UnmsEventFactory.IDENTIFIER;

		logger.debug(StringUtils.toHexString(body));

		equipOutputStream.write(body);
		equipOutputStream.flush();

		logger.info(StringUtils.toHexString(body));

		byte[] recvPacket = new byte[100];
		int count = equipInputStream.read(recvPacket);
		logger.info(StringUtils.toHexString(recvPacket, count));
	}

	public void sendRequestPort() throws Exception {
		logger.info("sendRequestPort");
		int count;
		byte[] headerPacket = { 0x1b // ESC
				, 0x02 // STX
				, 0x32 // Request
				, 0x30, 0x33, 0x30, 0x31 // PDU_SVCD_EVENT_PORT
				, 0x39, 0x39 // Don't care
				, 0x30 // 마지막 응답 메시지
				, 0x31 // Success
				, 0x30, 0x30, 0x32, 0x31 // Don't care
				, 0x30, 0x30, 0x30, 0x30, 0x35 };
		byte[] bodyPacket;
		String login = "*****";
		String port;

		// BodyPacket : login
		byte[] loginPacket;
		byte[] sendPacket = new byte[25];
		byte[] recvPacket = new byte[100];

		int index = 0;

		loginPacket = login.getBytes();

		// HeaderPacket 복사
		for (; index < headerPacket.length; ++index)
			sendPacket[index] = headerPacket[index];

		// login 복사
		for (int i = 0; i < loginPacket.length; ++i)
			sendPacket[index++] = loginPacket[i];

		// logger.debug(StringUtils.toHexString(sendPacket));

		equipOutputStream.write(sendPacket);
		count = equipInputStream.read(recvPacket);

		port = new String(recvPacket, 20, 4);
		equipOutputStream.close();
		equipInputStream.close();
		equipSocket.close();

		logger.info("ipAddress : " + equipIpAddress + ".....");
		logger.info("port : " + port + ".....");

		equipSocket = new Socket(equipIpAddress, Integer.parseInt(port));
		equipInputStream = equipSocket.getInputStream();
		equipOutputStream = equipSocket.getOutputStream();
	}

	public void sendRequestPort2() throws Exception {
		String login = "*****";

		UnmsHeader header = new UnmsHeader();
		header.setPduType(UnmsHeader.PDU_REQUEST);
		header.setServiceCode(UnmsHeader.SVCD_EVENT_PORT);
		header.setMessageSerialNo(UnmsHeader.MSN_DONT_CARE);
		header.setLastYn(UnmsHeader.LAST_N);
		header.setResponseResult(UnmsHeader.RESPONSE_SUCC);
		header.setExtendArea(UnmsHeader.EA_DONT_CARE);
		header.setBodyLength(login.length());

		header.write(equipOutputStream);

		byte[] body = new byte[login.length()];
		System.arraycopy(login.getBytes(), 0, body, 0, login.length());
		logger.debug(StringUtils.toHexString(body));

		equipOutputStream.write(body);
		equipOutputStream.flush();

		byte[] recvPacket = new byte[100];
		int count = equipInputStream.read(recvPacket);
		logger.info(StringUtils.toHexString(recvPacket, count));

		String port = new String(recvPacket, 20, 4);
		equipOutputStream.close();
		equipInputStream.close();
		equipSocket.close();

		logger.info("ipAddress : " + equipIpAddress + ", port : " + port);

		equipSocket = new Socket(equipIpAddress, Integer.parseInt(port));
		equipInputStream = equipSocket.getInputStream();
		equipOutputStream = equipSocket.getOutputStream();
	}

	public void keepAliveDB() throws Exception {
		String curDateStr = adamsSession.selectOne(
				"RealtimeUnms.selectSysdate", null);
		logger.info("keepAliveDB:" + curDateStr);
		adamsSession.clearCache();
	}

	public void sendEchoPacket() throws Exception {
		logger.debug("sendEchoPacket");
		UnmsHeader header = new UnmsHeader();
		header.setPduType(UnmsHeader.PDU_REQUEST);
		header.setServiceCode(UnmsHeader.SVCD_ECHO);
		header.setMessageSerialNo(UnmsHeader.MSN_BLANK);
		header.setLastYn(UnmsHeader.LAST_N);
		header.setResponseResult(UnmsHeader.RESPONSE_SUCC);
		header.setExtendArea(UnmsHeader.EA_BLANK);
		header.setBodyLength(0);

		header.write(equipOutputStream);
	}

	protected String getLoginId() {
		return "daims_test";
	}

	protected String getPassword() {
		return "5fbbbd91ecb1cbe2a726b1f53b8fd51b9becfa9e0a4758f21948a363714fc57c1342abdd9300ba51e49c2f1870ed864814275a4085b63d1302adaf2939954d0c";
	}

	protected String getDablGrCd(String str) {
		if (str.equals("1")) { // NMS Warning
			return "02"; // Adams Warning
		} else if (str.equals("2")) { // NMS Minor
			return "03"; // Adams Minor
		} else if (str.equals("3")) { // NMS Major
			return "04"; // Adams Major
		} else if (str.equals("4")) { // NMS Critical
			return "05"; // Adams Critical
		} else {
			return "01";
		}
	}

	protected UnmsIfVerEnum getIfVer() {
		return UnmsIfVerEnum.V1;
	}

	private String getNmsName(UnmsEvent event) {
		String nmsName = event.getNmsName();
		if (nmsName == null && nmsCdMap != null) {
			nmsName = nmsCdMap.get(event.getOrgNmsCd());
		}
		return nmsName;
	}

	private boolean filterMessage(String equipId) {
		boolean flag = false;

		int filterLength = track2Filter.length;

		for (int i = 0; filterLength > i; i++) {
			String filterEquipId = track2Filter[i];

			if (filterEquipId.equals(equipId)) {
				logger.debug("filtering EQUIP_ID : " + equipId);
				return true;
			}
		}

		return flag;
	}

	public static void main(String[] args) {
		EnvManager envManager = new EnvManager(args);
		if (envManager.isValid() == false) {
			HelpFormatter formatter = new HelpFormatter();
			formatter.printHelp("RealTimeCollectUnmsEquip",
					envManager.getOptions());
			System.exit(0);
		}
		new RealTimeCollectUnmsEquip(args);
	}
}
