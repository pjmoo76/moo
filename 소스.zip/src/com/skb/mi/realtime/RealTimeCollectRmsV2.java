package com.skb.mi.realtime;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;

import org.apache.commons.cli.HelpFormatter;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.common.MiscUtils;
import com.skb.mi.model.OMN30100;
import com.skb.mi.model.OMN30110;
import com.skb.mi.model.OMN30112;
import com.skb.mi.model.OMN30203;
import com.skb.mi.realtime.rms.RmsCatvFaultEvent;
import com.skb.mi.realtime.rms.RmsCircuitFaultEvent;
import com.skb.mi.realtime.rms.RmsEquipFaultEvent;
import com.skb.mi.realtime.rms.RmsEvent;
import com.skb.mi.realtime.rms.RmsEventFactory;
import com.skb.mi.thread.SendJsonThread;



public class RealTimeCollectRmsV2 {
	
	final private int			SOCKET_TIME_OUT	= (1000*60*5);	// Time-Out 5분 설정
	
	final private String		NET_CL_CD 			= "04";		// OCO20101 테이블
	final private String		NET_CL_NM 			= "HFC";	// OCO20101 테이블
	final private String		NMS_EQUIP_CD 		= "011";	// OCO20101 테이블
	final private String		NMS_EQUIP_NM 		= "RMS";
	
	final private String		NMS_CD_CATV 		= "032";	// OCO20101 테이블
	final private String		NMS_NM_CATV 		= "RMS_CATV";
	
	final private String		ETC_NET_CL_CD 		= "99";
	final private String		ETC_NET_CL_NM 		= "ETC";

    final private String  		GENERATE_EVENT 		= "GEN";
    final private String  		CLEAR_EVENT 		= "CLR";
    final private String  		INIT_EVENT 		= "INIT";
    final private String  		INIT_END_EVENT 		= "INIT_END";

    final private String  		GENERATED_FAULT_NM 	= "장애중";
    final private String  		CLEARED_FAULT_NM 	= "장애해제";

    final private String  		GENERATED_FAULT_CD 	= "01";
    final private String  		CLEARED_FAULT_CD 	= "02";
	
	final private String        RMS_UNKNOWN_FAULT 	= "210";    // 210: 미파악됨
	final private String        RMS_EQUIP_FAULT 	= "303";    // 303: 장비 장애
    final private String        RMS_CIRCUIT_FAULT 	= "501";   	// 501: 회선 장애

    final private int			SO_TIME_OUT	= (1000*60*5); //5분
    
	// RMS 서버 정보
	Socket						socket;
	InputStream					inputStream;
	OutputStream				outputStream;
	String []                   arrIpAddress;
	String						ipAddress;
	int							portNo;
	String						userId;
	String						authKey;

	HashMap<String, OMN30203>	omn30203Map;
	String						pushIpAddress;
	int							pushPortNo;

	Hashtable<String,String>	dablLclCdList;
	Hashtable<String,String>	dablLclNmList;
	Hashtable<String,String>	dablMclCdList;
	Hashtable<String,String>	dablMclNmList;
	Hashtable<String,String>	dablNmList;
	Hashtable<String,String>	dablCdList;

    private Logger		logger;
	private	SqlSession	adamsSession;
	private	SendJsonThread	jsonSender;
	
	List<OMN30100> initOmn30100List = new ArrayList<OMN30100>();
	
	List<JSONObject> jsonObjectList = new ArrayList<JSONObject>();

    public RealTimeCollectRmsV2 (String [] args) {
    	logger = LogManager.getLogger(this.getClass());
    	logger.setLevel(Level.DEBUG);
    	logger.info("start");
    	
    	loadConfig();

		try {
			adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
			adamsSession.getConnection().setAutoCommit(false);
			readRmsFaultCode();

			jsonSender = new SendJsonThread(pushIpAddress, pushPortNo, false);
			connectNms();
			
			Thread mainThread = new Thread(() -> {
				run();
			});
			
			
			Thread heartbeatThread = new Thread(() -> {
				while(true) {
					try{
						sendPollingPacket();
						Thread.sleep(30000);
					}catch(Exception e){
					}
				}
			});
			
			mainThread.start();
			heartbeatThread.start();

			outputStream.close ();
            inputStream.close ();
            socket.close ();

		} catch (Exception e ) {
			logger.error("Excetion", e);
		}
    }
    
    public void loadConfig() {
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		arrIpAddress = configManager.getConfig(Constants.RMS, Constants.IP_ADDRESS).split(",");		
		portNo = Integer.parseInt(configManager.getConfig(Constants.RMS, Constants.PORT_NO));
		pushIpAddress = configManager.getConfig(Constants.WEB_PUSH, Constants.IP_ADDRESS);
		pushPortNo = Integer.parseInt(configManager.getConfig(Constants.WEB_PUSH, Constants.PORT_NO));
		userId = configManager.getConfig(Constants.RMS, Constants.USER_ID);
		authKey = configManager.getConfig(Constants.RMS, Constants.AUTH_KEY);
		 
		logger.info("ipAddress : " + arrIpAddress[0]);
		logger.info("portNo : " + portNo);
		logger.info("pushIpAddress : " + pushIpAddress);
		logger.info("pushPortNo : " + pushPortNo);    	
    }

	public void connectNms() {
        boolean check = false;
        while (!check) {
        	try {
        		if (inputStream != null) inputStream.close();
        	} catch (Exception e) {
        	}
        	try {
        		if (outputStream != null) outputStream.close();
        	} catch (Exception e) {
        	}
        	try {
        		if (socket != null) socket.close();
        	} catch (Exception e) {
        	}
            try {
            	int arrIpAddressLength = arrIpAddress.length;
            	
            	for(int i=0;arrIpAddressLength>i;i++){
            		String tmpPushIpAddress = arrIpAddress[i];
            		if(ipAddress == null)
            		{
            			ipAddress = arrIpAddress[0];
            			break;
            		}else if(ipAddress.equals(tmpPushIpAddress)){
            			
            			if(i==arrIpAddressLength-1)
            			{
            				ipAddress = arrIpAddress[0];
            				break;            				
            			}else{
            				ipAddress = arrIpAddress[i+1];
            				break;
            			}            			
            		}
            	}
            	
            	
            	logger.info("try connecting " + ipAddress + ":" + portNo);
                socket = new Socket (ipAddress, portNo);
                socket.setSoTimeout(SO_TIME_OUT);
                logger.info("connected " + ipAddress + ":" + portNo);
                
                inputStream = socket.getInputStream();
                outputStream = socket.getOutputStream ();
                
                socket.setSoTimeout(SOCKET_TIME_OUT);
                
                sendInit();
                
                check = true;
            } catch (Exception e) {
                logger.error("Exception", e);
                MiscUtils.sleep(100);            // 0.1초
            }
        }
	}

	// RMS 관련 장애 코드 조회해서 분류별로 Hashtable에 저장한다.
	public void readRmsFaultCode () throws Exception {
		omn30203Map = new HashMap<String, OMN30203>();
		// DABL_LCL_CD, DABL_LCL_NM, DABL_MCL_CD, DABL_MCL_NM, DABL_CD, DABL_CD_NM, CLCT_EVT_ID, CLCT_EVT_CD
		List<OMN30203> omn30203List = (List) adamsSession.selectList("RealtimeRms.selectOMN30203", null);
		for (OMN30203 omn30203 : omn30203List) {
			String key = omn30203.getClctEvtId() + omn30203.getClctEvtCd();
			omn30203Map.put(key, omn30203);
			logger.debug(String.format("(%s),(%s,%s,%s,%s,%s,%s,%s,%s,%s)",
					key,
					omn30203.getDablLclCd(), omn30203.getDablLclNm(), omn30203.getDablMclCd(), omn30203.getDablMclNm(),
					omn30203.getDablCd(), omn30203.getDablCdNm(), omn30203.getClctEvtId(), omn30203.getClctEvtCd(), omn30203.getNmsCatvYn()));
		}
	}
	
    private void run() {
    	
    	RmsEventFactory	eventFactory = new RmsEventFactory();
    	RmsEvent event = null;
        int errContCnt = 0;
        boolean initEnd = false;
		while (true) {
	    	try {
	    		if (adamsSession == null) {
	    			adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
	    			adamsSession.getConnection().setAutoCommit(false);
	    		}
				if (event == null) {
					event = eventFactory.get(inputStream);
					//false에서 true로 변경됬을때 init데이터 적재
					if(!initEnd && eventFactory.getInitEnd()){
						if(initOmn30100List.size() > 0){
			    			insertInitList();
			    		}
					}
 					initEnd = eventFactory.getInitEnd();
					errContCnt = 0;
				} else {
					// retry
					errContCnt ++;
					if (errContCnt > 3) {
						event = null;
						continue;
					}
				}
				if (event != null) {
					process(event, initEnd);
					event = null;
				}
				
			} catch (SocketTimeoutException ste) {
				logger.debug("SocketTimeoutException", ste);
				connectNms();
			} catch (SocketException se) {
				logger.debug("SocketException", se);
				connectNms();
			} catch (SQLException sqle) {
				logger.debug("SQLException", sqle);
				adamsSession.close();
				adamsSession = null;
				MiscUtils.sleep(100);
			} catch (PersistenceException pe) {
				logger.debug("PersistenceException", pe);
				adamsSession.close();
				adamsSession = null;
				MiscUtils.sleep(100);
			} catch (Exception e) {
				logger.debug("Exception", e);
				// 2023-02-20 Song (infinite loop...)
				if ("failed to read".equals(e.getMessage())) {
					MiscUtils.sleep(1000);
					connectNms();
				}
				MiscUtils.sleep(100);
	    	}
        }
    }
    
    private void process(RmsEvent event, boolean initEnd) throws Exception {
    	
    	if ("04".equals(event.getEvtId()) && "90".equals(event.getEvtCode())) return;

    	JSONObject jsonObject = new JSONObject();    	
    	jsonObject.put("DABL_LCL_CD", event.getDablLclCd());
    	jsonObject.put("NMS_CD", NMS_EQUIP_CD);
    	jsonObject.put("NMS_NM", NMS_EQUIP_NM);
    	jsonObject.put("NMS_DABL_NUM_CTT", "" + event.getSerialNo());
    	jsonObject.put("NET_CL_CD", NET_CL_CD);
    	jsonObject.put("NET_CL_NM", NET_CL_NM);
    	
    	
    	String key = event.getEvtId() + event.getEvtCode();
		OMN30203 omn30203 = omn30203Map.get(key);
    	if(omn30203 != null && "Y".equals(omn30203.getNmsCatvYn())){
			jsonObject.put("NMS_CD", NMS_CD_CATV);
	    	jsonObject.put("NMS_NM", NMS_NM_CATV);
		}

    	if ("0".equals(event.getSeverity())) { // 장애해제
    		jsonObject.put("RLSE_DTM", event.getGenTime());
    		jsonObject.put("RLSE_RCV_DTM", MiscUtils.getDateTime());
    		jsonObject.put("DABL_ST_CD", CLEARED_FAULT_CD);
    		jsonObject.put("DABL_ST_NM", CLEARED_FAULT_NM);
    		jsonObject.put("NMS_CD", NMS_EQUIP_CD);
    		jsonObject.put("kind", CLEAR_EVENT);
    	} else { // 장애    		
			jsonObject.put("DABL_ST_CD", GENERATED_FAULT_CD);
    		jsonObject.put("DABL_ST_NM", GENERATED_FAULT_NM);

    		
    		String swingAnnceYn = "N";
    		if (omn30203 == null) {
    			jsonObject.put("DABL_LCL_CD", "*");
    			jsonObject.put("DABL_LCL_NM", "*");
    			jsonObject.put("DABL_MCL_CD", "*"); 
    			jsonObject.put("DABL_MCL_NM", "*");
    			jsonObject.put("DABL_CD", "*");
    			jsonObject.put("DABL_NM", "*");
    		} else {
    			jsonObject.put("DABL_LCL_CD", omn30203.getDablLclCd());
    			jsonObject.put("DABL_LCL_NM", omn30203.getDablLclNm());
    			jsonObject.put("DABL_MCL_CD", omn30203.getDablMclCd());
    			jsonObject.put("DABL_MCL_NM", omn30203.getDablMclNm());
    			jsonObject.put("DABL_CD", omn30203.getDablCd());
    			jsonObject.put("DABL_NM", omn30203.getDablCdNm());
				if (omn30203.getDablCd().equals ("014035")
						|| omn30203.getDablCd().equals ("074006")
						|| omn30203.getDablCd().equals ("074007")
						|| omn30203.getDablCd().equals ("074008")) {
					swingAnnceYn = "Y";
					/* Circuit 장애 규격에 DAMAGE_CUST_CNT 항목 추가됨 (2018.12.17)
					String dmgScrbrCnt = null;
					if (0 <= event.getContent().indexOf ("Offline:")) {
						String	one = event.getContent().substring (event.getContent().indexOf ("Offline:") + 8);
						if (one != null) {
							if (0 <= event.getContent().indexOf ("Offline:")) {
								for (int index = 0; index < one.length (); ++ index) {
									if ('0' <= one.charAt (index) && one.charAt (index) <= '9')
										dmgScrbrCnt += one.charAt (index);
									else
										break;
								}	
							}
						}
					}
					*/
				}
    		}
			jsonObject.put("SWING_ANNCE_YN", swingAnnceYn);
    		jsonObject.put("OCCR_DTM", event.getGenTime());
    		jsonObject.put("OCCR_RCV_DTM", MiscUtils.getDateTime());    		
    		jsonObject.put("DABL_GR_CD", event.getDablGrCd());
    		jsonObject.put("MKT_DIV_ORG_ID", "");
    		jsonObject.put("MKT_DIV_ORG_NM", "");
    		jsonObject.put("TEAM_ORG_ID", "");
    		jsonObject.put("TEAM_ORG_NM", "");
    		jsonObject.put("INFO_CNTR_CD", "");
    		jsonObject.put("INFO_CNTR_NM", "");
    		jsonObject.put("DISTB_CNTR_CD", "");
    		jsonObject.put("DISTB_CNTR_NM", "");
    		jsonObject.put("EQUIP_ID", event.getTid());
    		jsonObject.put("EQUIP_TID_VAL", event.getTid());
    		jsonObject.put("EQUIP_IP_ADDR", event.getSysId());
    		jsonObject.put("EQUIP_NM", event.getSysName());
    		jsonObject.put("EQUIP_MDL_CD", event.getDevType());
			jsonObject.put("DABL_DUP_YN", "");
			// OTX_NUM, CCELL_NUM 값이 || 를 구분자로 2개 이상 들어올 경우, 첫번째 값만 저장
			String otxNum = event.getOtxNo();
			if(otxNum == null || "".equals(otxNum)) {
				logger.info("[SPLIT] (skip) otxNum is null or blank");
			} else {
				logger.info("[SPLIT] (before) otxNum = " + otxNum);
				otxNum = otxNum.split("\\|\\|")[0];
				logger.info("[SPLIT] (after) otxNum = " + otxNum);
			}
			jsonObject.put("OTX_NUM", otxNum);
			
			String ccellNum = event.getCellNo();
			if(ccellNum == null || "".equals(ccellNum)) {
				logger.info("[SPLIT] (skip) ccellNum is null or blank");
			} else {
				logger.info("[SPLIT] (before) ccellNum = " + ccellNum);
				ccellNum = ccellNum.split("\\|\\|")[0];
				logger.info("[SPLIT] (after) ccellNum = " + ccellNum);
			}
			jsonObject.put("CCELL_NUM", ccellNum);
			jsonObject.put("SCARD_NUM_CTT", event.getCardNo());
			try {
				int portNo = Integer.parseInt(event.getPortNo());
				jsonObject.put("PORT_NUM", event.getPortNo());
			} catch (Exception e) {
				jsonObject.put("PORT_NUM", "");
			}
			jsonObject.put("DABL_DESC", event.getContent());

			jsonObject.put("SHSPD_VOC_CNT", ""+event.getVocCount());
			jsonObject.put("SHSPD_INET_DMG_LINE_CNT", ""+event.getInternetCnt());
			jsonObject.put("GNRL_IPTV_DMG_LINE_CNT", ""+event.getCommIptvCnt());
			jsonObject.put("INDPND_IPTV_DMG_LINE_CNT", ""+event.getOnlyIptvCnt());
			jsonObject.put("GNLPH_DMG_LINE_CNT", ""+event.getVoiceCnt());
			jsonObject.put("IPTV_VOC_CNT", ""+event.getIptvVocCnt());
			jsonObject.put("PHON_VOC_CNT", ""+event.getVoiceVocCnt());
			jsonObject.put("TOT_VOC_CNT",""+event.getTotalVocCnt());
			jsonObject.put("VOIP_VOC_CNT", "0");
			jsonObject.put("OPER_DABL_YN", ""+event.getOperDablYn());

			//303
			if (RmsEvent.EVT_EQUIP_FAULT.equals(event.getEvtKind())) {
				RmsEquipFaultEvent equipFaultEvent = (RmsEquipFaultEvent) event;

				jsonObject.put("EQUIP_MDL_NM", equipFaultEvent.getDevTypeName());
				jsonObject.put("DABL_DUP_CNT", "");
				jsonObject.put("DABL_DUP_CNT_1", "1" );
				jsonObject.put("DABL_DUP_CNT_2", "1" );
				jsonObject.put("DABL_DUP_CNT_3", "1" );
				
				jsonObject.put("NET_OP_NUM", "");
				jsonObject.put("EQUIP_SET_LOC_DESC", "");
				jsonObject.put("DMG_SCRBR_CNT", "");
				jsonObject.put("TM_TYP_CD", "");
				jsonObject.put("TM_CTT", "");
				jsonObject.put("INCOMM_BIZR_ID", "");
				jsonObject.put("MODULE_EQUIP_ID", "");
				jsonObject.put("MSC_MODULE_NM", "");
				jsonObject.put("ROUT_NUM", "");
				jsonObject.put("ROUT_NM", "");
				jsonObject.put("DSST_YN", "");
				jsonObject.put("DSSTR_YN", "");
			//901	
			} else if (RmsEvent.EVT_CATV_FAULT.equals(event.getEvtKind())) {
				/* 2022-09-30 CATV 장애 추가  강대윤*/
				
				RmsCatvFaultEvent catvFaultEvent = (RmsCatvFaultEvent) event;
				
				jsonObject.put("EQUIP_MDL_NM", catvFaultEvent.getDevTypeName());
				jsonObject.put("DABL_DUP_CNT", "");
				jsonObject.put("DABL_DUP_CNT_1", "1" );
				jsonObject.put("DABL_DUP_CNT_2", "1" );
				jsonObject.put("DABL_DUP_CNT_3", "1" );
				
				jsonObject.put("NET_OP_NUM", "");
				jsonObject.put("EQUIP_SET_LOC_DESC", "");
				jsonObject.put("DMG_SCRBR_CNT", "");
				jsonObject.put("TM_TYP_CD", "");
				jsonObject.put("TM_CTT", "");
				jsonObject.put("INCOMM_BIZR_ID", "");
				jsonObject.put("MODULE_EQUIP_ID", "");
				jsonObject.put("MSC_MODULE_NM", "");
				jsonObject.put("ROUT_NUM", "");
				jsonObject.put("ROUT_NM", "");
				jsonObject.put("DSST_YN", "");
				jsonObject.put("DSSTR_YN", "");
				
				// 2025.04.22 실시간 장애규격변경
				// - CATV 피해 고객/회선수 관련 항목 추가
				jsonObject.put ("CM_STB_CNT", catvFaultEvent.getCmStbCount());
				jsonObject.put ("TOT_LINE_CNT", catvFaultEvent.getLineTotalCnt());
				jsonObject.put ("INET_LINE_CNT", catvFaultEvent.getLineInternetCount());
				jsonObject.put ("QAM_LINE_CNT", catvFaultEvent.getLineQamCount());
				jsonObject.put ("VSB8_LINE_CNT", catvFaultEvent.getLine8vsbCount());
				jsonObject.put ("TOT_DMG_LINE_CNT", catvFaultEvent.getDmgTotalLineCount());
				jsonObject.put ("INET_DMG_LINE_CNT", catvFaultEvent.getDmgInternetLineCount());
				jsonObject.put ("QAM_DMG_LINE_CNT", catvFaultEvent.getDmgQamLineCount());
				jsonObject.put ("VSB8_DMG_LINE_CNT", catvFaultEvent.getDmg8vsbLineCount());
				jsonObject.put ("TOT_VOC_CNT", ""+catvFaultEvent.getTotalVocCnt());
				jsonObject.put ("TOT_CUST_CNT", catvFaultEvent.getCustTotalCount());
				jsonObject.put ("INET_CUST_CNT", catvFaultEvent.getCustInternetCount());
				jsonObject.put ("QAM_CUST_CNT", catvFaultEvent.getCustQamCount());
				jsonObject.put ("VSB8_CUST_CNT", catvFaultEvent.getCust8vsbCount());
				jsonObject.put ("TOT_DMG_CUST_CNT", catvFaultEvent.getDmgTotalCustCount());
				jsonObject.put ("INET_DMG_CUST_CNT", catvFaultEvent.getDmgInternetCustCount());
				jsonObject.put ("QAM_DMG_CUST_CNT", catvFaultEvent.getDmgQamCustCount());
				jsonObject.put ("VSB8_DMG_CUST_CNT", catvFaultEvent.getDmg8vsbCustCount());
				jsonObject.put ("TB_SO_NM", ""+catvFaultEvent.getCatvSoName());
				jsonObject.put ("CELL_MEMO", ""+catvFaultEvent.getCellMemo());
				
				// 2026.01.06 임은수M 요청사항
				jsonObject.put ("DMG_SCRBR_CNT", ""+catvFaultEvent.getDmgTotalCustCount());
				jsonObject.put ("SCRBR_CNT", ""+catvFaultEvent.getCustTotalCount());
			//501	
			} else if (RmsEvent.EVT_CIRCUIT_FAULT.equals(event.getEvtKind())) {
				RmsCircuitFaultEvent circuitFaultEvent = (RmsCircuitFaultEvent) event;

				jsonObject.put("EQUIP_MDL_NM", "*");
	        	jsonObject.put ("DABL_DUP_CNT", "");
	        	jsonObject.put ("DABL_DUP_CNT_1", "1" );
	        	jsonObject.put ("DABL_DUP_CNT_2", "1" );
	        	jsonObject.put ("DABL_DUP_CNT_3", "1" );
	        	
	        	jsonObject.put ("NET_OP_NUM", "");
	        	jsonObject.put ("EQUIP_SET_LOC_DESC", "");
	        	jsonObject.put ("DMG_SCRBR_CNT", ""+circuitFaultEvent.getDamageCustCnt());
	        	jsonObject.put ("U_ORG_ID", "");
				jsonObject.put ("U_ORG_NM", "");
				jsonObject.put ("L_ORG_ID", "");
				jsonObject.put ("L_ORG_NM", "");
				jsonObject.put ("CUST_NUM", "");
				jsonObject.put ("LINE_NUM", "");
				jsonObject.put ("RING_NUM", "");
				jsonObject.put ("RING_NM", "");
				jsonObject.put ("DSSTR_YN", "");
				// 2018.12.17 실시간 장애규격변경
				// - 장애별 피해 고객/회선수 관련 항목 추가
				// - 2018.12.27 20:00 운용 적용
				jsonObject.put ("SCRBR_CNT", ""+circuitFaultEvent.getTotalCustCnt());
				jsonObject.put ("SHSPD_ACEPT_LINE_CNT", ""+circuitFaultEvent.getInternetLineCnt());
				jsonObject.put ("GNRL_IPTV_ACEPT_LINE_CNT", ""+circuitFaultEvent.getCommIptvLineCnt());
				jsonObject.put ("INDPND_IPTV_ACEPT_LINE_CNT", ""+circuitFaultEvent.getOnlyIptvLineCnt());
				jsonObject.put ("PHON_ACEPT_LINE_CNT", ""+circuitFaultEvent.getVoiceLineCnt());
				jsonObject.put ("DMG_SCRBR_CNT", ""+circuitFaultEvent.getDamageCustCnt());
				jsonObject.put ("DABL_RMK", circuitFaultEvent.getMemo());
				jsonObject.put ("RING_NUM", circuitFaultEvent.getRingId());
				jsonObject.put ("FDF_LINE_NUM", circuitFaultEvent.getFdf());
				jsonObject.put ("CBL_DIST", circuitFaultEvent.getCableDistance());
				
			}
			jsonObject.put ("kind", GENERATE_EVENT);
			jsonObject.put ("DABL_OCCR_LOC_DESC", 
						event.getOtxNo()
						+ "_" + event.getCellNo()
						+ "_" + event.getCardNo()
						+ "_" + event.getPortNo());

    	}
    	logger.info("JSON:" + jsonObject.toString());
    	if(initEnd){
    		jsonSender.put(jsonObject);
    	}else{
    		addInitList(jsonObject);
    	}    	
    }

	public void insertInitList() throws Exception {
		int insertOmn30100Cnt = 0;
		int insertOmn30110Cnt = 0;
		int insertOmn30112Cnt = 0;
		int updateOmn30100Cnt = 0;
		int updateOmn30112Cnt = 0;
		int chunkSize = 1000; // 한 번에 처리할 단위
		try{
			long before;
			long after;
			
			//기존 장애와 비교하여 신규장애만 조회
			logger.info("INIT SIZE: "+initOmn30100List.size());
			logger.info("INIT SIZE: "+initOmn30100List.size());
			before = System.currentTimeMillis();
			adamsSession.clearCache();
			List<OMN30100> insertOmn30100List = new ArrayList<OMN30100>();
			//임시테이블 적재여부
			OMN30100 tmpOmn30100 = adamsSession.selectOne("RealtimeRms.selectTMP_OMN30100_RINK_CNT");
			
			for (int i = 0; i < initOmn30100List.size(); i += chunkSize) {
			    List<OMN30100> chunk = initOmn30100List.subList(i, Math.min(i + chunkSize, initOmn30100List.size()));
			    // chunk 단위로 MyBatis BATCH 처리
			    //신규장애 등록
			    before = System.currentTimeMillis();
			    List<OMN30100> insertOmn30100ChunkList = adamsSession.selectList("RealtimeRms.selectOMN30100", chunk);
			    insertOmn30100List.addAll(insertOmn30100ChunkList);
				after = System.currentTimeMillis();
				logger.info("신규장애 등록 insertOMN30100: prepared elapsed time : " + (after - before)+ "chunk size"+ chunk.size());
				
				before = System.currentTimeMillis();
				//임시테이블 데이터 적재
				if(tmpOmn30100 != null){
					Integer rmsLinkCnt = tmpOmn30100.getRmsLinkCnt();
					chunk.forEach(omn30100 -> omn30100.setRmsLinkCnt(rmsLinkCnt));
					adamsSession.insert("RealtimeRms.insertTMP_OMN30100", chunk);
				}
				after = System.currentTimeMillis();
				logger.info("임시테이블 등록 insertTMP_OMN30100: prepared elapsed time : " + (after - before)+ "chunk size"+ chunk.size());
			}
			
			after = System.currentTimeMillis();
			logger.info("신규장애 조회 : prepared elapsed time : " + (after - before));
			//신규장애 등록
			if(insertOmn30100List != null && insertOmn30100List.size() > 0){
				logger.info("신규장애 등록 SIZE: "+insertOmn30100List.size());
				logger.info("신규장애 등록 SIZE: "+insertOmn30100List.size());
				
				for (int i = 0; i < insertOmn30100List.size(); i += chunkSize) {
				    List<OMN30100> chunk = insertOmn30100List.subList(i, Math.min(i + chunkSize, insertOmn30100List.size()));
				    // chunk 단위로 MyBatis BATCH 처리
				    //신규장애 등록
				    before = System.currentTimeMillis();
					insertOmn30100Cnt += adamsSession.insert("RealtimeRms.insertOMN30100", chunk);
					after = System.currentTimeMillis();
					logger.info("신규장애 등록 insertOMN30100: prepared elapsed time : " + (after - before)+ "chunk size"+ chunk.size());
				}
				
				List<OMN30110> insertOMN30110List = createOMN30110List(insertOmn30100List, jsonObjectList);
				if(insertOMN30110List != null && insertOMN30110List.size() > 0){
					for (int i = 0; i < insertOMN30110List.size(); i += chunkSize) {
					    List<OMN30110> chunk = insertOMN30110List.subList(i, Math.min(i + chunkSize, insertOMN30110List.size()));
					    // chunk 단위로 MyBatis BATCH 처리
					    //신규장애 등록
					    before = System.currentTimeMillis();
					    insertOmn30110Cnt += adamsSession.insert("RealtimeRms.insertOMN30110", chunk);
						after = System.currentTimeMillis();
						logger.info("신규장애 등록 insertOMN30110: prepared elapsed time : " + (after - before)+ "chunk size"+ chunk.size());
					}
				}
				
				List<OMN30112> insertOMN30112List = createOMN30112List(insertOmn30100List, jsonObjectList);
				if(insertOMN30112List != null && insertOMN30112List.size() > 0){
					for (int i = 0; i < insertOMN30112List.size(); i += chunkSize) {
					    List<OMN30112> chunk = insertOMN30112List.subList(i, Math.min(i + chunkSize, insertOMN30112List.size()));
					    // chunk 단위로 MyBatis BATCH 처리
					    //신규장애 등록
					    before = System.currentTimeMillis();
					    insertOmn30112Cnt += adamsSession.insert("RealtimeRms.insertOMN30112", chunk);
						after = System.currentTimeMillis();
						logger.info("신규장애 등록 insertOMN30112: prepared elapsed time : " + (after - before)+ "chunk size"+ chunk.size());
					}
				}
		    	
		    	//신규 장애 UI에 소켓 전달
				/*(추후 UI 소켓으로 전송)
				for(OMN30100 oMN30100 : insertOmn30100List){
					String nmsDablNumCtt = oMN30100.getNmsDablNumCtt();
					if(nmsDablNumCtt != null){
						JSONObject jsonObject = jsonObjectList.stream().filter(obj -> nmsDablNumCtt.equals(obj.get("NMS_DABL_NUM_CTT"))).findFirst().orElse(null);
						if(jsonObject != null){
							JSONObject newJsonObject = setEquipInfo(oMN30100, jsonObject);
							jsonSender.put(newJsonObject);
						}
					}
				}
				*/
			}
			
			//장애 해제
			
			if(initOmn30100List != null && initOmn30100List.size() > 0){
				//기존장애 전체조회
				List<OMN30100> faultOmn30100List  = adamsSession.selectList("RealtimeRms.selectFaultOMN30100");
				logger.info("기존장애 전체 SIZE: "+faultOmn30100List.size());
				logger.info("기존장애 전체 SIZE: "+faultOmn30100List.size());
				
				if(faultOmn30100List != null && faultOmn30100List.size() > 0){
					
					//해제 목록(추후 UI 소켓으로 전송)
					List<OMN30100> clearedOmn30100List = filterListData(faultOmn30100List, initOmn30100List);
					List<OMN30100> clearedOmn30112List = filterCatvListData(faultOmn30100List, initOmn30100List);
					logger.info("해제 목록 OMN30100 SIZE: "+clearedOmn30100List.size());
					logger.info("해제 목록 OMN30100 SIZE: "+clearedOmn30100List.size());
					if(clearedOmn30100List != null && clearedOmn30100List.size() > 0){
						for (int i = 0; i < clearedOmn30100List.size(); i += chunkSize) {
						    List<OMN30100> chunk = clearedOmn30100List.subList(i, Math.min(i + chunkSize, clearedOmn30100List.size()));
						    // chunk 단위로 MyBatis BATCH 처리
						    //기존장애 해제처리
						    before = System.currentTimeMillis();
						    updateOmn30100Cnt += adamsSession.insert("RealtimeRms.updateOMN30100", chunk);
						    after = System.currentTimeMillis();
						    logger.info("기존장애 해제처리 OMN30100: prepared elapsed time : " + (after - before)+ "chunk size"+ chunk.size());
						}
					}
					
					logger.info("해제 목록 OMN30112 SIZE: "+clearedOmn30112List.size());
					logger.info("해제 목록 OMN30112 SIZE: "+clearedOmn30112List.size());
					if(clearedOmn30112List != null && clearedOmn30112List.size() > 0){
						for (int i = 0; i < clearedOmn30112List.size(); i += chunkSize) {
						    List<OMN30100> chunk = clearedOmn30112List.subList(i, Math.min(i + chunkSize, clearedOmn30112List.size()));
						    // chunk 단위로 MyBatis BATCH 처리
						    //기존장애 해제처리
						    before = System.currentTimeMillis();
						    updateOmn30112Cnt += adamsSession.insert("RealtimeRms.updateOMN30112", chunk);
						    after = System.currentTimeMillis();
						    logger.info("기존장애 해제처리 OMN30112: prepared elapsed time : " + (after - before)+ "chunk size"+ chunk.size());
						}
					}
				}
			}
			
			initOmn30100List.clear();
	    	adamsSession.commit();
			jsonObjectList.clear();
			
		}catch(Exception e){
			
			initOmn30100List.clear();
			jsonObjectList.clear();
			adamsSession.rollback();
			logger.error("RealTimeCollectRmsV2 : insertInitList Exception : " + e);
		}
	}
	
	public List<OMN30110> createOMN30110List(List<OMN30100> insertOmn30100List, 
	            													List<JSONObject> jsonObjectList) throws Exception {
	        
		  	List<OMN30110> oMN30110List = new ArrayList<OMN30110>();
	        for(OMN30100 oMN30100 : insertOmn30100List){
				String nmsDablNumCtt = oMN30100.getNmsDablNumCtt();
				if(nmsDablNumCtt != null){
					JSONObject jsonObject = jsonObjectList.stream().filter(obj -> nmsDablNumCtt.equals(obj.get("NMS_DABL_NUM_CTT"))).findFirst().orElse(null);
					if(jsonObject != null){
						OMN30110 oMN30110 = createOMN30110(jsonObject, oMN30100);
						oMN30110List.add(oMN30110);
					}
				}
			}

	        return oMN30110List;
    }
	
	public List<OMN30112> createOMN30112List(List<OMN30100> insertOmn30100List, 
            														List<JSONObject> jsonObjectList) throws Exception {
        
	  	List<OMN30112> oMN30112List = new ArrayList<OMN30112>();
        for(OMN30100 oMN30100 : insertOmn30100List){
			String nmsDablNumCtt = oMN30100.getNmsDablNumCtt();
			String nmsCd = oMN30100.getNmsCd();
			if(nmsDablNumCtt != null && NMS_CD_CATV.equals(nmsCd)){
				JSONObject jsonObject = jsonObjectList.stream().filter(obj -> nmsDablNumCtt.equals(obj.get("NMS_DABL_NUM_CTT"))).findFirst().orElse(null);
				if(jsonObject != null){
					OMN30112 oMN30112 = createOMN30112(jsonObject, oMN30100);
					oMN30112List.add(oMN30112);
				}
			}
		}

        return oMN30112List;
	}
	
	public OMN30112 createOMN30112(JSONObject jsonObject, OMN30100 oMN30100) throws Exception {
		
		
		OMN30112 oMN30112 = new OMN30112();
		oMN30112.setDablNum(oMN30100.getDablNum());
		oMN30112.setAuditId(oMN30100.getAuditId());
		oMN30112.setCmStbCnt(((Number) jsonObject.get("CM_STB_CNT")).longValue());
		oMN30112.setTotLineCnt(((Number) jsonObject.get("TOT_LINE_CNT")).longValue());
		oMN30112.setInetLineCnt(((Number) jsonObject.get("INET_LINE_CNT")).longValue());
		oMN30112.setQamLineCnt(((Number) jsonObject.get("QAM_LINE_CNT")).longValue());
		oMN30112.setVsb8LineCnt(((Number) jsonObject.get("VSB8_LINE_CNT")).longValue());
		oMN30112.setTotDmgLineCnt(((Number) jsonObject.get("TOT_DMG_LINE_CNT")).longValue());
		oMN30112.setInetDmgLineCnt(((Number) jsonObject.get("INET_DMG_LINE_CNT")).longValue());
		oMN30112.setQamDmgLineCnt(((Number) jsonObject.get("QAM_DMG_LINE_CNT")).longValue());
		oMN30112.setVsb8DmgLineCnt(((Number) jsonObject.get("VSB8_DMG_LINE_CNT")).longValue());
		oMN30112.setTotVocCnt((String) jsonObject.get("TOT_VOC_CNT"));
		oMN30112.setTotCustCnt(((Number) jsonObject.get("TOT_CUST_CNT")).longValue());
		oMN30112.setInetCustCnt(((Number) jsonObject.get("INET_CUST_CNT")).longValue());
		oMN30112.setQamCustCnt(((Number) jsonObject.get("QAM_CUST_CNT")).longValue());
		oMN30112.setVsb8CustCnt(((Number) jsonObject.get("VSB8_CUST_CNT")).longValue());
		oMN30112.setTotDmgCustCnt(((Number) jsonObject.get("TOT_DMG_CUST_CNT")).longValue());
		oMN30112.setInetDmgCustCnt(((Number) jsonObject.get("INET_DMG_CUST_CNT")).longValue());
		oMN30112.setQamDmgCustCnt(((Number) jsonObject.get("QAM_DMG_CUST_CNT")).longValue());
		oMN30112.setVsb8DmgCustCnt(((Number) jsonObject.get("VSB8_DMG_CUST_CNT")).longValue());
		oMN30112.setTbSoNm((String) jsonObject.get("TB_SO_NM"));
		oMN30112.setCellMemo((String) jsonObject.get("CELL_MEMO"));
		oMN30112.setNmsDablNumCtt((String) jsonObject.get("NMS_DABL_NUM_CTT"));
		oMN30112.setDablCd((String) jsonObject.get("DABL_CD"));
		oMN30112.setDablStCd((String) jsonObject.get("DABL_ST_CD"));
		oMN30112.setDablGrCd((String) jsonObject.get("DABL_GR_CD"));
		oMN30112.setOccrDtm((String) jsonObject.get("OCCR_DTM"));
		oMN30112.setOccrRcvDtm((String) jsonObject.get("OCCR_RCV_DTM"));
		oMN30112.setEquipId((String) jsonObject.get("EQUIP_ID"));
		oMN30112.setCcellNum((String) jsonObject.get("CCELL_NUM"));
		oMN30112.setScardNumCtt((String) jsonObject.get("SCARD_NUM_CTT"));
		oMN30112.setPortNum((String) jsonObject.get("PORT_NUM"));
		
		return oMN30112;
	}
	  
	public OMN30110 createOMN30110(JSONObject jsonObject, OMN30100 oMN30100) throws Exception {
			OMN30110 oMN30110 = new OMN30110();
			oMN30110.setDablNum(oMN30100.getDablNum());
			oMN30110.setAuditId(oMN30100.getAuditId());
			oMN30110.setCoVipCustYn((String) jsonObject.get("CO_VIP_CUST_YN"));
			oMN30110.setEquipId(oMN30100.getEquipId());
			oMN30110.setOtxNum((String) jsonObject.get("OTX_NUM"));
			oMN30110.setCcellNum((String) jsonObject.get("CCELL_NUM"));
			oMN30110.setScardNumCtt((String) jsonObject.get("SLOT_NUM"));
			oMN30110.setPortNum((String) jsonObject.get("PORT_NUM"));
			
			String routNum = (String) jsonObject.get("ROUT_NUM");
			String routInfo;
			if(routNum == null) {
				routInfo = "";
			}else{
				routInfo = routNum;
				if (routNum.length() > 6) {
					routNum = "";
				}
			}
			
			oMN30110.setRoutNum(routNum);
			oMN30110.setModuleEquipId((String) jsonObject.get("MODULE_EQUIP_ID"));
			oMN30110.setMscModuleTypCd((String) jsonObject.get("MSC_MODULE_TYP_CD"));
			oMN30110.setMscModuleNm((String) jsonObject.get("MSC_MODULE_NM"));
			oMN30110.setIncommBizrNm((String) jsonObject.get("INCOMM_BIZR_NM"));
			oMN30110.setTmId((String) jsonObject.get("TM_ID"));
			oMN30110.setProcId((String) jsonObject.get("MAIN_PROC"));
			oMN30110.setSubProcId((String) jsonObject.get("SUB_PROC"));
			oMN30110.setSupEquipIpAddr((String) jsonObject.get("SUP_EQUIP_IP_ADDR"));
			oMN30110.setSupEquipNm((String) jsonObject.get("SUP_EQUIP_NM"));
			oMN30110.setSupEquipIfPortNm((String) jsonObject.get("SUP_EQUIP_IF_PORT_NM"));
			oMN30110.setSupEquipIfAlsNm((String) jsonObject.get("SUP_EQUIP_IF_ALS_NM"));
			oMN30110.setRingNm((String) jsonObject.get("RING_NM"));
			oMN30110.setDablLocNm((String) jsonObject.get("DABL_LOC_NM"));
			oMN30110.setSbnmsEquipNm((String) jsonObject.get("SBNMS_EQUIP_NM"));
			oMN30110.setRoutInfo(routInfo);
			oMN30110.setCustChrticCd((String) jsonObject.get("CUST_CHRTIC_CD"));
			oMN30110.setShspdAceptLineCnt((String) jsonObject.get("SHSPD_ACEPT_LINE_CNT"));
			oMN30110.setGnrlIptvAceptLineCnt((String) jsonObject.get("GNRL_IPTV_ACEPT_LINE_CNT"));
			oMN30110.setIndpndIptvAceptLineCnt((String) jsonObject.get("INDPND_IPTV_ACEPT_LINE_CNT"));
			oMN30110.setPhonAceptLineCnt((String) jsonObject.get("PHON_ACEPT_LINE_CNT"));
			oMN30110.setRingNum((String) jsonObject.get("RING_NUM"));
			oMN30110.setFdfLineNum((String) jsonObject.get("FDF_LINE_NUM"));
			oMN30110.setCblDist((String) jsonObject.get("CBL_DIST"));
			
			return oMN30110;
		}
	  
	  public List<OMN30100> filterListData(List<OMN30100> fullList, 
	            											List<OMN30100> filterList) {

	        // filterList를 HashSet으로 변환 (NMS_DABL_NUM_CTT 기준)
	        Set<String> filterSet = new HashSet<>();
	        for (OMN30100 vo : filterList) {
	            filterSet.add(vo.getNmsDablNumCtt());
	        }

	        // fullList에서 filterSet에 없는 것만 추출
	        List<OMN30100> result = new ArrayList<>();
	        for (OMN30100 vo : fullList) {
	            if (!filterSet.contains(vo.getNmsDablNumCtt())) {
	                result.add(vo);
	            }
	        }

	        return result;
	  }
	  
	  public List<OMN30100> filterCatvListData(List<OMN30100> fullList, 
	            												  List<OMN30100> filterList) {

	        // filterList를 HashSet으로 변환 (NMS_DABL_NUM_CTT 기준)
	        Set<String> filterSet = new HashSet<>();
	        for (OMN30100 vo : filterList) {
	            filterSet.add(vo.getNmsDablNumCtt());
	        }

	        // fullList에서 filterSet에 없는 것만 추출
	        List<OMN30100> result = new ArrayList<>();
	        for (OMN30100 vo : fullList) {
	            if (!filterSet.contains(vo.getNmsDablNumCtt()) && NMS_CD_CATV.equals(vo.getNmsCd())) {
	                result.add(vo);
	            }
	        }

	        return result;
	  }

	
	public JSONObject setEquipInfo(OMN30100 oMN30100, JSONObject jsonObject) {
		
			String equipMdlNm = oMN30100.getEquipMdlNm();
			jsonObject.put ("EQUIP_ID", oMN30100.getEquipId());
			jsonObject.put ("EQUIP_NM", oMN30100.getEquipNm());
			jsonObject.put ("TPO_CD", oMN30100.getDistbCntrCd());
			jsonObject.put ("TPO_NM", oMN30100.getDistbCntrNm());
			jsonObject.put ("DISTB_CNTR_CD", oMN30100.getDistbCntrCd());
			jsonObject.put ("DISTB_CNTR_NM", oMN30100.getDistbCntrNm());
			jsonObject.put ("EQUIP_IP_ADDR", oMN30100.getEquipIpAddr());
			jsonObject.put ("EQUIP_MDL_CD", oMN30100.getEquipMdlCd());
			if (equipMdlNm != null && !equipMdlNm.equals("")) {
				jsonObject.put ("EQUIP_MDL_NM", equipMdlNm);
			}
			jsonObject.put ("EQUIP_SET_LOC_DESC", oMN30100.getEquipSetLocDesc());
			jsonObject.put ("MGMT_TPO_CD", oMN30100.getInfoCntrCd());
			jsonObject.put ("MGMT_TPO_NM", oMN30100.getInfoCntrNm());
			jsonObject.put ("INFO_CNTR_NM", oMN30100.getInfoCntrNm());
			jsonObject.put ("INFO_CNTR_CD", oMN30100.getInfoCntrCd());
			jsonObject.put ("TEAM_ID", oMN30100.getTeamId());
			jsonObject.put ("TEAM_NM", oMN30100.getTeamNm());
			jsonObject.put ("DIV_ID", oMN30100.getDivId());
			jsonObject.put ("DIV_NM", oMN30100.getDivNm());
			jsonObject.put ("EQUIP_MDL_TYP_CD", oMN30100.getEquipMdlTypCd());
			jsonObject.put ("EQUIP_MDL_TYP_NM", oMN30100.getEquipMdlTypNm());
			jsonObject.put ("EQUIP_TID_VAL", oMN30100.getEquipTidVal());
			
			return jsonObject;
	}
	
	public OMN30100 createOMN30100(JSONObject jsonObject) throws Exception {
		OMN30100 oMN30100 = new OMN30100();
		oMN30100.setAuditId("admin");
		oMN30100.setDablNm((String) jsonObject.get("DABL_NM"));
		oMN30100.setNmsCd((String) jsonObject.get("NMS_CD"));
		oMN30100.setNetClCd((String) jsonObject.get("NET_CL_CD"));
		oMN30100.setDablLclCd((String) jsonObject.get("DABL_LCL_CD"));
		oMN30100.setDablStCd((String) jsonObject.get("DABL_ST_CD"));
		oMN30100.setDablGrCd((String) jsonObject.get("DABL_GR_CD"));
		oMN30100.setOperDablYn((String) jsonObject.get("OPER_DABL_YN"));
		oMN30100.setDablNetClCd("1");
		oMN30100.setNmsDablNumCtt((String) jsonObject.get("NMS_DABL_NUM_CTT"));
		oMN30100.setOccrDtm((String) jsonObject.get("OCCR_DTM"));
		oMN30100.setOccrRcvDtm((String) jsonObject.get("OCCR_RCV_DTM"));
		oMN30100.setEquipId((String) jsonObject.get("EQUIP_ID"));
		oMN30100.setEquipNm((String) jsonObject.get("EQUIP_NM"));
		oMN30100.setDablDesc((String) jsonObject.get("DABL_DESC"));
		oMN30100.setDablMclCd((String) jsonObject.get("DABL_MCL_CD"));
		oMN30100.setDablCd((String)jsonObject.get("DABL_CD"));
		oMN30100.setDablOccrLocDesc((String) jsonObject.get("DABL_OCCR_LOC_DESC"));
		oMN30100.setEquipDablMsgCtt((String) jsonObject.get("EQUIP_DABL_MSG_CTT"));
		oMN30100.setEquipDablSmryCtt((String) jsonObject.get("NMS_ALARM_NO"));
		oMN30100.setNetOpNum((String) jsonObject.get("NET_OP_NUM"));
		oMN30100.setDmgScrbrCnt((String) jsonObject.get("DMG_SCRBR_CNT"));
		oMN30100.setDablPortDesc((String) jsonObject.get("DABL_PORT_DESC"));
		oMN30100.setPortAlsNm((String) jsonObject.get("PORT_ALS_NM"));
		oMN30100.setDablCdSerNum((String) jsonObject.get("DABL_CD_SER_NUM"));
		oMN30100.setVocCnt((String) jsonObject.get("VOC_CNT"));
		oMN30100.setSwingAnnceYn("N");
		oMN30100.setDablConsItmDesc((String) jsonObject.get("EQUIP_MDL_NM"));
		oMN30100.setNmsDablCd((String) jsonObject.get("NMS_DABL_CD"));
		oMN30100.setTrmsNetMgmtOwnrCd((String) jsonObject.get("TRMS_NET_MGMT_OWNR_CD"));
		oMN30100.setSktOrgNm(null);
		oMN30100.setScrbrCnt((String) jsonObject.get("SCRBR_CNT"));
		oMN30100.setDablRmk((String) jsonObject.get("DABL_RMK"));
		oMN30100.setEquipTidVal((String) jsonObject.get("EQUIP_TID_VAL"));
		
		return oMN30100;
	}
	
	public void addInitList(JSONObject jsonObject) throws Exception {
		OMN30100 oMN30100 = createOMN30100(jsonObject);
		
		String dablStCd = oMN30100.getDablStCd();
		if(GENERATED_FAULT_CD.equals(dablStCd)){
			jsonObjectList.add(jsonObject);
			initOmn30100List.add(oMN30100);
		}
	}

    public void sendInit() throws Exception {
    	
		byte [] dataPacket0 = {
				0x1b,0x02,
				0x52,0x4e,0x4d,0x53,0x1f, // "RNMS"
				0x49,0x4e,0x49,0x54, // "INIT"
				//0x4e,0x4f,0x4c,0x4f,0x41,0x44, // "NOLOAD"
				0x1f   
		};
		byte [] userId = this.userId.getBytes();
		byte [] dataPacket1 ={
				 0x1f //userid				 
				 ,0x30,0x1f                 //usertype
				 ,0x30,0x1f                 //iptv관할지역
				 ,0x30,0x1f                 //catv관할지역
				 ,0x30,0x1f                 //iptv분배센터
				 ,0x30,0x1f                 //catv분배센터
		};
		byte [] authKey = this.authKey.getBytes();
		byte [] dataPacket2 ={
				  0x1f
				 ,0x1b
				 ,0x03
		};
		 
		 byte [] sendPacket = new byte[dataPacket0.length +
		                               userId.length +
		                               dataPacket1.length +
		                               authKey.length +
		                               dataPacket2.length + 1] ;
		 
		 int sendIndex = 0;
		 
		 for(;sendIndex<dataPacket0.length;sendIndex++)
		 {
			 sendPacket[sendIndex] =  dataPacket0[sendIndex];
		 }
		 
		 for(int i=0;i<userId.length;i++)
		 {
			 sendPacket[sendIndex++] =  userId[i];
		 }
		 
		 for(int i=0;i<dataPacket1.length;i++)
		 {
			 sendPacket[sendIndex++] =  dataPacket1[i];
		 }
		 
		 for(int i=0;i<authKey.length;i++)
		 {
			 sendPacket[sendIndex++] =  authKey[i];
		 }
		 
		 for(int i=0;i<dataPacket2.length;i++)
		 {
			 sendPacket[sendIndex++] =  dataPacket2[i];
		 }
		
		outputStream.write(sendPacket);
		logger.info("send init packet" + sendPacket.length);
	}
    
    public void sendPollingPacket() throws Exception {
        byte [] packet = {
        				 0x1b,0x02,
        				 0x52,0x4e,0x4d,0x53,0x1f,  // "RNMS"
        				 0x48,0x45,0x41,0x52,0x54,0x42,0x45,0x41,0x54,0x1f, // "HEARTBEAT"
        				 0x1b,0x03
        				 };
		outputStream.write(packet);
		outputStream.flush();
		logger.info("send polling packet");
    }
    
	public static void main (String [] args) {
//		if (args.length != 1) {
//			System.out.println ("사용법 : ./run RealtimeCollectRms 절대path");
//			System.exit (0);
//		}
		
		
    	EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("RealTimeCollectRms", envManager.getOptions());
    		System.exit(0);
    	}
        new RealTimeCollectRmsV2 (args);
    }
}



