package com.skb.mi.realtime;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketException;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.skb.mi.common.MiscUtils;
import com.skb.mi.common.SockUtils;
import com.skb.mi.common.StringUtils;


public class TeamsSocketTest {
	
	private static final String SERVER_IP = "12.4.5.165";
	private static final int SERVER_PORT = 3104;
	static public final byte 	IDENTIFIER		= 0x1f;
	static public final String	CHARSET_NAME	= "EUC-KR";
	static public String	MANUAL_CLEAR	= "0450"; 

	final int	HEADER_LEN	= 20;
	final byte	ESC = 0x1b;
	final byte	STX = 0x02;				// Start of Text
	private	byte[]	header;
	final char	PDU_EVENT		= '1';	// 0x31
	final char	PDU_REQUEST		= '2';	// 0x32
	final char	PDU_RESPONSE	= '3';	// 0x33
	
	private Logger		logger;
	Socket socket;
	BufferedReader br;
    PrintWriter pw;
    OutputStream outputStream;
    InputStream inputStream;
    
	public TeamsSocketTest () {
		 logger = LogManager.getLogger(TeamsSocketTest.class.getName());
	     logger.debug("start");
	     long nextEchoTime = (System.currentTimeMillis() / 1000L) + (60*3);
	     this.header = new byte[HEADER_LEN];
	     
	     connectNms();
	    // TeamsEventFactory eventFactory = new TeamsEventFactory();
	     
	     while (true) {
	    	
			try {
				get(inputStream);
				long currentTime = System.currentTimeMillis() / 1000L;
				
				if (nextEchoTime < currentTime) {
					this.sendEchoPacket();
					nextEchoTime = currentTime + (60*3);
				}
			} catch (SocketException e) {
				// TODO Auto-generated catch block
				logger.debug("Exception"+e);
				connectNms();
			}catch (Exception e) {
				// TODO: handle exception
				logger.debug("Exception");
				e.printStackTrace();
			}
	    	 
	     }
	}
	 public static void main (String [] args) {  		

		 new TeamsSocketTest();
		
	}  
	 
	
	 public void connectNms() {
	        boolean check = false;
	        while (!check) {
	        	try {
	        		if (inputStream != null) inputStream.close();
	        	} catch (Exception e) {
	        	}
	        	try {
	        		if (inputStream != null) outputStream.close();
	        	} catch (Exception e) {
	        	}
	        	try {
	        		if (socket != null) socket.close();
	        	} catch (Exception e) {
	        	}
	            try {
	            	logger.info("try connecting " + SERVER_IP + ":" + SERVER_PORT);
	                socket = new Socket (SERVER_IP, SERVER_PORT);
	                logger.info("connected " + SERVER_IP + ":" + SERVER_PORT);

	                //br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
	                outputStream = socket.getOutputStream ();
	                inputStream = socket.getInputStream();
	                logger.info("sending loginPacket ");
	                outputStream.write(makeLoginPacket ());
	                outputStream.flush();
	                logger.info("end loginPacket ");
	                check = true;
	            } catch (Exception e) {
	                logger.error("Exception", e);
	                MiscUtils.sleep(100);            // 0.1초
	            }
	        }
		}
	 
	 private byte [] makeLoginPacket() throws Exception {
			byte [] headerPacket = {0x1b, 0x02, 0x32, 0x30, 0x30, 
							  		0x30, 0x35, 0x30, 0x30, 0x30, 		// 0x35 : 로긴 요청
							  		0x31, 0x30, 0x30, 0x30, 0x30, 
							  		0x30, 0x30, 0x30, 0x33, 0x35
			};
			byte [] bodyPacket;
			String	login = "NmsConnect";

			// BodyPacket : login + 0x1f + login + 0x1f + 0x20 + 0x1f + 0x31 + 0x30;
			byte [] loginPacket;
			byte [] sendPacket = new byte [55];

			int		index = 0;

			loginPacket = login.getBytes();	

			// HeaderPacket 복사
			for (; index < headerPacket.length; ++ index)
				sendPacket [index] = headerPacket [index];

			// login 복사
			for (int i = 0; i < loginPacket.length; ++ i)
				sendPacket [index ++] = loginPacket [i];
			sendPacket [index ++] = IDENTIFIER; 

			// password 복사
			for (int i = 0; i < loginPacket.length; ++ i)
				sendPacket [index ++] = loginPacket [i];
			sendPacket [index ++] = IDENTIFIER; 

			// Black 및 '10'복사
			sendPacket [index ++] = (byte) 0x30;			// 모든 장애 표시
			sendPacket [index ++] = (byte) 0x30;			// 모든 장애 표시
			sendPacket [index ++] = (byte) 0x30;			// 모든 장애 표시
			sendPacket [index ++] = (byte) 0x30;			// 모든 장애 표시
			sendPacket [index ++] = (byte) 0x30;			// 모든 장애 표시

			sendPacket [index ++] = (byte) 0x30;			// 모든 장애 표시
			sendPacket [index ++] = (byte) 0x30;			// 모든 장애 표시
			sendPacket [index ++] = (byte) 0x30;			// 모든 장애 표시
			sendPacket [index ++] = (byte) 0x30;			// 모든 장애 표시
			sendPacket [index ++] = (byte) 0x30;			// 모든 장애 표시
			sendPacket [index ++] = IDENTIFIER;

			sendPacket [index ++] = 0x31;					// '1'

			return sendPacket;
			
		}
	 	public void sendEchoPacket() throws Exception {
			logger.debug("sendEchoPacket");
			byte [] headerPacket = {0x1b, 0x02, 0x32, 0x30, 0x30, 
							  		0x30, 0x30, 0x30, 0x30, 0x30, 		// 0x30 : ECHO패킷 
							  		0x31, 0x30, 0x30, 0x30, 0x30, 
							  		0x30, 0x30, 0x30, 0x30, 0x30
			};

			outputStream.write(headerPacket);
			outputStream.flush();
			logger.debug("sent EchoPacket");
		}
	 	
	 	public void get(InputStream is) throws Exception {
			logger.debug("reading...");
			/*
			 * ESC				: 1 byte
			 * STX				: 1 byte
			 * PduType			: 1 byte (1: Event, 2: Request, 3: Response)
			 * ServiceCode		: 4 byte
			 * messageSerialNo	: 2 byte
			 * lastYn			: 1 byte
			 * responseResult	: 1 byte
			 * extendArea		: 4 byte
			 * bodyLength		: 5 byte
			 */
			//int len = is.read(header);
			int len = SockUtils.read(is, header, header.length);
			if (len != HEADER_LEN) {
				throw new Exception(String.format("failed to read header (%d,%d)", HEADER_LEN, len));
			}
			logger.debug(StringUtils.toHexString(header));
			logger.debug(StringUtils.toReadableString(header));

			if (header[0] != ESC) {
				throw new Exception("header[0] is not ESC");
			}
			if (header[1] != STX) {
				throw new Exception("header[1] is not STX");
			}
			char pduType = (char) header[2];
			if (pduType != PDU_EVENT && pduType != PDU_REQUEST && pduType != PDU_RESPONSE) {
				throw new Exception("invalid pduType : " + pduType);
			}
			String serviceCode = new String(StringUtils.getBytes(header, 3, 4));
			int bodyLength = Integer.parseInt(new String(StringUtils.getBytes(header, 15, 5)));

			byte[] body = new byte[bodyLength];
			//len = is.read(body);
			len = SockUtils.read(is, body, body.length);
			if (len != bodyLength) {
				throw new Exception(String.format("failed to read body (%d,%d)", bodyLength, len));
			}
			logger.debug(String.format("(serviceCode=%s),(bodyLength=%d)", serviceCode, bodyLength));
			
			
			if (MANUAL_CLEAR.equals(serviceCode)) {
				// 다수의 장애수동해제정보가 존재함. 각각의 장애정보는 '^' 로 구분됨.
				logger.debug(new String(body, 0, body.length, CHARSET_NAME));
				
			} else {
				String[] items = StringUtils.split(body, IDENTIFIER, CHARSET_NAME);
				for (int i = 0; i < items.length; i ++) {
					logger.debug(String.format("[%d]%s", i, items[i]));
				}
				
				
			}

			
		}	
}
