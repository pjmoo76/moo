package com.skb.mi.realtime;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.SocketException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.sql.Statement;


// JSON
import	org.json.simple.JSONObject;
import	org.json.simple.parser.JSONParser;

// WebSocket
import	org.java_websocket.WebSocketImpl;
import	org.java_websocket.client.WebSocketClient;
import	org.java_websocket.drafts.Draft;
import	org.java_websocket.drafts.Draft_6455;
import	org.java_websocket.handshake.ServerHandshake;

import  com.skb.mi.common.DBController;
import	com.skb.mi.thread.SmsClientCircuitThread;				// 10분마다 SMS발송 VIP List를 Update

public class SmsClientCircuit extends WebSocketClient {

	public static int	 ONE_SECOND = 1000;

	public static String ALL_SVC_MGMT_NUM = "9999999999";

	public static String	TEAMS				= "005";		// TEAMS 장애(NMS_CD)
	public static String	FAULT_CIRCUIT		= "042001";		// 회선 장애(DABL_CD)

	JSONParser	   jsonParser;
    DBController   dbController;
    String         dbUrl, userName, password; 

    String         absolutePath;

	Hashtable<String,String>	faultList;

	// 10분마다 SMS 발송 VIP List를 Update하는 Thread
	SmsClientCircuitThread		smsClientCircuitThread;

	private WebSocketClient webSocketClient;

	public	boolean			check = false;

	private	Statement		statement;

	public SmsClientCircuit (String absolutePath, URI url, Draft draft) {
		super (url, draft);
        this.absolutePath = absolutePath;
		jsonParser = new JSONParser ();

		faultList = new Hashtable<String,String> ();

        try {
            readDbInfo ();
			dbOpen ();
			statement = dbController.getConnection ().createStatement ();
			smsClientCircuitThread = new SmsClientCircuitThread (dbController.getStmt ());
			smsClientCircuitThread.start ();
        } catch (Exception e) {
             System.out.println ("SmsClientCircuitThread 생성 Exception : " + e);
        } 
	}

	public boolean	getCheck () {return check; }

	public void readDbInfo () throws Exception {
		String  oneLine;
		FileReader      fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + "db.info");
		BufferedReader bufferedReader = new BufferedReader (fileReader);
		dbUrl = bufferedReader.readLine ();
		userName = bufferedReader.readLine ();
		password = bufferedReader.readLine ();
		bufferedReader.close ();
		fileReader.close ();
	}

	public void dbOpen () {
        try {
             dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
        } catch (Exception e) {
             System.out.println ("SmsClientCircuit DB Exception : " + e);
             System.exit (1);                                        // DB접속 에러시 종료
        } 
	}

	@Override
	public void onOpen (ServerHandshake serverHandshake) {
		check = true;
		System.out.println ("opend connection....");
		String	message = "{\"kind\":\"ID\",\"ID\":\"gildong\",\"recvMessage\":\"GEN|CLR\"}";
		send (message);
	}

	@Override
	public void onMessage (String message) {
//        System.out.println ("\nonMessage : " + message);
        String dablNum, equipId, dablCd;
		try {
			JSONObject	jsonObject = (JSONObject) jsonParser.parse (message);
			String		kind = jsonObject.get ("kind").toString ();
			if (kind != null ) {
				if (kind.equals ("GEN") || kind.equals ("CLR")) {
					checkSms (jsonObject);
				}
			}
			jsonObject = null;
		} catch (Exception e) {
			System.out.println ("[" + getDateSecond () + "] " + "=========== Exception ==========");
			System.out.println ("[" + getDateSecond () + "] " + "Received : " + message);
			System.out.println ("[" + getDateSecond () + "] " + "jsonParser : " + jsonParser);
			System.out.println ("[" + getDateSecond () + "] " + "Exception : " + e);
			System.out.println ("[" + getDateSecond () + "] " + "================================\n");
		}
	}

	public void checkSms (JSONObject jsonObject) {
		String	nmsCd = jsonObject.get ("NMS_CD").toString ();
		if (nmsCd.equals (TEAMS)) {    // TEAMS
			String	dablCd = jsonObject.get ("DABL_CD").toString ();
			String	kind = jsonObject.get ("kind").toString ();
			String	dablNum = jsonObject.get ("DABL_NUM").toString ();
			if (kind.equals ("GEN") && dablCd.equals (FAULT_CIRCUIT)) {	// 장애발생
				String	occrDtm = jsonObject.get ("OCCR_DTM").toString ();
				String	equipNm = jsonObject.get ("EQUIP_NM").toString ();
				String	dablDesc = jsonObject.get ("DABL_DESC").toString ();
				String	equipId = jsonObject.get ("EQUIP_ID").toString ();
				String	dablNm = jsonObject.get ("DABL_NM").toString ();
				String	dablGrCd = jsonObject.get ("DABL_GR_CD").toString ();
				String	lineNum = jsonObject.get ("LINE_NUM").toString ();
				String	lineNm = jsonObject.get ("LINE_NM").toString ();
				String	svcMgmtNum = jsonObject.get ("SVC_MGMT_NUM").toString ();
				String	phoneList = smsClientCircuitThread.getPhoneList (lineNum, dablGrCd);
				String	rcvTelNo, query, token;

				StringTokenizer	telTokens;

				System.out.println ("회선 장애 : " + jsonObject);
				if (phoneList != null) {
					telTokens = new StringTokenizer (phoneList, ",");
					while (telTokens.hasMoreTokens ()) {
						rcvTelNo = telTokens.nextToken ();
						query = makeQuery ("발생", occrDtm, lineNm, dablNm, dablDesc, rcvTelNo, dablNum);	
						executeUpdate (query);
					}
					faultList.put (jsonObject.get ("NMS_ALARM_NO").toString ()
								 + "$" + dablNum
								 , phoneList + "$" + lineNm + "$" + dablNm + "$" + dablDesc);
				}
				System.out.println ("=======> faultList'size : " + faultList.size ());
			} else if (kind.equals ("CLR") && dablCd.equals (FAULT_CIRCUIT)) {// 장애해제
				System.out.println ("해제 : " + jsonObject.toString ());
				sendClearSms (jsonObject.get ("NMS_DABL_NUM_CTT").toString ()
						    + "$" + dablNum
							, jsonObject.get ("RLSE_RCV_DTM").toString (), dablNum);
				System.out.println ("=======> faultList'size : " + faultList.size ());
			}
		}
	}

    public void executeUpdate (String query) {
        try {
            statement.executeUpdate (query);
        } catch (Exception e) {
            System.out.println ("SmsClientCircuit:executeUpdate:query = " + query);
            System.out.println ("SmsClientCircuit:Exception: " + e);
        }
    }
	public void sendClearSms (String key, String rlseRcvDtm, String dablNum) {		// Key : NMS_ALAMR_NO + dablNum
		if (faultList.get (key) != null) {
			StringTokenizer	tokens = new StringTokenizer (faultList.get (key), "$");
			String phoneList = tokens.nextToken ();
			String lineNm = tokens.nextToken ();
			String dablNm = tokens.nextToken ();
			String dablDesc = tokens.nextToken ();
			String rcvTelNo, query;

			tokens = new StringTokenizer (phoneList, ",");
			while (tokens.hasMoreTokens ()) {
				rcvTelNo = tokens.nextToken ();
				query = makeQuery ("복구", rlseRcvDtm, lineNm, dablNm, dablDesc, rcvTelNo, dablNum);	
				dbController.executeUpdate (query);
			}
			faultList.remove (key);
		}
	}

	@Override
	public void onClose (int code, String reason, boolean remote) {
		System.out.println ("[" + getDateSecond () + "] " + "Connection closed by " + (remote ? "remote peer" : "us"));
		check = false;
	}

	@Override
	public void onError (Exception e) {
		System.out.println ("[" + getDateSecond () + "] " + "onError : " + e);
		check = false;
	}

	public String makeQuery (String kind
							 , String occrDtm
							 , String lineNm
							 , String dablNm
							 , String dablDesc
							 , String rcvTelNo
							 , String dablNum) {
		System.out.println ("----------> kind : " + kind + ", lineNm : " + lineNm + ", dablNm : " + dablNm + ", rcvTelNo : " + rcvTelNo + ", dablNum : " + dablNum);

		String  msg = "※관련 운용자는 확인 후 신속한 대응 바랍니다.";
		if (kind.equals ("복구"))
			msg = "장애 해제되었습니다.";
		String	query = "INSERT INTO TBL_SUBMIT_QUEUE"
					  + " ( CMP_MSG_ID "
					  + " , CMP_MSG_GROUP_ID"
					  + " , USR_ID"
					  + " , SMS_GB"
					  + " , USED_CD"
					  + " , CONTENT_CNT"
					  + " , CONTENT_MIME_TYPE"
					  + " , RESERVED_FG"
					  + " , RESERVED_DTTM"
					  + " , SAVED_FG"
					  + " , RCV_PHN_ID"
					  + " , SND_PHN_ID"
					  + " , NAT_CD"
					  + " , ASSIGN_CD"
					  + " , SND_MSG)" 
					  + " VALUES "
					  + " (MI_APP.TBL_SUBMIT_QUEUE_SEQ.NEXTVAL"
					  + " , 'FAULT_CIRCUIT'"
					  + " , '5464'"
					  + " , '1'"
					  + " , '10'"
                      + " , '1'"
                      + " , 'text/plain'"
					  + " , 'I'"
					  + " , TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS')"
					  + " , '1'"
					  + " , REPLACE ('" + rcvTelNo + "', '-', '')"
					  + " , '07078051228'"
					  + " , '82'"
					  + " , '00000'"
					  + ", '[ADAMS-Web발신]"
					  + "\r\n●[" + kind + "시각] " + occrDtm
					  + "\r\n●[회선명] " + lineNm
					  + "\r\n●[장애종류] " + dablNm
					  + "\r\n●[장애내용] " + dablDesc
					  + "\r\n" + msg + "')";
		return query;
	}

	public String queryString (String str) {
        String ret = "";
        for (int index = 0; index < str.length (); ++ index) {
            if (str.charAt (index) == '\'')
                ret += '\'';
            ret += str.charAt (index);
        }
        return ret;
	}

	public String getDateSecond () {
		Calendar        calendar = Calendar.getInstance ();

		return String.format ("%04d-%02d-%02d %02d:%02d:%02d",
				calendar.get(Calendar.YEAR),
				calendar.get(Calendar.MONTH) + 1,
				calendar.get(Calendar.DAY_OF_MONTH),
				calendar.get(Calendar.HOUR_OF_DAY),
				calendar.get(Calendar.MINUTE),
				calendar.get(Calendar.SECOND));
	}

	public void sleep () {
		System.out.print ("^");
		try {
			Thread.sleep (ONE_SECOND);
		} catch (Exception e) {
		}
	}

	public static void main (String [] args) throws URISyntaxException {
		String a;
        if (args.length != 2) {
             System.out.println ("사용법 : java SmsClientCircuit 절대패스 URI");
             System.exit(0);
        }
		SmsClientCircuit smsClientCircuit = new SmsClientCircuit (
//			new URI ("ws://12.4.96.92:59768"), new Draft_6455 ());		
			args[0], new URI (args [1]), new Draft_6455 ());		
		
		while (true) {
//			try{
//				System.out.println(smsClientCircuit.getSocket().getKeepAlive());
//			}catch (SocketException se){
//				
//			}	
			
			System.out.println(smsClientCircuit.getConnection().getReadyState());
			System.out.println(smsClientCircuit.getConnection().getReadyState().equals(org.java_websocket.WebSocket.READYSTATE.OPEN));
			if (!smsClientCircuit.getConnection().getReadyState().equals(org.java_websocket.WebSocket.READYSTATE.OPEN)) {
				try{
		//			smsClientCircuit.close ();
					System.out.println("try reconnect");
					smsClientCircuit.connect ();
					
				}catch(Exception e){
					
				}
				
				
			}
			smsClientCircuit.sleep ();
		}
	}
}
