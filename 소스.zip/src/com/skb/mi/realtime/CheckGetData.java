package com.skb.mi.realtime;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.LinkedList;

import com.skb.adams.cm.util.StringUtils;
import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.DBController;
import com.skb.mi.common.EnvManager;

import org.apache.commons.cli.HelpFormatter;
import org.json.simple.JSONObject;

import com.skb.mi.common.OutputLog;
import com.skb.mi.thread.KeepAliveSbnnms;
import com.skb.mi.thread.CheckKeepAlive;

public class CheckGetData {
	final private int 			BUFFER_SIZE 		= 16384;
	final private byte			IDENTIFIER 			= 0x1f;
	final private byte			ETX 				= 0x03;

	final private String		NMS_CD 				= "006";	// OCO20101 테이블에 있음.
	final private String		NMS_NM 				= "SBNNMS";

	final private String		NET_CL_CD 			= "05";	
	final private String		NET_CL_NM 			= "IP";

	final private String 		EQUIP_FAULT 		= "01";		// 01: 장비 장애
	final private String 		CIRCUIT_FAULT 		= "02"; 	// 02: 회선 장애
	final private String 		TRAFFIC_FAULT 		= "03"; 	// 03: 트래픽 장애

	final private String		EQUIP_DABL_LCL_NM 	= "장비장애";
	final private String		EQUIP_DABL_MCL_CD 	= "01501";
	final private String		EQUIP_DABL_MCL_NM 	= "정보기간망장애";
	final private String		EQUIP_DABL_CD 	  	= "015001";
	final private String		EQUIP_DABL_NM 		= "정보기간망장비장애";

    final private String        GENERATE_EVENT      = "GEN";
    final private String        CLEAR_EVENT         = "CLR";

    final private String        GENERATED_FAULT_NM  = "장애중";
    final private String        CLEARED_FAULT_NM    = "장애해제";

    final private String        GENERATED_FAULT_CD  = "01";
    final private String        CLEARED_FAULT_CD    = "02";

    final private int			SO_TIME_OUT	= (1000*60*5);	// Time-Out 5분 설정

    String						sbnnmsIpAddress;
	int							portNo;

	String						dbUrl, userName, password;
//	String []					alarmField;

	byte []						buffer;
	int							bufferFront, bufferRear;
	int							maxColumn = 22;

	Socket						socket;
	InputStream					inputStream;
	OutputStream				outputStream;

    // Push Processor 정보
    Socket                      pushSocket;
    InputStream                 pushInputStream;
    OutputStream                pushOutputStream;
    String                      pushIpAddress;
    int                         pushPortNo;

	Hashtable<String,String>	alarmColumn;	

    LinkedList<JSONObject>      notSendJson;
    JSONObject                  jsonObject;

	String						pgmId;
	String						absolutePath;

    OutputLog                   outputLog;
    CheckKeepAlive             keepAliveSbnnms;

    DBController                dbController;

    public CheckGetData (String[] args) {
		absolutePath = EnvManager.env.getHome();
        outputLog = new OutputLog (true, this.getClass().getName (), EnvManager.env.getLogs());
        outputLog.write ("Start : " + getDateSecond ());

		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		dbUrl = configManager.getConfig(Constants.ADAMS_DB, Constants.DB_URL);
		userName = configManager.getConfig(Constants.ADAMS_DB, Constants.USER_NAME);
		password = configManager.getConfig(Constants.ADAMS_DB, Constants.PASSWORD);
		sbnnmsIpAddress = configManager.getConfig(Constants.SBNNMS, Constants.IP_ADDRESS);
		portNo = Integer.parseInt(configManager.getConfig(Constants.SBNNMS, Constants.PORT_NO));
		pushIpAddress = configManager.getConfig(Constants.WEB_PUSH, Constants.IP_ADDRESS);
		pushPortNo = Integer.parseInt(configManager.getConfig(Constants.WEB_PUSH, Constants.PORT_NO));

		outputLog.write("dbUrl : " + dbUrl);
		outputLog.write("userName : " + userName);
		outputLog.write("password : " + password);
		outputLog.write("sbnnmsIpAddress : " + sbnnmsIpAddress);
		outputLog.write("portNo : " + portNo);
		outputLog.write("pushIpAddress : " + pushIpAddress);
		outputLog.write("pushPortNo : " + pushPortNo);

        try {
            //readDbInfo ();
            dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
/**
            InetAddress local = InetAddress.getLocalHost ();
            String  ip = local.getHostAddress ();
            ResultSet resultSet = dbController.selectProgramInfo (this.getClass().getName (), ip);

            if (resultSet.next ()) {
                pgmId = resultSet.getString (1);
                String  pgmUseYn = resultSet.getString (2);
                String  pgmStCd = resultSet.getString (3);
                resultSet.close ();

                outputLog.write ("pgmId : " + pgmId + ", pgmUseYn : " + pgmUseYn + ", pgmStCd : " + pgmStCd);
                // 프로세스 Use Y/N 검사
                if (pgmUseYn.equals ("N"))
                    exitProcess (false, "");
                // 프로세스 동작중인지 검사
                if (pgmStCd.equals ("S"))       // 동작중이면 바로 종료
                    exitProcess (false, "");
                else                            // 동작이 종료되어 있는 경우
                    dbController.insertProcessHistory(pgmId, "프로세스가 시작되었습니다", "S", "Y");
                    outputLog.write ("프로세스가 시작되었습니다.");
            } else {
                dbController.insertProcessHistory(pgmId, "프로세스가 시작되었습니다", "S", "Y");
                exitProcess (true, "프로세스를 찾을 수 없습니다.");
            }
**/

        } catch (Exception e ) {
            exitProcess (true, "DB 정보를 읽는 도중에 에러발생되었습니다.");
        }

        /*
		try {
			readSbnnmsInfo ();
			readPushInfo ();
		} catch (Exception e ) {
			exitProcess (true, "readSbnnmsInfo Error : " + e);
		}*/

//		try {
//			readAlarmMessage ("sbnnms.dat");
//		} catch (Exception e ) {
//			exitProcess (true, "readAlarmMessage Error : " + e);
//		}

		notSendJson = new LinkedList<JSONObject> ();
		alarmColumn = new Hashtable<String,String> ();

        try {
			buffer = new byte [BUFFER_SIZE];
			bufferFront = bufferRear = 0;

			inputStream = null;
			outputStream = null;

			connectNms ();

            pushSocket = new Socket (pushIpAddress, pushPortNo);
            pushOutputStream = pushSocket.getOutputStream ();

            outputLog.write ("new CheckKeepAlive");
            keepAliveSbnnms = new CheckKeepAlive (outputStream, this);
            
            keepAliveSbnnms.start ();

            realTimeCollect ();
            
            outputStream.close ();
            inputStream.close ();
            socket.close ();
            
        } catch (Exception e) {
            exitProcess (true, "Socket Open Error : " + e);
        }
		exitProcess (true, "Finish : " + getDateSecond ());
    }

    public void exitProcess (boolean check, String clctRsltCtt) {
        if (check) {
            try {
                dbController.insertProcessHistory(pgmId, clctRsltCtt, "F", "Y");
            } catch (Exception e) {
                outputLog.write ("exitProcess () Exception : " + e);
            }
        }
        outputLog.write (clctRsltCtt);
        outputLog.close ();
        dbController.closeDB ();
        try {
            outputStream.close ();
            inputStream.close ();
            socket.close ();
        } catch (Exception e) {
        }
        outputLog.write ("Finish : " + getDateSecond ());
        System.exit (0);
    }

	public void connectNms () {
        outputLog.write ("connecting NMS");
        boolean check = false;
        while (!check) {
            try {
            	try {
            		if (inputStream != null) {
            			inputStream.close();
                    	inputStream = null;            		
            		}
            	} catch (Exception e) {
                	inputStream = null;            		
            	}
            	try {
            		if (socket != null) socket.close();
                	socket = null;            		
            	} catch (Exception e) {
                	socket = null;            		
            	}
            	
                socket = new Socket (sbnnmsIpAddress, portNo);
                socket.setSoTimeout(SO_TIME_OUT);
                inputStream = socket.getInputStream();
                outputStream = socket.getOutputStream ();
                bufferFront = bufferRear = 0;

                check = true;
            } catch (Exception e) {
                outputLog.write ("[" + getDateSecond () + "] Socket Open Error : " + e);
                sleep (100);            // 0.1초
            }
        }
        outputLog.write ("connected NMS");
	}

	/*
	public void readDbInfo () throws Exception {
		String	oneLine;
		FileReader	fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + "db.info");
		BufferedReader bufferedReader = new BufferedReader (fileReader);
		dbUrl = bufferedReader.readLine ();
		userName = bufferedReader.readLine ();
		password = bufferedReader.readLine ();
		bufferedReader.close ();
		fileReader.close ();
	}

	public void readSbnnmsInfo () throws Exception {
		String	oneLine;
		FileReader	fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + "sbnnms.info");
		BufferedReader bufferedReader = new BufferedReader (fileReader);
		sbnnmsIpAddress = bufferedReader.readLine ();
		portNo = Integer.parseInt (bufferedReader.readLine ());	
		bufferedReader.close ();
		fileReader.close ();
	}

    // Push Processor IP Address와 포트 정보 조회
    public void readPushInfo () throws Exception {
        FileReader  fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + "push.info");
        BufferedReader bufferedReader = new BufferedReader (fileReader);
        pushIpAddress = bufferedReader.readLine ();
        pushPortNo = Integer.parseInt (bufferedReader.readLine ());
        bufferedReader.close ();
        fileReader.close ();
    }
    */

	/*
	public void readAlarmMessage (String alarmFile) throws Exception {
		String	  oneLine;
		int		  rowNo;
		FileReader	fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + alarmFile);
		BufferedReader bufferedReader = new BufferedReader (fileReader);
		oneLine = bufferedReader.readLine ();
		maxColumn = Integer.parseInt (oneLine);
		alarmField = new String [maxColumn];

		for (int index = 0; index < maxColumn; ++ index) 
			alarmField [index] = bufferedReader.readLine ();

		bufferedReader.close ();
		fileReader.close ();
	}
	*/

	public void checkProcess () {
		String query = "SELECT PGM_USE_YN FROM oco30310 WHERE PGM_ID='" + pgmId + "'";
		try {
			ResultSet resultSet = dbController.getStmt ().executeQuery (query);
			if (resultSet.next ()) {
				if (resultSet.getString (1).equals ("N")) {
					exitProcess (true, "프로세스가 동작 중지 되었습니다.");
				}
			} else {
				exitProcess (true, "PgmId : " + pgmId + "를 찾을 수 없습니다.");
			}
		} catch (Exception e) {
			exitProcess (true, "checkProcess 함수에서 에러가 발생되었습니다.");
		}
	}

    public void realTimeCollect () {
		int		index, evtSeverity;
		byte	oneByte;
		byte []	tempBytes;
		String	token, query, idSerial, evtGenTime;

    	while (true) {
			query = "";
			token = "";
			idSerial = "";
			evtSeverity = 0;
			evtGenTime = "";
			jsonObject = new JSONObject ();
			try {
				oneByte = getOneByte ();
				if (oneByte != 0x1b)
					continue;

				oneByte = getOneByte ();
				if (oneByte != 0x02)
					continue;

				for (index = 1; index <= maxColumn; ++ index) { 
					token = getBytes ();			// 01 : PduType 	: 장애 이벤트(303)
//					System.out.printf ("%s.", token);	
					if (token == null)
						break;
					token = token.trim ();
					alarmColumn.put ("Field" + index, token);
					outputLog.write ("Field" + index + " : " + token);
				}
				evtSeverity = Integer.parseInt (alarmColumn.get("Field5"));	// 장애 등급

				jsonObject.put ("NMS_CD", NMS_CD);
				if (evtSeverity == 0) {								// 장애 해제
					jsonObject.put ("kind", CLEAR_EVENT);
					jsonObject.put ("DABL_ST_CD", CLEARED_FAULT_CD);
					jsonObject.put ("DABL_ST_NM", CLEARED_FAULT_NM);
					jsonObject.put ("RLSE_DTM", alarmColumn.get ("Field10"));
					jsonObject.put ("RLSE_RCV_DTM", getDateTime ());
					jsonObject.put ("NMS_DABL_NUM_CTT", alarmColumn.get ("Field2"));
				} else {
					jsonObject.put ("DABL_OCCR_LOC_DESC", alarmColumn.get ("Field19"));
					jsonObject.put ("kind", GENERATE_EVENT);
					jsonObject.put ("DABL_ST_CD", GENERATED_FAULT_CD);
					jsonObject.put ("DABL_ST_NM", GENERATED_FAULT_NM);
					jsonObject.put ("NMS_NM", NMS_NM);
					jsonObject.put ("NMS_DABL_NUM_CTT", alarmColumn.get ("Field2"));
					jsonObject.put ("DABL_LCL_CD", EQUIP_FAULT);
					jsonObject.put ("DABL_LCL_NM", EQUIP_DABL_LCL_NM);
					jsonObject.put ("DABL_MCL_CD", EQUIP_DABL_MCL_CD);
					jsonObject.put ("DABL_MCL_NM", EQUIP_DABL_MCL_NM);
					jsonObject.put ("DABL_CD", EQUIP_DABL_CD);
					jsonObject.put ("DABL_NM", EQUIP_DABL_NM);
					jsonObject.put ("TEAM_ORG_ID", alarmColumn.get ("Field6"));
					jsonObject.put ("TEAM_ORG_NM", alarmColumn.get ("Field7"));
					jsonObject.put ("MGMT_TPO_CD", alarmColumn.get ("Field8"));
					jsonObject.put ("MGMT_TPO_NM", alarmColumn.get ("Field9"));
					jsonObject.put ("OCCR_DTM", alarmColumn.get ("Field10"));
					jsonObject.put ("OCCR_RCV_DTM", getDateTime ());
					jsonObject.put ("EQUIP_IP_ADDR", alarmColumn.get ("Field11"));
					jsonObject.put ("EQUIP_NM", alarmColumn.get ("Field12"));
					jsonObject.put ("SBNMS_EQUIP_NM", alarmColumn.get ("Field12"));
					jsonObject.put ("EQUIP_TID_VAL", alarmColumn.get ("Field13"));
					jsonObject.put ("EQUIP_MDL_CD", alarmColumn.get ("Field14"));
					jsonObject.put ("EQUIP_MDL_NM", alarmColumn.get ("Field15"));
					jsonObject.put ("PORT_ALS_NM", alarmColumn.get ("Field20"));
					jsonObject.put ("DABL_DESC", alarmColumn.get ("Field21"));
					jsonObject.put ("DMG_SCRBR_CNT", alarmColumn.get ("Field22"));
					jsonObject.put ("NET_CL_CD", NET_CL_CD);
					jsonObject.put ("NET_CL_NM", NET_CL_NM);

					switch (evtSeverity) {
						case 1 :									// Warning
						case 2 :									// Minor
						case 3 :									// Major
						case 4 :									// Critical
							jsonObject.put ("DABL_GR_CD", "0" + String.valueOf (evtSeverity + 1));
							break;
						case -1:									// 확인
								break;
						case -2:									// 조치중
								break;
					}
				}
				if (0 <= evtSeverity) {
					outputLog.write (jsonObject.toJSONString ());
					try {
						//pushOutputStream.write (makeSendBuffer (jsonObject.toString ().getBytes ()));
						//pushOutputStream.flush ();
					} catch (Exception e) {
						outputLog.write ("============ Push Exception : " + e);
						//notSendJson.add (jsonObject);
						//sendJson ();
					}
				}
			} catch (Exception e) {
				outputLog.write (e);
			}
			alarmColumn.clear ();
    	}
    }
    
//    public void sendJson () {
//        JSONObject  obj;
//        int size = notSendJson.size ();
//        outputLog.write ("Push 프로세스에게 전달할 JSON크기 : " + size);
//        try {
//            try {
//                pushOutputStream.close ();
//            } catch (Exception e1) {
//            }
//            try {
//                pushSocket.close ();
//            } catch (Exception e2) {
//            }
//            pushSocket = new Socket (pushIpAddress, pushPortNo);
//            pushOutputStream = pushSocket.getOutputStream ();
//            for (int index = 0; index < size; ++ index) {
//                obj = notSendJson.get (0);
//                pushOutputStream.write (makeSendBuffer (obj.toString ().getBytes ()));
//                pushOutputStream.flush ();
//                outputLog.write (obj.toJSONString ());
//                notSendJson.remove (0);
//                Thread.sleep (100);
//            }
//            pushOutputStream.flush ();
//        } catch (Exception e) {
//            outputLog.write ("Push 프로세스와 연결이 끊겼습니다.");
//        }
//    }

    public byte[] makeSendBuffer (byte [] temp) {
        byte [] sendBuffer = new byte [temp.length + 1];
        int index = 0;
        for (; index < temp.length; ++ index)
            sendBuffer [index] = temp [index];
        sendBuffer [index] = ETX;
        return sendBuffer;
    }

	public byte getOneByte () {
        while (true) {
            try {
                if (bufferFront == bufferRear) {
                    bufferFront = 0;
                    bufferRear = inputStream.read (buffer);
                }
                if (bufferRear != -1) {
					byte tmp;
					if (buffer [bufferFront] == '}')
						tmp = ']';
					else if (buffer [bufferFront] == '{')
						tmp = '[';
					else
						tmp = buffer [bufferFront];
					++ bufferFront;
                    return tmp;
				} else {
                    outputLog.write ("getOneByte () Else : " + bufferFront);
                    inputStream.close ();
                    outputStream.close ();
                    socket.close ();
                    connectNms ();
				}
            } catch (Exception e) {
                try {
                    outputLog.write ("getOneByte () Exception : " + e);
                    inputStream.close ();
                    outputStream.close ();
                    socket.close ();
                    connectNms ();
                } catch (Exception ee) {
                    outputLog.write ("getOneByte () Catch Exception : " + ee);
                }
            }
        }
	}

	public byte [] getBytes (int number) {
		byte [] bytes = new byte [number];
		byte temp;
		for (int index = 0; index < number; ++ index) {
			temp = getOneByte ();
			if (temp == -1)
				return null;	
			bytes [index] = temp;
		}
		return bytes;
	}

	public String getBytes () {
		byte [] bytes = new byte [BUFFER_SIZE];
		byte temp;
		int	index;
		for (index = 0; ; ++ index) {
			temp = getOneByte ();
			if (temp == -1) {
				//outputLog.write("recvDataLen:" + index);
				//outputLog.write("recvData:" + StringUtils.toHexString(bytes, index));
				return null;
			}
			//outputLog.write(index + ":" + String.format("%02X", temp));
			if (temp == IDENTIFIER)
				break;
			bytes [index] = temp;
		}
		try {
			return new String (bytes, 0, index, "EUC-KR");
		} catch (Exception e) {
			outputLog.write ("getBytes : new String : Exception : " + e);
			return null;
		}
	}

	public String getDateSecond () {
		Calendar	calendar = Calendar.getInstance ();

		return String.format ("%04d-%02d-%02d %02d:%02d:%02d",
			calendar.get(Calendar.YEAR),
			calendar.get(Calendar.MONTH) + 1,
			calendar.get(Calendar.DAY_OF_MONTH),
			calendar.get(Calendar.HOUR_OF_DAY),
			calendar.get(Calendar.MINUTE),
			calendar.get(Calendar.SECOND));
	}

    public void printHexaCode (int length, byte[] buffer) {
		int count = 0;
    	for (int index = 0; index < length; ++ index) {
/*
			if (buffer [index] == ESC)
				System.out.println ();
*/
			if (count++ % 20 == 0)
				outputLog.write ("\n");
    		outputLog.write (String.format ("%02x.", buffer [index]));
		}
		outputLog.write ("\n");
    }
    
    public void sleep (int waitingTime) {
        try {
            Thread.sleep (waitingTime);
        } catch (Exception e) {
        }
    }

	public void write (String message) {
		outputLog.write (message);
	}

	public void keepAlive () {
		try {
			dbController.getStmt ().executeQuery ("SELECT SYSDATE FROM DUAL");
		} catch (Exception e) {
			outputLog.write (" keepAlive Exception : " + e);
		}
	}

    public String getDateTime () {
        Calendar    calendar = Calendar.getInstance ();

        return String.format ("%04d-%02d-%02d %02d:%02d:%02d",
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH) + 1,
            calendar.get(Calendar.DAY_OF_MONTH),
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            calendar.get(Calendar.SECOND));
    }

    public static void main (String [] args) {
//        if (args.length != 1) {
//            System.out.println ("Usage : RealTimeCollectSbnnms directory");
//            System.exit (0);
//        }
    	EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("RealTimeCollectSbnnms", envManager.getOptions());
    		System.exit(0);
    	}
        new CheckGetData (args);
    }
}

