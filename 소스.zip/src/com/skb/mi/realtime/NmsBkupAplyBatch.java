package com.skb.mi.realtime;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;

import org.apache.commons.cli.HelpFormatter;
import org.apache.ibatis.session.SqlSession;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import subkjh.bas.log.Logger;

import com.skb.mi.common.Constants;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.common.OutputLog;

public class NmsBkupAplyBatch {
	final public String        ABSOLUTE_PATH = "/app/nexcore/adams/nmsbkup"; 
	final public String        BKUP_PATH = "/app/nexcore/adams/nmsbkup/logs/";  
	SqlSession				   adamsSession;
	OutputLog				   outputLog;
	

	public NmsBkupAplyBatch(String[] args) {
		File dir = new File(ABSOLUTE_PATH); //경로를 args로 받을지
		File bkupPath = new File(BKUP_PATH);
		
		outputLog = new OutputLog (true, this.getClass().getName (), EnvManager.env.getLogs());
		
		if(dir.isDirectory() && dir.exists()){
			File[] files = dir.listFiles();
			if(files != null && files.length > 0){
				try {
					Logger.logger.debug("DB 연결 중....");
					adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
				} catch (Exception e1) {
					Logger.logger.debug("DB 연결 에러 : " + e1);
				}
				Arrays.sort(files);
				JSONParser parser = new JSONParser();
				for(File file : files){
					if(!file.isDirectory()){
						try {
							FileReader  fileReader = new FileReader (ABSOLUTE_PATH + File.separator + file.getName());
					        BufferedReader bufferedReader = new BufferedReader (fileReader);
					        String jsonStr = null;
					        int count = 0;
					        while(true){
					        	jsonStr = bufferedReader.readLine();
					        	if (jsonStr == null) {
									break;
								}
	
					        	try {
									JSONObject json = (JSONObject) parser.parse(jsonStr);
									Logger.logger.debug(json.get("kind"));
									//CLR 데이터만 처리 로직 실행
									if("CLR".equals((String)json.get("kind"))){
										Logger.logger.debug("CLR 전문 내용 >> " + json.toJSONString());
										adamsSession.insert("WebSocketServerSystem.updateBkupClrFault", json);
									}
									//테스트 출력용
									//count++;
									//System.out.println(file.getName() + " // " + count + ". " + jsonStr);
								} catch (ParseException e) {
									System.out.println("JSON 오류 : " + e);
								}
					        }
					        adamsSession.commit();
						} catch (Exception e) {
							System.out.println("파일 오류 : " + e);
						} finally {
							Logger.logger.debug("Finish....");
							adamsSession.close();
						}
						//파일 처리에 이상없으면 파일 이동
						try {
							Logger.logger.debug("from path >>> " + file.toPath().toString());
							Logger.logger.debug("filename >>> " + file.getName().toString());
							Logger.logger.debug("to path >>> " + Paths.get(BKUP_PATH, file.getName()).toString());
							Files.move(file.toPath(), Paths.get(BKUP_PATH, file.getName()), StandardCopyOption.REPLACE_EXISTING);
						} catch (IOException e) {
							Logger.logger.debug("파일 Move 에러 : " + e);
						}
					}
				}
			}
		}
	}

	public static void main(String[] args) {
		EnvManager envManager = new EnvManager(args);
		if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("NmsBkupAplyBatch", envManager.getOptions());
    		System.exit(0);
    	}
		
		new NmsBkupAplyBatch(args);
	}
}
