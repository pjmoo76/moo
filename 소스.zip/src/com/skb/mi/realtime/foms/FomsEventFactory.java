package com.skb.mi.realtime.foms;

import java.io.InputStream;

import org.apache.log4j.Logger;

import com.skb.mi.common.SockUtils;
import com.skb.mi.common.StringUtils;

public class FomsEventFactory {
	private int		HEADER_LEN	= 24;	
	private	byte	DELIMITER	= 0x1f;
	
	private	byte[]	header;
	private	String	CHARSET_NAME	= "EUC-KR";
	private	Logger	logger;

	public FomsEventFactory() {
		this.logger = Logger.getLogger(this.getClass());
		this.header = new byte[HEADER_LEN];
	}
	
	public FomsFaultEvent get(InputStream is) throws Exception {
		/*
		 * ---------------------------------
			SrcTcpid	unsigned char	4	0
			Msgkind		unsigned char	1	4
			chain		unsigned char	1	5
			detailcmd1	unsigned char	1	6
			detailcmd2	unsigned char	1	7
			Detail		unsigned char	8	8
			result		unsigned char	2	16
			protdetail	unsigned char	1	18
			protid		unsigned char	1	19
			size		int				4	20
			data		unsigned char	최대 2048
		 * ----------------------------------
		 */
		
		int len = SockUtils.read(is, header, header.length);
		if (len != HEADER_LEN) {
			throw new Exception(String.format("failed to read header (%d,%d)", HEADER_LEN, len));
		}
		int dataSize = getDataSize(StringUtils.getBytes(header, 20, 4));
		byte detailCmd2 = header[7];
		logger.debug(String.format("%02X %d",  detailCmd2, dataSize));
		if (dataSize == 0) return null;
		byte[] data = new byte[dataSize];
		len = SockUtils.read(is, data, data.length);
		if (len != dataSize) {
			throw new Exception(String.format("failed to read body (%d,%d)", dataSize, len));
		}
		if (detailCmd2 == FomsEvent.DETAIL_CMD2_POLL
				|| detailCmd2 == FomsEvent.DETAIL_CMD2_INIT_NET || detailCmd2 == FomsEvent.DETAIL_CMD2_INIT_AMI || detailCmd2 == FomsEvent.DETAIL_CMD2_INIT_ENV
				|| detailCmd2 == FomsEvent.DETAIL_CMD2_INIT_END || detailCmd2 == FomsEvent.DETAIL_CMD2_VOC) {
			return null;
		}
		String[] items = StringUtils.split(data, DELIMITER, CHARSET_NAME);
		for (int i = 0; i < items.length; i ++) {
			logger.debug(String.format("[%d] %s", i, items[i]));
		}
		
		FomsFaultEvent event = null;
		if (detailCmd2 == FomsEvent.DETAIL_CMD2_NET_GEN || detailCmd2 == FomsEvent.DETAIL_CMD2_NET_CLR) {
			event = new FomsNetFaultEvent(detailCmd2, items);
		} else if (detailCmd2 == FomsEvent.DETAIL_CMD2_AMI_GEN || detailCmd2 == FomsEvent.DETAIL_CMD2_AMI_CLR
				|| detailCmd2 == FomsEvent.DETAIL_CMD2_ENV_GEN || detailCmd2 == FomsEvent.DETAIL_CMD2_ENV_CLR) {
			event = new FomsFaultEvent(detailCmd2, items);
		}
		
		return event;
	}
	
	private int getDataSize(byte[] bytes) throws Exception {
		if (bytes.length != 4) throw new Exception("invalid data size");
		int intVal = 0;
		for (int i = 0; i < (bytes.length - 1); ++ i) {
			intVal += (int) (bytes[i] & 0x000000ff);
			intVal = intVal << 8;
		}
		intVal += (int) (bytes[3] & 0x000000ff);
		return intVal;
	}
}
