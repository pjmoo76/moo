package com.skb.mi.realtime.foms;

public class FomsFaultEvent extends FomsEvent {
	private	String	evtSeverity;
	private	String	dablGrCd;
	private	String	pingCnt;
	private	String	evtId;
	private	String	evtCode;
	private	String	evtGenTime;
	private	String	teamCode;
	private	String	teamName;
	private	String	kTpoCd;
	private	String	kTpoNm;
	private	String	tpoCd;
	private	String	tpoNm;
	private	String	deviceNum;
	private	String	tid;
	private	String	deviceIp;
	private	String	emsIp;
	private	String	devGroup;
	private	String	devType;
	private	String	devTypeName;
	private	String	rackId;
	private	String	shelfId;
	private	String	cardId;
	private	String	portNo;
	private	String	etc;
	private	String	poolName;
	private	String	evtContent;
	private	String	noticeId;
	private	String	noticeType;
	private	String	evtCollectTime;
	private	String	evtChorusSn;
	private	String	devRemark;
	private	String	cellNo;
	private	String	upDeviceNum;
	private	String	upTid;
	private	String mangTypeNm;
	private	String prAlarm;
	private	String bizCustLevel;
	private	String bizCustomerIds;
	private	String bizCustomerNames;
	private	String upFdf;
	private	String upDistance;
	private	String panelRiskCode;
	private	String panelRiskName;
	private	String teamGroupIds;
	private	String dongCd;
	private	String dongNm;
	private String netType;
	
	

	public String getEvtSeverity() {
		return evtSeverity;
	}
	public void setEvtSeverity(String evtSeverity) {
		this.evtSeverity = evtSeverity;
		/*
			0	info
			1	warning
			2	minor
			3	major
			4	critical
			5	chorus_critical
		 */
		if (evtSeverity.equals ("1")) {
			dablGrCd = "02";
		} else if (evtSeverity.equals ("2")) {
			dablGrCd = "03";
		} else if (evtSeverity.equals ("3")) {
			dablGrCd = "04";
		} else if (evtSeverity.equals ("4")) {
			dablGrCd = "05";
		} else if (evtSeverity.equals ("5")) {
			dablGrCd = "05";
		} else {
			dablGrCd = "01";
		}
	}
	public String getDablGrCd() {
		return this.dablGrCd;
	}
	public String getPingCnt() {
		return pingCnt;
	}
	public void setPingCnt(String pingCnt) {
		this.pingCnt = pingCnt;
	}
	public String getEvtId() {
		return evtId;
	}
	public void setEvtId(String evtId) {
		this.evtId = evtId;
	}
	public String getEvtCode() {
		return evtCode;
	}
	public void setEvtCode(String evtCode) {
		this.evtCode = evtCode;
	}
	public String getEvtGenTime() {
		return evtGenTime;
	}
	public void setEvtGenTime(String evtGenTime) {
		this.evtGenTime = evtGenTime;
	}
	public String getTeamCode() {
		return teamCode;
	}
	public void setTeamCode(String teamCode) {
		this.teamCode = teamCode;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public String getkTpoCd() {
		return kTpoCd;
	}
	public void setkTpoCd(String kTpoCd) {
		this.kTpoCd = kTpoCd;
	}
	public String getkTpoNm() {
		return kTpoNm;
	}
	public void setkTpoNm(String kTpoNm) {
		this.kTpoNm = kTpoNm;
	}
	public String getTpoCd() {
		return tpoCd;
	}
	public void setTpoCd(String tpoCd) {
		this.tpoCd = tpoCd;
	}
	public String getTpoNm() {
		return tpoNm;
	}
	public void setTpoNm(String tpoNm) {
		this.tpoNm = tpoNm;
	}
	public String getDeviceNum() {
		return deviceNum;
	}
	public void setDeviceNum(String deviceNum) {
		this.deviceNum = deviceNum;
	}
	public String getTid() {
		return tid;
	}
	public void setTid(String tid) {
		this.tid = tid;
	}
	public String getDeviceIp() {
		return deviceIp;
	}
	public void setDeviceIp(String deviceIp) {
		this.deviceIp = deviceIp;
	}
	public String getEmsIp() {
		return emsIp;
	}
	public void setEmsIp(String emsIp) {
		this.emsIp = emsIp;
	}
	public String getDevGroup() {
		return devGroup;
	}
	public void setDevGroup(String devGroup) {
		this.devGroup = devGroup;
	}
	public String getDevType() {
		return devType;
	}
	public void setDevType(String devType) {
		this.devType = devType;
	}
	public String getDevTypeName() {
		return devTypeName;
	}
	public void setDevTypeName(String devTypeName) {
		this.devTypeName = devTypeName;
	}
	public String getRackId() {
		return rackId;
	}
	public void setRackId(String rackId) {
		this.rackId = rackId;
	}
	public String getShelfId() {
		return shelfId;
	}
	public void setShelfId(String shelfId) {
		this.shelfId = shelfId;
	}
	public String getCardId() {
		return cardId;
	}
	public void setCardId(String cardId) {
		this.cardId = cardId;
	}
	public String getPortNo() {
		return portNo;
	}
	public void setPortNo(String portNo) {
		this.portNo = portNo;
	}
	public String getEtc() {
		return etc;
	}
	public void setEtc(String etc) {
		this.etc = etc;
	}
	public String getPoolName() {
		return poolName;
	}
	public void setPoolName(String poolName) {
		this.poolName = poolName;
	}
	public String getEvtContent() {
		return evtContent;
	}
	public void setEvtContent(String evtContent) {
		this.evtContent = evtContent;
	}
	public String getNoticeId() {
		return noticeId;
	}
	public void setNoticeId(String noticeId) {
		this.noticeId = noticeId;
	}
	public String getNoticeType() {
		return noticeType;
	}
	public void setNoticeType(String noticeType) {
		this.noticeType = noticeType;
	}
	public String getEvtCollectTime() {
		return evtCollectTime;
	}
	public void setEvtCollectTime(String evtCollectTime) {
		this.evtCollectTime = evtCollectTime;
	}
	public String getEvtChorusSn() {
		return evtChorusSn;
	}
	public void setEvtChorusSn(String evtChorusSn) {
		this.evtChorusSn = evtChorusSn;
	}
	public String getDevRemark() {
		return devRemark;
	}
	public void setDevRemark(String devRemark) {
		this.devRemark = devRemark;
	}
	public String getCellNo() {
		return cellNo;
	}
	public void setCellNo(String cellNo) {
		this.cellNo = cellNo;
	}
	public String getUpDeviceNum() {
		return upDeviceNum;
	}
	public void setUpDeviceNum(String upDeviceNum) {
		this.upDeviceNum = upDeviceNum;
	}
	public String getUpTid() {
		return upTid;
	}
	public void setUpTid(String upTid) {
		this.upTid = upTid;
	}
	
	public String getMangTypeNm() {
		return mangTypeNm;
	}
	public void setMangTypeNm(String mangTypeNm) {
		this.mangTypeNm = mangTypeNm;
	}
	public String getPrAlarm() {
		return prAlarm;
	}
	public void setPrAlarm(String prAlarm) {
		this.prAlarm = prAlarm;
	}
	public String getBizCustLevel() {
		return bizCustLevel;
	}
	public void setBizCustLevel(String bizCustLevel) {
		this.bizCustLevel = bizCustLevel;
	}
	public String getBizCustomerIds() {
		return bizCustomerIds;
	}
	public void setBizCustomerIds(String bizCustomerIds) {
		this.bizCustomerIds = bizCustomerIds;
	}
	public String getBizCustomerNames() {
		return bizCustomerNames;
	}
	public void setBizCustomerNames(String bizCustomerNames) {
		this.bizCustomerNames = bizCustomerNames;
	}
	public String getUpFdf() {
		return upFdf;
	}
	public void setUpFdf(String upFdf) {
		this.upFdf = upFdf;
	}
	public String getUpDistance() {
		return upDistance;
	}
	public void setUpDistance(String upDistance) {
		this.upDistance = upDistance;
	}
	public String getPanelRiskCode() {
		return panelRiskCode;
	}
	public void setPanelRiskCode(String panelRiskCode) {
		this.panelRiskCode = panelRiskCode;
	}
	public String getPanelRiskName() {
		return panelRiskName;
	}
	public void setPanelRiskName(String panelRiskName) {
		this.panelRiskName = panelRiskName;
	}
	public void setDablGrCd(String dablGrCd) {
		this.dablGrCd = dablGrCd;
	}
	
	public String getTeamGroupIds() {
		return teamGroupIds;
	}
	public void setTeamGroupIds(String teamGroupIds) {
		this.teamGroupIds = teamGroupIds;
	}
	public String getDongCd() {
		return dongCd;
	}
	public void setDongCd(String dongCd) {
		this.dongCd = dongCd;
	}
	public String getDongNm() {
		return dongNm;
	}
	public void setDongNm(String dongNm) {
		this.dongNm = dongNm;
	}
	public String getNetType() {
		return netType;
	}
	public void setNetType(String netType) {
		this.netType = netType;
	}
	public FomsFaultEvent(byte detailCmd2, String[] items) {
		super(detailCmd2, items);

		this.setEvtSeverity(items[2].trim());
		this.setPingCnt(items[3].trim());
		this.setEvtId(items[4].trim());
		this.setEvtCode(items[5].trim());
		this.setEvtGenTime(items[6].trim());
		this.setTeamCode(items[7].trim());
		this.setTeamName(items[8].trim());
		this.setkTpoCd(items[9].trim());
		this.setkTpoNm(items[10].trim());
		this.setTpoCd(items[11].trim());
		this.setTpoNm(items[12].trim());
		this.setDeviceNum(items[13].trim());
		this.setTid(items[14].trim());
		this.setDeviceIp(items[15].trim());
		this.setEmsIp(items[16].trim());
		this.setDevGroup(items[17].trim());
		this.setDevType(items[18].trim());
		this.setDevTypeName(items[19].trim());
		this.setRackId(items[20].trim());
		this.setShelfId(items[21].trim());
		this.setCardId(items[22].trim());
		this.setPortNo(items[23].trim());
		this.setEtc(items[24].trim());
		this.setPoolName(items[25].trim());
		this.setEvtContent(items[26].trim());
		this.setNoticeId(items[27].trim());
		this.setNoticeType(items[28].trim());
		this.setEvtCollectTime(items[29].trim());
		this.setEvtChorusSn(items[30].trim());
		this.setDevRemark(items[31].trim());
		this.setCellNo(items[32].trim());
		this.setUpDeviceNum(items[33].trim());
		this.setUpTid(items[34].trim());
		
		
		/* 2023-08-03 강대윤 추가 
		 * 2024-01-23 강대윤 추가*/
		if (detailCmd2 == FomsEvent.DETAIL_CMD2_AMI_GEN || detailCmd2 == FomsEvent.DETAIL_CMD2_AMI_CLR)
		{
			this.setMangTypeNm(items[38].trim());
			this.setPrAlarm(items[39].trim());
			this.setBizCustLevel(items[40].trim());
			this.setBizCustomerIds(items[41].trim());
			this.setBizCustomerNames(items[42].trim());
			this.setUpFdf(items[43].trim());
			this.setUpDistance(items[44].trim());
			this.setPanelRiskCode(items[45].trim());
			this.setPanelRiskName(items[46].trim());
			this.setTeamGroupIds(items[47].trim());
			this.setDongCd(items[48].trim());
			this.setDongNm(items[49].trim());
			if(items.length -1 >= 50){
				this.setNetType(items[50].trim());
			}
		}else if (detailCmd2 == FomsEvent.DETAIL_CMD2_ENV_GEN || detailCmd2 == FomsEvent.DETAIL_CMD2_ENV_CLR){
			this.setMangTypeNm(items[35].trim());
			this.setPrAlarm(items[36].trim());
			this.setBizCustLevel(items[37].trim());
			this.setBizCustomerIds(items[38].trim());
			this.setBizCustomerNames(items[39].trim());
			this.setUpFdf(items[40].trim());
			this.setUpDistance(items[41].trim());
			this.setPanelRiskCode(items[42].trim());
			this.setPanelRiskName(items[43].trim());	
			this.setTeamGroupIds(items[44].trim());
			this.setDongCd(items[45].trim());
			this.setDongNm(items[46].trim());
			if(items.length -1 >= 47){
				this.setNetType(items[47].trim());
			}
		}
		
		

	}
}
