package com.skb.mi.realtime.foms;

public class FomsNetFaultEvent extends FomsFaultEvent {
	private	String	netVocCnt;
	private	String	iptvVocCnt; 
	private	String	netAlarmCnt; 
	private	String	iptvAlarmCnt; 
	private	String	phoneAlarmCnt; 
	private	String	voipVocCnt ;
	private	String	devAlarmType;
	private	String	mAlarmCnt;
	private	String	mNetAlarmCnt; 
	private	String	mIptvAlarmCnt; 
	private	String	mPhoneAlarmCnt; 
	private	String	mNetVocCnt;
	private	String	mIptvVocCnt; 
	private	String	mVoipVocCnt;
	private	String	bAlarmCnt;
	private	String	bNetAlarmCnt; 
	private	String	bIptvAlarmCnt; 
	private	String	bPhoneAlarmCnt; 
	private	String	bNetVocCnt;
	private	String	bIptvVocCnt; 
	private	String	bVoipVocCnt;

	public String getNetVocCnt() {
		return netVocCnt;
	}
	public void setNetVocCnt(String netVocCnt) {
		this.netVocCnt = netVocCnt;
	}
	public String getIptvVocCnt() {
		return iptvVocCnt;
	}
	public void setIptvVocCnt(String iptvVocCnt) {
		this.iptvVocCnt = iptvVocCnt;
	}
	public String getNetAlarmCnt() {
		return netAlarmCnt;
	}
	public void setNetAlarmCnt(String netAlarmCnt) {
		this.netAlarmCnt = netAlarmCnt;
	}
	public String getIptvAlarmCnt() {
		return iptvAlarmCnt;
	}
	public void setIptvAlarmCnt(String iptvAlarmCnt) {
		this.iptvAlarmCnt = iptvAlarmCnt;
	}
	public String getPhoneAlarmCnt() {
		return phoneAlarmCnt;
	}
	public void setPhoneAlarmCnt(String phoneAlarmCnt) {
		this.phoneAlarmCnt = phoneAlarmCnt;
	}
	public String getVoipVocCnt() {
		return voipVocCnt;
	}
	public void setVoipVocCnt(String voipVocCnt) {
		this.voipVocCnt = voipVocCnt;
	}
	public String getDevAlarmType() {
		return devAlarmType;
	}
	public void setDevAlarmType(String devAlarmType) {
		this.devAlarmType = devAlarmType;
	}
	public String getmAlarmCnt() {
		return mAlarmCnt;
	}
	public void setmAlarmCnt(String mAlarmCnt) {
		this.mAlarmCnt = mAlarmCnt;
	}
	public String getmNetAlarmCnt() {
		return mNetAlarmCnt;
	}
	public void setmNetAlarmCnt(String mNetAlarmCnt) {
		this.mNetAlarmCnt = mNetAlarmCnt;
	}
	public String getmIptvAlarmCnt() {
		return mIptvAlarmCnt;
	}
	public void setmIptvAlarmCnt(String mIptvAlarmCnt) {
		this.mIptvAlarmCnt = mIptvAlarmCnt;
	}
	public String getmPhoneAlarmCnt() {
		return mPhoneAlarmCnt;
	}
	public void setmPhoneAlarmCnt(String mPhoneAlarmCnt) {
		this.mPhoneAlarmCnt = mPhoneAlarmCnt;
	}
	public String getmNetVocCnt() {
		return mNetVocCnt;
	}
	public void setmNetVocCnt(String mNetVocCnt) {
		this.mNetVocCnt = mNetVocCnt;
	}
	public String getmIptvVocCnt() {
		return mIptvVocCnt;
	}
	public void setmIptvVocCnt(String mIptvVocCnt) {
		this.mIptvVocCnt = mIptvVocCnt;
	}
	public String getmVoipVocCnt() {
		return mVoipVocCnt;
	}
	public void setmVoipVocCnt(String mVoipVocCnt) {
		this.mVoipVocCnt = mVoipVocCnt;
	}
	public String getbAlarmCnt() {
		return bAlarmCnt;
	}
	public void setbAlarmCnt(String bAlarmCnt) {
		this.bAlarmCnt = bAlarmCnt;
	}
	public String getbNetAlarmCnt() {
		return bNetAlarmCnt;
	}
	public void setbNetAlarmCnt(String bNetAlarmCnt) {
		this.bNetAlarmCnt = bNetAlarmCnt;
	}
	public String getbIptvAlarmCnt() {
		return bIptvAlarmCnt;
	}
	public void setbIptvAlarmCnt(String bIptvAlarmCnt) {
		this.bIptvAlarmCnt = bIptvAlarmCnt;
	}
	public String getbPhoneAlarmCnt() {
		return bPhoneAlarmCnt;
	}
	public void setbPhoneAlarmCnt(String bPhoneAlarmCnt) {
		this.bPhoneAlarmCnt = bPhoneAlarmCnt;
	}
	public String getbNetVocCnt() {
		return bNetVocCnt;
	}
	public void setbNetVocCnt(String bNetVocCnt) {
		this.bNetVocCnt = bNetVocCnt;
	}
	public String getbIptvVocCnt() {
		return bIptvVocCnt;
	}
	public void setbIptvVocCnt(String bIptvVocCnt) {
		this.bIptvVocCnt = bIptvVocCnt;
	}
	public String getbVoipVocCnt() {
		return bVoipVocCnt;
	}
	public void setbVoipVocCnt(String bVoipVocCnt) {
		this.bVoipVocCnt = bVoipVocCnt;
	}
	
	public FomsNetFaultEvent(byte detailCmd2, String[] items) {
		super(detailCmd2, items);

		this.setNetVocCnt(items[35].trim());
		this.setIptvVocCnt(items[36].trim());
		this.setNetAlarmCnt(items[37].trim());
		this.setIptvAlarmCnt(items[38].trim());
		this.setPhoneAlarmCnt(items[39].trim());
		this.setVoipVocCnt(items[40].trim());
		this.setDevAlarmType(items[41].trim());
		this.setmAlarmCnt(items[42].trim());
		this.setmNetAlarmCnt(items[43].trim());
		this.setmIptvAlarmCnt(items[44].trim());
		this.setmPhoneAlarmCnt(items[45].trim());
		this.setmNetVocCnt(items[46].trim());
		this.setmIptvVocCnt(items[47].trim());
		this.setmVoipVocCnt(items[48].trim());
		this.setbAlarmCnt(items[49].trim());
		this.setbNetAlarmCnt(items[50].trim());
		this.setbIptvAlarmCnt(items[51].trim());
		this.setbPhoneAlarmCnt(items[52].trim());
		this.setbNetVocCnt(items[53].trim());
		this.setbIptvVocCnt(items[54].trim());
		this.setbVoipVocCnt(items[55].trim());
		
		/* 2023-08-03 강대윤 추가 
		 * 2024-01-23 강대윤 추가
		 * */
		this.setMangTypeNm(items[56].trim());
		this.setPrAlarm(items[57].trim());
		this.setBizCustLevel(items[58].trim());
		this.setBizCustomerIds(items[59].trim());
		this.setBizCustomerNames(items[60].trim());
		this.setUpFdf(items[61].trim());
		this.setUpDistance(items[62].trim());
		this.setPanelRiskCode(items[63].trim());
		this.setPanelRiskName(items[64].trim());
		this.setTeamGroupIds(items[65].trim());
		this.setDongCd(items[66].trim());
		this.setDongNm(items[67].trim());
		if(items.length -1 >= 68){
			this.setNetType(items[68].trim());
		}
	}
}
