package com.skb.mi.realtime.foms;

public class FomsEvent {
	
	public static	byte	DETAIL_CMD1			= 0x2b;
	public static	byte	DETAIL_CMD2_INIT	= 0x51;	/* INIT 요청 */
	public static	byte	DETAIL_CMD2_POLL	= (byte) 0xff;	/* POLL 요청 */
	
	public static	byte	DETAIL_CMD2_INIT_NET	= 0x5a;	/* 기발생중 장애데이터(일반장애용) */
	public static	byte	DETAIL_CMD2_INIT_AMI	= 0x59;	/* 기발생중 장애데이터 */
	public static	byte	DETAIL_CMD2_INIT_ENV	= 0x69;	/* 기발생중 장애데이터(환경감시 장애용) */
	public static	byte	DETAIL_CMD2_INIT_END	= (byte) 0xfe;	/* 기발생중 장애데이터 공급완료 */
	
	public static	byte	DETAIL_CMD2_NET_GEN	= 0x5b;	/* 가입자망 장애발생 */
	public static	byte	DETAIL_CMD2_NET_CLR	= 0x5d;	/* 가입자망 장애해제 */
	public static	byte	DETAIL_CMD2_AMI_GEN	= 0x58;	/* AMI 장애발생 */
	public static	byte	DETAIL_CMD2_AMI_CLR	= 0x57;	/* AMI 장애해제 */
	public static	byte	DETAIL_CMD2_ENV_GEN	= 0x68;	/* 환경감시 장애발생 */
	public static	byte	DETAIL_CMD2_ENV_CLR	= 0x67;	/* 환경감시 장애해제 */
	public static	byte	DETAIL_CMD2_VOC		= 0x5e;	/* 실시간 장애 VoC 데이터 : 미처리*/

	private	byte	detailCmd2;

	private	String	evtKind;
	private	String	evtSerialNo;
	
	public FomsEvent() {
		
	}
	
	public FomsEvent(byte detailCmd2, String[] items) {
		this.detailCmd2 = detailCmd2;
		this.evtKind = items[0].trim();
		this.evtSerialNo = items[1].trim();
	}

	public byte getDetailCmd2() {
		return detailCmd2;
	}
	public String getEvtKind() {
		return evtKind;
	}
	public String getEvtSerialNo() {
		return evtSerialNo;
	}
}
