package com.skb.mi.realtime;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.ResultSetMetaData;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.LinkedList;

import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.DBController;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.MiscUtils;
import com.skb.mi.common.OutputLog;

public class ChangeSwingDbPassword {
//	final private int			PREPARED_STATEMENT  = 1;
//	final private String		ABSOLUTE_PATH 		= "/home/miuser/kmkang/data";
//	final private String		TABLE_NAME			= "ZOSS_TPO";

	DBController				neifController;
	String						neifUrl, neifUserName, neifPassword, neifNextPassword;
	String						cbDbXml, cbTargetXml, cbRestartSh;

	ConfigManager				configManager;
	OutputLog					outputLog;
	
	final static public String	CHANGE_MODE		= "CHANGE_MODE";

	final static String	CHANEG_MODE_FILE	= "FILE";
	final static String	CHANEG_MODE_DB		= "DB";
	final static String	CHANEG_MODE_ALL		= "ALL";
	
	private String	changeMode = CHANEG_MODE_ALL;

    public ChangeSwingDbPassword (String[] args) {

		try {
			outputLog = new OutputLog (true, this.getClass().getName (), EnvManager.env.getLogs());
			outputLog.write ("Start !!!");

			//readDbInfo ();
			
			String tmp = EnvManager.env.getOptionValue(CHANGE_MODE);
			if (CHANEG_MODE_FILE.equals(tmp)) {
				changeMode = CHANEG_MODE_FILE;
			} else if (CHANEG_MODE_DB.equals(tmp)) {
				changeMode = CHANEG_MODE_DB;
			}
			
			String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
			configManager = new ConfigManager(cfgFile);
			neifUrl = configManager.getConfig(Constants.NEIF_DB, Constants.DB_URL);
			neifUserName = configManager.getConfig(Constants.NEIF_DB, Constants.USER_NAME);
			neifPassword = configManager.getConfig(Constants.NEIF_DB, Constants.PASSWORD);
			neifNextPassword = configManager.getConfig(Constants.NEIF_DB, Constants.NEXT_PASSWORD);

			cbDbXml = configManager.getConfig(Constants.CM_BATCH, Constants.CB_DB_XML);
			cbRestartSh = configManager.getConfig(Constants.CM_BATCH, Constants.CB_RESTART_SH);
			cbTargetXml = cbDbXml + "." + MiscUtils.getAlphaNumeric(neifNextPassword);

			outputLog.write("neifUrl : " + neifUrl);
			outputLog.write("neifUserName : " + neifUserName);
			outputLog.write("neifPassword : " + neifPassword);
			outputLog.write("neifNextPassword : " + neifNextPassword);
			outputLog.write("cbDbXml : " + cbDbXml);
			outputLog.write("cbRestartSh : " + cbRestartSh);
			outputLog.write("cbTargetXml : " + cbTargetXml);

		} catch (Exception e ) {
			System.out.println ("readDbInfo Exception : " + e);
			System.out.println ("Finish : " + getDateSecond ());
			System.exit (0);
		}	

		try {
			if (CHANEG_MODE_DB.equals(changeMode) || CHANEG_MODE_ALL.equals(changeMode)) {
				neifController = new DBController (DBController.ORACLE_DB, neifUrl, neifUserName, neifPassword);
				neifController.getStmt ().executeUpdate ("ALTER USER NEADAMS IDENTIFIED BY \"" + neifNextPassword + "\" REPLACE \"" + neifPassword + "\"");
				neifController.closeDB ();
				outputLog.write(String.format("NEIF DB : password changed. (%s -> %s)", neifPassword, neifNextPassword));
			}
			
			if (CHANEG_MODE_FILE.equals(changeMode) || CHANEG_MODE_ALL.equals(changeMode)) {
				// switch
				configManager.set(Constants.NEIF_DB, Constants.PASSWORD, neifNextPassword);
				configManager.set(Constants.NEIF_DB, Constants.NEXT_PASSWORD, neifPassword);

				configManager.write(configManager.getFileName());
				//writeDbInfo ();
				
				outputLog.write("changed : " + configManager.getFileName());
				
				String cmd = String.format("cp -f %s %s", cbTargetXml, cbDbXml);
				Runtime.getRuntime().exec(cmd);
				outputLog.write("did : " + cmd);
				
				Runtime.getRuntime().exec(cbRestartSh);
				
				outputLog.write("did " + cbRestartSh);
			}
			
		} catch (Exception e) {
			outputLog.write(e);
		}
//		selectColumnType ();
//		dbController.closeDB ();
		outputLog.write("Finish");
    }

    /*
	public void readDbInfo () throws Exception {
		String	oneLine;
		FileReader	fileReader = new FileReader (ABSOLUTE_PATH + File.separator + "data" + File.separator + "db.info");
		BufferedReader bufferedReader = new BufferedReader (fileReader);
		dbUrl = bufferedReader.readLine ();
		userName = bufferedReader.readLine ();
		password = bufferedReader.readLine ();
		neifUrl = bufferedReader.readLine ();
		neifUserName = bufferedReader.readLine ();
		neifPassword = bufferedReader.readLine ();
		System.out.println ("neifUrl : " + neifUrl);
		System.out.println ("neifUserName : " + neifUserName);
		System.out.println ("neifPassword : " + neifPassword);
		bufferedReader.close ();
		fileReader.close ();
	}

	public void writeDbInfo () throws Exception {
		String	oneLine;
		FileWriter	fileWriter = new FileWriter (ABSOLUTE_PATH + File.separator + "data" + File.separator + "db.info");
		BufferedWriter bufferedWriter = new BufferedWriter (fileWriter);
		bufferedWriter.write (dbUrl); bufferedWriter.newLine ();
		bufferedWriter.write (userName); bufferedWriter.newLine ();
		bufferedWriter.write (password); bufferedWriter.newLine ();
		bufferedWriter.write (neifUrl); bufferedWriter.newLine ();
		bufferedWriter.write (neifUserName); bufferedWriter.newLine ();
		bufferedWriter.write (neifPassword); bufferedWriter.newLine ();
		bufferedWriter.close ();
		fileWriter.close ();
	}
	*/

	public String getDateSecond () {
		Calendar	calendar = Calendar.getInstance ();

		return String.format ("%04d-%02d-%02d %02d:%02d:%02d",
			calendar.get(Calendar.YEAR),
			calendar.get(Calendar.MONTH) + 1,
			calendar.get(Calendar.DAY_OF_MONTH),
			calendar.get(Calendar.HOUR_OF_DAY),
			calendar.get(Calendar.MINUTE),
			calendar.get(Calendar.SECOND));
	}

    public static void main (String [] args) {
    	Options options = new Options();
		Option chgMode = Option.builder().longOpt(CHANGE_MODE)
				.desc("Change Mode (FILE: Only File, DB: Only DB, ALL: FILE & DB)").hasArg().argName(CHANGE_MODE).build();
		options.addOption(chgMode);
    	EnvManager envManager = new EnvManager(args, options);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("ChangeSwingDbPassword", envManager.getOptions());
    		System.exit(0);
    	}
        new ChangeSwingDbPassword (args);
    }
}

