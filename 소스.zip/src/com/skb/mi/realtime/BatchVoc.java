package com.skb.mi.realtime;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.File;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Calendar;

import com.skb.mi.common.DBController;

public class BatchVoc {
	final	private	int			COLUMN_COUNT = 5;
    DBController                dbController;
	String						dbUrl, userName, password;

	String						insertQuery, selectQuery, deleteQuery;

	String						absolutePath;
	PreparedStatement			updateStatement;

    public BatchVoc (String[] args) {
		System.out.println ("프로그램 시작 : " + getDateSecond ());
		absolutePath = args [0];

        try {
            readDbInfo ();
			readQueryInfo (args [1]);
            dbController = new DBController (DBController.ORACLE_DB, dbUrl, userName, password);
			updateStatement = dbController.getConnection ().prepareStatement (insertQuery);
        } catch (Exception e ) {
			System.out.println ("DB정보 조회 Exception : " + e);
			System.out.println ("프로그램 종료 : " + getDateSecond ());
			System.exit (1);
        }

		realTimeCollect ();

		dbController.closeDB ();
		System.out.println ("프로그램 종료 : " + getDateSecond ());
    }

	public void readDbInfo () throws Exception {
		String	oneLine;
		FileReader	fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + "db.info");
		BufferedReader bufferedReader = new BufferedReader (fileReader);
		dbUrl = bufferedReader.readLine ();
		userName = bufferedReader.readLine ();
		password = bufferedReader.readLine ();
		bufferedReader.close ();
		fileReader.close ();
	}

	public void readQueryInfo (String queryFile) throws Exception {
		String	oneLine;
		FileReader	fileReader = new FileReader (absolutePath + File.separator + "data" + File.separator + queryFile);
		BufferedReader bufferedReader = new BufferedReader (fileReader);
		deleteQuery = bufferedReader.readLine ();
		insertQuery = bufferedReader.readLine ();
		selectQuery = "";
		while ((oneLine = bufferedReader.readLine ()) != null) {
			selectQuery += " " + oneLine;
		}
		System.out.println ("deleteQuery : " + deleteQuery);
		System.out.println ("insertQuery : " + insertQuery);
		System.out.println ("selectQuery : " + selectQuery);
		bufferedReader.close ();
		fileReader.close ();
	}

    public void realTimeCollect () {
		ResultSet	resultSet;
		String		query = "";
		try {
			query = deleteQuery;
//			dbController.getStmt ().executeUpdate (deleteQuery);
//			System.out.println ("Delete Table......");
			resultSet = dbController.getStmt ().executeQuery (selectQuery);

			int	index = 1;
			while (resultSet.next ()) {
				for (index = 1; index <= COLUMN_COUNT; ++ index) {
                    updateStatement.setString (index,  resultSet.getString (index));
                    updateStatement.setString (index + COLUMN_COUNT,  resultSet.getString (index));
				}
				updateStatement.addBatch ();
			}
			resultSet.close ();
			updateStatement.executeBatch ();
			updateStatement.close ();
		} catch (Exception e) {
			System.out.println ("query : " + query);
			System.out.println ("realTimeCollect Exception : " + e);
		}
    }
    
    public String getDateSecond () {
        Calendar    calendar = Calendar.getInstance ();

        return String.format ("%04d-%02d-%02d %02d:%02d:%02d",
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH) + 1,
            calendar.get(Calendar.DAY_OF_MONTH),
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            calendar.get(Calendar.SECOND));
    }

    public static void main (String [] args) {
        if (args.length != 2) {
            System.out.println ("Usage : BatchVoc directory QueryFile");
            System.exit (0);
        }
        new BatchVoc (args);
    }
}

