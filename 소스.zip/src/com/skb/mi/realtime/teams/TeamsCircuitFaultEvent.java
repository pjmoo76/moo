package com.skb.mi.realtime.teams;

public class TeamsCircuitFaultEvent extends TeamsEvent {
	private	String	alarmNo;
	private	String	lineNo;
	private	String	lineName;
	private	String	custNo;
	private	String	custName;
	private	String	custTelNo;
	private	String	entServiceNo;
	private	String	lineTypeCd;
	private	String	lineType;
	private	String	serviceTypeCd;
	private	String	serviceType;
	private	String	leaseLineNo;
	private	String	leaseCorpCd;
	private	String	leaseCorp;
	private	String	linkCorpCd;
	private	String	linkCorp;
	private	String	capacityCd;
	private	String	capacity;
	private	String	uOrgId;
	private	String	uOrgName;
	private	String	uSystemName;
	private	String	uSystemOrgId;
	private	String	uSystemOrgName;
	private	String	lOrgId;
	private	String	lOrgName;
	private	String	lSystemName;
	private	String	lSystemOrgId;
	private	String	lSystemOrgName;
	private	String	nmsAlarmNo;
	private	String	nmsCd;
	private	String	modelId;
	private	String	modelName;
	private	String	neName;
	private	String	tid;
	private	String	ipAddr;
	private	String	equipUsage;
	private	String	portDescr;
	private	String	location;
	private	String	reason;
	private	String	orgId;
	private	String	orgName;
	private	String	occurTime;
	private	String	alarmKey;
	private	String	workYn;
	private	String	ticketYn;
	private	String	egovAlarmYn;
	private	String	backboneYn;
	private	String	ofdAlarmYn;
	private	String	postGroupCd;
	private	String	postGroupName;
	private	String	postCd;
	private	String	postName;
	private	String	closeMode;
	private	String	lineClassCd;
	private	String	lineClass;
	private	String	alarmIdOther;
	private	String	lCityId;
	private	String	lCityName;
	private	String	lGuId;
	private	String	lGuName;
	private	String	trunkId;
	private	String	trunkName;
	private	String	networkId;
	private	String	networkName;
	private	String	uTrRoomId;
	private	String	uTrRoomName;
	private	String	lTrRoomId;
	private	String	lTrRoomName;
	private	String	trRoomId;
	private	String	trRoomName;
	private	String	occurRTime;
	private	String	conPortDescr;
	private	String	rasId;
	private	String	macAddr;
	private	String	supProviderCd;
	private	String	supProviderName;
	private	String	nwCarrierCd;
	private	String	nwCarrierName;
	private	String	shopName;
	private	String	cotRtType;
	private	String	lineTrRoomId;
	private	String	lineTrRoomName;
	private	String	qdfInfoStr;
	private	String	ogTie1;
	private	String	ogTie2;
	private	String	icTie1;
	private	String	icTie2;
	private	String	focusYn;
	private	String	userAlarmLevel;
	private	String	userReason;
	private	String	ringId;
	private	String	ringName;
	private	String	modelType;
	private	String	lineStatusCd;
	private	String	lineStatus;
	private	String	effortStatus;
	private	String	lineAmId;
	public String getAlarmNo() {
		return alarmNo;
	}
	public void setAlarmNo(String alarmNo) {
		this.alarmNo = alarmNo;
	}
	public String getLineNo() {
		return lineNo;
	}
	public void setLineNo(String lineNo) {
		this.lineNo = lineNo;
	}
	public String getLineName() {
		return lineName;
	}
	public void setLineName(String lineName) {
		this.lineName = lineName;
	}
	public String getCustNo() {
		return custNo;
	}
	public void setCustNo(String custNo) {
		this.custNo = custNo;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustTelNo() {
		return custTelNo;
	}
	public void setCustTelNo(String custTelNo) {
		this.custTelNo = custTelNo;
	}
	public String getEntServiceNo() {
		return entServiceNo;
	}
	public void setEntServiceNo(String entServiceNo) {
		this.entServiceNo = entServiceNo;
	}
	public String getLineTypeCd() {
		return lineTypeCd;
	}
	public void setLineTypeCd(String lineTypeCd) {
		this.lineTypeCd = lineTypeCd;
	}
	public String getLineType() {
		return lineType;
	}
	public void setLineType(String lineType) {
		this.lineType = lineType;
	}
	public String getServiceTypeCd() {
		return serviceTypeCd;
	}
	public void setServiceTypeCd(String serviceTypeCd) {
		this.serviceTypeCd = serviceTypeCd;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getLeaseLineNo() {
		return leaseLineNo;
	}
	public void setLeaseLineNo(String leaseLineNo) {
		this.leaseLineNo = leaseLineNo;
	}
	public String getLeaseCorpCd() {
		return leaseCorpCd;
	}
	public void setLeaseCorpCd(String leaseCorpCd) {
		this.leaseCorpCd = leaseCorpCd;
	}
	public String getLeaseCorp() {
		return leaseCorp;
	}
	public void setLeaseCorp(String leaseCorp) {
		this.leaseCorp = leaseCorp;
	}
	public String getLinkCorpCd() {
		return linkCorpCd;
	}
	public void setLinkCorpCd(String linkCorpCd) {
		this.linkCorpCd = linkCorpCd;
	}
	public String getLinkCorp() {
		return linkCorp;
	}
	public void setLinkCorp(String linkCorp) {
		this.linkCorp = linkCorp;
	}
	public String getCapacityCd() {
		return capacityCd;
	}
	public void setCapacityCd(String capacityCd) {
		this.capacityCd = capacityCd;
	}
	public String getCapacity() {
		return capacity;
	}
	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}
	public String getuOrgId() {
		return uOrgId;
	}
	public void setuOrgId(String uOrgId) {
		this.uOrgId = uOrgId;
	}
	public String getuOrgName() {
		return uOrgName;
	}
	public void setuOrgName(String uOrgName) {
		this.uOrgName = uOrgName;
	}
	public String getuSystemName() {
		return uSystemName;
	}
	public void setuSystemName(String uSystemName) {
		this.uSystemName = uSystemName;
	}
	public String getuSystemOrgId() {
		return uSystemOrgId;
	}
	public void setuSystemOrgId(String uSystemOrgId) {
		this.uSystemOrgId = uSystemOrgId;
	}
	public String getuSystemOrgName() {
		return uSystemOrgName;
	}
	public void setuSystemOrgName(String uSystemOrgName) {
		this.uSystemOrgName = uSystemOrgName;
	}
	public String getlOrgId() {
		return lOrgId;
	}
	public void setlOrgId(String lOrgId) {
		this.lOrgId = lOrgId;
	}
	public String getlOrgName() {
		return lOrgName;
	}
	public void setlOrgName(String lOrgName) {
		this.lOrgName = lOrgName;
	}
	public String getlSystemName() {
		return lSystemName;
	}
	public void setlSystemName(String lSystemName) {
		this.lSystemName = lSystemName;
	}
	public String getlSystemOrgId() {
		return lSystemOrgId;
	}
	public void setlSystemOrgId(String lSystemOrgId) {
		this.lSystemOrgId = lSystemOrgId;
	}
	public String getlSystemOrgName() {
		return lSystemOrgName;
	}
	public void setlSystemOrgName(String lSystemOrgName) {
		this.lSystemOrgName = lSystemOrgName;
	}
	public String getNmsAlarmNo() {
		return nmsAlarmNo;
	}
	public void setNmsAlarmNo(String nmsAlarmNo) {
		this.nmsAlarmNo = nmsAlarmNo;
	}
	public String getNmsCd() {
		return nmsCd;
	}
	public void setNmsCd(String nmsCd) {
		this.nmsCd = nmsCd;
	}
	public String getModelId() {
		return modelId;
	}
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getNeName() {
		return neName;
	}
	public void setNeName(String neName) {
		this.neName = neName;
	}
	public String getTid() {
		return tid;
	}
	public void setTid(String tid) {
		this.tid = tid;
	}
	public String getIpAddr() {
		return ipAddr;
	}
	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}
	public String getEquipUsage() {
		return equipUsage;
	}
	public void setEquipUsage(String equipUsage) {
		this.equipUsage = equipUsage;
	}
	public String getPortDescr() {
		return portDescr;
	}
	public void setPortDescr(String portDescr) {
		this.portDescr = portDescr;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getOccurTime() {
		return occurTime;
	}
	public void setOccurTime(String occurTime) {
		this.occurTime = occurTime;
	}
	public String getAlarmKey() {
		return alarmKey;
	}
	public void setAlarmKey(String alarmKey) {
		this.alarmKey = alarmKey;
	}
	public String getWorkYn() {
		return workYn;
	}
	public void setWorkYn(String workYn) {
		this.workYn = workYn;
	}
	public String getTicketYn() {
		return ticketYn;
	}
	public void setTicketYn(String ticketYn) {
		this.ticketYn = ticketYn;
	}
	public String getEgovAlarmYn() {
		return egovAlarmYn;
	}
	public void setEgovAlarmYn(String egovAlarmYn) {
		this.egovAlarmYn = egovAlarmYn;
	}
	public String getBackboneYn() {
		return backboneYn;
	}
	public void setBackboneYn(String backboneYn) {
		this.backboneYn = backboneYn;
	}
	public String getOfdAlarmYn() {
		return ofdAlarmYn;
	}
	public void setOfdAlarmYn(String ofdAlarmYn) {
		this.ofdAlarmYn = ofdAlarmYn;
	}
	public String getPostGroupCd() {
		return postGroupCd;
	}
	public void setPostGroupCd(String postGroupCd) {
		this.postGroupCd = postGroupCd;
	}
	public String getPostGroupName() {
		return postGroupName;
	}
	public void setPostGroupName(String postGroupName) {
		this.postGroupName = postGroupName;
	}
	public String getPostCd() {
		return postCd;
	}
	public void setPostCd(String postCd) {
		this.postCd = postCd;
	}
	public String getPostName() {
		return postName;
	}
	public void setPostName(String postName) {
		this.postName = postName;
	}
	public String getCloseMode() {
		return closeMode;
	}
	public void setCloseMode(String closeMode) {
		this.closeMode = closeMode;
	}
	public String getLineClassCd() {
		return lineClassCd;
	}
	public void setLineClassCd(String lineClassCd) {
		this.lineClassCd = lineClassCd;
	}
	public String getLineClass() {
		return lineClass;
	}
	public void setLineClass(String lineClass) {
		this.lineClass = lineClass;
	}
	public String getAlarmIdOther() {
		return alarmIdOther;
	}
	public void setAlarmIdOther(String alarmIdOther) {
		this.alarmIdOther = alarmIdOther;
	}
	public String getlCityId() {
		return lCityId;
	}
	public void setlCityId(String lCityId) {
		this.lCityId = lCityId;
	}
	public String getlCityName() {
		return lCityName;
	}
	public void setlCityName(String lCityName) {
		this.lCityName = lCityName;
	}
	public String getlGuId() {
		return lGuId;
	}
	public void setlGuId(String lGuId) {
		this.lGuId = lGuId;
	}
	public String getlGuName() {
		return lGuName;
	}
	public void setlGuName(String lGuName) {
		this.lGuName = lGuName;
	}
	public String getTrunkId() {
		return trunkId;
	}
	public void setTrunkId(String trunkId) {
		this.trunkId = trunkId;
	}
	public String getTrunkName() {
		return trunkName;
	}
	public void setTrunkName(String trunkName) {
		this.trunkName = trunkName;
	}
	public String getNetworkId() {
		return networkId;
	}
	public void setNetworkId(String networkId) {
		this.networkId = networkId;
	}
	public String getNetworkName() {
		return networkName;
	}
	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}
	public String getuTrRoomId() {
		return uTrRoomId;
	}
	public void setuTrRoomId(String uTrRoomId) {
		this.uTrRoomId = uTrRoomId;
	}
	public String getuTrRoomName() {
		return uTrRoomName;
	}
	public void setuTrRoomName(String uTrRoomName) {
		this.uTrRoomName = uTrRoomName;
	}
	public String getlTrRoomId() {
		return lTrRoomId;
	}
	public void setlTrRoomId(String lTrRoomId) {
		this.lTrRoomId = lTrRoomId;
	}
	public String getlTrRoomName() {
		return lTrRoomName;
	}
	public void setlTrRoomName(String lTrRoomName) {
		this.lTrRoomName = lTrRoomName;
	}
	public String getTrRoomId() {
		return trRoomId;
	}
	public void setTrRoomId(String trRoomId) {
		this.trRoomId = trRoomId;
	}
	public String getTrRoomName() {
		return trRoomName;
	}
	public void setTrRoomName(String trRoomName) {
		this.trRoomName = trRoomName;
	}
	public String getOccurRTime() {
		return occurRTime;
	}
	public void setOccurRTime(String occurRTime) {
		this.occurRTime = occurRTime;
	}
	public String getConPortDescr() {
		return conPortDescr;
	}
	public void setConPortDescr(String conPortDescr) {
		this.conPortDescr = conPortDescr;
	}
	public String getRasId() {
		return rasId;
	}
	public void setRasId(String rasId) {
		this.rasId = rasId;
	}
	public String getMacAddr() {
		return macAddr;
	}
	public void setMacAddr(String macAddr) {
		this.macAddr = macAddr;
	}
	public String getSupProviderCd() {
		return supProviderCd;
	}
	public void setSupProviderCd(String supProviderCd) {
		this.supProviderCd = supProviderCd;
	}
	public String getSupProviderName() {
		return supProviderName;
	}
	public void setSupProviderName(String supProviderName) {
		this.supProviderName = supProviderName;
	}
	public String getNwCarrierCd() {
		return nwCarrierCd;
	}
	public void setNwCarrierCd(String nwCarrierCd) {
		this.nwCarrierCd = nwCarrierCd;
	}
	public String getNwCarrierName() {
		return nwCarrierName;
	}
	public void setNwCarrierName(String nwCarrierName) {
		this.nwCarrierName = nwCarrierName;
	}
	public String getShopName() {
		return shopName;
	}
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	public String getCotRtType() {
		return cotRtType;
	}
	public void setCotRtType(String cotRtType) {
		this.cotRtType = cotRtType;
	}
	public String getLineTrRoomId() {
		return lineTrRoomId;
	}
	public void setLineTrRoomId(String lineTrRoomId) {
		this.lineTrRoomId = lineTrRoomId;
	}
	public String getLineTrRoomName() {
		return lineTrRoomName;
	}
	public void setLineTrRoomName(String lineTrRoomName) {
		this.lineTrRoomName = lineTrRoomName;
	}
	public String getQdfInfoStr() {
		return qdfInfoStr;
	}
	public void setQdfInfoStr(String qdfInfoStr) {
		this.qdfInfoStr = qdfInfoStr;
	}
	public String getOgTie1() {
		return ogTie1;
	}
	public void setOgTie1(String ogTie1) {
		this.ogTie1 = ogTie1;
	}
	public String getOgTie2() {
		return ogTie2;
	}
	public void setOgTie2(String ogTie2) {
		this.ogTie2 = ogTie2;
	}
	public String getIcTie1() {
		return icTie1;
	}
	public void setIcTie1(String icTie1) {
		this.icTie1 = icTie1;
	}
	public String getIcTie2() {
		return icTie2;
	}
	public void setIcTie2(String icTie2) {
		this.icTie2 = icTie2;
	}
	public String getFocusYn() {
		return focusYn;
	}
	public void setFocusYn(String focusYn) {
		this.focusYn = focusYn;
	}
	public String getUserAlarmLevel() {
		return userAlarmLevel;
	}
	public void setUserAlarmLevel(String userAlarmLevel) {
		this.userAlarmLevel = userAlarmLevel;
	}
	public String getUserReason() {
		return userReason;
	}
	public void setUserReason(String userReason) {
		this.userReason = userReason;
	}
	public String getRingId() {
		return ringId;
	}
	public void setRingId(String ringId) {
		this.ringId = ringId;
	}
	public String getRingName() {
		return ringName;
	}
	public void setRingName(String ringName) {
		this.ringName = ringName;
	}
	public String getModelType() {
		return modelType;
	}
	public void setModelType(String modelType) {
		this.modelType = modelType;
	}
	public String getLineStatusCd() {
		return lineStatusCd;
	}
	public void setLineStatusCd(String lineStatusCd) {
		this.lineStatusCd = lineStatusCd;
	}
	public String getLineStatus() {
		return lineStatus;
	}
	public void setLineStatus(String lineStatus) {
		this.lineStatus = lineStatus;
	}
	public String getEffortStatus() {
		return effortStatus;
	}
	public void setEffortStatus(String effortStatus) {
		this.effortStatus = effortStatus;
	}
	public String getLineAmId() {
		return lineAmId;
	}
	public void setLineAmId(String lineAmId) {
		this.lineAmId = lineAmId;
	}
	public TeamsCircuitFaultEvent() {
		this.setEventType(TeamsEvent.CIRCUIT_FAULT);
	}
	public TeamsCircuitFaultEvent(String[] items) {
		this.setEventType(TeamsEvent.CIRCUIT_FAULT);

		this.alarmNo = items[0];
		this.setAlarmLevel(items[1]);
		this.lineNo = items[2];
		this.lineName = items[3];
		this.custNo = items[4];
		this.custName = items[5];
		this.custTelNo = items[6];
		this.entServiceNo = items[7];
		this.lineTypeCd = items[8];
		this.lineType = items[9];
		this.serviceTypeCd = items[10];
		this.serviceType = items[11];
		this.leaseLineNo = items[12];
		this.leaseCorpCd = items[13];
		this.leaseCorp = items[14];
		this.linkCorpCd = items[15];
		this.linkCorp = items[16];
		this.capacityCd = items[17];
		this.capacity = items[18];
		this.uOrgId = items[19];
		this.uOrgName = items[20];
		this.uSystemName = items[21];
		this.uSystemOrgId = items[22];
		this.uSystemOrgName = items[23];
		this.lOrgId = items[24];
		this.lOrgName = items[25];
		this.lSystemName = items[26];
		this.lSystemOrgId = items[27];
		this.lSystemOrgName = items[28];
		this.nmsAlarmNo = items[29];
		this.setMngGroupCd(items[30]);
		this.nmsCd = items[31];
		this.modelId = items[32];
		this.modelName = items[33];
		this.setNeId(items[34]);
		this.neName = items[35];
		this.tid = items[36];
		this.ipAddr = items[37];
		this.equipUsage = items[38];
		this.portDescr = items[39];
		this.location = items[40];
		this.reason = items[41];
		this.orgId = items[42];
		this.orgName = items[43];
		this.occurTime = items[44];
		this.alarmKey = items[45];
		this.workYn = items[46];
		this.ticketYn = items[47];
		this.egovAlarmYn = items[48];
		this.backboneYn = items[49];
		this.ofdAlarmYn = items[50];
		this.postGroupCd = items[51];
		this.postGroupName = items[52];
		this.postCd = items[53];
		this.postName = items[54];
		this.closeMode = items[55];
		this.lineClassCd = items[56];
		this.lineClass = items[57];
		this.alarmIdOther = items[58];
		this.lCityId = items[59];
		this.lCityName = items[60];
		this.lGuId = items[61];
		this.lGuName = items[62];
		this.trunkId = items[63];
		this.trunkName = items[64];
		this.networkId = items[65];
		this.networkName = items[66];
		this.uTrRoomId = items[67];
		this.uTrRoomName = items[68];
		this.lTrRoomId = items[69];
		this.lTrRoomName = items[70];
		this.trRoomId = items[71];
		this.trRoomName = items[72];
		this.occurRTime = items[73];
		this.conPortDescr = items[74];
		this.rasId = items[75];
		this.macAddr = items[76];
		this.supProviderCd = items[77];
		this.supProviderName = items[78];
		this.nwCarrierCd = items[79];
		this.nwCarrierName = items[80];
		this.shopName = items[81];
		this.cotRtType = items[82];
		this.lineTrRoomId = items[83];
		this.lineTrRoomName = items[84];
		this.qdfInfoStr = items[85];
		this.ogTie1 = items[86];
		this.ogTie2 = items[87];
		this.icTie1 = items[88];
		this.icTie2 = items[89];
		this.focusYn = items[90];
		this.userAlarmLevel = items[91];
		this.userReason = items[92];
		this.ringId = items[93];
		this.ringName = items[94];
		this.modelType = items[95];
		this.lineStatusCd = items[101];
		this.lineStatus = items[102];
		this.effortStatus = items[103];
		this.lineAmId = items[104];
	}
}
