package com.skb.mi.realtime.teams;

public class TeamsEquipFaultEvent extends TeamsEvent {
	private	String	alarmNo;
	private	String	nmsCd;
	private	String	modelCd;
	private	String	modelName;
	private	String	neName;
	private	String	tid;
	private	String	ipAddr;
	private	String	equipUsage;
	private	String	portDescr;
	private	String	location;
	private	String	reason;
	private	String	orgId;
	private	String	orgName;
	private	String	linCount;
	private	String	alarmDupCount;
	private	String	occurTime;
	private	String	alarmKey;
	private	String	workYn;
	private	String	ticketYn;
	private	String	egovAlarmYn;
	private	String	backboneYn;
	private	String	ofdAlarmYn;
	private	String	postGroupCd;
	private	String	postGroupName;
	private	String	postCd;
	private	String	postName;
	private	String	alarmDupYn;
	private	String	seriousAlarmYn;
	private	String	alarmTypCd;
	private	String	alarmIdOther;
	private	String	closeMode;
	private	String	modelType;
	private	String	networkIds;
	private	String	networkNames;
	private	String	trRoomId;
	private	String	trRoomName;
	private	String	cityId;
	private	String	cityName;
	private	String	guId;
	private	String	guName;
	private	String	occurRTime;
	private	String	rasId;
	private	String	macAddr;
	private	String	supProviderCd;
	private	String	supProviderName;
	private	String	nwCarrierCd;
	private	String	nwCarrierName;
	private	String	entServiceNo;
	private	String	etc;
	private	String	cotRtType;
	private	String	focusYn;
	private	String	userAlarmLevel;
	private	String	userReason;
	private	String	alarmKind;

	public String getAlarmNo() {
		return alarmNo;
	}
	public void setAlarmNo(String alarmNo) {
		this.alarmNo = alarmNo;
	}
	public String getNmsCd() {
		return nmsCd;
	}
	public void setNmsCd(String nmsCd) {
		this.nmsCd = nmsCd;
	}
	public String getModelCd() {
		return modelCd;
	}
	public void setModelCd(String modelCd) {
		this.modelCd = modelCd;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getNeName() {
		return neName;
	}
	public void setNeName(String neName) {
		this.neName = neName;
	}
	public String getTid() {
		return tid;
	}
	public void setTid(String tid) {
		this.tid = tid;
	}
	public String getIpAddr() {
		return ipAddr;
	}
	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}
	public String getEquipUsage() {
		return equipUsage;
	}
	public void setEquipUsage(String equipUsage) {
		this.equipUsage = equipUsage;
	}
	public String getPortDescr() {
		return portDescr;
	}
	public void setPortDescr(String portDescr) {
		this.portDescr = portDescr;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getLinCount() {
		return linCount;
	}
	public void setLinCount(String linCount) {
		this.linCount = linCount;
	}
	public String getAlarmDupCount() {
		return alarmDupCount;
	}
	public void setAlarmDupCount(String alarmDupCount) {
		this.alarmDupCount = alarmDupCount;
	}
	public String getOccurTime() {
		return occurTime;
	}
	public void setOccurTime(String occurTime) {
		this.occurTime = occurTime;
	}
	public String getAlarmKey() {
		return alarmKey;
	}
	public void setAlarmKey(String alarmKey) {
		this.alarmKey = alarmKey;
	}
	public String getWorkYn() {
		return workYn;
	}
	public void setWorkYn(String workYn) {
		this.workYn = workYn;
	}
	public String getTicketYn() {
		return ticketYn;
	}
	public void setTicketYn(String ticketYn) {
		this.ticketYn = ticketYn;
	}
	public String getEgovAlarmYn() {
		return egovAlarmYn;
	}
	public void setEgovAlarmYn(String egovAlarmYn) {
		this.egovAlarmYn = egovAlarmYn;
	}
	public String getBackboneYn() {
		return backboneYn;
	}
	public void setBackboneYn(String backboneYn) {
		this.backboneYn = backboneYn;
	}
	public String getOfdAlarmYn() {
		return ofdAlarmYn;
	}
	public void setOfdAlarmYn(String ofdAlarmYn) {
		this.ofdAlarmYn = ofdAlarmYn;
	}
	public String getPostGroupCd() {
		return postGroupCd;
	}
	public void setPostGroupCd(String postGroupCd) {
		this.postGroupCd = postGroupCd;
	}
	public String getPostGroupName() {
		return postGroupName;
	}
	public void setPostGroupName(String postGroupName) {
		this.postGroupName = postGroupName;
	}
	public String getPostCd() {
		return postCd;
	}
	public void setPostCd(String postCd) {
		this.postCd = postCd;
	}
	public String getPostName() {
		return postName;
	}
	public void setPostName(String postName) {
		this.postName = postName;
	}
	public String getAlarmDupYn() {
		return alarmDupYn;
	}
	public void setAlarmDupYn(String alarmDupYn) {
		this.alarmDupYn = alarmDupYn;
	}
	public String getSeriousAlarmYn() {
		return seriousAlarmYn;
	}
	public void setSeriousAlarmYn(String seriousAlarmYn) {
		this.seriousAlarmYn = seriousAlarmYn;
	}
	public String getAlarmTypCd() {
		return alarmTypCd;
	}
	public void setAlarmTypCd(String alarmTypCd) {
		this.alarmTypCd = alarmTypCd;
	}
	public String getAlarmIdOther() {
		return alarmIdOther;
	}
	public void setAlarmIdOther(String alarmIdOther) {
		this.alarmIdOther = alarmIdOther;
	}
	public String getCloseMode() {
		return closeMode;
	}
	public void setCloseMode(String closeMode) {
		this.closeMode = closeMode;
	}
	public String getModelType() {
		return modelType;
	}
	public void setModelType(String modelType) {
		this.modelType = modelType;
	}
	public String getNetworkIds() {
		return networkIds;
	}
	public void setNetworkIds(String networkIds) {
		this.networkIds = networkIds;
	}
	public String getNetworkNames() {
		return networkNames;
	}
	public void setNetworkNames(String networkNames) {
		this.networkNames = networkNames;
	}
	public String getTrRoomId() {
		return trRoomId;
	}
	public void setTrRoomId(String trRoomId) {
		this.trRoomId = trRoomId;
	}
	public String getTrRoomName() {
		return trRoomName;
	}
	public void setTrRoomName(String trRoomName) {
		this.trRoomName = trRoomName;
	}
	public String getCityId() {
		return cityId;
	}
	public void setCityId(String cityId) {
		this.cityId = cityId;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getGuId() {
		return guId;
	}
	public void setGuId(String guId) {
		this.guId = guId;
	}
	public String getGuName() {
		return guName;
	}
	public void setGuName(String guName) {
		this.guName = guName;
	}
	public String getOccurRTime() {
		return occurRTime;
	}
	public void setOccurRTime(String occurRTime) {
		this.occurRTime = occurRTime;
	}
	public String getRasId() {
		return rasId;
	}
	public void setRasId(String rasId) {
		this.rasId = rasId;
	}
	public String getMacAddr() {
		return macAddr;
	}
	public void setMacAddr(String macAddr) {
		this.macAddr = macAddr;
	}
	public String getSupProviderCd() {
		return supProviderCd;
	}
	public void setSupProviderCd(String supProviderCd) {
		this.supProviderCd = supProviderCd;
	}
	public String getSupProviderName() {
		return supProviderName;
	}
	public void setSupProviderName(String supProviderName) {
		this.supProviderName = supProviderName;
	}
	public String getNwCarrierCd() {
		return nwCarrierCd;
	}
	public void setNwCarrierCd(String nwCarrierCd) {
		this.nwCarrierCd = nwCarrierCd;
	}
	public String getNwCarrierName() {
		return nwCarrierName;
	}
	public void setNwCarrierName(String nwCarrierName) {
		this.nwCarrierName = nwCarrierName;
	}
	public String getEntServiceNo() {
		return entServiceNo;
	}
	public void setEntServiceNo(String entServiceNo) {
		this.entServiceNo = entServiceNo;
	}
	public String getEtc() {
		return etc;
	}
	public void setEtc(String etc) {
		this.etc = etc;
	}
	public String getCotRtType() {
		return cotRtType;
	}
	public void setCotRtType(String cotRtType) {
		this.cotRtType = cotRtType;
	}
	public String getFocusYn() {
		return focusYn;
	}
	public void setFocusYn(String focusYn) {
		this.focusYn = focusYn;
	}
	public String getUserAlarmLevel() {
		return userAlarmLevel;
	}
	public void setUserAlarmLevel(String userAlarmLevel) {
		this.userAlarmLevel = userAlarmLevel;
	}
	public String getUserReason() {
		return userReason;
	}
	public void setUserReason(String userReason) {
		this.userReason = userReason;
	}
	public String getAlarmKind() {
		return alarmKind;
	}
	public void setAlarmKind(String alarmKind) {
		this.alarmKind = alarmKind;
	}

	public TeamsEquipFaultEvent() {
		this.setEventType(TeamsEvent.EQUIP_FAULT);
	}

	public TeamsEquipFaultEvent(String[] items) {
		this.setEventType(TeamsEvent.EQUIP_FAULT);

		this.alarmNo = items[0];
		this.nmsCd = items[1];
		this.modelCd = items[2];
		this.modelName = items[3];
		this.setNeId(items[4]);
		this.neName = items[5];
		this.tid = items[6];
		this.ipAddr = items[7];
		this.equipUsage = items[8];
		this.setAlarmLevel(items[9]);
		this.portDescr = items[10];
		this.location = items[11];
		this.reason = items[12];
		this.orgId = items[13];
		this.orgName = items[14];
		this.linCount = items[15];
		this.alarmDupCount = items[16];
		this.occurTime = items[17];
		this.alarmKey = items[18];
		this.workYn = items[19];
		this.ticketYn = items[20];
		this.egovAlarmYn = items[21];
		this.backboneYn = items[22];
		this.ofdAlarmYn = items[23];
		this.postGroupCd = items[24];
		this.postGroupName = items[25];
		this.postCd = items[26];
		this.postName = items[27];
		this.alarmDupYn = items[28];
		this.seriousAlarmYn = items[29];
		this.alarmTypCd = items[30];
		this.alarmIdOther = items[31];
		this.setMngGroupCd(items[32]);
		this.closeMode = items[33];
		this.modelType = items[34];
		this.networkIds = items[35];
		this.networkNames = items[36];
		this.trRoomId = items[37];
		this.trRoomName = items[38];
		this.cityId = items[39];
		this.cityName = items[40];
		this.guId = items[41];
		this.guName = items[42];
		this.occurRTime = items[43];
		this.rasId = items[44];
		this.macAddr = items[45];
		this.supProviderCd = items[46];
		this.supProviderName = items[47];
		this.nwCarrierCd = items[48];
		this.nwCarrierName = items[49];
		this.entServiceNo = items[50];
		this.etc = items[51];
		this.cotRtType = items[52];
		this.focusYn = items[53];
		this.userAlarmLevel = items[54];
		this.userReason = items[55];
		this.alarmKind = items[56];
	}

}
