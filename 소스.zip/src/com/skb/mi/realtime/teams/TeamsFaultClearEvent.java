package com.skb.mi.realtime.teams;

public class TeamsFaultClearEvent extends TeamsEvent {
	private	String	alarmEventType;
	private	String	clrUserId;
	private	String	clrFlag;
	private	String	clearTime;
	private	String	durationSec;
	private	String	alarmNo;
	private	String	clearRTime;
	private	String	trRoomId;
	private	String	modelId;
	private	String	nmsCd;
	private	String	workYn;
	private	String	linCount;
	
	public String getAlarmEventType() {
		return alarmEventType;
	}
	public void setAlarmEventType(String alarmEventType) {
		this.alarmEventType = alarmEventType;
	}
	public String getClrUserId() {
		return clrUserId;
	}
	public void setClrUserId(String clrUserId) {
		this.clrUserId = clrUserId;
	}
	public String getClrFlag() {
		return clrFlag;
	}
	public void setClrFlag(String clrFlag) {
		this.clrFlag = clrFlag;
	}
	public String getClearTime() {
		return clearTime;
	}
	public void setClearTime(String clearTime) {
		this.clearTime = clearTime;
	}
	public String getDurationSec() {
		return durationSec;
	}
	public void setDurationSec(String durationSec) {
		this.durationSec = durationSec;
	}
	public String getAlarmNo() {
		return alarmNo;
	}
	public void setAlarmNo(String alarmNo) {
		this.alarmNo = alarmNo;
	}
	public String getClearRTime() {
		return clearRTime;
	}
	public void setClearRTime(String clearRTime) {
		this.clearRTime = clearRTime;
	}
	public String getTrRoomId() {
		return trRoomId;
	}
	public void setTrRoomId(String trRoomId) {
		this.trRoomId = trRoomId;
	}
	public String getModelId() {
		return modelId;
	}
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}
	public String getNmsCd() {
		return nmsCd;
	}
	public void setNmsCd(String nmsCd) {
		this.nmsCd = nmsCd;
	}
	public String getWorkYn() {
		return workYn;
	}
	public void setWorkYn(String workYn) {
		this.workYn = workYn;
	}
	public String getLinCount() {
		return linCount;
	}
	public void setLinCount(String linCount) {
		this.linCount = linCount;
	}

	public TeamsFaultClearEvent() {
		this.setEventType(TeamsEvent.FAULT_CLEAR);
	}
	public TeamsFaultClearEvent(String[] items) {
		this.setEventType(TeamsEvent.FAULT_CLEAR);

		this.alarmEventType = items[0];
		this.clrUserId = items[1];
		this.clrFlag = items[2];
		this.clearTime = items[3];
		this.durationSec = items[4];
		this.alarmNo = items[5];
		this.setMngGroupCd(items[6]);
		this.clearRTime = items[7];
		this.setAlarmLevel(items[8]);
		this.trRoomId = items[9];
		this.modelId = items[10];
		this.setNeId(items[11]);
		this.nmsCd = items[12];
		this.workYn = items[13];
		this.linCount = items[14];
	}

}
