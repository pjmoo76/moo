package com.skb.mi.realtime.teams;

public class TeamsRingFaultEvent extends TeamsEvent {
	private	String	alarmNo;
	private	String	nmsCd;
	private	String	networkId;
	private	String	networkName;
	private	String	networkAlarmReason;
	private	String	nmsAlarmNo;
	private	String	modelId;
	private	String	modelName;
	private	String	neName;
	private	String	tid;
	private	String	ipAddr;
	private	String	equipUsage;
	private	String	portDescr;
	private	String	location;
	private	String	reason;
	private	String	orgId;
	private	String	orgName;
	private	String	occurTime;
	private	String	alarmKey;
	private	String	workYn;
	private	String	ticketYn;
	private	String	egovAlarmYn;
	private	String	backbonYn;
	private	String	ofdAlarmYn;
	private	String	postGroupCd;
	private	String	postGroupName;
	private	String	postCd;
	private	String	postName;
	private	String	closeMode;
	private	String	networkAlarmReasonCd;
	private	String	topologyCd;
	private	String	ringId;
	private	String	ringName;
	private	String	trunkId;
	private	String	trunkName;
	private	String	trRoomId;
	private	String	trRoomName;
	private	String	occurRTime;
	private	String	focusYn;
	private	String	userAlarmLevel;
	private	String	userReason;
	private	String	seriousAlarmYn;
	
	public String getAlarmNo() {
		return alarmNo;
	}
	public void setAlarmNo(String alarmNo) {
		this.alarmNo = alarmNo;
	}
	public String getNmsCd() {
		return nmsCd;
	}
	public void setNmsCd(String nmsCd) {
		this.nmsCd = nmsCd;
	}
	public String getNetworkId() {
		return networkId;
	}
	public void setNetworkId(String networkId) {
		this.networkId = networkId;
	}
	public String getNetworkName() {
		return networkName;
	}
	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}
	public String getNetworkAlarmReason() {
		return networkAlarmReason;
	}
	public void setNetworkAlarmReason(String networkAlarmReason) {
		this.networkAlarmReason = networkAlarmReason;
	}
	public String getNmsAlarmNo() {
		return nmsAlarmNo;
	}
	public void setNmsAlarmNo(String nmsAlarmNo) {
		this.nmsAlarmNo = nmsAlarmNo;
	}
	public String getModelId() {
		return modelId;
	}
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getNeName() {
		return neName;
	}
	public void setNeName(String neName) {
		this.neName = neName;
	}
	public String getTid() {
		return tid;
	}
	public void setTid(String tid) {
		this.tid = tid;
	}
	public String getIpAddr() {
		return ipAddr;
	}
	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}
	public String getEquipUsage() {
		return equipUsage;
	}
	public void setEquipUsage(String equipUsage) {
		this.equipUsage = equipUsage;
	}
	public String getPortDescr() {
		return portDescr;
	}
	public void setPortDescr(String portDescr) {
		this.portDescr = portDescr;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getOccurTime() {
		return occurTime;
	}
	public void setOccurTime(String occurTime) {
		this.occurTime = occurTime;
	}
	public String getAlarmKey() {
		return alarmKey;
	}
	public void setAlarmKey(String alarmKey) {
		this.alarmKey = alarmKey;
	}
	public String getWorkYn() {
		return workYn;
	}
	public void setWorkYn(String workYn) {
		this.workYn = workYn;
	}
	public String getTicketYn() {
		return ticketYn;
	}
	public void setTicketYn(String ticketYn) {
		this.ticketYn = ticketYn;
	}
	public String getEgovAlarmYn() {
		return egovAlarmYn;
	}
	public void setEgovAlarmYn(String egovAlarmYn) {
		this.egovAlarmYn = egovAlarmYn;
	}
	public String getBackbonYn() {
		return backbonYn;
	}
	public void setBackbonYn(String backbonYn) {
		this.backbonYn = backbonYn;
	}
	public String getOfdAlarmYn() {
		return ofdAlarmYn;
	}
	public void setOfdAlarmYn(String ofdAlarmYn) {
		this.ofdAlarmYn = ofdAlarmYn;
	}
	public String getPostGroupCd() {
		return postGroupCd;
	}
	public void setPostGroupCd(String postGroupCd) {
		this.postGroupCd = postGroupCd;
	}
	public String getPostGroupName() {
		return postGroupName;
	}
	public void setPostGroupName(String postGroupName) {
		this.postGroupName = postGroupName;
	}
	public String getPostCd() {
		return postCd;
	}
	public void setPostCd(String postCd) {
		this.postCd = postCd;
	}
	public String getPostName() {
		return postName;
	}
	public void setPostName(String postName) {
		this.postName = postName;
	}
	public String getCloseMode() {
		return closeMode;
	}
	public void setCloseMode(String closeMode) {
		this.closeMode = closeMode;
	}
	public String getNetworkAlarmReasonCd() {
		return networkAlarmReasonCd;
	}
	public void setNetworkAlarmReasonCd(String networkAlarmReasonCd) {
		this.networkAlarmReasonCd = networkAlarmReasonCd;
	}
	public String getTopologyCd() {
		return topologyCd;
	}
	public void setTopologyCd(String topologyCd) {
		this.topologyCd = topologyCd;
	}
	public String getRingId() {
		return ringId;
	}
	public void setRingId(String ringId) {
		this.ringId = ringId;
	}
	public String getRingName() {
		return ringName;
	}
	public void setRingName(String ringName) {
		this.ringName = ringName;
	}
	public String getTrunkId() {
		return trunkId;
	}
	public void setTrunkId(String trunkId) {
		this.trunkId = trunkId;
	}
	public String getTrunkName() {
		return trunkName;
	}
	public void setTrunkName(String trunkName) {
		this.trunkName = trunkName;
	}
	public String getTrRoomId() {
		return trRoomId;
	}
	public void setTrRoomId(String trRoomId) {
		this.trRoomId = trRoomId;
	}
	public String getTrRoomName() {
		return trRoomName;
	}
	public void setTrRoomName(String trRoomName) {
		this.trRoomName = trRoomName;
	}
	public String getOccurRTime() {
		return occurRTime;
	}
	public void setOccurRTime(String occurRTime) {
		this.occurRTime = occurRTime;
	}
	public String getFocusYn() {
		return focusYn;
	}
	public void setFocusYn(String focusYn) {
		this.focusYn = focusYn;
	}
	public String getUserAlarmLevel() {
		return userAlarmLevel;
	}
	public void setUserAlarmLevel(String userAlarmLevel) {
		this.userAlarmLevel = userAlarmLevel;
	}
	public String getUserReason() {
		return userReason;
	}
	public void setUserReason(String userReason) {
		this.userReason = userReason;
	}
	public String getSeriousAlarmYn() {
		return seriousAlarmYn;
	}
	public void setSeriousAlarmYn(String seriousAlarmYn) {
		this.seriousAlarmYn = seriousAlarmYn;
	}
	
	public TeamsRingFaultEvent() {
		this.setEventType(TeamsEvent.RING_FAULT);
	}
	public TeamsRingFaultEvent(String[] items) {
		this.setEventType(TeamsEvent.RING_FAULT);
		
		this.alarmNo = items[0];
		this.nmsCd = items[1];
		this.setMngGroupCd(items[2]);
		this.networkId = items[3];
		this.networkName = items[4];
		this.networkAlarmReason = items[5];
		this.nmsAlarmNo = items[6];
		this.modelId = items[7];
		this.modelName = items[8];
		this.setNeId(items[9]);
		this.neName = items[10];
		this.tid = items[11];
		this.ipAddr = items[12];
		this.equipUsage = items[13];
		this.setAlarmLevel(items[14]);
		this.portDescr = items[15];
		this.location = items[16];
		this.reason = items[17];
		this.orgId = items[18];
		this.orgName = items[19];
		this.occurTime = items[20];
		this.alarmKey = items[21];
		this.workYn = items[22];
		this.ticketYn = items[23];
		this.egovAlarmYn = items[24];
		this.backbonYn = items[25];
		this.ofdAlarmYn = items[26];
		this.postGroupCd = items[27];
		this.postGroupName = items[28];
		this.postCd = items[29];
		this.postName = items[30];
		this.closeMode = items[31];
		this.networkAlarmReasonCd = items[32];
		this.topologyCd = items[33];
		this.ringId = items[34];
		this.ringName = items[35];
		this.trunkId = items[36];
		this.trunkName = items[37];
		this.trRoomId = items[38];
		this.trRoomName = items[39];
		this.occurRTime = items[40];
		this.focusYn = items[41];
		this.userAlarmLevel = items[42];
		this.userReason = items[43];
		this.seriousAlarmYn = items[44];
	}

}
