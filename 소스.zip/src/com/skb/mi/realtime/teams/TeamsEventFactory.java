package com.skb.mi.realtime.teams;

import java.io.InputStream;

import org.apache.log4j.Logger;

import com.skb.mi.common.SockUtils;
import com.skb.mi.common.StringUtils;

public class TeamsEventFactory {
	static public final byte 	IDENTIFIER		= 0x1f;
	static public final String	CHARSET_NAME	= "EUC-KR";

	final int	HEADER_LEN	= 20;
	final byte	ESC = 0x1b;
	final byte	STX = 0x02;				// Start of Text
	private	byte[]	header;
	final char	PDU_EVENT		= '1';	// 0x31
	final char	PDU_REQUEST		= '2';	// 0x32
	final char	PDU_RESPONSE	= '3';	// 0x33

	private Logger logger;

	public TeamsEventFactory() {
		this.logger = Logger.getLogger(this.getClass());
		this.header = new byte[HEADER_LEN];
	}
	
	public TeamsEvent get(InputStream is) throws Exception {
		logger.debug("reading...");
		/*
		 * ESC				: 1 byte
		 * STX				: 1 byte
		 * PduType			: 1 byte (1: Event, 2: Request, 3: Response)
		 * ServiceCode		: 4 byte
		 * messageSerialNo	: 2 byte
		 * lastYn			: 1 byte
		 * responseResult	: 1 byte
		 * extendArea		: 4 byte
		 * bodyLength		: 5 byte
		 */
		//int len = is.read(header);
		int len = SockUtils.read(is, header, header.length);
		if (len != HEADER_LEN) {
			throw new Exception(String.format("failed to read header (%d,%d)", HEADER_LEN, len));
		}
		logger.debug(StringUtils.toHexString(header));
		logger.debug(StringUtils.toReadableString(header));

		if (header[0] != ESC) {
			throw new Exception("header[0] is not ESC");
		}
		if (header[1] != STX) {
			throw new Exception("header[1] is not STX");
		}
		char pduType = (char) header[2];
		if (pduType != PDU_EVENT && pduType != PDU_REQUEST && pduType != PDU_RESPONSE) {
			throw new Exception("invalid pduType : " + pduType);
		}
		String serviceCode = new String(StringUtils.getBytes(header, 3, 4));
		int bodyLength = Integer.parseInt(new String(StringUtils.getBytes(header, 15, 5)));

		byte[] body = new byte[bodyLength];
		//len = is.read(body);
		len = SockUtils.read(is, body, body.length);
		if (len != bodyLength) {
			throw new Exception(String.format("failed to read body (%d,%d)", bodyLength, len));
		}
		logger.debug(String.format("(serviceCode=%s),(bodyLength=%d)", serviceCode, bodyLength));
		
		TeamsEvent event = null;
		if (TeamsEvent.MANUAL_CLEAR.equals(serviceCode)) {
			// 다수의 장애수동해제정보가 존재함. 각각의 장애정보는 '^' 로 구분됨.
			logger.debug(new String(body, 0, body.length, CHARSET_NAME));
			event = new TeamsManualClearEvent(body, logger);
		} else {
			String[] items = StringUtils.split(body, IDENTIFIER, CHARSET_NAME);
			for (int i = 0; i < items.length; i ++) {
				logger.debug(String.format("[%d]%s", i, items[i]));
			}
			
			if (TeamsEvent.EQUIP_FAULT.equals(serviceCode)) {
				event = new TeamsEquipFaultEvent(items);
			} else if (TeamsEvent.CIRCUIT_FAULT.equals(serviceCode)) {
				event = new TeamsCircuitFaultEvent(items);
			} else if (TeamsEvent.RING_FAULT.equals(serviceCode)) {
				event = new TeamsRingFaultEvent(items);
			} else if (TeamsEvent.FAULT_CLEAR.equals(serviceCode)) {
				event = new TeamsFaultClearEvent(items);
			}
		}

		return event;
	}	
}
