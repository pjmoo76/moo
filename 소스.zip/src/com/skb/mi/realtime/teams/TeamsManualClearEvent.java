package com.skb.mi.realtime.teams;

import java.util.ArrayList;

import org.apache.log4j.Logger;

public class TeamsManualClearEvent extends TeamsEvent {
	ArrayList<TeamsFaultClearEvent>	clearEventList;
	
	public TeamsManualClearEvent() {
		this.setEventType(TeamsEvent.MANUAL_CLEAR);
	}

	public TeamsManualClearEvent(byte[] data, Logger logger) {
		this.setEventType(TeamsEvent.MANUAL_CLEAR);
		int idx = 0;
		for (idx = 0; idx < data.length; idx ++ ) {
			if (data[idx] == TeamsEventFactory.IDENTIFIER) {
				break;
			}
		}
		int count = 0;
		try {
			count = Integer.parseInt(new String(data, 0, idx));
		} catch (Exception e) {
			return;
		}
		if (count == 0) {
			return;
		}
		logger.debug("count="+count);
		try {
			clearEventList = new ArrayList<TeamsFaultClearEvent>();
			String value = new String(data, idx, data.length - idx, TeamsEventFactory.CHARSET_NAME);
			String[] items = value.split("\\^");
			for (int i = 0; i < items.length; i ++) {
				String[] items2 = items[i].split("\\|");
				for (int j = 0; j < items2.length; j ++) {
					logger.debug(String.format("[%d][%d]%s", i, j, items2[j]));
				}
				TeamsFaultClearEvent event = new TeamsFaultClearEvent(items2);
				clearEventList.add(event);
			}
		} catch (Exception e) {
			
		}
	}

	public ArrayList<TeamsFaultClearEvent> getClearEventList() {
		return this.clearEventList;
	}
}
