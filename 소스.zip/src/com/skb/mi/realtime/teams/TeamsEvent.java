package com.skb.mi.realtime.teams;

public class TeamsEvent {
	static public String	EQUIP_FAULT		= "0411";
	static public String	CIRCUIT_FAULT	= "0415";
	static public String	RING_FAULT		= "0416";
	static public String	FAULT_CLEAR		= "0413";
	static public String	MANUAL_CLEAR	= "0450"; /* 수동해제 */
	
	static public String	SKT		= "01";
	static public String	SKT2	= "02";
	static public String	SKB		= "03";
	
	private	String	eventType;
	private	String	alarmLevel;
	private	String	mngGroupCd;
	private	String	trmsNetMgmtOwnerCd;
	private	String	dablGrCd;
	private	String	neId;

	public String getEventType() {
		return this.eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getAlarmLevel() {
		return alarmLevel;
	}
	public void setAlarmLevel(String alarmLevel) {
		this.alarmLevel = alarmLevel;
		if (alarmLevel.equals("1")			// Info
				|| alarmLevel.equals("2")	// Warning
				|| alarmLevel.equals("3")	// Minor
				|| alarmLevel.equals("4")	// Major
				|| alarmLevel.equals("5")	// Critical
				|| alarmLevel.equals("7"))	// Fatal
			dablGrCd = "0" + alarmLevel;
		else
			dablGrCd = "01";
	}
	public void setMngGroupCd(String mngGroupCd) {
		this.mngGroupCd = mngGroupCd;
		if ("003001".equals(mngGroupCd)) {
			this.trmsNetMgmtOwnerCd = SKT;
		} else if ("003002".equals(mngGroupCd)) {
			this.trmsNetMgmtOwnerCd = SKT2;
		} else if ("003003".equals(mngGroupCd)) {
			this.trmsNetMgmtOwnerCd = SKB;
		}
	}
	public String getMngGroupCd() {
		return this.mngGroupCd;
	}
	public String getDablGrCd() {
		return this.dablGrCd;
	}
	public String getTrmsNetMgmtOwnerCd() {
		return this.trmsNetMgmtOwnerCd;
	}
	public String getNeId() {
		return neId;
	}
	public void setNeId(String neId) {
		this.neId = neId;
	}
}
