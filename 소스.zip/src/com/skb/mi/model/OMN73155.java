package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OMN73155 extends AggrDataVO {
	private	String	mntrDthr;
	private	String	apMacAddr;
	private String	auditId;
	private	String	netClCd;
	private	String	infoCntrCd;
	private	String	distbCntrCd;
	private	String	homeCntrCd;
	private	String	l3EquipId;
	private	String	l2EquipId;
	private	String	ccellNum;
	private	String	eqpMdlCd;
	private	long	inetSvcMgmtNum;
	private	int		wanOnOccrCnt;
	private	int		lan1OnOccrCnt;
	private	int		lan1OffOccrCnt;
	private	int		lan2OnOccrCnt;
	private	int		lan2OffOccrCnt;
	private	int		lan3OnOccrCnt;
	private	int		lan3OffOccrCnt;
	private	int		lan4OnOccrCnt;
	private	int		lan4OffOccrCnt;
	private	String	eqpVerInfo;

	public String getMntrDthr() {
		return mntrDthr;
	}
	public void setMntrDthr(String mntrDthr) {
		this.mntrDthr = mntrDthr;
	}
	public String getApMacAddr() {
		return apMacAddr;
	}
	public void setApMacAddr(String apMacAddr) {
		this.apMacAddr = apMacAddr;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getNetClCd() {
		return netClCd;
	}
	public void setNetClCd(String netClCd) {
		this.netClCd = netClCd;
	}
	public String getInfoCntrCd() {
		return infoCntrCd;
	}
	public void setInfoCntrCd(String infoCntrCd) {
		this.infoCntrCd = infoCntrCd;
	}
	public String getDistbCntrCd() {
		return distbCntrCd;
	}
	public void setDistbCntrCd(String distbCntrCd) {
		this.distbCntrCd = distbCntrCd;
	}
	public String getHomeCntrCd() {
		return homeCntrCd;
	}
	public void setHomeCntrCd(String homeCntrCd) {
		this.homeCntrCd = homeCntrCd;
	}
	public String getL3EquipId() {
		return l3EquipId;
	}
	public void setL3EquipId(String l3EquipId) {
		this.l3EquipId = l3EquipId;
	}
	public String getL2EquipId() {
		return l2EquipId;
	}
	public void setL2EquipId(String l2EquipId) {
		this.l2EquipId = l2EquipId;
	}
	public String getCcellNum() {
		return ccellNum;
	}
	public void setCcellNum(String ccellNum) {
		this.ccellNum = ccellNum;
	}
	public String getEqpMdlCd() {
		return eqpMdlCd;
	}
	public void setEqpMdlCd(String eqpMdlCd) {
		this.eqpMdlCd = eqpMdlCd;
	}
	public long getInetSvcMgmtNum() {
		return inetSvcMgmtNum;
	}
	public void setInetSvcMgmtNum(long inetSvcMgmtNum) {
		this.inetSvcMgmtNum = inetSvcMgmtNum;
	}
	public int getWanOnOccrCnt() {
		return wanOnOccrCnt;
	}
	public void setWanOnOccrCnt(int wanOnOccrCnt) {
		this.wanOnOccrCnt = wanOnOccrCnt;
	}
	public int getLan1OnOccrCnt() {
		return lan1OnOccrCnt;
	}
	public void setLan1OnOccrCnt(int lan1OnOccrCnt) {
		this.lan1OnOccrCnt = lan1OnOccrCnt;
	}
	public int getLan1OffOccrCnt() {
		return lan1OffOccrCnt;
	}
	public void setLan1OffOccrCnt(int lan1OffOccrCnt) {
		this.lan1OffOccrCnt = lan1OffOccrCnt;
	}
	public int getLan2OnOccrCnt() {
		return lan2OnOccrCnt;
	}
	public void setLan2OnOccrCnt(int lan2OnOccrCnt) {
		this.lan2OnOccrCnt = lan2OnOccrCnt;
	}
	public int getLan2OffOccrCnt() {
		return lan2OffOccrCnt;
	}
	public void setLan2OffOccrCnt(int lan2OffOccrCnt) {
		this.lan2OffOccrCnt = lan2OffOccrCnt;
	}
	public int getLan3OnOccrCnt() {
		return lan3OnOccrCnt;
	}
	public void setLan3OnOccrCnt(int lan3OnOccrCnt) {
		this.lan3OnOccrCnt = lan3OnOccrCnt;
	}
	public int getLan3OffOccrCnt() {
		return lan3OffOccrCnt;
	}
	public void setLan3OffOccrCnt(int lan3OffOccrCnt) {
		this.lan3OffOccrCnt = lan3OffOccrCnt;
	}
	public int getLan4OnOccrCnt() {
		return lan4OnOccrCnt;
	}
	public void setLan4OnOccrCnt(int lan4OnOccrCnt) {
		this.lan4OnOccrCnt = lan4OnOccrCnt;
	}
	public int getLan4OffOccrCnt() {
		return lan4OffOccrCnt;
	}
	public void setLan4OffOccrCnt(int lan4OffOccrCnt) {
		this.lan4OffOccrCnt = lan4OffOccrCnt;
	}
	public String getEqpVerInfo() {
		return eqpVerInfo;
	}
	public void setEqpVerInfo(String eqpVerInfo) {
		this.eqpVerInfo = eqpVerInfo;
	}
	@Override
	public boolean isValid() {
		if (this.apMacAddr == null || this.apMacAddr.isEmpty() || this.apMacAddr.length() > 15) {
			return false;
		}
		return true;
	}
	@Override
	public String toDelimiterString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("%s|", mntrDthr));
		sb.append(String.format("%s|", apMacAddr));
		sb.append(String.format("%s|", auditId));
		sb.append(String.format("%s|", StringUtils.null2Empty(netClCd)));
		sb.append(String.format("%s|", StringUtils.null2Empty(infoCntrCd)));
		sb.append(String.format("%s|", StringUtils.null2Empty(distbCntrCd)));
		sb.append(String.format("%s|", StringUtils.null2Empty(homeCntrCd)));
		sb.append(String.format("%s|", StringUtils.null2Empty(l3EquipId)));
		sb.append(String.format("%s|", StringUtils.null2Empty(l2EquipId)));
		sb.append(String.format("%s|", StringUtils.null2Empty(ccellNum)));
		sb.append(String.format("%s|", StringUtils.null2Empty(eqpMdlCd)));
		sb.append(String.format("%d|", inetSvcMgmtNum));
		sb.append(String.format("%d|", wanOnOccrCnt));
		sb.append(String.format("%d|", lan1OnOccrCnt));
		sb.append(String.format("%d|", lan1OffOccrCnt));
		sb.append(String.format("%d|", lan2OnOccrCnt));
		sb.append(String.format("%d|", lan2OffOccrCnt));
		sb.append(String.format("%d|", lan3OnOccrCnt));
		sb.append(String.format("%d|", lan3OffOccrCnt));
		sb.append(String.format("%d|", lan4OnOccrCnt));
		sb.append(String.format("%d|", lan4OffOccrCnt));
		sb.append(String.format("%s|", StringUtils.null2Empty(eqpVerInfo)));
		return sb.toString();
	}
	@Override
	public void add(AggrDataVO obj) {
		OMN73155 addObj = (OMN73155) obj;
		this.wanOnOccrCnt += addObj.wanOnOccrCnt;
		this.lan1OnOccrCnt += addObj.lan1OnOccrCnt;
		this.lan1OffOccrCnt += addObj.lan1OffOccrCnt;
		this.lan2OnOccrCnt += addObj.lan2OnOccrCnt;
		this.lan2OffOccrCnt += addObj.lan2OffOccrCnt;
		this.lan3OnOccrCnt += addObj.lan3OnOccrCnt;
		this.lan3OffOccrCnt += addObj.lan3OffOccrCnt;
		this.lan4OnOccrCnt += addObj.lan4OnOccrCnt;
		this.lan4OffOccrCnt += addObj.lan4OffOccrCnt;
	}
}
