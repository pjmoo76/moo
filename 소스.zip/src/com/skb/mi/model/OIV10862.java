package com.skb.mi.model;

public class OIV10862 {
	private	String	mntrDthm;
	private	String	sumOperId;
	private	String	sumExecProcNm;
	private	String	tblNm;
	private	String	sumOperStCd;
	private	String	operRcvDtm;
	private	String	operStaDtm;
	private	String	operFnshDtm;
	private	String	operRsltCtt;
	private	String	retryOperStaDtm;
	private	String	retryOperFnshDtm;
	
	public String getMntrDthm() {
		return mntrDthm;
	}
	public void setMntrDthm(String mntrDthm) {
		this.mntrDthm = mntrDthm;
	}
	public String getSumOperId() {
		return sumOperId;
	}
	public void setSumOperId(String sumOperId) {
		this.sumOperId = sumOperId;
	}
	public String getSumExecProcNm() {
		return sumExecProcNm;
	}
	public void setSumExecProcNm(String sumExecProcNm) {
		this.sumExecProcNm = sumExecProcNm;
	}
	public String getTblNm() {
		return tblNm;
	}
	public void setTblNm(String tblNm) {
		this.tblNm = tblNm;
	}
	public String getSumOperStCd() {
		return sumOperStCd;
	}
	public void setSumOperStCd(String sumOperStCd) {
		this.sumOperStCd = sumOperStCd;
	}
	public String getOperRcvDtm() {
		return operRcvDtm;
	}
	public void setOperRcvDtm(String operRcvDtm) {
		this.operRcvDtm = operRcvDtm;
	}
	public String getOperStaDtm() {
		return operStaDtm;
	}
	public void setOperStaDtm(String operStaDtm) {
		this.operStaDtm = operStaDtm;
	}
	public String getOperFnshDtm() {
		return operFnshDtm;
	}
	public void setOperFnshDtm(String operFnshDtm) {
		this.operFnshDtm = operFnshDtm;
	}
	public String getOperRsltCtt() {
		return operRsltCtt;
	}
	public void setOperRsltCtt(String operRsltCtt) {
		this.operRsltCtt = operRsltCtt;
	}
	public String getRetryOperStaDtm() {
		return retryOperStaDtm;
	}
	public void setRetryOperStaDtm(String retryOperStaDtm) {
		this.retryOperStaDtm = retryOperStaDtm;
	}
	public String getRetryOperFnshDtm() {
		return retryOperFnshDtm;
	}
	public void setRetryOperFnshDtm(String retryOperFnshDtm) {
		this.retryOperFnshDtm = retryOperFnshDtm;
	}
}
