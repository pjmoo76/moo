package com.skb.mi.model;

abstract public class CopyVO {
	private	boolean	checked = false;
	protected boolean	dubChecked = false;
	protected String key;
	
	public boolean checked() {
		return checked;
	}
	public void checked(boolean checked) {
		this.checked = checked;
	}
	public boolean getDubChecked() {
		return dubChecked;
	}
	public String getKey() {
		return key;
	}
	abstract public void setKey();
	abstract public boolean equals(CopyVO obj);
	abstract public void setRange(CopyVO obj);
}
