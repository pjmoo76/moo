package com.skb.mi.model;

public class OCL29350 {
	private	String	occrDtm;
	private	String	ipAddr;
	private	long	serNum;
	private	String	auditId;
	private	String	macAddr;
	private	String	configFileNm;
	private	String	dloadReqRsltCd;
	private	String	dloadReqCtt;
	private	String	opRsltCtt;

	public String getOccrDtm() {
		return occrDtm;
	}
	public void setOccrDtm(String occrDtm) {
		this.occrDtm = occrDtm;
	}
	public String getIpAddr() {
		return ipAddr;
	}
	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}
	public long getSerNum() {
		return serNum;
	}
	public void setSerNum(long serNum) {
		this.serNum = serNum;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getMacAddr() {
		return macAddr;
	}
	public void setMacAddr(String macAddr) {
		this.macAddr = macAddr;
	}
	public String getConfigFileNm() {
		return configFileNm;
	}
	public void setConfigFileNm(String configFileNm) {
		this.configFileNm = configFileNm;
	}
	public String getDloadReqRsltCd() {
		return dloadReqRsltCd;
	}
	public void setDloadReqRsltCd(String dloadReqRsltCd) {
		this.dloadReqRsltCd = dloadReqRsltCd;
	}
	public String getDloadReqCtt() {
		return dloadReqCtt;
	}
	public void setDloadReqCtt(String dloadReqCtt) {
		this.dloadReqCtt = dloadReqCtt;
	}
	public String getOpRsltCtt() {
		return opRsltCtt;
	}
	public void setOpRsltCtt(String opRsltCtt) {
		this.opRsltCtt = opRsltCtt;
	}
}
