package com.skb.mi.model;

public class OMN30110 {
	private Integer dablNum;
    private String auditId;
    private String auditDtm;
    private String equipId;
    private String otxNum;
    private String ccellNum;
    private String scardNumCtt;
    private String portNum;
    private String rackNum;
    private String shlfNum;
    private String routNum;
    private String routConnDirnCd;
    private String moduleEquipId;
    private String mscModuleTypCd;
    private String mscModuleNm;
    private String coVipCustYn;
    private String incommBizrNm;
    private String tmId;
    private String procId;
    private String subProcId;
    private String supEquipIpAddr;
    private String supEquipNm;
    private String supEquipIfPortNm;
    private String supEquipIfAlsNm;
    private String ringNm;
    private String dablLocNm;
    private String shspdInetDmgLineCnt;
    private String gnrlIptvDmgLineCnt;
    private String indpndIptvDmgLineCnt;
    private String gnlphDmgLineCnt;
    private String shspdVocCnt;
    private String iptvVocCnt;
    private String sbnmsEquipNm;
    private String phonVocCnt;
    private String totVocCnt;
    private String voipVocCnt;
    private String routInfo;
    private String custChrticCd;
    private String massCoClCd;
    private String massDmgScrbrCnt;
    private String massShspdDmgLineCnt;
    private String massIptvDmgLineCnt;
    private String massPhonDmgLineCnt;
    private String massShspdInetVocCnt;
    private String massIptvVocCnt;
    private String massVoipVocCnt;
    private String coDmgScrbrCnt;
    private String coShspdDmgLineCnt;
    private String coIptvDmgLineCnt;
    private String coPhonDmgLineCnt;
    private String coShspdInetVocCnt;
    private String coIptvVocCnt;
    private String coVoipVocCnt;
    private String sktEquipNum;
    private String sktEquipNm;
    private String sktEquipMdlNm;
    private String sktEquipTidVal;
    private String sktEquipIpAddr;
    private String useUsgDesc;
    private String troomNm;
    private String shspdAceptLineCnt;
    private String gnrlIptvAceptLineCnt;
    private String indpndIptvAceptLineCnt;
    private String phonAceptLineCnt;
    private String dablObjClCd;
    private String dhcpLnkgEquipClCd;
    private String nmsEquipTidVal;
    private String nmsEquipId;
    private String ringNum;
    private String fdfLineNum;
    private String cblDist;


    // ===== Getter/Setter =====

    public Integer getDablNum() { return dablNum; }
    public void setDablNum(Integer dablNum) { this.dablNum = dablNum; }

    public String getAuditId() { return auditId; }
    public void setAuditId(String auditId) { this.auditId = auditId; }

    public String getAuditDtm() { return auditDtm; }
    public void setAuditDtm(String auditDtm) { this.auditDtm = auditDtm; }

    public String getEquipId() { return equipId; }
    public void setEquipId(String equipId) { this.equipId = equipId; }

    public String getOtxNum() { return otxNum; }
    public void setOtxNum(String otxNum) { this.otxNum = otxNum; }

    public String getCcellNum() { return ccellNum; }
    public void setCcellNum(String ccellNum) { this.ccellNum = ccellNum; }

    public String getScardNumCtt() { return scardNumCtt; }
    public void setScardNumCtt(String scardNumCtt) { this.scardNumCtt = scardNumCtt; }

    public String getPortNum() { return portNum; }
    public void setPortNum(String portNum) { this.portNum = portNum; }

    public String getRackNum() { return rackNum; }
    public void setRackNum(String rackNum) { this.rackNum = rackNum; }

    public String getShlfNum() { return shlfNum; }
    public void setShlfNum(String shlfNum) { this.shlfNum = shlfNum; }

    public String getRoutNum() { return routNum; }
    public void setRoutNum(String routNum) { this.routNum = routNum; }

    public String getRoutConnDirnCd() { return routConnDirnCd; }
    public void setRoutConnDirnCd(String routConnDirnCd) { this.routConnDirnCd = routConnDirnCd; }

    public String getModuleEquipId() { return moduleEquipId; }
    public void setModuleEquipId(String moduleEquipId) { this.moduleEquipId = moduleEquipId; }

    public String getMscModuleTypCd() { return mscModuleTypCd; }
    public void setMscModuleTypCd(String mscModuleTypCd) { this.mscModuleTypCd = mscModuleTypCd; }

    public String getMscModuleNm() { return mscModuleNm; }
    public void setMscModuleNm(String mscModuleNm) { this.mscModuleNm = mscModuleNm; }

    public String getCoVipCustYn() { return coVipCustYn; }
    public void setCoVipCustYn(String coVipCustYn) { this.coVipCustYn = coVipCustYn; }

    public String getIncommBizrNm() { return incommBizrNm; }
    public void setIncommBizrNm(String incommBizrNm) { this.incommBizrNm = incommBizrNm; }

    public String getTmId() { return tmId; }
    public void setTmId(String tmId) { this.tmId = tmId; }

    public String getProcId() { return procId; }
    public void setProcId(String procId) { this.procId = procId; }

    public String getSubProcId() { return subProcId; }
    public void setSubProcId(String subProcId) { this.subProcId = subProcId; }

    public String getSupEquipIpAddr() { return supEquipIpAddr; }
    public void setSupEquipIpAddr(String supEquipIpAddr) { this.supEquipIpAddr = supEquipIpAddr; }

    public String getSupEquipNm() { return supEquipNm; }
    public void setSupEquipNm(String supEquipNm) { this.supEquipNm = supEquipNm; }

    public String getSupEquipIfPortNm() { return supEquipIfPortNm; }
    public void setSupEquipIfPortNm(String supEquipIfPortNm) { this.supEquipIfPortNm = supEquipIfPortNm; }

    public String getSupEquipIfAlsNm() { return supEquipIfAlsNm; }
    public void setSupEquipIfAlsNm(String supEquipIfAlsNm) { this.supEquipIfAlsNm = supEquipIfAlsNm; }

    public String getRingNm() { return ringNm; }
    public void setRingNm(String ringNm) { this.ringNm = ringNm; }

    public String getDablLocNm() { return dablLocNm; }
    public void setDablLocNm(String dablLocNm) { this.dablLocNm = dablLocNm; }

    public String getShspdInetDmgLineCnt() { return shspdInetDmgLineCnt; }
    public void setShspdInetDmgLineCnt(String shspdInetDmgLineCnt) { this.shspdInetDmgLineCnt = shspdInetDmgLineCnt; }

    public String getGnrlIptvDmgLineCnt() { return gnrlIptvDmgLineCnt; }
    public void setGnrlIptvDmgLineCnt(String gnrlIptvDmgLineCnt) { this.gnrlIptvDmgLineCnt = gnrlIptvDmgLineCnt; }

    public String getIndpndIptvDmgLineCnt() { return indpndIptvDmgLineCnt; }
    public void setIndpndIptvDmgLineCnt(String indpndIptvDmgLineCnt) { this.indpndIptvDmgLineCnt = indpndIptvDmgLineCnt; }

    public String getGnlphDmgLineCnt() { return gnlphDmgLineCnt; }
    public void setGnlphDmgLineCnt(String gnlphDmgLineCnt) { this.gnlphDmgLineCnt = gnlphDmgLineCnt; }

    public String getShspdVocCnt() { return shspdVocCnt; }
    public void setShspdVocCnt(String shspdVocCnt) { this.shspdVocCnt = shspdVocCnt; }

    public String getIptvVocCnt() { return iptvVocCnt; }
    public void setIptvVocCnt(String iptvVocCnt) { this.iptvVocCnt = iptvVocCnt; }

    public String getSbnmsEquipNm() { return sbnmsEquipNm; }
    public void setSbnmsEquipNm(String sbnmsEquipNm) { this.sbnmsEquipNm = sbnmsEquipNm; }

    public String getPhonVocCnt() { return phonVocCnt; }
    public void setPhonVocCnt(String phonVocCnt) { this.phonVocCnt = phonVocCnt; }

    public String getTotVocCnt() { return totVocCnt; }
    public void setTotVocCnt(String totVocCnt) { this.totVocCnt = totVocCnt; }

    public String getVoipVocCnt() { return voipVocCnt; }
    public void setVoipVocCnt(String voipVocCnt) { this.voipVocCnt = voipVocCnt; }

    public String getRoutInfo() { return routInfo; }
    public void setRoutInfo(String routInfo) { this.routInfo = routInfo; }

    public String getCustChrticCd() { return custChrticCd; }
    public void setCustChrticCd(String custChrticCd) { this.custChrticCd = custChrticCd; }

    public String getMassCoClCd() { return massCoClCd; }
    public void setMassCoClCd(String massCoClCd) { this.massCoClCd = massCoClCd; }

    public String getMassDmgScrbrCnt() { return massDmgScrbrCnt; }
    public void setMassDmgScrbrCnt(String massDmgScrbrCnt) { this.massDmgScrbrCnt = massDmgScrbrCnt; }

    public String getMassShspdDmgLineCnt() { return massShspdDmgLineCnt; }
    public void setMassShspdDmgLineCnt(String massShspdDmgLineCnt) { this.massShspdDmgLineCnt = massShspdDmgLineCnt; }

    public String getMassIptvDmgLineCnt() { return massIptvDmgLineCnt; }
    public void setMassIptvDmgLineCnt(String massIptvDmgLineCnt) { this.massIptvDmgLineCnt = massIptvDmgLineCnt; }

    public String getMassPhonDmgLineCnt() { return massPhonDmgLineCnt; }
    public void setMassPhonDmgLineCnt(String massPhonDmgLineCnt) { this.massPhonDmgLineCnt = massPhonDmgLineCnt; }

    public String getMassShspdInetVocCnt() { return massShspdInetVocCnt; }
    public void setMassShspdInetVocCnt(String massShspdInetVocCnt) { this.massShspdInetVocCnt = massShspdInetVocCnt; }

    public String getMassIptvVocCnt() { return massIptvVocCnt; }
    public void setMassIptvVocCnt(String massIptvVocCnt) { this.massIptvVocCnt = massIptvVocCnt; }

    public String getMassVoipVocCnt() { return massVoipVocCnt; }
    public void setMassVoipVocCnt(String massVoipVocCnt) { this.massVoipVocCnt = massVoipVocCnt; }

    public String getCoDmgScrbrCnt() { return coDmgScrbrCnt; }
    public void setCoDmgScrbrCnt(String coDmgScrbrCnt) { this.coDmgScrbrCnt = coDmgScrbrCnt; }

    public String getCoShspdDmgLineCnt() { return coShspdDmgLineCnt; }
    public void setCoShspdDmgLineCnt(String coShspdDmgLineCnt) { this.coShspdDmgLineCnt = coShspdDmgLineCnt; }

    public String getCoIptvDmgLineCnt() { return coIptvDmgLineCnt; }
    public void setCoIptvDmgLineCnt(String coIptvDmgLineCnt) { this.coIptvDmgLineCnt = coIptvDmgLineCnt; }

    public String getCoPhonDmgLineCnt() { return coPhonDmgLineCnt; }
    public void setCoPhonDmgLineCnt(String coPhonDmgLineCnt) { this.coPhonDmgLineCnt = coPhonDmgLineCnt; }

    public String getCoShspdInetVocCnt() { return coShspdInetVocCnt; }
    public void setCoShspdInetVocCnt(String coShspdInetVocCnt) { this.coShspdInetVocCnt = coShspdInetVocCnt; }

    public String getCoIptvVocCnt() { return coIptvVocCnt; }
    public void setCoIptvVocCnt(String coIptvVocCnt) { this.coIptvVocCnt = coIptvVocCnt; }

    public String getCoVoipVocCnt() { return coVoipVocCnt; }
    public void setCoVoipVocCnt(String coVoipVocCnt) { this.coVoipVocCnt = coVoipVocCnt; }

    public String getSktEquipNum() { return sktEquipNum; }
    public void setSktEquipNum(String sktEquipNum) { this.sktEquipNum = sktEquipNum; }

    public String getSktEquipNm() { return sktEquipNm; }
    public void setSktEquipNm(String sktEquipNm) { this.sktEquipNm = sktEquipNm; }

    public String getSktEquipMdlNm() { return sktEquipMdlNm; }
    public void setSktEquipMdlNm(String sktEquipMdlNm) { this.sktEquipMdlNm = sktEquipMdlNm; }

    public String getSktEquipTidVal() { return sktEquipTidVal; }
    public void setSktEquipTidVal(String sktEquipTidVal) { this.sktEquipTidVal = sktEquipTidVal; }

    public String getSktEquipIpAddr() { return sktEquipIpAddr; }
    public void setSktEquipIpAddr(String sktEquipIpAddr) { this.sktEquipIpAddr = sktEquipIpAddr; }

    public String getUseUsgDesc() { return useUsgDesc; }
    public void setUseUsgDesc(String useUsgDesc) { this.useUsgDesc = useUsgDesc; }

    public String getTroomNm() { return troomNm; }
    public void setTroomNm(String troomNm) { this.troomNm = troomNm; }

    public String getShspdAceptLineCnt() { return shspdAceptLineCnt; }
    public void setShspdAceptLineCnt(String shspdAceptLineCnt) { this.shspdAceptLineCnt = shspdAceptLineCnt; }

    public String getGnrlIptvAceptLineCnt() { return gnrlIptvAceptLineCnt; }
    public void setGnrlIptvAceptLineCnt(String gnrlIptvAceptLineCnt) { this.gnrlIptvAceptLineCnt = gnrlIptvAceptLineCnt; }

    public String getIndpndIptvAceptLineCnt() { return indpndIptvAceptLineCnt; }
    public void setIndpndIptvAceptLineCnt(String indpndIptvAceptLineCnt) { this.indpndIptvAceptLineCnt = indpndIptvAceptLineCnt; }

    public String getPhonAceptLineCnt() { return phonAceptLineCnt; }
    public void setPhonAceptLineCnt(String phonAceptLineCnt) { this.phonAceptLineCnt = phonAceptLineCnt; }

    public String getDablObjClCd() { return dablObjClCd; }
    public void setDablObjClCd(String dablObjClCd) { this.dablObjClCd = dablObjClCd; }

    public String getDhcpLnkgEquipClCd() { return dhcpLnkgEquipClCd; }
    public void setDhcpLnkgEquipClCd(String dhcpLnkgEquipClCd) { this.dhcpLnkgEquipClCd = dhcpLnkgEquipClCd; }

    public String getNmsEquipTidVal() { return nmsEquipTidVal; }
    public void setNmsEquipTidVal(String nmsEquipTidVal) { this.nmsEquipTidVal = nmsEquipTidVal; }

    public String getNmsEquipId() { return nmsEquipId; }
    public void setNmsEquipId(String nmsEquipId) { this.nmsEquipId = nmsEquipId; }

    public String getRingNum() { return ringNum; }
    public void setRingNum(String ringNum) { this.ringNum = ringNum; }

    public String getFdfLineNum() { return fdfLineNum; }
    public void setFdfLineNum(String fdfLineNum) { this.fdfLineNum = fdfLineNum; }

    public String getCblDist() { return cblDist; }
    public void setCblDist(String cblDist) { this.cblDist = cblDist; }
}
