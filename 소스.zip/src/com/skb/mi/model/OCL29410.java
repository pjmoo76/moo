package com.skb.mi.model;

public class OCL29410 {
	private	String	clctDt;
	private	String	fileTypCtt;
	private	String	filePathNm;
	private	String	fileNm;
	private	String	auditId;
	private	long	fileSize;
	private	long	dataCnt;
	private	String	operStaDtm;
	private	String	operFnshDtm;
	private	String	operRsltCtt;

	public String getClctDt() {
		return clctDt;
	}
	public void setClctDt(String clctDt) {
		this.clctDt = clctDt;
	}
	public String getFileTypCtt() {
		return fileTypCtt;
	}
	public void setFileTypCtt(String fileTypCtt) {
		this.fileTypCtt = fileTypCtt;
	}
	public String getFilePathNm() {
		return filePathNm;
	}
	public void setFilePathNm(String filePathNm) {
		this.filePathNm = filePathNm;
	}
	public String getFileNm() {
		return fileNm;
	}
	public void setFileNm(String fileNm) {
		this.fileNm = fileNm;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public long getFileSize() {
		return fileSize;
	}
	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}
	public long getDataCnt() {
		return dataCnt;
	}
	public void setDataCnt(long dataCnt) {
		this.dataCnt = dataCnt;
	}
	public String getOperStaDtm() {
		return operStaDtm;
	}
	public void setOperStaDtm(String operStaDtm) {
		this.operStaDtm = operStaDtm;
	}
	public String getOperFnshDtm() {
		return operFnshDtm;
	}
	public void setOperFnshDtm(String operFnshDtm) {
		this.operFnshDtm = operFnshDtm;
	}
	public String getOperRsltCtt() {
		return operRsltCtt;
	}
	public void setOperRsltCtt(String operRsltCtt) {
		this.operRsltCtt = operRsltCtt;
	}
}
