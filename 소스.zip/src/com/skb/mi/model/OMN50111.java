package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OMN50111 extends CopyVO {
	private	String	vocTypClCd;
	private	String	auditId;
	private	String	auditDtm;
	private	String	supVocTypClCd;
	private	String	maxVocTypClCd;
	private	String	maxVocTypClCdNm;
	private	String	mclVocTypClCd;
	private	String	mclVocTypClCdNm;
	private	String	sclVocTypClCd;
	private	String	sclVocTypClCdNm;
	private	int	sortSeq;
	private	int	vocTypClCdDepthCnt;
	private	String	vocTypClRelOrgId;
	private	String	coClCd;
	private	String	kpiChgFuncAddYn;
	private	String	rangeVocTypClCd;

	public String getVocTypClCd() {
		return vocTypClCd;
	}
	public void setVocTypClCd(String vocTypClCd) {
		this.vocTypClCd = vocTypClCd;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getSupVocTypClCd() {
		return supVocTypClCd;
	}
	public void setSupVocTypClCd(String supVocTypClCd) {
		this.supVocTypClCd = supVocTypClCd;
	}
	public String getMaxVocTypClCd() {
		return maxVocTypClCd;
	}
	public void setMaxVocTypClCd(String maxVocTypClCd) {
		this.maxVocTypClCd = maxVocTypClCd;
	}
	public String getMaxVocTypClCdNm() {
		return maxVocTypClCdNm;
	}
	public void setMaxVocTypClCdNm(String maxVocTypClCdNm) {
		this.maxVocTypClCdNm = maxVocTypClCdNm;
	}
	public String getMclVocTypClCd() {
		return mclVocTypClCd;
	}
	public void setMclVocTypClCd(String mclVocTypClCd) {
		this.mclVocTypClCd = mclVocTypClCd;
	}
	public String getMclVocTypClCdNm() {
		return mclVocTypClCdNm;
	}
	public void setMclVocTypClCdNm(String mclVocTypClCdNm) {
		this.mclVocTypClCdNm = mclVocTypClCdNm;
	}
	public String getSclVocTypClCd() {
		return sclVocTypClCd;
	}
	public void setSclVocTypClCd(String sclVocTypClCd) {
		this.sclVocTypClCd = sclVocTypClCd;
	}
	public String getSclVocTypClCdNm() {
		return sclVocTypClCdNm;
	}
	public void setSclVocTypClCdNm(String sclVocTypClCdNm) {
		this.sclVocTypClCdNm = sclVocTypClCdNm;
	}
	public int getSortSeq() {
		return sortSeq;
	}
	public void setSortSeq(int sortSeq) {
		this.sortSeq = sortSeq;
	}
	public int getVocTypClCdDepthCnt() {
		return vocTypClCdDepthCnt;
	}
	public void setVocTypClCdDepthCnt(int vocTypClCdDepthCnt) {
		this.vocTypClCdDepthCnt = vocTypClCdDepthCnt;
	}
	public String getVocTypClRelOrgId() {
		return vocTypClRelOrgId;
	}
	public void setVocTypClRelOrgId(String vocTypClRelOrgId) {
		this.vocTypClRelOrgId = vocTypClRelOrgId;
	}
	public String getCoClCd() {
		return coClCd;
	}
	public void setCoClCd(String coClCd) {
		this.coClCd = coClCd;
	}
	public String getKpiChgFuncAddYn() {
		return kpiChgFuncAddYn;
	}
	public void setKpiChgFuncAddYn(String kpiChgFuncAddYn) {
		this.kpiChgFuncAddYn = kpiChgFuncAddYn;
	}
	public String getRangeVocTypClCd() {
		return rangeVocTypClCd;
	}
	public void setRangeVocTypClCd(String rangeVocTypClCd) {
		this.rangeVocTypClCd = rangeVocTypClCd;
	}
	@Override
	public void setKey() {
		this.key = this.vocTypClCd;
	}
	@Override
	public boolean equals(CopyVO obj) {
		OMN50111 dest = (OMN50111) obj;
		if (false == StringUtils.equals(this.supVocTypClCd, dest.supVocTypClCd)) return false;
		if (false == StringUtils.equals(this.maxVocTypClCd, dest.maxVocTypClCd)) return false;
		if (false == StringUtils.equals(this.maxVocTypClCdNm, dest.maxVocTypClCdNm)) return false;
		if (false == StringUtils.equals(this.mclVocTypClCd, dest.mclVocTypClCd)) return false;
		if (false == StringUtils.equals(this.mclVocTypClCdNm, dest.mclVocTypClCdNm)) return false;
		if (false == StringUtils.equals(this.sclVocTypClCd, dest.sclVocTypClCd)) return false;
		if (false == StringUtils.equals(this.sclVocTypClCdNm, dest.sclVocTypClCdNm)) return false;
		if (this.sortSeq != dest.sortSeq) return false;
		if (this.vocTypClCdDepthCnt != dest.vocTypClCdDepthCnt) return false;
		if (false == StringUtils.equals(this.vocTypClRelOrgId, dest.vocTypClRelOrgId)) return false;
		if (false == StringUtils.equals(this.coClCd, dest.coClCd)) return false;
		if (false == StringUtils.equals(this.kpiChgFuncAddYn, dest.kpiChgFuncAddYn)) return false;
		return true;
	}
	@Override
	public void setRange(CopyVO obj) {
		OMN50111 src = (OMN50111) obj;
		this.rangeVocTypClCd = src.vocTypClCd;
	}
}
