package com.skb.mi.model;

public class OIV10866 {
	private	String	mntrDthm;
	private	String	tblNm;
	private	String	auditId;
	private	int		dataAllCnt;
	private	String	logUseFnshYn;
	private	String	operStaDtm;
	private	String	operFnshDtm;
	private	String	operRsltCtt;

	public String getMntrDthm() {
		return mntrDthm;
	}
	public void setMntrDthm(String mntrDthm) {
		this.mntrDthm = mntrDthm;
	}
	public String getTblNm() {
		return tblNm;
	}
	public void setTblNm(String tblNm) {
		this.tblNm = tblNm;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public int getDataAllCnt() {
		return dataAllCnt;
	}
	public void setDataAllCnt(int dataAllCnt) {
		this.dataAllCnt = dataAllCnt;
	}
	public String getLogUseFnshYn() {
		return logUseFnshYn;
	}
	public void setLogUseFnshYn(String logUseFnshYn) {
		this.logUseFnshYn = logUseFnshYn;
	}
	public String getOperStaDtm() {
		return operStaDtm;
	}
	public void setOperStaDtm(String operStaDtm) {
		this.operStaDtm = operStaDtm;
	}
	public String getOperFnshDtm() {
		return operFnshDtm;
	}
	public void setOperFnshDtm(String operFnshDtm) {
		this.operFnshDtm = operFnshDtm;
	}
	public String getOperRsltCtt() {
		return operRsltCtt;
	}
	public void setOperRsltCtt(String operRsltCtt) {
		this.operRsltCtt = operRsltCtt;
	}
}
