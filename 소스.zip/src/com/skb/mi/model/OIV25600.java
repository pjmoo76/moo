package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV25600 extends CopyVO {
	private	String	equipId;
	private	String	consAttrNm;
	private	String	consAttrVal;
	private	String	auditId;
	private	String	auditDtm;
	private	String	teamOrgId;

	private	String	rangeEquipId;
	private	String	rangeConsAttrNm;
	private	String	rangeConsAttrVal;

	public String getEquipId() {
		return equipId;
	}
	public void setEquipId(String equipId) {
		this.equipId = equipId;
	}
	public String getConsAttrNm() {
		return consAttrNm;
	}
	public void setConsAttrNm(String consAttrNm) {
		this.consAttrNm = consAttrNm;
	}
	public String getConsAttrVal() {
		return consAttrVal;
	}
	public void setConsAttrVal(String consAttrVal) {
		this.consAttrVal = consAttrVal;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getTeamOrgId() {
		return teamOrgId;
	}
	public void setTeamOrgId(String teamOrgId) {
		this.teamOrgId = teamOrgId;
	}
	public String getRangeEquipId() {
		return rangeEquipId;
	}
	public void setRangeEquipId(String rangeEquipId) {
		this.rangeEquipId = rangeEquipId;
	}
	public String getRangeConsAttrNm() {
		return rangeConsAttrNm;
	}
	public void setRangeConsAttrNm(String rangeConsAttrNm) {
		this.rangeConsAttrNm = rangeConsAttrNm;
	}
	public String getRangeConsAttrVal() {
		return rangeConsAttrVal;
	}
	public void setRangeConsAttrVal(String rangeConsAttrVal) {
		this.rangeConsAttrVal = rangeConsAttrVal;
	}
	@Override
	public void setKey() {
		this.key = this.equipId + "|" + this.consAttrNm + "|" + this.consAttrVal;
	}
	@Override
	public boolean equals(CopyVO obj) {
		OIV25600 dest = (OIV25600) obj;
		if (false == StringUtils.equals(this.teamOrgId, dest.teamOrgId)) return false;
		return true;
	}
	@Override
	public void setRange(CopyVO obj) {
		OIV25600 src = (OIV25600) obj;
		this.rangeEquipId = src.equipId;
		this.rangeConsAttrNm = src.consAttrNm;
		this.rangeConsAttrVal = src.consAttrVal;
	}
}
