package com.skb.mi.model;

public class OIV10875 {
	private	String	dbNm;
	private	String	dbTypNm;
	private	String	ipAddr;
	private	String	connPortNum;
	private	String	dbConnUrl;
	private	String	dbAddInfo;

	public String getDbNm() {
		return dbNm;
	}
	public void setDbNm(String dbNm) {
		this.dbNm = dbNm;
	}
	public String getDbTypNm() {
		return dbTypNm;
	}
	public void setDbTypNm(String dbTypNm) {
		this.dbTypNm = dbTypNm;
	}
	public String getIpAddr() {
		return ipAddr;
	}
	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}
	public String getConnPortNum() {
		return connPortNum;
	}
	public void setConnPortNum(String connPortNum) {
		this.connPortNum = connPortNum;
	}
	public String getDbConnUrl() {
		return dbConnUrl;
	}
	public void setDbConnUrl(String dbConnUrl) {
		this.dbConnUrl = dbConnUrl;
	}
	public String getDbAddInfo() {
		return dbAddInfo;
	}
	public void setDbAddInfo(String dbAddInfo) {
		this.dbAddInfo = dbAddInfo;
	}
}
