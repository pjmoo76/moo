package com.skb.mi.model;

import java.util.ArrayList;

public class OMN50201 {
	private	String	cnslDt;
	private	String	linCallClCd;
	private	String	cnslSerNum;
	private	String	auditId;
	private	String	auditDtm;
	private	String	cnslTm;
	private	String	csrId;
	private	String	vocRcvId;
	private	String	vocTypClCd;
	private	String	vocActCd;
	private	String	cnslOpStCd;
	private	String	dablOpStCd;
	private	String	netDablIdntNum;
	private	String	addrId;
	private	String	allAddr;
	private	String	ldongCd;
	private	String	dsatClCd;
	private	String	cnslContClCd;
	private	String	custNum;
	private	String	custNm;
	private	String	dablRcvNum;
	private	String	svcTechMthdCd;
	private	String	svcNum;
	private	String	svcMgmtNum;
	private	String	feeProdId;
	private	String	svcDtlClCd;
	private	String	cnslMemo;
	private	String	cnslDtm;
	private	String	insDtm;
	private	String	rgstDt;
	private	String	apMdlNm;
	private	String	apMacAddr;
	private	String	apVerCtt;
	private	String	stbMdlNm;
	private	String	stbMacAddr;
	private	String	stbVerCtt;
	private	String	sswNm;
	private	String	sbcNm;
	private	String	iptvSvcMgmtNum;
	private	String	inetSvcMgmtNum;
	private	String	phonSvcMgmtNum;
	private	String	netClCd;
	private	String	infoCntrCd;
	private	String	distbCntrCd;
	private	String	l2EquipId;
	private	String	l3EquipId;
	private	String	equipId;
	private	String	weqpMdlCd;
	private	String	svcCd;
	private	String	ccellNum;
	private	String	apWeqpMgmtNum;
	private	String	apEqpMdlCd;
	private	String	stbWeqpMgmtNum;
	private	String	stbEqpMdlCd;
	private	String	shspdWeqpMgmtNum;
	private	String	shspdEqpMdlCd;
	private	String	shspdEqpMdlNm;
	private	String	shspdEqpMacAddr;
	private	String	shspdEqpVerCtt;
	private	String	shspdEqpMfactSerNum;
	private	String	etcWeqpMdlNm;
	private	String	etcMacAddr;
	private	String	etcWeqpVerCtt;
	private	String	etcWeqpMgmtNum;
	private	String	etcEqpMdlCd;
	private	String 	nSvcTechMthdCd; /* 비회선 체크용 */
	private	String 	outLnkgIpAddr;  /* 외부연동IP */
	
	private String	tvClVal;
	private String	scrbrTbSoClCd;
	private String	stbInrCmMacAddr;
	
	private	int	procCnt;
	private	ArrayList<OMN50202>	dtlList;
	

	// additional
	private	String	svcTechMthdNm;
	private String	tableName = "OMN50201";


	public String getCnslDt() {
		return cnslDt;
	}
	public void setCnslDt(String cnslDt) {
		this.cnslDt = cnslDt;
	}
	public String getLinCallClCd() {
		return linCallClCd;
	}
	public void setLinCallClCd(String linCallClCd) {
		this.linCallClCd = linCallClCd;
	}
	public String getCnslSerNum() {
		return cnslSerNum;
	}
	public void setCnslSerNum(String cnslSerNum) {
		this.cnslSerNum = cnslSerNum;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getCnslTm() {
		return cnslTm;
	}
	public void setCnslTm(String cnslTm) {
		this.cnslTm = cnslTm;
	}
	public String getCsrId() {
		return csrId;
	}
	public void setCsrId(String csrId) {
		this.csrId = csrId;
	}
	public String getVocRcvId() {
		return vocRcvId;
	}
	public void setVocRcvId(String vocRcvId) {
		this.vocRcvId = vocRcvId;
	}
	public String getVocTypClCd() {
		return vocTypClCd;
	}
	public void setVocTypClCd(String vocTypClCd) {
		this.vocTypClCd = vocTypClCd;
	}
	public String getVocActCd() {
		return vocActCd;
	}
	public void setVocActCd(String vocActCd) {
		this.vocActCd = vocActCd;
	}
	public String getCnslOpStCd() {
		return cnslOpStCd;
	}
	public void setCnslOpStCd(String cnslOpStCd) {
		this.cnslOpStCd = cnslOpStCd;
	}
	public String getDablOpStCd() {
		return dablOpStCd;
	}
	public void setDablOpStCd(String dablOpStCd) {
		this.dablOpStCd = dablOpStCd;
	}
	public String getNetDablIdntNum() {
		return netDablIdntNum;
	}
	public void setNetDablIdntNum(String netDablIdntNum) {
		this.netDablIdntNum = netDablIdntNum;
	}
	public String getAddrId() {
		return addrId;
	}
	public void setAddrId(String addrId) {
		this.addrId = addrId;
	}
	public String getAllAddr() {
		return allAddr;
	}
	public void setAllAddr(String allAddr) {
		this.allAddr = allAddr;
	}
	public String getLdongCd() {
		return ldongCd;
	}
	public void setLdongCd(String ldongCd) {
		this.ldongCd = ldongCd;
	}
	public String getDsatClCd() {
		return dsatClCd;
	}
	public void setDsatClCd(String dsatClCd) {
		this.dsatClCd = dsatClCd;
	}
	public String getCnslContClCd() {
		return cnslContClCd;
	}
	public void setCnslContClCd(String cnslContClCd) {
		this.cnslContClCd = cnslContClCd;
	}
	public String getCustNum() {
		return custNum;
	}
	public void setCustNum(String custNum) {
		this.custNum = custNum;
	}
	public String getCustNm() {
		return custNm;
	}
	public void setCustNm(String custNm) {
		this.custNm = custNm;
	}
	public String getDablRcvNum() {
		return dablRcvNum;
	}
	public void setDablRcvNum(String dablRcvNum) {
		this.dablRcvNum = dablRcvNum;
	}
	public String getSvcTechMthdCd() {
		return svcTechMthdCd;
	}
	public void setSvcTechMthdCd(String svcTechMthdCd) {
		this.svcTechMthdCd = svcTechMthdCd;
	}
	public String getSvcNum() {
		return svcNum;
	}
	public void setSvcNum(String svcNum) {
		this.svcNum = svcNum;
	}
	public String getSvcMgmtNum() {
		return svcMgmtNum;
	}
	public void setSvcMgmtNum(String svcMgmtNum) {
		this.svcMgmtNum = svcMgmtNum;
	}
	public String getFeeProdId() {
		return feeProdId;
	}
	public void setFeeProdId(String feeProdId) {
		this.feeProdId = feeProdId;
	}
	public String getSvcDtlClCd() {
		return svcDtlClCd;
	}
	public void setSvcDtlClCd(String svcDtlClCd) {
		this.svcDtlClCd = svcDtlClCd;
	}
	public String getCnslMemo() {
		return cnslMemo;
	}
	public void setCnslMemo(String cnslMemo) {
		this.cnslMemo = cnslMemo;
	}
	public String getCnslDtm() {
		return cnslDtm;
	}
	public void setCnslDtm(String cnslDtm) {
		this.cnslDtm = cnslDtm;
	}
	public String getInsDtm() {
		return insDtm;
	}
	public void setInsDtm(String insDtm) {
		this.insDtm = insDtm;
	}
	public String getRgstDt() {
		return rgstDt;
	}
	public void setRgstDt(String rgstDt) {
		this.rgstDt = rgstDt;
	}
	public String getApMdlNm() {
		return apMdlNm;
	}
	public void setApMdlNm(String apMdlNm) {
		this.apMdlNm = apMdlNm;
	}
	public String getApMacAddr() {
		return apMacAddr;
	}
	public void setApMacAddr(String apMacAddr) {
		this.apMacAddr = apMacAddr;
	}
	public String getApVerCtt() {
		return apVerCtt;
	}
	public void setApVerCtt(String apVerCtt) {
		this.apVerCtt = apVerCtt;
	}
	public String getStbMdlNm() {
		return stbMdlNm;
	}
	public void setStbMdlNm(String stbMdlNm) {
		this.stbMdlNm = stbMdlNm;
	}
	public String getStbMacAddr() {
		return stbMacAddr;
	}
	public void setStbMacAddr(String stbMacAddr) {
		this.stbMacAddr = stbMacAddr;
	}
	public String getStbVerCtt() {
		return stbVerCtt;
	}
	public void setStbVerCtt(String stbVerCtt) {
		this.stbVerCtt = stbVerCtt;
	}
	public String getSswNm() {
		return sswNm;
	}
	public void setSswNm(String sswNm) {
		this.sswNm = sswNm;
	}
	public String getSbcNm() {
		return sbcNm;
	}
	public void setSbcNm(String sbcNm) {
		this.sbcNm = sbcNm;
	}
	public String getIptvSvcMgmtNum() {
		return iptvSvcMgmtNum;
	}
	public void setIptvSvcMgmtNum(String iptvSvcMgmtNum) {
		this.iptvSvcMgmtNum = iptvSvcMgmtNum;
	}
	public String getInetSvcMgmtNum() {
		return inetSvcMgmtNum;
	}
	public void setInetSvcMgmtNum(String inetSvcMgmtNum) {
		this.inetSvcMgmtNum = inetSvcMgmtNum;
	}
	public String getPhonSvcMgmtNum() {
		return phonSvcMgmtNum;
	}
	public void setPhonSvcMgmtNum(String phonSvcMgmtNum) {
		this.phonSvcMgmtNum = phonSvcMgmtNum;
	}
	public String getNetClCd() {
		return netClCd;
	}
	public void setNetClCd(String netClCd) {
		this.netClCd = netClCd;
	}
	public String getInfoCntrCd() {
		return infoCntrCd;
	}
	public void setInfoCntrCd(String infoCntrCd) {
		this.infoCntrCd = infoCntrCd;
	}
	public String getDistbCntrCd() {
		return distbCntrCd;
	}
	public void setDistbCntrCd(String distbCntrCd) {
		this.distbCntrCd = distbCntrCd;
	}
	public String getL2EquipId() {
		return l2EquipId;
	}
	public void setL2EquipId(String l2EquipId) {
		this.l2EquipId = l2EquipId;
	}
	public String getL3EquipId() {
		return l3EquipId;
	}
	public void setL3EquipId(String l3EquipId) {
		this.l3EquipId = l3EquipId;
	}
	public String getEquipId() {
		return equipId;
	}
	public void setEquipId(String equipId) {
		this.equipId = equipId;
	}
	public String getWeqpMdlCd() {
		return weqpMdlCd;
	}
	public void setWeqpMdlCd(String weqpMdlCd) {
		this.weqpMdlCd = weqpMdlCd;
	}
	public String getSvcCd() {
		return svcCd;
	}
	public void setSvcCd(String svcCd) {
		this.svcCd = svcCd;
	}
	public String getCcellNum() {
		return ccellNum;
	}
	public void setCcellNum(String ccellNum) {
		this.ccellNum = ccellNum;
	}
	public String getApWeqpMgmtNum() {
		return apWeqpMgmtNum;
	}
	public void setApWeqpMgmtNum(String apWeqpMgmtNum) {
		this.apWeqpMgmtNum = apWeqpMgmtNum;
	}
	public String getApEqpMdlCd() {
		return apEqpMdlCd;
	}
	public void setApEqpMdlCd(String apEqpMdlCd) {
		this.apEqpMdlCd = apEqpMdlCd;
	}
	public String getStbWeqpMgmtNum() {
		return stbWeqpMgmtNum;
	}
	public void setStbWeqpMgmtNum(String stbWeqpMgmtNum) {
		this.stbWeqpMgmtNum = stbWeqpMgmtNum;
	}
	public String getStbEqpMdlCd() {
		return stbEqpMdlCd;
	}
	public void setStbEqpMdlCd(String stbEqpMdlCd) {
		this.stbEqpMdlCd = stbEqpMdlCd;
	}
	public String getShspdWeqpMgmtNum() {
		return shspdWeqpMgmtNum;
	}
	public void setShspdWeqpMgmtNum(String shspdWeqpMgmtNum) {
		this.shspdWeqpMgmtNum = shspdWeqpMgmtNum;
	}
	public String getShspdEqpMdlCd() {
		return shspdEqpMdlCd;
	}
	public void setShspdEqpMdlCd(String shspdEqpMdlCd) {
		this.shspdEqpMdlCd = shspdEqpMdlCd;
	}
	public String getShspdEqpMdlNm() {
		return shspdEqpMdlNm;
	}
	public void setShspdEqpMdlNm(String shspdEqpMdlNm) {
		this.shspdEqpMdlNm = shspdEqpMdlNm;
	}
	public String getShspdEqpMacAddr() {
		return shspdEqpMacAddr;
	}
	public void setShspdEqpMacAddr(String shspdEqpMacAddr) {
		this.shspdEqpMacAddr = shspdEqpMacAddr;
	}
	public String getShspdEqpVerCtt() {
		return shspdEqpVerCtt;
	}
	public void setShspdEqpVerCtt(String shspdEqpVerCtt) {
		this.shspdEqpVerCtt = shspdEqpVerCtt;
	}
	public String getShspdEqpMfactSerNum() {
		return shspdEqpMfactSerNum;
	}
	public void setShspdEqpMfactSerNum(String shspdEqpMfactSerNum) {
		this.shspdEqpMfactSerNum = shspdEqpMfactSerNum;
	}

	// additional
	public String getSvcTechMthdNm() {
		return svcTechMthdNm;
	}
	public void setSvcTechMthdNm(String svcTechMthdNm) {
		this.svcTechMthdNm = svcTechMthdNm;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public int getProcCnt() {
		return procCnt;
	}
	public void setProcCnt(int procCnt) {
		this.procCnt = procCnt;
	}
	
	public ArrayList<OMN50202> getDtlList() {
		return dtlList;
	}
	public void setDtlList(ArrayList<OMN50202> dtlList) {
		this.dtlList = dtlList;
	}

	

	public String getMqDebugString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("[01] CSR_ID : %s\n", this.csrId));
		sb.append(String.format("[02] CNSL_DT : %s\n", this.cnslDt));
		sb.append(String.format("[03] CNSL_TM : %s\n", this.cnslTm));
		sb.append(String.format("[04] LIN_CALL_CL_CD : %s\n", this.linCallClCd));
		sb.append(String.format("[05] VOC_TYP_CL_CD : %s\n", this.vocTypClCd));
		sb.append(String.format("[06] CNSL_OP_ST_CD : %s\n", this.cnslOpStCd));
		sb.append(String.format("[07] DABL_OP_ST_CD : %s\n", this.dablOpStCd));
		sb.append(String.format("[08] NET_DABL_IDNT_NUM : %s\n", this.netDablIdntNum));
		sb.append(String.format("[09] ADDR_ID : %s\n", this.addrId));
		sb.append(String.format("[10] ALL_ADDR : %s\n", this.allAddr));
		sb.append(String.format("[11] LDONG_CD : %s\n", this.ldongCd));
		sb.append(String.format("[12] DSAT_CL_CD : %s\n", this.dsatClCd));
		sb.append(String.format("[13] CNSL_CONT_CL_CD : %s\n", this.cnslContClCd));
		sb.append(String.format("[14] CUST_NUM : %s\n", this.custNum));
		sb.append(String.format("[15] CUST_NM : %s\n", this.custNm));
		sb.append(String.format("[16] DABL_RCV_NUM : %s\n", this.dablRcvNum));
		sb.append(String.format("[17] PROC_CNT : %s\n", this.procCnt));
		sb.append(String.format("[18] SVC_CD : %s\n", this.svcCd));		
		sb.append(String.format("[19] SVC_NUM : %s\n", this.svcNum));
		sb.append(String.format("[20] SVC_MGMT_NUM : %s\n", this.svcMgmtNum));
		sb.append(String.format("[21] FEE_PROD_ID : %s\n", this.feeProdId));
		sb.append(String.format("[22] SVC_DTL_CL_CD : %s\n", this.svcDtlClCd));	
		int itemIndex = 18;
		ArrayList<OMN50202> dtlList =  this.dtlList;
		sb.append(String.format("인입호부가정보 %s건\n",this.procCnt));
		for(int i=0;i<dtlList.size();i++)
		{
			
			OMN50202 omn50202= dtlList.get(i);
			sb.append(String.format("DTL_SEQ : %s\n",omn50202.getDtlSeq()));
			sb.append(String.format("[%s] SVC_CD : %s\n", itemIndex++,omn50202.getSvcCd()));
			sb.append(String.format("[%s] SVC_NUM : %s\n", itemIndex++, omn50202.getSvcNum()));
			sb.append(String.format("[%s] SVC_MGMT_NUM : %s\n", itemIndex++, omn50202.getSvcMgmtNum()));
			sb.append(String.format("[%s] FEE_PROD_ID : %s\n", itemIndex++, omn50202.getFeeProdId()));
			sb.append(String.format("[%s] SVC_DTL_CL_CD : %s\n", itemIndex++, omn50202.getSvcDtlClCd()));
		}
				
		sb.append(String.format("[%s] CNSL_MEMO : %s",itemIndex, this.cnslMemo));
		return sb.toString();
	}

	public String getEtcMacAddr() {
		return etcMacAddr;
	}
	public void setEtcMacAddr(String etcMacAddr) {
		this.etcMacAddr = etcMacAddr;
	}

	public String getEtcWeqpMgmtNum() {
		return etcWeqpMgmtNum;
	}
	public void setEtcWeqpMgmtNum(String etcWeqpMgmtNum) {
		this.etcWeqpMgmtNum = etcWeqpMgmtNum;
	}
	public String getEtcEqpMdlCd() {
		return etcEqpMdlCd;
	}
	public void setEtcEqpMdlCd(String etcEqpMdlCd) {
		this.etcEqpMdlCd = etcEqpMdlCd;
	}
	public String getEtcWeqpMdlNm() {
		return etcWeqpMdlNm;
	}
	public void setEtcWeqpMdlNm(String etcWeqpMdlNm) {
		this.etcWeqpMdlNm = etcWeqpMdlNm;
	}
	public String getEtcWeqpVerCtt() {
		return etcWeqpVerCtt;
	}
	public void setEtcWeqpVerCtt(String etcWeqpVerCtt) {
		this.etcWeqpVerCtt = etcWeqpVerCtt;
	}
	public String getnSvcTechMthdCd() {
		return nSvcTechMthdCd;
	}
	public void setnSvcTechMthdCd(String nSvcTechMthdCd) {
		this.nSvcTechMthdCd = nSvcTechMthdCd;
	}
	public String getOutLnkgIpAddr() {
		return outLnkgIpAddr;
	}
	public void setOutLnkgIpAddr(String outLnkgIpAddr) {
		this.outLnkgIpAddr = outLnkgIpAddr;
	}
	public String getTvClVal() {
		return tvClVal;
	}
	public void setTvClVal(String tvClVal) {
		this.tvClVal = tvClVal;
	}
	public String getScrbrTbSoClCd() {
		return scrbrTbSoClCd;
	}
	public void setScrbrTbSoClCd(String scrbrTbSoClCd) {
		this.scrbrTbSoClCd = scrbrTbSoClCd;
	}
	public String getStbInrCmMacAddr() {
		return stbInrCmMacAddr;
	}
	public void setStbInrCmMacAddr(String stbInrCmMacAddr) {
		this.stbInrCmMacAddr = stbInrCmMacAddr;
	}
	@Override
	public String toString() {
		return "OMN50201 [cnslDt=" + cnslDt + ", linCallClCd=" + linCallClCd
				+ ", cnslSerNum=" + cnslSerNum + ", auditId=" + auditId
				+ ", auditDtm=" + auditDtm + ", cnslTm=" + cnslTm + ", csrId="
				+ csrId + ", vocRcvId=" + vocRcvId + ", vocTypClCd="
				+ vocTypClCd + ", vocActCd=" + vocActCd + ", cnslOpStCd="
				+ cnslOpStCd + ", dablOpStCd=" + dablOpStCd
				+ ", netDablIdntNum=" + netDablIdntNum + ", addrId=" + addrId
				+ ", allAddr=" + allAddr + ", ldongCd=" + ldongCd
				+ ", dsatClCd=" + dsatClCd + ", cnslContClCd=" + cnslContClCd
				+ ", custNum=" + custNum + ", custNm=" + custNm
				+ ", dablRcvNum=" + dablRcvNum + ", svcTechMthdCd="
				+ svcTechMthdCd + ", svcNum=" + svcNum + ", svcMgmtNum="
				+ svcMgmtNum + ", feeProdId=" + feeProdId + ", svcDtlClCd="
				+ svcDtlClCd + ", cnslMemo=" + cnslMemo + ", cnslDtm="
				+ cnslDtm + ", insDtm=" + insDtm + ", rgstDt=" + rgstDt
				+ ", apMdlNm=" + apMdlNm + ", apMacAddr=" + apMacAddr
				+ ", apVerCtt=" + apVerCtt + ", stbMdlNm=" + stbMdlNm
				+ ", stbMacAddr=" + stbMacAddr + ", stbVerCtt=" + stbVerCtt
				+ ", sswNm=" + sswNm + ", sbcNm=" + sbcNm + ", iptvSvcMgmtNum="
				+ iptvSvcMgmtNum + ", inetSvcMgmtNum=" + inetSvcMgmtNum
				+ ", phonSvcMgmtNum=" + phonSvcMgmtNum + ", netClCd=" + netClCd
				+ ", infoCntrCd=" + infoCntrCd + ", distbCntrCd=" + distbCntrCd
				+ ", l2EquipId=" + l2EquipId + ", l3EquipId=" + l3EquipId
				+ ", equipId=" + equipId + ", weqpMdlCd=" + weqpMdlCd
				+ ", svcCd=" + svcCd + ", ccellNum=" + ccellNum
				+ ", apWeqpMgmtNum=" + apWeqpMgmtNum + ", apEqpMdlCd="
				+ apEqpMdlCd + ", stbWeqpMgmtNum=" + stbWeqpMgmtNum
				+ ", stbEqpMdlCd=" + stbEqpMdlCd + ", shspdWeqpMgmtNum="
				+ shspdWeqpMgmtNum + ", shspdEqpMdlCd=" + shspdEqpMdlCd
				+ ", shspdEqpMdlNm=" + shspdEqpMdlNm + ", shspdEqpMacAddr="
				+ shspdEqpMacAddr + ", shspdEqpVerCtt=" + shspdEqpVerCtt
				+ ", shspdEqpMfactSerNum=" + shspdEqpMfactSerNum
				+ ", etcWeqpMdlNm=" + etcWeqpMdlNm + ", etcMacAddr="
				+ etcMacAddr + ", etcWeqpVerCtt=" + etcWeqpVerCtt
				+ ", etcWeqpMgmtNum=" + etcWeqpMgmtNum + ", etcEqpMdlCd="
				+ etcEqpMdlCd + ", nSvcTechMthdCd=" + nSvcTechMthdCd
				+ ", outLnkgIpAddr=" + outLnkgIpAddr + ", tvClVal=" + tvClVal
				+ ", scrbrTbSoClCd=" + scrbrTbSoClCd + ", stbInrCmMacAddr="
				+ stbInrCmMacAddr + ", procCnt=" + procCnt + ", dtlList="
				+ dtlList + ", svcTechMthdNm=" + svcTechMthdNm + ", tableName="
				+ tableName + "]";
	}
	
	
}
