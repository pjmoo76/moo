package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OMN32525 extends AggrDataVO {
	private	String	evtRcvDtm;
	private	String	macAddrVal;
	private	String	auditId;
	private	String	evtOccrDtm;
	private	String	netClCd;
	private	String	infoCntrCd;
	private	String	distbCntrCd;
	private	String	homeCntrCd;
	private	String	l3TidVal;
	private	String	l3EquipId;
	private	String	l2TidVal;
	private	String	l2EquipId;
	private	String	ccellNum;
	private	String	eqpMdlCd;
	private	String	eqpVerInfo;
	private	long	inetSvcMgmtNum;
	private	String	inetSvcNm;
	private	long	iptvSvcMgmtNum;
	private	String	iptvSvcNm;
	private	String	ipAddr;
	private	String	weqpPortClVal;
	private	String	cpeMacAddr;
	private	int		evtOccrCnt;
	
	// add
	private	long	timeMillis;
	
	public String getEvtRcvDtm() {
		return evtRcvDtm;
	}
	public void setEvtRcvDtm(String evtRcvDtm) {
		this.evtRcvDtm = evtRcvDtm;
	}
	public String getMacAddrVal() {
		return macAddrVal;
	}
	public void setMacAddrVal(String macAddrVal) {
		this.macAddrVal = macAddrVal;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getEvtOccrDtm() {
		return evtOccrDtm;
	}
	public void setEvtOccrDtm(String evtOccrDtm) {
		this.evtOccrDtm = evtOccrDtm;
	}
	public String getNetClCd() {
		return netClCd;
	}
	public void setNetClCd(String netClCd) {
		this.netClCd = netClCd;
	}
	public String getInfoCntrCd() {
		return infoCntrCd;
	}
	public void setInfoCntrCd(String infoCntrCd) {
		this.infoCntrCd = infoCntrCd;
	}
	public String getDistbCntrCd() {
		return distbCntrCd;
	}
	public void setDistbCntrCd(String distbCntrCd) {
		this.distbCntrCd = distbCntrCd;
	}
	public String getHomeCntrCd() {
		return homeCntrCd;
	}
	public void setHomeCntrCd(String homeCntrCd) {
		this.homeCntrCd = homeCntrCd;
	}
	public String getL3TidVal() {
		return l3TidVal;
	}
	public void setL3TidVal(String l3TidVal) {
		this.l3TidVal = l3TidVal;
	}
	public String getL3EquipId() {
		return l3EquipId;
	}
	public void setL3EquipId(String l3EquipId) {
		this.l3EquipId = l3EquipId;
	}
	public String getL2TidVal() {
		return l2TidVal;
	}
	public void setL2TidVal(String l2TidVal) {
		this.l2TidVal = l2TidVal;
	}
	public String getL2EquipId() {
		return l2EquipId;
	}
	public void setL2EquipId(String l2EquipId) {
		this.l2EquipId = l2EquipId;
	}
	public String getCcellNum() {
		return ccellNum;
	}
	public void setCcellNum(String ccellNum) {
		this.ccellNum = ccellNum;
	}
	public String getEqpMdlCd() {
		return eqpMdlCd;
	}
	public void setEqpMdlCd(String eqpMdlCd) {
		this.eqpMdlCd = eqpMdlCd;
	}
	public String getEqpVerInfo() {
		return eqpVerInfo;
	}
	public void setEqpVerInfo(String eqpVerInfo) {
		this.eqpVerInfo = eqpVerInfo;
	}
	public long getInetSvcMgmtNum() {
		return inetSvcMgmtNum;
	}
	public void setInetSvcMgmtNum(long inetSvcMgmtNum) {
		this.inetSvcMgmtNum = inetSvcMgmtNum;
	}
	public String getInetSvcNm() {
		return inetSvcNm;
	}
	public void setInetSvcNm(String inetSvcNm) {
		this.inetSvcNm = inetSvcNm;
	}
	public long getIptvSvcMgmtNum() {
		return iptvSvcMgmtNum;
	}
	public void setIptvSvcMgmtNum(long iptvSvcMgmtNum) {
		this.iptvSvcMgmtNum = iptvSvcMgmtNum;
	}
	public String getIptvSvcNm() {
		return iptvSvcNm;
	}
	public void setIptvSvcNm(String iptvSvcNm) {
		this.iptvSvcNm = iptvSvcNm;
	}
	public String getIpAddr() {
		return ipAddr;
	}
	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}
	public String getWeqpPortClVal() {
		return weqpPortClVal;
	}
	public void setWeqpPortClVal(String weqpPortClVal) {
		this.weqpPortClVal = weqpPortClVal;
	}
	public String getCpeMacAddr() {
		return cpeMacAddr;
	}
	public void setCpeMacAddr(String cpeMacAddr) {
		this.cpeMacAddr = cpeMacAddr;
	}
	public int getEvtOccrCnt() {
		return evtOccrCnt;
	}
	public void setEvtOccrCnt(int evtOccrCnt) {
		this.evtOccrCnt = evtOccrCnt;
	}
	public long getTimeMillis() {
		return timeMillis;
	}
	public void setTimeMillis(long timeMillis) {
		this.timeMillis = timeMillis;
	}

	@Override
	public boolean isValid() {
		if (this.macAddrVal == null || this.macAddrVal.isEmpty() || this.macAddrVal.length() > 15) {
			return false;
		}
		return true;
	}

	@Override
	public String toDelimiterString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("%s|", evtRcvDtm));
		sb.append(String.format("%s|", macAddrVal));
		sb.append(String.format("%s|", auditId));
		sb.append(String.format("%s|", evtOccrDtm));
		sb.append(String.format("%s|", StringUtils.null2Empty(netClCd)));
		sb.append(String.format("%s|", StringUtils.null2Empty(infoCntrCd)));
		sb.append(String.format("%s|", StringUtils.null2Empty(distbCntrCd)));
		sb.append(String.format("%s|", StringUtils.null2Empty(homeCntrCd)));
		sb.append(String.format("%s|", StringUtils.null2Empty(l3EquipId)));
		sb.append(String.format("%s|", StringUtils.null2Empty(l2EquipId)));
		sb.append(String.format("%s|", StringUtils.null2Empty(ccellNum)));
		sb.append(String.format("%s|", StringUtils.null2Empty(eqpMdlCd)));
		sb.append(String.format("%s|", StringUtils.null2Empty(eqpVerInfo)));
		sb.append(String.format("%d|", inetSvcMgmtNum));
		sb.append(String.format("%s|", StringUtils.null2Empty(inetSvcNm)));
		sb.append(String.format("%d|", iptvSvcMgmtNum));
		sb.append(String.format("%s|", StringUtils.null2Empty(iptvSvcNm)));
		sb.append(String.format("%s|", StringUtils.null2Empty(ipAddr)));
		sb.append(String.format("%s|", StringUtils.null2Empty(weqpPortClVal)));
		sb.append(String.format("%s|", StringUtils.null2Empty(cpeMacAddr)));
		sb.append(String.format("%d|", evtOccrCnt));
		return sb.toString();
	}

	@Override
	public void add(AggrDataVO obj) {
		// TODO Auto-generated method stub
		
	}
}
