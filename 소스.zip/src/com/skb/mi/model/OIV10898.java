package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV10898  extends CopyVO {
	
	private	String	apMacAddr;
	private	String	prvShrrMacAddr;
	private	String	auditId;
	private	String	auditDtm;
	private	String	prvShrrIpAddr;
	private	String	prvShrrMfactNm;
	private	String	lastUpdDtm;

	private	String	rangeApMacAddr;
	private	String	rangePrvShrrMacAddr;
	
	
	public String getApMacAddr() {
		return apMacAddr;
	}

	public void setApMacAddr(String apMacAddr) {
		this.apMacAddr = apMacAddr;
	}

	public String getPrvShrrMacAddr() {
		return prvShrrMacAddr;
	}

	public void setPrvShrrMacAddr(String prvShrrMacAddr) {
		this.prvShrrMacAddr = prvShrrMacAddr;
	}

	public String getAuditId() {
		return auditId;
	}

	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	public String getAuditDtm() {
		return auditDtm;
	}

	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}

	public String getPrvShrrIpAddr() {
		return prvShrrIpAddr;
	}

	public void setPrvShrrIpAddr(String prvShrrIpAddr) {
		this.prvShrrIpAddr = prvShrrIpAddr;
	}

	public String getPrvShrrMfactNm() {
		return prvShrrMfactNm;
	}

	public void setPrvShrrMfactNm(String prvShrrMfactNm) {
		this.prvShrrMfactNm = prvShrrMfactNm;
	}

	public String getLastUpdDtm() {
		return lastUpdDtm;
	}

	public void setLastUpdDtm(String lastUpdDtm) {
		this.lastUpdDtm = lastUpdDtm;
	}

	
	
	public String getRangeApMacAddr() {
		return rangeApMacAddr;
	}

	public void setRangeApMacAddr(String rangeApMacAddr) {
		this.rangeApMacAddr = rangeApMacAddr;
	}
	
	public String getRangePrvShrrMacAddr() {
		return rangePrvShrrMacAddr;
	}

	public void setRangePrvShrrMacAddr(String rangePrvShrrMacAddr) {
		this.rangePrvShrrMacAddr = rangePrvShrrMacAddr;
	}

	
	@Override
	public void setKey() {
		this.key = this.apMacAddr+"|"+this.prvShrrMacAddr;
		
	}

	@Override
	public boolean equals(CopyVO obj) {
		OIV10898 dest = (OIV10898) obj;
		if (false == StringUtils.equals(this.apMacAddr, dest.apMacAddr)) return false;
		if (false == StringUtils.equals(this.prvShrrMacAddr, dest.prvShrrMacAddr)) return false;
		if (false == StringUtils.equals(this.prvShrrIpAddr, dest.prvShrrIpAddr)) return false;
		if (false == StringUtils.equals(this.prvShrrMfactNm, dest.prvShrrMfactNm)) return false;
		if (false == StringUtils.equals(this.lastUpdDtm, dest.lastUpdDtm)) return false;
		return true;
	}

	@Override
	public void setRange(CopyVO obj) {
		OIV10898 src = (OIV10898) obj;
		this.rangeApMacAddr = src.apMacAddr;
		this.rangePrvShrrMacAddr = src.prvShrrMacAddr;
		
	}

}