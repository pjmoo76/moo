package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV10708 extends CopyVO {
	private	String	weqpGrpCd;
	private	String	auditId;
	private	String	auditDtm;
	private	String	supWeqpGrpCd;
	private	String	weqpGrpClCd;
	private	String	weqpGrpNm;
	private	String	weqpGrpEngNm;
	private	String	massCoUsgEqpClCd;
	private	String	useYn;
	private	String	onlineClCd;
	private	String	rmk;
	
	private	String	rangeWeqpGrpCd;

	public String getWeqpGrpCd() {
		return weqpGrpCd;
	}
	public void setWeqpGrpCd(String weqpGrpCd) {
		this.weqpGrpCd = weqpGrpCd;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getSupWeqpGrpCd() {
		return supWeqpGrpCd;
	}
	public void setSupWeqpGrpCd(String supWeqpGrpCd) {
		this.supWeqpGrpCd = supWeqpGrpCd;
	}
	public String getWeqpGrpClCd() {
		return weqpGrpClCd;
	}
	public void setWeqpGrpClCd(String weqpGrpClCd) {
		this.weqpGrpClCd = weqpGrpClCd;
	}
	public String getWeqpGrpNm() {
		return weqpGrpNm;
	}
	public void setWeqpGrpNm(String weqpGrpNm) {
		this.weqpGrpNm = weqpGrpNm;
	}
	public String getWeqpGrpEngNm() {
		return weqpGrpEngNm;
	}
	public void setWeqpGrpEngNm(String weqpGrpEngNm) {
		this.weqpGrpEngNm = weqpGrpEngNm;
	}
	public String getMassCoUsgEqpClCd() {
		return massCoUsgEqpClCd;
	}
	public void setMassCoUsgEqpClCd(String massCoUsgEqpClCd) {
		this.massCoUsgEqpClCd = massCoUsgEqpClCd;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	public String getOnlineClCd() {
		return onlineClCd;
	}
	public void setOnlineClCd(String onlineClCd) {
		this.onlineClCd = onlineClCd;
	}
	public String getRmk() {
		return rmk;
	}
	public void setRmk(String rmk) {
		this.rmk = rmk;
	}
	public String getRangeWeqpGrpCd() {
		return rangeWeqpGrpCd;
	}
	public void setRangeWeqpGrpCd(String rangeWeqpGrpCd) {
		this.rangeWeqpGrpCd = rangeWeqpGrpCd;
	}
	@Override
	public void setKey() {
		this.key = this.weqpGrpCd;
	}
	@Override
	public boolean equals(CopyVO obj) {
		OIV10708 dest = (OIV10708) obj;
		if (false == StringUtils.equals(this.weqpGrpCd, dest.weqpGrpCd)) return false;
		if (false == StringUtils.equals(this.auditId, dest.auditId)) return false;
		if (false == StringUtils.equals(this.auditDtm, dest.auditDtm)) return false;
		if (false == StringUtils.equals(this.supWeqpGrpCd, dest.supWeqpGrpCd)) return false;
		if (false == StringUtils.equals(this.weqpGrpClCd, dest.weqpGrpClCd)) return false;
		if (false == StringUtils.equals(this.weqpGrpNm, dest.weqpGrpNm)) return false;
		if (false == StringUtils.equals(this.weqpGrpEngNm, dest.weqpGrpEngNm)) return false;
		if (false == StringUtils.equals(this.massCoUsgEqpClCd, dest.massCoUsgEqpClCd)) return false;
		if (false == StringUtils.equals(this.useYn, dest.useYn)) return false;
		if (false == StringUtils.equals(this.onlineClCd, dest.onlineClCd)) return false;
		if (false == StringUtils.equals(this.rmk, dest.rmk)) return false;
		return true;
	}
	@Override
	public void setRange(CopyVO obj) {
		OIV10708 src = (OIV10708) obj;
		this.rangeWeqpGrpCd = src.weqpGrpCd;
	}

}
