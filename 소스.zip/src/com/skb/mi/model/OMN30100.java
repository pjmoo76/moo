package com.skb.mi.model;

public class OMN30100 {
	private Integer rmsLinkCnt;
	private Integer dablNum;
    private String auditId;
    private String auditDtm;
    private String dablNm;
    private String dablDesc;
    private String nmsCd;
    private String nmsDablNumCtt;
    private String nmsDablCd;
    private String dablLclCd;
    private String dablMclCd;
    private String dablCd;
    private String netDablSrcId;
    private String dablStCd;
    private String dablGrCd;
    private String dablRgstClCd;
    private String dablExlYn;
    private String occrDtm;
    private String occrRcvDtm;
    private String rlseDtm;
    private String rlseRcvDtm;
    private String dablRlseMthdCd;
    private String dablRlseRsnCtt;
    private String dablRlsrId;
    private String dablOpStCd;
    private String dablOprId;
    private String dablOpDtm;
    private String equipId;
    private String equipNm;
    private String equipTidVal;
    private String equipMdlCd;
    private String dmgScrbrCnt;
    private String dablCheckYn;
    private String dablChkrId;
    private String dablCheckDtm;
    private String infoCntrCd;
    private String distbCntrCd;
    private String orgId;
    private String equipDablNumCtt;
    private String equipDablMsgCtt;
    private String equipDablSmryCtt;
    private String dablDupCnt;
    private String ticketYn;
    private String emcyDablYn;
    private String egovDablYn;
    private String dsstrYn;
    private String suplrCd;
    private String netBizrCd;
    private String ofdDablYn;
    private String bbntDablYn;
    private String dablConsItmDesc;
    private String dablOccrLocDesc;
    private String operDablYn;
    private String dablPortDesc;
    private String netOpNum;
    private String keepTms;
    private String netClCd;
    private String dablModmCnt;
    private String vocCnt;
    private String dablNetClCd;
    private String portAlsNm;
    private String dablCdSerNum;
    private String dablSrcRgstDtm;
    private String annceNum;
    private String swingAnnceYn;
    private String scrbrCnt;
    private String dmgLineCnt;
    private String trmsNetMgmtOwnrCd;
    private String sktOrgNm;
    private String operEndDtm;
    private String dablRmk;
    private String dablActCtt1;
    private String dablActCtt2;
    private String dablActCtt3;
    private String dablActCtt4;
    private String dablActCtt5;
    private String autoRlseYn;
    private String infoCntrNm;
    private String distbCntrNm;
    private String equipIpAddr;
    private String equipMdlNm;
    private String equipSetLocDesc;
    private String teamNm;
    private String teamId;
    private String divNm;
    private String divId;
    private String equipMdlTypCd;
    private String equipMdlTypNm;

    // ---------- Getter / Setter ----------

    public String getInfoCntrNm() {
        return infoCntrNm;
    }

    public void setInfoCntrNm(String infoCntrNm) {
        this.infoCntrNm = infoCntrNm;
    }

    public String getDistbCntrNm() {
        return distbCntrNm;
    }

    public void setDistbCntrNm(String distbCntrNm) {
        this.distbCntrNm = distbCntrNm;
    }

    public String getEquipIpAddr() {
        return equipIpAddr;
    }

    public void setEquipIpAddr(String equipIpAddr) {
        this.equipIpAddr = equipIpAddr;
    }

    public String getEquipMdlNm() {
        return equipMdlNm;
    }

    public void setEquipMdlNm(String equipMdlNm) {
        this.equipMdlNm = equipMdlNm;
    }

    public String getEquipSetLocDesc() {
        return equipSetLocDesc;
    }

    public void setEquipSetLocDesc(String equipSetLocDesc) {
        this.equipSetLocDesc = equipSetLocDesc;
    }

    public String getTeamNm() {
        return teamNm;
    }

    public void setTeamNm(String teamNm) {
        this.teamNm = teamNm;
    }

    public String getTeamId() {
        return teamId;
    }

    public void setTeamId(String teamId) {
        this.teamId = teamId;
    }

    public String getDivNm() {
        return divNm;
    }

    public void setDivNm(String divNm) {
        this.divNm = divNm;
    }

    public String getDivId() {
        return divId;
    }

    public void setDivId(String divId) {
        this.divId = divId;
    }

    public String getEquipMdlTypCd() {
        return equipMdlTypCd;
    }

    public void setEquipMdlTypCd(String equipMdlTypCd) {
        this.equipMdlTypCd = equipMdlTypCd;
    }

    public String getEquipMdlTypNm() {
        return equipMdlTypNm;
    }

    public void setEquipMdlTypNm(String equipMdlTypNm) {
        this.equipMdlTypNm = equipMdlTypNm;
    }

    // getter / setter
    public Integer getRmsLinkCnt() { return rmsLinkCnt; }
    public void setRmsLinkCnt(Integer rmsLinkCnt) { this.rmsLinkCnt = rmsLinkCnt; }
    
    public Integer getDablNum() { return dablNum; }
    public void setDablNum(Integer dablNum) { this.dablNum = dablNum; }

    public String getAuditId() { return auditId; }
    public void setAuditId(String auditId) { this.auditId = auditId; }

    public String getAuditDtm() { return auditDtm; }
    public void setAuditDtm(String auditDtm) { this.auditDtm = auditDtm; }

    public String getDablNm() { return dablNm; }
    public void setDablNm(String dablNm) { this.dablNm = dablNm; }

    public String getDablDesc() { return dablDesc; }
    public void setDablDesc(String dablDesc) { this.dablDesc = dablDesc; }

    public String getNmsCd() { return nmsCd; }
    public void setNmsCd(String nmsCd) { this.nmsCd = nmsCd; }

    public String getNmsDablNumCtt() { return nmsDablNumCtt; }
    public void setNmsDablNumCtt(String nmsDablNumCtt) { this.nmsDablNumCtt = nmsDablNumCtt; }

    public String getNmsDablCd() { return nmsDablCd; }
    public void setNmsDablCd(String nmsDablCd) { this.nmsDablCd = nmsDablCd; }

    public String getDablLclCd() { return dablLclCd; }
    public void setDablLclCd(String dablLclCd) { this.dablLclCd = dablLclCd; }

    public String getDablMclCd() { return dablMclCd; }
    public void setDablMclCd(String dablMclCd) { this.dablMclCd = dablMclCd; }

    public String getDablCd() { return dablCd; }
    public void setDablCd(String dablCd) { this.dablCd = dablCd; }

    public String getNetDablSrcId() { return netDablSrcId; }
    public void setNetDablSrcId(String netDablSrcId) { this.netDablSrcId = netDablSrcId; }

    public String getDablStCd() { return dablStCd; }
    public void setDablStCd(String dablStCd) { this.dablStCd = dablStCd; }

    public String getDablGrCd() { return dablGrCd; }
    public void setDablGrCd(String dablGrCd) { this.dablGrCd = dablGrCd; }

    public String getDablRgstClCd() { return dablRgstClCd; }
    public void setDablRgstClCd(String dablRgstClCd) { this.dablRgstClCd = dablRgstClCd; }

    public String getDablExlYn() { return dablExlYn; }
    public void setDablExlYn(String dablExlYn) { this.dablExlYn = dablExlYn; }

    public String getOccrDtm() { return occrDtm; }
    public void setOccrDtm(String occrDtm) { this.occrDtm = occrDtm; }

    public String getOccrRcvDtm() { return occrRcvDtm; }
    public void setOccrRcvDtm(String occrRcvDtm) { this.occrRcvDtm = occrRcvDtm; }

    public String getRlseDtm() { return rlseDtm; }
    public void setRlseDtm(String rlseDtm) { this.rlseDtm = rlseDtm; }

    public String getRlseRcvDtm() { return rlseRcvDtm; }
    public void setRlseRcvDtm(String rlseRcvDtm) { this.rlseRcvDtm = rlseRcvDtm; }

    public String getDablRlseMthdCd() { return dablRlseMthdCd; }
    public void setDablRlseMthdCd(String dablRlseMthdCd) { this.dablRlseMthdCd = dablRlseMthdCd; }

    public String getDablRlseRsnCtt() { return dablRlseRsnCtt; }
    public void setDablRlseRsnCtt(String dablRlseRsnCtt) { this.dablRlseRsnCtt = dablRlseRsnCtt; }

    public String getDablRlsrId() { return dablRlsrId; }
    public void setDablRlsrId(String dablRlsrId) { this.dablRlsrId = dablRlsrId; }

    public String getDablOpStCd() { return dablOpStCd; }
    public void setDablOpStCd(String dablOpStCd) { this.dablOpStCd = dablOpStCd; }

    public String getDablOprId() { return dablOprId; }
    public void setDablOprId(String dablOprId) { this.dablOprId = dablOprId; }

    public String getDablOpDtm() { return dablOpDtm; }
    public void setDablOpDtm(String dablOpDtm) { this.dablOpDtm = dablOpDtm; }

    public String getEquipId() { return equipId; }
    public void setEquipId(String equipId) { this.equipId = equipId; }
    
    public String getEquipNm() { return equipNm; }
    public void setEquipNm(String equipNm) { this.equipId = equipNm; }
    
    public String getEquipTidVal() { return equipTidVal; }
    public void setEquipTidVal(String equipTidVal) { this.equipTidVal = equipTidVal; }
    
    public String getEquipMdlCd() { return equipMdlCd; }
    public void setEquipMdlCd(String equipMdlCd) { this.equipMdlCd = equipMdlCd; }

    public String getDmgScrbrCnt() { return dmgScrbrCnt; }
    public void setDmgScrbrCnt(String dmgScrbrCnt) { this.dmgScrbrCnt = dmgScrbrCnt; }

    public String getDablCheckYn() { return dablCheckYn; }
    public void setDablCheckYn(String dablCheckYn) { this.dablCheckYn = dablCheckYn; }

    public String getDablChkrId() { return dablChkrId; }
    public void setDablChkrId(String dablChkrId) { this.dablChkrId = dablChkrId; }

    public String getDablCheckDtm() { return dablCheckDtm; }
    public void setDablCheckDtm(String dablCheckDtm) { this.dablCheckDtm = dablCheckDtm; }

    public String getInfoCntrCd() { return infoCntrCd; }
    public void setInfoCntrCd(String infoCntrCd) { this.infoCntrCd = infoCntrCd; }

    public String getDistbCntrCd() { return distbCntrCd; }
    public void setDistbCntrCd(String distbCntrCd) { this.distbCntrCd = distbCntrCd; }

    public String getOrgId() { return orgId; }
    public void setOrgId(String orgId) { this.orgId = orgId; }

    public String getEquipDablNumCtt() { return equipDablNumCtt; }
    public void setEquipDablNumCtt(String equipDablNumCtt) { this.equipDablNumCtt = equipDablNumCtt; }

    public String getEquipDablMsgCtt() { return equipDablMsgCtt; }
    public void setEquipDablMsgCtt(String equipDablMsgCtt) { this.equipDablMsgCtt = equipDablMsgCtt; }

    public String getEquipDablSmryCtt() { return equipDablSmryCtt; }
    public void setEquipDablSmryCtt(String equipDablSmryCtt) { this.equipDablSmryCtt = equipDablSmryCtt; }

    public String getDablDupCnt() { return dablDupCnt; }
    public void setDablDupCnt(String dablDupCnt) { this.dablDupCnt = dablDupCnt; }

    public String getTicketYn() { return ticketYn; }
    public void setTicketYn(String ticketYn) { this.ticketYn = ticketYn; }

    public String getEmcyDablYn() { return emcyDablYn; }
    public void setEmcyDablYn(String emcyDablYn) { this.emcyDablYn = emcyDablYn; }

    public String getEgovDablYn() { return egovDablYn; }
    public void setEgovDablYn(String egovDablYn) { this.egovDablYn = egovDablYn; }

    public String getDsstrYn() { return dsstrYn; }
    public void setDsstrYn(String dsstrYn) { this.dsstrYn = dsstrYn; }

    public String getSuplrCd() { return suplrCd; }
    public void setSuplrCd(String suplrCd) { this.suplrCd = suplrCd; }

    public String getNetBizrCd() { return netBizrCd; }
    public void setNetBizrCd(String netBizrCd) { this.netBizrCd = netBizrCd; }

    public String getOfdDablYn() { return ofdDablYn; }
    public void setOfdDablYn(String ofdDablYn) { this.ofdDablYn = ofdDablYn; }

    public String getBbntDablYn() { return bbntDablYn; }
    public void setBbntDablYn(String bbntDablYn) { this.bbntDablYn = bbntDablYn; }

    public String getDablConsItmDesc() { return dablConsItmDesc; }
    public void setDablConsItmDesc(String dablConsItmDesc) { this.dablConsItmDesc = dablConsItmDesc; }

    public String getDablOccrLocDesc() { return dablOccrLocDesc; }
    public void setDablOccrLocDesc(String dablOccrLocDesc) { this.dablOccrLocDesc = dablOccrLocDesc; }

    public String getOperDablYn() { return operDablYn; }
    public void setOperDablYn(String operDablYn) { this.operDablYn = operDablYn; }

    public String getDablPortDesc() { return dablPortDesc; }
    public void setDablPortDesc(String dablPortDesc) { this.dablPortDesc = dablPortDesc; }

    public String getNetOpNum() { return netOpNum; }
    public void setNetOpNum(String netOpNum) { this.netOpNum = netOpNum; }

    public String getKeepTms() { return keepTms; }
    public void setKeepTms(String keepTms) { this.keepTms = keepTms; }

    public String getNetClCd() { return netClCd; }
    public void setNetClCd(String netClCd) { this.netClCd = netClCd; }

    public String getDablModmCnt() { return dablModmCnt; }
    public void setDablModmCnt(String dablModmCnt) { this.dablModmCnt = dablModmCnt; }

    public String getVocCnt() { return vocCnt; }
    public void setVocCnt(String vocCnt) { this.vocCnt = vocCnt; }

    public String getDablNetClCd() { return dablNetClCd; }
    public void setDablNetClCd(String dablNetClCd) { this.dablNetClCd = dablNetClCd; }

    public String getPortAlsNm() { return portAlsNm; }
    public void setPortAlsNm(String portAlsNm) { this.portAlsNm = portAlsNm; }

    public String getDablCdSerNum() { return dablCdSerNum; }
    public void setDablCdSerNum(String dablCdSerNum) { this.dablCdSerNum = dablCdSerNum; }

    public String getDablSrcRgstDtm() { return dablSrcRgstDtm; }
    public void setDablSrcRgstDtm(String dablSrcRgstDtm) { this.dablSrcRgstDtm = dablSrcRgstDtm; }

    public String getAnnceNum() { return annceNum; }
    public void setAnnceNum(String annceNum) { this.annceNum = annceNum; }

    public String getSwingAnnceYn() { return swingAnnceYn; }
    public void setSwingAnnceYn(String swingAnnceYn) { this.swingAnnceYn = swingAnnceYn; }

    public String getScrbrCnt() { return scrbrCnt; }
    public void setScrbrCnt(String scrbrCnt) { this.scrbrCnt = scrbrCnt; }

    public String getDmgLineCnt() { return dmgLineCnt; }
    public void setDmgLineCnt(String dmgLineCnt) { this.dmgLineCnt = dmgLineCnt; }

    public String getTrmsNetMgmtOwnrCd() { return trmsNetMgmtOwnrCd; }
    public void setTrmsNetMgmtOwnrCd(String trmsNetMgmtOwnrCd) { this.trmsNetMgmtOwnrCd = trmsNetMgmtOwnrCd; }

    public String getSktOrgNm() { return sktOrgNm; }
    public void setSktOrgNm(String sktOrgNm) { this.sktOrgNm = sktOrgNm; }

    public String getOperEndDtm() { return operEndDtm; }
    public void setOperEndDtm(String operEndDtm) { this.operEndDtm = operEndDtm; }

    public String getDablRmk() { return dablRmk; }
    public void setDablRmk(String dablRmk) { this.dablRmk = dablRmk; }

    public String getDablActCtt1() { return dablActCtt1; }
    public void setDablActCtt1(String dablActCtt1) { this.dablActCtt1 = dablActCtt1; }

    public String getDablActCtt2() { return dablActCtt2; }
    public void setDablActCtt2(String dablActCtt2) { this.dablActCtt2 = dablActCtt2; }

    public String getDablActCtt3() { return dablActCtt3; }
    public void setDablActCtt3(String dablActCtt3) { this.dablActCtt3 = dablActCtt3; }

    public String getDablActCtt4() { return dablActCtt4; }
    public void setDablActCtt4(String dablActCtt4) { this.dablActCtt4 = dablActCtt4; }

    public String getDablActCtt5() { return dablActCtt5; }
    public void setDablActCtt5(String dablActCtt5) { this.dablActCtt5 = dablActCtt5; }
    
    public String getAutoRlseYn() { return autoRlseYn; }
    public void setAutoRlseYn(String autoRlseYn) { this.autoRlseYn = autoRlseYn; }

	public void setCoVipCustYn(String string) {
		// TODO Auto-generated method stub
		
	}
}
