package com.skb.mi.model;

public class SdsStbInfoVO {
	// STB_MAC|SVC_MGMT_NUM|VERSION|ST_VERSION|UPTIME|STB_LOCAL_IP|STB_REAL_IP|SDS_PATCH_GROUP|STB_LAST_UTIME
	private	String	stbMac;
	private	String	svcMgmtNum;
	private	String	version;
	private	String	stVersion;
	private	String	upTime;
	private	String	stbLocalIp;
	private	String	stbRealIp;
	private	String	sdsPatchGroup;
	private	String	sdsLastUtime;
	
	public String getStbMac() {
		return stbMac;
	}
	public void setStbMac(String stbMac) {
		this.stbMac = stbMac;
	}
	public String getSvcMgmtNum() {
		return svcMgmtNum;
	}
	public void setSvcMgmtNum(String svcMgmtNum) {
		this.svcMgmtNum = svcMgmtNum;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getStVersion() {
		return stVersion;
	}
	public void setStVersion(String stVersion) {
		this.stVersion = stVersion;
	}
	public String getUpTime() {
		return upTime;
	}
	public void setUpTime(String upTime) {
		this.upTime = upTime;
	}
	public String getStbLocalIp() {
		return stbLocalIp;
	}
	public void setStbLocalIp(String stbLocalIp) {
		this.stbLocalIp = stbLocalIp;
	}
	public String getStbRealIp() {
		return stbRealIp;
	}
	public void setStbRealIp(String stbRealIp) {
		this.stbRealIp = stbRealIp;
	}
	public String getSdsPatchGroup() {
		return sdsPatchGroup;
	}
	public void setSdsPatchGroup(String sdsPatchGroup) {
		this.sdsPatchGroup = sdsPatchGroup;
	}
	public String getSdsLastUtime() {
		return sdsLastUtime;
	}
	public void setSdsLastUtime(String sdsLastUtime) {
		this.sdsLastUtime = sdsLastUtime;
	}
	
	public void parse(String data) {
		String[] items = data.split(":");
		stbMac = items[0].replaceAll(":", "").toUpperCase();
		
	}
}
