package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV10200 extends CopyVO {
	private	String	equipMdlCd;
	private	String	auditId;
	private	String	auditDtm;
	private	String	equipMfactCd;
	private	String	equipMdlNm;
	private	String	equipMdlTypCd;
	private	String	equipTypCd;
	private	String	equipMdlDesc;
	private	String	equipIntdcYm;
	private	String	consItmManlRgstYn;
	private	String	sameConnIdUseYn;
	private	String	scrbrNetEquipCapaClCd;
	private	String	rtypAIniPortAlsNm;
	private	String	rtypBIniPortAlsNm;
	private	String	clctMthdClCd;
	private	String	olvlYn;

	private	String	rangeEquipMdlCd;

	public String getEquipMdlCd() {
		return equipMdlCd;
	}
	public void setEquipMdlCd(String equipMdlCd) {
		this.equipMdlCd = equipMdlCd;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getEquipMfactCd() {
		return equipMfactCd;
	}
	public void setEquipMfactCd(String equipMfactCd) {
		this.equipMfactCd = equipMfactCd;
	}
	public String getEquipMdlNm() {
		return equipMdlNm;
	}
	public void setEquipMdlNm(String equipMdlNm) {
		this.equipMdlNm = equipMdlNm;
	}
	public String getEquipMdlTypCd() {
		return equipMdlTypCd;
	}
	public void setEquipMdlTypCd(String equipMdlTypCd) {
		this.equipMdlTypCd = equipMdlTypCd;
	}
	public String getEquipTypCd() {
		return equipTypCd;
	}
	public void setEquipTypCd(String equipTypCd) {
		this.equipTypCd = equipTypCd;
	}
	public String getEquipMdlDesc() {
		return equipMdlDesc;
	}
	public void setEquipMdlDesc(String equipMdlDesc) {
		this.equipMdlDesc = equipMdlDesc;
	}
	public String getEquipIntdcYm() {
		return equipIntdcYm;
	}
	public void setEquipIntdcYm(String equipIntdcYm) {
		this.equipIntdcYm = equipIntdcYm;
	}
	public String getConsItmManlRgstYn() {
		return consItmManlRgstYn;
	}
	public void setConsItmManlRgstYn(String consItmManlRgstYn) {
		this.consItmManlRgstYn = consItmManlRgstYn;
	}
	public String getSameConnIdUseYn() {
		return sameConnIdUseYn;
	}
	public void setSameConnIdUseYn(String sameConnIdUseYn) {
		this.sameConnIdUseYn = sameConnIdUseYn;
	}
	public String getScrbrNetEquipCapaClCd() {
		return scrbrNetEquipCapaClCd;
	}
	public void setScrbrNetEquipCapaClCd(String scrbrNetEquipCapaClCd) {
		this.scrbrNetEquipCapaClCd = scrbrNetEquipCapaClCd;
	}
	public String getRtypAIniPortAlsNm() {
		return rtypAIniPortAlsNm;
	}
	public void setRtypAIniPortAlsNm(String rtypAIniPortAlsNm) {
		this.rtypAIniPortAlsNm = rtypAIniPortAlsNm;
	}
	public String getRtypBIniPortAlsNm() {
		return rtypBIniPortAlsNm;
	}
	public void setRtypBIniPortAlsNm(String rtypBIniPortAlsNm) {
		this.rtypBIniPortAlsNm = rtypBIniPortAlsNm;
	}
	public String getClctMthdClCd() {
		return clctMthdClCd;
	}
	public void setClctMthdClCd(String clctMthdClCd) {
		this.clctMthdClCd = clctMthdClCd;
	}
	public String getOlvlYn() {
		return olvlYn;
	}
	public void setOlvlYn(String olvlYn) {
		this.olvlYn = olvlYn;
	}
	@Override
	public void setKey() {
		this.key = this.equipMdlCd;
	}
	@Override
	public boolean equals(CopyVO obj) {
		OIV10200 dest = (OIV10200) obj;
		if (false == StringUtils.equals(this.equipMdlCd, dest.equipMdlCd)) return false;
		if (false == StringUtils.equals(this.equipMfactCd, dest.equipMfactCd)) return false;
		if (false == StringUtils.equals(this.equipMdlNm, dest.equipMdlNm)) return false;
		if (false == StringUtils.equals(this.equipMdlTypCd, dest.equipMdlTypCd)) return false;
		if (false == StringUtils.equals(this.equipTypCd, dest.equipTypCd)) return false;
		if (false == StringUtils.equals(this.equipMdlDesc, dest.equipMdlDesc)) return false;
		if (false == StringUtils.equals(this.equipIntdcYm, dest.equipIntdcYm)) return false;
		if (false == StringUtils.equals(this.consItmManlRgstYn, dest.consItmManlRgstYn)) return false;
		if (false == StringUtils.equals(this.sameConnIdUseYn, dest.sameConnIdUseYn)) return false;
		if (false == StringUtils.equals(this.scrbrNetEquipCapaClCd, dest.scrbrNetEquipCapaClCd)) return false;
		if (false == StringUtils.equals(this.rtypAIniPortAlsNm, dest.rtypAIniPortAlsNm)) return false;
		if (false == StringUtils.equals(this.rtypBIniPortAlsNm, dest.rtypBIniPortAlsNm)) return false;
		if (false == StringUtils.equals(this.clctMthdClCd, dest.clctMthdClCd)) return false;
		if (false == StringUtils.equals(this.olvlYn, dest.olvlYn)) return false;
		return true;
	}
	@Override
	public void setRange(CopyVO obj) {
		OIV10200 src = (OIV10200) obj;
		this.rangeEquipMdlCd = src.getEquipMdlCd();
	}
	public String getRangeEquipMdlCd() {
		return rangeEquipMdlCd;
	}
	public void setRangeEquipMdlCd(String rangeEquipMdlCd) {
		this.rangeEquipMdlCd = rangeEquipMdlCd;
	}
}
