package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OMN50104 extends CopyVO {
	private	String	vocTypClCd;
	private	String	auditId;
	private	String	auditDtm;
	private	String	useYn;
	private	String	vocTypClAddCd;
	private	String	kpiYn;
	private	String	iptvDfltUseYn;
	private	String	rangeVocTypClCd;

	public String getVocTypClCd() {
		return vocTypClCd;
	}
	public void setVocTypClCd(String vocTypClCd) {
		this.vocTypClCd = vocTypClCd;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	public String getVocTypClAddCd() {
		return vocTypClAddCd;
	}
	public void setVocTypClAddCd(String vocTypClAddCd) {
		this.vocTypClAddCd = vocTypClAddCd;
	}
	public String getKpiYn() {
		return kpiYn;
	}
	public void setKpiYn(String kpiYn) {
		this.kpiYn = kpiYn;
	}
	public String getIptvDfltUseYn() {
		return iptvDfltUseYn;
	}
	public void setIptvDfltUseYn(String iptvDfltUseYn) {
		this.iptvDfltUseYn = iptvDfltUseYn;
	}
	public String getRangeVocTypClCd() {
		return rangeVocTypClCd;
	}
	public void setRangeVocTypClCd(String rangeVocTypClCd) {
		this.rangeVocTypClCd = rangeVocTypClCd;
	}
	@Override
	public void setKey() {
		this.key = this.vocTypClCd;
	}
	@Override
	public boolean equals(CopyVO obj) {
		OMN50104 dest = (OMN50104) obj;
		if (false == StringUtils.equals(this.useYn, dest.useYn)) return false;
		if (false == StringUtils.equals(this.vocTypClAddCd, dest.vocTypClAddCd)) return false;
		if (false == StringUtils.equals(this.kpiYn, dest.kpiYn)) return false;
		if (false == StringUtils.equals(this.iptvDfltUseYn, dest.iptvDfltUseYn)) return false;
		return true;
	}
	@Override
	public void setRange(CopyVO obj) {
		OMN50104 src = (OMN50104) obj;
		this.rangeVocTypClCd = src.vocTypClCd;
	}
}
