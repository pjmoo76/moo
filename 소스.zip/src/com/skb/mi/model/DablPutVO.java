package com.skb.mi.model;

public class DablPutVO {
	private	int		dataType;
	private	long	dablNum;
	private	String	nmsDablNumCtt;
	private	String	nmsDablCd;
	private	String	operDablYn;
	private String	dablStCd;
	private	String	occrRcvDtm;
	private	String	occrDtm;
	private	String	operEndDtm;
	private	String	dablDesc;
	private String	rlseDtm;
	private	String	equipNm;
	private	String	equipSysNm;
	private	String	routNum;
	private	String	routNm;
	private	String	equipMgmtNum;
	private	int		useCnt;
	private	String	infoCntrCd;
	private	String	equipMntgRgstCyclVal;

	public int getDataType() {
		return dataType;
	}
	public void setDataType(int dataType) {
		this.dataType = dataType;
	}
	public long getDablNum() {
		return dablNum;
	}
	public void setDablNum(long dablNum) {
		this.dablNum = dablNum;
	}
	public String getNmsDablNumCtt() {
		return nmsDablNumCtt;
	}
	public void setNmsDablNumCtt(String nmsDablNumCtt) {
		this.nmsDablNumCtt = nmsDablNumCtt;
	}
	public String getNmsDablCd() {
		return nmsDablCd;
	}
	public void setNmsDablCd(String nmsDablCd) {
		this.nmsDablCd = nmsDablCd;
	}
	public String getOperDablYn() {
		return operDablYn;
	}
	public void setOperDablYn(String operDablYn) {
		this.operDablYn = operDablYn;
	}
	public String getDablStCd() {
		return dablStCd;
	}
	public void setDablStCd(String dablStCd) {
		this.dablStCd = dablStCd;
	}
	public String getOccrRcvDtm() {
		return occrRcvDtm;
	}
	public void setOccrRcvDtm(String occrRcvDtm) {
		this.occrRcvDtm = occrRcvDtm;
	}
	public String getOccrDtm() {
		return occrDtm;
	}
	public void setOccrDtm(String occrDtm) {
		this.occrDtm = occrDtm;
	}
	public String getOperEndDtm() {
		return operEndDtm;
	}
	public void setOperEndDtm(String operEndDtm) {
		this.operEndDtm = operEndDtm;
	}
	public String getDablDesc() {
		return dablDesc;
	}
	public void setDablDesc(String dablDesc) {
		this.dablDesc = dablDesc;
	}
	public String getRlseDtm() {
		return rlseDtm;
	}
	public void setRlseDtm(String rlseDtm) {
		this.rlseDtm = rlseDtm;
	}
	public String getEquipNm() {
		return equipNm;
	}
	public void setEquipNm(String equipNm) {
		this.equipNm = equipNm;
	}
	public String getEquipSysNm() {
		return equipSysNm;
	}
	public void setEquipSysNm(String equipSysNm) {
		this.equipSysNm = equipSysNm;
	}
	public String getRoutNum() {
		return routNum;
	}
	public void setRoutNum(String routNum) {
		this.routNum = routNum;
	}
	public String getRoutNm() {
		return routNm;
	}
	public void setRoutNm(String routNm) {
		this.routNm = routNm;
	}
	public String getEquipMgmtNum() {
		return equipMgmtNum;
	}
	public void setEquipMgmtNum(String equipMgmtNum) {
		this.equipMgmtNum = equipMgmtNum;
	}
	public int getUseCnt() {
		return useCnt;
	}
	public void setUseCnt(int useCnt) {
		this.useCnt = useCnt;
	}
	public String getInfoCntrCd() {
		return infoCntrCd;
	}
	public void setInfoCntrCd(String infoCntrCd) {
		this.infoCntrCd = infoCntrCd;
	}
	public String getEquipMntgRgstCyclVal() {
		return equipMntgRgstCyclVal;
	}
	public void setEquipMntgRgstCyclVal(String equipMntgRgstCyclVal) {
		this.equipMntgRgstCyclVal = equipMntgRgstCyclVal;
	}
	
	public String toDebugString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("(dataType:%d)\n", dataType));
		sb.append(String.format("(dablNum:%d)\n", dablNum));
		sb.append(String.format("(nmsDablNumCtt:%s)\n", nmsDablNumCtt));
		sb.append(String.format("(nmsDablCd:%s)\n", nmsDablCd));
		sb.append(String.format("(operDablYn:%s)\n", operDablYn));
		sb.append(String.format("(dablStCd:%s)\n", dablStCd));
		sb.append(String.format("(occrRcvDtm:%s)\n", occrRcvDtm));
		sb.append(String.format("(occrDtm:%s)\n", occrDtm));
		sb.append(String.format("(operEndDtm:%s)\n", operEndDtm));
		sb.append(String.format("(dablDesc:%s)\n", dablDesc));
		sb.append(String.format("(rlseDtm:%s)\n", rlseDtm));
		sb.append(String.format("(equipNm:%s)\n", equipNm));
		sb.append(String.format("(equipSysNm:%s)\n", equipSysNm));
		sb.append(String.format("(routNum:%s)\n", routNum));
		sb.append(String.format("(routNm:%s)\n", routNm));
		sb.append(String.format("(equipMgmtNum:%s)\n", equipMgmtNum));
		sb.append(String.format("(useCnt:%d)\n", useCnt));
		sb.append(String.format("(infoCntrCd:%s)\n", infoCntrCd));
		sb.append(String.format("(equipMntgRgstCyclVal:%s)", equipMntgRgstCyclVal));
		return sb.toString();
	}
}
