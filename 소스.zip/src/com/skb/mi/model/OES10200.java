package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OES10200 extends CopyVO {
	private	long	svcMgmtNum;
	private	String	auditId;
	private	String	auditDtm;
	private	String	svcCd;
	private	String	cntrctMgmtNum;
	private	String	svcNum;
	private	String	svcStCd;
	private	String	svcStChgCd;
	private	String	svcChgRsnCd;
	private	String	svcUseTypCd;
	private	String	svcScrbDt;
	private	String	svcTermDt;
	private	String	feeProdId;
	private	String	coClCd;
	private	String	svcDtlClCd;
	private	String	termDtlRsnCd;
	private	String	massCoClCd;
	private	String	custInfoAbolStCd;
	private	String	custInfoAbolDt;
	
	private	long	rangeSvcMgmtNum;
	
	public long getSvcMgmtNum() {
		return svcMgmtNum;
	}
	public void setSvcMgmtNum(long svcMgmtNum) {
		this.svcMgmtNum = svcMgmtNum;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getSvcCd() {
		return svcCd;
	}
	public void setSvcCd(String svcCd) {
		this.svcCd = svcCd;
	}
	public String getCntrctMgmtNum() {
		return cntrctMgmtNum;
	}
	public void setCntrctMgmtNum(String cntrctMgmtNum) {
		this.cntrctMgmtNum = cntrctMgmtNum;
	}
	public String getSvcNum() {
		return svcNum;
	}
	public void setSvcNum(String svcNum) {
		this.svcNum = svcNum;
	}
	public String getSvcStCd() {
		return svcStCd;
	}
	public void setSvcStCd(String svcStCd) {
		this.svcStCd = svcStCd;
	}
	public String getSvcStChgCd() {
		return svcStChgCd;
	}
	public void setSvcStChgCd(String svcStChgCd) {
		this.svcStChgCd = svcStChgCd;
	}
	public String getSvcChgRsnCd() {
		return svcChgRsnCd;
	}
	public void setSvcChgRsnCd(String svcChgRsnCd) {
		this.svcChgRsnCd = svcChgRsnCd;
	}
	public String getSvcUseTypCd() {
		return svcUseTypCd;
	}
	public void setSvcUseTypCd(String svcUseTypCd) {
		this.svcUseTypCd = svcUseTypCd;
	}
	public String getSvcScrbDt() {
		return svcScrbDt;
	}
	public void setSvcScrbDt(String svcScrbDt) {
		this.svcScrbDt = svcScrbDt;
	}
	public String getSvcTermDt() {
		return svcTermDt;
	}
	public void setSvcTermDt(String svcTermDt) {
		this.svcTermDt = svcTermDt;
	}
	public String getFeeProdId() {
		return feeProdId;
	}
	public void setFeeProdId(String feeProdId) {
		this.feeProdId = feeProdId;
	}
	public String getCoClCd() {
		return coClCd;
	}
	public void setCoClCd(String coClCd) {
		this.coClCd = coClCd;
	}
	public String getSvcDtlClCd() {
		return svcDtlClCd;
	}
	public void setSvcDtlClCd(String svcDtlClCd) {
		this.svcDtlClCd = svcDtlClCd;
	}
	public String getTermDtlRsnCd() {
		return termDtlRsnCd;
	}
	public void setTermDtlRsnCd(String termDtlRsnCd) {
		this.termDtlRsnCd = termDtlRsnCd;
	}
	public String getMassCoClCd() {
		return massCoClCd;
	}
	public void setMassCoClCd(String massCoClCd) {
		this.massCoClCd = massCoClCd;
	}
	public String getCustInfoAbolStCd() {
		return custInfoAbolStCd;
	}
	public void setCustInfoAbolStCd(String custInfoAbolStCd) {
		this.custInfoAbolStCd = custInfoAbolStCd;
	}
	public String getCustInfoAbolDt() {
		return custInfoAbolDt;
	}
	public void setCustInfoAbolDt(String custInfoAbolDt) {
		this.custInfoAbolDt = custInfoAbolDt;
	}
	public long getRangeSvcMgmtNum() {
		return rangeSvcMgmtNum;
	}
	public void setRangeSvcMgmtNum(long rangeSvcMgmtNum) {
		this.rangeSvcMgmtNum = rangeSvcMgmtNum;
	}
	@Override
	public void setKey() {
		this.key = "" + this.svcMgmtNum;
	}
	@Override
	public boolean equals(CopyVO obj) {
		OES10200 dest = (OES10200) obj;
		if (this.svcMgmtNum != dest.svcMgmtNum) return false;
		if (false == StringUtils.equals(this.svcCd, dest.svcCd)) return false;
		if (false == StringUtils.equals(this.cntrctMgmtNum, dest.cntrctMgmtNum)) return false;
		if (false == StringUtils.equals(this.svcNum, dest.svcNum)) return false;
		if (false == StringUtils.equals(this.svcStCd, dest.svcStCd)) return false;
		if (false == StringUtils.equals(this.svcStChgCd, dest.svcStChgCd)) return false;
		if (false == StringUtils.equals(this.svcChgRsnCd, dest.svcChgRsnCd)) return false;
		if (false == StringUtils.equals(this.svcUseTypCd, dest.svcUseTypCd)) return false;
		if (false == StringUtils.equals(this.svcScrbDt, dest.svcScrbDt)) return false;
		if (false == StringUtils.equals(this.svcTermDt, dest.svcTermDt)) return false;
		if (false == StringUtils.equals(this.feeProdId, dest.feeProdId)) return false;
		if (false == StringUtils.equals(this.coClCd, dest.coClCd)) return false;
		if (false == StringUtils.equals(this.svcDtlClCd, dest.svcDtlClCd)) return false;
		if (false == StringUtils.equals(this.termDtlRsnCd, dest.termDtlRsnCd)) return false;
		if (false == StringUtils.equals(this.massCoClCd, dest.massCoClCd)) return false;
		if (false == StringUtils.equals(this.custInfoAbolStCd, dest.custInfoAbolStCd)) return false;
		if (false == StringUtils.equals(this.custInfoAbolDt, dest.custInfoAbolDt)) return false;
		return true;
	}
	@Override
	public void setRange(CopyVO obj) {
		OES10200 src = (OES10200) obj;
		this.rangeSvcMgmtNum = src.svcMgmtNum;
	}
}
