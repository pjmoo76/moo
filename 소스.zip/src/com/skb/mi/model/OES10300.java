package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OES10300 extends CopyVO {
	private	long	svcMgmtNum;
	private	String	auditId;
	private	String	auditDtm;
	private	String	apMacAddrVal;
	private	String	swtchgClCd;
	private	String	dodLineClCd;
	private	String	pubPhonTypCd;
	private	String	rentLineUseYn;
	private	String	iocallClCd;
	private	String	iocallStCd;
	private	String	didRepSvcNum;
	private	String	dodRepSvcNum;
	private	String	strmPhonStaDt;
	private	String	strmPhonEndDt;
	private	String	othrCoSvcId;
	private	String	prmsOutClCd;
	private	String	intPhonWlbizrCd;
	private	String	apAddYn;
	private	String	rcvDt;
	private	String	strmRentStaDt;
	private	String	strmRentEndDt;
	private	String	eqpMdlCd;
	private	String	eqpSerNum;
	private	String	massCoClCd;
	private	String	svcTechMthdCd;
	private	String	wphonDwtnBizrCd;
	private	String	wphonPselSysBizrCd;
	private	String	inofcSvcYn;
	private	long	rangeSvcMgmtNum;
	
	public long getSvcMgmtNum() {
		return svcMgmtNum;
	}
	public void setSvcMgmtNum(long svcMgmtNum) {
		this.svcMgmtNum = svcMgmtNum;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getApMacAddrVal() {
		return apMacAddrVal;
	}
	public void setApMacAddrVal(String apMacAddrVal) {
		this.apMacAddrVal = apMacAddrVal;
	}
	public String getSwtchgClCd() {
		return swtchgClCd;
	}
	public void setSwtchgClCd(String swtchgClCd) {
		this.swtchgClCd = swtchgClCd;
	}
	public String getDodLineClCd() {
		return dodLineClCd;
	}
	public void setDodLineClCd(String dodLineClCd) {
		this.dodLineClCd = dodLineClCd;
	}
	public String getPubPhonTypCd() {
		return pubPhonTypCd;
	}
	public void setPubPhonTypCd(String pubPhonTypCd) {
		this.pubPhonTypCd = pubPhonTypCd;
	}
	public String getRentLineUseYn() {
		return rentLineUseYn;
	}
	public void setRentLineUseYn(String rentLineUseYn) {
		this.rentLineUseYn = rentLineUseYn;
	}
	public String getIocallClCd() {
		return iocallClCd;
	}
	public void setIocallClCd(String iocallClCd) {
		this.iocallClCd = iocallClCd;
	}
	public String getIocallStCd() {
		return iocallStCd;
	}
	public void setIocallStCd(String iocallStCd) {
		this.iocallStCd = iocallStCd;
	}
	public String getDidRepSvcNum() {
		return didRepSvcNum;
	}
	public void setDidRepSvcNum(String didRepSvcNum) {
		this.didRepSvcNum = didRepSvcNum;
	}
	public String getDodRepSvcNum() {
		return dodRepSvcNum;
	}
	public void setDodRepSvcNum(String dodRepSvcNum) {
		this.dodRepSvcNum = dodRepSvcNum;
	}
	public String getStrmPhonStaDt() {
		return strmPhonStaDt;
	}
	public void setStrmPhonStaDt(String strmPhonStaDt) {
		this.strmPhonStaDt = strmPhonStaDt;
	}
	public String getStrmPhonEndDt() {
		return strmPhonEndDt;
	}
	public void setStrmPhonEndDt(String strmPhonEndDt) {
		this.strmPhonEndDt = strmPhonEndDt;
	}
	public String getOthrCoSvcId() {
		return othrCoSvcId;
	}
	public void setOthrCoSvcId(String othrCoSvcId) {
		this.othrCoSvcId = othrCoSvcId;
	}
	public String getPrmsOutClCd() {
		return prmsOutClCd;
	}
	public void setPrmsOutClCd(String prmsOutClCd) {
		this.prmsOutClCd = prmsOutClCd;
	}
	public String getIntPhonWlbizrCd() {
		return intPhonWlbizrCd;
	}
	public void setIntPhonWlbizrCd(String intPhonWlbizrCd) {
		this.intPhonWlbizrCd = intPhonWlbizrCd;
	}
	public String getApAddYn() {
		return apAddYn;
	}
	public void setApAddYn(String apAddYn) {
		this.apAddYn = apAddYn;
	}
	public String getRcvDt() {
		return rcvDt;
	}
	public void setRcvDt(String rcvDt) {
		this.rcvDt = rcvDt;
	}
	public String getStrmRentStaDt() {
		return strmRentStaDt;
	}
	public void setStrmRentStaDt(String strmRentStaDt) {
		this.strmRentStaDt = strmRentStaDt;
	}
	public String getStrmRentEndDt() {
		return strmRentEndDt;
	}
	public void setStrmRentEndDt(String strmRentEndDt) {
		this.strmRentEndDt = strmRentEndDt;
	}
	public String getEqpMdlCd() {
		return eqpMdlCd;
	}
	public void setEqpMdlCd(String eqpMdlCd) {
		this.eqpMdlCd = eqpMdlCd;
	}
	public String getEqpSerNum() {
		return eqpSerNum;
	}
	public void setEqpSerNum(String eqpSerNum) {
		this.eqpSerNum = eqpSerNum;
	}
	public String getMassCoClCd() {
		return massCoClCd;
	}
	public void setMassCoClCd(String massCoClCd) {
		this.massCoClCd = massCoClCd;
	}
	public String getSvcTechMthdCd() {
		return svcTechMthdCd;
	}
	public void setSvcTechMthdCd(String svcTechMthdCd) {
		this.svcTechMthdCd = svcTechMthdCd;
	}
	public String getWphonDwtnBizrCd() {
		return wphonDwtnBizrCd;
	}
	public void setWphonDwtnBizrCd(String wphonDwtnBizrCd) {
		this.wphonDwtnBizrCd = wphonDwtnBizrCd;
	}
	public String getWphonPselSysBizrCd() {
		return wphonPselSysBizrCd;
	}
	public void setWphonPselSysBizrCd(String wphonPselSysBizrCd) {
		this.wphonPselSysBizrCd = wphonPselSysBizrCd;
	}
	public String getInofcSvcYn() {
		return inofcSvcYn;
	}
	public void setInofcSvcYn(String inofcSvcYn) {
		this.inofcSvcYn = inofcSvcYn;
	}
	public long getRangeSvcMgmtNum() {
		return rangeSvcMgmtNum;
	}
	public void setRangeSvcMgmtNum(long rangeSvcMgmtNum) {
		this.rangeSvcMgmtNum = rangeSvcMgmtNum;
	}
	@Override
	public void setKey() {
		this.key = "" + this.svcMgmtNum;
	}
	@Override
	public boolean equals(CopyVO obj) {
		OES10300 dest = (OES10300) obj;
		if (this.svcMgmtNum != dest.svcMgmtNum) return false;
		if (false == StringUtils.equals(this.apMacAddrVal, dest.apMacAddrVal)) return false;
		if (false == StringUtils.equals(this.swtchgClCd, dest.swtchgClCd)) return false;
		if (false == StringUtils.equals(this.dodLineClCd, dest.dodLineClCd)) return false;
		if (false == StringUtils.equals(this.pubPhonTypCd, dest.pubPhonTypCd)) return false;
		if (false == StringUtils.equals(this.rentLineUseYn, dest.rentLineUseYn)) return false;
		if (false == StringUtils.equals(this.iocallClCd, dest.iocallClCd)) return false;
		if (false == StringUtils.equals(this.iocallStCd, dest.iocallStCd)) return false;
		if (false == StringUtils.equals(this.didRepSvcNum, dest.didRepSvcNum)) return false;
		if (false == StringUtils.equals(this.dodRepSvcNum, dest.dodRepSvcNum)) return false;
		if (false == StringUtils.equals(this.strmPhonStaDt, dest.strmPhonStaDt)) return false;
		if (false == StringUtils.equals(this.strmPhonEndDt, dest.strmPhonEndDt)) return false;
		if (false == StringUtils.equals(this.othrCoSvcId, dest.othrCoSvcId)) return false;
		if (false == StringUtils.equals(this.prmsOutClCd, dest.prmsOutClCd)) return false;
		if (false == StringUtils.equals(this.intPhonWlbizrCd, dest.intPhonWlbizrCd)) return false;
		if (false == StringUtils.equals(this.apAddYn, dest.apAddYn)) return false;
		if (false == StringUtils.equals(this.rcvDt, dest.rcvDt)) return false;
		if (false == StringUtils.equals(this.strmRentStaDt, dest.strmRentStaDt)) return false;
		if (false == StringUtils.equals(this.strmRentEndDt, dest.strmRentEndDt)) return false;
		if (false == StringUtils.equals(this.eqpMdlCd, dest.eqpMdlCd)) return false;
		if (false == StringUtils.equals(this.eqpSerNum, dest.eqpSerNum)) return false;
		if (false == StringUtils.equals(this.massCoClCd, dest.massCoClCd)) return false;
		if (false == StringUtils.equals(this.svcTechMthdCd, dest.svcTechMthdCd)) return false;
		if (false == StringUtils.equals(this.wphonDwtnBizrCd, dest.wphonDwtnBizrCd)) return false;
		if (false == StringUtils.equals(this.wphonPselSysBizrCd, dest.wphonPselSysBizrCd)) return false;
		if (false == StringUtils.equals(this.inofcSvcYn, dest.inofcSvcYn)) return false;		
		return true;
	}
	@Override
	public void setRange(CopyVO obj) {
		OES10300 src = (OES10300) obj;
		this.rangeSvcMgmtNum = src.svcMgmtNum;
	}
}
