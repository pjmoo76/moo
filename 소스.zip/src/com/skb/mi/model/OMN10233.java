package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OMN10233 extends CopyVO {
	private	String	iptvThrsCd;
	private	String	auditId;
	private	String	auditDtm;
	private	String	iptvThrsCdNm;
	private	String	iptvThrsClCd;
	private	String	iptvThrsClCdNm;
	private	String	warngSetVal;
	private	String	crtgSetVal;
	private	String	dataIncreRt;
	private	String	dataMinVal;
	private	String	teamThrsVal;
	private	String	allThrsVal;
	private	String	dataUnitVal;

	private	String	rangeIptvThrsCd;

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("iptvThrsCd=%s\n", iptvThrsCd));
		sb.append(String.format("auditId=%s\n", auditId));
		sb.append(String.format("auditDtm=%s\n", auditDtm));
		sb.append(String.format("iptvThrsCdNm=%s\n", iptvThrsCdNm));
		sb.append(String.format("iptvThrsClCd=%s\n", iptvThrsClCd));
		sb.append(String.format("iptvThrsClCdNm=%s\n", iptvThrsClCdNm));
		sb.append(String.format("warngSetVal=%s\n", warngSetVal));
		sb.append(String.format("crtgSetVal=%s\n", crtgSetVal));
		sb.append(String.format("dataIncreRt=%s\n", dataIncreRt));
		sb.append(String.format("dataMinVal=%s\n", dataMinVal));
		sb.append(String.format("teamThrsVal=%s\n", teamThrsVal));
		sb.append(String.format("allThrsVal=%s\n", allThrsVal));
		sb.append(String.format("dataUnitVal=%s\n", dataUnitVal));
		return sb.toString();
	}

	public String getIptvThrsCd() {
		return iptvThrsCd;
	}
	public void setIptvThrsCd(String iptvThrsCd) {
		this.iptvThrsCd = iptvThrsCd;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getIptvThrsCdNm() {
		return iptvThrsCdNm;
	}
	public void setIptvThrsCdNm(String iptvThrsCdNm) {
		this.iptvThrsCdNm = iptvThrsCdNm;
	}
	public String getIptvThrsClCd() {
		return iptvThrsClCd;
	}
	public void setIptvThrsClCd(String iptvThrsClCd) {
		this.iptvThrsClCd = iptvThrsClCd;
	}
	public String getIptvThrsClCdNm() {
		return iptvThrsClCdNm;
	}
	public void setIptvThrsClCdNm(String iptvThrsClCdNm) {
		this.iptvThrsClCdNm = iptvThrsClCdNm;
	}
	public String getWarngSetVal() {
		return warngSetVal;
	}
	public void setWarngSetVal(String warngSetVal) {
		this.warngSetVal = warngSetVal;
	}
	public String getCrtgSetVal() {
		return crtgSetVal;
	}
	public void setCrtgSetVal(String crtgSetVal) {
		this.crtgSetVal = crtgSetVal;
	}
	public String getDataIncreRt() {
		return dataIncreRt;
	}
	public void setDataIncreRt(String dataIncreRt) {
		this.dataIncreRt = dataIncreRt;
	}
	public String getDataMinVal() {
		return dataMinVal;
	}
	public void setDataMinVal(String dataMinVal) {
		this.dataMinVal = dataMinVal;
	}
	public String getTeamThrsVal() {
		return teamThrsVal;
	}
	public void setTeamThrsVal(String teamThrsVal) {
		this.teamThrsVal = teamThrsVal;
	}
	public String getAllThrsVal() {
		return allThrsVal;
	}
	public void setAllThrsVal(String allThrsVal) {
		this.allThrsVal = allThrsVal;
	}
	public String getDataUnitVal() {
		return dataUnitVal;
	}
	public void setDataUnitVal(String dataUnitVal) {
		this.dataUnitVal = dataUnitVal;
	}
	public String getRangeIptvThrsCd() {
		return rangeIptvThrsCd;
	}
	public void setRangeIptvThrsCd(String rangeIptvThrsCd) {
		this.rangeIptvThrsCd = rangeIptvThrsCd;
	}

	@Override
	public void setKey() {
		this.key = this.iptvThrsCd;
	}

	@Override
	public boolean equals(CopyVO obj) {
		OMN10233 dest = (OMN10233) obj;
		if (false == StringUtils.equals(this.iptvThrsCdNm, dest.iptvThrsCdNm)) return false;
		if (false == StringUtils.equals(this.iptvThrsClCd, dest.iptvThrsClCd)) return false;
		if (false == StringUtils.equals(this.iptvThrsClCdNm, dest.iptvThrsClCdNm)) return false;
		if (false == StringUtils.equals(this.warngSetVal, dest.warngSetVal)) return false;
		if (false == StringUtils.equals(this.crtgSetVal, dest.crtgSetVal)) return false;
		if (false == StringUtils.equals(this.dataIncreRt, dest.dataIncreRt)) return false;
		if (false == StringUtils.equals(this.dataMinVal, dest.dataMinVal)) return false;
		if (false == StringUtils.equals(this.teamThrsVal, dest.teamThrsVal)) return false;
		if (false == StringUtils.equals(this.allThrsVal, dest.allThrsVal)) return false;
		if (false == StringUtils.equals(this.dataUnitVal, dest.dataUnitVal)) return false;
		return true;
	}

	@Override
	public void setRange(CopyVO obj) {
		OMN10233 src = (OMN10233) obj;
		this.rangeIptvThrsCd = src.iptvThrsCd;
	}

}
