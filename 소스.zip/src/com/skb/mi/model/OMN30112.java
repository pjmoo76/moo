package com.skb.mi.model;

public class OMN30112 {
	private Integer dablNum;
    private String auditId;
    private String auditDtm;
    private Long cmStbCnt;
    private Long totLineCnt;
    private Long inetLineCnt;
    private Long qamLineCnt;
    private Long vsb8LineCnt;
    private Long totDmgLineCnt;
    private Long inetDmgLineCnt;
    private Long qamDmgLineCnt;
    private Long vsb8DmgLineCnt;
    private String totVocCnt;
    private Long totCustCnt;
    private Long inetCustCnt;
    private Long qamCustCnt;
    private Long vsb8CustCnt;
    private Long totDmgCustCnt;
    private Long inetDmgCustCnt;
    private Long qamDmgCustCnt;
    private Long vsb8DmgCustCnt;
    private String tbSoNm;
    private String cellMemo;
    private String nmsDablNumCtt;
    private String dablCd;
    private String dablStCd;
    private String dablGrCd;
    private String occrDtm;
    private String occrRcvDtm;
    private String rlseDtm;
    private String rlseRcvDtm;
    private String equipId;
    private String ccellNum;
    private String scardNumCtt;
    private String portNum;

    public Integer getDablNum() { return dablNum; }
    public void setDablNum(Integer dablNum) { this.dablNum = dablNum; }

    public String getAuditId() { return auditId; }
    public void setAuditId(String auditId) { this.auditId = auditId; }

    public String getAuditDtm() { return auditDtm; }
    public void setAuditDtm(String auditDtm) { this.auditDtm = auditDtm; }

    public Long getCmStbCnt() { return cmStbCnt; }
    public void setCmStbCnt(Long cmStbCnt) { this.cmStbCnt = cmStbCnt; }

    public Long getTotLineCnt() { return totLineCnt; }
    public void setTotLineCnt(Long totLineCnt) { this.totLineCnt = totLineCnt; }

    public Long getInetLineCnt() { return inetLineCnt; }
    public void setInetLineCnt(Long inetLineCnt) { this.inetLineCnt = inetLineCnt; }

    public Long getQamLineCnt() { return qamLineCnt; }
    public void setQamLineCnt(Long qamLineCnt) { this.qamLineCnt = qamLineCnt; }

    public Long getVsb8LineCnt() { return vsb8LineCnt; }
    public void setVsb8LineCnt(Long vsb8LineCnt) { this.vsb8LineCnt = vsb8LineCnt; }

    public Long getTotDmgLineCnt() { return totDmgLineCnt; }
    public void setTotDmgLineCnt(Long totDmgLineCnt) { this.totDmgLineCnt = totDmgLineCnt; }

    public Long getInetDmgLineCnt() { return inetDmgLineCnt; }
    public void setInetDmgLineCnt(Long inetDmgLineCnt) { this.inetDmgLineCnt = inetDmgLineCnt; }

    public Long getQamDmgLineCnt() { return qamDmgLineCnt; }
    public void setQamDmgLineCnt(Long qamDmgLineCnt) { this.qamDmgLineCnt = qamDmgLineCnt; }

    public Long getVsb8DmgLineCnt() { return vsb8DmgLineCnt; }
    public void setVsb8DmgLineCnt(Long vsb8DmgLineCnt) { this.vsb8DmgLineCnt = vsb8DmgLineCnt; }

    public String getTotVocCnt() { return totVocCnt; }
    public void setTotVocCnt(String totVocCnt) { this.totVocCnt = totVocCnt; }

    public Long getTotCustCnt() { return totCustCnt; }
    public void setTotCustCnt(Long totCustCnt) { this.totCustCnt = totCustCnt; }

    public Long getInetCustCnt() { return inetCustCnt; }
    public void setInetCustCnt(Long inetCustCnt) { this.inetCustCnt = inetCustCnt; }

    public Long getQamCustCnt() { return qamCustCnt; }
    public void setQamCustCnt(Long qamCustCnt) { this.qamCustCnt = qamCustCnt; }

    public Long getVsb8CustCnt() { return vsb8CustCnt; }
    public void setVsb8CustCnt(Long vsb8CustCnt) { this.vsb8CustCnt = vsb8CustCnt; }

    public Long getTotDmgCustCnt() { return totDmgCustCnt; }
    public void setTotDmgCustCnt(Long totDmgCustCnt) { this.totDmgCustCnt = totDmgCustCnt; }

    public Long getInetDmgCustCnt() { return inetDmgCustCnt; }
    public void setInetDmgCustCnt(Long inetDmgCustCnt) { this.inetDmgCustCnt = inetDmgCustCnt; }

    public Long getQamDmgCustCnt() { return qamDmgCustCnt; }
    public void setQamDmgCustCnt(Long qamDmgCustCnt) { this.qamDmgCustCnt = qamDmgCustCnt; }

    public Long getVsb8DmgCustCnt() { return vsb8DmgCustCnt; }
    public void setVsb8DmgCustCnt(Long vsb8DmgCustCnt) { this.vsb8DmgCustCnt = vsb8DmgCustCnt; }

    public String getTbSoNm() { return tbSoNm; }
    public void setTbSoNm(String tbSoNm) { this.tbSoNm = tbSoNm; }

    public String getCellMemo() { return cellMemo; }
    public void setCellMemo(String cellMemo) { this.cellMemo = cellMemo; }

    public String getNmsDablNumCtt() { return nmsDablNumCtt; }
    public void setNmsDablNumCtt(String nmsDablNumCtt) { this.nmsDablNumCtt = nmsDablNumCtt; }

    public String getDablCd() { return dablCd; }
    public void setDablCd(String dablCd) { this.dablCd = dablCd; }

    public String getDablStCd() { return dablStCd; }
    public void setDablStCd(String dablStCd) { this.dablStCd = dablStCd; }

    public String getDablGrCd() { return dablGrCd; }
    public void setDablGrCd(String dablGrCd) { this.dablGrCd = dablGrCd; }

    public String getOccrDtm() { return occrDtm; }
    public void setOccrDtm(String occrDtm) { this.occrDtm = occrDtm; }

    public String getOccrRcvDtm() { return occrRcvDtm; }
    public void setOccrRcvDtm(String occrRcvDtm) { this.occrRcvDtm = occrRcvDtm; }

    public String getRlseDtm() { return rlseDtm; }
    public void setRlseDtm(String rlseDtm) { this.rlseDtm = rlseDtm; }

    public String getRlseRcvDtm() { return rlseRcvDtm; }
    public void setRlseRcvDtm(String rlseRcvDtm) { this.rlseRcvDtm = rlseRcvDtm; }

    public String getEquipId() { return equipId; }
    public void setEquipId(String equipId) { this.equipId = equipId; }

    public String getCcellNum() { return ccellNum; }
    public void setCcellNum(String ccellNum) { this.ccellNum = ccellNum; }

    public String getScardNumCtt() { return scardNumCtt; }
    public void setScardNumCtt(String scardNumCtt) { this.scardNumCtt = scardNumCtt; }

    public String getPortNum() { return portNum; }
    public void setPortNum(String portNum) { this.portNum = portNum; }
}
