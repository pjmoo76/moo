package com.skb.mi.model;

import java.util.ArrayList;

public class ONM10100 {
	private	String	netOpNum;
	private	String	auditId;
	private	String	auditDtm;
	private	String	netOpTypCd;
	private	String	dablOperClCd;
	private	String	operInfluAreaDesc;
	private	String	netOpStCd;
	private	String	netClCd;
	private	String	operStaDtm;
	private	String	exptOperFnshDtm;
	private	String	operFnshDtm;
	private	String	operRsnCtt;
	private	String	operCtt;
	private	String	svcInfluYn;
	private	String	svcInfluTypCd;
	private	int		vocCnt;
	private	String	bfNetOpNum;
	private	String	opertrId;
	private	String	opertrNm;
	private	String	opertrPhonNum;
	private	String	operOpTypCd;
	private	String	operActCtt;
	private	String	fwupActNeedCtt;
	private	String	rgstDtm;
	private	String	rgstrId;
	private	String	rgstrNm;
	private	String	rgstrPostCtt;
	private	String	rgstrPhonNum;
	private	String	tpoCd;
	private	String	nmsCd;
	private	String	netOpDablTypCd;
	private	String	almSetItmCtt;
	private	String	almRsnDtlCtt;
	private	String	netOpSvcTypCd;
	private	String	ifClCd;
	private	String	opOperFnshDtm;
	private	String	dablSrcCd;
	private	String	dablConsItmCtt;
	private	String	dablDtlSrcCtt;
	private	String	opRgstDtm;
	private	String	opRgstrId;
	private	String	opRgstrNm;
	private	String	opRgstrTeamOrgNm;
	private	String	opRgstrPhonNum;
	private	String	emailSndYn;
	private	String	swingLnkgYn;
	private	ArrayList<ONM10112>	dtlList;
	
	public ArrayList<ONM10112> getDtlList() {
		return dtlList;
	}
	public void setDtlList(ArrayList<ONM10112> dtlList) {
		this.dtlList = dtlList;
	}
	public String getNetOpNum() {
		return netOpNum;
	}
	public void setNetOpNum(String netOpNum) {
		this.netOpNum = netOpNum;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getNetOpTypCd() {
		return netOpTypCd;
	}
	public void setNetOpTypCd(String netOpTypCd) {
		this.netOpTypCd = netOpTypCd;
	}
	public String getDablOperClCd() {
		return dablOperClCd;
	}
	public void setDablOperClCd(String dablOperClCd) {
		this.dablOperClCd = dablOperClCd;
	}
	public String getOperInfluAreaDesc() {
		return operInfluAreaDesc;
	}
	public void setOperInfluAreaDesc(String operInfluAreaDesc) {
		this.operInfluAreaDesc = operInfluAreaDesc;
	}
	public String getNetOpStCd() {
		return netOpStCd;
	}
	public void setNetOpStCd(String netOpStCd) {
		this.netOpStCd = netOpStCd;
	}
	public String getNetClCd() {
		return netClCd;
	}
	public void setNetClCd(String netClCd) {
		this.netClCd = netClCd;
	}
	public String getOperStaDtm() {
		return operStaDtm;
	}
	public void setOperStaDtm(String operStaDtm) {
		this.operStaDtm = operStaDtm;
	}
	public String getExptOperFnshDtm() {
		return exptOperFnshDtm;
	}
	public void setExptOperFnshDtm(String exptOperFnshDtm) {
		this.exptOperFnshDtm = exptOperFnshDtm;
	}
	public String getOperFnshDtm() {
		return operFnshDtm;
	}
	public void setOperFnshDtm(String operFnshDtm) {
		this.operFnshDtm = operFnshDtm;
	}
	public String getOperRsnCtt() {
		return operRsnCtt;
	}
	public void setOperRsnCtt(String operRsnCtt) {
		this.operRsnCtt = operRsnCtt;
	}
	public String getOperCtt() {
		return operCtt;
	}
	public void setOperCtt(String operCtt) {
		this.operCtt = operCtt;
	}
	public String getSvcInfluYn() {
		return svcInfluYn;
	}
	public void setSvcInfluYn(String svcInfluYn) {
		this.svcInfluYn = svcInfluYn;
	}
	public String getSvcInfluTypCd() {
		return svcInfluTypCd;
	}
	public void setSvcInfluTypCd(String svcInfluTypCd) {
		this.svcInfluTypCd = svcInfluTypCd;
	}
	public int getVocCnt() {
		return vocCnt;
	}
	public void setVocCnt(int vocCnt) {
		this.vocCnt = vocCnt;
	}
	public String getBfNetOpNum() {
		return bfNetOpNum;
	}
	public void setBfNetOpNum(String bfNetOpNum) {
		this.bfNetOpNum = bfNetOpNum;
	}
	public String getOpertrId() {
		return opertrId;
	}
	public void setOpertrId(String opertrId) {
		this.opertrId = opertrId;
	}
	public String getOpertrNm() {
		return opertrNm;
	}
	public void setOpertrNm(String opertrNm) {
		this.opertrNm = opertrNm;
	}
	public String getOpertrPhonNum() {
		return opertrPhonNum;
	}
	public void setOpertrPhonNum(String opertrPhonNum) {
		this.opertrPhonNum = opertrPhonNum;
	}
	public String getOperOpTypCd() {
		return operOpTypCd;
	}
	public void setOperOpTypCd(String operOpTypCd) {
		this.operOpTypCd = operOpTypCd;
	}
	public String getOperActCtt() {
		return operActCtt;
	}
	public void setOperActCtt(String operActCtt) {
		this.operActCtt = operActCtt;
	}
	public String getFwupActNeedCtt() {
		return fwupActNeedCtt;
	}
	public void setFwupActNeedCtt(String fwupActNeedCtt) {
		this.fwupActNeedCtt = fwupActNeedCtt;
	}
	public String getRgstDtm() {
		return rgstDtm;
	}
	public void setRgstDtm(String rgstDtm) {
		this.rgstDtm = rgstDtm;
	}
	public String getRgstrId() {
		return rgstrId;
	}
	public void setRgstrId(String rgstrId) {
		this.rgstrId = rgstrId;
	}
	public String getRgstrNm() {
		return rgstrNm;
	}
	public void setRgstrNm(String rgstrNm) {
		this.rgstrNm = rgstrNm;
	}
	public String getRgstrPostCtt() {
		return rgstrPostCtt;
	}
	public void setRgstrPostCtt(String rgstrPostCtt) {
		this.rgstrPostCtt = rgstrPostCtt;
	}
	public String getRgstrPhonNum() {
		return rgstrPhonNum;
	}
	public void setRgstrPhonNum(String rgstrPhonNum) {
		this.rgstrPhonNum = rgstrPhonNum;
	}
	public String getTpoCd() {
		return tpoCd;
	}
	public void setTpoCd(String tpoCd) {
		this.tpoCd = tpoCd;
	}
	public String getNmsCd() {
		return nmsCd;
	}
	public void setNmsCd(String nmsCd) {
		this.nmsCd = nmsCd;
	}
	public String getNetOpDablTypCd() {
		return netOpDablTypCd;
	}
	public void setNetOpDablTypCd(String netOpDablTypCd) {
		this.netOpDablTypCd = netOpDablTypCd;
	}
	public String getAlmSetItmCtt() {
		return almSetItmCtt;
	}
	public void setAlmSetItmCtt(String almSetItmCtt) {
		this.almSetItmCtt = almSetItmCtt;
	}
	public String getAlmRsnDtlCtt() {
		return almRsnDtlCtt;
	}
	public void setAlmRsnDtlCtt(String almRsnDtlCtt) {
		this.almRsnDtlCtt = almRsnDtlCtt;
	}
	public String getNetOpSvcTypCd() {
		return netOpSvcTypCd;
	}
	public void setNetOpSvcTypCd(String netOpSvcTypCd) {
		this.netOpSvcTypCd = netOpSvcTypCd;
	}
	public String getIfClCd() {
		return ifClCd;
	}
	public void setIfClCd(String ifClCd) {
		this.ifClCd = ifClCd;
	}
	public String getOpOperFnshDtm() {
		return opOperFnshDtm;
	}
	public void setOpOperFnshDtm(String opOperFnshDtm) {
		this.opOperFnshDtm = opOperFnshDtm;
	}
	public String getDablSrcCd() {
		return dablSrcCd;
	}
	public void setDablSrcCd(String dablSrcCd) {
		this.dablSrcCd = dablSrcCd;
	}
	public String getDablConsItmCtt() {
		return dablConsItmCtt;
	}
	public void setDablConsItmCtt(String dablConsItmCtt) {
		this.dablConsItmCtt = dablConsItmCtt;
	}
	public String getDablDtlSrcCtt() {
		return dablDtlSrcCtt;
	}
	public void setDablDtlSrcCtt(String dablDtlSrcCtt) {
		this.dablDtlSrcCtt = dablDtlSrcCtt;
	}
	public String getOpRgstDtm() {
		return opRgstDtm;
	}
	public void setOpRgstDtm(String opRgstDtm) {
		this.opRgstDtm = opRgstDtm;
	}
	public String getOpRgstrId() {
		return opRgstrId;
	}
	public void setOpRgstrId(String opRgstrId) {
		this.opRgstrId = opRgstrId;
	}
	public String getOpRgstrNm() {
		return opRgstrNm;
	}
	public void setOpRgstrNm(String opRgstrNm) {
		this.opRgstrNm = opRgstrNm;
	}
	public String getOpRgstrTeamOrgNm() {
		return opRgstrTeamOrgNm;
	}
	public void setOpRgstrTeamOrgNm(String opRgstrTeamOrgNm) {
		this.opRgstrTeamOrgNm = opRgstrTeamOrgNm;
	}
	public String getOpRgstrPhonNum() {
		return opRgstrPhonNum;
	}
	public void setOpRgstrPhonNum(String opRgstrPhonNum) {
		this.opRgstrPhonNum = opRgstrPhonNum;
	}
	public String getEmailSndYn() {
		return emailSndYn;
	}
	public void setEmailSndYn(String emailSndYn) {
		this.emailSndYn = emailSndYn;
	}
	public String getSwingLnkgYn() {
		return swingLnkgYn;
	}
	public void setSwingLnkgYn(String swingLnkgYn) {
		this.swingLnkgYn = swingLnkgYn;
	}

	public String getMqDebugString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("[01] NMS_CD : %s\n", this.nmsCd));
		sb.append(String.format("[02] NET_OP_NUM : %s\n", this.netOpNum));
		sb.append(String.format("[03] DABL_OPER_CL_CD : %s\n", this.dablOperClCd));
		sb.append(String.format("[04] IF_CL_CD : %s\n", this.ifClCd));
		sb.append(String.format("[05] NET_OP_ST_CD : %s\n", this.netOpStCd));
		sb.append(String.format("[06] NET_CL_CD : %s\n", this.netClCd));
		sb.append(String.format("[07] OPER_STA_DTM : %s\n", this.operStaDtm));
		sb.append(String.format("[08] EXPT_OPER_FNSH_DTM : %s\n", this.exptOperFnshDtm));
		sb.append(String.format("[09] SVC_INFLU_TYP_CD : %s\n", this.svcInfluTypCd));
		sb.append(String.format("[10] SVC_INFLU_YN : %s\n", this.svcInfluYn));
		sb.append(String.format("[11] NET_OP_TYP_CD : %s\n", this.netOpTypCd));
		sb.append(String.format("[12] OPER_INFLU_AREA_DESC : %s\n", this.operInfluAreaDesc));
		sb.append(String.format("[13] OPER_RSN_CTT : %s\n", this.operRsnCtt));
		sb.append(String.format("[14] RGST_DTM : %s\n", this.rgstDtm));
		sb.append(String.format("[15] RGSTR_ID : %s\n", this.rgstrId));
		sb.append(String.format("[16] RGSTR_NM : %s\n", this.rgstrNm));
		sb.append(String.format("[17] RGSTR_POST_CTT : %s\n", this.rgstrPostCtt));
		sb.append(String.format("[18] RGSTR_PHON_NUM : %s\n", this.rgstrPhonNum));
		sb.append(String.format("[19] OPER_FNSH_DTM : %s\n", this.operFnshDtm));
		sb.append(String.format("[20] VOC_CNT : %d\n", this.vocCnt));
		sb.append(String.format("[21] OP_RGSTR_ID : %s\n", this.opRgstrId));
		sb.append(String.format("[22] OP_RGSTR_NM : %s\n", this.opRgstrNm));
		sb.append(String.format("[23] OP_RGSTR_PHON_NUM : %s\n", this.opRgstrPhonNum));
		sb.append(String.format("[24] NET_DABL_OPER_ACT_TYP_CD : %s\n", this.operOpTypCd));
		sb.append(String.format("[25] OPER_ACT_CTT : %s\n", this.operActCtt));
		sb.append(String.format("[26] FWUP_ACT_NEED_CTT : %s\n", this.fwupActNeedCtt));
		sb.append(String.format("[27] DABL_SRC_CD : %s\n", this.dablSrcCd));
		sb.append(String.format("[28] DABL_CONS_ITM_CTT : %s\n", this.dablConsItmCtt));
		sb.append(String.format("[29] DABL_DTL_SRC_CTT : %s", this.dablDtlSrcCtt));
		return sb.toString();
	}
}
