package com.skb.mi.model;

public class OCO40301 {
	private	String	cldrYr;
	private	String	yrWkNum;
	private	String	auditId;
	private	String	auditDtm;
	private	String	wkStaDt;
	private	String	wkEndDt;
	private	String	yrWkNm;

	public String getCldrYr() {
		return cldrYr;
	}
	public void setCldrYr(String cldrYr) {
		this.cldrYr = cldrYr;
	}
	public String getYrWkNum() {
		return yrWkNum;
	}
	public void setYrWkNum(String yrWkNum) {
		this.yrWkNum = yrWkNum;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getWkStaDt() {
		return wkStaDt;
	}
	public void setWkStaDt(String wkStaDt) {
		this.wkStaDt = wkStaDt;
	}
	public String getWkEndDt() {
		return wkEndDt;
	}
	public void setWkEndDt(String wkEndDt) {
		this.wkEndDt = wkEndDt;
	}
	public String getYrWkNm() {
		return yrWkNm;
	}
	public void setYrWkNm(String yrWkNm) {
		this.yrWkNm = yrWkNm;
	}
}
