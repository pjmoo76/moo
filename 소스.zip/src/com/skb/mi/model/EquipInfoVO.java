package com.skb.mi.model;

public class EquipInfoVO {
	private	String	equipId;
	private	String	equipMgmtNum;
	private	String	equipMdlCd;
	private	String	equipMdlNm;
	private	String	equipUsgCd;

	public String getEquipId() {
		return equipId;
	}
	public void setEquipId(String equipId) {
		this.equipId = equipId;
	}
	public String getEquipMgmtNum() {
		return equipMgmtNum;
	}
	public void setEquipMgmtNum(String equipMgmtNum) {
		this.equipMgmtNum = equipMgmtNum;
	}
	public String getEquipMdlCd() {
		return equipMdlCd;
	}
	public void setEquipMdlCd(String equipMdlCd) {
		this.equipMdlCd = equipMdlCd;
	}
	public String getEquipMdlNm() {
		return equipMdlNm;
	}
	public void setEquipMdlNm(String equipMdlNm) {
		this.equipMdlNm = equipMdlNm;
	}
	public String getEquipUsgCd() {
		return equipUsgCd;
	}
	public void setEquipUsgCd(String equipUsgCd) {
		this.equipUsgCd = equipUsgCd;
	}
}
