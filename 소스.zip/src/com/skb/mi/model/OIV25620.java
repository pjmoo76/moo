package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV25620 extends CopyVO {
	private	String	ivmsChnlSvrMappId;
	private	String	auditId;
	private	String	auditDtm;
	private	String	svrIpAddr;
	private	String	chnlNm;

	private	String	rangeIvmsChnlSvrMappId;

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("ivmsChnlSvrMappId=%s\n", ivmsChnlSvrMappId));
		sb.append(String.format("auditId=%s\n", auditId));
		sb.append(String.format("auditDtm=%s\n", auditDtm));
		sb.append(String.format("svrIpAddr=%s\n", svrIpAddr));
		sb.append(String.format("chnlNm=%s\n", chnlNm));
		return sb.toString();
	}

	public String getIvmsChnlSvrMappId() {
		return ivmsChnlSvrMappId;
	}
	public void setIvmsChnlSvrMappId(String ivmsChnlSvrMappId) {
		this.ivmsChnlSvrMappId = ivmsChnlSvrMappId;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getSvrIpAddr() {
		return svrIpAddr;
	}
	public void setSvrIpAddr(String svrIpAddr) {
		this.svrIpAddr = svrIpAddr;
	}
	public String getChnlNm() {
		return chnlNm;
	}
	public void setChnlNm(String chnlNm) {
		this.chnlNm = chnlNm;
	}

	public String getRangeIvmsChnlSvrMappId() {
		return rangeIvmsChnlSvrMappId;
	}
	public void setRangeIvmsChnlSvrMappId(String rangeIvmsChnlSvrMappId) {
		this.rangeIvmsChnlSvrMappId = rangeIvmsChnlSvrMappId;
	}

	@Override
	public void setKey() {
		this.key = this.ivmsChnlSvrMappId;
	}

	@Override
	public boolean equals(CopyVO obj) {
		OIV25620 dest = (OIV25620) obj;
		if (false == StringUtils.equals(this.svrIpAddr, dest.svrIpAddr)) return false;
		if (false == StringUtils.equals(this.chnlNm, dest.chnlNm)) return false;
		return true;
	}

	@Override
	public void setRange(CopyVO obj) {
		OIV25620 src = (OIV25620) obj;
		this.rangeIvmsChnlSvrMappId = src.ivmsChnlSvrMappId;
	}
}
