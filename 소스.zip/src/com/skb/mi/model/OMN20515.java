package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OMN20515 extends CopyVO {
	private	String	vipCustSerNum;
	private	String	auditId;
	private	String	auditDtm;
	private	String	macAddrVal;
	private	String	netClCd;
	private	String	infoCntrCd;
	private	String	distbCntrCd;
	private	String	l2EquipId;
	private	String	l3EquipId;
	private	String	custNum;
	private	String	iptvSvcNum;
	private	String	iptvSvcMgmtNum;
	private	String	inetSvcNum;
	private	String	inetSvcMgmtNum;
	private	String	custRmk;
	private	String	vipCustStCd;
	private	String	mgmtChrgrId;
	private	String	rangeVipCustSerNum;
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("vipCustSerNum=%s\n", vipCustSerNum));
		sb.append(String.format("auditId=%s\n", auditId));
		sb.append(String.format("macAddrVal=%s\n", macAddrVal));
		sb.append(String.format("netClCd=%s\n", netClCd));
		sb.append(String.format("infoCntrCd=%s\n", infoCntrCd));
		sb.append(String.format("distbCntrCd=%s\n", distbCntrCd));
		sb.append(String.format("l2EquipId=%s\n", l2EquipId));
		sb.append(String.format("l3EquipId=%s\n", l3EquipId));
		sb.append(String.format("custNum=%s\n", custNum));
		sb.append(String.format("iptvSvcNum=%s\n", iptvSvcNum));
		sb.append(String.format("iptvSvcMgmtNum=%s\n", iptvSvcMgmtNum));
		sb.append(String.format("inetSvcNum=%s\n", inetSvcNum));
		sb.append(String.format("inetSvcMgmtNum=%s\n", inetSvcMgmtNum));
		sb.append(String.format("custRmk=%s\n", custRmk));
		sb.append(String.format("vipCustStCd=%s\n", vipCustStCd));
		sb.append(String.format("mgmtChrgrId=%s\n", mgmtChrgrId));
		return sb.toString();
	}

	public String getVipCustSerNum() {
		return vipCustSerNum;
	}
	public void setVipCustSerNum(String vipCustSerNum) {
		this.vipCustSerNum = vipCustSerNum;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getMacAddrVal() {
		return macAddrVal;
	}
	public void setMacAddrVal(String macAddrVal) {
		this.macAddrVal = macAddrVal;
	}
	public String getNetClCd() {
		return netClCd;
	}
	public void setNetClCd(String netClCd) {
		this.netClCd = netClCd;
	}
	public String getInfoCntrCd() {
		return infoCntrCd;
	}
	public void setInfoCntrCd(String infoCntrCd) {
		this.infoCntrCd = infoCntrCd;
	}
	public String getDistbCntrCd() {
		return distbCntrCd;
	}
	public void setDistbCntrCd(String distbCntrCd) {
		this.distbCntrCd = distbCntrCd;
	}
	public String getL2EquipId() {
		return l2EquipId;
	}
	public void setL2EquipId(String l2EquipId) {
		this.l2EquipId = l2EquipId;
	}
	public String getL3EquipId() {
		return l3EquipId;
	}
	public void setL3EquipId(String l3EquipId) {
		this.l3EquipId = l3EquipId;
	}
	public String getCustNum() {
		return custNum;
	}
	public void setCustNum(String custNum) {
		this.custNum = custNum;
	}
	public String getIptvSvcNum() {
		return iptvSvcNum;
	}
	public void setIptvSvcNum(String iptvSvcNum) {
		this.iptvSvcNum = iptvSvcNum;
	}
	public String getIptvSvcMgmtNum() {
		return iptvSvcMgmtNum;
	}
	public void setIptvSvcMgmtNum(String iptvSvcMgmtNum) {
		this.iptvSvcMgmtNum = iptvSvcMgmtNum;
	}
	public String getInetSvcNum() {
		return inetSvcNum;
	}
	public void setInetSvcNum(String inetSvcNum) {
		this.inetSvcNum = inetSvcNum;
	}
	public String getInetSvcMgmtNum() {
		return inetSvcMgmtNum;
	}
	public void setInetSvcMgmtNum(String inetSvcMgmtNum) {
		this.inetSvcMgmtNum = inetSvcMgmtNum;
	}
	public String getCustRmk() {
		return custRmk;
	}
	public void setCustRmk(String custRmk) {
		this.custRmk = custRmk;
	}
	public String getVipCustStCd() {
		return vipCustStCd;
	}
	public void setVipCustStCd(String vipCustStCd) {
		this.vipCustStCd = vipCustStCd;
	}
	public String getMgmtChrgrId() {
		return mgmtChrgrId;
	}
	public void setMgmtChrgrId(String mgmtChrgrId) {
		this.mgmtChrgrId = mgmtChrgrId;
	}
	public String getRangeVipCustSerNum() {
		return rangeVipCustSerNum;
	}
	public void setRangeVipCustSerNum(String rangeVipCustSerNum) {
		this.rangeVipCustSerNum = rangeVipCustSerNum;
	}

	@Override
	public void setKey() {
		this.key = this.vipCustSerNum;
	}

	@Override
	public boolean equals(CopyVO obj) {
		OMN20515 dest = (OMN20515) obj;
		if (false == StringUtils.equals(this.macAddrVal, dest.macAddrVal)) return false;
		if (false == StringUtils.equals(this.netClCd, dest.netClCd)) return false;
		if (false == StringUtils.equals(this.infoCntrCd, dest.infoCntrCd)) return false;
		if (false == StringUtils.equals(this.distbCntrCd, dest.distbCntrCd)) return false;
		if (false == StringUtils.equals(this.l2EquipId, dest.l2EquipId)) return false;
		if (false == StringUtils.equals(this.l3EquipId, dest.l3EquipId)) return false;
		if (false == StringUtils.equals(this.custNum, dest.custNum)) return false;
		if (false == StringUtils.equals(this.iptvSvcNum, dest.iptvSvcNum)) return false;
		if (false == StringUtils.equals(this.iptvSvcMgmtNum, dest.iptvSvcMgmtNum)) return false;
		if (false == StringUtils.equals(this.inetSvcNum, dest.inetSvcNum)) return false;
		if (false == StringUtils.equals(this.inetSvcMgmtNum, dest.inetSvcMgmtNum)) return false;
		if (false == StringUtils.equals(this.custRmk, dest.custRmk)) return false;
		if (false == StringUtils.equals(this.vipCustStCd, dest.vipCustStCd)) return false;
		if (false == StringUtils.equals(this.mgmtChrgrId, dest.mgmtChrgrId)) return false;
		return true;
	}

	@Override
	public void setRange(CopyVO obj) {
		OMN20515 src = (OMN20515) obj;
		this.rangeVipCustSerNum = src.vipCustSerNum;
	}

}
