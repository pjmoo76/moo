package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OES10100 extends CopyVO {
	private	long	custNum;
	private	String	auditId;
	private	String	auditDtm;
	private	String	custNm;
	private	String	custStCd;
	private	String	custClCd;
	private	String	custTypCd;
	private	String	mgmtAreaCd;
	private	String	zip;
	private	String	houseNumClCd;
	private	String	mainHouseNumCtt;
	private	String	subHouseNumCtt;
	private	String	bldClCd;
	private	String	bldCd;
	private	int	bldblkNum;
	private	int	blduntNum;
	private	String	basAddr;
	private	String	assistAddr;
	private	String	ldongCd;
	private	String	phonNum;
	private	String	inlineNum;
	private	String	faxNum;
	private	String	mblPhonNum;
	private	String	fstRgstDtm;
	private	String	effStaDtm;
	private	String	offcPhonNum;
	private	String	emailAddr;
	private	String	spclCustYn;
	private	String	custChrticCd;
	private	long	rangeCustNum;
	
	public long getCustNum() {
		return custNum;
	}
	public void setCustNum(long custNum) {
		this.custNum = custNum;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getCustNm() {
		return custNm;
	}
	public void setCustNm(String custNm) {
		this.custNm = custNm;
	}
	public String getCustStCd() {
		return custStCd;
	}
	public void setCustStCd(String custStCd) {
		this.custStCd = custStCd;
	}
	public String getCustClCd() {
		return custClCd;
	}
	public void setCustClCd(String custClCd) {
		this.custClCd = custClCd;
	}
	public String getCustTypCd() {
		return custTypCd;
	}
	public void setCustTypCd(String custTypCd) {
		this.custTypCd = custTypCd;
	}
	public String getMgmtAreaCd() {
		return mgmtAreaCd;
	}
	public void setMgmtAreaCd(String mgmtAreaCd) {
		this.mgmtAreaCd = mgmtAreaCd;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getHouseNumClCd() {
		return houseNumClCd;
	}
	public void setHouseNumClCd(String houseNumClCd) {
		this.houseNumClCd = houseNumClCd;
	}
	public String getMainHouseNumCtt() {
		return mainHouseNumCtt;
	}
	public void setMainHouseNumCtt(String mainHouseNumCtt) {
		this.mainHouseNumCtt = mainHouseNumCtt;
	}
	public String getSubHouseNumCtt() {
		return subHouseNumCtt;
	}
	public void setSubHouseNumCtt(String subHouseNumCtt) {
		this.subHouseNumCtt = subHouseNumCtt;
	}
	public String getBldClCd() {
		return bldClCd;
	}
	public void setBldClCd(String bldClCd) {
		this.bldClCd = bldClCd;
	}
	public String getBldCd() {
		return bldCd;
	}
	public void setBldCd(String bldCd) {
		this.bldCd = bldCd;
	}
	public int getBldblkNum() {
		return bldblkNum;
	}
	public void setBldblkNum(int bldblkNum) {
		this.bldblkNum = bldblkNum;
	}
	public int getBlduntNum() {
		return blduntNum;
	}
	public void setBlduntNum(int blduntNum) {
		this.blduntNum = blduntNum;
	}
	public String getBasAddr() {
		return basAddr;
	}
	public void setBasAddr(String basAddr) {
		this.basAddr = basAddr;
	}
	public String getAssistAddr() {
		return assistAddr;
	}
	public void setAssistAddr(String assistAddr) {
		this.assistAddr = assistAddr;
	}
	public String getLdongCd() {
		return ldongCd;
	}
	public void setLdongCd(String ldongCd) {
		this.ldongCd = ldongCd;
	}
	public String getPhonNum() {
		return phonNum;
	}
	public void setPhonNum(String phonNum) {
		this.phonNum = phonNum;
	}
	public String getInlineNum() {
		return inlineNum;
	}
	public void setInlineNum(String inlineNum) {
		this.inlineNum = inlineNum;
	}
	public String getFaxNum() {
		return faxNum;
	}
	public void setFaxNum(String faxNum) {
		this.faxNum = faxNum;
	}
	public String getMblPhonNum() {
		return mblPhonNum;
	}
	public void setMblPhonNum(String mblPhonNum) {
		this.mblPhonNum = mblPhonNum;
	}
	public String getFstRgstDtm() {
		return fstRgstDtm;
	}
	public void setFstRgstDtm(String fstRgstDtm) {
		this.fstRgstDtm = fstRgstDtm;
	}
	public String getEffStaDtm() {
		return effStaDtm;
	}
	public void setEffStaDtm(String effStaDtm) {
		this.effStaDtm = effStaDtm;
	}
	public String getOffcPhonNum() {
		return offcPhonNum;
	}
	public void setOffcPhonNum(String offcPhonNum) {
		this.offcPhonNum = offcPhonNum;
	}
	public String getEmailAddr() {
		return emailAddr;
	}
	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}
	public String getSpclCustYn() {
		return spclCustYn;
	}
	public void setSpclCustYn(String spclCustYn) {
		this.spclCustYn = spclCustYn;
	}
	public String getCustChrticCd() {
		return custChrticCd;
	}
	public void setCustChrticCd(String custChrticCd) {
		this.custChrticCd = custChrticCd;
	}
	public long getRangeCustNum() {
		return rangeCustNum;
	}
	public void setRangeCustNum(long rangeCustNum) {
		this.rangeCustNum = rangeCustNum;
	}
	@Override
	public void setKey() {
		this.key = "" + this.custNum;
	}
	@Override
	public boolean equals(CopyVO obj) {
		OES10100 dest = (OES10100) obj;
		if (this.custNum != dest.custNum) return false;
		if (false == StringUtils.equals(this.custNm, dest.custNm)) return false;
		if (false == StringUtils.equals(this.custStCd, dest.custStCd)) return false;
		if (false == StringUtils.equals(this.custClCd, dest.custClCd)) return false;
		if (false == StringUtils.equals(this.custTypCd, dest.custTypCd)) return false;
		if (false == StringUtils.equals(this.mgmtAreaCd, dest.mgmtAreaCd)) return false;
		if (false == StringUtils.equals(this.zip, dest.zip)) return false;
		if (false == StringUtils.equals(this.houseNumClCd, dest.houseNumClCd)) return false;
		if (false == StringUtils.equals(this.mainHouseNumCtt, dest.mainHouseNumCtt)) return false;
		if (false == StringUtils.equals(this.subHouseNumCtt, dest.subHouseNumCtt)) return false;
		if (false == StringUtils.equals(this.bldClCd, dest.bldClCd)) return false;
		if (false == StringUtils.equals(this.bldCd, dest.bldCd)) return false;
		if (this.bldblkNum != dest.bldblkNum) return false;
		if (this.blduntNum != dest.blduntNum) return false;
		if (false == StringUtils.equals(this.basAddr, dest.basAddr)) return false;
		if (false == StringUtils.equals(this.assistAddr, dest.assistAddr)) return false;
		if (false == StringUtils.equals(this.ldongCd, dest.ldongCd)) return false;
		if (false == StringUtils.equals(this.phonNum, dest.phonNum)) return false;
		if (false == StringUtils.equals(this.inlineNum, dest.inlineNum)) return false;
		if (false == StringUtils.equals(this.faxNum, dest.faxNum)) return false;
		if (false == StringUtils.equals(this.mblPhonNum, dest.mblPhonNum)) return false;
		if (false == StringUtils.equals(this.fstRgstDtm, dest.fstRgstDtm)) return false;
		if (false == StringUtils.equals(this.effStaDtm, dest.effStaDtm)) return false;
		if (false == StringUtils.equals(this.offcPhonNum, dest.offcPhonNum)) return false;
		if (false == StringUtils.equals(this.emailAddr, dest.emailAddr)) return false;
		if (false == StringUtils.equals(this.spclCustYn, dest.spclCustYn)) return false;
		if (false == StringUtils.equals(this.custChrticCd, dest.custChrticCd)) return false;

		return true;
	}
	@Override
	public void setRange(CopyVO obj) {
		OES10100 src = (OES10100) obj;
		this.rangeCustNum = src.custNum;
	}
}
