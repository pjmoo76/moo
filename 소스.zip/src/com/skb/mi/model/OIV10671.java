package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV10671 extends CopyVO {
	private	long	svcMgmtNum;
	private	String	auditId;
	private	String	auditDtm;
	private	long	custNum;
	private	String	svcTechMthdCd;
	private	String	svcWeqpMgmtNum1;
	private	String	svcWeqpMgmtNum2;
	private	String	apWeqpMgmtNum;
	private	String	cmWeqpMgmtNum;
	private	String	ontWeqpMgmtNum;
	private	String	addWireEqpExistYn;
	private	String	ccellNum;
	private	String	routNum;
	private	String	assaspNum;
	private	String	phonNum;
	private	String	l3EquipId;
	private	String	lineNum;
	private	String	netLinkMgmtNum;
	private	String	svcLinkMgmtNum;
	private	String	srcInfo;
	private	String	l2EquipId;
	private	String	rnTapNum;
	private	String	svcCd;
	private	String	addrId;
	private	String	allAddr;
	private	String	ldongCd;
	private	String	svcWeqpVerInfo1;
	private	String	svcWeqpVerInfo2;
	private	String	apWeqpVerInfo;
	private	String	cmWeqpVerInfo;
	private	String	ontWeqpVerInfo;
	private	String	svcEqpMdlCd1;
	private	String	svcEqpMdlCd2;
	private	String	apEqpMdlCd;
	private	String	cmEqpMdlCd;
	private	String	ontEqpMdlCd;
	private	String	svcWeqpMdlNm1;
	private	String	svcWeqpMdlNm2;
	private	String	apWeqpMdlNm;
	private	String	cmWeqpMdlNm;
	private	String	ontWeqpMdlNm;
	private	String	svcWeqpMacAddr1;
	private	String	svcWeqpMacAddr2;
	private	String	apMacAddr;
	private	String	cmMacAddr;
	private	String	ontMacAddr;
	private	String	svcWeqpMfactSerNum1;
	private	String	svcWeqpMfactSerNum2;
	private	String	apMfactSerNum;
	private	String	cmMfactSerNum;
	private	String	ontMfactSerNum;
	private	String	arEquipId1;
	private	String	arEquipNm1;
	private	String	arPortNm1;
	private	String	arEquipId2;
	private	String	arEquipNm2;
	private	String	arPortNm2;
	private	String	dhcpEquipId1;
	private	String	dhcpEquipNm1;
	private	String	dhcpEquipId2;
	private	String	dhcpEquipNm2;
	private	String	sswEquipId;
	private	String	sswEquipNm;
	private	String	sbcEquipId;
	private	String	sbcEquipNm;
	private	String	l3EquipNm;
	private	String	l3PortNm;
	private	String	l2EquipNm;
	private	String	l2PortNm;
	private	String	enetWeqpMgmtNum;
	private	String	enetWeqpVerInfo;
	private	String	enetEqpMdlCd;
	private	String	enetWeqpMdlNm;
	private	String	enetMacAddr;
	private	String	enetMfactSerNum;
	private	String	tpoCd;
	private	String	massCoClCd;
	private	String	agwEquipId;
	private	String	agwEquipNm;
	private	String	agwEquipTidVal;
	private	String	agwEquipMdlNm;
	private	String	assaspNumLstVal;
	private	String	smktObjYn;
	private	long	motherLineSvcMgmtNum;
	private	String	l2EquipId2;
	private	String	l2EquipNm2;
	private	String	fstSvcDt;
	private	String	chgSvcDt;
	private	String	stbWeqpMgmtNum;
	private	String	stbWeqpVerInfo;
	private	String	stbEqpMdlCd;
	private	String	stbWeqpMdlNm;
	private	String	stbMacAddr;
	private	String	stbMfactSerNum;
	private	String	mtaWeqpMgmtNum;
	private	String	mtaWeqpVerInfo;
	private	String	mtaEqpMdlCd;
	private	String	mtaWeqpMdlNm;
	private	String	mtaMacAddr;
	private	String	mtaMfactSerNum;
	private	String	prvShrrExistYn;
	private	String	vdslWeqpMgmtNum;
	private	String	vdslWeqpVerInfo;
	private	String	vdslEqpMdlCd;
	private	String	vdslWeqpMdlNm;
	private	String	vdslMacAddr;
	private	String	vdslMfactSerNum;
	private	String	speedCd;
	private	String	plcWeqpMgmtNum;
	private	String	plcWeqpVerInfo;
	private	String	plcEqpMdlCd;
	private	String	plcWeqpMdlNm;
	private	String	plcMacAddr;
	private	String	plcMfactSerNum;
	private	String	etcWeqpMgmtNum;
	private	String	etcWeqpVerInfo;
	private	String	etcEqpMdlCd;
	private	String	etcWeqpMdlNm;
	private	String	etcMacAddr;
	private	String	etcMfactSerNum;
	private	String	prvShrrMacAddr;
	private	String	prvShrrMfactNm;
	private	String	prvShrrIpAddr;
	private	String	memoCtt;
	private	long	rangeSvcMgmtNum;
	/* ADMAS DB와 BS DB 현황화 작업 및 CATV칼럼 추가 반영 (2025-03-11 by KMY) */
	private	String	l2TpoCd;
	private	String	setChgSvcDtm;
	private	String	svcChgSvcDtm;
	private	long	custMultiStbCnt;
	private	long	svcMultiStbCnt;
	private	long	custAddrMultiStbCnt;
	private	String	stbWeqpUiVerInfo;
	private	String	l2EquipPortId;
	private	String	l3EquipPortId;
	private	String	svcTpoCd;
	private	String	l3RackNum;
	private	String	l3ShlfNum;
	private	String	l3CardNum;
	private	String	l2RackNum;
	private	String	l2ShlfNum;
	private	String	l2CardNum;
	private	String	onuEquipId;
	private	String	oltSupEquipId1;
	private	String	oltSupEquipId2;
	private	String	homeCntrCd;
	private	String	l3TpoCd;
	private	String	oltTpoCd1;
	private	String	oltTpoCd2;
	private	String	arTpoCd1;
	private	String	arTpoCd2;
	private	String	l2BldCd;
	private	String	l3BldCd;
	private	String	oltBldCd1;
	private	String	oltBldCd2;
	private	String	arBldCd1;
	private	String	arBldCd2;
	private	String	tvClVal;
	private	String	scrbrTbSoClCd;
	private	String	stbInrCmMacAddr;
	/* SVC_DTL_CL_CD 칼럼 추가 반영 (2025-05-07 by KMY) */
	private	String	svcDtlClCd;

	public long getSvcMgmtNum() {
		return svcMgmtNum;
	}
	public void setSvcMgmtNum(long svcMgmtNum) {
		this.svcMgmtNum = svcMgmtNum;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public long getCustNum() {
		return custNum;
	}
	public void setCustNum(long custNum) {
		this.custNum = custNum;
	}
	public String getSvcTechMthdCd() {
		return svcTechMthdCd;
	}
	public void setSvcTechMthdCd(String svcTechMthdCd) {
		this.svcTechMthdCd = svcTechMthdCd;
	}
	public String getSvcWeqpMgmtNum1() {
		return svcWeqpMgmtNum1;
	}
	public void setSvcWeqpMgmtNum1(String svcWeqpMgmtNum1) {
		this.svcWeqpMgmtNum1 = svcWeqpMgmtNum1;
	}
	public String getSvcWeqpMgmtNum2() {
		return svcWeqpMgmtNum2;
	}
	public void setSvcWeqpMgmtNum2(String svcWeqpMgmtNum2) {
		this.svcWeqpMgmtNum2 = svcWeqpMgmtNum2;
	}
	public String getApWeqpMgmtNum() {
		return apWeqpMgmtNum;
	}
	public void setApWeqpMgmtNum(String apWeqpMgmtNum) {
		this.apWeqpMgmtNum = apWeqpMgmtNum;
	}
	public String getCmWeqpMgmtNum() {
		return cmWeqpMgmtNum;
	}
	public void setCmWeqpMgmtNum(String cmWeqpMgmtNum) {
		this.cmWeqpMgmtNum = cmWeqpMgmtNum;
	}
	public String getOntWeqpMgmtNum() {
		return ontWeqpMgmtNum;
	}
	public void setOntWeqpMgmtNum(String ontWeqpMgmtNum) {
		this.ontWeqpMgmtNum = ontWeqpMgmtNum;
	}
	public String getAddWireEqpExistYn() {
		return addWireEqpExistYn;
	}
	public void setAddWireEqpExistYn(String addWireEqpExistYn) {
		this.addWireEqpExistYn = addWireEqpExistYn;
	}
	public String getCcellNum() {
		return ccellNum;
	}
	public void setCcellNum(String ccellNum) {
		this.ccellNum = ccellNum;
	}
	public String getRoutNum() {
		return routNum;
	}
	public void setRoutNum(String routNum) {
		this.routNum = routNum;
	}
	public String getAssaspNum() {
		return assaspNum;
	}
	public void setAssaspNum(String assaspNum) {
		this.assaspNum = assaspNum;
	}
	public String getPhonNum() {
		return phonNum;
	}
	public void setPhonNum(String phonNum) {
		this.phonNum = phonNum;
	}
	public String getL3EquipId() {
		return l3EquipId;
	}
	public void setL3EquipId(String l3EquipId) {
		this.l3EquipId = l3EquipId;
	}
	public String getLineNum() {
		return lineNum;
	}
	public void setLineNum(String lineNum) {
		this.lineNum = lineNum;
	}
	public String getNetLinkMgmtNum() {
		return netLinkMgmtNum;
	}
	public void setNetLinkMgmtNum(String netLinkMgmtNum) {
		this.netLinkMgmtNum = netLinkMgmtNum;
	}
	public String getSvcLinkMgmtNum() {
		return svcLinkMgmtNum;
	}
	public void setSvcLinkMgmtNum(String svcLinkMgmtNum) {
		this.svcLinkMgmtNum = svcLinkMgmtNum;
	}
	public String getSrcInfo() {
		return srcInfo;
	}
	public void setSrcInfo(String srcInfo) {
		this.srcInfo = srcInfo;
	}
	public String getL2EquipId() {
		return l2EquipId;
	}
	public void setL2EquipId(String l2EquipId) {
		this.l2EquipId = l2EquipId;
	}
	public String getRnTapNum() {
		return rnTapNum;
	}
	public void setRnTapNum(String rnTapNum) {
		this.rnTapNum = rnTapNum;
	}
	public String getSvcCd() {
		return svcCd;
	}
	public void setSvcCd(String svcCd) {
		this.svcCd = svcCd;
	}
	public String getAddrId() {
		return addrId;
	}
	public void setAddrId(String addrId) {
		this.addrId = addrId;
	}
	public String getAllAddr() {
		return allAddr;
	}
	public void setAllAddr(String allAddr) {
		this.allAddr = allAddr;
	}
	public String getLdongCd() {
		return ldongCd;
	}
	public void setLdongCd(String ldongCd) {
		this.ldongCd = ldongCd;
	}
	public String getSvcWeqpVerInfo1() {
		return svcWeqpVerInfo1;
	}
	public void setSvcWeqpVerInfo1(String svcWeqpVerInfo1) {
		this.svcWeqpVerInfo1 = svcWeqpVerInfo1;
	}
	public String getSvcWeqpVerInfo2() {
		return svcWeqpVerInfo2;
	}
	public void setSvcWeqpVerInfo2(String svcWeqpVerInfo2) {
		this.svcWeqpVerInfo2 = svcWeqpVerInfo2;
	}
	public String getApWeqpVerInfo() {
		return apWeqpVerInfo;
	}
	public void setApWeqpVerInfo(String apWeqpVerInfo) {
		this.apWeqpVerInfo = apWeqpVerInfo;
	}
	public String getCmWeqpVerInfo() {
		return cmWeqpVerInfo;
	}
	public void setCmWeqpVerInfo(String cmWeqpVerInfo) {
		this.cmWeqpVerInfo = cmWeqpVerInfo;
	}
	public String getOntWeqpVerInfo() {
		return ontWeqpVerInfo;
	}
	public void setOntWeqpVerInfo(String ontWeqpVerInfo) {
		this.ontWeqpVerInfo = ontWeqpVerInfo;
	}
	public String getSvcEqpMdlCd1() {
		return svcEqpMdlCd1;
	}
	public void setSvcEqpMdlCd1(String svcEqpMdlCd1) {
		this.svcEqpMdlCd1 = svcEqpMdlCd1;
	}
	public String getSvcEqpMdlCd2() {
		return svcEqpMdlCd2;
	}
	public void setSvcEqpMdlCd2(String svcEqpMdlCd2) {
		this.svcEqpMdlCd2 = svcEqpMdlCd2;
	}
	public String getApEqpMdlCd() {
		return apEqpMdlCd;
	}
	public void setApEqpMdlCd(String apEqpMdlCd) {
		this.apEqpMdlCd = apEqpMdlCd;
	}
	public String getCmEqpMdlCd() {
		return cmEqpMdlCd;
	}
	public void setCmEqpMdlCd(String cmEqpMdlCd) {
		this.cmEqpMdlCd = cmEqpMdlCd;
	}
	public String getOntEqpMdlCd() {
		return ontEqpMdlCd;
	}
	public void setOntEqpMdlCd(String ontEqpMdlCd) {
		this.ontEqpMdlCd = ontEqpMdlCd;
	}
	public String getSvcWeqpMdlNm1() {
		return svcWeqpMdlNm1;
	}
	public void setSvcWeqpMdlNm1(String svcWeqpMdlNm1) {
		this.svcWeqpMdlNm1 = svcWeqpMdlNm1;
	}
	public String getSvcWeqpMdlNm2() {
		return svcWeqpMdlNm2;
	}
	public void setSvcWeqpMdlNm2(String svcWeqpMdlNm2) {
		this.svcWeqpMdlNm2 = svcWeqpMdlNm2;
	}
	public String getApWeqpMdlNm() {
		return apWeqpMdlNm;
	}
	public void setApWeqpMdlNm(String apWeqpMdlNm) {
		this.apWeqpMdlNm = apWeqpMdlNm;
	}
	public String getCmWeqpMdlNm() {
		return cmWeqpMdlNm;
	}
	public void setCmWeqpMdlNm(String cmWeqpMdlNm) {
		this.cmWeqpMdlNm = cmWeqpMdlNm;
	}
	public String getOntWeqpMdlNm() {
		return ontWeqpMdlNm;
	}
	public void setOntWeqpMdlNm(String ontWeqpMdlNm) {
		this.ontWeqpMdlNm = ontWeqpMdlNm;
	}
	public String getSvcWeqpMacAddr1() {
		return svcWeqpMacAddr1;
	}
	public void setSvcWeqpMacAddr1(String svcWeqpMacAddr1) {
		this.svcWeqpMacAddr1 = svcWeqpMacAddr1;
	}
	public String getSvcWeqpMacAddr2() {
		return svcWeqpMacAddr2;
	}
	public void setSvcWeqpMacAddr2(String svcWeqpMacAddr2) {
		this.svcWeqpMacAddr2 = svcWeqpMacAddr2;
	}
	public String getApMacAddr() {
		return apMacAddr;
	}
	public void setApMacAddr(String apMacAddr) {
		this.apMacAddr = apMacAddr;
	}
	public String getCmMacAddr() {
		return cmMacAddr;
	}
	public void setCmMacAddr(String cmMacAddr) {
		this.cmMacAddr = cmMacAddr;
	}
	public String getOntMacAddr() {
		return ontMacAddr;
	}
	public void setOntMacAddr(String ontMacAddr) {
		this.ontMacAddr = ontMacAddr;
	}
	public String getSvcWeqpMfactSerNum1() {
		return svcWeqpMfactSerNum1;
	}
	public void setSvcWeqpMfactSerNum1(String svcWeqpMfactSerNum1) {
		this.svcWeqpMfactSerNum1 = svcWeqpMfactSerNum1;
	}
	public String getSvcWeqpMfactSerNum2() {
		return svcWeqpMfactSerNum2;
	}
	public void setSvcWeqpMfactSerNum2(String svcWeqpMfactSerNum2) {
		this.svcWeqpMfactSerNum2 = svcWeqpMfactSerNum2;
	}
	public String getApMfactSerNum() {
		return apMfactSerNum;
	}
	public void setApMfactSerNum(String apMfactSerNum) {
		this.apMfactSerNum = apMfactSerNum;
	}
	public String getCmMfactSerNum() {
		return cmMfactSerNum;
	}
	public void setCmMfactSerNum(String cmMfactSerNum) {
		this.cmMfactSerNum = cmMfactSerNum;
	}
	public String getOntMfactSerNum() {
		return ontMfactSerNum;
	}
	public void setOntMfactSerNum(String ontMfactSerNum) {
		this.ontMfactSerNum = ontMfactSerNum;
	}
	public String getArEquipId1() {
		return arEquipId1;
	}
	public void setArEquipId1(String arEquipId1) {
		this.arEquipId1 = arEquipId1;
	}
	public String getArEquipNm1() {
		return arEquipNm1;
	}
	public void setArEquipNm1(String arEquipNm1) {
		this.arEquipNm1 = arEquipNm1;
	}
	public String getArPortNm1() {
		return arPortNm1;
	}
	public void setArPortNm1(String arPortNm1) {
		this.arPortNm1 = arPortNm1;
	}
	public String getArEquipId2() {
		return arEquipId2;
	}
	public void setArEquipId2(String arEquipId2) {
		this.arEquipId2 = arEquipId2;
	}
	public String getArEquipNm2() {
		return arEquipNm2;
	}
	public void setArEquipNm2(String arEquipNm2) {
		this.arEquipNm2 = arEquipNm2;
	}
	public String getArPortNm2() {
		return arPortNm2;
	}
	public void setArPortNm2(String arPortNm2) {
		this.arPortNm2 = arPortNm2;
	}
	public String getDhcpEquipId1() {
		return dhcpEquipId1;
	}
	public void setDhcpEquipId1(String dhcpEquipId1) {
		this.dhcpEquipId1 = dhcpEquipId1;
	}
	public String getDhcpEquipNm1() {
		return dhcpEquipNm1;
	}
	public void setDhcpEquipNm1(String dhcpEquipNm1) {
		this.dhcpEquipNm1 = dhcpEquipNm1;
	}
	public String getDhcpEquipId2() {
		return dhcpEquipId2;
	}
	public void setDhcpEquipId2(String dhcpEquipId2) {
		this.dhcpEquipId2 = dhcpEquipId2;
	}
	public String getDhcpEquipNm2() {
		return dhcpEquipNm2;
	}
	public void setDhcpEquipNm2(String dhcpEquipNm2) {
		this.dhcpEquipNm2 = dhcpEquipNm2;
	}
	public String getSswEquipId() {
		return sswEquipId;
	}
	public void setSswEquipId(String sswEquipId) {
		this.sswEquipId = sswEquipId;
	}
	public String getSswEquipNm() {
		return sswEquipNm;
	}
	public void setSswEquipNm(String sswEquipNm) {
		this.sswEquipNm = sswEquipNm;
	}
	public String getSbcEquipId() {
		return sbcEquipId;
	}
	public void setSbcEquipId(String sbcEquipId) {
		this.sbcEquipId = sbcEquipId;
	}
	public String getSbcEquipNm() {
		return sbcEquipNm;
	}
	public void setSbcEquipNm(String sbcEquipNm) {
		this.sbcEquipNm = sbcEquipNm;
	}
	public String getL3EquipNm() {
		return l3EquipNm;
	}
	public void setL3EquipNm(String l3EquipNm) {
		this.l3EquipNm = l3EquipNm;
	}
	public String getL3PortNm() {
		return l3PortNm;
	}
	public void setL3PortNm(String l3PortNm) {
		this.l3PortNm = l3PortNm;
	}
	public String getL2EquipNm() {
		return l2EquipNm;
	}
	public void setL2EquipNm(String l2EquipNm) {
		this.l2EquipNm = l2EquipNm;
	}
	public String getL2PortNm() {
		return l2PortNm;
	}
	public void setL2PortNm(String l2PortNm) {
		this.l2PortNm = l2PortNm;
	}
	public String getEnetWeqpMgmtNum() {
		return enetWeqpMgmtNum;
	}
	public void setEnetWeqpMgmtNum(String enetWeqpMgmtNum) {
		this.enetWeqpMgmtNum = enetWeqpMgmtNum;
	}
	public String getEnetWeqpVerInfo() {
		return enetWeqpVerInfo;
	}
	public void setEnetWeqpVerInfo(String enetWeqpVerInfo) {
		this.enetWeqpVerInfo = enetWeqpVerInfo;
	}
	public String getEnetEqpMdlCd() {
		return enetEqpMdlCd;
	}
	public void setEnetEqpMdlCd(String enetEqpMdlCd) {
		this.enetEqpMdlCd = enetEqpMdlCd;
	}
	public String getEnetWeqpMdlNm() {
		return enetWeqpMdlNm;
	}
	public void setEnetWeqpMdlNm(String enetWeqpMdlNm) {
		this.enetWeqpMdlNm = enetWeqpMdlNm;
	}
	public String getEnetMacAddr() {
		return enetMacAddr;
	}
	public void setEnetMacAddr(String enetMacAddr) {
		this.enetMacAddr = enetMacAddr;
	}
	public String getEnetMfactSerNum() {
		return enetMfactSerNum;
	}
	public void setEnetMfactSerNum(String enetMfactSerNum) {
		this.enetMfactSerNum = enetMfactSerNum;
	}
	public String getTpoCd() {
		return tpoCd;
	}
	public void setTpoCd(String tpoCd) {
		this.tpoCd = tpoCd;
	}
	public String getMassCoClCd() {
		return massCoClCd;
	}
	public void setMassCoClCd(String massCoClCd) {
		this.massCoClCd = massCoClCd;
	}
	public String getAgwEquipId() {
		return agwEquipId;
	}
	public void setAgwEquipId(String agwEquipId) {
		this.agwEquipId = agwEquipId;
	}
	public String getAgwEquipNm() {
		return agwEquipNm;
	}
	public void setAgwEquipNm(String agwEquipNm) {
		this.agwEquipNm = agwEquipNm;
	}
	public String getAgwEquipTidVal() {
		return agwEquipTidVal;
	}
	public void setAgwEquipTidVal(String agwEquipTidVal) {
		this.agwEquipTidVal = agwEquipTidVal;
	}
	public String getAgwEquipMdlNm() {
		return agwEquipMdlNm;
	}
	public void setAgwEquipMdlNm(String agwEquipMdlNm) {
		this.agwEquipMdlNm = agwEquipMdlNm;
	}
	public String getAssaspNumLstVal() {
		return assaspNumLstVal;
	}
	public void setAssaspNumLstVal(String assaspNumLstVal) {
		this.assaspNumLstVal = assaspNumLstVal;
	}
	public String getSmktObjYn() {
		return smktObjYn;
	}
	public void setSmktObjYn(String smktObjYn) {
		this.smktObjYn = smktObjYn;
	}
	public long getMotherLineSvcMgmtNum() {
		return motherLineSvcMgmtNum;
	}
	public void setMotherLineSvcMgmtNum(long motherLineSvcMgmtNum) {
		this.motherLineSvcMgmtNum = motherLineSvcMgmtNum;
	}
	public String getL2EquipId2() {
		return l2EquipId2;
	}
	public void setL2EquipId2(String l2EquipId2) {
		this.l2EquipId2 = l2EquipId2;
	}
	public String getL2EquipNm2() {
		return l2EquipNm2;
	}
	public void setL2EquipNm2(String l2EquipNm2) {
		this.l2EquipNm2 = l2EquipNm2;
	}
	public String getFstSvcDt() {
		return fstSvcDt;
	}
	public void setFstSvcDt(String fstSvcDt) {
		this.fstSvcDt = fstSvcDt;
	}
	public String getChgSvcDt() {
		return chgSvcDt;
	}
	public void setChgSvcDt(String chgSvcDt) {
		this.chgSvcDt = chgSvcDt;
	}
	public String getStbWeqpMgmtNum() {
		return stbWeqpMgmtNum;
	}
	public void setStbWeqpMgmtNum(String stbWeqpMgmtNum) {
		this.stbWeqpMgmtNum = stbWeqpMgmtNum;
	}
	public String getStbWeqpVerInfo() {
		return stbWeqpVerInfo;
	}
	public void setStbWeqpVerInfo(String stbWeqpVerInfo) {
		this.stbWeqpVerInfo = stbWeqpVerInfo;
	}
	public String getStbEqpMdlCd() {
		return stbEqpMdlCd;
	}
	public void setStbEqpMdlCd(String stbEqpMdlCd) {
		this.stbEqpMdlCd = stbEqpMdlCd;
	}
	public String getStbWeqpMdlNm() {
		return stbWeqpMdlNm;
	}
	public void setStbWeqpMdlNm(String stbWeqpMdlNm) {
		this.stbWeqpMdlNm = stbWeqpMdlNm;
	}
	public String getStbMacAddr() {
		return stbMacAddr;
	}
	public void setStbMacAddr(String stbMacAddr) {
		this.stbMacAddr = stbMacAddr;
	}
	public String getStbMfactSerNum() {
		return stbMfactSerNum;
	}
	public void setStbMfactSerNum(String stbMfactSerNum) {
		this.stbMfactSerNum = stbMfactSerNum;
	}
	public String getMtaWeqpMgmtNum() {
		return mtaWeqpMgmtNum;
	}
	public void setMtaWeqpMgmtNum(String mtaWeqpMgmtNum) {
		this.mtaWeqpMgmtNum = mtaWeqpMgmtNum;
	}
	public String getMtaWeqpVerInfo() {
		return mtaWeqpVerInfo;
	}
	public void setMtaWeqpVerInfo(String mtaWeqpVerInfo) {
		this.mtaWeqpVerInfo = mtaWeqpVerInfo;
	}
	public String getMtaEqpMdlCd() {
		return mtaEqpMdlCd;
	}
	public void setMtaEqpMdlCd(String mtaEqpMdlCd) {
		this.mtaEqpMdlCd = mtaEqpMdlCd;
	}
	public String getMtaWeqpMdlNm() {
		return mtaWeqpMdlNm;
	}
	public void setMtaWeqpMdlNm(String mtaWeqpMdlNm) {
		this.mtaWeqpMdlNm = mtaWeqpMdlNm;
	}
	public String getMtaMacAddr() {
		return mtaMacAddr;
	}
	public void setMtaMacAddr(String mtaMacAddr) {
		this.mtaMacAddr = mtaMacAddr;
	}
	public String getMtaMfactSerNum() {
		return mtaMfactSerNum;
	}
	public void setMtaMfactSerNum(String mtaMfactSerNum) {
		this.mtaMfactSerNum = mtaMfactSerNum;
	}
	public String getPrvShrrExistYn() {
		return prvShrrExistYn;
	}
	public void setPrvShrrExistYn(String prvShrrExistYn) {
		this.prvShrrExistYn = prvShrrExistYn;
	}
	public String getVdslWeqpMgmtNum() {
		return vdslWeqpMgmtNum;
	}
	public void setVdslWeqpMgmtNum(String vdslWeqpMgmtNum) {
		this.vdslWeqpMgmtNum = vdslWeqpMgmtNum;
	}
	public String getVdslWeqpVerInfo() {
		return vdslWeqpVerInfo;
	}
	public void setVdslWeqpVerInfo(String vdslWeqpVerInfo) {
		this.vdslWeqpVerInfo = vdslWeqpVerInfo;
	}
	public String getVdslEqpMdlCd() {
		return vdslEqpMdlCd;
	}
	public void setVdslEqpMdlCd(String vdslEqpMdlCd) {
		this.vdslEqpMdlCd = vdslEqpMdlCd;
	}
	public String getVdslWeqpMdlNm() {
		return vdslWeqpMdlNm;
	}
	public void setVdslWeqpMdlNm(String vdslWeqpMdlNm) {
		this.vdslWeqpMdlNm = vdslWeqpMdlNm;
	}
	public String getVdslMacAddr() {
		return vdslMacAddr;
	}
	public void setVdslMacAddr(String vdslMacAddr) {
		this.vdslMacAddr = vdslMacAddr;
	}
	public String getVdslMfactSerNum() {
		return vdslMfactSerNum;
	}
	public void setVdslMfactSerNum(String vdslMfactSerNum) {
		this.vdslMfactSerNum = vdslMfactSerNum;
	}
	public String getSpeedCd() {
		return speedCd;
	}
	public void setSpeedCd(String speedCd) {
		this.speedCd = speedCd;
	}
	public String getPlcWeqpMgmtNum() {
		return plcWeqpMgmtNum;
	}
	public void setPlcWeqpMgmtNum(String plcWeqpMgmtNum) {
		this.plcWeqpMgmtNum = plcWeqpMgmtNum;
	}
	public String getPlcWeqpVerInfo() {
		return plcWeqpVerInfo;
	}
	public void setPlcWeqpVerInfo(String plcWeqpVerInfo) {
		this.plcWeqpVerInfo = plcWeqpVerInfo;
	}
	public String getPlcEqpMdlCd() {
		return plcEqpMdlCd;
	}
	public void setPlcEqpMdlCd(String plcEqpMdlCd) {
		this.plcEqpMdlCd = plcEqpMdlCd;
	}
	public String getPlcWeqpMdlNm() {
		return plcWeqpMdlNm;
	}
	public void setPlcWeqpMdlNm(String plcWeqpMdlNm) {
		this.plcWeqpMdlNm = plcWeqpMdlNm;
	}
	public String getPlcMacAddr() {
		return plcMacAddr;
	}
	public void setPlcMacAddr(String plcMacAddr) {
		this.plcMacAddr = plcMacAddr;
	}
	public String getPlcMfactSerNum() {
		return plcMfactSerNum;
	}
	public void setPlcMfactSerNum(String plcMfactSerNum) {
		this.plcMfactSerNum = plcMfactSerNum;
	}
	public String getEtcWeqpMgmtNum() {
		return etcWeqpMgmtNum;
	}
	public void setEtcWeqpMgmtNum(String etcWeqpMgmtNum) {
		this.etcWeqpMgmtNum = etcWeqpMgmtNum;
	}
	public String getEtcWeqpVerInfo() {
		return etcWeqpVerInfo;
	}
	public void setEtcWeqpVerInfo(String etcWeqpVerInfo) {
		this.etcWeqpVerInfo = etcWeqpVerInfo;
	}
	public String getEtcEqpMdlCd() {
		return etcEqpMdlCd;
	}
	public void setEtcEqpMdlCd(String etcEqpMdlCd) {
		this.etcEqpMdlCd = etcEqpMdlCd;
	}
	public String getEtcWeqpMdlNm() {
		return etcWeqpMdlNm;
	}
	public void setEtcWeqpMdlNm(String etcWeqpMdlNm) {
		this.etcWeqpMdlNm = etcWeqpMdlNm;
	}
	public String getEtcMacAddr() {
		return etcMacAddr;
	}
	public void setEtcMacAddr(String etcMacAddr) {
		this.etcMacAddr = etcMacAddr;
	}
	public String getEtcMfactSerNum() {
		return etcMfactSerNum;
	}
	public void setEtcMfactSerNum(String etcMfactSerNum) {
		this.etcMfactSerNum = etcMfactSerNum;
	}
	public String getPrvShrrMacAddr() {
		return prvShrrMacAddr;
	}
	public void setPrvShrrMacAddr(String prvShrrMacAddr) {
		this.prvShrrMacAddr = prvShrrMacAddr;
	}
	public String getPrvShrrMfactNm() {
		return prvShrrMfactNm;
	}
	public void setPrvShrrMfactNm(String prvShrrMfactNm) {
		this.prvShrrMfactNm = prvShrrMfactNm;
	}
	public String getPrvShrrIpAddr() {
		return prvShrrIpAddr;
	}
	public void setPrvShrrIpAddr(String prvShrrIpAddr) {
		this.prvShrrIpAddr = prvShrrIpAddr;
	}
	public String getMemoCtt() {
		return memoCtt;
	}
	public void setMemoCtt(String memoCtt) {
		this.memoCtt = memoCtt;
	}
	public long getRangeSvcMgmtNum() {
		return rangeSvcMgmtNum;
	}
	public void setRangeSvcMgmtNum(long rangeSvcMgmtNum) {
		this.rangeSvcMgmtNum = rangeSvcMgmtNum;
	}
	@Override
	public void setKey() {
		this.key = "" + this.svcMgmtNum;
	}

	@Override
	public void setRange(CopyVO obj) {
		OIV10671 src = (OIV10671) obj;
		this.rangeSvcMgmtNum = src.svcMgmtNum;
	}

	/* ADMAS DB와 BS DB 현황화 작업 및 CATV칼럼 추가 반영 (2025-03-11 by KMY) */
	public String getL2TpoCd() {
		return l2TpoCd;
	}
	public void setL2TpoCd(String l2TpoCd) {
		this.l2TpoCd = l2TpoCd;
	}
	public String getSetChgSvcDtm() {
		return setChgSvcDtm;
	}
	public void setSetChgSvcDtm(String setChgSvcDtm) {
		this.setChgSvcDtm = setChgSvcDtm;
	}
	public String getSvcChgSvcDtm() {
		return svcChgSvcDtm;
	}
	public void setSvcChgSvcDtm(String svcChgSvcDtm) {
		this.svcChgSvcDtm = svcChgSvcDtm;
	}
	public long getCustMultiStbCnt() {
		return custMultiStbCnt;
	}
	public void setCustMultiStbCnt(long custMultiStbCnt) {
		this.custMultiStbCnt = custMultiStbCnt;
	}
	public long getSvcMultiStbCnt() {
		return svcMultiStbCnt;
	}
	public void setSvcMultiStbCnt(long svcMultiStbCnt) {
		this.svcMultiStbCnt = svcMultiStbCnt;
	}
	public long getCustAddrMultiStbCnt() {
		return custAddrMultiStbCnt;
	}
	public void setCustAddrMultiStbCnt(long custAddrMultiStbCnt) {
		this.custAddrMultiStbCnt = custAddrMultiStbCnt;
	}
	public String getStbWeqpUiVerInfo() {
		return stbWeqpUiVerInfo;
	}
	public void setStbWeqpUiVerInfo(String stbWeqpUiVerInfo) {
		this.stbWeqpUiVerInfo = stbWeqpUiVerInfo;
	}
	public String getL2EquipPortId() {
		return l2EquipPortId;
	}
	public void setL2EquipPortId(String l2EquipPortId) {
		this.l2EquipPortId = l2EquipPortId;
	}
	public String getL3EquipPortId() {
		return l3EquipPortId;
	}
	public void setL3EquipPortId(String l3EquipPortId) {
		this.l3EquipPortId = l3EquipPortId;
	}
	public String getSvcTpoCd() {
		return svcTpoCd;
	}
	public void setSvcTpoCd(String svcTpoCd) {
		this.svcTpoCd = svcTpoCd;
	}
	public String getL3RackNum() {
		return l3RackNum;
	}
	public void setL3RackNum(String l3RackNum) {
		this.l3RackNum = l3RackNum;
	}
	public String getL3ShlfNum() {
		return l3ShlfNum;
	}
	public void setL3ShlfNum(String l3ShlfNum) {
		this.l3ShlfNum = l3ShlfNum;
	}
	public String getL3CardNum() {
		return l3CardNum;
	}
	public void setL3CardNum(String l3CardNum) {
		this.l3CardNum = l3CardNum;
	}
	public String getL2RackNum() {
		return l2RackNum;
	}
	public void setL2RackNum(String l2RackNum) {
		this.l2RackNum = l2RackNum;
	}
	public String getL2ShlfNum() {
		return l2ShlfNum;
	}
	public void setL2ShlfNum(String l2ShlfNum) {
		this.l2ShlfNum = l2ShlfNum;
	}
	public String getL2CardNum() {
		return l2CardNum;
	}
	public void setL2CardNum(String l2CardNum) {
		this.l2CardNum = l2CardNum;
	}
	public String getOnuEquipId() {
		return onuEquipId;
	}
	public void setOnuEquipId(String onuEquipId) {
		this.onuEquipId = onuEquipId;
	}
	public String getOltSupEquipId1() {
		return oltSupEquipId1;
	}
	public void setOltSupEquipId1(String oltSupEquipId1) {
		this.oltSupEquipId1 = oltSupEquipId1;
	}
	public String getOltSupEquipId2() {
		return oltSupEquipId2;
	}
	public void setOltSupEquipId2(String oltSupEquipId2) {
		this.oltSupEquipId2 = oltSupEquipId2;
	}
	public String getHomeCntrCd() {
		return homeCntrCd;
	}
	public void setHomeCntrCd(String homeCntrCd) {
		this.homeCntrCd = homeCntrCd;
	}
	public String getL3TpoCd() {
		return l3TpoCd;
	}
	public void setL3TpoCd(String l3TpoCd) {
		this.l3TpoCd = l3TpoCd;
	}
	public String getOltTpoCd1() {
		return oltTpoCd1;
	}
	public void setOltTpoCd1(String oltTpoCd1) {
		this.oltTpoCd1 = oltTpoCd1;
	}
	public String getOltTpoCd2() {
		return oltTpoCd2;
	}
	public void setOltTpoCd2(String oltTpoCd2) {
		this.oltTpoCd2 = oltTpoCd2;
	}
	public String getArTpoCd1() {
		return arTpoCd1;
	}
	public void setArTpoCd1(String arTpoCd1) {
		this.arTpoCd1 = arTpoCd1;
	}
	public String getArTpoCd2() {
		return arTpoCd2;
	}
	public void setArTpoCd2(String arTpoCd2) {
		this.arTpoCd2 = arTpoCd2;
	}
	public String getL2BldCd() {
		return l2BldCd;
	}
	public void setL2BldCd(String l2BldCd) {
		this.l2BldCd = l2BldCd;
	}
	public String getL3BldCd() {
		return l3BldCd;
	}
	public void setL3BldCd(String l3BldCd) {
		this.l3BldCd = l3BldCd;
	}
	public String getOltBldCd1() {
		return oltBldCd1;
	}
	public void setOltBldCd1(String oltBldCd1) {
		this.oltBldCd1 = oltBldCd1;
	}
	public String getOltBldCd2() {
		return oltBldCd2;
	}
	public void setOltBldCd2(String oltBldCd2) {
		this.oltBldCd2 = oltBldCd2;
	}
	public String getArBldCd1() {
		return arBldCd1;
	}
	public void setArBldCd1(String arBldCd1) {
		this.arBldCd1 = arBldCd1;
	}
	public String getArBldCd2() {
		return arBldCd2;
	}
	public void setArBldCd2(String arBldCd2) {
		this.arBldCd2 = arBldCd2;
	}
	public String getTvClVal() {
		return tvClVal;
	}
	public void setTvClVal(String tvClVal) {
		this.tvClVal = tvClVal;
	}
	public String getScrbrTbSoClCd() {
		return scrbrTbSoClCd;
	}
	public void setScrbrTbSoClCd(String scrbrTbSoClCd) {
		this.scrbrTbSoClCd = scrbrTbSoClCd;
	}
	public String getStbInrCmMacAddr() {
		return stbInrCmMacAddr;
	}
	public void setStbInrCmMacAddr(String stbInrCmMacAddr) {
		this.stbInrCmMacAddr = stbInrCmMacAddr;
	}

	public String getSvcDtlClCd() {
		return svcDtlClCd;
	}
	public void setSvcDtlClCd(String svcDtlClCd) {
		this.svcDtlClCd = svcDtlClCd;
	}

	@Override
	public boolean equals(CopyVO obj) {
		OIV10671 dest = (OIV10671) obj;
		if (this.svcMgmtNum != dest.svcMgmtNum) return false;
		if (this.custNum != dest.custNum) return false;
		if (false == StringUtils.equals(this.svcTechMthdCd, dest.svcTechMthdCd)) return false;
		if (false == StringUtils.equals(this.svcWeqpMgmtNum1, dest.svcWeqpMgmtNum1)) return false;
		if (false == StringUtils.equals(this.svcWeqpMgmtNum2, dest.svcWeqpMgmtNum2)) return false;
		if (false == StringUtils.equals(this.apWeqpMgmtNum, dest.apWeqpMgmtNum)) return false;
		if (false == StringUtils.equals(this.cmWeqpMgmtNum, dest.cmWeqpMgmtNum)) return false;
		if (false == StringUtils.equals(this.ontWeqpMgmtNum, dest.ontWeqpMgmtNum)) return false;
		if (false == StringUtils.equals(this.addWireEqpExistYn, dest.addWireEqpExistYn)) return false;
		if (false == StringUtils.equals(this.ccellNum, dest.ccellNum)) return false;
		if (false == StringUtils.equals(this.routNum, dest.routNum)) return false;
		if (false == StringUtils.equals(this.assaspNum, dest.assaspNum)) return false;
		if (false == StringUtils.equals(this.phonNum, dest.phonNum)) return false;
		if (false == StringUtils.equals(this.l3EquipId, dest.l3EquipId)) return false;
		if (false == StringUtils.equals(this.lineNum, dest.lineNum)) return false;
		if (false == StringUtils.equals(this.netLinkMgmtNum, dest.netLinkMgmtNum)) return false;
		if (false == StringUtils.equals(this.svcLinkMgmtNum, dest.svcLinkMgmtNum)) return false;
		if (false == StringUtils.equals(this.srcInfo, dest.srcInfo)) return false;
		if (false == StringUtils.equals(this.l2EquipId, dest.l2EquipId)) return false;
		if (false == StringUtils.equals(this.rnTapNum, dest.rnTapNum)) return false;
		if (false == StringUtils.equals(this.svcCd, dest.svcCd)) return false;
		if (false == StringUtils.equals(this.addrId, dest.addrId)) return false;
		if (false == StringUtils.equals(this.allAddr, dest.allAddr)) return false;
		if (false == StringUtils.equals(this.ldongCd, dest.ldongCd)) return false;
		if (false == StringUtils.equals(this.svcWeqpVerInfo1, dest.svcWeqpVerInfo1)) return false;
		if (false == StringUtils.equals(this.svcWeqpVerInfo2, dest.svcWeqpVerInfo2)) return false;
		if (false == StringUtils.equals(this.apWeqpVerInfo, dest.apWeqpVerInfo)) return false;
		if (false == StringUtils.equals(this.cmWeqpVerInfo, dest.cmWeqpVerInfo)) return false;
		if (false == StringUtils.equals(this.ontWeqpVerInfo, dest.ontWeqpVerInfo)) return false;
		if (false == StringUtils.equals(this.svcEqpMdlCd1, dest.svcEqpMdlCd1)) return false;
		if (false == StringUtils.equals(this.svcEqpMdlCd2, dest.svcEqpMdlCd2)) return false;
		if (false == StringUtils.equals(this.apEqpMdlCd, dest.apEqpMdlCd)) return false;
		if (false == StringUtils.equals(this.cmEqpMdlCd, dest.cmEqpMdlCd)) return false;
		if (false == StringUtils.equals(this.ontEqpMdlCd, dest.ontEqpMdlCd)) return false;
		if (false == StringUtils.equals(this.svcWeqpMdlNm1, dest.svcWeqpMdlNm1)) return false;
		if (false == StringUtils.equals(this.svcWeqpMdlNm2, dest.svcWeqpMdlNm2)) return false;
		if (false == StringUtils.equals(this.apWeqpMdlNm, dest.apWeqpMdlNm)) return false;
		if (false == StringUtils.equals(this.cmWeqpMdlNm, dest.cmWeqpMdlNm)) return false;
		if (false == StringUtils.equals(this.ontWeqpMdlNm, dest.ontWeqpMdlNm)) return false;
		if (false == StringUtils.equals(this.svcWeqpMacAddr1, dest.svcWeqpMacAddr1)) return false;
		if (false == StringUtils.equals(this.svcWeqpMacAddr2, dest.svcWeqpMacAddr2)) return false;
		if (false == StringUtils.equals(this.apMacAddr, dest.apMacAddr)) return false;
		if (false == StringUtils.equals(this.cmMacAddr, dest.cmMacAddr)) return false;
		if (false == StringUtils.equals(this.ontMacAddr, dest.ontMacAddr)) return false;
		if (false == StringUtils.equals(this.svcWeqpMfactSerNum1, dest.svcWeqpMfactSerNum1)) return false;
		if (false == StringUtils.equals(this.svcWeqpMfactSerNum2, dest.svcWeqpMfactSerNum2)) return false;
		if (false == StringUtils.equals(this.apMfactSerNum, dest.apMfactSerNum)) return false;
		if (false == StringUtils.equals(this.cmMfactSerNum, dest.cmMfactSerNum)) return false;
		if (false == StringUtils.equals(this.ontMfactSerNum, dest.ontMfactSerNum)) return false;
		if (false == StringUtils.equals(this.arEquipId1, dest.arEquipId1)) return false;
		if (false == StringUtils.equals(this.arEquipNm1, dest.arEquipNm1)) return false;
		if (false == StringUtils.equals(this.arPortNm1, dest.arPortNm1)) return false;
		if (false == StringUtils.equals(this.arEquipId2, dest.arEquipId2)) return false;
		if (false == StringUtils.equals(this.arEquipNm2, dest.arEquipNm2)) return false;
		if (false == StringUtils.equals(this.arPortNm2, dest.arPortNm2)) return false;
		if (false == StringUtils.equals(this.dhcpEquipId1, dest.dhcpEquipId1)) return false;
		if (false == StringUtils.equals(this.dhcpEquipNm1, dest.dhcpEquipNm1)) return false;
		if (false == StringUtils.equals(this.dhcpEquipId2, dest.dhcpEquipId2)) return false;
		if (false == StringUtils.equals(this.dhcpEquipNm2, dest.dhcpEquipNm2)) return false;
		if (false == StringUtils.equals(this.sswEquipId, dest.sswEquipId)) return false;
		if (false == StringUtils.equals(this.sswEquipNm, dest.sswEquipNm)) return false;
		if (false == StringUtils.equals(this.sbcEquipId, dest.sbcEquipId)) return false;
		if (false == StringUtils.equals(this.sbcEquipNm, dest.sbcEquipNm)) return false;
		if (false == StringUtils.equals(this.l3EquipNm, dest.l3EquipNm)) return false;
		if (false == StringUtils.equals(this.l3PortNm, dest.l3PortNm)) return false;
		if (false == StringUtils.equals(this.l2EquipNm, dest.l2EquipNm)) return false;
		if (false == StringUtils.equals(this.l2PortNm, dest.l2PortNm)) return false;
		if (false == StringUtils.equals(this.enetWeqpMgmtNum, dest.enetWeqpMgmtNum)) return false;
		if (false == StringUtils.equals(this.enetWeqpVerInfo, dest.enetWeqpVerInfo)) return false;
		if (false == StringUtils.equals(this.enetEqpMdlCd, dest.enetEqpMdlCd)) return false;
		if (false == StringUtils.equals(this.enetWeqpMdlNm, dest.enetWeqpMdlNm)) return false;
		if (false == StringUtils.equals(this.enetMacAddr, dest.enetMacAddr)) return false;
		if (false == StringUtils.equals(this.enetMfactSerNum, dest.enetMfactSerNum)) return false;
		if (false == StringUtils.equals(this.tpoCd, dest.tpoCd)) return false;
		if (false == StringUtils.equals(this.massCoClCd, dest.massCoClCd)) return false;
		if (false == StringUtils.equals(this.agwEquipId, dest.agwEquipId)) return false;
		if (false == StringUtils.equals(this.agwEquipNm, dest.agwEquipNm)) return false;
		if (false == StringUtils.equals(this.agwEquipTidVal, dest.agwEquipTidVal)) return false;
		if (false == StringUtils.equals(this.agwEquipMdlNm, dest.agwEquipMdlNm)) return false;
		if (false == StringUtils.equals(this.assaspNumLstVal, dest.assaspNumLstVal)) return false;
		if (false == StringUtils.equals(this.smktObjYn, dest.smktObjYn)) return false;
		if (this.motherLineSvcMgmtNum != dest.motherLineSvcMgmtNum) return false;
		if (false == StringUtils.equals(this.l2EquipId2, dest.l2EquipId2)) return false;
		if (false == StringUtils.equals(this.l2EquipNm2, dest.l2EquipNm2)) return false;
		if (false == StringUtils.equals(this.fstSvcDt, dest.fstSvcDt)) return false;
		if (false == StringUtils.equals(this.chgSvcDt, dest.chgSvcDt)) return false;
		if (false == StringUtils.equals(this.stbWeqpMgmtNum, dest.stbWeqpMgmtNum)) return false;
		if (false == StringUtils.equals(this.stbWeqpVerInfo, dest.stbWeqpVerInfo)) return false;
		if (false == StringUtils.equals(this.stbEqpMdlCd, dest.stbEqpMdlCd)) return false;
		if (false == StringUtils.equals(this.stbWeqpMdlNm, dest.stbWeqpMdlNm)) return false;
		if (false == StringUtils.equals(this.stbMacAddr, dest.stbMacAddr)) return false;
		if (false == StringUtils.equals(this.stbMfactSerNum, dest.stbMfactSerNum)) return false;
		if (false == StringUtils.equals(this.mtaWeqpMgmtNum, dest.mtaWeqpMgmtNum)) return false;
		if (false == StringUtils.equals(this.mtaWeqpVerInfo, dest.mtaWeqpVerInfo)) return false;
		if (false == StringUtils.equals(this.mtaEqpMdlCd, dest.mtaEqpMdlCd)) return false;
		if (false == StringUtils.equals(this.mtaWeqpMdlNm, dest.mtaWeqpMdlNm)) return false;
		if (false == StringUtils.equals(this.mtaMacAddr, dest.mtaMacAddr)) return false;
		if (false == StringUtils.equals(this.mtaMfactSerNum, dest.mtaMfactSerNum)) return false;
		if (false == StringUtils.equals(this.prvShrrExistYn, dest.prvShrrExistYn)) return false;
		if (false == StringUtils.equals(this.vdslWeqpMgmtNum, dest.vdslWeqpMgmtNum)) return false;
		if (false == StringUtils.equals(this.vdslWeqpVerInfo, dest.vdslWeqpVerInfo)) return false;
		if (false == StringUtils.equals(this.vdslEqpMdlCd, dest.vdslEqpMdlCd)) return false;
		if (false == StringUtils.equals(this.vdslWeqpMdlNm, dest.vdslWeqpMdlNm)) return false;
		if (false == StringUtils.equals(this.vdslMacAddr, dest.vdslMacAddr)) return false;
		if (false == StringUtils.equals(this.vdslMfactSerNum, dest.vdslMfactSerNum)) return false;
		if (false == StringUtils.equals(this.speedCd, dest.speedCd)) return false;
		if (false == StringUtils.equals(this.plcWeqpMgmtNum, dest.plcWeqpMgmtNum)) return false;
		if (false == StringUtils.equals(this.plcWeqpVerInfo, dest.plcWeqpVerInfo)) return false;
		if (false == StringUtils.equals(this.plcEqpMdlCd, dest.plcEqpMdlCd)) return false;
		if (false == StringUtils.equals(this.plcWeqpMdlNm, dest.plcWeqpMdlNm)) return false;
		if (false == StringUtils.equals(this.plcMacAddr, dest.plcMacAddr)) return false;
		if (false == StringUtils.equals(this.plcMfactSerNum, dest.plcMfactSerNum)) return false;
		if (false == StringUtils.equals(this.etcWeqpMgmtNum, dest.etcWeqpMgmtNum)) return false;
		if (false == StringUtils.equals(this.etcWeqpVerInfo, dest.etcWeqpVerInfo)) return false;
		if (false == StringUtils.equals(this.etcEqpMdlCd, dest.etcEqpMdlCd)) return false;
		if (false == StringUtils.equals(this.etcWeqpMdlNm, dest.etcWeqpMdlNm)) return false;
		if (false == StringUtils.equals(this.etcMacAddr, dest.etcMacAddr)) return false;
		if (false == StringUtils.equals(this.etcMfactSerNum, dest.etcMfactSerNum)) return false;
		if (false == StringUtils.equals(this.prvShrrMacAddr, dest.prvShrrMacAddr)) return false;
		if (false == StringUtils.equals(this.prvShrrMfactNm, dest.prvShrrMfactNm)) return false;
		if (false == StringUtils.equals(this.prvShrrIpAddr, dest.prvShrrIpAddr)) return false;
		if (false == StringUtils.equals(this.memoCtt, dest.memoCtt)) return false;

		/* ADMAS DB와 BS DB 현황화 작업 및 CATV칼럼 추가 반영 (2025-03-11 by KMY) */
		if (false == StringUtils.equals(this.l2TpoCd, dest.l2TpoCd)) return false;
		if (false == StringUtils.equals(this.setChgSvcDtm, dest.setChgSvcDtm)) return false;
		if (false == StringUtils.equals(this.svcChgSvcDtm, dest.svcChgSvcDtm)) return false;
		if (this.custMultiStbCnt != dest.custMultiStbCnt) return false;
		if (this.svcMultiStbCnt != dest.svcMultiStbCnt) return false;
		if (this.custAddrMultiStbCnt != dest.custAddrMultiStbCnt) return false;
		if (false == StringUtils.equals(this.stbWeqpUiVerInfo, dest.stbWeqpUiVerInfo)) return false;
		if (false == StringUtils.equals(this.l2EquipPortId, dest.l2EquipPortId)) return false;
		if (false == StringUtils.equals(this.l3EquipPortId, dest.l3EquipPortId)) return false;
		if (false == StringUtils.equals(this.svcTpoCd, dest.svcTpoCd)) return false;
		if (false == StringUtils.equals(this.l3RackNum, dest.l3RackNum)) return false;
		if (false == StringUtils.equals(this.l3ShlfNum, dest.l3ShlfNum)) return false;
		if (false == StringUtils.equals(this.l3CardNum, dest.l3CardNum)) return false;
		if (false == StringUtils.equals(this.l2RackNum, dest.l2RackNum)) return false;
		if (false == StringUtils.equals(this.l2ShlfNum, dest.l2ShlfNum)) return false;
		if (false == StringUtils.equals(this.l2CardNum, dest.l2CardNum)) return false;
		if (false == StringUtils.equals(this.onuEquipId, dest.onuEquipId)) return false;
		if (false == StringUtils.equals(this.oltSupEquipId1, dest.oltSupEquipId1)) return false;
		if (false == StringUtils.equals(this.oltSupEquipId2, dest.oltSupEquipId2)) return false;
		if (false == StringUtils.equals(this.homeCntrCd, dest.homeCntrCd)) return false;
		if (false == StringUtils.equals(this.l3TpoCd, dest.l3TpoCd)) return false;
		if (false == StringUtils.equals(this.oltTpoCd1, dest.oltTpoCd1)) return false;
		if (false == StringUtils.equals(this.oltTpoCd2, dest.oltTpoCd2)) return false;
		if (false == StringUtils.equals(this.arTpoCd1, dest.arTpoCd1)) return false;
		if (false == StringUtils.equals(this.arTpoCd2, dest.arTpoCd2)) return false;
		if (false == StringUtils.equals(this.l2BldCd, dest.l2BldCd)) return false;
		if (false == StringUtils.equals(this.l3BldCd, dest.l3BldCd)) return false;
		if (false == StringUtils.equals(this.oltBldCd1, dest.oltBldCd1)) return false;
		if (false == StringUtils.equals(this.oltBldCd2, dest.oltBldCd2)) return false;
		if (false == StringUtils.equals(this.arBldCd1, dest.arBldCd1)) return false;
		if (false == StringUtils.equals(this.arBldCd2, dest.arBldCd2)) return false;
		if (false == StringUtils.equals(this.tvClVal, dest.tvClVal)) return false;
		if (false == StringUtils.equals(this.scrbrTbSoClCd, dest.scrbrTbSoClCd)) return false;
		if (false == StringUtils.equals(this.stbInrCmMacAddr, dest.stbInrCmMacAddr)) return false;
		if (false == StringUtils.equals(this.svcDtlClCd, dest.svcDtlClCd)) return false;

		return true;
	}
}
