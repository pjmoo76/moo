package com.skb.mi.model;

public class OCL29111 {
	private	String	clctDtm;
	private	String	macAddrVal;
	private	String	auditId;
	private	String	netClCd;
	private	String	teamOrgId;
	private	String	infoCntrCd;
	private	String	distbCntrCd;
	private	String	homeCntrCd;
	private	String	l3EquipId;
	private	String	l2EquipId;
	private	String	ccellNum;
	private	String	eqpMdlCd;
	private	String	eqpVerInfo;
	private	long	custNum;
	private	long	inetSvcMgmtNum;
	private	String	ipAddr;
	private	String	dnsIpAddr1;
	private	String	dnsIpAddr2;
	private	String	portSetModeCd;
	private	String	portDplxSetCd;
	private	String	lan1PortMacAddr;
	private	String	lan1PortIpAddr;
	private	String	lan1PortClVal;
	private	String	lan1PortDplxSetCd;
	private	String	lan2PortMacAddr;
	private	String	lan2PortIpAddr;
	private	String	lan2PortClVal;
	private	String	lan2PortDplxSetCd;
	private	String	lan3PortMacAddr;
	private	String	lan3PortIpAddr;
	private	String	lan3PortClVal;
	private	String	lan3PortDplxSetCd;
	private	String	lan4PortMacAddr;
	private	String	lan4PortIpAddr;
	private	String	lan4PortClVal;
	private	String	lan4PortDplxSetCd;
	private	String	wanPortDplxSetCd;

	public String getClctDtm() {
		return clctDtm;
	}
	public void setClctDtm(String clctDtm) {
		this.clctDtm = clctDtm;
	}
	public String getMacAddrVal() {
		return macAddrVal;
	}
	public void setMacAddrVal(String macAddrVal) {
		this.macAddrVal = macAddrVal;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getNetClCd() {
		return netClCd;
	}
	public void setNetClCd(String netClCd) {
		this.netClCd = netClCd;
	}
	public String getTeamOrgId() {
		return teamOrgId;
	}
	public void setTeamOrgId(String teamOrgId) {
		this.teamOrgId = teamOrgId;
	}
	public String getInfoCntrCd() {
		return infoCntrCd;
	}
	public void setInfoCntrCd(String infoCntrCd) {
		this.infoCntrCd = infoCntrCd;
	}
	public String getDistbCntrCd() {
		return distbCntrCd;
	}
	public void setDistbCntrCd(String distbCntrCd) {
		this.distbCntrCd = distbCntrCd;
	}
	public String getHomeCntrCd() {
		return homeCntrCd;
	}
	public void setHomeCntrCd(String homeCntrCd) {
		this.homeCntrCd = homeCntrCd;
	}
	public String getL3EquipId() {
		return l3EquipId;
	}
	public void setL3EquipId(String l3EquipId) {
		this.l3EquipId = l3EquipId;
	}
	public String getL2EquipId() {
		return l2EquipId;
	}
	public void setL2EquipId(String l2EquipId) {
		this.l2EquipId = l2EquipId;
	}
	public String getCcellNum() {
		return ccellNum;
	}
	public void setCcellNum(String ccellNum) {
		this.ccellNum = ccellNum;
	}
	public String getEqpMdlCd() {
		return eqpMdlCd;
	}
	public void setEqpMdlCd(String eqpMdlCd) {
		this.eqpMdlCd = eqpMdlCd;
	}
	public String getEqpVerInfo() {
		return eqpVerInfo;
	}
	public void setEqpVerInfo(String eqpVerInfo) {
		this.eqpVerInfo = eqpVerInfo;
	}
	public long getCustNum() {
		return custNum;
	}
	public void setCustNum(long custNum) {
		this.custNum = custNum;
	}
	public long getInetSvcMgmtNum() {
		return inetSvcMgmtNum;
	}
	public void setInetSvcMgmtNum(long inetSvcMgmtNum) {
		this.inetSvcMgmtNum = inetSvcMgmtNum;
	}
	public String getIpAddr() {
		return ipAddr;
	}
	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}
	public String getDnsIpAddr1() {
		return dnsIpAddr1;
	}
	public void setDnsIpAddr1(String dnsIpAddr1) {
		this.dnsIpAddr1 = dnsIpAddr1;
	}
	public String getDnsIpAddr2() {
		return dnsIpAddr2;
	}
	public void setDnsIpAddr2(String dnsIpAddr2) {
		this.dnsIpAddr2 = dnsIpAddr2;
	}
	public String getPortSetModeCd() {
		return portSetModeCd;
	}
	public void setPortSetModeCd(String portSetModeCd) {
		this.portSetModeCd = portSetModeCd;
	}
	public String getPortDplxSetCd() {
		return portDplxSetCd;
	}
	public void setPortDplxSetCd(String portDplxSetCd) {
		this.portDplxSetCd = portDplxSetCd;
	}
	public String getLan1PortMacAddr() {
		return lan1PortMacAddr;
	}
	public void setLan1PortMacAddr(String lan1PortMacAddr) {
		this.lan1PortMacAddr = lan1PortMacAddr;
	}
	public String getLan1PortIpAddr() {
		return lan1PortIpAddr;
	}
	public void setLan1PortIpAddr(String lan1PortIpAddr) {
		this.lan1PortIpAddr = lan1PortIpAddr;
	}
	public String getLan1PortClVal() {
		return lan1PortClVal;
	}
	public void setLan1PortClVal(String lan1PortClVal) {
		this.lan1PortClVal = lan1PortClVal;
	}
	public String getLan1PortDplxSetCd() {
		return lan1PortDplxSetCd;
	}
	public void setLan1PortDplxSetCd(String lan1PortDplxSetCd) {
		this.lan1PortDplxSetCd = lan1PortDplxSetCd;
	}
	public String getLan2PortMacAddr() {
		return lan2PortMacAddr;
	}
	public void setLan2PortMacAddr(String lan2PortMacAddr) {
		this.lan2PortMacAddr = lan2PortMacAddr;
	}
	public String getLan2PortIpAddr() {
		return lan2PortIpAddr;
	}
	public void setLan2PortIpAddr(String lan2PortIpAddr) {
		this.lan2PortIpAddr = lan2PortIpAddr;
	}
	public String getLan2PortClVal() {
		return lan2PortClVal;
	}
	public void setLan2PortClVal(String lan2PortClVal) {
		this.lan2PortClVal = lan2PortClVal;
	}
	public String getLan2PortDplxSetCd() {
		return lan2PortDplxSetCd;
	}
	public void setLan2PortDplxSetCd(String lan2PortDplxSetCd) {
		this.lan2PortDplxSetCd = lan2PortDplxSetCd;
	}
	public String getLan3PortMacAddr() {
		return lan3PortMacAddr;
	}
	public void setLan3PortMacAddr(String lan3PortMacAddr) {
		this.lan3PortMacAddr = lan3PortMacAddr;
	}
	public String getLan3PortIpAddr() {
		return lan3PortIpAddr;
	}
	public void setLan3PortIpAddr(String lan3PortIpAddr) {
		this.lan3PortIpAddr = lan3PortIpAddr;
	}
	public String getLan3PortClVal() {
		return lan3PortClVal;
	}
	public void setLan3PortClVal(String lan3PortClVal) {
		this.lan3PortClVal = lan3PortClVal;
	}
	public String getLan3PortDplxSetCd() {
		return lan3PortDplxSetCd;
	}
	public void setLan3PortDplxSetCd(String lan3PortDplxSetCd) {
		this.lan3PortDplxSetCd = lan3PortDplxSetCd;
	}
	public String getLan4PortMacAddr() {
		return lan4PortMacAddr;
	}
	public void setLan4PortMacAddr(String lan4PortMacAddr) {
		this.lan4PortMacAddr = lan4PortMacAddr;
	}
	public String getLan4PortIpAddr() {
		return lan4PortIpAddr;
	}
	public void setLan4PortIpAddr(String lan4PortIpAddr) {
		this.lan4PortIpAddr = lan4PortIpAddr;
	}
	public String getLan4PortClVal() {
		return lan4PortClVal;
	}
	public void setLan4PortClVal(String lan4PortClVal) {
		this.lan4PortClVal = lan4PortClVal;
	}
	public String getLan4PortDplxSetCd() {
		return lan4PortDplxSetCd;
	}
	public void setLan4PortDplxSetCd(String lan4PortDplxSetCd) {
		this.lan4PortDplxSetCd = lan4PortDplxSetCd;
	}
	public String getWanPortDplxSetCd() {
		return wanPortDplxSetCd;
	}
	public void setWanPortDplxSetCd(String wanPortDplxSetCd) {
		this.wanPortDplxSetCd = wanPortDplxSetCd;
	}
}
