package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV10301 extends CopyVO {
	private	String	tpoCd;
	private	String	auditId;
	private	String	auditDtm;
	private	String	tpoNm;
	private	String	teamOrgId;
	private	String	teamOrgNm;
	private	String	mktDivOrgId;
	private	String	mktDivOrgNm;
	private	String	useYn;
	private	String	scrnDispSeq;
	private	String	hfcMgmtTeamCd;
	
	private	String	rangeTpoCd;
	
	public String getTpoCd() {
		return tpoCd;
	}
	public void setTpoCd(String tpoCd) {
		this.tpoCd = tpoCd;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getTpoNm() {
		return tpoNm;
	}
	public void setTpoNm(String tpoNm) {
		this.tpoNm = tpoNm;
	}
	public String getTeamOrgId() {
		return teamOrgId;
	}
	public void setTeamOrgId(String teamOrgId) {
		this.teamOrgId = teamOrgId;
	}
	public String getTeamOrgNm() {
		return teamOrgNm;
	}
	public void setTeamOrgNm(String teamOrgNm) {
		this.teamOrgNm = teamOrgNm;
	}
	public String getMktDivOrgId() {
		return mktDivOrgId;
	}
	public void setMktDivOrgId(String mktDivOrgId) {
		this.mktDivOrgId = mktDivOrgId;
	}
	public String getMktDivOrgNm() {
		return mktDivOrgNm;
	}
	public void setMktDivOrgNm(String mktDivOrgNm) {
		this.mktDivOrgNm = mktDivOrgNm;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	public String getScrnDispSeq() {
		return scrnDispSeq;
	}
	public void setScrnDispSeq(String scrnDispSeq) {
		this.scrnDispSeq = scrnDispSeq;
	}
	public String getHfcMgmtTeamCd() {
		return hfcMgmtTeamCd;
	}
	public void setHfcMgmtTeamCd(String hfcMgmtTeamCd) {
		this.hfcMgmtTeamCd = hfcMgmtTeamCd;
	}
	@Override
	public void setKey() {
		this.key = this.tpoCd;
	}
	@Override
	public boolean equals(CopyVO obj) {
		OIV10301 dest = (OIV10301) obj;
		if (false == StringUtils.equals(this.tpoCd, dest.tpoCd)) return false;
		if (false == StringUtils.equals(this.tpoNm, dest.tpoNm)) return false;
		if (false == StringUtils.equals(this.teamOrgId, dest.teamOrgId)) return false;
		if (false == StringUtils.equals(this.teamOrgNm, dest.teamOrgNm)) return false;
		if (false == StringUtils.equals(this.mktDivOrgId, dest.mktDivOrgId)) return false;
		if (false == StringUtils.equals(this.mktDivOrgNm, dest.mktDivOrgNm)) return false;
		if (false == StringUtils.equals(this.useYn, dest.useYn)) return false;
		if (false == StringUtils.equals(this.scrnDispSeq, dest.scrnDispSeq)) return false;
		if (false == StringUtils.equals(this.hfcMgmtTeamCd, dest.hfcMgmtTeamCd)) return false;
		return true;
	}
	@Override
	public void setRange(CopyVO obj) {
		OIV10301 src = (OIV10301) obj;
		this.rangeTpoCd = src.getTpoCd();
	}
	public String getRangeTpoCd() {
		return rangeTpoCd;
	}
	public void setRangeTpoCd(String rangeTpoCd) {
		this.rangeTpoCd = rangeTpoCd;
	}
}
