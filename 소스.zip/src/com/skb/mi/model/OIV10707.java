package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV10707 extends CopyVO {
	private	String	supWeqpGrpCd;
	private	String	auditId;
	private	String	auditDtm;
	private	String	weqpMdlTypCd;
	private	String	rangeSupWeqpGrpCd;

	public String getSupWeqpGrpCd() {
		return supWeqpGrpCd;
	}
	public void setSupWeqpGrpCd(String supWeqpGrpCd) {
		this.supWeqpGrpCd = supWeqpGrpCd;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getWeqpMdlTypCd() {
		return weqpMdlTypCd;
	}
	public void setWeqpMdlTypCd(String weqpMdlTypCd) {
		this.weqpMdlTypCd = weqpMdlTypCd;
	}
	public String getRangeSupWeqpGrpCd() {
		return rangeSupWeqpGrpCd;
	}
	public void setRangeSupWeqpGrpCd(String rangeSupWeqpGrpCd) {
		this.rangeSupWeqpGrpCd = rangeSupWeqpGrpCd;
	}
	@Override
	public void setKey() {
		this.key = this.supWeqpGrpCd;
	}
	@Override
	public boolean equals(CopyVO obj) {
		OIV10707 dest = (OIV10707) obj;
		if (false == StringUtils.equals(this.supWeqpGrpCd, dest.supWeqpGrpCd)) return false;
		if (false == StringUtils.equals(this.auditId, dest.auditId)) return false;
		if (false == StringUtils.equals(this.auditDtm, dest.auditDtm)) return false;
		if (false == StringUtils.equals(this.weqpMdlTypCd, dest.weqpMdlTypCd)) return false;
		return true;
	}
	@Override
	public void setRange(CopyVO obj) {
		OIV10707 src = (OIV10707) obj;
		this.rangeSupWeqpGrpCd = src.supWeqpGrpCd;
	}
}
