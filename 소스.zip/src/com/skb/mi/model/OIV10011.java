package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV10011 extends CopyVO {

	private	String	equipId;
	private	String	auditId;
	private	String	auditDtm;
	private	String	repEquipPortId;
	private	String	equipChrgrCntcPlcInfo;
	private	long	equipSvcCnt;
	private	String	rgstDtm;
	private	String	clctSvrClCd;
	private	String	snmpEngnDtm;
	private	String	dfltUseYn;
	private	String	autoSetYn;
	private	long	snmpCntrStVal;
	private	String	hstMgmtYn;
	private	String	thrsUseYn;
	private	String	prfmDablMgmtYn;
	private	long	prfmClctCycl;
	private	String	pwdActvnYn;
	private	String	bkDtm;
	private	String	sshUseYn;
	private	String	recntConnDtm;
	private	String	loginRsltCd;
	private	String	mngrId;
	private	String	tftpBkDtm;
	private	String	bkRsltMsgCtt;
	private	String	qltyMntrYn;
	private	String	lineNumClctYn;
	private	String	linkEquipNm;
	private	String	trmsNetEquipCapaClCd;
	private	String	egovBbYn;
	private	String	egovBbTypCd;
	private	String	aonYn;
	private	String	netMgmtCoCd;
	private	String	netMgmtCoOrgId;
	private	String	fcltMgmtIpAddr;
	private	String	fcltMgmtEquipOpenDt;
	private	long	dcnNum;
	private	String	chgOperSchdYn;
	private	String	fcltMgmtEquipChgDtm;
	private	String	remvlYn;
	private	String	iequipNetClCd;
	private	String	nmsEquipTidVal;
	
	private	String	rangeEquipId;

	public String getEquipId() {
		return equipId;
	}
	public void setEquipId(String equipId) {
		this.equipId = equipId;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getRepEquipPortId() {
		return repEquipPortId;
	}
	public void setRepEquipPortId(String repEquipPortId) {
		this.repEquipPortId = repEquipPortId;
	}
	public String getEquipChrgrCntcPlcInfo() {
		return equipChrgrCntcPlcInfo;
	}
	public void setEquipChrgrCntcPlcInfo(String equipChrgrCntcPlcInfo) {
		this.equipChrgrCntcPlcInfo = equipChrgrCntcPlcInfo;
	}
	public long getEquipSvcCnt() {
		return equipSvcCnt;
	}
	public void setEquipSvcCnt(long equipSvcCnt) {
		this.equipSvcCnt = equipSvcCnt;
	}
	public String getRgstDtm() {
		return rgstDtm;
	}
	public void setRgstDtm(String rgstDtm) {
		this.rgstDtm = rgstDtm;
	}
	public String getClctSvrClCd() {
		return clctSvrClCd;
	}
	public void setClctSvrClCd(String clctSvrClCd) {
		this.clctSvrClCd = clctSvrClCd;
	}
	public String getSnmpEngnDtm() {
		return snmpEngnDtm;
	}
	public void setSnmpEngnDtm(String snmpEngnDtm) {
		this.snmpEngnDtm = snmpEngnDtm;
	}
	public String getDfltUseYn() {
		return dfltUseYn;
	}
	public void setDfltUseYn(String dfltUseYn) {
		this.dfltUseYn = dfltUseYn;
	}
	public String getAutoSetYn() {
		return autoSetYn;
	}
	public void setAutoSetYn(String autoSetYn) {
		this.autoSetYn = autoSetYn;
	}
	public long getSnmpCntrStVal() {
		return snmpCntrStVal;
	}
	public void setSnmpCntrStVal(long snmpCntrStVal) {
		this.snmpCntrStVal = snmpCntrStVal;
	}
	public String getHstMgmtYn() {
		return hstMgmtYn;
	}
	public void setHstMgmtYn(String hstMgmtYn) {
		this.hstMgmtYn = hstMgmtYn;
	}
	public String getThrsUseYn() {
		return thrsUseYn;
	}
	public void setThrsUseYn(String thrsUseYn) {
		this.thrsUseYn = thrsUseYn;
	}
	public String getPrfmDablMgmtYn() {
		return prfmDablMgmtYn;
	}
	public void setPrfmDablMgmtYn(String prfmDablMgmtYn) {
		this.prfmDablMgmtYn = prfmDablMgmtYn;
	}
	public long getPrfmClctCycl() {
		return prfmClctCycl;
	}
	public void setPrfmClctCycl(long prfmClctCycl) {
		this.prfmClctCycl = prfmClctCycl;
	}
	public String getPwdActvnYn() {
		return pwdActvnYn;
	}
	public void setPwdActvnYn(String pwdActvnYn) {
		this.pwdActvnYn = pwdActvnYn;
	}
	public String getBkDtm() {
		return bkDtm;
	}
	public void setBkDtm(String bkDtm) {
		this.bkDtm = bkDtm;
	}
	public String getSshUseYn() {
		return sshUseYn;
	}
	public void setSshUseYn(String sshUseYn) {
		this.sshUseYn = sshUseYn;
	}
	public String getRecntConnDtm() {
		return recntConnDtm;
	}
	public void setRecntConnDtm(String recntConnDtm) {
		this.recntConnDtm = recntConnDtm;
	}
	public String getLoginRsltCd() {
		return loginRsltCd;
	}
	public void setLoginRsltCd(String loginRsltCd) {
		this.loginRsltCd = loginRsltCd;
	}
	public String getMngrId() {
		return mngrId;
	}
	public void setMngrId(String mngrId) {
		this.mngrId = mngrId;
	}
	public String getTftpBkDtm() {
		return tftpBkDtm;
	}
	public void setTftpBkDtm(String tftpBkDtm) {
		this.tftpBkDtm = tftpBkDtm;
	}
	public String getBkRsltMsgCtt() {
		return bkRsltMsgCtt;
	}
	public void setBkRsltMsgCtt(String bkRsltMsgCtt) {
		this.bkRsltMsgCtt = bkRsltMsgCtt;
	}
	public String getQltyMntrYn() {
		return qltyMntrYn;
	}
	public void setQltyMntrYn(String qltyMntrYn) {
		this.qltyMntrYn = qltyMntrYn;
	}
	public String getLineNumClctYn() {
		return lineNumClctYn;
	}
	public void setLineNumClctYn(String lineNumClctYn) {
		this.lineNumClctYn = lineNumClctYn;
	}
	public String getLinkEquipNm() {
		return linkEquipNm;
	}
	public void setLinkEquipNm(String linkEquipNm) {
		this.linkEquipNm = linkEquipNm;
	}
	public String getTrmsNetEquipCapaClCd() {
		return trmsNetEquipCapaClCd;
	}
	public void setTrmsNetEquipCapaClCd(String trmsNetEquipCapaClCd) {
		this.trmsNetEquipCapaClCd = trmsNetEquipCapaClCd;
	}
	public String getEgovBbYn() {
		return egovBbYn;
	}
	public void setEgovBbYn(String egovBbYn) {
		this.egovBbYn = egovBbYn;
	}
	public String getEgovBbTypCd() {
		return egovBbTypCd;
	}
	public void setEgovBbTypCd(String egovBbTypCd) {
		this.egovBbTypCd = egovBbTypCd;
	}
	public String getAonYn() {
		return aonYn;
	}
	public void setAonYn(String aonYn) {
		this.aonYn = aonYn;
	}
	public String getNetMgmtCoCd() {
		return netMgmtCoCd;
	}
	public void setNetMgmtCoCd(String netMgmtCoCd) {
		this.netMgmtCoCd = netMgmtCoCd;
	}
	public String getNetMgmtCoOrgId() {
		return netMgmtCoOrgId;
	}
	public void setNetMgmtCoOrgId(String netMgmtCoOrgId) {
		this.netMgmtCoOrgId = netMgmtCoOrgId;
	}
	public String getFcltMgmtIpAddr() {
		return fcltMgmtIpAddr;
	}
	public void setFcltMgmtIpAddr(String fcltMgmtIpAddr) {
		this.fcltMgmtIpAddr = fcltMgmtIpAddr;
	}
	public String getFcltMgmtEquipOpenDt() {
		return fcltMgmtEquipOpenDt;
	}
	public void setFcltMgmtEquipOpenDt(String fcltMgmtEquipOpenDt) {
		this.fcltMgmtEquipOpenDt = fcltMgmtEquipOpenDt;
	}
	public long getDcnNum() {
		return dcnNum;
	}
	public void setDcnNum(long dcnNum) {
		this.dcnNum = dcnNum;
	}
	public String getChgOperSchdYn() {
		return chgOperSchdYn;
	}
	public void setChgOperSchdYn(String chgOperSchdYn) {
		this.chgOperSchdYn = chgOperSchdYn;
	}
	public String getFcltMgmtEquipChgDtm() {
		return fcltMgmtEquipChgDtm;
	}
	public void setFcltMgmtEquipChgDtm(String fcltMgmtEquipChgDtm) {
		this.fcltMgmtEquipChgDtm = fcltMgmtEquipChgDtm;
	}
	public String getRemvlYn() {
		return remvlYn;
	}
	public void setRemvlYn(String remvlYn) {
		this.remvlYn = remvlYn;
	}
	public String getIequipNetClCd() {
		return iequipNetClCd;
	}
	public void setIequipNetClCd(String iequipNetClCd) {
		this.iequipNetClCd = iequipNetClCd;
	}
	public String getNmsEquipTidVal() {
		return nmsEquipTidVal;
	}
	public void setNmsEquipTidVal(String nmsEquipTidVal) {
		this.nmsEquipTidVal = nmsEquipTidVal;
	}
	public String getRangeEquipId() {
		return rangeEquipId;
	}
	public void setRangeEquipId(String rangeEquipId) {
		this.rangeEquipId = rangeEquipId;
	}

	@Override
	public void setKey() {
		this.key = this.equipId;
	}

	@Override
	public boolean equals(CopyVO obj) {
		OIV10011 dest = (OIV10011) obj;
		if (false == StringUtils.equals(this.equipId, dest.equipId)) return false;
		if (false == StringUtils.equals(this.auditId, dest.auditId)) return false;
		if (false == StringUtils.equals(this.auditDtm, dest.auditDtm)) return false;
		if (false == StringUtils.equals(this.repEquipPortId, dest.repEquipPortId)) return false;
		if (false == StringUtils.equals(this.equipChrgrCntcPlcInfo, dest.equipChrgrCntcPlcInfo)) return false;
		if (this.equipSvcCnt != dest.equipSvcCnt) return false;
		if (false == StringUtils.equals(this.rgstDtm, dest.rgstDtm)) return false;
		if (false == StringUtils.equals(this.clctSvrClCd, dest.clctSvrClCd)) return false;
		if (false == StringUtils.equals(this.snmpEngnDtm, dest.snmpEngnDtm)) return false;
		if (false == StringUtils.equals(this.dfltUseYn, dest.dfltUseYn)) return false;
		if (false == StringUtils.equals(this.autoSetYn, dest.autoSetYn)) return false;
		if (this.snmpCntrStVal != dest.snmpCntrStVal) return false;
		if (false == StringUtils.equals(this.hstMgmtYn, dest.hstMgmtYn)) return false;
		if (false == StringUtils.equals(this.thrsUseYn, dest.thrsUseYn)) return false;
		if (false == StringUtils.equals(this.prfmDablMgmtYn, dest.prfmDablMgmtYn)) return false;
		if (this.prfmClctCycl != dest.prfmClctCycl) return false;
		if (false == StringUtils.equals(this.pwdActvnYn, dest.pwdActvnYn)) return false;
		if (false == StringUtils.equals(this.bkDtm, dest.bkDtm)) return false;
		if (false == StringUtils.equals(this.sshUseYn, dest.sshUseYn)) return false;
		if (false == StringUtils.equals(this.recntConnDtm, dest.recntConnDtm)) return false;
		if (false == StringUtils.equals(this.loginRsltCd, dest.loginRsltCd)) return false;
		if (false == StringUtils.equals(this.mngrId, dest.mngrId)) return false;
		if (false == StringUtils.equals(this.tftpBkDtm, dest.tftpBkDtm)) return false;
		if (false == StringUtils.equals(this.bkRsltMsgCtt, dest.bkRsltMsgCtt)) return false;
		if (false == StringUtils.equals(this.qltyMntrYn, dest.qltyMntrYn)) return false;
		if (false == StringUtils.equals(this.lineNumClctYn, dest.lineNumClctYn)) return false;
		if (false == StringUtils.equals(this.linkEquipNm, dest.linkEquipNm)) return false;
		if (false == StringUtils.equals(this.trmsNetEquipCapaClCd, dest.trmsNetEquipCapaClCd)) return false;
		if (false == StringUtils.equals(this.egovBbYn, dest.egovBbYn)) return false;
		if (false == StringUtils.equals(this.egovBbTypCd, dest.egovBbTypCd)) return false;
		if (false == StringUtils.equals(this.aonYn, dest.aonYn)) return false;
		if (false == StringUtils.equals(this.netMgmtCoCd, dest.netMgmtCoCd)) return false;
		if (false == StringUtils.equals(this.netMgmtCoOrgId, dest.netMgmtCoOrgId)) return false;
		if (false == StringUtils.equals(this.fcltMgmtIpAddr, dest.fcltMgmtIpAddr)) return false;
		if (false == StringUtils.equals(this.fcltMgmtEquipOpenDt, dest.fcltMgmtEquipOpenDt)) return false;
		if (this.dcnNum != dest.dcnNum) return false;
		if (false == StringUtils.equals(this.chgOperSchdYn, dest.chgOperSchdYn)) return false;
		if (false == StringUtils.equals(this.fcltMgmtEquipChgDtm, dest.fcltMgmtEquipChgDtm)) return false;
		if (false == StringUtils.equals(this.remvlYn, dest.remvlYn)) return false;
		if (false == StringUtils.equals(this.iequipNetClCd, dest.iequipNetClCd)) return false;
		if (false == StringUtils.equals(this.nmsEquipTidVal, dest.nmsEquipTidVal)) return false;
		return true;
	}

	@Override
	public void setRange(CopyVO obj) {
		OIV10011 dest = (OIV10011) obj;
		this.rangeEquipId = dest.equipId;
	}

}
