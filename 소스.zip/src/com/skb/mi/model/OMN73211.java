package com.skb.mi.model;

public class OMN73211 extends AggrDataVO {
	private	String	apMacAddr;
	private	String	mntrDthms;
	private	String	auditId;
	private	int	eqpUptimeCnt;
	private	int	wanCrcOccrCnt;
	private	int	lan1CrcOccrCnt;
	private	int	lan2CrcOccrCnt;
	private	int	lan3CrcOccrCnt;
	private	int	lan4CrcOccrCnt;

	public String getApMacAddr() {
		return apMacAddr;
	}
	public void setApMacAddr(String apMacAddr) {
		this.apMacAddr = apMacAddr;
	}
	public String getMntrDthms() {
		return mntrDthms;
	}
	public void setMntrDthms(String mntrDthms) {
		this.mntrDthms = mntrDthms;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public int getEqpUptimeCnt() {
		return eqpUptimeCnt;
	}
	public void setEqpUptimeCnt(int eqpUptimeCnt) {
		this.eqpUptimeCnt = eqpUptimeCnt;
	}
	public int getWanCrcOccrCnt() {
		return wanCrcOccrCnt;
	}
	public void setWanCrcOccrCnt(int wanCrcOccrCnt) {
		this.wanCrcOccrCnt = wanCrcOccrCnt;
	}
	public int getLan1CrcOccrCnt() {
		return lan1CrcOccrCnt;
	}
	public void setLan1CrcOccrCnt(int lan1CrcOccrCnt) {
		this.lan1CrcOccrCnt = lan1CrcOccrCnt;
	}
	public int getLan2CrcOccrCnt() {
		return lan2CrcOccrCnt;
	}
	public void setLan2CrcOccrCnt(int lan2CrcOccrCnt) {
		this.lan2CrcOccrCnt = lan2CrcOccrCnt;
	}
	public int getLan3CrcOccrCnt() {
		return lan3CrcOccrCnt;
	}
	public void setLan3CrcOccrCnt(int lan3CrcOccrCnt) {
		this.lan3CrcOccrCnt = lan3CrcOccrCnt;
	}
	public int getLan4CrcOccrCnt() {
		return lan4CrcOccrCnt;
	}
	public void setLan4CrcOccrCnt(int lan4CrcOccrCnt) {
		this.lan4CrcOccrCnt = lan4CrcOccrCnt;
	}
	@Override
	public boolean isValid() {
		return true;
	}
	@Override
	public String toDelimiterString() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void add(AggrDataVO obj) {
		// TODO Auto-generated method stub
		
	}
}
