package com.skb.mi.model;

import com.skb.mi.common.StringUtils;


public class OCO10100 extends CopyVO {
	private	String	userId;
	private	String	auditId;
	private	String	auditDtm;
	private	String	loginPwd;
	private	String	userNm;
	private	String	orgId;
	private	String	useYn;
	private	String	infoCntrCd;
	private	String	chrgrId;
	private	String	chrgrNm;
	private	String	phonNum;
	private	String	emailAddr;
	private	String	effStaDtm;
	private	String	effEndDtm;
	private	String	reqDtm;
	private	String	bfPwd;
	private	String	desiSetClCd;
	private	int		atfilSerNum;
	private	String	coNm;
	private	String	skbUserYn;
	private	String	bfLoginPwd;
	private	String	pwdChgDtm;
	private	String	mntgAcntRgstrId;
	
	private	String	rangeUserId;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getLoginPwd() {
		return loginPwd;
	}
	public void setLoginPwd(String loginPwd) {
		this.loginPwd = loginPwd;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	public String getInfoCntrCd() {
		return infoCntrCd;
	}
	public void setInfoCntrCd(String infoCntrCd) {
		this.infoCntrCd = infoCntrCd;
	}
	public String getChrgrId() {
		return chrgrId;
	}
	public void setChrgrId(String chrgrId) {
		this.chrgrId = chrgrId;
	}
	public String getChrgrNm() {
		return chrgrNm;
	}
	public void setChrgrNm(String chrgrNm) {
		this.chrgrNm = chrgrNm;
	}
	public String getPhonNum() {
		return phonNum;
	}
	public void setPhonNum(String phonNum) {
		this.phonNum = phonNum;
	}
	public String getEmailAddr() {
		return emailAddr;
	}
	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}
	public String getEffStaDtm() {
		return effStaDtm;
	}
	public void setEffStaDtm(String effStaDtm) {
		this.effStaDtm = effStaDtm;
	}
	public String getEffEndDtm() {
		return effEndDtm;
	}
	public void setEffEndDtm(String effEndDtm) {
		this.effEndDtm = effEndDtm;
	}
	public String getReqDtm() {
		return reqDtm;
	}
	public void setReqDtm(String reqDtm) {
		this.reqDtm = reqDtm;
	}
	public String getBfPwd() {
		return bfPwd;
	}
	public void setBfPwd(String bfPwd) {
		this.bfPwd = bfPwd;
	}
	public String getDesiSetClCd() {
		return desiSetClCd;
	}
	public void setDesiSetClCd(String desiSetClCd) {
		this.desiSetClCd = desiSetClCd;
	}
	public int getAtfilSerNum() {
		return atfilSerNum;
	}
	public void setAtfilSerNum(int atfilSerNum) {
		this.atfilSerNum = atfilSerNum;
	}
	public String getCoNm() {
		return coNm;
	}
	public void setCoNm(String coNm) {
		this.coNm = coNm;
	}
	public String getSkbUserYn() {
		return skbUserYn;
	}
	public void setSkbUserYn(String skbUserYn) {
		this.skbUserYn = skbUserYn;
	}
	public String getBfLoginPwd() {
		return bfLoginPwd;
	}
	public void setBfLoginPwd(String bfLoginPwd) {
		this.bfLoginPwd = bfLoginPwd;
	}
	public String getPwdChgDtm() {
		return pwdChgDtm;
	}
	public void setPwdChgDtm(String pwdChgDtm) {
		this.pwdChgDtm = pwdChgDtm;
	}
	public String getMntgAcntRgstrId() {
		return mntgAcntRgstrId;
	}
	public void setMntgAcntRgstrId(String mntgAcntRgstrId) {
		this.mntgAcntRgstrId = mntgAcntRgstrId;
	}
	@Override
	public void setKey() {
		this.key = this.userId;
	}
	@Override
	public boolean equals(CopyVO obj) {
		OCO10100 dest = (OCO10100) obj;
		if (false == StringUtils.equals(this.userId, dest.userId)) return false;
		if (false == StringUtils.equals(this.loginPwd, dest.loginPwd)) return false;
		if (false == StringUtils.equals(this.userNm, dest.userNm)) return false;
		if (false == StringUtils.equals(this.orgId, dest.orgId)) return false;
		if (false == StringUtils.equals(this.useYn, dest.useYn)) return false;
		if (false == StringUtils.equals(this.infoCntrCd, dest.infoCntrCd)) return false;
		if (false == StringUtils.equals(this.chrgrId, dest.chrgrId)) return false;
		if (false == StringUtils.equals(this.chrgrNm, dest.chrgrNm)) return false;
		if (false == StringUtils.equals(this.phonNum, dest.phonNum)) return false;
		if (false == StringUtils.equals(this.emailAddr, dest.emailAddr)) return false;
		if (false == StringUtils.equals(this.effStaDtm, dest.effStaDtm)) return false;
		if (false == StringUtils.equals(this.effEndDtm, dest.effEndDtm)) return false;
		if (false == StringUtils.equals(this.reqDtm, dest.reqDtm)) return false;
		if (false == StringUtils.equals(this.bfPwd, dest.bfPwd)) return false;
		if (false == StringUtils.equals(this.desiSetClCd, dest.desiSetClCd)) return false;
		if (this.atfilSerNum != dest.atfilSerNum) return false;
		if (false == StringUtils.equals(this.coNm, dest.coNm)) return false;
		if (false == StringUtils.equals(this.skbUserYn, dest.skbUserYn)) return false;
		if (false == StringUtils.equals(this.bfLoginPwd, dest.bfLoginPwd)) return false;
		if (false == StringUtils.equals(this.pwdChgDtm, dest.pwdChgDtm)) return false;
		if (false == StringUtils.equals(this.mntgAcntRgstrId, dest.mntgAcntRgstrId)) return false;
		return true;
	}

	public String getRangeUserId() {
		return rangeUserId;
	}
	public void setRangeUserId(String rangeUserId) {
		this.rangeUserId = rangeUserId;
	}

	@Override
	public void setRange(CopyVO obj) {
		OCO10100 src = (OCO10100) obj;
		this.rangeUserId = src.userId;
	}
}
