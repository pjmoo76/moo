package com.skb.mi.model;

public class OIV10872 {
	private	String	apMacAddr;
	private	String	auditId;
	private	String	auditDtm;
	private	String	dnsIpAddr1;
	private	String	dnsIpAddr2;
	private	String	portSetModeCd;
	private	String	easyMeshModeVal;
	private	String	wanPortDplxSetCd;
	private	String	wanBandwCtt;
	private	String	lan1PortMacAddr;
	private	String	lan1PortIpAddr;
	private	String	lan1PortClVal;
	private	String	lan1PortDplxSetCd;
	private	String	lan1BandwCtt;
	private	String	lan1PortMfactNm;
	private	String	lan2PortMacAddr;
	private	String	lan2PortIpAddr;
	private	String	lan2PortClVal;
	private	String	lan2PortDplxSetCd;
	private	String	lan2BandwCtt;
	private	String	lan2PortMfactNm;
	private	String	lan3PortMacAddr;
	private	String	lan3PortIpAddr;
	private	String	lan3PortClVal;
	private	String	lan3PortDplxSetCd;
	private	String	lan3BandwCtt;
	private	String	lan3PortMfactNm;
	private	String	lan4PortMacAddr;
	private	String	lan4PortIpAddr;
	private	String	lan4PortClVal;
	private	String	lan4PortDplxSetCd;
	private	String	lan4BandwCtt;
	private	String	lan4PortMfactNm;
	private	String	portInfoUpdDtm;
	public String getApMacAddr() {
		return apMacAddr;
	}
	public void setApMacAddr(String apMacAddr) {
		this.apMacAddr = apMacAddr;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getDnsIpAddr1() {
		return dnsIpAddr1;
	}
	public void setDnsIpAddr1(String dnsIpAddr1) {
		this.dnsIpAddr1 = dnsIpAddr1;
	}
	public String getDnsIpAddr2() {
		return dnsIpAddr2;
	}
	public void setDnsIpAddr2(String dnsIpAddr2) {
		this.dnsIpAddr2 = dnsIpAddr2;
	}
	public String getPortSetModeCd() {
		return portSetModeCd;
	}
	public void setPortSetModeCd(String portSetModeCd) {
		this.portSetModeCd = portSetModeCd;
	}
	public String getEasyMeshModeVal() {
		return easyMeshModeVal;
	}
	public void setEasyMeshModeVal(String easyMeshModeVal) {
		this.easyMeshModeVal = easyMeshModeVal;
	}
	public String getWanPortDplxSetCd() {
		return wanPortDplxSetCd;
	}
	public void setWanPortDplxSetCd(String wanPortDplxSetCd) {
		this.wanPortDplxSetCd = wanPortDplxSetCd;
	}
	public String getWanBandwCtt() {
		return wanBandwCtt;
	}
	public void setWanBandwCtt(String wanBandwCtt) {
		this.wanBandwCtt = wanBandwCtt;
	}
	public String getLan1PortMacAddr() {
		return lan1PortMacAddr;
	}
	public void setLan1PortMacAddr(String lan1PortMacAddr) {
		this.lan1PortMacAddr = lan1PortMacAddr;
	}
	public String getLan1PortIpAddr() {
		return lan1PortIpAddr;
	}
	public void setLan1PortIpAddr(String lan1PortIpAddr) {
		this.lan1PortIpAddr = lan1PortIpAddr;
	}
	public String getLan1PortClVal() {
		return lan1PortClVal;
	}
	public void setLan1PortClVal(String lan1PortClVal) {
		this.lan1PortClVal = lan1PortClVal;
	}
	public String getLan1PortDplxSetCd() {
		return lan1PortDplxSetCd;
	}
	public void setLan1PortDplxSetCd(String lan1PortDplxSetCd) {
		this.lan1PortDplxSetCd = lan1PortDplxSetCd;
	}
	public String getLan1BandwCtt() {
		return lan1BandwCtt;
	}
	public void setLan1BandwCtt(String lan1BandwCtt) {
		this.lan1BandwCtt = lan1BandwCtt;
	}
	public String getLan1PortMfactNm() {
		return lan1PortMfactNm;
	}
	public void setLan1PortMfactNm(String lan1PortMfactNm) {
		this.lan1PortMfactNm = lan1PortMfactNm;
	}
	public String getLan2PortMacAddr() {
		return lan2PortMacAddr;
	}
	public void setLan2PortMacAddr(String lan2PortMacAddr) {
		this.lan2PortMacAddr = lan2PortMacAddr;
	}
	public String getLan2PortIpAddr() {
		return lan2PortIpAddr;
	}
	public void setLan2PortIpAddr(String lan2PortIpAddr) {
		this.lan2PortIpAddr = lan2PortIpAddr;
	}
	public String getLan2PortClVal() {
		return lan2PortClVal;
	}
	public void setLan2PortClVal(String lan2PortClVal) {
		this.lan2PortClVal = lan2PortClVal;
	}
	public String getLan2PortDplxSetCd() {
		return lan2PortDplxSetCd;
	}
	public void setLan2PortDplxSetCd(String lan2PortDplxSetCd) {
		this.lan2PortDplxSetCd = lan2PortDplxSetCd;
	}
	public String getLan2BandwCtt() {
		return lan2BandwCtt;
	}
	public void setLan2BandwCtt(String lan2BandwCtt) {
		this.lan2BandwCtt = lan2BandwCtt;
	}
	public String getLan2PortMfactNm() {
		return lan2PortMfactNm;
	}
	public void setLan2PortMfactNm(String lan2PortMfactNm) {
		this.lan2PortMfactNm = lan2PortMfactNm;
	}
	public String getLan3PortMacAddr() {
		return lan3PortMacAddr;
	}
	public void setLan3PortMacAddr(String lan3PortMacAddr) {
		this.lan3PortMacAddr = lan3PortMacAddr;
	}
	public String getLan3PortIpAddr() {
		return lan3PortIpAddr;
	}
	public void setLan3PortIpAddr(String lan3PortIpAddr) {
		this.lan3PortIpAddr = lan3PortIpAddr;
	}
	public String getLan3PortClVal() {
		return lan3PortClVal;
	}
	public void setLan3PortClVal(String lan3PortClVal) {
		this.lan3PortClVal = lan3PortClVal;
	}
	public String getLan3PortDplxSetCd() {
		return lan3PortDplxSetCd;
	}
	public void setLan3PortDplxSetCd(String lan3PortDplxSetCd) {
		this.lan3PortDplxSetCd = lan3PortDplxSetCd;
	}
	public String getLan3BandwCtt() {
		return lan3BandwCtt;
	}
	public void setLan3BandwCtt(String lan3BandwCtt) {
		this.lan3BandwCtt = lan3BandwCtt;
	}
	public String getLan3PortMfactNm() {
		return lan3PortMfactNm;
	}
	public void setLan3PortMfactNm(String lan3PortMfactNm) {
		this.lan3PortMfactNm = lan3PortMfactNm;
	}
	public String getLan4PortMacAddr() {
		return lan4PortMacAddr;
	}
	public void setLan4PortMacAddr(String lan4PortMacAddr) {
		this.lan4PortMacAddr = lan4PortMacAddr;
	}
	public String getLan4PortIpAddr() {
		return lan4PortIpAddr;
	}
	public void setLan4PortIpAddr(String lan4PortIpAddr) {
		this.lan4PortIpAddr = lan4PortIpAddr;
	}
	public String getLan4PortClVal() {
		return lan4PortClVal;
	}
	public void setLan4PortClVal(String lan4PortClVal) {
		this.lan4PortClVal = lan4PortClVal;
	}
	public String getLan4PortDplxSetCd() {
		return lan4PortDplxSetCd;
	}
	public void setLan4PortDplxSetCd(String lan4PortDplxSetCd) {
		this.lan4PortDplxSetCd = lan4PortDplxSetCd;
	}
	public String getLan4BandwCtt() {
		return lan4BandwCtt;
	}
	public void setLan4BandwCtt(String lan4BandwCtt) {
		this.lan4BandwCtt = lan4BandwCtt;
	}
	public String getLan4PortMfactNm() {
		return lan4PortMfactNm;
	}
	public void setLan4PortMfactNm(String lan4PortMfactNm) {
		this.lan4PortMfactNm = lan4PortMfactNm;
	}
	public String getPortInfoUpdDtm() {
		return portInfoUpdDtm;
	}
	public void setPortInfoUpdDtm(String portInfoUpdDtm) {
		this.portInfoUpdDtm = portInfoUpdDtm;
	}
	
	
	
}
