package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV10170 extends CopyVO {
	private	String	ccellId;
	private	String	auditId;
	private	String	auditDtm;
	private	String	equipId;
	private	String	ccellNum;
	private	String	operTpoCd;
	private	String	netClCd;
	private	String	delYn;

	private	String	rangeCcellId;
	
	public String getCcellId() {
		return ccellId;
	}
	public void setCcellId(String ccellId) {
		this.ccellId = ccellId;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getEquipId() {
		return equipId;
	}
	public void setEquipId(String equipId) {
		this.equipId = equipId;
	}
	public String getCcellNum() {
		return ccellNum;
	}
	public void setCcellNum(String ccellNum) {
		this.ccellNum = ccellNum;
	}
	public String getOperTpoCd() {
		return operTpoCd;
	}
	public void setOperTpoCd(String operTpoCd) {
		this.operTpoCd = operTpoCd;
	}
	public String getNetClCd() {
		return netClCd;
	}
	public void setNetClCd(String netClCd) {
		this.netClCd = netClCd;
	}
	public String getDelYn() {
		return delYn;
	}
	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}
	@Override
	public boolean equals(CopyVO obj) {
		OIV10170 dest = (OIV10170) obj;
		if (false == StringUtils.equals(this.ccellId, dest.ccellId)) return false;
		if (false == StringUtils.equals(this.equipId, dest.equipId)) return false;
		if (false == StringUtils.equals(this.ccellNum, dest.ccellNum)) return false;
		if (false == StringUtils.equals(this.operTpoCd, dest.operTpoCd)) return false;
		if (false == StringUtils.equals(this.netClCd, dest.netClCd)) return false;
		if (false == StringUtils.equals(this.delYn, dest.delYn)) return false;
		return true;
	}
	@Override
	public void setKey() {
		this.key = this.ccellId;
	}
	@Override
	public void setRange(CopyVO obj) {
		OIV10170 src = (OIV10170) obj;
		this.rangeCcellId = src.getCcellId();
	}
	public String getRangeCcellId() {
		return rangeCcellId;
	}
	public void setRangeCcellId(String rangeCcellId) {
		this.rangeCcellId = rangeCcellId;
	}

}
