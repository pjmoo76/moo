package com.skb.mi.model;

public class OCL29300 {
	private	String	clctDtm;
	private	String	ipAddr;
	private	long	inetSvcMgmtNum;
	private	String	auditId;
	private	String	macAddr;
	private	String	skbWeqpYn;
	private	String	prvShrrYn;
	private	String	stbMacAddr;

	public String getClctDtm() {
		return clctDtm;
	}
	public void setClctDtm(String clctDtm) {
		this.clctDtm = clctDtm;
	}
	public String getIpAddr() {
		return ipAddr;
	}
	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}
	public long getInetSvcMgmtNum() {
		return inetSvcMgmtNum;
	}
	public void setInetSvcMgmtNum(long inetSvcMgmtNum) {
		this.inetSvcMgmtNum = inetSvcMgmtNum;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getMacAddr() {
		return macAddr;
	}
	public void setMacAddr(String macAddr) {
		this.macAddr = macAddr;
	}
	public String getSkbWeqpYn() {
		return skbWeqpYn;
	}
	public void setSkbWeqpYn(String skbWeqpYn) {
		this.skbWeqpYn = skbWeqpYn;
	}
	public String getPrvShrrYn() {
		return prvShrrYn;
	}
	public void setPrvShrrYn(String prvShrrYn) {
		this.prvShrrYn = prvShrrYn;
	}
	public String getStbMacAddr() {
		return stbMacAddr;
	}
	public void setStbMacAddr(String stbMacAddr) {
		this.stbMacAddr = stbMacAddr;
	}
}
