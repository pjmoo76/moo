package com.skb.mi.model;

public class OMN50202 {
	private	String	cnslDt;
	private	String	linCallClCd;
	private	String	cnslSerNum;
	private	String  dtlSeq;
	private	String	auditId;
	private	String	auditDtm;
	private	String	svcCd;
	private	String	svcNum;
	private	String	svcMgmtNum;
	private	String	feeProdId;
	private	String	svcDtlClCd;
	
	public String getCnslDt() {
		return cnslDt;
	}
	public void setCnslDt(String cnslDt) {
		this.cnslDt = cnslDt;
	}
	public String getLinCallClCd() {
		return linCallClCd;
	}
	public void setLinCallClCd(String linCallClCd) {
		this.linCallClCd = linCallClCd;
	}
	public String getCnslSerNum() {
		return cnslSerNum;
	}
	public void setCnslSerNum(String cnslSerNum) {
		this.cnslSerNum = cnslSerNum;
	}
	public String getDtlSeq() {
		return dtlSeq;
	}
	public void setDtlSeq(String dtlSeq) {
		this.dtlSeq = dtlSeq;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getSvcCd() {
		return svcCd;
	}
	public void setSvcCd(String svcCd) {
		this.svcCd = svcCd;
	}
	public String getSvcNum() {
		return svcNum;
	}
	public void setSvcNum(String svcNum) {
		this.svcNum = svcNum;
	}
	public String getSvcMgmtNum() {
		return svcMgmtNum;
	}
	public void setSvcMgmtNum(String svcMgmtNum) {
		this.svcMgmtNum = svcMgmtNum;
	}
	public String getFeeProdId() {
		return feeProdId;
	}
	public void setFeeProdId(String feeProdId) {
		this.feeProdId = feeProdId;
	}
	public String getSvcDtlClCd() {
		return svcDtlClCd;
	}
	public void setSvcDtlClCd(String svcDtlClCd) {
		this.svcDtlClCd = svcDtlClCd;
	}
	
}
