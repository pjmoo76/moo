package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV10700 extends CopyVO {
	private	String	eqpMdlCd;
	private	String	auditId;
	private	String	auditDtm;
	private	String	weqpMdlCd;
	private	String	weqpMdlNm;
	private	String	mfactMdlNm;
	private	String	weqpMnufactCoCd;
	private	String	weqpLclCd;
	private	String	weqpMclCd;
	private	String	weqpMdlTypCd;
	private	int	totPortCnt;
	private	String	useYn;
	private	String	swingCreYn;
	private	String	vocObjYn;
	private	String	delYn;
	
	private	String	rangeEqpMdlCd;
	
	public String getEqpMdlCd() {
		return eqpMdlCd;
	}
	public void setEqpMdlCd(String eqpMdlCd) {
		this.eqpMdlCd = eqpMdlCd;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getWeqpMdlCd() {
		return weqpMdlCd;
	}
	public void setWeqpMdlCd(String weqpMdlCd) {
		this.weqpMdlCd = weqpMdlCd;
	}
	public String getWeqpMdlNm() {
		return weqpMdlNm;
	}
	public void setWeqpMdlNm(String weqpMdlNm) {
		this.weqpMdlNm = weqpMdlNm;
	}
	public String getMfactMdlNm() {
		return mfactMdlNm;
	}
	public void setMfactMdlNm(String mfactMdlNm) {
		this.mfactMdlNm = mfactMdlNm;
	}
	public String getWeqpMnufactCoCd() {
		return weqpMnufactCoCd;
	}
	public void setWeqpMnufactCoCd(String weqpMnufactCoCd) {
		this.weqpMnufactCoCd = weqpMnufactCoCd;
	}
	public String getWeqpLclCd() {
		return weqpLclCd;
	}
	public void setWeqpLclCd(String weqpLclCd) {
		this.weqpLclCd = weqpLclCd;
	}
	public String getWeqpMclCd() {
		return weqpMclCd;
	}
	public void setWeqpMclCd(String weqpMclCd) {
		this.weqpMclCd = weqpMclCd;
	}
	public String getWeqpMdlTypCd() {
		return weqpMdlTypCd;
	}
	public void setWeqpMdlTypCd(String weqpMdlTypCd) {
		this.weqpMdlTypCd = weqpMdlTypCd;
	}
	public int getTotPortCnt() {
		return totPortCnt;
	}
	public void setTotPortCnt(int totPortCnt) {
		this.totPortCnt = totPortCnt;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	public String getSwingCreYn() {
		return swingCreYn;
	}
	public void setSwingCreYn(String swingCreYn) {
		this.swingCreYn = swingCreYn;
	}
	public String getVocObjYn() {
		return vocObjYn;
	}
	public void setVocObjYn(String vocObjYn) {
		this.vocObjYn = vocObjYn;
	}
	public String getDelYn() {
		return delYn;
	}
	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}
	@Override
	public void setKey() {
		this.key = this.eqpMdlCd;
		
	}
	@Override
	public boolean equals(CopyVO obj) {
		OIV10700 dest = (OIV10700) obj;
		if (false == StringUtils.equals(this.eqpMdlCd, dest.eqpMdlCd)) return false;
		if (false == StringUtils.equals(this.weqpMdlCd, dest.weqpMdlCd)) return false;
		if (false == StringUtils.equals(this.weqpMdlNm, dest.weqpMdlNm)) return false;
		if (false == StringUtils.equals(this.mfactMdlNm, dest.mfactMdlNm)) return false;
		if (false == StringUtils.equals(this.weqpMnufactCoCd, dest.weqpMnufactCoCd)) return false;
		if (false == StringUtils.equals(this.weqpLclCd, dest.weqpLclCd)) return false;
		if (false == StringUtils.equals(this.weqpMclCd, dest.weqpMclCd)) return false;
		if (false == StringUtils.equals(this.weqpMdlTypCd, dest.weqpMdlTypCd)) return false;
		if (this.totPortCnt != dest.totPortCnt) return false;
		if (false == StringUtils.equals(this.useYn, dest.useYn)) return false;
		if (false == StringUtils.equals(this.swingCreYn, dest.swingCreYn)) return false;
		if (false == StringUtils.equals(this.vocObjYn, dest.vocObjYn)) return false;
		if (false == StringUtils.equals(this.delYn, dest.delYn)) return false;
		return true;
	}

	public String getRangeEqpMdlCd() {
		return rangeEqpMdlCd;
	}
	public void setRangeEqpMdlCd(String rangeEqpMdlCd) {
		this.rangeEqpMdlCd = rangeEqpMdlCd;
	}

	@Override
	public void setRange(CopyVO obj) {
		OIV10700 src = (OIV10700) obj;
		this.rangeEqpMdlCd = src.rangeEqpMdlCd;
		
	}
}
