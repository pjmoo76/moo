package com.skb.mi.model;

abstract public class AggrDataVO {
	abstract public boolean	isValid();
	abstract public String	toDelimiterString();
	abstract public void	add(AggrDataVO obj);

	public String	getKey() {
		return null;
	}
	
	public boolean isTarget() {
		return true;
	}

	public void calculate() {
	}
}
