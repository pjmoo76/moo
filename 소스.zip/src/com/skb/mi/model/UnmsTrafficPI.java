package com.skb.mi.model;

public class UnmsTrafficPI {
	private String	netClCd;
	private	String	dablGrCd;
	private	String	equipNm;
	private	String	infoCntrCd;
	private	String	distbCntrCd;
	private	String	assaspNum;
	private	String	tmClCd;
	private	String	bizrClCd;
	private	String	dataSrcClNm;
	private	String	clctCyclNm;
	private	String	incommBizrNm;
	private	String	doexgMscNm;
	private	String	routConnDirnCd;
	private	String	routConnTypCd;
	private	String	connBizrNm;
	private	String	connCustNm;			/* 접속고객명 */
	private	String	prfmDablGrLstCtt;
	private	int		nyOccrDcOccrCnt;	/* 미발생장애연속발생횟수 */
	private	int		tmexlTryCallCnt;	/* 시도호(TM제외) */
	private	int		tmexlFnshCallCnt;	/* 완료호(TM제외) */
	private	double	tmexlFnshRt;		/* 완료율(TM제외) */
	private	int		mounLineCnt;		/* 실장회선수 */
	private	double	oosRt;				/* OOS율 */
	private	int		oosRtDcOccrCnt;		/* OOS율장애연속발생횟수 */
	private	int		ovrCallRt;			/* 넘침호율 */
	private	int		ovrCallRtDcOccrCnt;	/* 초과콜률장애연속발생횟수 */
	private	double	lineUseRt;			/* 회선이용율 */
	private	int		lineUseRtDcOccrCnt;	/*회선이용율장애연속발생횟수 */
	private	double	exfluRt;			/* 과다변동율 */
	private	double	tmFnshRt;			/* TM완료율 */
	private	int		tmTryCallCnt;		/* TM시도호 */
	private	int		tmFnshCallCnt;		/* TM완료호 */
	private	int		allTryCallCnt;		/* 전체시도호 */
	private	int		tryCallDcOccrCnt;	/* 시도콜장애연속발생횟수 */
	private	double	allFnshRt;			/* 전체완료율 */
	private	int		fnshRtDcOccrCnt;	/* 완료율장애연속발생횟수 */
	
	/* Service/BIZR */
	private	int		tmexlOcallRlayTryCallCnt;	/* 출중계 시도호(TM제외)*/
	private	int		tmexlOcallRlayFnshCallCnt;	/* 출중계 완료호(TM제외) */
	private	double	tmexlOcallRlayFnshRt;		/* 출중계 완료율(TM제외) */
	private	double	tmexlOcallRlayExfluRt;		/* 출중계과다변동율(TM제외) */
	private	int		otCallCnt7;					/* 전주 발신시도호 */
	private	int		tmexlRcvRlayTryCallCnt;		/* 입중계 시도호(TM제외) */
	private	int		tmexlRcvRlayFnshCallCnt;	/* 입중계 완료호(TM제외) */
	private	double	tmexlRcvRlayFnshRt;			/* 입중계 완료율(TM제외) */
	private	double	tmexlRcvRlayExfluRt;		/* 입중계과다변동율(TM제외) */
	private	int		itCallCnt7;					/* 전주 착신시도호 */
	
	/* VOIP */
//	private	int		otCallCnt;			/* 발신시도호 */
//	private	double	ocallFnshRt;		/* 발신완료율 */
	private	int		itCallCnt;			/* 착신시도호 */
	private	double	icallFnshRt;		/* 착신완료율 */
	
	public String getNetClCd() {
		return netClCd;
	}

	public void setNetClCd(String netClCd) {
		this.netClCd = netClCd;
	}

	public String getDablGrCd() {
		return dablGrCd;
	}

	public void setDablGrCd(String dablGrCd) {
		this.dablGrCd = dablGrCd;
	}

	public String getEquipNm() {
		return equipNm;
	}

	public void setEquipNm(String equipNm) {
		this.equipNm = equipNm;
	}
	
	public String getInfoCntrCd() {
		return infoCntrCd;
	}
	
	public void setInfoCntrCd(String infoCntrCd) {
		this.infoCntrCd = infoCntrCd;
	}
	
	public String getDistbCntrCd() {
		return distbCntrCd;
	}
	
	public void setDistbCntrCd(String distbCntrCd) {
		this.distbCntrCd = distbCntrCd;
	}

	public String getAssaspNum() {
		return assaspNum;
	}

	public void setAssaspNum(String assaspNum) {
		this.assaspNum = assaspNum;
	}

	public String getTmClCd() {
		return tmClCd;
	}

	public void setTmClCd(String tmClCd) {
		this.tmClCd = tmClCd;
	}

	public String getBizrClCd() {
		return bizrClCd;
	}

	public void setBizrClCd(String bizrClCd) {
		this.bizrClCd = bizrClCd;
	}

	public String getDataSrcClNm() {
		return dataSrcClNm;
	}

	public void setDataSrcClNm(String dataSrcClNm) {
		this.dataSrcClNm = dataSrcClNm;
	}

	public String getClctCyclNm() {
		return clctCyclNm;
	}

	public void setClctCyclNm(String clctCyclNm) {
		this.clctCyclNm = clctCyclNm;
	}

	public String getIncommBizrNm() {
		return incommBizrNm;
	}

	public void setIncommBizrNm(String incommBizrNm) {
		this.incommBizrNm = incommBizrNm;
	}

	public String getDoexgMscNm() {
		return doexgMscNm;
	}

	public void setDoexgMscNm(String doexgMscNm) {
		this.doexgMscNm = doexgMscNm;
	}

	public String getRoutConnDirnCd() {
		return routConnDirnCd;
	}

	public void setRoutConnDirnCd(String routConnDirnCd) {
		this.routConnDirnCd = routConnDirnCd;
	}

	public String getRoutConnTypCd() {
		return routConnTypCd;
	}

	public void setRoutConnTypCd(String routConnTypCd) {
		this.routConnTypCd = routConnTypCd;
	}

	public String getConnBizrNm() {
		return connBizrNm;
	}

	public void setConnBizrNm(String connBizrNm) {
		this.connBizrNm = connBizrNm;
	}

	public String getConnCustNm() {
		return connCustNm;
	}

	public void setConnCustNm(String connCustNm) {
		this.connCustNm = connCustNm;
	}

	public String getPrfmDablGrLstCtt() {
		return prfmDablGrLstCtt;
	}

	public void setPrfmDablGrLstCtt(String prfmDablGrLstCtt) {
		this.prfmDablGrLstCtt = prfmDablGrLstCtt;
	}

	public int getNyOccrDcOccrCnt() {
		return nyOccrDcOccrCnt;
	}

	public void setNyOccrDcOccrCnt(int nyOccrDcOccrCnt) {
		this.nyOccrDcOccrCnt = nyOccrDcOccrCnt;
	}

	public int getTmexlTryCallCnt() {
		return tmexlTryCallCnt;
	}

	public void setTmexlTryCallCnt(int tmexlTryCallCnt) {
		this.tmexlTryCallCnt = tmexlTryCallCnt;
	}

	public int getTmexlFnshCallCnt() {
		return tmexlFnshCallCnt;
	}

	public void setTmexlFnshCallCnt(int tmexlFnshCallCnt) {
		this.tmexlFnshCallCnt = tmexlFnshCallCnt;
	}

	public double getTmexlFnshRt() {
		return tmexlFnshRt;
	}

	public void setTmexlFnshRt(double tmexlFnshRt) {
		this.tmexlFnshRt = tmexlFnshRt;
	}

	public int getMounLineCnt() {
		return mounLineCnt;
	}

	public void setMounLineCnt(int mounLineCnt) {
		this.mounLineCnt = mounLineCnt;
	}

	public double getOosRt() {
		return oosRt;
	}

	public void setOosRt(double oosRt) {
		this.oosRt = oosRt;
	}

	public int getOosRtDcOccrCnt() {
		return oosRtDcOccrCnt;
	}

	public void setOosRtDcOccrCnt(int oosRtDcOccrCnt) {
		this.oosRtDcOccrCnt = oosRtDcOccrCnt;
	}

	public int getOvrCallRt() {
		return ovrCallRt;
	}

	public void setOvrCallRt(int ovrCallRt) {
		this.ovrCallRt = ovrCallRt;
	}

	public int getOvrCallRtDcOccrCnt() {
		return ovrCallRtDcOccrCnt;
	}

	public void setOvrCallRtDcOccrCnt(int ovrCallRtDcOccrCnt) {
		this.ovrCallRtDcOccrCnt = ovrCallRtDcOccrCnt;
	}

	public double getLineUseRt() {
		return lineUseRt;
	}

	public void setLineUseRt(double lineUseRt) {
		this.lineUseRt = lineUseRt;
	}

	public int getLineUseRtDcOccrCnt() {
		return lineUseRtDcOccrCnt;
	}

	public void setLineUseRtDcOccrCnt(int lineUseRtDcOccrCnt) {
		this.lineUseRtDcOccrCnt = lineUseRtDcOccrCnt;
	}

	public double getExfluRt() {
		return exfluRt;
	}

	public void setExfluRt(double exfluRt) {
		this.exfluRt = exfluRt;
	}

	public double getTmFnshRt() {
		return tmFnshRt;
	}

	public void setTmFnshRt(double tmFnshRt) {
		this.tmFnshRt = tmFnshRt;
	}

	public int getTmTryCallCnt() {
		return tmTryCallCnt;
	}

	public void setTmTryCallCnt(int tmTryCallCnt) {
		this.tmTryCallCnt = tmTryCallCnt;
	}

	public int getTmFnshCallCnt() {
		return tmFnshCallCnt;
	}

	public void setTmFnshCallCnt(int tmFnshCallCnt) {
		this.tmFnshCallCnt = tmFnshCallCnt;
	}

	public int getAllTryCallCnt() {
		return allTryCallCnt;
	}

	public void setAllTryCallCnt(int allTryCallCnt) {
		this.allTryCallCnt = allTryCallCnt;
	}

	public int getTryCallDcOccrCnt() {
		return tryCallDcOccrCnt;
	}

	public void setTryCallDcOccrCnt(int tryCallDcOccrCnt) {
		this.tryCallDcOccrCnt = tryCallDcOccrCnt;
	}

	public double getAllFnshRt() {
		return allFnshRt;
	}

	public void setAllFnshRt(double allFnshRt) {
		this.allFnshRt = allFnshRt;
	}

	public int getFnshRtDcOccrCnt() {
		return fnshRtDcOccrCnt;
	}

	public void setFnshRtDcOccrCnt(int fnshRtDcOccrCnt) {
		this.fnshRtDcOccrCnt = fnshRtDcOccrCnt;
	}

	public int getTmexlOcallRlayTryCallCnt() {
		return tmexlOcallRlayTryCallCnt;
	}

	public void setTmexlOcallRlayTryCallCnt(int tmexlOcallRlayTryCallCnt) {
		this.tmexlOcallRlayTryCallCnt = tmexlOcallRlayTryCallCnt;
	}

	public int getTmexlOcallRlayFnshCallCnt() {
		return tmexlOcallRlayFnshCallCnt;
	}

	public void setTmexlOcallRlayFnshCallCnt(int tmexlOcallRlayFnshCallCnt) {
		this.tmexlOcallRlayFnshCallCnt = tmexlOcallRlayFnshCallCnt;
	}

	public double getTmexlOcallRlayFnshRt() {
		return tmexlOcallRlayFnshRt;
	}

	public void setTmexlOcallRlayFnshRt(double tmexlOcallRlayFnshRt) {
		this.tmexlOcallRlayFnshRt = tmexlOcallRlayFnshRt;
	}

	public double getTmexlOcallRlayExfluRt() {
		return tmexlOcallRlayExfluRt;
	}

	public void setTmexlOcallRlayExfluRt(double tmexlOcallRlayExfluRt) {
		this.tmexlOcallRlayExfluRt = tmexlOcallRlayExfluRt;
	}

	public int getOtCallCnt7() {
		return otCallCnt7;
	}

	public void setOtCallCnt7(int otCallCnt7) {
		this.otCallCnt7 = otCallCnt7;
	}

	public int getTmexlRcvRlayTryCallCnt() {
		return tmexlRcvRlayTryCallCnt;
	}

	public void setTmexlRcvRlayTryCallCnt(int tmexlRcvRlayTryCallCnt) {
		this.tmexlRcvRlayTryCallCnt = tmexlRcvRlayTryCallCnt;
	}

	public int getTmexlRcvRlayFnshCallCnt() {
		return tmexlRcvRlayFnshCallCnt;
	}

	public void setTmexlRcvRlayFnshCallCnt(int tmexlRcvRlayFnshCallCnt) {
		this.tmexlRcvRlayFnshCallCnt = tmexlRcvRlayFnshCallCnt;
	}

	public double getTmexlRcvRlayFnshRt() {
		return tmexlRcvRlayFnshRt;
	}

	public void setTmexlRcvRlayFnshRt(double tmexlRcvRlayFnshRt) {
		this.tmexlRcvRlayFnshRt = tmexlRcvRlayFnshRt;
	}

	public double getTmexlRcvRlayExfluRt() {
		return tmexlRcvRlayExfluRt;
	}

	public void setTmexlRcvRlayExfluRt(double tmexlRcvRlayExfluRt) {
		this.tmexlRcvRlayExfluRt = tmexlRcvRlayExfluRt;
	}

	public int getItCallCnt7() {
		return itCallCnt7;
	}

	public void setItCallCnt7(int itCallCnt7) {
		this.itCallCnt7 = itCallCnt7;
	}

	public void set(OMN20305 omn20305) {
		/*----- PSTN Route/V5.2 --------------------------------------------------------------------*/
		/* 미발생장애연속발생횟수 */
		this.nyOccrDcOccrCnt = omn20305.getNyOccrDcOccrCnt();
		/* 시도호(TM제외) */
		this.tmexlTryCallCnt = omn20305.getIoexgTryCallCnt() + omn20305.getItCallCnt() + omn20305.getOtCallCnt()
				- (omn20305.getOcallNumTmTryCallCnt() + omn20305.getIcallNumTmTryCallCnt());
		/* 완료호(TM제외) */
		this.tmexlFnshCallCnt = omn20305.getIoexgFnshCallCnt() + omn20305.getIcallFnshCallCnt() + omn20305.getOcallFnshCallCnt()
				- (omn20305.getOcallNumTmFnshCallCnt() + omn20305.getIcallNumTmFnshCallCnt());
		/* OOS율 */
		this.oosRt = omn20305.getFblkCnt() + omn20305.getMblkCnt() + omn20305.getSblkCnt() + omn20305.getCardSpratCnt();
		/* OOS율장애연속발생횟수 */
		this.oosRtDcOccrCnt = omn20305.getOosRtDcOccrCnt();
		/* 넘침호율 */
		this.ovrCallRt = omn20305.getOvrCallCnt();
		/* 초과콜률장애연속발생횟수 */
		this.ovrCallRtDcOccrCnt = omn20305.getOvrCallRtDcOccrCnt();
		/* 회선이용율 */
		this.lineUseRt = omn20305.getErlangVal();
		/* 회선이용율장애연속발생횟수 */
		this.lineUseRtDcOccrCnt = omn20305.getLineUseRtDcOccrCnt();
		/* 과다변동율 */
		// 조회 쿼리에서 처리
		/* TM시도호 */
		this.tmTryCallCnt = omn20305.getOcallNumTmTryCallCnt() + omn20305.getIcallNumTmTryCallCnt();
		/* TM완료호 */
		this.tmFnshCallCnt = omn20305.getOcallNumTmFnshCallCnt() + omn20305.getIcallNumTmFnshCallCnt();
		/* 전체시도호 */
		this.allTryCallCnt = omn20305.getIoexgTryCallCnt() + omn20305.getItCallCnt() + omn20305.getOtCallCnt();
		/* 시도콜장애연속발생횟수 */
		this.tryCallDcOccrCnt = omn20305.getTryCallDcOccrCnt();
		/* 전체완료율 */
		this.allFnshRt = omn20305.getIoexgFnshCallCnt() + omn20305.getIcallFnshCallCnt() + omn20305.getOcallFnshCallCnt();
		/* 완료율장애연속발생횟수 */
		this.fnshRtDcOccrCnt = omn20305.getFnshRtDcOccrCnt();
		
		/*----- PSTN Service/Bizr --------------------------------------------------------------------*/
		/* 출중계 시도호(TM제외)*/
		this.tmexlOcallRlayTryCallCnt = omn20305.getOtCallCnt() - omn20305.getOcallNumTmTryCallCnt();
		/* 출중계 완료호(TM제외) */
		this.tmexlOcallRlayFnshCallCnt = omn20305.getOcallFnshCallCnt() - omn20305.getOcallNumTmFnshCallCnt();
		/* 출중계 완료율(TM제외) */
		this.tmexlOcallRlayFnshRt = 0.0;
		/* 출중계과다변동율(TM제외) */
		// VOIP 에서는 0.0 으로 되어 있음.
		this.tmexlOcallRlayExfluRt = omn20305.getOtCallCnt();
		/* 입중계 시도호(TM제외) */
		this.tmexlRcvRlayTryCallCnt = omn20305.getIoexgTryCallCnt() + omn20305.getItCallCnt() - omn20305.getIcallNumTmTryCallCnt();
		/* 입중계 완료호(TM제외) */
		this.tmexlRcvRlayFnshCallCnt = omn20305.getIoexgFnshCallCnt() + omn20305.getIcallFnshCallCnt() - omn20305.getIcallNumTmFnshCallCnt();
		/* 입중계 완료율(TM제외) */
		this.tmexlRcvRlayFnshRt = 0.0;
		/* 입중계과다변동율(TM제외) */
		// VOIP 에서는 0.0 으로 되어 있음
		this.tmexlRcvRlayExfluRt = omn20305.getIoexgTryCallCnt() + omn20305.getItCallCnt();
		/* TM완료율 */
		this.tmFnshRt = 0.0;
		/* TM시도호 */
		this.tmTryCallCnt = omn20305.getOcallNumTmTryCallCnt() + omn20305.getIcallNumTmTryCallCnt();
		/* TM완료호 */
		this.tmFnshCallCnt = omn20305.getOcallNumTmFnshCallCnt() + omn20305.getIcallNumTmFnshCallCnt();
		/* 전체시도호 */
		this.allTryCallCnt = omn20305.getIoexgTryCallCnt() + omn20305.getItCallCnt() + omn20305.getOtCallCnt();
	}
}
