package com.skb.mi.model;

public class OQA62574 {
	private	String	evtRcvDtm;
	private	String	macAddrVal;
	private	String	wifiFreqVal;
	private	String	actNodIdxVal;
	private	String	auditId;
	private	String	auditDtm;
	private	String	evtOccrDtm;
	private	String	netClCd;
	private	String	infoCntrCd;
	private	String	distbCntrCd;
	private	String	homeCntrCd;
	private	String	l3TidVal;
	private	String	l3EquipId;
	private	String	l2TidVal;
	private	String	l2EquipId;
	private	String	ccellNum;
	private	String	eqpMdlCd;
	private	String	eqpVerInfo;
	private	long	inetSvcMgmtNum;
	private	String	inetSvcNm;
	private	long	iptvSvcMgmtNum;
	private	String	iptvSvcNm;
	private	String	ipAddr;
	private	String	eqpUptimeTmsInfo;
	private	String	nodLinkSsidVal;
	private	String	actNodBssidVal;
	private	String	chnlNum;
	private	String	encKeyVal;
	private	int	rssiVal;
	private	int	d1VocCnt;
	private	String	d1VocCtt;
	private	int	d7VocCnt;
	private	String	d7VocCtt;
	private	int	d30VocCnt;
	private	String	d30VocCtt;
	private	String	wifi2p4gChnlNum;
	private	String	wifi5gChnlNum;
	private	int	chnlUseVal;
	
	public String getEvtRcvDtm() {
		return evtRcvDtm;
	}
	public void setEvtRcvDtm(String evtRcvDtm) {
		this.evtRcvDtm = evtRcvDtm;
	}
	public String getMacAddrVal() {
		return macAddrVal;
	}
	public void setMacAddrVal(String macAddrVal) {
		this.macAddrVal = macAddrVal;
	}
	public String getWifiFreqVal() {
		return wifiFreqVal;
	}
	public void setWifiFreqVal(String wifiFreqVal) {
		this.wifiFreqVal = wifiFreqVal;
	}
	public String getActNodIdxVal() {
		return actNodIdxVal;
	}
	public void setActNodIdxVal(String actNodIdxVal) {
		this.actNodIdxVal = actNodIdxVal;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getEvtOccrDtm() {
		return evtOccrDtm;
	}
	public void setEvtOccrDtm(String evtOccrDtm) {
		this.evtOccrDtm = evtOccrDtm;
	}
	public String getNetClCd() {
		return netClCd;
	}
	public void setNetClCd(String netClCd) {
		this.netClCd = netClCd;
	}
	public String getInfoCntrCd() {
		return infoCntrCd;
	}
	public void setInfoCntrCd(String infoCntrCd) {
		this.infoCntrCd = infoCntrCd;
	}
	public String getDistbCntrCd() {
		return distbCntrCd;
	}
	public void setDistbCntrCd(String distbCntrCd) {
		this.distbCntrCd = distbCntrCd;
	}
	public String getHomeCntrCd() {
		return homeCntrCd;
	}
	public void setHomeCntrCd(String homeCntrCd) {
		this.homeCntrCd = homeCntrCd;
	}
	public String getL3TidVal() {
		return l3TidVal;
	}
	public void setL3TidVal(String l3TidVal) {
		this.l3TidVal = l3TidVal;
	}
	public String getL3EquipId() {
		return l3EquipId;
	}
	public void setL3EquipId(String l3EquipId) {
		this.l3EquipId = l3EquipId;
	}
	public String getL2TidVal() {
		return l2TidVal;
	}
	public void setL2TidVal(String l2TidVal) {
		this.l2TidVal = l2TidVal;
	}
	public String getL2EquipId() {
		return l2EquipId;
	}
	public void setL2EquipId(String l2EquipId) {
		this.l2EquipId = l2EquipId;
	}
	public String getCcellNum() {
		return ccellNum;
	}
	public void setCcellNum(String ccellNum) {
		this.ccellNum = ccellNum;
	}
	public String getEqpMdlCd() {
		return eqpMdlCd;
	}
	public void setEqpMdlCd(String eqpMdlCd) {
		this.eqpMdlCd = eqpMdlCd;
	}
	public String getEqpVerInfo() {
		return eqpVerInfo;
	}
	public void setEqpVerInfo(String eqpVerInfo) {
		this.eqpVerInfo = eqpVerInfo;
	}
	public long getInetSvcMgmtNum() {
		return inetSvcMgmtNum;
	}
	public void setInetSvcMgmtNum(long inetSvcMgmtNum) {
		this.inetSvcMgmtNum = inetSvcMgmtNum;
	}
	public String getInetSvcNm() {
		return inetSvcNm;
	}
	public void setInetSvcNm(String inetSvcNm) {
		this.inetSvcNm = inetSvcNm;
	}
	public long getIptvSvcMgmtNum() {
		return iptvSvcMgmtNum;
	}
	public void setIptvSvcMgmtNum(long iptvSvcMgmtNum) {
		this.iptvSvcMgmtNum = iptvSvcMgmtNum;
	}
	public String getIptvSvcNm() {
		return iptvSvcNm;
	}
	public void setIptvSvcNm(String iptvSvcNm) {
		this.iptvSvcNm = iptvSvcNm;
	}
	public String getIpAddr() {
		return ipAddr;
	}
	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}
	public String getEqpUptimeTmsInfo() {
		return eqpUptimeTmsInfo;
	}
	public void setEqpUptimeTmsInfo(String eqpUptimeTmsInfo) {
		this.eqpUptimeTmsInfo = eqpUptimeTmsInfo;
	}
	public String getNodLinkSsidVal() {
		return nodLinkSsidVal;
	}
	public void setNodLinkSsidVal(String nodLinkSsidVal) {
		this.nodLinkSsidVal = nodLinkSsidVal;
	}
	public String getActNodBssidVal() {
		return actNodBssidVal;
	}
	public void setActNodBssidVal(String actNodBssidVal) {
		this.actNodBssidVal = actNodBssidVal;
	}
	public String getChnlNum() {
		return chnlNum;
	}
	public void setChnlNum(String chnlNum) {
		this.chnlNum = chnlNum;
	}
	public String getEncKeyVal() {
		return encKeyVal;
	}
	public void setEncKeyVal(String encKeyVal) {
		this.encKeyVal = encKeyVal;
	}
	public int getRssiVal() {
		return rssiVal;
	}
	public void setRssiVal(int rssiVal) {
		this.rssiVal = rssiVal;
	}
	public int getD1VocCnt() {
		return d1VocCnt;
	}
	public void setD1VocCnt(int d1VocCnt) {
		this.d1VocCnt = d1VocCnt;
	}
	public String getD1VocCtt() {
		return d1VocCtt;
	}
	public void setD1VocCtt(String d1VocCtt) {
		this.d1VocCtt = d1VocCtt;
	}
	public int getD7VocCnt() {
		return d7VocCnt;
	}
	public void setD7VocCnt(int d7VocCnt) {
		this.d7VocCnt = d7VocCnt;
	}
	public String getD7VocCtt() {
		return d7VocCtt;
	}
	public void setD7VocCtt(String d7VocCtt) {
		this.d7VocCtt = d7VocCtt;
	}
	public int getD30VocCnt() {
		return d30VocCnt;
	}
	public void setD30VocCnt(int d30VocCnt) {
		this.d30VocCnt = d30VocCnt;
	}
	public String getD30VocCtt() {
		return d30VocCtt;
	}
	public void setD30VocCtt(String d30VocCtt) {
		this.d30VocCtt = d30VocCtt;
	}
	public String getWifi2p4gChnlNum() {
		return wifi2p4gChnlNum;
	}
	public void setWifi2p4gChnlNum(String wifi2p4gChnlNum) {
		this.wifi2p4gChnlNum = wifi2p4gChnlNum;
	}
	public String getWifi5gChnlNum() {
		return wifi5gChnlNum;
	}
	public void setWifi5gChnlNum(String wifi5gChnlNum) {
		this.wifi5gChnlNum = wifi5gChnlNum;
	}
	public int getChnlUseVal() {
		return chnlUseVal;
	}
	public void setChnlUseVal(int chnlUseVal) {
		this.chnlUseVal = chnlUseVal;
	}
	
	
}
	