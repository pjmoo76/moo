package com.skb.mi.model;

public class OMN32601 extends AggrDataVO {
	private	long	apDablNum;
	private	String	auditId;
	private	String	apDablCd;
	private	String	dablDesc;
	private	String	dablStCd;
	private	String	dablGrCd;
	private	String	occrDtm;
	private	String	netClCd;
	private	String	infoCntrCd;
	private	String	distbCntrCd;
	private	String	rlseDtm;
	private	String	dablRlseMthdCd;
	private	String	dablRlseRsnCtt;
	private	String	dablRlsrId;
	private	long	evtOccrCnt;
	private	int		apCnt;

	public long getApDablNum() {
		return apDablNum;
	}
	public void setApDablNum(long apDablNum) {
		this.apDablNum = apDablNum;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getApDablCd() {
		return apDablCd;
	}
	public void setApDablCd(String apDablCd) {
		this.apDablCd = apDablCd;
	}
	public String getDablDesc() {
		return dablDesc;
	}
	public void setDablDesc(String dablDesc) {
		this.dablDesc = dablDesc;
	}
	public String getDablStCd() {
		return dablStCd;
	}
	public void setDablStCd(String dablStCd) {
		this.dablStCd = dablStCd;
	}
	public String getDablGrCd() {
		return dablGrCd;
	}
	public void setDablGrCd(String dablGrCd) {
		this.dablGrCd = dablGrCd;
	}
	public String getOccrDtm() {
		return occrDtm;
	}
	public void setOccrDtm(String occrDtm) {
		this.occrDtm = occrDtm;
	}
	public String getNetClCd() {
		return netClCd;
	}
	public void setNetClCd(String netClCd) {
		this.netClCd = netClCd;
	}
	public String getInfoCntrCd() {
		return infoCntrCd;
	}
	public void setInfoCntrCd(String infoCntrCd) {
		this.infoCntrCd = infoCntrCd;
	}
	public String getDistbCntrCd() {
		return distbCntrCd;
	}
	public void setDistbCntrCd(String distbCntrCd) {
		this.distbCntrCd = distbCntrCd;
	}
	public String getRlseDtm() {
		return rlseDtm;
	}
	public void setRlseDtm(String rlseDtm) {
		this.rlseDtm = rlseDtm;
	}
	public String getDablRlseMthdCd() {
		return dablRlseMthdCd;
	}
	public void setDablRlseMthdCd(String dablRlseMthdCd) {
		this.dablRlseMthdCd = dablRlseMthdCd;
	}
	public String getDablRlseRsnCtt() {
		return dablRlseRsnCtt;
	}
	public void setDablRlseRsnCtt(String dablRlseRsnCtt) {
		this.dablRlseRsnCtt = dablRlseRsnCtt;
	}
	public String getDablRlsrId() {
		return dablRlsrId;
	}
	public void setDablRlsrId(String dablRlsrId) {
		this.dablRlsrId = dablRlsrId;
	}
	public long getEvtOccrCnt() {
		return evtOccrCnt;
	}
	public void setEvtOccrCnt(long evtOccrCnt) {
		this.evtOccrCnt = evtOccrCnt;
	}
	public int getApCnt() {
		return apCnt;
	}
	public void setApCnt(int apCnt) {
		this.apCnt = apCnt;
	}

	@Override
	public String	getKey() {
		return occrDtm+"-"+apDablCd+"-"+distbCntrCd;
	}

	@Override
	public boolean isValid() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String toDelimiterString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("%d|", apDablNum));
		sb.append(String.format("%s|", auditId));
		sb.append(String.format("%s|", apDablCd));
		sb.append(String.format("%s|", dablDesc));
		sb.append(String.format("%s|", dablStCd));
		sb.append(String.format("%s|", dablGrCd));
		sb.append(String.format("%s|", occrDtm));
		sb.append(String.format("%s|", netClCd));
		sb.append(String.format("%s|", infoCntrCd));
		sb.append(String.format("%s|", distbCntrCd));
		sb.append(String.format("%s|", rlseDtm));
		sb.append(String.format("%s|", dablRlseMthdCd));
		sb.append(String.format("%s|", dablRlseRsnCtt));
		sb.append(String.format("%s|", dablRlsrId));
		return sb.toString();
	}

	@Override
	public void add(AggrDataVO obj) {
		// TODO Auto-generated method stub
		
	}

}
