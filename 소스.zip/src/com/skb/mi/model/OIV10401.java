package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV10401 extends CopyVO {
	private	String	linkId;
	private	String	auditId;
	private	String	auditDtm;
	private	String	adrcEquipId;
	private	String	adrcEquipPortId;
	private	String	adrcIfId;
	private	String	adrcCcellNum;
	private	String	zdrcEquipId;
	private	String	zdrcEquipPortId;
	private	String	zdrcIfId;
	private	String	zdrcCcellNum;
	private	String	linkTypCd;
	private	String	linkUsgCd;
	private	String	linkRngCd;
	private	String	lineNum;
	private	int	lineSerNum;

	private	String	rangeLinkId;

	public String getLinkId() {
		return linkId;
	}
	public void setLinkId(String linkId) {
		this.linkId = linkId;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getAdrcEquipId() {
		return adrcEquipId;
	}
	public void setAdrcEquipId(String adrcEquipId) {
		this.adrcEquipId = adrcEquipId;
	}
	public String getAdrcEquipPortId() {
		return adrcEquipPortId;
	}
	public void setAdrcEquipPortId(String adrcEquipPortId) {
		this.adrcEquipPortId = adrcEquipPortId;
	}
	public String getAdrcIfId() {
		return adrcIfId;
	}
	public void setAdrcIfId(String adrcIfId) {
		this.adrcIfId = adrcIfId;
	}
	public String getAdrcCcellNum() {
		return adrcCcellNum;
	}
	public void setAdrcCcellNum(String adrcCcellNum) {
		this.adrcCcellNum = adrcCcellNum;
	}
	public String getZdrcEquipId() {
		return zdrcEquipId;
	}
	public void setZdrcEquipId(String zdrcEquipId) {
		this.zdrcEquipId = zdrcEquipId;
	}
	public String getZdrcEquipPortId() {
		return zdrcEquipPortId;
	}
	public void setZdrcEquipPortId(String zdrcEquipPortId) {
		this.zdrcEquipPortId = zdrcEquipPortId;
	}
	public String getZdrcIfId() {
		return zdrcIfId;
	}
	public void setZdrcIfId(String zdrcIfId) {
		this.zdrcIfId = zdrcIfId;
	}
	public String getZdrcCcellNum() {
		return zdrcCcellNum;
	}
	public void setZdrcCcellNum(String zdrcCcellNum) {
		this.zdrcCcellNum = zdrcCcellNum;
	}
	public String getLinkTypCd() {
		return linkTypCd;
	}
	public void setLinkTypCd(String linkTypCd) {
		this.linkTypCd = linkTypCd;
	}
	public String getLinkUsgCd() {
		return linkUsgCd;
	}
	public void setLinkUsgCd(String linkUsgCd) {
		this.linkUsgCd = linkUsgCd;
	}
	public String getLinkRngCd() {
		return linkRngCd;
	}
	public void setLinkRngCd(String linkRngCd) {
		this.linkRngCd = linkRngCd;
	}
	public String getLineNum() {
		return lineNum;
	}
	public void setLineNum(String lineNum) {
		this.lineNum = lineNum;
	}
	public int getLineSerNum() {
		return lineSerNum;
	}
	public void setLineSerNum(int lineSerNum) {
		this.lineSerNum = lineSerNum;
	}
	@Override
	public void setKey() {
		this.key = this.linkId;
	}
	@Override
	public boolean equals(CopyVO obj) {
		OIV10401 dest = (OIV10401) obj;
		if (false == StringUtils.equals(this.linkId, dest.linkId)) return false;
		if (false == StringUtils.equals(this.adrcEquipId, dest.adrcEquipId)) return false;
		if (false == StringUtils.equals(this.adrcEquipPortId, dest.adrcEquipPortId)) return false;
		if (false == StringUtils.equals(this.adrcIfId, dest.adrcIfId)) return false;
		if (false == StringUtils.equals(this.adrcCcellNum, dest.adrcCcellNum)) return false;
		if (false == StringUtils.equals(this.zdrcEquipId, dest.zdrcEquipId)) return false;
		if (false == StringUtils.equals(this.zdrcEquipPortId, dest.zdrcEquipPortId)) return false;
		if (false == StringUtils.equals(this.zdrcIfId, dest.zdrcIfId)) return false;
		if (false == StringUtils.equals(this.zdrcCcellNum, dest.zdrcCcellNum)) return false;
		if (false == StringUtils.equals(this.linkTypCd, dest.linkTypCd)) return false;
		if (false == StringUtils.equals(this.linkUsgCd, dest.linkUsgCd)) return false;
		if (false == StringUtils.equals(this.linkRngCd, dest.linkRngCd)) return false;
		if (false == StringUtils.equals(this.lineNum, dest.lineNum)) return false;
		if (this.lineSerNum != dest.lineSerNum) return false;
		return true;
	}
	@Override
	public void setRange(CopyVO obj) {
		OIV10401 src = (OIV10401) obj;
		this.rangeLinkId = src.getLinkId();
	}
	public String getRangeLinkId() {
		return rangeLinkId;
	}
	public void setRangeLinkId(String rangeLinkId) {
		this.rangeLinkId = rangeLinkId;
	}

}
