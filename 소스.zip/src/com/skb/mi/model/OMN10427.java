package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OMN10427 extends CopyVO {
	private	String	userId;
	private	String	scrnId;
	private	String	iptvAlmTypCd;
	private	String	iptvAlmClCd;
	private	String	infoCntrCd;
	private	String	auditId;
	private	String	auditDtm;
	private	String	useYn;
	
	private	String	rangeUserId;
	private	String	rangeScrnId;
	private	String	rangeIptvAlmTypCd;
	private	String	rangeIptvAlmClCd;
	private	String	rangeInfoCntrCd;
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("userId=%s\n", userId));
		sb.append(String.format("scrnId=%s\n", scrnId));
		sb.append(String.format("iptvAlmTypCd=%s\n", iptvAlmTypCd));
		sb.append(String.format("iptvAlmClCd=%s\n", iptvAlmClCd));
		sb.append(String.format("infoCntrCd=%s\n", infoCntrCd));
		sb.append(String.format("auditId=%s\n", auditId));
		sb.append(String.format("useYn=%s\n", useYn));
		return sb.toString();
	}
	
	public boolean isValidKey() {
		if (userId.isEmpty()) return false;
		if (scrnId.isEmpty()) return false;
		if (iptvAlmTypCd.isEmpty()) return false;
		if (iptvAlmClCd.isEmpty()) return false;
		if (infoCntrCd.isEmpty()) return false;
		return true;
	}

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getScrnId() {
		return scrnId;
	}
	public void setScrnId(String scrnId) {
		this.scrnId = scrnId;
	}
	public String getIptvAlmTypCd() {
		return iptvAlmTypCd;
	}
	public void setIptvAlmTypCd(String iptvAlmTypCd) {
		this.iptvAlmTypCd = iptvAlmTypCd;
	}
	public String getIptvAlmClCd() {
		return iptvAlmClCd;
	}
	public void setIptvAlmClCd(String iptvAlmClCd) {
		this.iptvAlmClCd = iptvAlmClCd;
	}
	public String getInfoCntrCd() {
		return infoCntrCd;
	}
	public void setInfoCntrCd(String infoCntrCd) {
		this.infoCntrCd = infoCntrCd;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	public String getRangeUserId() {
		return rangeUserId;
	}
	public void setRangeUserId(String rangeUserId) {
		this.rangeUserId = rangeUserId;
	}
	public String getRangeScrnId() {
		return rangeScrnId;
	}
	public void setRangeScrnId(String rangeScrnId) {
		this.rangeScrnId = rangeScrnId;
	}
	public String getRangeIptvAlmTypCd() {
		return rangeIptvAlmTypCd;
	}
	public void setRangeIptvAlmTypCd(String rangeIptvAlmTypCd) {
		this.rangeIptvAlmTypCd = rangeIptvAlmTypCd;
	}
	public String getRangeIptvAlmClCd() {
		return rangeIptvAlmClCd;
	}
	public void setRangeIptvAlmClCd(String rangeIptvAlmClCd) {
		this.rangeIptvAlmClCd = rangeIptvAlmClCd;
	}
	public String getRangeInfoCntrCd() {
		return rangeInfoCntrCd;
	}
	public void setRangeInfoCntrCd(String rangeInfoCntrCd) {
		this.rangeInfoCntrCd = rangeInfoCntrCd;
	}

	@Override
	public void setKey() {
		this.key = this.userId + "|" + this.scrnId + "|" + this.iptvAlmTypCd + "|" + this.iptvAlmClCd + "|" + this.infoCntrCd;
	}

	@Override
	public boolean equals(CopyVO obj) {
		OMN10427 dest = (OMN10427) obj;
		if (false == StringUtils.equals(this.useYn, dest.useYn)) return false;
		return true;
	}

	@Override
	public void setRange(CopyVO obj) {
		OMN10427 src = (OMN10427) obj;
		this.rangeUserId = src.userId;
		this.rangeScrnId = src.scrnId;
		this.rangeIptvAlmTypCd = src.iptvAlmTypCd;
		this.rangeIptvAlmClCd = src.iptvAlmClCd;
		this.rangeInfoCntrCd = src.infoCntrCd;
	}

}
