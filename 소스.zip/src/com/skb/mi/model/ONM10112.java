package com.skb.mi.model;

public class ONM10112 {
	
	private	String	auditId;
	private	String	auditDtm;
	private	String	netOpNum;
	private	String	svcMgmtNum;
	
	
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getNetOpNum() {
		return netOpNum;
	}
	public void setNetOpNum(String netOpNum) {
		this.netOpNum = netOpNum;
	}
	public String getSvcMgmtNum() {
		return svcMgmtNum;
	}
	public void setSvcMgmtNum(String svcMgmtNum) {
		this.svcMgmtNum = svcMgmtNum;
	}
	
	
	
}
