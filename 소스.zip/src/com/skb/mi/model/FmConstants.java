package com.skb.mi.model;

public class FmConstants {
	
	public interface DATA_SRC_CL_CD {
		public static final String	CDR		= "C";	// CDR
		public static final String	CALL	= "L";	// VOIP CLOG
		public static final String	MSG		= "M";	// PSTN CLOG
	}

	public interface DABL_MCL_CD {
		public static final String	PSTN_TRAFFIC_ROUTE		= "03101";	/* [PSTN]루트별 트래픽 장애 */
		public static final String	PSTN_TRAFFIC_V52		= "03107";	/* [PSTN]V5.2별 트래픽 장애 */
		public static final String	PSTN_TRAFFIC_SERVICE	= "03102";	/* [PSTN]서비스별 트래픽 장애 */
		public static final String	PSTN_TRAFFIC_BIZR		= "03108";	/* [PSTN]사업자별 트래픽 장애 */
		public static final String	VOIP_TRAFFIC_CALL		= "03105";	/* [VOIP]호 트래픽 장애 */
		public static final String	VOIP_TRAFFIC_V52		= "03106";	/* [VOIP]V5.2 트래픽 장애 */
	}

	public interface THRS_NM {
		public static final String	ROUTE		= "시내 루트별 임계치";
		public static final String	VOIP_ROUTE	= "VOIP 루트별 임계치";
		public static final String	SERVICE		= "시내 서비스별 임계치";
		public static final String	BIZR		= "시내 사업자별 임계치";		
	}

	public interface THRS_DEFAULT_ID {
		public static final String	ROUTE		= "8";
		public static final String	VOIP_ROUTE	= "21";
		public static final String	SERVICE		= "17";
		public static final String	BIZR		= "16";		
	}
	
	public interface ROUT_USG_CTT {
		public static final String	RUC_BIZR_110		= "110";
		public static final String	RUC_SERVICE_120		= "120";
		public static final String	RUC_V52				= "2";
		public static final String	RUC_ROUTE_0			= "0";
		public static final String	RUC_ROUTE_1			= "1";
		public static final String	RUC_ROUTE_3			= "3";
	}

	public interface THRS_ITM_NM {
		public static final String	USAGE		= "USAGE";
		public static final String	OSS			= "OSS";
		public static final String	OVEREFF		= "OVEREFF";
		public static final String	OVE			= "OVE";
		public static final String	NOT			= "NOT";
		public static final String	COM			= "COM";
		public static final String	TRY			= "TRY";
		public static final String	COM_S		= "COM_S";
		public static final String	OVER_S		= "OVER_S";
		public static final String	COM_R		= "COM_R";
		public static final String	OVER_R		= "OVER_R";
	}

	public interface SING_VAL {
		public static final String	GREATER_OR_EQUAL	= ">=";
		public static final String	LESS_OR_EQUAL		= "<=";
		public static final String	GREATER				= ">";
		public static final String	LESS				= "<";
	}

	public interface DABL_GR_CD {
		public static final String	CRITICAL	= "05";
		public static final String	MAJOR		= "04";
		public static final String	MINOR		= "03";
		public static final String	WARNING		= "02";
		public static final String	NONE		= "00";
	}

	public interface DABL_CD {
		public static final String	CD_031043	= "031043";		/* [PSTN]V5.2별 트래픽 장애 - 미발생 장애(시도호) */
		public static final String	CD_031004	= "031004";		/* [PSTN]루트별 트래픽 장애 - 미발생 장애(시도호) */
		public static final String	CD_031040	= "031040";		/* [PSTN]V5.2별 트래픽 장애 - OOS율 장애 */
		public static final String	CD_031001	= "031001";		/* [PSTN]루트별 트래픽 장애 - OOS율 장애 */
		public static final String	CD_031041	= "031041";		/* [PSTN]V5.2별 트래픽 장애 - 넘침호율(OVFL) 장애 */
		public static final String	CD_031002	= "031002";		/* [PSTN]루트별 트래픽 장애 - 넘침호율(OVFL) 장애 */
		public static final String	CD_031045	= "031045";		/* [PSTN]V5.2별 트래픽 장애 - 회선 이용율 */
		public static final String	CD_031006	= "031006";		/* [PSTN]루트별 트래픽 장애 - 회선 이용율 */
		public static final String	CD_031044	= "031044";		/* [PSTN]V5.2별 트래픽 장애 - 과다변동 장애(시도호) */
		public static final String	CD_031005	= "031005";		/* [PSTN]루트별 트래픽 장애 - 과다변동 장애(시도호) */
		public static final String	CD_031050	= "031050";		/* [PSTN]V5.2별 트래픽 장애 - TM완료율 */
		public static final String	CD_031033	= "031033";		/* [PSTN]루트별 트래픽 장애 - TM완료율 */
		public static final String	CD_031048	= "031048";		/* [PSTN]V5.2별 트래픽 장애 - 전체시도호 */
		public static final String	CD_031019	= "031019";		/* [PSTN]루트별 트래픽 장애 - 전체시도호 */
		public static final String	CD_031049	= "031049";		/* [PSTN]V5.2별 트래픽 장애 - 전체완료율 */
		public static final String	CD_031020	= "031020";		/* [PSTN]루트별 트래픽 장애 - 전체완료율 */
		public static final String	CD_031009	= "031009";		/* [PSTN]서비스별 트래픽 장애 - 출중계 완료율 장애 */
		public static final String	CD_031052	= "031052";		/* [PSTN]사업자별 트래픽 장애 - 출중계 완료율 장애 */
		public static final String	CD_031011	= "031011";		/* [PSTN]서비스별 트래픽 장애 - 출중계 과다변동 장애(시도호) */
		public static final String	CD_031054	= "031054";		/* [PSTN]사업자별 트래픽 장애 - 출중계 과다변동 장애(시도호) */
		public static final String	CD_031008	= "031008";		/* [PSTN]서비스별 트래픽 장애 - 입중계 완료율 장애 */
		public static final String	CD_031051	= "031051";		/* [PSTN]사업자별 트래픽 장애 - 입중계 완료율 장애 */
		public static final String	CD_031010	= "031010";		/* [PSTN]서비스별 트래픽 장애 - 입중계 과다변동 장애(시도호) */
		public static final String	CD_031053	= "031053";		/* [PSTN]사업자별 트래픽 장애 - 입중계 과다변동 장애(시도호) */

		public static final String	CD_031021	= "031021";		/* [VOIP]호 트래픽 장애 - 미발생 */
		public static final String	CD_031034	= "031034";		/* [VOIP]V5.2 트래픽 장애 - 미발생 */
		public static final String	CD_031024	= "031024";		/* [VOIP]호 트래픽 장애 - 발신완료율 */
		public static final String	CD_031035	= "031035";		/* [VOIP]V5.2 트래픽 장애 - 발신완료율 */
		public static final String	CD_031025	= "031025";		/* [VOIP]호 트래픽 장애 - 발신과다변동율 */
		public static final String	CD_031036	= "031036";		/* [VOIP]V5.2 트래픽 장애 - 발신과다변동율 */
		public static final String	CD_031029	= "031029";		/* [VOIP]호 트래픽 장애 - 착신완료율 */
		public static final String	CD_031037	= "031037";		/* [VOIP]V5.2 트래픽 장애 - 착신완료율 */
		public static final String	CD_031030	= "031030";		/* [VOIP]호 트래픽 장애 - 착신과다변동율 */
		public static final String	CD_031038	= "031038";		/* [VOIP]V5.2 트래픽 장애 - 착신과다변동율 */
		public static final String	CD_031032	= "031032";		/* [VOIP]호 트래픽 장애 - 이용율 */
		public static final String	CD_031039	= "031039";		/* [VOIP]V5.2 트래픽 장애 - 이용율 */

	}
	
	public interface EQUIP_USG_CD {
		public static final String	CD_4101	= "4101";		/* PSTN ESS */
		public static final String	CD_4201	= "4201";		/* VOIP 기간망 */		
		public static final String	CD_4301	= "4301";		/* VOIP 가입자망 장비 */		
	}
}
