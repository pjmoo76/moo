package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV10800 extends CopyVO {
	private	String	weqpMgmtNum;
	private	String	auditId;
	private	String	auditDtm;
	private	String	weqpGrpCd;
	private	String	eqpMdlCd;
	private	String	macAddrVal;
	private	String	mfactSerNum;
	private	String	weqpClCd;
	private	long	repSvcMgmtNum;
	private	String	weqpLocClCd;
	private	String	weqpLocId;
	private	String	dsnetOrgId;
	private	String	vipEqpYn;
	private	String	vipEqpRgstRsnCtt;
	private	String	homeCntrCd;
	
	private	String	rangeWeqpMgmtNum;
	
	public String getWeqpMgmtNum() {
		return weqpMgmtNum;
	}
	public void setWeqpMgmtNum(String weqpMgmtNum) {
		this.weqpMgmtNum = weqpMgmtNum;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getWeqpGrpCd() {
		return weqpGrpCd;
	}
	public void setWeqpGrpCd(String weqpGrpCd) {
		this.weqpGrpCd = weqpGrpCd;
	}
	public String getEqpMdlCd() {
		return eqpMdlCd;
	}
	public void setEqpMdlCd(String eqpMdlCd) {
		this.eqpMdlCd = eqpMdlCd;
	}
	public String getMacAddrVal() {
		return macAddrVal;
	}
	public void setMacAddrVal(String macAddrVal) {
		this.macAddrVal = macAddrVal;
	}
	public String getMfactSerNum() {
		return mfactSerNum;
	}
	public void setMfactSerNum(String mfactSerNum) {
		this.mfactSerNum = mfactSerNum;
	}
	public String getWeqpClCd() {
		return weqpClCd;
	}
	public void setWeqpClCd(String weqpClCd) {
		this.weqpClCd = weqpClCd;
	}
	public long getRepSvcMgmtNum() {
		return repSvcMgmtNum;
	}
	public void setRepSvcMgmtNum(long repSvcMgmtNum) {
		this.repSvcMgmtNum = repSvcMgmtNum;
	}
	public String getWeqpLocClCd() {
		return weqpLocClCd;
	}
	public void setWeqpLocClCd(String weqpLocClCd) {
		this.weqpLocClCd = weqpLocClCd;
	}
	public String getWeqpLocId() {
		return weqpLocId;
	}
	public void setWeqpLocId(String weqpLocId) {
		this.weqpLocId = weqpLocId;
	}
	public String getDsnetOrgId() {
		return dsnetOrgId;
	}
	public void setDsnetOrgId(String dsnetOrgId) {
		this.dsnetOrgId = dsnetOrgId;
	}
	public String getVipEqpYn() {
		return vipEqpYn;
	}
	public void setVipEqpYn(String vipEqpYn) {
		this.vipEqpYn = vipEqpYn;
	}
	public String getVipEqpRgstRsnCtt() {
		return vipEqpRgstRsnCtt;
	}
	public void setVipEqpRgstRsnCtt(String vipEqpRgstRsnCtt) {
		this.vipEqpRgstRsnCtt = vipEqpRgstRsnCtt;
	}
	public String getHomeCntrCd() {
		return homeCntrCd;
	}
	public void setHomeCntrCd(String homeCntrCd) {
		this.homeCntrCd = homeCntrCd;
	}
	@Override
	public void setKey() {
		this.key = this.weqpMgmtNum;
	}
	@Override
	public boolean equals(CopyVO obj) {
		OIV10800 dest = (OIV10800) obj;
		if (false == StringUtils.equals(this.weqpMgmtNum, dest.weqpMgmtNum)) return false;
		if (false == StringUtils.equals(this.weqpGrpCd, dest.weqpGrpCd)) return false;
		if (false == StringUtils.equals(this.eqpMdlCd, dest.eqpMdlCd)) return false;
		if (false == StringUtils.equals(this.macAddrVal, dest.macAddrVal)) return false;
		if (false == StringUtils.equals(this.mfactSerNum, dest.mfactSerNum)) return false;
		if (false == StringUtils.equals(this.weqpClCd, dest.weqpClCd)) return false;
		if (this.repSvcMgmtNum != dest.repSvcMgmtNum) return false;
		if (false == StringUtils.equals(this.weqpLocClCd, dest.weqpLocClCd)) return false;
		if (false == StringUtils.equals(this.weqpLocId, dest.weqpLocId)) return false;
		if (false == StringUtils.equals(this.dsnetOrgId, dest.dsnetOrgId)) return false;
		if (false == StringUtils.equals(this.vipEqpYn, dest.vipEqpYn)) return false;
		if (false == StringUtils.equals(this.vipEqpRgstRsnCtt, dest.vipEqpRgstRsnCtt)) return false;
		if (false == StringUtils.equals(this.homeCntrCd, dest.homeCntrCd)) return false;
		return true;
	}

	public String getRangeWeqpMgmtNum() {
		return rangeWeqpMgmtNum;
	}
	public void setRangeWeqpMgmtNum(String rangeWeqpMgmtNum) {
		this.rangeWeqpMgmtNum = rangeWeqpMgmtNum;
	}
	@Override
	public void setRange(CopyVO obj) {
		OIV10800 src = (OIV10800) obj;
		this.rangeWeqpMgmtNum = src.weqpMgmtNum;
	}

	// UK 중복 체크용 (2022-10-20 by KMY)
	public void setDubChecked(String dubChecked) {
		if (dubChecked.equals("TRUE")) {
			this.dubChecked = true;
		} else {
			this.dubChecked = false;
		}
	}
}
