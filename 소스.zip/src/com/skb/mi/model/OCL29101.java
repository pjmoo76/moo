package com.skb.mi.model;

public class OCL29101 {
	private	String	clctDtm;
	private	String	ipAddr;
	private	String	dnsIpAddr;
	private	String	auditId;
	private	String	blklstObjYn;
	private	String	whelstObjYn;
	private	String	rtnIpObjYn;
	private	String	bizrNm;

	public String getClctDtm() {
		return clctDtm;
	}
	public void setClctDtm(String clctDtm) {
		this.clctDtm = clctDtm;
	}
	public String getIpAddr() {
		return ipAddr;
	}
	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}
	public String getDnsIpAddr() {
		return dnsIpAddr;
	}
	public void setDnsIpAddr(String dnsIpAddr) {
		this.dnsIpAddr = dnsIpAddr;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getBlklstObjYn() {
		return blklstObjYn;
	}
	public void setBlklstObjYn(String blklstObjYn) {
		this.blklstObjYn = blklstObjYn;
	}
	public String getWhelstObjYn() {
		return whelstObjYn;
	}
	public void setWhelstObjYn(String whelstObjYn) {
		this.whelstObjYn = whelstObjYn;
	}
	public String getRtnIpObjYn() {
		return rtnIpObjYn;
	}
	public void setRtnIpObjYn(String rtnIpObjYn) {
		this.rtnIpObjYn = rtnIpObjYn;
	}
	public String getBizrNm() {
		return bizrNm;
	}
	public void setBizrNm(String bizrNm) {
		this.bizrNm = bizrNm;
	}
}
