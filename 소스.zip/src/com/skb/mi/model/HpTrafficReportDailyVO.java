package com.skb.mi.model;

import java.util.HashMap;

public class HpTrafficReportDailyVO extends AggrDataVO {
	static public int badRssi = -85; /* 열위값 수정 -75 => -85 : 이기호M 요청 (2025-05-22 by KMY) */

	private	String	mntrDt;
	private	String	macAddrVal;
	private	String	auditId;
	private	int		wifi2p4gRssiBadCpeCnt;
	private	int		wifi5gRssiBadCpeCnt;
	private	int		wifi2p4gCpeCnt;
	private	int		wifi5gCpeCnt;
	
	public HashMap<String,Integer> wifi2p4gRssiCpeMap;
	public HashMap<String,Integer> wifi5gRssiCpeMap;

	public HpTrafficReportDailyVO() {
		wifi2p4gRssiCpeMap = new HashMap<String,Integer>();
		wifi5gRssiCpeMap = new HashMap<String,Integer>();
	}

	public String getMntrDt() {
		return mntrDt;
	}
	public void setMntrDt(String mntrDt) {
		this.mntrDt = mntrDt;
	}
	public String getMacAddrVal() {
		return macAddrVal;
	}
	public void setMacAddrVal(String macAddrVal) {
		this.macAddrVal = macAddrVal;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public int getWifi2p4gRssiBadCpeCnt() {
		return wifi2p4gRssiBadCpeCnt;
	}
	public void setWifi2p4gRssiBadCpeCnt(int wifi2p4gRssiBadCpeCnt) {
		this.wifi2p4gRssiBadCpeCnt = wifi2p4gRssiBadCpeCnt;
	}
	public int getWifi5gRssiBadCpeCnt() {
		return wifi5gRssiBadCpeCnt;
	}
	public void setWifi5gRssiBadCpeCnt(int wifi5gRssiBadCpeCnt) {
		this.wifi5gRssiBadCpeCnt = wifi5gRssiBadCpeCnt;
	}
	public int getWifi2p4gCpeCnt() {
		return wifi2p4gCpeCnt;
	}
	public void setWifi2p4gCpeCnt(int wifi2p4gCpeCnt) {
		this.wifi2p4gCpeCnt = wifi2p4gCpeCnt;
	}
	public int getWifi5gCpeCnt() {
		return wifi5gCpeCnt;
	}
	public void setWifi5gCpeCnt(int wifi5gCpeCnt) {
		this.wifi5gCpeCnt = wifi5gCpeCnt;
	}

	@Override
	public boolean isValid() {
		if (this.macAddrVal == null || this.macAddrVal.isEmpty() || this.macAddrVal.length() > 15) {
			return false;
		}
		return true;
	}

	@Override
	public String toDelimiterString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("%s|", mntrDt));
		sb.append(String.format("%s|", macAddrVal));
		sb.append(String.format("%d|", wifi2p4gRssiBadCpeCnt));
		sb.append(String.format("%d|", wifi5gRssiBadCpeCnt));
		sb.append(String.format("%d|", wifi2p4gCpeCnt));
		sb.append(String.format("%d|", wifi5gCpeCnt));
		return sb.toString();
	}

	@Override
	public void add(AggrDataVO obj) {
		HpTrafficReportDailyVO obj2 = (HpTrafficReportDailyVO) obj;
		for (String key : obj2.wifi2p4gRssiCpeMap.keySet()) {
			Integer badRssi = this.wifi2p4gRssiCpeMap.get(key);
			if (badRssi == null) {
				// 기존에 존재하지 않는다면
				Integer badRssi2 = (Integer) obj2.wifi2p4gRssiCpeMap.get(key);
				this.wifi2p4gRssiCpeMap.put(key, badRssi2);
			} else {
				Integer badRssi2 = (Integer) obj2.wifi2p4gRssiCpeMap.get(key);
				if (badRssi.compareTo(badRssi2) > 0) {
					this.wifi2p4gRssiCpeMap.put(key, badRssi2);
				}
			}
		}
		for (String key : obj2.wifi5gRssiCpeMap.keySet()) {
			Integer badRssi = this.wifi5gRssiCpeMap.get(key);
			if (badRssi == null) {
				// 기존에 존재하지 않는다면
				Integer badRssi2 = (Integer) obj2.wifi5gRssiCpeMap.get(key);
				this.wifi5gRssiCpeMap.put(key, badRssi2);
			} else {
				Integer badRssi2 = (Integer) obj2.wifi5gRssiCpeMap.get(key);
				if (badRssi.compareTo(badRssi2) > 0) {
					this.wifi5gRssiCpeMap.put(key, badRssi2);
				}
			}
		}
	}

	@Override
	public void calculate() {
		this.wifi2p4gCpeCnt = wifi2p4gRssiCpeMap.size();
		this.wifi2p4gRssiBadCpeCnt = 0;
		for (String key : this.wifi2p4gRssiCpeMap.keySet()) {
			int badRssi = this.wifi2p4gRssiCpeMap.get(key);
			if (badRssi < this.badRssi) {
				this.wifi2p4gRssiBadCpeCnt ++;
			}
		}
		this.wifi5gCpeCnt = wifi5gRssiCpeMap.size();
		this.wifi5gRssiBadCpeCnt = 0;
		for (String key : this.wifi5gRssiCpeMap.keySet()) {
			int badRssi = this.wifi5gRssiCpeMap.get(key);
			if (badRssi < this.badRssi) {
				this.wifi5gRssiBadCpeCnt ++;
			}
		}
	}
	
	@Override
	public String getKey() {
		return this.macAddrVal;
	}
}
