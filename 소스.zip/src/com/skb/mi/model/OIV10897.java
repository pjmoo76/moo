package com.skb.mi.model;

public class OIV10897 {
	private	String	eqpMdlCd;
	private	String	auditId;
	private	String	wlessEnvQltyCalTypVal;
	private	String	wlessEnvQltyCalDesc;

	public String getEqpMdlCd() {
		return eqpMdlCd;
	}
	public void setEqpMdlCd(String eqpMdlCd) {
		this.eqpMdlCd = eqpMdlCd;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getWlessEnvQltyCalTypVal() {
		return wlessEnvQltyCalTypVal;
	}
	public void setWlessEnvQltyCalTypVal(String wlessEnvQltyCalTypVal) {
		this.wlessEnvQltyCalTypVal = wlessEnvQltyCalTypVal;
	}
	public String getWlessEnvQltyCalDesc() {
		return wlessEnvQltyCalDesc;
	}
	public void setWlessEnvQltyCalDesc(String wlessEnvQltyCalDesc) {
		this.wlessEnvQltyCalDesc = wlessEnvQltyCalDesc;
	}
}
