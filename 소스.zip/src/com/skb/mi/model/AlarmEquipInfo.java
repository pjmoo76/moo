package com.skb.mi.model;

public class AlarmEquipInfo {
	private	String	equipId;
	private	String	equipNm;
	private	String	tpoNm;
	private	String	equipIpAddr;
	private	String	equipMdlCd;
	private	String	equipMdlNm;
	private	String	equipSetLocDesc;
	private	String	tpoCd;
	private	String	mgmtTpoNm;
	private	String	mgmtTpoCd;
	private	String	teamNm;
	private	String	teamId;
	private	String	divNm;
	private	String	divId;
	private	String	equipMdlTypCd;
	private	String	equipMdlTypNm;

	public String getEquipId() {
		return equipId;
	}
	public void setEquipId(String equipId) {
		this.equipId = equipId;
	}
	public String getEquipNm() {
		return equipNm;
	}
	public void setEquipNm(String equipNm) {
		this.equipNm = equipNm;
	}
	public String getTpoNm() {
		return tpoNm;
	}
	public void setTpoNm(String tpoNm) {
		this.tpoNm = tpoNm;
	}
	public String getEquipIpAddr() {
		return equipIpAddr;
	}
	public void setEquipIpAddr(String equipIpAddr) {
		this.equipIpAddr = equipIpAddr;
	}
	public String getEquipMdlCd() {
		return equipMdlCd;
	}
	public void setEquipMdlCd(String equipMdlCd) {
		this.equipMdlCd = equipMdlCd;
	}
	public String getEquipMdlNm() {
		return equipMdlNm;
	}
	public void setEquipMdlNm(String equipMdlNm) {
		this.equipMdlNm = equipMdlNm;
	}
	public String getEquipSetLocDesc() {
		return equipSetLocDesc;
	}
	public void setEquipSetLocDesc(String equipSetLocDesc) {
		this.equipSetLocDesc = equipSetLocDesc;
	}
	public String getTpoCd() {
		return tpoCd;
	}
	public void setTpoCd(String tpoCd) {
		this.tpoCd = tpoCd;
	}
	public String getMgmtTpoNm() {
		return mgmtTpoNm;
	}
	public void setMgmtTpoNm(String mgmtTpoNm) {
		this.mgmtTpoNm = mgmtTpoNm;
	}
	public String getMgmtTpoCd() {
		return mgmtTpoCd;
	}
	public void setMgmtTpoCd(String mgmtTpoCd) {
		this.mgmtTpoCd = mgmtTpoCd;
	}
	public String getTeamNm() {
		return teamNm;
	}
	public void setTeamNm(String teamNm) {
		this.teamNm = teamNm;
	}
	public String getTeamId() {
		return teamId;
	}
	public void setTeamId(String teamId) {
		this.teamId = teamId;
	}
	public String getDivNm() {
		return divNm;
	}
	public void setDivNm(String divNm) {
		this.divNm = divNm;
	}
	public String getDivId() {
		return divId;
	}
	public void setDivId(String divId) {
		this.divId = divId;
	}
	public String getEquipMdlTypCd() {
		return equipMdlTypCd;
	}
	public void setEquipMdlTypCd(String equipMdlTypCd) {
		this.equipMdlTypCd = equipMdlTypCd;
	}
	public String getEquipMdlTypNm() {
		return equipMdlTypNm;
	}
	public void setEquipMdlTypNm(String equipMdlTypNm) {
		this.equipMdlTypNm = equipMdlTypNm;
	}
}
