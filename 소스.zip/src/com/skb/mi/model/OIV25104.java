package com.skb.mi.model;

public class OIV25104 {
	private	String	configDloadOccrDt;
	private	String	auditId;
	private	String	macAddrVal;
	private	String	ipAddr;
	private	String	lastDloadReqDtm;
	private	String	lastDloadSussDtm;
	private	String	configFileNm;
	private	int	dloadReqCnt;
	private	int	dloadSussCnt;
	private	int	nrpsCnt;
	private	int	writeErrCnt;
	private	int	readErrCnt;
	private	int	dupDropCnt;
	private	int	nyClFailCnt;

	public String getConfigDloadOccrDt() {
		return configDloadOccrDt;
	}
	public void setConfigDloadOccrDt(String configDloadOccrDt) {
		this.configDloadOccrDt = configDloadOccrDt;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getMacAddrVal() {
		return macAddrVal;
	}
	public void setMacAddrVal(String macAddrVal) {
		this.macAddrVal = macAddrVal;
	}
	public String getIpAddr() {
		return ipAddr;
	}
	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}
	public String getLastDloadReqDtm() {
		return lastDloadReqDtm;
	}
	public void setLastDloadReqDtm(String lastDloadReqDtm) {
		this.lastDloadReqDtm = lastDloadReqDtm;
	}
	public String getLastDloadSussDtm() {
		return lastDloadSussDtm;
	}
	public void setLastDloadSussDtm(String lastDloadSussDtm) {
		this.lastDloadSussDtm = lastDloadSussDtm;
	}
	public String getConfigFileNm() {
		return configFileNm;
	}
	public void setConfigFileNm(String configFileNm) {
		this.configFileNm = configFileNm;
	}
	public int getDloadReqCnt() {
		return dloadReqCnt;
	}
	public void setDloadReqCnt(int dloadReqCnt) {
		this.dloadReqCnt = dloadReqCnt;
	}
	public int getDloadSussCnt() {
		return dloadSussCnt;
	}
	public void setDloadSussCnt(int dloadSussCnt) {
		this.dloadSussCnt = dloadSussCnt;
	}
	public int getNrpsCnt() {
		return nrpsCnt;
	}
	public void setNrpsCnt(int nrpsCnt) {
		this.nrpsCnt = nrpsCnt;
	}
	public int getWriteErrCnt() {
		return writeErrCnt;
	}
	public void setWriteErrCnt(int writeErrCnt) {
		this.writeErrCnt = writeErrCnt;
	}
	public int getReadErrCnt() {
		return readErrCnt;
	}
	public void setReadErrCnt(int readErrCnt) {
		this.readErrCnt = readErrCnt;
	}
	public int getDupDropCnt() {
		return dupDropCnt;
	}
	public void setDupDropCnt(int dupDropCnt) {
		this.dupDropCnt = dupDropCnt;
	}
	public int getNyClFailCnt() {
		return nyClFailCnt;
	}
	public void setNyClFailCnt(int nyClFailCnt) {
		this.nyClFailCnt = nyClFailCnt;
	}
}
