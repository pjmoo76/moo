package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OQA62100 extends CopyVO {
	private	String	stbEvtCd;
	private	String	auditId;
	private	String	auditDtm;
	private	String	stbEvtTypCd;
	private	String	stbEvtNm;
	private	String	memo;
	private	String	smplCtt;
	private	String	hwYn;
	private	String	iptvYn;
	private	String	heYn;
	private	String	vodYn;
	private	String	rangeStbEvtCd;

	public String getStbEvtCd() {
		return stbEvtCd;
	}
	public void setStbEvtCd(String stbEvtCd) {
		this.stbEvtCd = stbEvtCd;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getStbEvtTypCd() {
		return stbEvtTypCd;
	}
	public void setStbEvtTypCd(String stbEvtTypCd) {
		this.stbEvtTypCd = stbEvtTypCd;
	}
	public String getStbEvtNm() {
		return stbEvtNm;
	}
	public void setStbEvtNm(String stbEvtNm) {
		this.stbEvtNm = stbEvtNm;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public String getSmplCtt() {
		return smplCtt;
	}
	public void setSmplCtt(String smplCtt) {
		this.smplCtt = smplCtt;
	}
	public String getHwYn() {
		return hwYn;
	}
	public void setHwYn(String hwYn) {
		this.hwYn = hwYn;
	}
	public String getIptvYn() {
		return iptvYn;
	}
	public void setIptvYn(String iptvYn) {
		this.iptvYn = iptvYn;
	}
	public String getHeYn() {
		return heYn;
	}
	public void setHeYn(String heYn) {
		this.heYn = heYn;
	}
	public String getVodYn() {
		return vodYn;
	}
	public void setVodYn(String vodYn) {
		this.vodYn = vodYn;
	}
	public String getRangeStbEvtCd() {
		return rangeStbEvtCd;
	}
	public void setRangeStbEvtCd(String rangeStbEvtCd) {
		this.rangeStbEvtCd = rangeStbEvtCd;
	}
	@Override
	public void setKey() {
		this.key = this.stbEvtCd;
	}
	@Override
	public boolean equals(CopyVO obj) {
		OQA62100 dest = (OQA62100) obj;
		if (false == StringUtils.equals(this.stbEvtTypCd, dest.stbEvtTypCd)) return false;
		if (false == StringUtils.equals(this.stbEvtNm, dest.stbEvtNm)) return false;
		if (false == StringUtils.equals(this.memo, dest.memo)) return false;
		if (false == StringUtils.equals(this.smplCtt, dest.smplCtt)) return false;
		if (false == StringUtils.equals(this.hwYn, dest.hwYn)) return false;
		if (false == StringUtils.equals(this.iptvYn, dest.iptvYn)) return false;
		if (false == StringUtils.equals(this.heYn, dest.heYn)) return false;
		if (false == StringUtils.equals(this.vodYn, dest.vodYn)) return false;
		return true;
	}
	@Override
	public void setRange(CopyVO obj) {
		OQA62100 src = (OQA62100) obj;
		this.rangeStbEvtCd = src.stbEvtCd;
	}
}
