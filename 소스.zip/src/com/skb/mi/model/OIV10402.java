package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV10402 extends CopyVO {
	private	String	linkId;
	private	int		thruSerNum;
	private	String	weqpMgmtNum;
	private	String	auditId;
	private	String	auditDtm;
	private	long	custNum;
	private	String	tpoCd;
	private	String	hpyCntrOrgId;
	private	String	supWeqpMgmtNum;
	private	long	repSvcMgmtNum;

	private	String	rangeLinkId;
	private	int		rangeThruSerNum;
	private	String	rangeWeqpMgmtNum;

	public String getLinkId() {
		return linkId;
	}
	public void setLinkId(String linkId) {
		this.linkId = linkId;
	}
	public int getThruSerNum() {
		return thruSerNum;
	}
	public void setThruSerNum(int thruSerNum) {
		this.thruSerNum = thruSerNum;
	}
	public String getWeqpMgmtNum() {
		return weqpMgmtNum;
	}
	public void setWeqpMgmtNum(String weqpMgmtNum) {
		this.weqpMgmtNum = weqpMgmtNum;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public long getCustNum() {
		return custNum;
	}
	public void setCustNum(long custNum) {
		this.custNum = custNum;
	}
	public String getTpoCd() {
		return tpoCd;
	}
	public void setTpoCd(String tpoCd) {
		this.tpoCd = tpoCd;
	}
	public String getHpyCntrOrgId() {
		return hpyCntrOrgId;
	}
	public void setHpyCntrOrgId(String hpyCntrOrgId) {
		this.hpyCntrOrgId = hpyCntrOrgId;
	}
	public String getSupWeqpMgmtNum() {
		return supWeqpMgmtNum;
	}
	public void setSupWeqpMgmtNum(String supWeqpMgmtNum) {
		this.supWeqpMgmtNum = supWeqpMgmtNum;
	}
	public long getRepSvcMgmtNum() {
		return repSvcMgmtNum;
	}
	public void setRepSvcMgmtNum(long repSvcMgmtNum) {
		this.repSvcMgmtNum = repSvcMgmtNum;
	}
	@Override
	public void setKey() {
		//this.key = this.linkId + "|" + this.thruSerNum + "|" + this.weqpMgmtNum;
		this.key = this.weqpMgmtNum;
	}
	@Override
	public boolean equals(CopyVO obj) {
		OIV10402 dest = (OIV10402) obj;
		if (false == StringUtils.equals(this.linkId, dest.linkId)) return false;
		if (this.thruSerNum != dest.thruSerNum) return false;
		if (false == StringUtils.equals(this.weqpMgmtNum, dest.weqpMgmtNum)) return false;
		if (this.custNum != dest.custNum) return false;
		if (false == StringUtils.equals(this.tpoCd, dest.tpoCd)) return false;
		if (false == StringUtils.equals(this.hpyCntrOrgId, dest.hpyCntrOrgId)) return false;
		if (false == StringUtils.equals(this.supWeqpMgmtNum, dest.supWeqpMgmtNum)) return false;
		if (this.repSvcMgmtNum != dest.repSvcMgmtNum) return false;
		return true;
	}
	@Override
	public void setRange(CopyVO obj) {
		OIV10402 src = (OIV10402) obj;
		this.rangeLinkId = src.getLinkId();
		this.rangeThruSerNum = src.getThruSerNum();
		this.rangeWeqpMgmtNum = src.getWeqpMgmtNum();
	}
	public String getRangeLinkId() {
		return rangeLinkId;
	}
	public void setRangeLinkId(String rangeLinkId) {
		this.rangeLinkId = rangeLinkId;
	}
	public int getRangeThruSerNum() {
		return rangeThruSerNum;
	}
	public void setRangeThruSerNum(int rangeThruSerNum) {
		this.rangeThruSerNum = rangeThruSerNum;
	}
	public String getRangeWeqpMgmtNum() {
		return rangeWeqpMgmtNum;
	}
	public void setRangeWeqpMgmtNum(String rangeWeqpMgmtNum) {
		this.rangeWeqpMgmtNum = rangeWeqpMgmtNum;
	}
}
