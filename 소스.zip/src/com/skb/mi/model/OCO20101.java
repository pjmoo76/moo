package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OCO20101 extends CopyVO {
	private	String	commCd;
	private	String	commCdVal;
	private	String	auditId;
	private	String	auditDtm;
	private	String	commCdValNm;
	private	String	commCdValEngNm;
	private	String	commCdValDesc;
	private	int		sortSeq;
	private	String	effStaDtm;
	private	String	effEndDtm;
	private	String	supCommCd;
	private	String	supCommCdVal;
	private	String	etcAttrVal1;
	private	String	etcAttrVal2;

	private	String	rangeCommCd;
	private	String	rangeCommCdVal;

	public String getCommCd() {
		return commCd;
	}
	public void setCommCd(String commCd) {
		this.commCd = commCd;
	}
	public String getCommCdVal() {
		return commCdVal;
	}
	public void setCommCdVal(String commCdVal) {
		this.commCdVal = commCdVal;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getCommCdValNm() {
		return commCdValNm;
	}
	public void setCommCdValNm(String commCdValNm) {
		this.commCdValNm = commCdValNm;
	}
	public String getCommCdValEngNm() {
		return commCdValEngNm;
	}
	public void setCommCdValEngNm(String commCdValEngNm) {
		this.commCdValEngNm = commCdValEngNm;
	}
	public String getCommCdValDesc() {
		return commCdValDesc;
	}
	public void setCommCdValDesc(String commCdValDesc) {
		this.commCdValDesc = commCdValDesc;
	}
	public int getSortSeq() {
		return sortSeq;
	}
	public void setSortSeq(int sortSeq) {
		this.sortSeq = sortSeq;
	}
	public String getEffStaDtm() {
		return effStaDtm;
	}
	public void setEffStaDtm(String effStaDtm) {
		this.effStaDtm = effStaDtm;
	}
	public String getEffEndDtm() {
		return effEndDtm;
	}
	public void setEffEndDtm(String effEndDtm) {
		this.effEndDtm = effEndDtm;
	}
	public String getSupCommCd() {
		return supCommCd;
	}
	public void setSupCommCd(String supCommCd) {
		this.supCommCd = supCommCd;
	}
	public String getSupCommCdVal() {
		return supCommCdVal;
	}
	public void setSupCommCdVal(String supCommCdVal) {
		this.supCommCdVal = supCommCdVal;
	}
	public String getEtcAttrVal1() {
		return etcAttrVal1;
	}
	public void setEtcAttrVal1(String etcAttrVal1) {
		this.etcAttrVal1 = etcAttrVal1;
	}
	public String getEtcAttrVal2() {
		return etcAttrVal2;
	}
	public void setEtcAttrVal2(String etcAttrVal2) {
		this.etcAttrVal2 = etcAttrVal2;
	}

	@Override
	public boolean equals(CopyVO obj) {
		OCO20101 dest = (OCO20101) obj;
		if (false == StringUtils.equals(this.commCd, dest.commCd)) return false;
		if (false == StringUtils.equals(this.commCdVal, dest.commCdVal)) return false;
		if (false == StringUtils.equals(this.commCdValNm, dest.commCdValNm)) return false;
		if (false == StringUtils.equals(this.commCdValEngNm, dest.commCdValEngNm)) return false;
		if (false == StringUtils.equals(this.commCdValDesc, dest.commCdValDesc)) return false;
		if (this.sortSeq != dest.sortSeq) return false;
		if (false == StringUtils.equals(this.effStaDtm, dest.effStaDtm)) return false;
		if (false == StringUtils.equals(this.effEndDtm, dest.effEndDtm)) return false;
		if (false == StringUtils.equals(this.supCommCd, dest.supCommCd)) return false;
		if (false == StringUtils.equals(this.supCommCdVal, dest.supCommCdVal)) return false;
		if (false == StringUtils.equals(this.etcAttrVal1, dest.etcAttrVal1)) return false;
		if (false == StringUtils.equals(this.etcAttrVal2, dest.etcAttrVal2)) return false;
		return true;
	}
	@Override
	public void setKey() {
		this.key = this.commCd + "|" + this.commCdVal;
	}

	public String getRangeCommCd() {
		return rangeCommCd;
	}
	public void setRangeCommCd(String rangeCommCd) {
		this.rangeCommCd = rangeCommCd;
	}
	public String getRangeCommCdVal() {
		return rangeCommCdVal;
	}
	public void setRangeCommCdVal(String rangeCommCdVal) {
		this.rangeCommCdVal = rangeCommCdVal;
	}

	@Override
	public void setRange(CopyVO obj) {
		OCO20101 src = (OCO20101) obj;
		this.rangeCommCd = src.commCd;
		this.rangeCommCdVal = src.commCdVal;
	}

}
