package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV10673 extends CopyVO {
	private	String	weqpMgmtNum;
	private	String	auditId;
	private	String	auditDtm;
	private	String	macAddrVal;
	private	String	custNm;
	private	long	custNum;
	private	long	inetSvcMgmtNum;
	private	long	iptvSvcMgmtNum;
	private	long	phonSvcMgmtNum;
	private	String	l3EquipMgmtNum;
	private	String	l3RackNum;
	private	String	l3ShlfNum;
	private	String	l3CardNum;
	private	String	l3PortNum;
	private	String	l2EquipMgmtNum;
	private	String	l2RackNum;
	private	String	l2ShlfNum;
	private	String	l2CardNum;
	private	String	l2PortNum;
	private	String	ccellNum;
	private	String	onuEquipId;
	private	String	rnTapNum;
	private	String	telpolNum;
	private	String	phonNum;
	private	String	rangeWeqpMgmtNum;
	/* ADMAS DB와 BS DB 현황화 작업 및 CATV칼럼 추가 반영 (2025-03-11 by KMY) */
	private	String	shspdSetAddr;
	private	String	inetSvcNm;
	private	String	inetSvcNum;
	private	String	inetOrbkStCd;
	private	String	iptvSvcNm;
	private	String	iptvSvcNum;
	private	String	iptvOrbkStCd;
	private	String	phonSvcNm;
	private	String	phonSvcNum;
	private	String	wphonOrbkStCd;
	private	String	homeCntrCd;
	private	String	oltSupEquipMgmtNum1;
	private	String	oltSupEquipMgmtNum2;
	private	String	svcTechMthdCd;
	private	String	acntNum;
	private	String	tvClVal;
	private	String	scrbrTbSoClCd;
	private	String	stbInrCmMacAddr;
	/* WEQP_SET_LOC_CTT 칼럼 추가 반영 (2025-12-09 by KMY) */
	private	String	weqpSetLocCtt;

	public String getWeqpMgmtNum() {
		return weqpMgmtNum;
	}
	public void setWeqpMgmtNum(String weqpMgmtNum) {
		this.weqpMgmtNum = weqpMgmtNum;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getMacAddrVal() {
		return macAddrVal;
	}
	public void setMacAddrVal(String macAddrVal) {
		this.macAddrVal = macAddrVal;
	}
	public String getCustNm() {
		return custNm;
	}
	public void setCustNm(String custNm) {
		this.custNm = custNm;
	}
	public long getCustNum() {
		return custNum;
	}
	public void setCustNum(long custNum) {
		this.custNum = custNum;
	}
	public long getInetSvcMgmtNum() {
		return inetSvcMgmtNum;
	}
	public void setInetSvcMgmtNum(long inetSvcMgmtNum) {
		this.inetSvcMgmtNum = inetSvcMgmtNum;
	}
	public long getIptvSvcMgmtNum() {
		return iptvSvcMgmtNum;
	}
	public void setIptvSvcMgmtNum(long iptvSvcMgmtNum) {
		this.iptvSvcMgmtNum = iptvSvcMgmtNum;
	}
	public long getPhonSvcMgmtNum() {
		return phonSvcMgmtNum;
	}
	public void setPhonSvcMgmtNum(long phonSvcMgmtNum) {
		this.phonSvcMgmtNum = phonSvcMgmtNum;
	}
	public String getL3EquipMgmtNum() {
		return l3EquipMgmtNum;
	}
	public void setL3EquipMgmtNum(String l3EquipMgmtNum) {
		this.l3EquipMgmtNum = l3EquipMgmtNum;
	}
	public String getL3RackNum() {
		return l3RackNum;
	}
	public void setL3RackNum(String l3RackNum) {
		this.l3RackNum = l3RackNum;
	}
	public String getL3ShlfNum() {
		return l3ShlfNum;
	}
	public void setL3ShlfNum(String l3ShlfNum) {
		this.l3ShlfNum = l3ShlfNum;
	}
	public String getL3CardNum() {
		return l3CardNum;
	}
	public void setL3CardNum(String l3CardNum) {
		this.l3CardNum = l3CardNum;
	}
	public String getL3PortNum() {
		return l3PortNum;
	}
	public void setL3PortNum(String l3PortNum) {
		this.l3PortNum = l3PortNum;
	}
	public String getL2EquipMgmtNum() {
		return l2EquipMgmtNum;
	}
	public void setL2EquipMgmtNum(String l2EquipMgmtNum) {
		this.l2EquipMgmtNum = l2EquipMgmtNum;
	}
	public String getL2RackNum() {
		return l2RackNum;
	}
	public void setL2RackNum(String l2RackNum) {
		this.l2RackNum = l2RackNum;
	}
	public String getL2ShlfNum() {
		return l2ShlfNum;
	}
	public void setL2ShlfNum(String l2ShlfNum) {
		this.l2ShlfNum = l2ShlfNum;
	}
	public String getL2CardNum() {
		return l2CardNum;
	}
	public void setL2CardNum(String l2CardNum) {
		this.l2CardNum = l2CardNum;
	}
	public String getL2PortNum() {
		return l2PortNum;
	}
	public void setL2PortNum(String l2PortNum) {
		this.l2PortNum = l2PortNum;
	}
	public String getCcellNum() {
		return ccellNum;
	}
	public void setCcellNum(String ccellNum) {
		this.ccellNum = ccellNum;
	}
	public String getOnuEquipId() {
		return onuEquipId;
	}
	public void setOnuEquipId(String onuEquipId) {
		this.onuEquipId = onuEquipId;
	}
	public String getRnTapNum() {
		return rnTapNum;
	}
	public void setRnTapNum(String rnTapNum) {
		this.rnTapNum = rnTapNum;
	}
	public String getTelpolNum() {
		return telpolNum;
	}
	public void setTelpolNum(String telpolNum) {
		this.telpolNum = telpolNum;
	}
	public String getPhonNum() {
		return phonNum;
	}
	public void setPhonNum(String phonNum) {
		this.phonNum = phonNum;
	}
	public String getRangeWeqpMgmtNum() {
		return rangeWeqpMgmtNum;
	}
	public void setRangeWeqpMgmtNum(String rangeWeqpMgmtNum) {
		this.rangeWeqpMgmtNum = rangeWeqpMgmtNum;
	}
	@Override
	public void setKey() {
		this.key = this.weqpMgmtNum;
	}

	/* ADMAS DB와 BS DB 현황화 작업 및 CATV칼럼 추가 반영 (2025-03-11 by KMY) */
	public String getShspdSetAddr() {
		return shspdSetAddr;
	}
	public void setShspdSetAddr(String shspdSetAddr) {
		this.shspdSetAddr = shspdSetAddr;
	}
	public String getInetSvcNm() {
		return inetSvcNm;
	}
	public void setInetSvcNm(String inetSvcNm) {
		this.inetSvcNm = inetSvcNm;
	}
	public String getInetSvcNum() {
		return inetSvcNum;
	}
	public void setInetSvcNum(String inetSvcNum) {
		this.inetSvcNum = inetSvcNum;
	}
	public String getInetOrbkStCd() {
		return inetOrbkStCd;
	}
	public void setInetOrbkStCd(String inetOrbkStCd) {
		this.inetOrbkStCd = inetOrbkStCd;
	}
	public String getIptvSvcNm() {
		return iptvSvcNm;
	}
	public void setIptvSvcNm(String iptvSvcNm) {
		this.iptvSvcNm = iptvSvcNm;
	}
	public String getIptvSvcNum() {
		return iptvSvcNum;
	}
	public void setIptvSvcNum(String iptvSvcNum) {
		this.iptvSvcNum = iptvSvcNum;
	}
	public String getIptvOrbkStCd() {
		return iptvOrbkStCd;
	}
	public void setIptvOrbkStCd(String iptvOrbkStCd) {
		this.iptvOrbkStCd = iptvOrbkStCd;
	}
	public String getPhonSvcNm() {
		return phonSvcNm;
	}
	public void setPhonSvcNm(String phonSvcNm) {
		this.phonSvcNm = phonSvcNm;
	}
	public String getPhonSvcNum() {
		return phonSvcNum;
	}
	public void setPhonSvcNum(String phonSvcNum) {
		this.phonSvcNum = phonSvcNum;
	}
	public String getWphonOrbkStCd() {
		return wphonOrbkStCd;
	}
	public void setWphonOrbkStCd(String wphonOrbkStCd) {
		this.wphonOrbkStCd = wphonOrbkStCd;
	}
	public String getHomeCntrCd() {
		return homeCntrCd;
	}
	public void setHomeCntrCd(String homeCntrCd) {
		this.homeCntrCd = homeCntrCd;
	}
	public String getOltSupEquipMgmtNum1() {
		return oltSupEquipMgmtNum1;
	}
	public void setOltSupEquipMgmtNum1(String oltSupEquipMgmtNum1) {
		this.oltSupEquipMgmtNum1 = oltSupEquipMgmtNum1;
	}
	public String getOltSupEquipMgmtNum2() {
		return oltSupEquipMgmtNum2;
	}
	public void setOltSupEquipMgmtNum2(String oltSupEquipMgmtNum2) {
		this.oltSupEquipMgmtNum2 = oltSupEquipMgmtNum2;
	}
	public String getSvcTechMthdCd() {
		return svcTechMthdCd;
	}
	public void setSvcTechMthdCd(String svcTechMthdCd) {
		this.svcTechMthdCd = svcTechMthdCd;
	}
	public String getAcntNum() {
		return acntNum;
	}
	public void setAcntNum(String acntNum) {
		this.acntNum = acntNum;
	}
	public String getTvClVal() {
		return tvClVal;
	}
	public void setTvClVal(String tvClVal) {
		this.tvClVal = tvClVal;
	}
	public String getScrbrTbSoClCd() {
		return scrbrTbSoClCd;
	}
	public void setScrbrTbSoClCd(String scrbrTbSoClCd) {
		this.scrbrTbSoClCd = scrbrTbSoClCd;
	}
	public String getStbInrCmMacAddr() {
		return stbInrCmMacAddr;
	}
	public void setStbInrCmMacAddr(String stbInrCmMacAddr) {
		this.stbInrCmMacAddr = stbInrCmMacAddr;
	}
	public String getWeqpSetLocCtt() {
		return weqpSetLocCtt;
	}
	public void setWeqpSetLocCtt(String weqpSetLocCtt) {
		this.weqpSetLocCtt = weqpSetLocCtt;
	}

	@Override
	public boolean equals(CopyVO obj) {
		OIV10673 dest = (OIV10673) obj;
		if (false == StringUtils.equals(this.weqpMgmtNum, dest.weqpMgmtNum)) return false;
		if (false == StringUtils.equals(this.macAddrVal, dest.macAddrVal)) return false;
		if (false == StringUtils.equals(this.custNm, dest.custNm)) return false;
		if (this.custNum != dest.custNum) return false;
		if (this.inetSvcMgmtNum != dest.inetSvcMgmtNum) return false;
		if (this.iptvSvcMgmtNum != dest.iptvSvcMgmtNum) return false;
		if (this.phonSvcMgmtNum != dest.phonSvcMgmtNum) return false;
		if (false == StringUtils.equals(this.l3EquipMgmtNum, dest.l3EquipMgmtNum)) return false;
		if (false == StringUtils.equals(this.l3RackNum, dest.l3RackNum)) return false;
		if (false == StringUtils.equals(this.l3ShlfNum, dest.l3ShlfNum)) return false;
		if (false == StringUtils.equals(this.l3CardNum, dest.l3CardNum)) return false;
		if (false == StringUtils.equals(this.l3PortNum, dest.l3PortNum)) return false;
		if (false == StringUtils.equals(this.l2EquipMgmtNum, dest.l2EquipMgmtNum)) return false;
		if (false == StringUtils.equals(this.l2RackNum, dest.l2RackNum)) return false;
		if (false == StringUtils.equals(this.l2ShlfNum, dest.l2ShlfNum)) return false;
		if (false == StringUtils.equals(this.l2CardNum, dest.l2CardNum)) return false;
		if (false == StringUtils.equals(this.l2PortNum, dest.l2PortNum)) return false;
		if (false == StringUtils.equals(this.ccellNum, dest.ccellNum)) return false;
		if (false == StringUtils.equals(this.onuEquipId, dest.onuEquipId)) return false;
		if (false == StringUtils.equals(this.rnTapNum, dest.rnTapNum)) return false;
		if (false == StringUtils.equals(this.telpolNum, dest.telpolNum)) return false;
		if (false == StringUtils.equals(this.phonNum, dest.phonNum)) return false;

		/* ADMAS DB와 BS DB 현황화 작업 및 CATV칼럼 추가 반영 (2025-03-11 by KMY) */
		if (false == StringUtils.equals(this.shspdSetAddr, dest.shspdSetAddr)) return false;
		if (false == StringUtils.equals(this.inetSvcNm, dest.inetSvcNm)) return false;
		if (false == StringUtils.equals(this.inetSvcNum, dest.inetSvcNum)) return false;
		if (false == StringUtils.equals(this.inetOrbkStCd, dest.inetOrbkStCd)) return false;
		if (false == StringUtils.equals(this.iptvSvcNm, dest.iptvSvcNm)) return false;
		if (false == StringUtils.equals(this.iptvSvcNum, dest.iptvSvcNum)) return false;
		if (false == StringUtils.equals(this.iptvOrbkStCd, dest.iptvOrbkStCd)) return false;
		if (false == StringUtils.equals(this.phonSvcNm, dest.phonSvcNm)) return false;
		if (false == StringUtils.equals(this.phonSvcNum, dest.phonSvcNum)) return false;
		if (false == StringUtils.equals(this.wphonOrbkStCd, dest.wphonOrbkStCd)) return false;
		if (false == StringUtils.equals(this.homeCntrCd, dest.homeCntrCd)) return false;
		if (false == StringUtils.equals(this.oltSupEquipMgmtNum1, dest.oltSupEquipMgmtNum1)) return false;
		if (false == StringUtils.equals(this.oltSupEquipMgmtNum2, dest.oltSupEquipMgmtNum2)) return false;
		if (false == StringUtils.equals(this.svcTechMthdCd, dest.svcTechMthdCd)) return false;
		if (false == StringUtils.equals(this.acntNum, dest.acntNum)) return false;
		if (false == StringUtils.equals(this.tvClVal, dest.tvClVal)) return false;
		if (false == StringUtils.equals(this.scrbrTbSoClCd, dest.scrbrTbSoClCd)) return false;
		if (false == StringUtils.equals(this.stbInrCmMacAddr, dest.stbInrCmMacAddr)) return false;
		if (false == StringUtils.equals(this.weqpSetLocCtt, dest.weqpSetLocCtt)) return false;
		return true;
	}
	@Override
	public void setRange(CopyVO obj) {
		OIV10673 src = (OIV10673) obj;
		this.rangeWeqpMgmtNum = src.weqpMgmtNum;
	}
}
