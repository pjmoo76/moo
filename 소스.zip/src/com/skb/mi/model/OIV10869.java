package com.skb.mi.model;

public class OIV10869 {
	private	String	ipAddr;
	private	String	auditId;
	private	String	fstAuthDtm;
	private	String	recntAuthDtm;
	private	String	dhcpIpAddr;
	private	String	macAddrVal;
	private	String	apAuthVal;
	private	String	authSysNm;
	private	String	bfApAuthVal;
	private	long	inetSvcMgmtNum;
	private	String	skbWeqpYn;
	private	String	prvShrrYn;

	public String getIpAddr() {
		return ipAddr;
	}
	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getFstAuthDtm() {
		return fstAuthDtm;
	}
	public void setFstAuthDtm(String fstAuthDtm) {
		this.fstAuthDtm = fstAuthDtm;
	}
	public String getRecntAuthDtm() {
		return recntAuthDtm;
	}
	public void setRecntAuthDtm(String recntAuthDtm) {
		this.recntAuthDtm = recntAuthDtm;
	}
	public String getDhcpIpAddr() {
		return dhcpIpAddr;
	}
	public void setDhcpIpAddr(String dhcpIpAddr) {
		this.dhcpIpAddr = dhcpIpAddr;
	}
	public String getMacAddrVal() {
		return macAddrVal;
	}
	public void setMacAddrVal(String macAddrVal) {
		this.macAddrVal = macAddrVal;
	}
	public String getApAuthVal() {
		return apAuthVal;
	}
	public void setApAuthVal(String apAuthVal) {
		this.apAuthVal = apAuthVal;
	}
	public String getAuthSysNm() {
		return authSysNm;
	}
	public void setAuthSysNm(String authSysNm) {
		this.authSysNm = authSysNm;
	}
	public String getBfApAuthVal() {
		return bfApAuthVal;
	}
	public void setBfApAuthVal(String bfApAuthVal) {
		this.bfApAuthVal = bfApAuthVal;
	}
	public long getInetSvcMgmtNum() {
		return inetSvcMgmtNum;
	}
	public void setInetSvcMgmtNum(long inetSvcMgmtNum) {
		this.inetSvcMgmtNum = inetSvcMgmtNum;
	}
	public String getSkbWeqpYn() {
		return skbWeqpYn;
	}
	public void setSkbWeqpYn(String skbWeqpYn) {
		this.skbWeqpYn = skbWeqpYn;
	}
	public String getPrvShrrYn() {
		return prvShrrYn;
	}
	public void setPrvShrrYn(String prvShrrYn) {
		this.prvShrrYn = prvShrrYn;
	}
}
