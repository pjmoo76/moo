package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OMN73151 extends AggrDataVO {
	private	String	mntrDthr;
	private	String	apMacAddr;
	private String	auditId;
	private	String	netClCd;
	private	String	infoCntrCd;
	private	String	distbCntrCd;
	private	String	homeCntrCd;
	private	String	l3EquipId;
	private	String	l2EquipId;
	private	String	ccellNum;
	private	String	eqpMdlCd;
	private	long	inetSvcMgmtNum;
	private	long	wanInByteCnt;
	private	long	wanOutByteCnt;
	private	int		wanCrcOccrCnt;
	private	long	lan1InByteCnt;
	private	long	lan1OutByteCnt;
	private	int		lan1CrcOccrCnt;
	private	long	lan2InByteCnt;
	private	long	lan2OutByteCnt;
	private	int		lan2CrcOccrCnt;
	private	long	lan3InByteCnt;
	private	long	lan3OutByteCnt;
	private	int		lan3CrcOccrCnt;
	private	long	lan4InByteCnt;
	private	long	lan4OutByteCnt;
	private	int		lan4CrcOccrCnt;
	private	String	eqpVerInfo;
	private	String	recntCrcOccrDtm;
	
	private String	evtTime;

	/*
	private	int		preWanCrcOccrCnt;
	private	int		preLan1CrcOccrCnt;
	private	int		preLan2CrcOccrCnt;
	private	int		preLan3CrcOccrCnt;
	private	int		preLan4CrcOccrCnt;
	*/
	
	public String getMntrDthr() {
		return mntrDthr;
	}
	public void setMntrDthr(String mntrDthr) {
		this.mntrDthr = mntrDthr;
	}
	public String getApMacAddr() {
		return apMacAddr;
	}
	public void setApMacAddr(String apMacAddr) {
		this.apMacAddr = apMacAddr;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getNetClCd() {
		return netClCd;
	}
	public void setNetClCd(String netClCd) {
		this.netClCd = netClCd;
	}
	public String getInfoCntrCd() {
		return infoCntrCd;
	}
	public void setInfoCntrCd(String infoCntrCd) {
		this.infoCntrCd = infoCntrCd;
	}
	public String getDistbCntrCd() {
		return distbCntrCd;
	}
	public void setDistbCntrCd(String distbCntrCd) {
		this.distbCntrCd = distbCntrCd;
	}
	public String getHomeCntrCd() {
		return homeCntrCd;
	}
	public void setHomeCntrCd(String homeCntrCd) {
		this.homeCntrCd = homeCntrCd;
	}
	public String getL3EquipId() {
		return l3EquipId;
	}
	public void setL3EquipId(String l3EquipId) {
		this.l3EquipId = l3EquipId;
	}
	public String getL2EquipId() {
		return l2EquipId;
	}
	public void setL2EquipId(String l2EquipId) {
		this.l2EquipId = l2EquipId;
	}
	public String getCcellNum() {
		return ccellNum;
	}
	public void setCcellNum(String ccellNum) {
		this.ccellNum = ccellNum;
	}
	public String getEqpMdlCd() {
		return eqpMdlCd;
	}
	public void setEqpMdlCd(String eqpMdlCd) {
		this.eqpMdlCd = eqpMdlCd;
	}
	public long getInetSvcMgmtNum() {
		return inetSvcMgmtNum;
	}
	public void setInetSvcMgmtNum(long inetSvcMgmtNum) {
		this.inetSvcMgmtNum = inetSvcMgmtNum;
	}
	public long getWanInByteCnt() {
		return wanInByteCnt;
	}
	public void setWanInByteCnt(long wanInByteCnt) {
		this.wanInByteCnt = wanInByteCnt;
	}
	public long getWanOutByteCnt() {
		return wanOutByteCnt;
	}
	public void setWanOutByteCnt(long wanOutByteCnt) {
		this.wanOutByteCnt = wanOutByteCnt;
	}
	public int getWanCrcOccrCnt() {
		return wanCrcOccrCnt;
	}
	public void setWanCrcOccrCnt(int wanCrcOccrCnt) {
		this.wanCrcOccrCnt = wanCrcOccrCnt;
	}
	public long getLan1InByteCnt() {
		return lan1InByteCnt;
	}
	public void setLan1InByteCnt(long lan1InByteCnt) {
		this.lan1InByteCnt = lan1InByteCnt;
	}
	public long getLan1OutByteCnt() {
		return lan1OutByteCnt;
	}
	public void setLan1OutByteCnt(long lan1OutByteCnt) {
		this.lan1OutByteCnt = lan1OutByteCnt;
	}
	public int getLan1CrcOccrCnt() {
		return lan1CrcOccrCnt;
	}
	public void setLan1CrcOccrCnt(int lan1CrcOccrCnt) {
		this.lan1CrcOccrCnt = lan1CrcOccrCnt;
	}
	public long getLan2InByteCnt() {
		return lan2InByteCnt;
	}
	public void setLan2InByteCnt(long lan2InByteCnt) {
		this.lan2InByteCnt = lan2InByteCnt;
	}
	public long getLan2OutByteCnt() {
		return lan2OutByteCnt;
	}
	public void setLan2OutByteCnt(long lan2OutByteCnt) {
		this.lan2OutByteCnt = lan2OutByteCnt;
	}
	public int getLan2CrcOccrCnt() {
		return lan2CrcOccrCnt;
	}
	public void setLan2CrcOccrCnt(int lan2CrcOccrCnt) {
		this.lan2CrcOccrCnt = lan2CrcOccrCnt;
	}
	public long getLan3InByteCnt() {
		return lan3InByteCnt;
	}
	public void setLan3InByteCnt(long lan3InByteCnt) {
		this.lan3InByteCnt = lan3InByteCnt;
	}
	public long getLan3OutByteCnt() {
		return lan3OutByteCnt;
	}
	public void setLan3OutByteCnt(long lan3OutByteCnt) {
		this.lan3OutByteCnt = lan3OutByteCnt;
	}
	public int getLan3CrcOccrCnt() {
		return lan3CrcOccrCnt;
	}
	public void setLan3CrcOccrCnt(int lan3CrcOccrCnt) {
		this.lan3CrcOccrCnt = lan3CrcOccrCnt;
	}
	public long getLan4InByteCnt() {
		return lan4InByteCnt;
	}
	public void setLan4InByteCnt(long lan4InByteCnt) {
		this.lan4InByteCnt = lan4InByteCnt;
	}
	public long getLan4OutByteCnt() {
		return lan4OutByteCnt;
	}
	public void setLan4OutByteCnt(long lan4OutByteCnt) {
		this.lan4OutByteCnt = lan4OutByteCnt;
	}
	public int getLan4CrcOccrCnt() {
		return lan4CrcOccrCnt;
	}
	public void setLan4CrcOccrCnt(int lan4CrcOccrCnt) {
		this.lan4CrcOccrCnt = lan4CrcOccrCnt;
	}

	/*
	public int getPreWanCrcOccrCnt() {
		return preWanCrcOccrCnt;
	}
	public void setPreWanCrcOccrCnt(int preWanCrcOccrCnt) {
		this.preWanCrcOccrCnt = preWanCrcOccrCnt;
	}
	public int getPreLan1CrcOccrCnt() {
		return preLan1CrcOccrCnt;
	}
	public void setPreLan1CrcOccrCnt(int preLan1CrcOccrCnt) {
		this.preLan1CrcOccrCnt = preLan1CrcOccrCnt;
	}
	public int getPreLan2CrcOccrCnt() {
		return preLan2CrcOccrCnt;
	}
	public void setPreLan2CrcOccrCnt(int preLan2CrcOccrCnt) {
		this.preLan2CrcOccrCnt = preLan2CrcOccrCnt;
	}
	public int getPreLan3CrcOccrCnt() {
		return preLan3CrcOccrCnt;
	}
	public void setPreLan3CrcOccrCnt(int preLan3CrcOccrCnt) {
		this.preLan3CrcOccrCnt = preLan3CrcOccrCnt;
	}
	public int getPreLan4CrcOccrCnt() {
		return preLan4CrcOccrCnt;
	}
	public void setPreLan4CrcOccrCnt(int preLan4CrcOccrCnt) {
		this.preLan4CrcOccrCnt = preLan4CrcOccrCnt;
	}
	*/
	public String getEqpVerInfo() {
		return eqpVerInfo;
	}
	public void setEqpVerInfo(String eqpVerInfo) {
		this.eqpVerInfo = eqpVerInfo;
	}
	public String getRecntCrcOccrDtm() {
		return recntCrcOccrDtm;
	}
	public void setRecntCrcOccrDtm(String recntCrcOccrDtm) {
		this.recntCrcOccrDtm = recntCrcOccrDtm;
	}
	public String getEvtTime() {
		return evtTime;
	}
	public void setEvtTime(String evtTime) {
		this.evtTime = evtTime;
	}

	@Override
	public boolean isValid() {
		if (this.apMacAddr == null || this.apMacAddr.isEmpty() || this.apMacAddr.length() > 15) {
			return false;
		}
		return true;
	}
	@Override
	public String toDelimiterString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("%s|", mntrDthr));
		sb.append(String.format("%s|", apMacAddr));
		sb.append(String.format("%s|", auditId));
		sb.append(String.format("%s|", StringUtils.null2Empty(netClCd)));
		sb.append(String.format("%s|", StringUtils.null2Empty(infoCntrCd)));
		sb.append(String.format("%s|", StringUtils.null2Empty(distbCntrCd)));
		sb.append(String.format("%s|", StringUtils.null2Empty(homeCntrCd)));
		sb.append(String.format("%s|", StringUtils.null2Empty(l3EquipId)));
		sb.append(String.format("%s|", StringUtils.null2Empty(l2EquipId)));
		sb.append(String.format("%s|", StringUtils.null2Empty(ccellNum)));
		sb.append(String.format("%s|", StringUtils.null2Empty(eqpMdlCd)));
		sb.append(String.format("%d|", inetSvcMgmtNum));
		sb.append(String.format("%d|", wanInByteCnt));
		sb.append(String.format("%d|", wanOutByteCnt));
		sb.append(String.format("%d|", wanCrcOccrCnt));
		sb.append(String.format("%d|", lan1InByteCnt));
		sb.append(String.format("%d|", lan1OutByteCnt));
		sb.append(String.format("%d|", lan1CrcOccrCnt));
		sb.append(String.format("%d|", lan2InByteCnt));
		sb.append(String.format("%d|", lan2OutByteCnt));
		sb.append(String.format("%d|", lan2CrcOccrCnt));
		sb.append(String.format("%d|", lan3InByteCnt));
		sb.append(String.format("%d|", lan3OutByteCnt));
		sb.append(String.format("%d|", lan3CrcOccrCnt));
		sb.append(String.format("%d|", lan4InByteCnt));
		sb.append(String.format("%d|", lan4OutByteCnt));
		sb.append(String.format("%d|", lan4CrcOccrCnt));
		sb.append(String.format("%s|", StringUtils.null2Empty(eqpVerInfo)));
		return sb.toString();
	}
	@Override
	public void add(AggrDataVO obj) {
		OMN73151 addObj = (OMN73151) obj;
		this.wanInByteCnt += addObj.wanInByteCnt;
		this.wanOutByteCnt += addObj.wanOutByteCnt;
		this.wanCrcOccrCnt += addObj.wanCrcOccrCnt;

		this.lan1InByteCnt += addObj.lan1InByteCnt;
		this.lan1OutByteCnt += addObj.lan1OutByteCnt;
		this.lan1CrcOccrCnt += addObj.lan1CrcOccrCnt;

		this.lan2InByteCnt += addObj.lan2InByteCnt;
		this.lan2OutByteCnt += addObj.lan2OutByteCnt;
		this.lan2CrcOccrCnt += addObj.lan2CrcOccrCnt;
		
		this.lan3InByteCnt += addObj.lan3InByteCnt;
		this.lan3OutByteCnt += addObj.lan3OutByteCnt;
		this.lan3CrcOccrCnt += addObj.lan3CrcOccrCnt;
		
		this.lan4InByteCnt += addObj.lan4InByteCnt;
		this.lan4OutByteCnt += addObj.lan4OutByteCnt;
		this.lan4CrcOccrCnt += addObj.lan4CrcOccrCnt;
		
		if (addObj.wanCrcOccrCnt > 0 || addObj.lan1CrcOccrCnt > 0 || addObj.lan2CrcOccrCnt > 0 || addObj.lan3CrcOccrCnt > 0 || addObj.lan4CrcOccrCnt > 0) {
			this.recntCrcOccrDtm = addObj.evtTime;
		}
	}
}
