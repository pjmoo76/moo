package com.skb.mi.model;

public class WeqpRelVO {
	String	linkId;
	String	thruSerNum;
	String	custNum;
	String	weqpMgmtNum;
	String	weqpMdlTypCd;
	String	supWeqpMgmtNum;
	String	repSvcMgmtNum;
	String	inetSvcMgmtNum;
	String	iptvSvcMgmtNum;
	String	phonSvcMgmtNum;
	String	newSupWeqpMgmtNum;

	public void WeqpRelVo() {
		
	}

	public String getLinkId() {
		return linkId;
	}

	public void setLinkId(String linkId) {
		this.linkId = linkId;
	}

	public String getThruSerNum() {
		return thruSerNum;
	}

	public void setThruSerNum(String thruSerNum) {
		this.thruSerNum = thruSerNum;
	}

	public String getCustNum() {
		return custNum;
	}

	public void setCustNum(String custNum) {
		this.custNum = custNum;
	}

	public String getWeqpMgmtNum() {
		return weqpMgmtNum;
	}

	public void setWeqpMgmtNum(String weqpMgmtNum) {
		this.weqpMgmtNum = weqpMgmtNum;
	}

	public String getWeqpMdlTypCd() {
		return weqpMdlTypCd;
	}

	public void setWeqpMdlTypCd(String weqpMdlTypCd) {
		this.weqpMdlTypCd = weqpMdlTypCd;
	}

	public String getSupWeqpMgmtNum() {
		return supWeqpMgmtNum;
	}

	public void setSupWeqpMgmtNum(String supWeqpMgmtNum) {
		this.supWeqpMgmtNum = supWeqpMgmtNum;
	}

	public String getRepSvcMgmtNum() {
		return repSvcMgmtNum;
	}

	public void setRepSvcMgmtNum(String repSvcMgmtNum) {
		this.repSvcMgmtNum = repSvcMgmtNum;
	}

	public String getInetSvcMgmtNum() {
		return inetSvcMgmtNum;
	}

	public void setInetSvcMgmtNum(String inetSvcMgmtNum) {
		this.inetSvcMgmtNum = inetSvcMgmtNum;
	}

	public String getIptvSvcMgmtNum() {
		return iptvSvcMgmtNum;
	}

	public void setIptvSvcMgmtNum(String iptvSvcMgmtNum) {
		this.iptvSvcMgmtNum = iptvSvcMgmtNum;
	}

	public String getPhonSvcMgmtNum() {
		return phonSvcMgmtNum;
	}

	public void setPhonSvcMgmtNum(String phonSvcMgmtNum) {
		this.phonSvcMgmtNum = phonSvcMgmtNum;
	}
	
	public String getNewSupWeqpMgmtNum() {
		return newSupWeqpMgmtNum;
	}

	public void setNewSupWeqpMgmtNum(String newSupWeqpMgmtNum) {
		this.newSupWeqpMgmtNum = newSupWeqpMgmtNum;
	}

	public String debugMessage() {
		return "(linkId=" + linkId + "),(thruSerNum=" + thruSerNum + "),(custNum=" + custNum +
				"),(repSvcMgmtNum=" + repSvcMgmtNum +
				"),(inetSvcMgmtNum=" + inetSvcMgmtNum +
				"),(iptvSvcMgmtNum=" + iptvSvcMgmtNum +
				"),(phonSvcMgmtNum=" + phonSvcMgmtNum +
				"),(weqpMgmtNum=" + weqpMgmtNum + "),(weqpMdlTypCd=" + weqpMdlTypCd + "),(supWeqpMgmtNum=" + supWeqpMgmtNum +
				"),(newSupWeqpMgmtNum=" + newSupWeqpMgmtNum + ")";
	}
}
