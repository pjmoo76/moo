package com.skb.mi.model;

public class OMN32523 {
	private	String	evtRcvDtm;
	private	String	macAddrVal;
	private	String	uuidVal;
	private	String	auditId;
	private	String	evtOccrDtm;
	private	String	netClCd;
	private	String	infoCntrCd;
	private	String	distbCntrCd;
	private	String	homeCntrCd;
	private	String	l3TidVal;
	private	String	l3EquipId;
	private	String	l2TidVal;
	private	String	l2EquipId;
	private	String	ccellNum;
	private	String	eqpMdlCd;
	private	String	eqpVerInfo;
	private	long	inetSvcMgmtNum;
	private	String	inetSvcNm;
	private	long	iptvSvcMgmtNum;
	private	String	iptvSvcNm;
	private	String	ipAddr;
	private	String	eqpUptimeTmsInfo;
	private	String	cpeIpAddr;
	private	String	cpeMacAddr;
	private	String	portNum;
	private	double	rtripTmsAvgVal;
	private	double	rtripTmsMaxVal;
	private	double	rtripTmsMinVal;
	private	int		timeoutCnt;
	
	public OMN32523() {
		
	}
	
	public OMN32523(OMN32523 source) {
		this.evtRcvDtm = source.evtRcvDtm;
		this.macAddrVal = source.macAddrVal;
		this.uuidVal = source.uuidVal;
		this.auditId = source.auditId;
		this.evtOccrDtm = source.evtOccrDtm;
		this.netClCd = source.netClCd;
		this.infoCntrCd = source.infoCntrCd;
		this.distbCntrCd = source.distbCntrCd;
		this.homeCntrCd = source.homeCntrCd;
		this.l3TidVal = source.l3TidVal;
		this.l3EquipId = source.l3EquipId;
		this.l2TidVal = source.l2TidVal;
		this.l2EquipId = source.l2EquipId;
		this.ccellNum = source.ccellNum;
		this.eqpMdlCd = source.eqpMdlCd;
		this.eqpVerInfo = source.eqpVerInfo;
		this.inetSvcMgmtNum = source.inetSvcMgmtNum;
		this.inetSvcNm = source.inetSvcNm;
		this.iptvSvcMgmtNum = source.iptvSvcMgmtNum;
		this.iptvSvcNm = source.iptvSvcNm;
		this.ipAddr = source.ipAddr;
		this.eqpUptimeTmsInfo = source.eqpUptimeTmsInfo;
		this.cpeIpAddr = source.cpeIpAddr;
		this.cpeMacAddr = source.cpeMacAddr;
		this.portNum = source.portNum;
		this.rtripTmsAvgVal = source.rtripTmsAvgVal;
		this.rtripTmsMaxVal = source.rtripTmsMaxVal;
		this.rtripTmsMinVal = source.rtripTmsMinVal;
		this.timeoutCnt = source.timeoutCnt;
	}

	public String getEvtRcvDtm() {
		return evtRcvDtm;
	}
	public void setEvtRcvDtm(String evtRcvDtm) {
		this.evtRcvDtm = evtRcvDtm;
	}
	public String getMacAddrVal() {
		return macAddrVal;
	}
	public void setMacAddrVal(String macAddrVal) {
		this.macAddrVal = macAddrVal;
	}
	public String getUuidVal() {
		return uuidVal;
	}
	public void setUuidVal(String uuidVal) {
		this.uuidVal = uuidVal;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getEvtOccrDtm() {
		return evtOccrDtm;
	}
	public void setEvtOccrDtm(String evtOccrDtm) {
		this.evtOccrDtm = evtOccrDtm;
	}
	public String getNetClCd() {
		return netClCd;
	}
	public void setNetClCd(String netClCd) {
		this.netClCd = netClCd;
	}
	public String getInfoCntrCd() {
		return infoCntrCd;
	}
	public void setInfoCntrCd(String infoCntrCd) {
		this.infoCntrCd = infoCntrCd;
	}
	public String getDistbCntrCd() {
		return distbCntrCd;
	}
	public void setDistbCntrCd(String distbCntrCd) {
		this.distbCntrCd = distbCntrCd;
	}
	public String getHomeCntrCd() {
		return homeCntrCd;
	}
	public void setHomeCntrCd(String homeCntrCd) {
		this.homeCntrCd = homeCntrCd;
	}
	public String getL3TidVal() {
		return l3TidVal;
	}
	public void setL3TidVal(String l3TidVal) {
		this.l3TidVal = l3TidVal;
	}
	public String getL3EquipId() {
		return l3EquipId;
	}
	public void setL3EquipId(String l3EquipId) {
		this.l3EquipId = l3EquipId;
	}
	public String getL2TidVal() {
		return l2TidVal;
	}
	public void setL2TidVal(String l2TidVal) {
		this.l2TidVal = l2TidVal;
	}
	public String getL2EquipId() {
		return l2EquipId;
	}
	public void setL2EquipId(String l2EquipId) {
		this.l2EquipId = l2EquipId;
	}
	public String getCcellNum() {
		return ccellNum;
	}
	public void setCcellNum(String ccellNum) {
		this.ccellNum = ccellNum;
	}
	public String getEqpMdlCd() {
		return eqpMdlCd;
	}
	public void setEqpMdlCd(String eqpMdlCd) {
		this.eqpMdlCd = eqpMdlCd;
	}
	public String getEqpVerInfo() {
		return eqpVerInfo;
	}
	public void setEqpVerInfo(String eqpVerInfo) {
		this.eqpVerInfo = eqpVerInfo;
	}
	public long getInetSvcMgmtNum() {
		return inetSvcMgmtNum;
	}
	public void setInetSvcMgmtNum(long inetSvcMgmtNum) {
		this.inetSvcMgmtNum = inetSvcMgmtNum;
	}
	public String getInetSvcNm() {
		return inetSvcNm;
	}
	public void setInetSvcNm(String inetSvcNm) {
		this.inetSvcNm = inetSvcNm;
	}
	public long getIptvSvcMgmtNum() {
		return iptvSvcMgmtNum;
	}
	public void setIptvSvcMgmtNum(long iptvSvcMgmtNum) {
		this.iptvSvcMgmtNum = iptvSvcMgmtNum;
	}
	public String getIptvSvcNm() {
		return iptvSvcNm;
	}
	public void setIptvSvcNm(String iptvSvcNm) {
		this.iptvSvcNm = iptvSvcNm;
	}
	public String getIpAddr() {
		return ipAddr;
	}
	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}
	public String getEqpUptimeTmsInfo() {
		return eqpUptimeTmsInfo;
	}
	public void setEqpUptimeTmsInfo(String eqpUptimeTmsInfo) {
		this.eqpUptimeTmsInfo = eqpUptimeTmsInfo;
	}
	public String getCpeIpAddr() {
		return cpeIpAddr;
	}
	public void setCpeIpAddr(String cpeIpAddr) {
		this.cpeIpAddr = cpeIpAddr;
	}
	public String getCpeMacAddr() {
		return cpeMacAddr;
	}
	public void setCpeMacAddr(String cpeMacAddr) {
		this.cpeMacAddr = cpeMacAddr;
	}
	public String getPortNum() {
		return portNum;
	}
	public void setPortNum(String portNum) {
		this.portNum = portNum;
	}
	public double getRtripTmsAvgVal() {
		return rtripTmsAvgVal;
	}
	public void setRtripTmsAvgVal(double rtripTmsAvgVal) {
		this.rtripTmsAvgVal = rtripTmsAvgVal;
	}
	public double getRtripTmsMaxVal() {
		return rtripTmsMaxVal;
	}
	public void setRtripTmsMaxVal(double rtripTmsMaxVal) {
		this.rtripTmsMaxVal = rtripTmsMaxVal;
	}
	public double getRtripTmsMinVal() {
		return rtripTmsMinVal;
	}
	public void setRtripTmsMinVal(double rtripTmsMinVal) {
		this.rtripTmsMinVal = rtripTmsMinVal;
	}
	public int getTimeoutCnt() {
		return timeoutCnt;
	}
	public void setTimeoutCnt(int timeoutCnt) {
		this.timeoutCnt = timeoutCnt;
	}
}
