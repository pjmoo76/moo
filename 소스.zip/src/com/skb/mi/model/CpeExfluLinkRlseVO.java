package com.skb.mi.model;

public class CpeExfluLinkRlseVO extends AggrDataVO {
	
	static public int rlseOccrThresholdCnt = 10;

	private	String	mntrDt;
	private	String	macAddrVal;
	private	String	cpeMacAddr;
	private	String	auditId;
	private	int		rlseOccrCnt;

	public String getMntrDt() {
		return mntrDt;
	}
	public void setMntrDt(String mntrDt) {
		this.mntrDt = mntrDt;
	}
	public String getMacAddrVal() {
		return macAddrVal;
	}
	public void setMacAddrVal(String macAddrVal) {
		this.macAddrVal = macAddrVal;
	}
	public String getCpeMacAddr() {
		return cpeMacAddr;
	}
	public void setCpeMacAddr(String cpeMacAddr) {
		this.cpeMacAddr = cpeMacAddr;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public int getRlseOccrCnt() {
		return rlseOccrCnt;
	}
	public void setRlseOccrCnt(int rlseOccrCnt) {
		this.rlseOccrCnt = rlseOccrCnt;
	}

	@Override
	public boolean isValid() {
		if (this.macAddrVal == null || this.macAddrVal.isEmpty() || this.macAddrVal.length() > 15) {
			return false;
		}
		if (this.cpeMacAddr == null || this.cpeMacAddr.isEmpty() || this.cpeMacAddr.length() > 15) {
			return false;
		}
		return true;
	}

	@Override
	public String toDelimiterString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("%s|", mntrDt));
		sb.append(String.format("%s|", macAddrVal));
		sb.append(String.format("%s|", cpeMacAddr));
		sb.append(String.format("%d|", rlseOccrCnt));
		return sb.toString();
	}

	@Override
	public void add(AggrDataVO obj) {
		this.rlseOccrCnt += ((CpeExfluLinkRlseVO) obj).rlseOccrCnt;
	}

	@Override
	public boolean isTarget() {
		if (this.rlseOccrCnt >= rlseOccrThresholdCnt) {
			return true;
		} else {
			return false;
		}
	}
	
	@Override
	public String getKey() {
		return this.macAddrVal + ":" + this.cpeMacAddr;
	}
}
