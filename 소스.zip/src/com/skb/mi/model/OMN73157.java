package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OMN73157 extends AggrDataVO {
	private	String	mntrDthr;
	private	String	apMacAddr;
	private String	auditId;
	private	String	netClCd;
	private	String	infoCntrCd;
	private	String	distbCntrCd;
	private	String	homeCntrCd;
	private	String	l3EquipId;
	private	String	l2EquipId;
	private	String	ccellNum;
	private	String	eqpMdlCd;
	private	String	eqpVerInfo;
	private	long	inetSvcMgmtNum;
	private	int		goodIgmpCnt;
	private	int		badIgmpCnt;

	public String getMntrDthr() {
		return mntrDthr;
	}
	public void setMntrDthr(String mntrDthr) {
		this.mntrDthr = mntrDthr;
	}
	public String getApMacAddr() {
		return apMacAddr;
	}
	public void setApMacAddr(String apMacAddr) {
		this.apMacAddr = apMacAddr;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getNetClCd() {
		return netClCd;
	}
	public void setNetClCd(String netClCd) {
		this.netClCd = netClCd;
	}
	public String getInfoCntrCd() {
		return infoCntrCd;
	}
	public void setInfoCntrCd(String infoCntrCd) {
		this.infoCntrCd = infoCntrCd;
	}
	public String getDistbCntrCd() {
		return distbCntrCd;
	}
	public void setDistbCntrCd(String distbCntrCd) {
		this.distbCntrCd = distbCntrCd;
	}
	public String getHomeCntrCd() {
		return homeCntrCd;
	}
	public void setHomeCntrCd(String homeCntrCd) {
		this.homeCntrCd = homeCntrCd;
	}
	public String getL3EquipId() {
		return l3EquipId;
	}
	public void setL3EquipId(String l3EquipId) {
		this.l3EquipId = l3EquipId;
	}
	public String getL2EquipId() {
		return l2EquipId;
	}
	public void setL2EquipId(String l2EquipId) {
		this.l2EquipId = l2EquipId;
	}
	public String getCcellNum() {
		return ccellNum;
	}
	public void setCcellNum(String ccellNum) {
		this.ccellNum = ccellNum;
	}
	public String getEqpMdlCd() {
		return eqpMdlCd;
	}
	public void setEqpMdlCd(String eqpMdlCd) {
		this.eqpMdlCd = eqpMdlCd;
	}
	public String getEqpVerInfo() {
		return eqpVerInfo;
	}
	public void setEqpVerInfo(String eqpVerInfo) {
		this.eqpVerInfo = eqpVerInfo;
	}
	public long getInetSvcMgmtNum() {
		return inetSvcMgmtNum;
	}
	public void setInetSvcMgmtNum(long inetSvcMgmtNum) {
		this.inetSvcMgmtNum = inetSvcMgmtNum;
	}
	public int getGoodIgmpCnt() {
		return goodIgmpCnt;
	}
	public void setGoodIgmpCnt(int goodIgmpCnt) {
		this.goodIgmpCnt = goodIgmpCnt;
	}
	public int getBadIgmpCnt() {
		return badIgmpCnt;
	}
	public void setBadIgmpCnt(int badIgmpCnt) {
		this.badIgmpCnt = badIgmpCnt;
	}
	@Override
	public boolean isValid() {
		if (this.apMacAddr == null || this.apMacAddr.isEmpty() || this.apMacAddr.length() > 15) {
			return false;
		}
		return true;
	}
	@Override
	public String toDelimiterString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("%s|", mntrDthr));
		sb.append(String.format("%s|", apMacAddr));
		sb.append(String.format("%s|", auditId));
		sb.append(String.format("%s|", StringUtils.null2Empty(netClCd)));
		sb.append(String.format("%s|", StringUtils.null2Empty(infoCntrCd)));
		sb.append(String.format("%s|", StringUtils.null2Empty(distbCntrCd)));
		sb.append(String.format("%s|", StringUtils.null2Empty(homeCntrCd)));
		sb.append(String.format("%s|", StringUtils.null2Empty(l3EquipId)));
		sb.append(String.format("%s|", StringUtils.null2Empty(l2EquipId)));
		sb.append(String.format("%s|", StringUtils.null2Empty(ccellNum)));
		sb.append(String.format("%s|", StringUtils.null2Empty(eqpMdlCd)));
		sb.append(String.format("%s|", StringUtils.null2Empty(eqpVerInfo)));
		sb.append(String.format("%d|", inetSvcMgmtNum));
		sb.append(String.format("%d|", goodIgmpCnt));
		sb.append(String.format("%d|", badIgmpCnt));
		return sb.toString();
	}
	@Override
	public void add(AggrDataVO obj) {
		OMN73157 addObj = (OMN73157) obj;
		this.goodIgmpCnt += addObj.goodIgmpCnt;
		this.badIgmpCnt += addObj.badIgmpCnt;
	}
}
