package com.skb.mi.model;

public class OIV10892 {
	private	String	apMacAddr;
	private	String	ssidVal;
	private	String	auditId;
	private	String	wifiFreqVal;
	private	String	bandwCtt;
	private	String	updDtm;
	private	String	ssidIdxVal;

	public String getApMacAddr() {
		return apMacAddr;
	}
	public void setApMacAddr(String apMacAddr) {
		this.apMacAddr = apMacAddr;
	}
	public String getSsidVal() {
		return ssidVal;
	}
	public void setSsidVal(String ssidVal) {
		this.ssidVal = ssidVal;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getWifiFreqVal() {
		return wifiFreqVal;
	}
	public void setWifiFreqVal(String wifiFreqVal) {
		this.wifiFreqVal = wifiFreqVal;
	}
	public String getBandwCtt() {
		return bandwCtt;
	}
	public void setBandwCtt(String bandwCtt) {
		this.bandwCtt = bandwCtt;
	}
	public String getUpdDtm() {
		return updDtm;
	}
	public void setUpdDtm(String updDtm) {
		this.updDtm = updDtm;
	}
	public String getSsidIdxVal() {
		return ssidIdxVal;
	}
	public void setSsidIdxVal(String ssidIdxVal) {
		this.ssidIdxVal = ssidIdxVal;
	}
}
