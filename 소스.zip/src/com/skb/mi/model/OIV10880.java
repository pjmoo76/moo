package com.skb.mi.model;

public class OIV10880 {
	private	String	macAddr;
	private String  assistAddr;
	private	String	auditId;
	private	String	auditDtm;
	private	String	weqpGrpCd;
	private	String	inoutClCd;
	private	String	mfactNm;
	private	String	equipMdlNm;
	private	long	custNum;
	private	long	acntNum;
	private	String	equipCd;
	private	String	custNm;
	private	String	svcTechMthdCd;
	private	String	custAddr;
	private	String	custPhonNum;
	private	long	inetSvcNum;
	private	long	inetSvcMgmtNum;
	private	String	phonSvcNum;
	private	long	phonSvcMgmtNum;
	private	long	iptvSvcNum;
	private	long	iptvSvcMgmtNum;
	private	String	inetSvcNm;
	private	String	phonSvcNm;
	private	String	iptvSvcNm;
	private	String	rltmTvClCd;
	private	String	inetOrbkStCd;
	private	String	wphonOrbkStCd;
	private	String	iptvOrbkStCd;
	private	long	iptvLineCnt;
	private	String	l3TidVal;
	private	String	l3EquipMgmtNum;
	private	String	l3EquipNm;
	private	String	l3EquipMfactNm;
	private	String	l3IpAddr;
	private	String	infoCntrCd;
	private	String	infcNm;
	private	String	l3CellNum;
	private	String	l3RackNum;
	private	String	l3ShlfNum;
	private	String	l3CardNum;
	private	String	l3PortNum;
	private	String	l2TidVal;
	private	String	l2EquipMgmtNum;
	private	String	l2EquipNm;
	private	String	l2EquipMfactNm;
	private	String	l2IpAddr;
	private	String	tpoCd;
	private	String	tpoNm;
	private	String	l2CellNum;
	private	String	l2RackNum;
	private	String	l2ShlfNum;
	private	String	l2CardNum;
	private	String	l2PortNum;
	private	String	onuEquipId;
	private	String	rnTapNum;
	private	String	telpolNum;
	private	String	ldongCd;
	private	String	addrId;
	private	long	bldblkNum;
	private	long	blduntNum;
	private	String	assitAddr;
	private	String	zip;
	private	String	basAddr;
	private	String	dtlAddr;
	private	String	dsnetId;
	private	String	dsnetNm;
	private	String	fstScrbOrgId;
	private	String	fstScrbOrgNm;
	private	String	teamOrgNm;
	private	String	svcLinkNum;
	private	String	setBldAttrInfo;
	private	String	assitMacAddrSerNum;
	private	String	weqpMgmtNum;
	private	String	l3EquipId;
	private	String	l3EquipMdlCd;
	private	String	l3EquipMdlNm;
	private	String	l3EquipUsgCd;
	private	String	l2EquipId;
	private	String	l2EquipMdlCd;
	private	String	l2EquipMdlNm;

	public String getMacAddr() {
		return macAddr;
	}
	public void setMacAddr(String macAddr) {
		this.macAddr = macAddr;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getWeqpGrpCd() {
		return weqpGrpCd;
	}
	public void setWeqpGrpCd(String weqpGrpCd) {
		this.weqpGrpCd = weqpGrpCd;
	}
	public String getInoutClCd() {
		return inoutClCd;
	}
	public void setInoutClCd(String inoutClCd) {
		this.inoutClCd = inoutClCd;
	}
	public String getMfactNm() {
		return mfactNm;
	}
	public void setMfactNm(String mfactNm) {
		this.mfactNm = mfactNm;
	}
	public String getEquipMdlNm() {
		return equipMdlNm;
	}
	public void setEquipMdlNm(String equipMdlNm) {
		this.equipMdlNm = equipMdlNm;
	}
	public long getCustNum() {
		return custNum;
	}
	public void setCustNum(long custNum) {
		this.custNum = custNum;
	}
	public long getAcntNum() {
		return acntNum;
	}
	public void setAcntNum(long acntNum) {
		this.acntNum = acntNum;
	}
	public String getEquipCd() {
		return equipCd;
	}
	public void setEquipCd(String equipCd) {
		this.equipCd = equipCd;
	}
	public String getCustNm() {
		return custNm;
	}
	public void setCustNm(String custNm) {
		this.custNm = custNm;
	}
	public String getSvcTechMthdCd() {
		return svcTechMthdCd;
	}
	public void setSvcTechMthdCd(String svcTechMthdCd) {
		this.svcTechMthdCd = svcTechMthdCd;
	}
	public String getCustAddr() {
		return custAddr;
	}
	public void setCustAddr(String custAddr) {
		this.custAddr = custAddr;
	}
	public String getCustPhonNum() {
		return custPhonNum;
	}
	public void setCustPhonNum(String custPhonNum) {
		this.custPhonNum = custPhonNum;
	}
	public long getInetSvcNum() {
		return inetSvcNum;
	}
	public void setInetSvcNum(long inetSvcNum) {
		this.inetSvcNum = inetSvcNum;
	}
	public long getInetSvcMgmtNum() {
		return inetSvcMgmtNum;
	}
	public void setInetSvcMgmtNum(long inetSvcMgmtNum) {
		this.inetSvcMgmtNum = inetSvcMgmtNum;
	}
	public String getPhonSvcNum() {
		return phonSvcNum;
	}
	public void setPhonSvcNum(String phonSvcNum) {
		this.phonSvcNum = phonSvcNum;
	}
	public long getPhonSvcMgmtNum() {
		return phonSvcMgmtNum;
	}
	public void setPhonSvcMgmtNum(long phonSvcMgmtNum) {
		this.phonSvcMgmtNum = phonSvcMgmtNum;
	}
	public long getIptvSvcNum() {
		return iptvSvcNum;
	}
	public void setIptvSvcNum(long iptvSvcNum) {
		this.iptvSvcNum = iptvSvcNum;
	}
	public long getIptvSvcMgmtNum() {
		return iptvSvcMgmtNum;
	}
	public void setIptvSvcMgmtNum(long iptvSvcMgmtNum) {
		this.iptvSvcMgmtNum = iptvSvcMgmtNum;
	}
	public String getInetSvcNm() {
		return inetSvcNm;
	}
	public void setInetSvcNm(String inetSvcNm) {
		this.inetSvcNm = inetSvcNm;
	}
	public String getPhonSvcNm() {
		return phonSvcNm;
	}
	public void setPhonSvcNm(String phonSvcNm) {
		this.phonSvcNm = phonSvcNm;
	}
	public String getIptvSvcNm() {
		return iptvSvcNm;
	}
	public void setIptvSvcNm(String iptvSvcNm) {
		this.iptvSvcNm = iptvSvcNm;
	}
	public String getRltmTvClCd() {
		return rltmTvClCd;
	}
	public void setRltmTvClCd(String rltmTvClCd) {
		this.rltmTvClCd = rltmTvClCd;
	}
	public String getInetOrbkStCd() {
		return inetOrbkStCd;
	}
	public void setInetOrbkStCd(String inetOrbkStCd) {
		this.inetOrbkStCd = inetOrbkStCd;
	}
	public String getWphonOrbkStCd() {
		return wphonOrbkStCd;
	}
	public void setWphonOrbkStCd(String wphonOrbkStCd) {
		this.wphonOrbkStCd = wphonOrbkStCd;
	}
	public String getIptvOrbkStCd() {
		return iptvOrbkStCd;
	}
	public void setIptvOrbkStCd(String iptvOrbkStCd) {
		this.iptvOrbkStCd = iptvOrbkStCd;
	}
	public long getIptvLineCnt() {
		return iptvLineCnt;
	}
	public void setIptvLineCnt(long iptvLineCnt) {
		this.iptvLineCnt = iptvLineCnt;
	}
	public String getL3TidVal() {
		return l3TidVal;
	}
	public void setL3TidVal(String l3TidVal) {
		this.l3TidVal = l3TidVal;
	}
	public String getL3EquipMgmtNum() {
		return l3EquipMgmtNum;
	}
	public void setL3EquipMgmtNum(String l3EquipMgmtNum) {
		this.l3EquipMgmtNum = l3EquipMgmtNum;
	}
	public String getL3EquipNm() {
		return l3EquipNm;
	}
	public void setL3EquipNm(String l3EquipNm) {
		this.l3EquipNm = l3EquipNm;
	}
	public String getL3EquipMfactNm() {
		return l3EquipMfactNm;
	}
	public void setL3EquipMfactNm(String l3EquipMfactNm) {
		this.l3EquipMfactNm = l3EquipMfactNm;
	}
	public String getL3IpAddr() {
		return l3IpAddr;
	}
	public void setL3IpAddr(String l3IpAddr) {
		this.l3IpAddr = l3IpAddr;
	}
	public String getInfoCntrCd() {
		return infoCntrCd;
	}
	public void setInfoCntrCd(String infoCntrCd) {
		this.infoCntrCd = infoCntrCd;
	}
	public String getInfcNm() {
		return infcNm;
	}
	public void setInfcNm(String infcNm) {
		this.infcNm = infcNm;
	}
	public String getL3CellNum() {
		return l3CellNum;
	}
	public void setL3CellNum(String l3CellNum) {
		this.l3CellNum = l3CellNum;
	}
	public String getL3RackNum() {
		return l3RackNum;
	}
	public void setL3RackNum(String l3RackNum) {
		this.l3RackNum = l3RackNum;
	}
	public String getL3ShlfNum() {
		return l3ShlfNum;
	}
	public void setL3ShlfNum(String l3ShlfNum) {
		this.l3ShlfNum = l3ShlfNum;
	}
	public String getL3CardNum() {
		return l3CardNum;
	}
	public void setL3CardNum(String l3CardNum) {
		this.l3CardNum = l3CardNum;
	}
	public String getL3PortNum() {
		return l3PortNum;
	}
	public void setL3PortNum(String l3PortNum) {
		this.l3PortNum = l3PortNum;
	}
	public String getL2TidVal() {
		return l2TidVal;
	}
	public void setL2TidVal(String l2TidVal) {
		this.l2TidVal = l2TidVal;
	}
	public String getL2EquipMgmtNum() {
		return l2EquipMgmtNum;
	}
	public void setL2EquipMgmtNum(String l2EquipMgmtNum) {
		this.l2EquipMgmtNum = l2EquipMgmtNum;
	}
	public String getL2EquipNm() {
		return l2EquipNm;
	}
	public void setL2EquipNm(String l2EquipNm) {
		this.l2EquipNm = l2EquipNm;
	}
	public String getL2EquipMfactNm() {
		return l2EquipMfactNm;
	}
	public void setL2EquipMfactNm(String l2EquipMfactNm) {
		this.l2EquipMfactNm = l2EquipMfactNm;
	}
	public String getL2IpAddr() {
		return l2IpAddr;
	}
	public void setL2IpAddr(String l2IpAddr) {
		this.l2IpAddr = l2IpAddr;
	}
	public String getTpoCd() {
		return tpoCd;
	}
	public void setTpoCd(String tpoCd) {
		this.tpoCd = tpoCd;
	}
	public String getTpoNm() {
		return tpoNm;
	}
	public void setTpoNm(String tpoNm) {
		this.tpoNm = tpoNm;
	}
	public String getL2CellNum() {
		return l2CellNum;
	}
	public void setL2CellNum(String l2CellNum) {
		this.l2CellNum = l2CellNum;
	}
	public String getL2RackNum() {
		return l2RackNum;
	}
	public void setL2RackNum(String l2RackNum) {
		this.l2RackNum = l2RackNum;
	}
	public String getL2ShlfNum() {
		return l2ShlfNum;
	}
	public void setL2ShlfNum(String l2ShlfNum) {
		this.l2ShlfNum = l2ShlfNum;
	}
	public String getL2CardNum() {
		return l2CardNum;
	}
	public void setL2CardNum(String l2CardNum) {
		this.l2CardNum = l2CardNum;
	}
	public String getL2PortNum() {
		return l2PortNum;
	}
	public void setL2PortNum(String l2PortNum) {
		this.l2PortNum = l2PortNum;
	}
	public String getOnuEquipId() {
		return onuEquipId;
	}
	public void setOnuEquipId(String onuEquipId) {
		this.onuEquipId = onuEquipId;
	}
	public String getRnTapNum() {
		return rnTapNum;
	}
	public void setRnTapNum(String rnTapNum) {
		this.rnTapNum = rnTapNum;
	}
	public String getTelpolNum() {
		return telpolNum;
	}
	public void setTelpolNum(String telpolNum) {
		this.telpolNum = telpolNum;
	}
	public String getLdongCd() {
		return ldongCd;
	}
	public void setLdongCd(String ldongCd) {
		this.ldongCd = ldongCd;
	}
	public String getAddrId() {
		return addrId;
	}
	public void setAddrId(String addrId) {
		this.addrId = addrId;
	}
	public long getBldblkNum() {
		return bldblkNum;
	}
	public void setBldblkNum(long bldblkNum) {
		this.bldblkNum = bldblkNum;
	}
	public long getBlduntNum() {
		return blduntNum;
	}
	public void setBlduntNum(long blduntNum) {
		this.blduntNum = blduntNum;
	}
	public String getAssitAddr() {
		return assitAddr;
	}
	public void setAssitAddr(String assitAddr) {
		this.assitAddr = assitAddr;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getBasAddr() {
		return basAddr;
	}
	public void setBasAddr(String basAddr) {
		this.basAddr = basAddr;
	}
	public String getDtlAddr() {
		return dtlAddr;
	}
	public void setDtlAddr(String dtlAddr) {
		this.dtlAddr = dtlAddr;
	}
	public String getDsnetId() {
		return dsnetId;
	}
	public void setDsnetId(String dsnetId) {
		this.dsnetId = dsnetId;
	}
	public String getDsnetNm() {
		return dsnetNm;
	}
	public void setDsnetNm(String dsnetNm) {
		this.dsnetNm = dsnetNm;
	}
	public String getFstScrbOrgId() {
		return fstScrbOrgId;
	}
	public void setFstScrbOrgId(String fstScrbOrgId) {
		this.fstScrbOrgId = fstScrbOrgId;
	}
	public String getFstScrbOrgNm() {
		return fstScrbOrgNm;
	}
	public void setFstScrbOrgNm(String fstScrbOrgNm) {
		this.fstScrbOrgNm = fstScrbOrgNm;
	}
	public String getTeamOrgNm() {
		return teamOrgNm;
	}
	public void setTeamOrgNm(String teamOrgNm) {
		this.teamOrgNm = teamOrgNm;
	}
	public String getSvcLinkNum() {
		return svcLinkNum;
	}
	public void setSvcLinkNum(String svcLinkNum) {
		this.svcLinkNum = svcLinkNum;
	}
	public String getSetBldAttrInfo() {
		return setBldAttrInfo;
	}
	public void setSetBldAttrInfo(String setBldAttrInfo) {
		this.setBldAttrInfo = setBldAttrInfo;
	}
	public String getAssitMacAddrSerNum() {
		return assitMacAddrSerNum;
	}
	public void setAssitMacAddrSerNum(String assitMacAddrSerNum) {
		this.assitMacAddrSerNum = assitMacAddrSerNum;
	}
	public String getWeqpMgmtNum() {
		return weqpMgmtNum;
	}
	public void setWeqpMgmtNum(String weqpMgmtNum) {
		this.weqpMgmtNum = weqpMgmtNum;
	}
	public String getL3EquipId() {
		return l3EquipId;
	}
	public void setL3EquipId(String l3EquipId) {
		this.l3EquipId = l3EquipId;
	}
	public String getL3EquipMdlCd() {
		return l3EquipMdlCd;
	}
	public void setL3EquipMdlCd(String l3EquipMdlCd) {
		this.l3EquipMdlCd = l3EquipMdlCd;
	}
	public String getL3EquipMdlNm() {
		return l3EquipMdlNm;
	}
	public void setL3EquipMdlNm(String l3EquipMdlNm) {
		this.l3EquipMdlNm = l3EquipMdlNm;
	}
	public String getL3EquipUsgCd() {
		return l3EquipUsgCd;
	}
	public void setL3EquipUsgCd(String l3EquipUsgCd) {
		this.l3EquipUsgCd = l3EquipUsgCd;
	}
	public String getL2EquipId() {
		return l2EquipId;
	}
	public void setL2EquipId(String l2EquipId) {
		this.l2EquipId = l2EquipId;
	}
	public String getL2EquipMdlCd() {
		return l2EquipMdlCd;
	}
	public void setL2EquipMdlCd(String l2EquipMdlCd) {
		this.l2EquipMdlCd = l2EquipMdlCd;
	}
	public String getL2EquipMdlNm() {
		return l2EquipMdlNm;
	}
	public void setL2EquipMdlNm(String l2EquipMdlNm) {
		this.l2EquipMdlNm = l2EquipMdlNm;
	}
	public String getAssistAddr() {
		return assistAddr;
	}
	public void setAssistAddr(String assistAddr) {
		this.assistAddr = assistAddr;
	}
	
}
