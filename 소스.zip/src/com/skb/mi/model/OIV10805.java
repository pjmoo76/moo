package com.skb.mi.model;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class OIV10805 {
	private long mqSerNum;
	private String auditId;
	private String mqChgDtm;
	private long mqExecTms;
	private String weqpGrpCd;
	private String macAddr;
	private String inoutClCd;
	private String mfactNm;
	private String equipMdlNm;
	private long custNum;
	private long acntNum;
	private String equipCd;
	private String custNm;
	private String svcTechMthdCd;
	private String custAddr;
	private String custPhonNum;
	private long inetSvcNum;
	private long inetSvcMgmtNum;
	private String phonSvcNum;
	private long phonSvcMgmtNum;
	private long iptvSvcNum;
	private long iptvSvcMgmtNum;
	private String inetSvcNm;
	private String phonSvcNm;
	private String iptvSvcNm;
	private String rltmTvClCd;
	private String inetOrbkStCd;
	private String wphonOrbkStCd;
	private String iptvOrbkStCd;
	private long iptvLineCnt;
	private String l3TidVal;
	private String l3EquipId;
	private String l3EquipNm;
	private String l3EquipMfactNm;
	private String l3IpAddr;
	private String infoCntrCd;
	private String infcNm;
	private String l3CellNum;
	private String l3RackNum;
	private String l3ShlfNum;
	private String l3CardNum;
	private String l3PortNum;
	private String l2TidVal;
	private String l2EquipId;
	private String l2EquipNm;
	private String l2EquipMfactNm;
	private String l2IpAddr;
	private String tpoCd;
	private String tpoNm;
	private String l2CellNum;
	private String l2RackNum;
	private String l2ShlfNum;
	private String l2CardNum;
	private String l2PortNum;
	private String onuEquipId;
	private String rnTapNum;
	private String telpolNum;
	private String ldongCd;
	private String addrId;
	private long bldblkNum;
	private long blduntNum;
	private String assistAddr;
	private String zip;
	private String basAddr;
	private String dtlAddr;
	private String dsnetId;
	private String dsnetNm;
	private String fstScrbOrgId;
	private String fstScrbOrgNm;
	private String teamOrgNm;
	private String svcLinkNum;
	private String setBldAttrInfo;
	private String weqpMgmtNum;
	private String assistMacAddrSerNum;

	static private final int	TOKEN_NO	= 69;	
	private Logger		logger;

	public OIV10805() {
		logger = LogManager.getLogger(this.getClass());
	}

	/**
	* MQ일련번호
	* @return MQ일련번호
	*/
	public long getMqSerNum() {
		return mqSerNum;
	}
	/**
	* MQ일련번호
	*@param mqSerNum MQ일련번호
	*/
	public void setMqSerNum(long mqSerNum) {
		this.mqSerNum = mqSerNum;
	}
	
	public void setMqSerNum(String mqSerNumStr) throws Exception {
		this.mqSerNum = Long.parseLong(mqSerNumStr);
	}
	/**
	* 최종변경자ID
	* @return 최종변경자ID
	*/
	public String getAuditId() {
		return auditId;
	}
	/**
	* 최종변경자ID
	*@param auditId 최종변경자ID
	*/
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	/**
	* MQ변경일시
	* @return MQ변경일시
	*/
	public String getMqChgDtm() {
		return mqChgDtm;
	}
	/**
	* MQ변경일시
	*@param mqChgDtm MQ변경일시
	*/
	public void setMqChgDtm(String mqChgDtm) {
		this.mqChgDtm = mqChgDtm;
	}
	/**
	* MQ수행시간
	* @return MQ수행시간
	*/
	public long getMqExecTms() {
		return mqExecTms;
	}
	/**
	* MQ수행시간
	*@param mqExecTms MQ수행시간
	*/
	public void setMqExecTms(long mqExecTms) {
		this.mqExecTms = mqExecTms;
	}
	/**
	* 유선단말군코드
	* @return 유선단말군코드
	*/
	public String getWeqpGrpCd() {
		return weqpGrpCd;
	}
	/**
	* 유선단말군코드
	*@param weqpGrpCd 유선단말군코드
	*/
	public void setWeqpGrpCd(String weqpGrpCd) {
		this.weqpGrpCd = weqpGrpCd;
	}
	/**
	* MAC주소
	* @return MAC주소
	*/
	public String getMacAddr() {
		return macAddr;
	}
	/**
	* MAC주소
	*@param macAddr MAC주소
	*/
	public void setMacAddr(String macAddr) {
		this.macAddr = macAddr;
	}
	/**
	* 입출고구분코드
	* @return 입출고구분코드
	*/
	public String getInoutClCd() {
		return inoutClCd;
	}
	/**
	* 입출고구분코드
	*@param inoutClCd 입출고구분코드
	*/
	public void setInoutClCd(String inoutClCd) {
		this.inoutClCd = inoutClCd;
	}
	/**
	* 제조사명
	* @return 제조사명
	*/
	public String getMfactNm() {
		return mfactNm;
	}
	/**
	* 제조사명
	*@param mfactNm 제조사명
	*/
	public void setMfactNm(String mfactNm) {
		this.mfactNm = mfactNm;
	}
	/**
	* 장비모델명
	* @return 장비모델명
	*/
	public String getEquipMdlNm() {
		return equipMdlNm;
	}
	/**
	* 장비모델명
	*@param equipMdlNm 장비모델명
	*/
	public void setEquipMdlNm(String equipMdlNm) {
		this.equipMdlNm = equipMdlNm;
	}
	/**
	* 고객번호
	* @return 고객번호
	*/
	public long getCustNum() {
		return custNum;
	}
	/**
	* 고객번호
	*@param custNum 고객번호
	*/
	public void setCustNum(long custNum) {
		this.custNum = custNum;
	}
	public void setCustNum(String custNumStr) throws Exception {
		this.custNum = Long.parseLong(custNumStr);
	}
	/**
	* 계정번호
	* @return 계정번호
	*/
	public long getAcntNum() {
		return acntNum;
	}
	/**
	* 계정번호
	*@param acntNum 계정번호
	*/
	public void setAcntNum(long acntNum) {
		this.acntNum = acntNum;
	}
	public void setAcntNum(String acntNumStr) throws Exception {
		this.acntNum = Long.parseLong(acntNumStr);
	}
	/**
	* 장비코드
	* @return 장비코드
	*/
	public String getEquipCd() {
		return equipCd;
	}
	/**
	* 장비코드
	*@param equipCd 장비코드
	*/
	public void setEquipCd(String equipCd) {
		this.equipCd = equipCd;
	}
	/**
	* 고객명
	* @return 고객명
	*/
	public String getCustNm() {
		return custNm;
	}
	/**
	* 고객명
	*@param custNm 고객명
	*/
	public void setCustNm(String custNm) {
		this.custNm = custNm;
	}
	/**
	* 서비스기술방식코드
	* @return 서비스기술방식코드
	*/
	public String getSvcTechMthdCd() {
		return svcTechMthdCd;
	}
	/**
	* 서비스기술방식코드
	*@param svcTechMthdCd 서비스기술방식코드
	*/
	public void setSvcTechMthdCd(String svcTechMthdCd) {
		this.svcTechMthdCd = svcTechMthdCd;
	}
	/**
	* 고객주소
	* @return 고객주소
	*/
	public String getCustAddr() {
		return custAddr;
	}
	/**
	* 고객주소
	*@param custAddr 고객주소
	*/
	public void setCustAddr(String custAddr) {
		this.custAddr = custAddr;
	}
	/**
	* 고객전화번호
	* @return 고객전화번호
	*/
	public String getCustPhonNum() {
		return custPhonNum;
	}
	/**
	* 고객전화번호
	*@param custPhonNum 고객전화번호
	*/
	public void setCustPhonNum(String custPhonNum) {
		this.custPhonNum = custPhonNum;
	}
	/**
	* 인터넷서비스번호
	* @return 인터넷서비스번호
	*/
	public long getInetSvcNum() {
		return inetSvcNum;
	}
	/**
	* 인터넷서비스번호
	*@param inetSvcNum 인터넷서비스번호
	*/
	public void setInetSvcNum(long inetSvcNum) {
		this.inetSvcNum = inetSvcNum;
	}
	public void setInetSvcNum(String inetSvcNumStr) {
		try {
			this.inetSvcNum = Long.parseLong(inetSvcNumStr);
		} catch (Exception e) {
			
		}
	}
	/**
	* 인터넷서비스관리번호
	* @return 인터넷서비스관리번호
	*/
	public long getInetSvcMgmtNum() {
		return inetSvcMgmtNum;
	}
	/**
	* 인터넷서비스관리번호
	*@param inetSvcMgmtNum 인터넷서비스관리번호
	*/
	public void setInetSvcMgmtNum(long inetSvcMgmtNum) {
		this.inetSvcMgmtNum = inetSvcMgmtNum;
	}
	public void setInetSvcMgmtNum(String inetSvcMgmtNumStr) {
		try {
			this.inetSvcMgmtNum = Long.parseLong(inetSvcMgmtNumStr);
		} catch (Exception e) {
			
		}
	}
	/**
	* 전화서비스번호
	* @return 전화서비스번호
	*/
	public String getPhonSvcNum() {
	return phonSvcNum;
	}
	/**
	* 전화서비스번호
	*@param phonSvcNum 전화서비스번호
	*/
	public void setPhonSvcNum(String phonSvcNum) {
		this.phonSvcNum = phonSvcNum;
	}
	/**
	* 전화서비스관리번호
	* @return 전화서비스관리번호
	*/
	public long getPhonSvcMgmtNum() {
		return phonSvcMgmtNum;
	}
	/**
	* 전화서비스관리번호
	*@param phonSvcMgmtNum 전화서비스관리번호
	*/
	public void setPhonSvcMgmtNum(long phonSvcMgmtNum) {
		this.phonSvcMgmtNum = phonSvcMgmtNum;
	}
	
	public void setPhonSvcMgmtNum(String phonSvcMgmtNumStr) {
		try {
			this.phonSvcMgmtNum = Long.parseLong(phonSvcMgmtNumStr);
		} catch (Exception e) {
			
		}
	}
	/**
	* IPTV서비스번호
	* @return IPTV서비스번호
	*/
	public long getIptvSvcNum() {
		return iptvSvcNum;
	}
	/**
	* IPTV서비스번호
	*@param iptvSvcNum IPTV서비스번호
	*/
	public void setIptvSvcNum(long iptvSvcNum) {
		this.iptvSvcNum = iptvSvcNum;
	}
	
	public void setIptvSvcNum(String iptvSvcNumStr) {
		try {
			this.iptvSvcNum = Long.parseLong(iptvSvcNumStr);
		} catch (Exception e) {
			
		}
	}
	/**
	* IPTV서비스관리번호
	* @return IPTV서비스관리번호
	*/
	public long getIptvSvcMgmtNum() {
		return iptvSvcMgmtNum;
	}
	/**
	* IPTV서비스관리번호
	*@param iptvSvcMgmtNum IPTV서비스관리번호
	*/
	public void setIptvSvcMgmtNum(long iptvSvcMgmtNum) {
		this.iptvSvcMgmtNum = iptvSvcMgmtNum;
	}
	
	public void setIptvSvcMgmtNum(String iptvSvcMgmtNumStr) {
		try {
			this.iptvSvcMgmtNum = Long.parseLong(iptvSvcMgmtNumStr);
		} catch (Exception e) {
			
		}
	}
	/**
	* 인터넷서비스명
	* @return 인터넷서비스명
	*/
	public String getInetSvcNm() {
		return inetSvcNm;
	}
	/**
	* 인터넷서비스명
	*@param inetSvcNm 인터넷서비스명
	*/
	public void setInetSvcNm(String inetSvcNm) {
		this.inetSvcNm = inetSvcNm;
	}
	/**
	* 전화서비스명
	* @return 전화서비스명
	*/
	public String getPhonSvcNm() {
		return phonSvcNm;
	}
	/**
	* 전화서비스명
	*@param phonSvcNm 전화서비스명
	*/
	public void setPhonSvcNm(String phonSvcNm) {
		this.phonSvcNm = phonSvcNm;
	}
	/**
	* IPTV서비스명
	* @return IPTV서비스명
	*/
	public String getIptvSvcNm() {
		return iptvSvcNm;
	}
	/**
	* IPTV서비스명
	*@param iptvSvcNm IPTV서비스명
	*/
	public void setIptvSvcNm(String iptvSvcNm) {
		this.iptvSvcNm = iptvSvcNm;
	}
	/**
	* 실시간TV구분코드
	* @return 실시간TV구분코드
	*/
	public String getRltmTvClCd() {
		return rltmTvClCd;
	}
	/**
	* 실시간TV구분코드
	*@param rltmTvClCd 실시간TV구분코드
	*/
	public void setRltmTvClCd(String rltmTvClCd) {
		this.rltmTvClCd = rltmTvClCd;
	}
	/**
	* 인터넷원부상태코드
	* @return 인터넷원부상태코드
	*/
	public String getInetOrbkStCd() {
		return inetOrbkStCd;
	}
	/**
	* 인터넷원부상태코드
	*@param inetOrbkStCd 인터넷원부상태코드
	*/
	public void setInetOrbkStCd(String inetOrbkStCd) {
		this.inetOrbkStCd = inetOrbkStCd;
	}
	/**
	* 유선전화원부상태코드
	* @return 유선전화원부상태코드
	*/
	public String getWphonOrbkStCd() {
		return wphonOrbkStCd;
	}
	/**
	* 유선전화원부상태코드
	*@param wphonOrbkStCd 유선전화원부상태코드
	*/
	public void setWphonOrbkStCd(String wphonOrbkStCd) {
		this.wphonOrbkStCd = wphonOrbkStCd;
	}
	/**
	* IPTV원부상태코드
	* @return IPTV원부상태코드
	*/
	public String getIptvOrbkStCd() {
	return iptvOrbkStCd;
	}
	/**
	* IPTV원부상태코드
	*@param iptvOrbkStCd IPTV원부상태코드
	*/
	public void setIptvOrbkStCd(String iptvOrbkStCd) {
		this.iptvOrbkStCd = iptvOrbkStCd;
	}
	/**
	* IPTV회선수
	* @return IPTV회선수
	*/
	public long getIptvLineCnt() {
		return iptvLineCnt;
	}
	/**
	* IPTV회선수
	*@param iptvLineCnt IPTV회선수
	*/
	public void setIptvLineCnt(long iptvLineCnt) {
		this.iptvLineCnt = iptvLineCnt;
	}

	public void setIptvLineCnt(String iptvLineCntStr) {
		try {
			this.iptvLineCnt = Integer.parseInt(iptvLineCntStr);
		} catch (Exception e) {
			
		}
	}
	/**
	* L3TID값
	* @return L3TID값
	*/
	public String getL3TidVal() {
		return l3TidVal;
	}
	/**
	* L3TID값
	*@param l3TidVal L3TID값
	*/
	public void setL3TidVal(String l3TidVal) {
		this.l3TidVal = l3TidVal;
	}
	/**
	* L3장비ID
	* @return L3장비ID
	*/
	public String getL3EquipId() {
		return l3EquipId;
	}
	/**
	* L3장비ID
	*@param l3EquipId L3장비ID
	*/
	public void setL3EquipId(String l3EquipId) {
		this.l3EquipId = l3EquipId;
	}
	/**
	* L3장비명
	* @return L3장비명
	*/
	public String getL3EquipNm() {
		return l3EquipNm;
	}
	/**
	* L3장비명
	*@param l3EquipNm L3장비명
	*/
	public void setL3EquipNm(String l3EquipNm) {
		this.l3EquipNm = l3EquipNm;
	}
	/**
	* L3장비제조사명
	* @return L3장비제조사명
	*/
	public String getL3EquipMfactNm() {
		return l3EquipMfactNm;
	}
	/**
	* L3장비제조사명
	*@param l3EquipMfactNm L3장비제조사명
	*/
	public void setL3EquipMfactNm(String l3EquipMfactNm) {
		this.l3EquipMfactNm = l3EquipMfactNm;
	}
	/**
	* L3IP주소
	* @return L3IP주소
	*/
	public String getL3IpAddr() {
		return l3IpAddr;
	}
	/**
	* L3IP주소
	*@param l3IpAddr L3IP주소
	*/
	public void setL3IpAddr(String l3IpAddr) {
		this.l3IpAddr = l3IpAddr;
	}
	/**
	* 정보센터코드
	* @return 정보센터코드
	*/
	public String getInfoCntrCd() {
		return infoCntrCd;
	}
	/**
	* 정보센터코드
	*@param infoCntrCd 정보센터코드
	*/
	public void setInfoCntrCd(String infoCntrCd) {
		this.infoCntrCd = infoCntrCd;
	}
	/**
	* 정보센터명
	* @return 정보센터명
	*/
	public String getInfcNm() {
		return infcNm;
	}
	/**
	* 정보센터명
	*@param infcNm 정보센터명
	*/
	public void setInfcNm(String infcNm) {
		this.infcNm = infcNm;
	}
	/**
	* L3셀번호
	* @return L3셀번호
	*/
	public String getL3CellNum() {
		return l3CellNum;
	}
	/**
	* L3셀번호
	*@param l3CellNum L3셀번호
	*/
	public void setL3CellNum(String l3CellNum) {
		this.l3CellNum = l3CellNum;
	}
	/**
	* L3RACK번호
	* @return L3RACK번호
	*/
	public String getL3RackNum() {
		return l3RackNum;
	}
	/**
	* L3RACK번호
	*@param l3RackNum L3RACK번호
	*/
	public void setL3RackNum(String l3RackNum) {
		this.l3RackNum = l3RackNum;
	}
	/**
	* L3SHELF번호
	* @return L3SHELF번호
	*/
	public String getL3ShlfNum() {
		return l3ShlfNum;
	}
	/**
	* L3SHELF번호
	*@param l3ShlfNum L3SHELF번호
	*/
	public void setL3ShlfNum(String l3ShlfNum) {
		this.l3ShlfNum = l3ShlfNum;
	}
	/**
	* L3카드번호
	* @return L3카드번호
	*/
	public String getL3CardNum() {
		return l3CardNum;
	}
	/**
	* L3카드번호
	*@param l3CardNum L3카드번호
	*/
	public void setL3CardNum(String l3CardNum) {
		this.l3CardNum = l3CardNum;
	}
	/**
	* L3포트번호
	* @return L3포트번호
	*/
	public String getL3PortNum() {
		return l3PortNum;
	}
	/**
	* L3포트번호
	*@param l3PortNum L3포트번호
	*/
	public void setL3PortNum(String l3PortNum) {
		this.l3PortNum = l3PortNum;
	}
	/**
	* L2TID값
	* @return L2TID값
	*/
	public String getL2TidVal() {
		return l2TidVal;
	}
	/**
	* L2TID값
	*@param l2TidVal L2TID값
	*/
	public void setL2TidVal(String l2TidVal) {
		this.l2TidVal = l2TidVal;
	}
	/**
	* L2장비ID
	* @return L2장비ID
	*/
	public String getL2EquipId() {
		return l2EquipId;
	}
	/**
	* L2장비ID
	*@param l2EquipId L2장비ID
	*/
	public void setL2EquipId(String l2EquipId) {
		this.l2EquipId = l2EquipId;
	}
	/**
	* L2장비명
	* @return L2장비명
	*/
	public String getL2EquipNm() {
		return l2EquipNm;
	}
	/**
	* L2장비명
	*@param l2EquipNm L2장비명
	*/
	public void setL2EquipNm(String l2EquipNm) {
		this.l2EquipNm = l2EquipNm;
	}
	/**
	* L2장비제조사명
	* @return L2장비제조사명
	*/
	public String getL2EquipMfactNm() {
		return l2EquipMfactNm;
	}
	/**
	* L2장비제조사명
	*@param l2EquipMfactNm L2장비제조사명
	*/
	public void setL2EquipMfactNm(String l2EquipMfactNm) {
		this.l2EquipMfactNm = l2EquipMfactNm;
	}
	/**
	* L2IP주소
	* @return L2IP주소
	*/
	public String getL2IpAddr() {
		return l2IpAddr;
	}
	/**
	* L2IP주소
	*@param l2IpAddr L2IP주소
	*/
	public void setL2IpAddr(String l2IpAddr) {
		this.l2IpAddr = l2IpAddr;
	}
	/**
	* 국사코드
	* @return 국사코드
	*/
	public String getTpoCd() {
		return tpoCd;
	}
	/**
	* 국사코드
	*@param tpoCd 국사코드
	*/
	public void setTpoCd(String tpoCd) {
		this.tpoCd = tpoCd;
	}
	/**
	* 국사명
	* @return 국사명
	*/
	public String getTpoNm() {
		return tpoNm;
	}
	/**
	* 국사명
	*@param tpoNm 국사명
	*/
	public void setTpoNm(String tpoNm) {
		this.tpoNm = tpoNm;
	}
	/**
	* L2셀번호
	* @return L2셀번호
	*/
	public String getL2CellNum() {
		return l2CellNum;
	}
	/**
	* L2셀번호
	*@param l2CellNum L2셀번호
	*/
	public void setL2CellNum(String l2CellNum) {
		this.l2CellNum = l2CellNum;
	}
	/**
	* L2RACK번호
	* @return L2RACK번호
	*/
	public String getL2RackNum() {
		return l2RackNum;
	}
	/**
	* L2RACK번호
	*@param l2RackNum L2RACK번호
	*/
	public void setL2RackNum(String l2RackNum) {
		this.l2RackNum = l2RackNum;
	}
	/**
	* L2SHELF번호
	* @return L2SHELF번호
	*/
	public String getL2ShlfNum() {
		return l2ShlfNum;
	}
	/**
	* L2SHELF번호
	*@param l2ShlfNum L2SHELF번호
	*/
	public void setL2ShlfNum(String l2ShlfNum) {
		this.l2ShlfNum = l2ShlfNum;
	}
	/**
	* L2카드번호
	* @return L2카드번호
	*/
	public String getL2CardNum() {
		return l2CardNum;
	}
	/**
	* L2카드번호
	*@param l2CardNum L2카드번호
	*/
	public void setL2CardNum(String l2CardNum) {
		this.l2CardNum = l2CardNum;
	}
	/**
	* L2포트번호
	* @return L2포트번호
	*/
	public String getL2PortNum() {
		return l2PortNum;
	}
	/**
	* L2포트번호
	*@param l2PortNum L2포트번호
	*/
	public void setL2PortNum(String l2PortNum) {
		this.l2PortNum = l2PortNum;
	}
	/**
	* ONU장비ID
	* @return ONU장비ID
	*/
	public String getOnuEquipId() {
		return onuEquipId;
	}
	/**
	* ONU장비ID
	*@param onuEquipId ONU장비ID
	*/
	public void setOnuEquipId(String onuEquipId) {
		this.onuEquipId = onuEquipId;
	}
	/**
	* RNTAP번호
	* @return RNTAP번호
	*/
	public String getRnTapNum() {
		return rnTapNum;
	}
	/**
	* RNTAP번호
	*@param rnTapNum RNTAP번호
	*/
	public void setRnTapNum(String rnTapNum) {
		this.rnTapNum = rnTapNum;
	}
	/**
	* 전주번호
	* @return 전주번호
	*/
	public String getTelpolNum() {
		return telpolNum;
	}
	/**
	* 전주번호
	*@param telpolNum 전주번호
	*/
	public void setTelpolNum(String telpolNum) {
		this.telpolNum = telpolNum;
	}
	/**
	* 법정동코드
	* @return 법정동코드
	*/
	public String getLdongCd() {
		return ldongCd;
	}
	/**
	* 법정동코드
	*@param ldongCd 법정동코드
	*/
	public void setLdongCd(String ldongCd) {
		this.ldongCd = ldongCd;
	}
	/**
	* 주소ID
	* @return 주소ID
	*/
	public String getAddrId() {
		return addrId;
	}
	/**
	* 주소ID
	*@param addrId 주소ID
	*/
	public void setAddrId(String addrId) {
		this.addrId = addrId;
	}
	/**
	* 건물동번호
	* @return 건물동번호
	*/
	public long getBldblkNum() {
		return bldblkNum;
	}
	/**
	* 건물동번호
	*@param bldblkNum 건물동번호
	*/
	public void setBldblkNum(long bldblkNum) {
		this.bldblkNum = bldblkNum;
	}
	public void setBldblkNum(String bldblkNumStr) throws Exception {
		this.bldblkNum = Long.parseLong(bldblkNumStr);
	}
	/**
	* 건물호번호
	* @return 건물호번호
	*/
	public long getBlduntNum() {
		return blduntNum;
	}
	/**
	* 건물호번호
	*@param blduntNum 건물호번호
	*/
	public void setBlduntNum(long blduntNum) {
		this.blduntNum = blduntNum;
	}
	public void setBlduntNum(String blduntNumStr) throws Exception {
		this.blduntNum = Long.parseLong(blduntNumStr);
	}
	/**
	* 보조주소
	* @return 보조주소
	*/
	public String getAssistAddr() {
		return assistAddr;
	}
	/**
	* 보조주소
	*@param assistAddr 보조주소
	*/
	public void setAssistAddr(String assistAddr) {
		this.assistAddr = assistAddr;
	}
	/**
	* 우편번호
	* @return 우편번호
	*/
	public String getZip() {
		return zip;
	}
	/**
	* 우편번호
	*@param zip 우편번호
	*/
	public void setZip(String zip) {
		this.zip = zip;
	}
	/**
	* 기본주소
	* @return 기본주소
	*/
	public String getBasAddr() {
		return basAddr;
	}
	/**
	* 기본주소
	*@param basAddr 기본주소
	*/
	public void setBasAddr(String basAddr) {
		this.basAddr = basAddr;
	}
	/**
	* 상세주소
	* @return 상세주소
	*/
	public String getDtlAddr() {
		return dtlAddr;
	}
	/**
	* 상세주소
	*@param dtlAddr 상세주소
	*/
	public void setDtlAddr(String dtlAddr) {
		this.dtlAddr = dtlAddr;
	}
	/**
	* 유통망ID
	* @return 유통망ID
	*/
	public String getDsnetId() {
		return dsnetId;
	}
	/**
	* 유통망ID
	*@param dsnetId 유통망ID
	*/
	public void setDsnetId(String dsnetId) {
		this.dsnetId = dsnetId;
	}
	/**
	* 유통망명
	* @return 유통망명
	*/
	public String getDsnetNm() {
		return dsnetNm;
	}
	/**
	* 유통망명
	*@param dsnetNm 유통망명
	*/
	public void setDsnetNm(String dsnetNm) {
		this.dsnetNm = dsnetNm;
	}
	/**
	* 최초가입조직ID
	* @return 최초가입조직ID
	*/
	public String getFstScrbOrgId() {
		return fstScrbOrgId;
	}
	/**
	* 최초가입조직ID
	*@param fstScrbOrgId 최초가입조직ID
	*/
	public void setFstScrbOrgId(String fstScrbOrgId) {
		this.fstScrbOrgId = fstScrbOrgId;
	}
	/**
	* 최초가입조직명
	* @return 최초가입조직명
	*/
	public String getFstScrbOrgNm() {
		return fstScrbOrgNm;
	}
	/**
	* 최초가입조직명
	*@param fstScrbOrgNm 최초가입조직명
	*/
	public void setFstScrbOrgNm(String fstScrbOrgNm) {
		this.fstScrbOrgNm = fstScrbOrgNm;
	}
	/**
	* 팀조직명
	* @return 팀조직명
	*/
	public String getTeamOrgNm() {
		return teamOrgNm;
	}
	/**
	* 팀조직명
	*@param teamOrgNm 팀조직명
	*/
	public void setTeamOrgNm(String teamOrgNm) {
		this.teamOrgNm = teamOrgNm;
	}
	/**
	* 서비스연결번호
	* @return 서비스연결번호
	*/
	public String getSvcLinkNum() {
		return svcLinkNum;
	}
	/**
	* 서비스연결번호
	*@param svcLinkNum 서비스연결번호
	*/
	public void setSvcLinkNum(String svcLinkNum) {
		this.svcLinkNum = svcLinkNum;
	}
	/**
	* 설치건물속성정보
	* @return 설치건물속성정보
	*/
	public String getSetBldAttrInfo() {
		return setBldAttrInfo;
	}
	/**
	* 설치건물속성정보
	*@param setBldAttrInfo 설치건물속성정보
	*/
	public void setSetBldAttrInfo(String setBldAttrInfo) {
		this.setBldAttrInfo = setBldAttrInfo;
	}
	/**
	* 유선단말관리번호
	* @return 유선단말관리번호
	*/
	public String getWeqpMgmtNum() {
		return weqpMgmtNum;
	}
	/**
	* 유선단말관리번호
	*@param weqpMgmtNum 유선단말관리번호
	*/
	public void setWeqpMgmtNum(String weqpMgmtNum) {
		this.weqpMgmtNum = weqpMgmtNum;
	}
	/**
	* 보조MAC주소시리얼번호
	* @return 보조MAC주소시리얼번호
	*/
	public String getAssistMacAddrSerNum() {
		return assistMacAddrSerNum;
	}
	/**
	* 보조MAC주소시리얼번호
	*@param assistMacAddrSerNum 보조MAC주소시리얼번호
	*/
	public void setAssistMacAddrSerNum(String assistMacAddrSerNum) {
		this.assistMacAddrSerNum = assistMacAddrSerNum;
	}
	
	public boolean parse(String line) throws Exception {
		String[] tokens = line.split("\\|");
		if (tokens.length < TOKEN_NO) {
			logger.error("invalid token no : " + tokens.length);
			return false;
		}
		for (int i = 0; i < tokens.length; i ++) {
			logger.debug(i + ":" + tokens[i]);
		}
		this.setWeqpGrpCd(tokens[0]);
		this.setMacAddr(tokens[1]);
		this.setInoutClCd(tokens[2]); /* 출고 : 1, 입고 : 2 */
		this.setMfactNm(tokens[3]);
		this.setEquipMdlNm(tokens[4]);
		if (tokens[5].trim().length() > 0) this.setCustNum(tokens[5]);
		if (tokens[6].trim().length() > 0) this.setAcntNum(tokens[6]);
		this.setEquipCd(tokens[7]);
		this.setCustNm(tokens[8]);
		this.setSvcTechMthdCd(tokens[9]);
		this.setCustAddr(tokens[10]);
		this.setCustPhonNum(tokens[11]);
		if (tokens[12].trim().length() > 0) this.setInetSvcNum(tokens[12]);
		if (tokens[13].trim().length() > 0) this.setInetSvcMgmtNum(tokens[13]);
		if (tokens[14].trim().length() > 0) this.setPhonSvcNum(tokens[14]);
		if (tokens[15].trim().length() > 0) this.setPhonSvcMgmtNum(tokens[15]);
		if (tokens[16].trim().length() > 0) this.setIptvSvcNum(tokens[16]);
		if (tokens[17].trim().length() > 0) this.setIptvSvcMgmtNum(tokens[17]);
		this.setInetSvcNm(tokens[18]);
		this.setPhonSvcNm(tokens[19]);
		this.setIptvSvcNm(tokens[20]);
		this.setRltmTvClCd(tokens[21]);
		this.setInetOrbkStCd(tokens[22]);
		this.setWphonOrbkStCd(tokens[23]);
		this.setIptvOrbkStCd(tokens[24]);
		if (tokens[25].trim().length() > 0) this.setIptvLineCnt(tokens[25]);
		this.setL3TidVal(tokens[26]);
		this.setL3EquipId(tokens[27]);
		this.setL3EquipNm(tokens[28]);
		this.setL3EquipMfactNm(tokens[29]);
		this.setL3IpAddr(tokens[30]);
		this.setInfoCntrCd(tokens[31]);
		this.setInfcNm(tokens[32]);
		this.setL3CellNum(tokens[33]);
		this.setL3RackNum(tokens[34]);
		this.setL3ShlfNum(tokens[35]);
		this.setL3CardNum(tokens[36]);
		this.setL3PortNum(tokens[37]);
		this.setL2TidVal(tokens[38]);
		this.setL2EquipId(tokens[39]);
		this.setL2EquipNm(tokens[40]);
		this.setL2EquipMfactNm(tokens[41]);
		this.setL2IpAddr(tokens[42]);
		this.setTpoCd(tokens[43]);
		this.setTpoNm(tokens[44]);
		this.setL2CellNum(tokens[45]);
		this.setL2RackNum(tokens[46]);
		this.setL2ShlfNum(tokens[47]);
		this.setL2CardNum(tokens[48]);
		this.setL2PortNum(tokens[49]);
		if (tokens[50].length() <= 12) {
			this.setOnuEquipId(tokens[50]);
		} else {
			this.setOnuEquipId(tokens[50].substring(0,12));
		}
		this.setRnTapNum(tokens[51]);
		this.setTelpolNum(tokens[52]);
		this.setLdongCd(tokens[53]);
		this.setAddrId(tokens[54]);
		if (tokens[55].trim().length() > 0) this.setBldblkNum(tokens[55]);
		if (tokens[56].trim().length() > 0) this.setBlduntNum(tokens[56]);
		this.setAssistAddr(tokens[57]);
		this.setZip(tokens[58]);
		this.setBasAddr(tokens[59]);
		this.setDtlAddr(tokens[60]);
		this.setDsnetId(tokens[61]);
		this.setDsnetNm(tokens[62]);
		this.setFstScrbOrgId(tokens[63]);
		this.setFstScrbOrgNm(tokens[64]);
		this.setTeamOrgNm(tokens[65]);
		this.setSvcLinkNum(tokens[66]);
		this.setSetBldAttrInfo(tokens[67]);
		this.setAssistMacAddrSerNum(tokens[68]);
		
		return true;
	}
}
