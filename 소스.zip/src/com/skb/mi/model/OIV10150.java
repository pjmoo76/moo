package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV10150 extends CopyVO {
	private	String	equipId;
	private	String	auditId;
	private	String	auditDtm;
	private	String	clctDtm;
	private	String	equipMacAddr;
	private	String	massCoClCd;
	private	String	svcClCd;
	private	String	svcNm;
	private	String	ldongCd;
	private	String	exlEquipClCd;
	private	int		equipHrchyLvl;

	private	String	rangeEquipId;

	public String getEquipId() {
		return equipId;
	}
	public void setEquipId(String equipId) {
		this.equipId = equipId;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getClctDtm() {
		return clctDtm;
	}
	public void setClctDtm(String clctDtm) {
		this.clctDtm = clctDtm;
	}
	public String getEquipMacAddr() {
		return equipMacAddr;
	}
	public void setEquipMacAddr(String equipMacAddr) {
		this.equipMacAddr = equipMacAddr;
	}
	public String getMassCoClCd() {
		return massCoClCd;
	}
	public void setMassCoClCd(String massCoClCd) {
		this.massCoClCd = massCoClCd;
	}
	public String getSvcClCd() {
		return svcClCd;
	}
	public void setSvcClCd(String svcClCd) {
		this.svcClCd = svcClCd;
	}
	public String getSvcNm() {
		return svcNm;
	}
	public void setSvcNm(String svcNm) {
		this.svcNm = svcNm;
	}
	public String getLdongCd() {
		return ldongCd;
	}
	public void setLdongCd(String ldongCd) {
		this.ldongCd = ldongCd;
	}
	public String getExlEquipClCd() {
		return exlEquipClCd;
	}
	public void setExlEquipClCd(String exlEquipClCd) {
		this.exlEquipClCd = exlEquipClCd;
	}
	public int getEquipHrchyLvl() {
		return equipHrchyLvl;
	}
	public void setEquipHrchyLvl(int equipHrchyLvl) {
		this.equipHrchyLvl = equipHrchyLvl;
	}

	public String getRangeEquipId() {
		return rangeEquipId;
	}
	public void setRangeEquipId(String rangeEquipId) {
		this.rangeEquipId = rangeEquipId;
	}

	@Override
	public void setKey() {
		this.key = this.equipId;
	}

	@Override
	public boolean equals(CopyVO obj) {
		OIV10150 dest = (OIV10150) obj;
		if (false == StringUtils.equals(this.equipId, dest.equipId)) return false;
		if (false == StringUtils.equals(this.auditId, dest.auditId)) return false;
		if (false == StringUtils.equals(this.auditDtm, dest.auditDtm)) return false;
		if (false == StringUtils.equals(this.clctDtm, dest.clctDtm)) return false;
		if (false == StringUtils.equals(this.equipMacAddr, dest.equipMacAddr)) return false;
		if (false == StringUtils.equals(this.massCoClCd, dest.massCoClCd)) return false;
		if (false == StringUtils.equals(this.svcClCd, dest.svcClCd)) return false;
		if (false == StringUtils.equals(this.svcNm, dest.svcNm)) return false;
		if (false == StringUtils.equals(this.ldongCd, dest.ldongCd)) return false;
		if (false == StringUtils.equals(this.exlEquipClCd, dest.exlEquipClCd)) return false;
		if (this.equipHrchyLvl != dest.equipHrchyLvl) return false;
		return true;
	}

	@Override
	public void setRange(CopyVO obj) {
		OIV10150 dest = (OIV10150) obj;
		this.rangeEquipId = dest.equipId;
	}

}
