package com.skb.mi.model;

public class UnmsAlarmHist {
	private	int	alarmNo;
	private	int	nmsType;
	private	int	neId;
	private	String	neIp;
	private	String	neName;
	private	String	neModelId;
	private	String	neModelName;
	private	String	almLocation;
	private	String	reason;
	private	String	inform;
	private	int	alarmClass;
	private	int	alarmType;
	private	int	alarmLevel;
	private	String	alarmCode;
	private	int	moduleType;
	private	String	moduleName;
	private	int	moduleNeId;
	private	String	moduleNeName;
	private	int	portIndex;
	private	int	portConnType;
	private	int	slotNo;
	private	int	portNo;
	private	String	portDescr;
	private	String	routes;
	private	String	mainProc;
	private	String	subProc;
	private	String	occurTime;
	private	String	clearTime;
	private	String	clearFlag;
	private	String	clearUserId;
	private	int	alarmDuSec;
	private	String	workMode;
	private	String	workEndTime;
	private	String	ackMode;
	private	String	ackTime;
	private	String	ackUserId;
	private	int	neNodeId;
	private	String	neNodeIds;
	private	String	neNodeNames;
	private	int	neAlarmNo;
	private	String	etc1;
	private	String	etc2;
	private	int	alarmNoP;
	private	String	vipYn;
	private	int	v52UseSubsCnt;
	private	String	comments;
	private	String	cmtUser;
	private	String	cmtTime;
	private	int	tmId;
	private	String	location;
	public int getAlarmNo() {
		return alarmNo;
	}
	public void setAlarmNo(int alarmNo) {
		this.alarmNo = alarmNo;
	}
	public int getNmsType() {
		return nmsType;
	}
	public void setNmsType(int nmsType) {
		this.nmsType = nmsType;
	}
	public int getNeId() {
		return neId;
	}
	public void setNeId(int neId) {
		this.neId = neId;
	}
	public String getNeIp() {
		return neIp;
	}
	public void setNeIp(String neIp) {
		this.neIp = neIp;
	}
	public String getNeName() {
		return neName;
	}
	public void setNeName(String neName) {
		this.neName = neName;
	}
	public String getNeModelId() {
		return neModelId;
	}
	public void setNeModelId(String neModelId) {
		this.neModelId = neModelId;
	}
	public String getNeModelName() {
		return neModelName;
	}
	public void setNeModelName(String neModelName) {
		this.neModelName = neModelName;
	}
	public String getAlmLocation() {
		return almLocation;
	}
	public void setAlmLocation(String almLocation) {
		this.almLocation = almLocation;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getInform() {
		return inform;
	}
	public void setInform(String inform) {
		this.inform = inform;
	}
	public int getAlarmClass() {
		return alarmClass;
	}
	public void setAlarmClass(int alarmClass) {
		this.alarmClass = alarmClass;
	}
	public int getAlarmType() {
		return alarmType;
	}
	public void setAlarmType(int alarmType) {
		this.alarmType = alarmType;
	}
	public int getAlarmLevel() {
		return alarmLevel;
	}
	public void setAlarmLevel(int alarmLevel) {
		this.alarmLevel = alarmLevel;
	}
	public String getAlarmCode() {
		return alarmCode;
	}
	public void setAlarmCode(String alarmCode) {
		this.alarmCode = alarmCode;
	}
	public int getModuleType() {
		return moduleType;
	}
	public void setModuleType(int moduleType) {
		this.moduleType = moduleType;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public int getModuleNeId() {
		return moduleNeId;
	}
	public void setModuleNeId(int moduleNeId) {
		this.moduleNeId = moduleNeId;
	}
	public String getModuleNeName() {
		return moduleNeName;
	}
	public void setModuleNeName(String moduleNeName) {
		this.moduleNeName = moduleNeName;
	}
	public int getPortIndex() {
		return portIndex;
	}
	public void setPortIndex(int portIndex) {
		this.portIndex = portIndex;
	}
	public int getPortConnType() {
		return portConnType;
	}
	public void setPortConnType(int portConnType) {
		this.portConnType = portConnType;
	}
	public int getSlotNo() {
		return slotNo;
	}
	public void setSlotNo(int slotNo) {
		this.slotNo = slotNo;
	}
	public int getPortNo() {
		return portNo;
	}
	public void setPortNo(int portNo) {
		this.portNo = portNo;
	}
	public String getPortDescr() {
		return portDescr;
	}
	public void setPortDescr(String portDescr) {
		this.portDescr = portDescr;
	}
	public String getRoutes() {
		return routes;
	}
	public void setRoutes(String routes) {
		this.routes = routes;
	}
	public String getMainProc() {
		return mainProc;
	}
	public void setMainProc(String mainProc) {
		this.mainProc = mainProc;
	}
	public String getSubProc() {
		return subProc;
	}
	public void setSubProc(String subProc) {
		this.subProc = subProc;
	}
	public String getOccurTime() {
		return occurTime;
	}
	public void setOccurTime(String occurTime) {
		this.occurTime = occurTime;
	}
	public String getClearTime() {
		return clearTime;
	}
	public void setClearTime(String clearTime) {
		this.clearTime = clearTime;
	}
	public String getClearFlag() {
		return clearFlag;
	}
	public void setClearFlag(String clearFlag) {
		this.clearFlag = clearFlag;
	}
	public String getClearUserId() {
		return clearUserId;
	}
	public void setClearUserId(String clearUserId) {
		this.clearUserId = clearUserId;
	}
	public int getAlarmDuSec() {
		return alarmDuSec;
	}
	public void setAlarmDuSec(int alarmDuSec) {
		this.alarmDuSec = alarmDuSec;
	}
	public String getWorkMode() {
		return workMode;
	}
	public void setWorkMode(String workMode) {
		this.workMode = workMode;
	}
	public String getWorkEndTime() {
		return workEndTime;
	}
	public void setWorkEndTime(String workEndTime) {
		this.workEndTime = workEndTime;
	}
	public String getAckMode() {
		return ackMode;
	}
	public void setAckMode(String ackMode) {
		this.ackMode = ackMode;
	}
	public String getAckTime() {
		return ackTime;
	}
	public void setAckTime(String ackTime) {
		this.ackTime = ackTime;
	}
	public String getAckUserId() {
		return ackUserId;
	}
	public void setAckUserId(String ackUserId) {
		this.ackUserId = ackUserId;
	}
	public int getNeNodeId() {
		return neNodeId;
	}
	public void setNeNodeId(int neNodeId) {
		this.neNodeId = neNodeId;
	}
	public String getNeNodeIds() {
		return neNodeIds;
	}
	public void setNeNodeIds(String neNodeIds) {
		this.neNodeIds = neNodeIds;
	}
	public String getNeNodeNames() {
		return neNodeNames;
	}
	public void setNeNodeNames(String neNodeNames) {
		this.neNodeNames = neNodeNames;
	}
	public int getNeAlarmNo() {
		return neAlarmNo;
	}
	public void setNeAlarmNo(int neAlarmNo) {
		this.neAlarmNo = neAlarmNo;
	}
	public String getEtc1() {
		return etc1;
	}
	public void setEtc1(String etc1) {
		this.etc1 = etc1;
	}
	public String getEtc2() {
		return etc2;
	}
	public void setEtc2(String etc2) {
		this.etc2 = etc2;
	}
	public int getAlarmNoP() {
		return alarmNoP;
	}
	public void setAlarmNoP(int alarmNoP) {
		this.alarmNoP = alarmNoP;
	}
	public String getVipYn() {
		return vipYn;
	}
	public void setVipYn(String vipYn) {
		this.vipYn = vipYn;
	}
	public int getV52UseSubsCnt() {
		return v52UseSubsCnt;
	}
	public void setV52UseSubsCnt(int v52UseSubsCnt) {
		this.v52UseSubsCnt = v52UseSubsCnt;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getCmtUser() {
		return cmtUser;
	}
	public void setCmtUser(String cmtUser) {
		this.cmtUser = cmtUser;
	}
	public String getCmtTime() {
		return cmtTime;
	}
	public void setCmtTime(String cmtTime) {
		this.cmtTime = cmtTime;
	}
	public int getTmId() {
		return tmId;
	}
	public void setTmId(int tmId) {
		this.tmId = tmId;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
}
