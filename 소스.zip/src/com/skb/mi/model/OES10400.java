package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OES10400 extends CopyVO {
	private	String	svcTechMthdCd;
	private	String	auditId;
	private	String	auditDtm;
	private	String	svcTechMthdNm;
	private	int	svcTs;
	private	String	svcCd;
	private	String	wsvcTypCd;
	private	String	wireMediaFcltTypCd;
	private	String	operGrpSelStrdId;
	private	String	availCheckYn;
	private	String	capaCheckYn;
	private	String	hkFlshYn;
	private	String	weqpNeedYn;
	private	String	weqpSubmitYn;
	private	String	weqpDistbYn;
	private	String	ossSvcNeedYn;
	private	String	schdlgObjYn;
	private	String	effStaDt;
	private	String	effEndDt;
	private	String	voiceTechMthdTypCd;
	private	String	mscLnkgVal;
	private	int	techAblId;
	private	int	brwsSeq;
	private	String	availOpClCd;
	private	String	endOpAsgnId;
	private	String	svcTechMthdEndObjYn;
	private	String	endOpAsgnrId;
	private	String	endObjExtrtDtm;
	private	String	rangeSvcTechMthdCd;
	/* ADMAS DB와 BS DB 현황화 작업 및 CATV칼럼 추가 반영 (2025-04-02 by KMY) */
	private	String	svcOfrSpeedVal;
	private	String	skbClYn;
	private	String	catvTechMthdClCd;

	public String getSvcTechMthdCd() {
		return svcTechMthdCd;
	}
	public void setSvcTechMthdCd(String svcTechMthdCd) {
		this.svcTechMthdCd = svcTechMthdCd;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getSvcTechMthdNm() {
		return svcTechMthdNm;
	}
	public void setSvcTechMthdNm(String svcTechMthdNm) {
		this.svcTechMthdNm = svcTechMthdNm;
	}
	public int getSvcTs() {
		return svcTs;
	}
	public void setSvcTs(int svcTs) {
		this.svcTs = svcTs;
	}
	public String getSvcCd() {
		return svcCd;
	}
	public void setSvcCd(String svcCd) {
		this.svcCd = svcCd;
	}
	public String getWsvcTypCd() {
		return wsvcTypCd;
	}
	public void setWsvcTypCd(String wsvcTypCd) {
		this.wsvcTypCd = wsvcTypCd;
	}
	public String getWireMediaFcltTypCd() {
		return wireMediaFcltTypCd;
	}
	public void setWireMediaFcltTypCd(String wireMediaFcltTypCd) {
		this.wireMediaFcltTypCd = wireMediaFcltTypCd;
	}
	public String getOperGrpSelStrdId() {
		return operGrpSelStrdId;
	}
	public void setOperGrpSelStrdId(String operGrpSelStrdId) {
		this.operGrpSelStrdId = operGrpSelStrdId;
	}
	public String getAvailCheckYn() {
		return availCheckYn;
	}
	public void setAvailCheckYn(String availCheckYn) {
		this.availCheckYn = availCheckYn;
	}
	public String getCapaCheckYn() {
		return capaCheckYn;
	}
	public void setCapaCheckYn(String capaCheckYn) {
		this.capaCheckYn = capaCheckYn;
	}
	public String getHkFlshYn() {
		return hkFlshYn;
	}
	public void setHkFlshYn(String hkFlshYn) {
		this.hkFlshYn = hkFlshYn;
	}
	public String getWeqpNeedYn() {
		return weqpNeedYn;
	}
	public void setWeqpNeedYn(String weqpNeedYn) {
		this.weqpNeedYn = weqpNeedYn;
	}
	public String getWeqpSubmitYn() {
		return weqpSubmitYn;
	}
	public void setWeqpSubmitYn(String weqpSubmitYn) {
		this.weqpSubmitYn = weqpSubmitYn;
	}
	public String getWeqpDistbYn() {
		return weqpDistbYn;
	}
	public void setWeqpDistbYn(String weqpDistbYn) {
		this.weqpDistbYn = weqpDistbYn;
	}
	public String getOssSvcNeedYn() {
		return ossSvcNeedYn;
	}
	public void setOssSvcNeedYn(String ossSvcNeedYn) {
		this.ossSvcNeedYn = ossSvcNeedYn;
	}
	public String getSchdlgObjYn() {
		return schdlgObjYn;
	}
	public void setSchdlgObjYn(String schdlgObjYn) {
		this.schdlgObjYn = schdlgObjYn;
	}
	public String getEffStaDt() {
		return effStaDt;
	}
	public void setEffStaDt(String effStaDt) {
		this.effStaDt = effStaDt;
	}
	public String getEffEndDt() {
		return effEndDt;
	}
	public void setEffEndDt(String effEndDt) {
		this.effEndDt = effEndDt;
	}
	public String getVoiceTechMthdTypCd() {
		return voiceTechMthdTypCd;
	}
	public void setVoiceTechMthdTypCd(String voiceTechMthdTypCd) {
		this.voiceTechMthdTypCd = voiceTechMthdTypCd;
	}
	public String getMscLnkgVal() {
		return mscLnkgVal;
	}
	public void setMscLnkgVal(String mscLnkgVal) {
		this.mscLnkgVal = mscLnkgVal;
	}
	public int getTechAblId() {
		return techAblId;
	}
	public void setTechAblId(int techAblId) {
		this.techAblId = techAblId;
	}
	public int getBrwsSeq() {
		return brwsSeq;
	}
	public void setBrwsSeq(int brwsSeq) {
		this.brwsSeq = brwsSeq;
	}
	public String getAvailOpClCd() {
		return availOpClCd;
	}
	public void setAvailOpClCd(String availOpClCd) {
		this.availOpClCd = availOpClCd;
	}
	public String getEndOpAsgnId() {
		return endOpAsgnId;
	}
	public void setEndOpAsgnId(String endOpAsgnId) {
		this.endOpAsgnId = endOpAsgnId;
	}
	public String getSvcTechMthdEndObjYn() {
		return svcTechMthdEndObjYn;
	}
	public void setSvcTechMthdEndObjYn(String svcTechMthdEndObjYn) {
		this.svcTechMthdEndObjYn = svcTechMthdEndObjYn;
	}
	public String getEndOpAsgnrId() {
		return endOpAsgnrId;
	}
	public void setEndOpAsgnrId(String endOpAsgnrId) {
		this.endOpAsgnrId = endOpAsgnrId;
	}
	public String getEndObjExtrtDtm() {
		return endObjExtrtDtm;
	}
	public void setEndObjExtrtDtm(String endObjExtrtDtm) {
		this.endObjExtrtDtm = endObjExtrtDtm;
	}
	public String getRangeSvcTechMthdCd() {
		return rangeSvcTechMthdCd;
	}
	public void setRangeSvcTechMthdCd(String rangeSvcTechMthdCd) {
		this.rangeSvcTechMthdCd = rangeSvcTechMthdCd;
	}
	@Override
	public void setKey() {
		this.key = this.svcTechMthdCd;
	}

	/* ADMAS DB와 BS DB 현황화 작업 및 CATV칼럼 추가 반영 (2025-04-02 by KMY) */
	public String getSvcOfrSpeedVal() {
		return svcOfrSpeedVal;
	}
	public void setSvcOfrSpeedVal(String svcOfrSpeedVal) {
		this.svcOfrSpeedVal = svcOfrSpeedVal;
	}
	public String getSkbClYn() {
		return skbClYn;
	}
	public void setSkbClYn(String skbClYn) {
		this.skbClYn = skbClYn;
	}
	public String getCatvTechMthdClCd() {
		return catvTechMthdClCd;
	}
	public void setCatvTechMthdClCd(String catvTechMthdClCd) {
		this.catvTechMthdClCd = catvTechMthdClCd;
	}

	@Override
	public boolean equals(CopyVO obj) {
		OES10400 dest = (OES10400) obj;
		if (false == StringUtils.equals(this.svcTechMthdNm, dest.svcTechMthdNm)) return false;
		if (this.svcTs != dest.svcTs) return false;
		if (false == StringUtils.equals(this.svcCd, dest.svcCd)) return false;
		if (false == StringUtils.equals(this.wsvcTypCd, dest.wsvcTypCd)) return false;
		if (false == StringUtils.equals(this.wireMediaFcltTypCd, dest.wireMediaFcltTypCd)) return false;
		if (false == StringUtils.equals(this.operGrpSelStrdId, dest.operGrpSelStrdId)) return false;
		if (false == StringUtils.equals(this.availCheckYn, dest.availCheckYn)) return false;
		if (false == StringUtils.equals(this.capaCheckYn, dest.capaCheckYn)) return false;
		if (false == StringUtils.equals(this.hkFlshYn, dest.hkFlshYn)) return false;
		if (false == StringUtils.equals(this.weqpNeedYn, dest.weqpNeedYn)) return false;
		if (false == StringUtils.equals(this.weqpSubmitYn, dest.weqpSubmitYn)) return false;
		if (false == StringUtils.equals(this.weqpDistbYn, dest.weqpDistbYn)) return false;
		if (false == StringUtils.equals(this.ossSvcNeedYn, dest.ossSvcNeedYn)) return false;
		if (false == StringUtils.equals(this.schdlgObjYn, dest.schdlgObjYn)) return false;
		if (false == StringUtils.equals(this.effStaDt, dest.effStaDt)) return false;
		if (false == StringUtils.equals(this.effEndDt, dest.effEndDt)) return false;
		if (false == StringUtils.equals(this.voiceTechMthdTypCd, dest.voiceTechMthdTypCd)) return false;
		if (false == StringUtils.equals(this.mscLnkgVal, dest.mscLnkgVal)) return false;
		if (this.techAblId != dest.techAblId) return false;
		if (this.brwsSeq != dest.brwsSeq) return false;
		if (false == StringUtils.equals(this.availOpClCd, dest.availOpClCd)) return false;
		if (false == StringUtils.equals(this.endOpAsgnId, dest.endOpAsgnId)) return false;
		if (false == StringUtils.equals(this.svcTechMthdEndObjYn, dest.svcTechMthdEndObjYn)) return false;
		if (false == StringUtils.equals(this.endOpAsgnrId, dest.endOpAsgnrId)) return false;
		if (false == StringUtils.equals(this.endObjExtrtDtm, dest.endObjExtrtDtm)) return false;
		/* ADMAS DB와 BS DB 현황화 작업 및 CATV칼럼 추가 반영 (2025-04-02 by KMY) */
		if (false == StringUtils.equals(this.svcOfrSpeedVal, dest.svcOfrSpeedVal)) return false;
		if (false == StringUtils.equals(this.skbClYn, dest.skbClYn)) return false;
		if (false == StringUtils.equals(this.catvTechMthdClCd, dest.catvTechMthdClCd)) return false;
		return true;
	}
	@Override
	public void setRange(CopyVO obj) {
		OES10400 src = (OES10400) obj;
		this.rangeSvcTechMthdCd = src.svcTechMthdCd;
	}
}

