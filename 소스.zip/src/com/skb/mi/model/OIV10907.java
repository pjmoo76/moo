package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV10907 extends CopyVO {
	private	String	teamOrgId;
	private	String	orgId;
	private	String	cntrOrgClCd;
	private	String	auditId;
	private	String	auditDtm;
	private	String	orgNm;
	private	String	mgmtObjYn;

	private	String	rangeTeamOrgId;
	private	String	rangeOrgId;
	private	String	rangeCntrOrgClCd;

	public String getTeamOrgId() {
		return teamOrgId;
	}
	public void setTeamOrgId(String teamOrgId) {
		this.teamOrgId = teamOrgId;
	}
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	public String getCntrOrgClCd() {
		return cntrOrgClCd;
	}
	public void setCntrOrgClCd(String cntrOrgClCd) {
		this.cntrOrgClCd = cntrOrgClCd;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getOrgNm() {
		return orgNm;
	}
	public void setOrgNm(String orgNm) {
		this.orgNm = orgNm;
	}
	public String getMgmtObjYn() {
		return mgmtObjYn;
	}
	public void setMgmtObjYn(String mgmtObjYn) {
		this.mgmtObjYn = mgmtObjYn;
	}
	@Override
	public void setKey() {
		this.key = this.teamOrgId+"|"+this.orgId+"|"+this.cntrOrgClCd;
	}
	@Override
	public boolean equals(CopyVO obj) {
		OIV10907 dest = (OIV10907) obj;
		if (false == StringUtils.equals(this.teamOrgId, dest.teamOrgId)) return false;
		if (false == StringUtils.equals(this.orgId, dest.orgId)) return false;
		if (false == StringUtils.equals(this.cntrOrgClCd, dest.cntrOrgClCd)) return false;
		if (false == StringUtils.equals(this.orgNm, dest.orgNm)) return false;
		if (false == StringUtils.equals(this.mgmtObjYn, dest.mgmtObjYn)) return false;
		return true;
	}

	public String getRangeTeamOrgId() {
		return rangeTeamOrgId;
	}
	public void setRangeTeamOrgId(String rangeTeamOrgId) {
		this.rangeTeamOrgId = rangeTeamOrgId;
	}
	public String getRangeOrgId() {
		return rangeOrgId;
	}
	public void setRangeOrgId(String rangeOrgId) {
		this.rangeOrgId = rangeOrgId;
	}
	public String getRangeCntrOrgClCd() {
		return rangeCntrOrgClCd;
	}
	public void setRangeCntrOrgClCd(String rangeCntrOrgClCd) {
		this.rangeCntrOrgClCd = rangeCntrOrgClCd;
	}

	@Override
	public void setRange(CopyVO obj) {
		OIV10907 src = (OIV10907) obj;
		this.rangeTeamOrgId = src.getTeamOrgId();
		this.rangeOrgId = src.getOrgId();
		this.rangeCntrOrgClCd = src.getCntrOrgClCd();
	}
}
