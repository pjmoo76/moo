package com.skb.mi.model;

public class OMN73132 extends AggrDataVO {

	private	String	mntrDt;
	private	String	apMacAddr;
	private	String	auditId;
	private	int		wanLpOccrCnt;
	private	int		lan1LpOccrCnt;
	private	int		lan2LpOccrCnt;
	private	int		lan3LpOccrCnt;
	private	int		lan4LpOccrCnt;

	public OMN73132() {
	}

	public String getMntrDt() {
		return mntrDt;
	}
	public void setMntrDt(String mntrDt) {
		this.mntrDt = mntrDt;
	}
	public String getApMacAddr() {
		return apMacAddr;
	}
	public void setApMacAddr(String apMacAddr) {
		this.apMacAddr = apMacAddr;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public int getWanLpOccrCnt() {
		return wanLpOccrCnt;
	}
	public void setWanLpOccrCnt(int wanLpOccrCnt) {
		this.wanLpOccrCnt = wanLpOccrCnt;
	}
	public int getLan1LpOccrCnt() {
		return lan1LpOccrCnt;
	}
	public void setLan1LpOccrCnt(int lan1LpOccrCnt) {
		this.lan1LpOccrCnt = lan1LpOccrCnt;
	}
	public int getLan2LpOccrCnt() {
		return lan2LpOccrCnt;
	}
	public void setLan2LpOccrCnt(int lan2LpOccrCnt) {
		this.lan2LpOccrCnt = lan2LpOccrCnt;
	}
	public int getLan3LpOccrCnt() {
		return lan3LpOccrCnt;
	}
	public void setLan3LpOccrCnt(int lan3LpOccrCnt) {
		this.lan3LpOccrCnt = lan3LpOccrCnt;
	}
	public int getLan4LpOccrCnt() {
		return lan4LpOccrCnt;
	}
	public void setLan4LpOccrCnt(int lan4LpOccrCnt) {
		this.lan4LpOccrCnt = lan4LpOccrCnt;
	}


	@Override
	public boolean isValid() {
		if (this.apMacAddr == null || this.apMacAddr.isEmpty() || this.apMacAddr.length() > 15) {
			return false;
		}
		return true;
	}
	@Override
	public String toDelimiterString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("%s|", mntrDt));
		sb.append(String.format("%s|", apMacAddr));
		sb.append(String.format("%d|", wanLpOccrCnt));
		sb.append(String.format("%d|", lan1LpOccrCnt));
		sb.append(String.format("%d|", lan2LpOccrCnt));
		sb.append(String.format("%d|", lan3LpOccrCnt));
		sb.append(String.format("%d|", lan4LpOccrCnt));
		return sb.toString();
	}

	@Override
	public void add(AggrDataVO obj) {
		OMN73132 obj2 = (OMN73132) obj;
		this.wanLpOccrCnt += obj2.wanLpOccrCnt;
		this.lan1LpOccrCnt += obj2.lan1LpOccrCnt;
		this.lan2LpOccrCnt += obj2.lan2LpOccrCnt;
		this.lan3LpOccrCnt += obj2.lan3LpOccrCnt;
		this.lan4LpOccrCnt += obj2.lan4LpOccrCnt;
	}

	@Override
	public boolean isTarget() {
		return true;
	}

	@Override
	public String getKey() {
		return this.apMacAddr;
	}
}
