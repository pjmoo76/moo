package com.skb.mi.model;

public class OIV10801 {
	private	String	macAddrVal;
	private	String	auditId;
	private	String	ipAddr;
	private	String	pingStVal;
	private	String	pingStChgDtm;
	private	String	lastPingStCheckDtm;

	public String getMacAddrVal() {
		return macAddrVal;
	}
	public void setMacAddrVal(String macAddrVal) {
		this.macAddrVal = macAddrVal;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getIpAddr() {
		return ipAddr;
	}
	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}
	public String getPingStVal() {
		return pingStVal;
	}
	public void setPingStVal(String pingStVal) {
		this.pingStVal = pingStVal;
	}
	public String getPingStChgDtm() {
		return pingStChgDtm;
	}
	public void setPingStChgDtm(String pingStChgDtm) {
		this.pingStChgDtm = pingStChgDtm;
	}
	public String getLastPingStCheckDtm() {
		return lastPingStCheckDtm;
	}
	public void setLastPingStCheckDtm(String lastPingStCheckDtm) {
		this.lastPingStCheckDtm = lastPingStCheckDtm;
	}
}
