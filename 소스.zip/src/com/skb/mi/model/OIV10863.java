package com.skb.mi.model;

public class OIV10863 {
	private	String	sumOperId;
	private	String	sumOperClCd;
	private	int		operSeq;
	private	String	operSqlId;
	private	String	operDslVal;
	private	String	esIdxNm;
	private	String	esIdxAddInfo;
	private	String	rmk;
	private	String	batModeVal;

	public String getSumOperId() {
		return sumOperId;
	}
	public void setSumOperId(String sumOperId) {
		this.sumOperId = sumOperId;
	}
	public String getSumOperClCd() {
		return sumOperClCd;
	}
	public void setSumOperClCd(String sumOperClCd) {
		this.sumOperClCd = sumOperClCd;
	}
	public int getOperSeq() {
		return operSeq;
	}
	public void setOperSeq(int operSeq) {
		this.operSeq = operSeq;
	}
	public String getOperSqlId() {
		return operSqlId;
	}
	public void setOperSqlId(String operSqlId) {
		this.operSqlId = operSqlId;
	}
	public String getOperDslVal() {
		return operDslVal;
	}
	public void setOperDslVal(String operDslVal) {
		this.operDslVal = operDslVal;
	}
	public String getEsIdxNm() {
		return esIdxNm;
	}
	public void setEsIdxNm(String esIdxNm) {
		this.esIdxNm = esIdxNm;
	}
	public String getEsIdxAddInfo() {
		return esIdxAddInfo;
	}
	public void setEsIdxAddInfo(String esIdxAddInfo) {
		this.esIdxAddInfo = esIdxAddInfo;
	}
	public String getRmk() {
		return rmk;
	}
	public void setRmk(String rmk) {
		this.rmk = rmk;
	}
	public String getBatModeVal() {
		return batModeVal;
	}
	public void setBatModeVal(String batModeVal) {
		this.batModeVal = batModeVal;
	}
}
