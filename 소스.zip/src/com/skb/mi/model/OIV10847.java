package com.skb.mi.model;

public class OIV10847 {
	private	String	dnsClCd;
	private	String	dnsIpAddr;
	private	String	auditId;
	private	String	bizrNm;
	private	String	staDnsIpAddr;
	private	String	endDnsIpAddr;

	public String getDnsClCd() {
		return dnsClCd;
	}
	public void setDnsClCd(String dnsClCd) {
		this.dnsClCd = dnsClCd;
	}
	public String getDnsIpAddr() {
		return dnsIpAddr;
	}
	public void setDnsIpAddr(String dnsIpAddr) {
		this.dnsIpAddr = dnsIpAddr;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getBizrNm() {
		return bizrNm;
	}
	public void setBizrNm(String bizrNm) {
		this.bizrNm = bizrNm;
	}
	public String getStaDnsIpAddr() {
		return staDnsIpAddr;
	}
	public void setStaDnsIpAddr(String staDnsIpAddr) {
		this.staDnsIpAddr = staDnsIpAddr;
	}
	public String getEndDnsIpAddr() {
		return endDnsIpAddr;
	}
	public void setEndDnsIpAddr(String endDnsIpAddr) {
		this.endDnsIpAddr = endDnsIpAddr;
	}
}
