package com.skb.mi.model;

public class OMN10801 {
	private	String	apThrsCd;
	private	String	apThrsCdNm;
	private	String	apThrsClCd;
	private	String	apThrsClCdNm;
	private	long	warngSetVal;
	private	long	crtgSetVal;
	private	long	dataIncreRt;
	private	long	dataMinVal;
	private	long	teamThrsVal;
	private	long	allThrsVal;
	private	String	dataUnitVal;
	
	public OMN10801() { 
	}

	public OMN10801(String apThrsCd) {
		this.apThrsCd = apThrsCd;
	}

	public String getApThrsCd() {
		return apThrsCd;
	}
	public void setApThrsCd(String apThrsCd) {
		this.apThrsCd = apThrsCd;
	}
	public String getApThrsCdNm() {
		return apThrsCdNm;
	}
	public void setApThrsCdNm(String apThrsCdNm) {
		this.apThrsCdNm = apThrsCdNm;
	}
	public String getApThrsClCd() {
		return apThrsClCd;
	}
	public void setApThrsClCd(String apThrsClCd) {
		this.apThrsClCd = apThrsClCd;
	}
	public String getApThrsClCdNm() {
		return apThrsClCdNm;
	}
	public void setApThrsClCdNm(String apThrsClCdNm) {
		this.apThrsClCdNm = apThrsClCdNm;
	}
	public long getWarngSetVal() {
		return warngSetVal;
	}
	public void setWarngSetVal(long warngSetVal) {
		this.warngSetVal = warngSetVal;
	}
	public long getCrtgSetVal() {
		return crtgSetVal;
	}
	public void setCrtgSetVal(long crtgSetVal) {
		this.crtgSetVal = crtgSetVal;
	}
	public long getDataIncreRt() {
		return dataIncreRt;
	}
	public void setDataIncreRt(long dataIncreRt) {
		this.dataIncreRt = dataIncreRt;
	}
	public long getDataMinVal() {
		return dataMinVal;
	}
	public void setDataMinVal(long dataMinVal) {
		this.dataMinVal = dataMinVal;
	}
	public long getTeamThrsVal() {
		return teamThrsVal;
	}
	public void setTeamThrsVal(long teamThrsVal) {
		this.teamThrsVal = teamThrsVal;
	}
	public long getAllThrsVal() {
		return allThrsVal;
	}
	public void setAllThrsVal(long allThrsVal) {
		this.allThrsVal = allThrsVal;
	}
	public String getDataUnitVal() {
		return dataUnitVal;
	}
	public void setDataUnitVal(String dataUnitVal) {
		this.dataUnitVal = dataUnitVal;
	}
}
