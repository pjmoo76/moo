package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV10400 extends CopyVO {
	private	String	equipId;
	private	String	equipPortId;
	private	String	auditId;
	private	String	auditDtm;
	private	String	equipConsItmId;
	private	String	mounLocNum;
	private	String	portNum;
	private	String	portAlsNm;
	private	String	portTypCd;
	private	String	portSpeedCd;
	private	String	pollingMObjYn;
	private	String	pingMObjYn;
	private	int		rgstCycl;
	private	String	portDesc;

	private	String	rangeEquipId;
	private	String	rangeEquipPortId;

	public String getEquipId() {
		return equipId;
	}
	public void setEquipId(String equipId) {
		this.equipId = equipId;
	}
	public String getEquipPortId() {
		return equipPortId;
	}
	public void setEquipPortId(String equipPortId) {
		this.equipPortId = equipPortId;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getEquipConsItmId() {
		return equipConsItmId;
	}
	public void setEquipConsItmId(String equipConsItmId) {
		this.equipConsItmId = equipConsItmId;
	}
	public String getMounLocNum() {
		return mounLocNum;
	}
	public void setMounLocNum(String mounLocNum) {
		this.mounLocNum = mounLocNum;
	}
	public String getPortNum() {
		return portNum;
	}
	public void setPortNum(String portNum) {
		this.portNum = portNum;
	}
	public String getPortAlsNm() {
		return portAlsNm;
	}
	public void setPortAlsNm(String portAlsNm) {
		this.portAlsNm = portAlsNm;
	}
	public String getPortTypCd() {
		return portTypCd;
	}
	public void setPortTypCd(String portTypCd) {
		this.portTypCd = portTypCd;
	}
	public String getPortSpeedCd() {
		return portSpeedCd;
	}
	public void setPortSpeedCd(String portSpeedCd) {
		this.portSpeedCd = portSpeedCd;
	}
	public String getPollingMObjYn() {
		return pollingMObjYn;
	}
	public void setPollingMObjYn(String pollingMObjYn) {
		this.pollingMObjYn = pollingMObjYn;
	}
	public String getPingMObjYn() {
		return pingMObjYn;
	}
	public void setPingMObjYn(String pingMObjYn) {
		this.pingMObjYn = pingMObjYn;
	}
	public int getRgstCycl() {
		return rgstCycl;
	}
	public void setRgstCycl(int rgstCycl) {
		this.rgstCycl = rgstCycl;
	}
	public String getPortDesc() {
		return portDesc;
	}
	public void setPortDesc(String portDesc) {
		this.portDesc = portDesc;
	}
	@Override
	public void setKey() {
		this.key = this.equipId+"|"+this.equipPortId;
	}
	@Override
	public boolean equals(CopyVO obj) {
		OIV10400 dest = (OIV10400) obj;
		if (false == StringUtils.equals(this.equipId, dest.equipId)) return false;
		if (false == StringUtils.equals(this.equipPortId, dest.equipPortId)) return false;
		if (false == StringUtils.equals(this.equipConsItmId, dest.equipConsItmId)) return false;
		if (false == StringUtils.equals(this.mounLocNum, dest.mounLocNum)) return false;
		if (false == StringUtils.equals(this.portNum, dest.portNum)) return false;
		if (false == StringUtils.equals(this.portAlsNm, dest.portAlsNm)) return false;
		if (false == StringUtils.equals(this.portTypCd, dest.portTypCd)) return false;
		if (false == StringUtils.equals(this.portSpeedCd, dest.portSpeedCd)) return false;
		if (false == StringUtils.equals(this.pollingMObjYn, dest.pollingMObjYn)) return false;
		if (false == StringUtils.equals(this.pingMObjYn, dest.pingMObjYn)) return false;
		if (this.rgstCycl != dest.rgstCycl) return false;
		if (false == StringUtils.equals(this.portDesc, dest.portDesc)) return false;
		return true;
	}
	@Override
	public void setRange(CopyVO obj) {
		OIV10400 src = (OIV10400) obj;
		this.rangeEquipId = src.getEquipId();
		this.rangeEquipPortId = src.getEquipPortId();
	}
	public String getRangeEquipId() {
		return rangeEquipId;
	}
	public void setRangeEquipId(String rangeEquipId) {
		this.rangeEquipId = rangeEquipId;
	}
	public String getRangeEquipPortId() {
		return rangeEquipPortId;
	}
	public void setRangeEquipPortId(String rangeEquipPortId) {
		this.rangeEquipPortId = rangeEquipPortId;
	}

}
