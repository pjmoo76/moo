package com.skb.mi.model;

public class OMN30203 {
	private	int		dablCdSerNum;
	private	String	auditId;
	private	String	auditDtm;
	private	String	netClCd;
	private	String	dablLclCd;
	private	String	dablLclNm;
	private	String	dablMclCd;
	private	String	dablMclNm;
	private	String	dablCd;
	private	String	dablCdNm;
	private	String	dablCdDesc;
	private	String	srcRgstMndtYn;
	private	String	nmsDablCd;
	private	String	clctNmsClCd;
	private	String	clctEvtId;
	private	String	clctEvtCd;
	private String  nmsCatvYn;

	public int getDablCdSerNum() {
		return dablCdSerNum;
	}
	public void setDablCdSerNum(int dablCdSerNum) {
		this.dablCdSerNum = dablCdSerNum;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getNetClCd() {
		return netClCd;
	}
	public void setNetClCd(String netClCd) {
		this.netClCd = netClCd;
	}
	public String getDablLclCd() {
		return dablLclCd;
	}
	public void setDablLclCd(String dablLclCd) {
		this.dablLclCd = dablLclCd;
	}
	public String getDablLclNm() {
		return dablLclNm;
	}
	public void setDablLclNm(String dablLclNm) {
		this.dablLclNm = dablLclNm;
	}
	public String getDablMclCd() {
		return dablMclCd;
	}
	public void setDablMclCd(String dablMclCd) {
		this.dablMclCd = dablMclCd;
	}
	public String getDablMclNm() {
		return dablMclNm;
	}
	public void setDablMclNm(String dablMclNm) {
		this.dablMclNm = dablMclNm;
	}
	public String getDablCd() {
		return dablCd;
	}
	public void setDablCd(String dablCd) {
		this.dablCd = dablCd;
	}
	public String getDablCdNm() {
		return dablCdNm;
	}
	public void setDablCdNm(String dablCdNm) {
		this.dablCdNm = dablCdNm;
	}
	public String getDablCdDesc() {
		return dablCdDesc;
	}
	public void setDablCdDesc(String dablCdDesc) {
		this.dablCdDesc = dablCdDesc;
	}
	public String getSrcRgstMndtYn() {
		return srcRgstMndtYn;
	}
	public void setSrcRgstMndtYn(String srcRgstMndtYn) {
		this.srcRgstMndtYn = srcRgstMndtYn;
	}
	public String getNmsDablCd() {
		return nmsDablCd;
	}
	public void setNmsDablCd(String nmsDablCd) {
		this.nmsDablCd = nmsDablCd;
	}
	public String getClctNmsClCd() {
		return clctNmsClCd;
	}
	public void setClctNmsClCd(String clctNmsClCd) {
		this.clctNmsClCd = clctNmsClCd;
	}
	public String getClctEvtId() {
		return clctEvtId;
	}
	public void setClctEvtId(String clctEvtId) {
		this.clctEvtId = clctEvtId;
	}
	public String getClctEvtCd() {
		return clctEvtCd;
	}
	public void setClctEvtCd(String clctEvtCd) {
		this.clctEvtCd = clctEvtCd;
	}
	public String getNmsCatvYn() {
		return nmsCatvYn;
	}
	public void setNmsCatvYn(String nmsCatvYn) {
		this.nmsCatvYn = nmsCatvYn;
	}
}
