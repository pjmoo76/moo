package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV25610 extends CopyVO {
	private	String	iptvChnlSvrMappId;
	private	String	auditId;
	private	String	auditDtm;
	private	String	svrIpAddr;
	private	String	svrPortNum;
	private	String	chnlNum;
	private	String	chnlNm;
	private	String	tvAreaInfo;
	private	String	grdwvYn;
	private	String	repChnlNm;
	private	String	lnkgChnlNm;
	private	String	rsltnGrCd;

	private	String	rangeIptvChnlSvrMappId;

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("iptvChnlSvrMappId=%s\n", iptvChnlSvrMappId));
		sb.append(String.format("auditId=%s\n", auditId));
		sb.append(String.format("auditDtm=%s\n", auditDtm));
		sb.append(String.format("svrIpAddr=%s\n", svrIpAddr));
		sb.append(String.format("svrPortNum=%s\n", svrPortNum));
		sb.append(String.format("chnlNum=%s\n", chnlNum));
		sb.append(String.format("chnlNm=%s\n", chnlNm));
		sb.append(String.format("tvAreaInfo=%s\n", tvAreaInfo));
		sb.append(String.format("grdwvYn=%s\n", grdwvYn));
		sb.append(String.format("repChnlNm=%s\n", repChnlNm));
		sb.append(String.format("lnkgChnlNm=%s\n", lnkgChnlNm));
		sb.append(String.format("rsltnGrCd=%s\n", rsltnGrCd));
		return sb.toString();
	}
	
	public String getIptvChnlSvrMappId() {
		return iptvChnlSvrMappId;
	}
	public void setIptvChnlSvrMappId(String iptvChnlSvrMappId) {
		this.iptvChnlSvrMappId = iptvChnlSvrMappId;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getSvrIpAddr() {
		return svrIpAddr;
	}
	public void setSvrIpAddr(String svrIpAddr) {
		this.svrIpAddr = svrIpAddr;
	}
	public String getSvrPortNum() {
		return svrPortNum;
	}
	public void setSvrPortNum(String svrPortNum) {
		this.svrPortNum = svrPortNum;
	}
	public String getChnlNum() {
		return chnlNum;
	}
	public void setChnlNum(String chnlNum) {
		this.chnlNum = chnlNum;
	}
	public String getChnlNm() {
		return chnlNm;
	}
	public void setChnlNm(String chnlNm) {
		this.chnlNm = chnlNm;
	}
	public String getTvAreaInfo() {
		return tvAreaInfo;
	}
	public void setTvAreaInfo(String tvAreaInfo) {
		this.tvAreaInfo = tvAreaInfo;
	}
	public String getGrdwvYn() {
		return grdwvYn;
	}
	public void setGrdwvYn(String grdwvYn) {
		this.grdwvYn = grdwvYn;
	}
	public String getRepChnlNm() {
		return repChnlNm;
	}
	public void setRepChnlNm(String repChnlNm) {
		this.repChnlNm = repChnlNm;
	}
	public String getLnkgChnlNm() {
		return lnkgChnlNm;
	}
	public void setLnkgChnlNm(String lnkgChnlNm) {
		this.lnkgChnlNm = lnkgChnlNm;
	}
	public String getRsltnGrCd() {
		return rsltnGrCd;
	}
	public void setRsltnGrCd(String rsltnGrCd) {
		this.rsltnGrCd = rsltnGrCd;
	}
	public String getRangeIptvChnlSvrMappId() {
		return rangeIptvChnlSvrMappId;
	}
	public void setRangeIptvChnlSvrMappId(String rangeIptvChnlSvrMappId) {
		this.rangeIptvChnlSvrMappId = rangeIptvChnlSvrMappId;
	}

	@Override
	public void setKey() {
		this.key = this.iptvChnlSvrMappId;
	}

	@Override
	public boolean equals(CopyVO obj) {
		OIV25610 dest = (OIV25610) obj;
		if (false == StringUtils.equals(this.svrIpAddr, dest.svrIpAddr)) return false;
		if (false == StringUtils.equals(this.svrPortNum, dest.svrPortNum)) return false;
		if (false == StringUtils.equals(this.chnlNum, dest.chnlNum)) return false;
		if (false == StringUtils.equals(this.chnlNm, dest.chnlNm)) return false;
		if (false == StringUtils.equals(this.tvAreaInfo, dest.tvAreaInfo)) return false;
		if (false == StringUtils.equals(this.grdwvYn, dest.grdwvYn)) return false;
		if (false == StringUtils.equals(this.repChnlNm, dest.repChnlNm)) return false;
		if (false == StringUtils.equals(this.lnkgChnlNm, dest.lnkgChnlNm)) return false;
		if (false == StringUtils.equals(this.rsltnGrCd, dest.rsltnGrCd)) return false;
		return true;
	}

	@Override
	public void setRange(CopyVO obj) {
		OIV25610 src = (OIV25610) obj;
		this.rangeIptvChnlSvrMappId = src.iptvChnlSvrMappId;
	}

}
