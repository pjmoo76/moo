package com.skb.mi.model;

public class OIV10865 {
	private	String	sumOperId;
	private	String	sumOperClCd;
	private	int		operSeq;
	private	String	trgtItmNm;
	private	String	srcItmNm;
	private	String	rmk;
	private	String	mappOperPgmClasNm;

	public String getSumOperId() {
		return sumOperId;
	}
	public void setSumOperId(String sumOperId) {
		this.sumOperId = sumOperId;
	}
	public String getSumOperClCd() {
		return sumOperClCd;
	}
	public void setSumOperClCd(String sumOperClCd) {
		this.sumOperClCd = sumOperClCd;
	}
	public int getOperSeq() {
		return operSeq;
	}
	public void setOperSeq(int operSeq) {
		this.operSeq = operSeq;
	}
	public String getTrgtItmNm() {
		return trgtItmNm;
	}
	public void setTrgtItmNm(String trgtItmNm) {
		this.trgtItmNm = trgtItmNm;
	}
	public String getSrcItmNm() {
		return srcItmNm;
	}
	public void setSrcItmNm(String srcItmNm) {
		this.srcItmNm = srcItmNm;
	}
	public String getRmk() {
		return rmk;
	}
	public void setRmk(String rmk) {
		this.rmk = rmk;
	}
	public String getMappOperPgmClasNm() {
		return mappOperPgmClasNm;
	}
	public void setMappOperPgmClasNm(String mappOperPgmClasNm) {
		this.mappOperPgmClasNm = mappOperPgmClasNm;
	}
}
