package com.skb.mi.model;

public class TblSubmitQueue {
	private	long	cmpMsgId;
	private	String	cmpMsgGroupId;
	private	String	usrId;
	private	String	smsGb;
	private	String	usedCd;
	private	String	reservedFg;
	private	String	reservedDttm;
	private	String	savedFg;
	private	String	rcvPhnId;
	private	String	sndPhnId;
	private	String	natCd;
	private	String	assignCd;
	private	String	sndMsg;
	private	String	callbackUrl;
	private	String	cmpSndDttm;
	private	String	regSndDttm;
	private	String	regRcvDttm;
	private	String	machineId;
	private	String	smsStatus;
	private	String	rsltVal;
	private	long	contentCnt;
	private	String	contentMimeType;
	private	String	contentPath;
	private	String	cmpRcvDttm;
	private	String	telcoId;
	private	String	msgTitle;
	
	public TblSubmitQueue() {
		this.cmpMsgGroupId = "CO";
		this.usrId = "5464";
		this.smsGb = "1";
		this.usedCd = "00";
		this.reservedFg = "I";
		this.contentCnt = 1;
		this.contentMimeType = "text/plain";
		this.savedFg = "0";
		this.sndPhnId = "07078051228";
		this.natCd = "82";
		this.assignCd = "00000";
	}

	public long getCmpMsgId() {
		return cmpMsgId;
	}
	public void setCmpMsgId(long cmpMsgId) {
		this.cmpMsgId = cmpMsgId;
	}
	public String getCmpMsgGroupId() {
		return cmpMsgGroupId;
	}
	public void setCmpMsgGroupId(String cmpMsgGroupId) {
		this.cmpMsgGroupId = cmpMsgGroupId;
	}
	public String getUsrId() {
		return usrId;
	}
	public void setUsrId(String usrId) {
		this.usrId = usrId;
	}
	public String getSmsGb() {
		return smsGb;
	}
	public void setSmsGb(String smsGb) {
		this.smsGb = smsGb;
	}
	public String getUsedCd() {
		return usedCd;
	}
	public void setUsedCd(String usedCd) {
		this.usedCd = usedCd;
	}
	public String getReservedFg() {
		return reservedFg;
	}
	public void setReservedFg(String reservedFg) {
		this.reservedFg = reservedFg;
	}
	public String getReservedDttm() {
		return reservedDttm;
	}
	public void setReservedDttm(String reservedDttm) {
		this.reservedDttm = reservedDttm;
	}
	public String getSavedFg() {
		return savedFg;
	}
	public void setSavedFg(String savedFg) {
		this.savedFg = savedFg;
	}
	public String getRcvPhnId() {
		return rcvPhnId;
	}
	public void setRcvPhnId(String rcvPhnId) {
		this.rcvPhnId = rcvPhnId;
	}
	public String getSndPhnId() {
		return sndPhnId;
	}
	public void setSndPhnId(String sndPhnId) {
		this.sndPhnId = sndPhnId;
	}
	public String getNatCd() {
		return natCd;
	}
	public void setNatCd(String natCd) {
		this.natCd = natCd;
	}
	public String getAssignCd() {
		return assignCd;
	}
	public void setAssignCd(String assignCd) {
		this.assignCd = assignCd;
	}
	public String getSndMsg() {
		return sndMsg;
	}
	public void setSndMsg(String sndMsg) {
		this.sndMsg = sndMsg;
	}
	public String getCallbackUrl() {
		return callbackUrl;
	}
	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}
	public String getCmpSndDttm() {
		return cmpSndDttm;
	}
	public void setCmpSndDttm(String cmpSndDttm) {
		this.cmpSndDttm = cmpSndDttm;
	}
	public String getRegSndDttm() {
		return regSndDttm;
	}
	public void setRegSndDttm(String regSndDttm) {
		this.regSndDttm = regSndDttm;
	}
	public String getRegRcvDttm() {
		return regRcvDttm;
	}
	public void setRegRcvDttm(String regRcvDttm) {
		this.regRcvDttm = regRcvDttm;
	}
	public String getMachineId() {
		return machineId;
	}
	public void setMachineId(String machineId) {
		this.machineId = machineId;
	}
	public String getSmsStatus() {
		return smsStatus;
	}
	public void setSmsStatus(String smsStatus) {
		this.smsStatus = smsStatus;
	}
	public String getRsltVal() {
		return rsltVal;
	}
	public void setRsltVal(String rsltVal) {
		this.rsltVal = rsltVal;
	}
	public long getContentCnt() {
		return contentCnt;
	}
	public void setContentCnt(long contentCnt) {
		this.contentCnt = contentCnt;
	}
	public String getContentMimeType() {
		return contentMimeType;
	}
	public void setContentMimeType(String contentMimeType) {
		this.contentMimeType = contentMimeType;
	}
	public String getContentPath() {
		return contentPath;
	}
	public void setContentPath(String contentPath) {
		this.contentPath = contentPath;
	}
	public String getCmpRcvDttm() {
		return cmpRcvDttm;
	}
	public void setCmpRcvDttm(String cmpRcvDttm) {
		this.cmpRcvDttm = cmpRcvDttm;
	}
	public String getTelcoId() {
		return telcoId;
	}
	public void setTelcoId(String telcoId) {
		this.telcoId = telcoId;
	}
	public String getMsgTitle() {
		return msgTitle;
	}
	public void setMsgTitle(String msgTitle) {
		this.msgTitle = msgTitle;
	}
}
