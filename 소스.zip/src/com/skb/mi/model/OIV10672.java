package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV10672 extends CopyVO {
	private	long	svcMgmtNum;
	private	String	weqpMgmtNum;
	private	String	auditId;
	private	String	auditDtm;
	private	String	weqpUsgClNm;
	private	String	wireEqpLinkOdr;
	private	long	rangeSvcMgmtNum;
	private	String	rangeWeqpMgmtNum;

	public long getSvcMgmtNum() {
		return svcMgmtNum;
	}
	public void setSvcMgmtNum(long svcMgmtNum) {
		this.svcMgmtNum = svcMgmtNum;
	}
	public String getWeqpMgmtNum() {
		return weqpMgmtNum;
	}
	public void setWeqpMgmtNum(String weqpMgmtNum) {
		this.weqpMgmtNum = weqpMgmtNum;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getWeqpUsgClNm() {
		return weqpUsgClNm;
	}
	public void setWeqpUsgClNm(String weqpUsgClNm) {
		this.weqpUsgClNm = weqpUsgClNm;
	}
	public String getWireEqpLinkOdr() {
		return wireEqpLinkOdr;
	}
	public void setWireEqpLinkOdr(String wireEqpLinkOdr) {
		this.wireEqpLinkOdr = wireEqpLinkOdr;
	}
	public long getRangeSvcMgmtNum() {
		return rangeSvcMgmtNum;
	}
	public void setRangeSvcMgmtNum(long rangeSvcMgmtNum) {
		this.rangeSvcMgmtNum = rangeSvcMgmtNum;
	}
	public String getRangeWeqpMgmtNum() {
		return rangeWeqpMgmtNum;
	}
	public void setRangeWeqpMgmtNum(String rangeWeqpMgmtNum) {
		this.rangeWeqpMgmtNum = rangeWeqpMgmtNum;
	}
	@Override
	public void setKey() {
		this.key = "" + this.svcMgmtNum + "|" + this.weqpMgmtNum;
	}
	@Override
	public boolean equals(CopyVO obj) {
		OIV10672 dest = (OIV10672) obj;
		if (this.svcMgmtNum != dest.svcMgmtNum) return false;
		if (false == StringUtils.equals(this.weqpMgmtNum, dest.weqpMgmtNum)) return false;
		if (false == StringUtils.equals(this.weqpUsgClNm, dest.weqpUsgClNm)) return false;
		if (false == StringUtils.equals(this.wireEqpLinkOdr, dest.wireEqpLinkOdr)) return false;
		return true;
	}
	@Override
	public void setRange(CopyVO obj) {
		OIV10672 src = (OIV10672) obj;
		this.rangeSvcMgmtNum = src.svcMgmtNum;
		this.rangeWeqpMgmtNum = src.weqpMgmtNum;
	}
}
