package com.skb.mi.model;

public class ONM10101 {
	private	long	netOperEquipSerNum;
	private	String	netOpNum;
	private	String	auditId;
	private	String	auditDtm;
	private	String	equipId;
	private	String	ccellId;
	private	String	rackNum;
	private	String	shlfNum;
	private	String	scardNumCtt;
	private	String	dmgLineCnt;
	private	String	v52IfId;
	private	String	wireMediaClCd;
	private	String	dablNetClCd;
	private	String	nmsAlmNum;
	private	String	almSerNum;
	private	String	routNum;
	private	String	portNum;
	private	String	scrbrScardNum;
	private	String	ccellNum;
	private String  infoCntrTpoCd;
	private String  equipSetTpoCd;
	private String  ccellInfo;
	private String  ccellCnt;
	
	public String getCcellNum() {
		return ccellNum;
	}
	public void setCcellNum(String ccellNum) {
		this.ccellNum = ccellNum;
	}
	public String getScrbrScardNum() {
		return scrbrScardNum;
	}
	public void setScrbrScardNum(String scrbrScardNum) {
		this.scrbrScardNum = scrbrScardNum;
	}
	public long getNetOperEquipSerNum() {
		return netOperEquipSerNum;
	}
	public void setNetOperEquipSerNum(long netOperEquipSerNum) {
		this.netOperEquipSerNum = netOperEquipSerNum;
	}
	public String getNetOpNum() {
		return netOpNum;
	}
	public void setNetOpNum(String netOpNum) {
		this.netOpNum = netOpNum;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getEquipId() {
		return equipId;
	}
	public void setEquipId(String equipId) {
		this.equipId = equipId;
	}
	public String getCcellId() {
		return ccellId;
	}
	public void setCcellId(String ccellId) {
		this.ccellId = ccellId;
	}
	public String getRackNum() {
		return rackNum;
	}
	public void setRackNum(String rackNum) {
		this.rackNum = rackNum;
	}
	public String getShlfNum() {
		return shlfNum;
	}
	public void setShlfNum(String shlfNum) {
		this.shlfNum = shlfNum;
	}
	public String getScardNumCtt() {
		return scardNumCtt;
	}
	public void setScardNumCtt(String scardNumCtt) {
		this.scardNumCtt = scardNumCtt;
	}
	public String getDmgLineCnt() {
		return dmgLineCnt;
	}
	public void setDmgLineCnt(String dmgLineCnt) {
		this.dmgLineCnt = dmgLineCnt;
	}
	public String getV52IfId() {
		return v52IfId;
	}
	public void setV52IfId(String v52IfId) {
		this.v52IfId = v52IfId;
	}
	public String getWireMediaClCd() {
		return wireMediaClCd;
	}
	public void setWireMediaClCd(String wireMediaClCd) {
		this.wireMediaClCd = wireMediaClCd;
	}
	public String getDablNetClCd() {
		return dablNetClCd;
	}
	public void setDablNetClCd(String dablNetClCd) {
		this.dablNetClCd = dablNetClCd;
	}
	public String getNmsAlmNum() {
		return nmsAlmNum;
	}
	public void setNmsAlmNum(String nmsAlmNum) {
		this.nmsAlmNum = nmsAlmNum;
	}
	public String getAlmSerNum() {
		return almSerNum;
	}
	public void setAlmSerNum(String almSerNum) {
		this.almSerNum = almSerNum;
	}
	public String getRoutNum() {
		return routNum;
	}
	public void setRoutNum(String routNum) {
		this.routNum = routNum;
	}
	public String getPortNum() {
		return portNum;
	}
	public void setPortNum(String portNum) {
		this.portNum = portNum;
	}
	public String getInfoCntrTpoCd() {
		return infoCntrTpoCd;
	}
	public void setInfoCntrTpoCd(String infoCntrTpoCd) {
		this.infoCntrTpoCd = infoCntrTpoCd;
	}
	public String getEquipSetTpoCd() {
		return equipSetTpoCd;
	}
	public void setEquipSetTpoCd(String equipSetTpoCd) {
		this.equipSetTpoCd = equipSetTpoCd;
	}
	public String getCcellInfo() {
		return ccellInfo;
	}
	public void setCcellInfo(String ccellInfo) {
		this.ccellInfo = ccellInfo;
	}
	public String getCcellCnt() {
		return ccellCnt;
	}
	public void setCcellCnt(String ccellCnt) {
		this.ccellCnt = ccellCnt;
	}
	
	
}
