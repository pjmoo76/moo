package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OMN73141 extends AggrDataVO {
	private	String	mntrDthr;
	private	String	apMacAddr;
	private String	auditId;
	private	String	netClCd;
	private	String	infoCntrCd;
	private	String	distbCntrCd;
	private	String	homeCntrCd;
	private	String	l3EquipId;
	private	String	l2EquipId;
	private	String	ccellNum;
	private	String	eqpMdlCd;
	private	long	inetSvcMgmtNum;
	private	int	wifi2p4gChnlUseVal;
	private	int	wifi5gChnlUseVal;
	private	int	wifi2p4gGoodGrCpeCnt;
	private	int	wifi2p4gNormGrCpeCnt;
	private	int	wifi2p4gBadGrCpeCnt;
	private	int	wifi5gGoodGrCpeCnt;
	private	int	wifi5gNormGrCpeCnt;
	private	int	wifi5gBadGrCpeCnt;
	private	int	wifi2p4gRssiMaxVal;
	private	int	wifi5gRssiMaxVal;
	private	long	wanTrfcTxVal;
	private	long	wanTrfcRxVal;
	private	long	lanTrfcTxVal;
	private	long	lanTrfcRxVal;
	private	long	wifi2p4gTrfcTxVal;
	private	long	wifi2p4gTrfcRxVal;
	private	long	wifi5gTrfcTxVal;
	private	long	wifi5gTrfcRxVal;
	private	long	wifi5gIptvTrfcTxVal;
	private	long	wifi5gIptvTrfcRxVal;
	private	String	eqpVerInfo;
	private	int		wifi2p4gRssiBadCnt;
	private	int		wifi5gRssiBadCnt;
	private	int		clctCnt;

	public String getMntrDthr() {
		return mntrDthr;
	}
	public void setMntrDthr(String mntrDthr) {
		this.mntrDthr = mntrDthr;
	}
	public String getApMacAddr() {
		return apMacAddr;
	}
	public void setApMacAddr(String apMacAddr) {
		this.apMacAddr = apMacAddr;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getNetClCd() {
		return netClCd;
	}
	public void setNetClCd(String netClCd) {
		this.netClCd = netClCd;
	}
	public String getInfoCntrCd() {
		return infoCntrCd;
	}
	public void setInfoCntrCd(String infoCntrCd) {
		this.infoCntrCd = infoCntrCd;
	}
	public String getDistbCntrCd() {
		return distbCntrCd;
	}
	public void setDistbCntrCd(String distbCntrCd) {
		this.distbCntrCd = distbCntrCd;
	}
	public String getHomeCntrCd() {
		return homeCntrCd;
	}
	public void setHomeCntrCd(String homeCntrCd) {
		this.homeCntrCd = homeCntrCd;
	}
	public String getL3EquipId() {
		return l3EquipId;
	}
	public void setL3EquipId(String l3EquipId) {
		this.l3EquipId = l3EquipId;
	}
	public String getL2EquipId() {
		return l2EquipId;
	}
	public void setL2EquipId(String l2EquipId) {
		this.l2EquipId = l2EquipId;
	}
	public String getCcellNum() {
		return ccellNum;
	}
	public void setCcellNum(String ccellNum) {
		this.ccellNum = ccellNum;
	}
	public String getEqpMdlCd() {
		return eqpMdlCd;
	}
	public void setEqpMdlCd(String eqpMdlCd) {
		this.eqpMdlCd = eqpMdlCd;
	}
	public long getInetSvcMgmtNum() {
		return inetSvcMgmtNum;
	}
	public void setInetSvcMgmtNum(long inetSvcMgmtNum) {
		this.inetSvcMgmtNum = inetSvcMgmtNum;
	}
	public int getWifi2p4gChnlUseVal() {
		return wifi2p4gChnlUseVal;
	}
	public void setWifi2p4gChnlUseVal(int wifi2p4gChnlUseVal) {
		this.wifi2p4gChnlUseVal = wifi2p4gChnlUseVal;
	}
	public int getWifi5gChnlUseVal() {
		return wifi5gChnlUseVal;
	}
	public void setWifi5gChnlUseVal(int wifi5gChnlUseVal) {
		this.wifi5gChnlUseVal = wifi5gChnlUseVal;
	}
	public int getWifi2p4gGoodGrCpeCnt() {
		return wifi2p4gGoodGrCpeCnt;
	}
	public void setWifi2p4gGoodGrCpeCnt(int wifi2p4gGoodGrCpeCnt) {
		this.wifi2p4gGoodGrCpeCnt = wifi2p4gGoodGrCpeCnt;
	}
	public int getWifi2p4gNormGrCpeCnt() {
		return wifi2p4gNormGrCpeCnt;
	}
	public void setWifi2p4gNormGrCpeCnt(int wifi2p4gNormGrCpeCnt) {
		this.wifi2p4gNormGrCpeCnt = wifi2p4gNormGrCpeCnt;
	}
	public int getWifi2p4gBadGrCpeCnt() {
		return wifi2p4gBadGrCpeCnt;
	}
	public void setWifi2p4gBadGrCpeCnt(int wifi2p4gBadGrCpeCnt) {
		this.wifi2p4gBadGrCpeCnt = wifi2p4gBadGrCpeCnt;
	}
	public int getWifi5gGoodGrCpeCnt() {
		return wifi5gGoodGrCpeCnt;
	}
	public void setWifi5gGoodGrCpeCnt(int wifi5gGoodGrCpeCnt) {
		this.wifi5gGoodGrCpeCnt = wifi5gGoodGrCpeCnt;
	}
	public int getWifi5gNormGrCpeCnt() {
		return wifi5gNormGrCpeCnt;
	}
	public void setWifi5gNormGrCpeCnt(int wifi5gNormGrCpeCnt) {
		this.wifi5gNormGrCpeCnt = wifi5gNormGrCpeCnt;
	}
	public int getWifi5gBadGrCpeCnt() {
		return wifi5gBadGrCpeCnt;
	}
	public void setWifi5gBadGrCpeCnt(int wifi5gBadGrCpeCnt) {
		this.wifi5gBadGrCpeCnt = wifi5gBadGrCpeCnt;
	}
	public int getWifi2p4gRssiMaxVal() {
		return wifi2p4gRssiMaxVal;
	}
	public void setWifi2p4gRssiMaxVal(int wifi2p4gRssiMaxVal) {
		this.wifi2p4gRssiMaxVal = wifi2p4gRssiMaxVal;
	}
	public int getWifi5gRssiMaxVal() {
		return wifi5gRssiMaxVal;
	}
	public void setWifi5gRssiMaxVal(int wifi5gRssiMaxVal) {
		this.wifi5gRssiMaxVal = wifi5gRssiMaxVal;
	}
	public long getWanTrfcTxVal() {
		return wanTrfcTxVal;
	}
	public void setWanTrfcTxVal(long wanTrfcTxVal) {
		this.wanTrfcTxVal = wanTrfcTxVal;
	}
	public long getWanTrfcRxVal() {
		return wanTrfcRxVal;
	}
	public void setWanTrfcRxVal(long wanTrfcRxVal) {
		this.wanTrfcRxVal = wanTrfcRxVal;
	}
	public long getLanTrfcTxVal() {
		return lanTrfcTxVal;
	}
	public void setLanTrfcTxVal(long lanTrfcTxVal) {
		this.lanTrfcTxVal = lanTrfcTxVal;
	}
	public long getLanTrfcRxVal() {
		return lanTrfcRxVal;
	}
	public void setLanTrfcRxVal(long lanTrfcRxVal) {
		this.lanTrfcRxVal = lanTrfcRxVal;
	}
	public long getWifi2p4gTrfcTxVal() {
		return wifi2p4gTrfcTxVal;
	}
	public void setWifi2p4gTrfcTxVal(long wifi2p4gTrfcTxVal) {
		this.wifi2p4gTrfcTxVal = wifi2p4gTrfcTxVal;
	}
	public long getWifi2p4gTrfcRxVal() {
		return wifi2p4gTrfcRxVal;
	}
	public void setWifi2p4gTrfcRxVal(long wifi2p4gTrfcRxVal) {
		this.wifi2p4gTrfcRxVal = wifi2p4gTrfcRxVal;
	}
	public long getWifi5gTrfcTxVal() {
		return wifi5gTrfcTxVal;
	}
	public void setWifi5gTrfcTxVal(long wifi5gTrfcTxVal) {
		this.wifi5gTrfcTxVal = wifi5gTrfcTxVal;
	}
	public long getWifi5gTrfcRxVal() {
		return wifi5gTrfcRxVal;
	}
	public void setWifi5gTrfcRxVal(long wifi5gTrfcRxVal) {
		this.wifi5gTrfcRxVal = wifi5gTrfcRxVal;
	}
	public long getWifi5gIptvTrfcTxVal() {
		return wifi5gIptvTrfcTxVal;
	}
	public void setWifi5gIptvTrfcTxVal(long wifi5gIptvTrfcTxVal) {
		this.wifi5gIptvTrfcTxVal = wifi5gIptvTrfcTxVal;
	}
	public long getWifi5gIptvTrfcRxVal() {
		return wifi5gIptvTrfcRxVal;
	}
	public void setWifi5gIptvTrfcRxVal(long wifi5gIptvTrfcRxVal) {
		this.wifi5gIptvTrfcRxVal = wifi5gIptvTrfcRxVal;
	}
	public String getEqpVerInfo() {
		return eqpVerInfo;
	}
	public void setEqpVerInfo(String eqpVerInfo) {
		this.eqpVerInfo = eqpVerInfo;
	}
	public int getWifi2p4gRssiBadCnt() {
		return wifi2p4gRssiBadCnt;
	}
	public void setWifi2p4gRssiBadCnt(int wifi2p4gRssiBadCnt) {
		this.wifi2p4gRssiBadCnt = wifi2p4gRssiBadCnt;
	}
	public int getWifi5gRssiBadCnt() {
		return wifi5gRssiBadCnt;
	}
	public void setWifi5gRssiBadCnt(int wifi5gRssiBadCnt) {
		this.wifi5gRssiBadCnt = wifi5gRssiBadCnt;
	}
	public int getClctCnt() {
		return clctCnt;
	}
	public void setClctCnt(int clctCnt) {
		this.clctCnt = clctCnt;
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("(mntrDthr=%s)\n", mntrDthr));
		sb.append(String.format("(apMacAddr=%s)\n", apMacAddr));
		sb.append(String.format("(auditId=%s)\n", auditId));
		sb.append(String.format("(netClCd=%s)\n", netClCd));
		sb.append(String.format("(infoCntrCd=%s)\n", infoCntrCd));
		sb.append(String.format("(distbCntrCd=%s)\n", distbCntrCd));
		sb.append(String.format("(homeCntrCd=%s)\n", homeCntrCd));
		sb.append(String.format("(l3EquipId=%s)\n", l3EquipId));
		sb.append(String.format("(l2EquipId=%s)\n", l2EquipId));
		sb.append(String.format("(ccellNum=%s)\n", ccellNum));
		sb.append(String.format("(eqpMdlCd=%s)\n", eqpMdlCd));
		sb.append(String.format("(inetSvcMgmtNum=%d)\n", inetSvcMgmtNum));
		sb.append(String.format("(wifi2p4gChnlUseVal=%d)\n", wifi2p4gChnlUseVal));
		sb.append(String.format("(wifi5gChnlUseVal=%d)\n", wifi5gChnlUseVal));
		sb.append(String.format("(wifi2p4gGoodGrCpeCnt=%d)\n", wifi2p4gGoodGrCpeCnt));
		sb.append(String.format("(wifi2p4gNormGrCpeCnt=%d)\n", wifi2p4gNormGrCpeCnt));
		sb.append(String.format("(wifi2p4gBadGrCpeCnt=%d)\n", wifi2p4gBadGrCpeCnt));
		sb.append(String.format("(wifi5gGoodGrCpeCnt=%d)\n", wifi5gGoodGrCpeCnt));
		sb.append(String.format("(wifi5gNormGrCpeCnt=%d)\n", wifi5gNormGrCpeCnt));
		sb.append(String.format("(wifi5gBadGrCpeCnt=%d)\n", wifi5gBadGrCpeCnt));
		sb.append(String.format("(wifi2p4gRssiMaxVal=%d)\n", wifi2p4gRssiMaxVal));
		sb.append(String.format("(wifi5gRssiMaxVal=%d)\n", wifi5gRssiMaxVal));
		sb.append(String.format("(wanTrfcTxVal=%d)\n", wanTrfcTxVal));
		sb.append(String.format("(wanTrfcRxVal=%d)\n", wanTrfcRxVal));
		sb.append(String.format("(lanTrfcTxVal=%d)\n", lanTrfcTxVal));
		sb.append(String.format("(lanTrfcRxVal=%d)\n", lanTrfcRxVal));
		sb.append(String.format("(wifi2p4gTrfcTxVal=%d)\n", wifi2p4gTrfcTxVal));
		sb.append(String.format("(wifi2p4gTrfcRxVal=%d)\n", wifi2p4gTrfcRxVal));
		sb.append(String.format("(wifi5gTrfcTxVal=%d)\n", wifi5gTrfcTxVal));
		sb.append(String.format("(wifi5gTrfcRxVal=%d)\n", wifi5gTrfcRxVal));
		sb.append(String.format("(wifi5gIptvTrfcTxVal=%d)\n", wifi5gIptvTrfcTxVal));
		sb.append(String.format("(wifi5gIptvTrfcRxVal=%d)\n", wifi5gIptvTrfcRxVal));
		sb.append(String.format("(eqpVerInfo=%s\n)", eqpVerInfo));
		sb.append(String.format("(wifi2p4gRssiBadCnt=%d)\n", wifi2p4gRssiBadCnt));
		sb.append(String.format("(wifi5gRssiBadCnt=%d)\n", wifi5gRssiBadCnt));
		sb.append(String.format("(clctCnt=%d)", clctCnt));
		return sb.toString();
	}
	
	@Override
	public boolean isValid() {
		if (this.apMacAddr == null || this.apMacAddr.isEmpty() || this.apMacAddr.length() > 15) {
			return false;
		}
		if (this.lanTrfcTxVal > 9999999999999L) {
			return false;
		}
		if (this.lanTrfcRxVal > 9999999999999L) {
			return false;
		}
		if (this.wanTrfcTxVal > 9999999999999L) {
			return false;
		}
		if (this.wanTrfcRxVal > 9999999999999L) {
			return false;
		}
		if (this.wifi2p4gTrfcTxVal > 9999999999999L) {
			return false;
		}
		if (this.wifi2p4gTrfcRxVal > 9999999999999L) {
			return false;
		}
		if (this.wifi5gTrfcTxVal > 9999999999999L) {
			return false;
		}
		if (this.wifi5gTrfcRxVal > 9999999999999L) {
			return false;
		}
		if (this.wifi5gIptvTrfcTxVal > 9999999999999L) {
			return false;
		}
		if (this.wifi5gIptvTrfcRxVal > 9999999999999L) {
			return false;
		}
		return true;
	}

	public void resetInvalidData() {
		if (this.lanTrfcTxVal > 9999999999999L || this.lanTrfcTxVal < 0) {
			this.lanTrfcTxVal = 0;
		}
		if (this.lanTrfcRxVal > 9999999999999L || this.lanTrfcRxVal < 0) {
			this.lanTrfcRxVal = 0;
		}
		if (this.wanTrfcTxVal > 9999999999999L || this.wanTrfcTxVal < 0) {
			this.wanTrfcTxVal = 0;
		}
		if (this.wanTrfcRxVal > 9999999999999L || this.wanTrfcRxVal < 0) {
			this.wanTrfcRxVal = 0;
		}
		if (this.wifi2p4gTrfcTxVal > 9999999999999L || this.wifi2p4gTrfcTxVal < 0) {
			this.wifi2p4gTrfcTxVal = 0;
		}
		if (this.wifi2p4gTrfcRxVal > 9999999999999L || this.wifi2p4gTrfcRxVal < 0) {
			this.wifi2p4gTrfcRxVal = 0;
		}
		if (this.wifi5gTrfcTxVal > 9999999999999L || this.wifi5gTrfcTxVal < 0) {
			this.wifi5gTrfcTxVal = 0;
		}
		if (this.wifi5gTrfcRxVal > 9999999999999L || this.wifi5gTrfcRxVal < 0) {
			this.wifi5gTrfcRxVal = 0;
		}
		if (this.wifi5gIptvTrfcTxVal > 9999999999999L || this.wifi5gIptvTrfcTxVal < 0) {
			this.wifi5gIptvTrfcTxVal = 0;
		}
		if (this.wifi5gIptvTrfcRxVal > 9999999999999L || this.wifi5gIptvTrfcRxVal < 0) {
			this.wifi5gIptvTrfcRxVal = 0;
		}
		if (this.wifi2p4gChnlUseVal > 255) {
			this.wifi2p4gChnlUseVal = 0;
		}
		if (this.wifi5gChnlUseVal > 255) {
			this.wifi5gChnlUseVal = 0;
		}
	}
	
	@Override
	public String toDelimiterString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("%s|", mntrDthr));
		sb.append(String.format("%s|", apMacAddr));
		sb.append(String.format("%s|", auditId));
		sb.append(String.format("%s|", StringUtils.null2Empty(netClCd)));
		sb.append(String.format("%s|", StringUtils.null2Empty(infoCntrCd)));
		sb.append(String.format("%s|", StringUtils.null2Empty(distbCntrCd)));
		sb.append(String.format("%s|", StringUtils.null2Empty(homeCntrCd)));
		sb.append(String.format("%s|", StringUtils.null2Empty(l3EquipId)));
		sb.append(String.format("%s|", StringUtils.null2Empty(l2EquipId)));
		sb.append(String.format("%s|", StringUtils.null2Empty(ccellNum)));
		sb.append(String.format("%s|", StringUtils.null2Empty(eqpMdlCd)));
		sb.append(String.format("%d|", inetSvcMgmtNum));
		sb.append(String.format("%d|", wifi2p4gChnlUseVal));
		sb.append(String.format("%d|", wifi5gChnlUseVal));
		sb.append(String.format("%d|", wifi2p4gGoodGrCpeCnt));
		sb.append(String.format("%d|", wifi2p4gNormGrCpeCnt));
		sb.append(String.format("%d|", wifi2p4gBadGrCpeCnt));
		sb.append(String.format("%d|", wifi5gGoodGrCpeCnt));
		sb.append(String.format("%d|", wifi5gNormGrCpeCnt));
		sb.append(String.format("%d|", wifi5gBadGrCpeCnt));
		sb.append(String.format("%d|", wifi2p4gRssiMaxVal));
		sb.append(String.format("%d|", wifi5gRssiMaxVal));
		sb.append(String.format("%d|", wanTrfcTxVal));
		sb.append(String.format("%d|", wanTrfcRxVal));
		sb.append(String.format("%d|", lanTrfcTxVal));
		sb.append(String.format("%d|", lanTrfcRxVal));
		sb.append(String.format("%d|", wifi2p4gTrfcTxVal));
		sb.append(String.format("%d|", wifi2p4gTrfcRxVal));
		sb.append(String.format("%d|", wifi5gTrfcTxVal));
		sb.append(String.format("%d|", wifi5gTrfcRxVal));
		sb.append(String.format("%d|", wifi5gIptvTrfcTxVal));
		sb.append(String.format("%d|", wifi5gIptvTrfcRxVal));
		sb.append(String.format("%s|", StringUtils.null2Empty(eqpVerInfo)));
		sb.append(String.format("%d|", wifi2p4gRssiBadCnt));
		sb.append(String.format("%d|", wifi5gRssiBadCnt));
		sb.append(String.format("%d", clctCnt));
		return sb.toString();
	}
	@Override
	public void add(AggrDataVO obj) {
		OMN73141 addObj = (OMN73141) obj;
		this.wanTrfcTxVal += addObj.wanTrfcTxVal;
		this.wanTrfcRxVal += addObj.wanTrfcRxVal;
		this.lanTrfcTxVal += addObj.lanTrfcTxVal;
		this.lanTrfcRxVal += addObj.lanTrfcRxVal;
		this.wifi2p4gTrfcTxVal += addObj.wifi2p4gTrfcTxVal;
		this.wifi2p4gTrfcRxVal += addObj.wifi2p4gTrfcRxVal;
		this.wifi5gTrfcTxVal += addObj.wifi5gTrfcTxVal;
		this.wifi5gTrfcRxVal += addObj.wifi5gTrfcRxVal;
		this.wifi5gIptvTrfcTxVal += addObj.wifi5gIptvTrfcTxVal;
		this.wifi5gIptvTrfcRxVal += addObj.wifi5gIptvTrfcRxVal;
		
		int oldCpeCnt = this.wifi2p4gGoodGrCpeCnt + this.wifi2p4gNormGrCpeCnt + this.wifi2p4gBadGrCpeCnt + this.wifi5gGoodGrCpeCnt + this.wifi5gNormGrCpeCnt + this.wifi5gBadGrCpeCnt;
		int newCpeCnt = addObj.wifi2p4gGoodGrCpeCnt + addObj.wifi2p4gNormGrCpeCnt + addObj.wifi2p4gBadGrCpeCnt + addObj.wifi5gGoodGrCpeCnt + addObj.wifi5gNormGrCpeCnt + addObj.wifi5gBadGrCpeCnt;

		if (oldCpeCnt < newCpeCnt) {
			this.wifi2p4gChnlUseVal = addObj.wifi2p4gChnlUseVal;
			this.wifi5gChnlUseVal = addObj.wifi5gChnlUseVal;
			this.wifi2p4gGoodGrCpeCnt = addObj.wifi2p4gGoodGrCpeCnt;
			this.wifi2p4gNormGrCpeCnt = addObj.wifi2p4gNormGrCpeCnt;
			this.wifi2p4gBadGrCpeCnt = addObj.wifi2p4gBadGrCpeCnt;
			this.wifi5gGoodGrCpeCnt = addObj.wifi5gGoodGrCpeCnt;
			this.wifi5gNormGrCpeCnt = addObj.wifi5gNormGrCpeCnt;
			this.wifi5gBadGrCpeCnt = addObj.wifi5gBadGrCpeCnt;
		}
		if (this.wifi2p4gRssiMaxVal > addObj.wifi2p4gRssiMaxVal) {
			this.wifi2p4gRssiMaxVal = addObj.wifi2p4gRssiMaxVal;
		}
		if (this.wifi5gRssiMaxVal > addObj.wifi5gRssiMaxVal) {
			this.wifi5gRssiMaxVal = addObj.wifi5gRssiMaxVal;
		}
		this.wifi2p4gRssiBadCnt += addObj.wifi2p4gRssiBadCnt;
		this.wifi5gRssiBadCnt += addObj.wifi5gRssiBadCnt;
		
		if (this.wifi2p4gChnlUseVal < addObj.wifi2p4gChnlUseVal) {
			this.wifi2p4gChnlUseVal = addObj.wifi2p4gChnlUseVal;
		}
		if (this.wifi5gChnlUseVal < addObj.wifi5gChnlUseVal) {
			this.wifi5gChnlUseVal = addObj.wifi5gChnlUseVal;
		}
		
		this.clctCnt += addObj.clctCnt;
	}
}
