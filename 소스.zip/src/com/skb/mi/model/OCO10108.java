package com.skb.mi.model;

public class OCO10108 {
	private	String	swingUserId;
	private	String	auditId;
	private	String	auditDtm;
	private	String	userNm;
	private	String	swingLoginId;
	private	String	postOrgId;
	private	String	aplyStaDt;
	private	String	aplyEndDt;
	private	String	mblPhonNum;
	
	public String getSwingUserId() {
		return swingUserId;
	}
	public void setSwingUserId(String swingUserId) {
		this.swingUserId = swingUserId;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	public String getSwingLoginId() {
		return swingLoginId;
	}
	public void setSwingLoginId(String swingLoginId) {
		this.swingLoginId = swingLoginId;
	}
	public String getPostOrgId() {
		return postOrgId;
	}
	public void setPostOrgId(String postOrgId) {
		this.postOrgId = postOrgId;
	}
	public String getAplyStaDt() {
		return aplyStaDt;
	}
	public void setAplyStaDt(String aplyStaDt) {
		this.aplyStaDt = aplyStaDt;
	}
	public String getAplyEndDt() {
		return aplyEndDt;
	}
	public void setAplyEndDt(String aplyEndDt) {
		this.aplyEndDt = aplyEndDt;
	}
	public String getMblPhonNum() {
		return mblPhonNum;
	}
	public void setMblPhonNum(String mblPhonNum) {
		this.mblPhonNum = mblPhonNum;
	}
	
}
