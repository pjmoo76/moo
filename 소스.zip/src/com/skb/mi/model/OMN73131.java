package com.skb.mi.model;

public class OMN73131 {
	private	String	mntrDt;
	private	String	apMacAddr;
	private	String	auditId;
	private	String	netClCd;
	private	String	infoCntrCd;
	private	String	distbCntrCd;
	private	String	homeCntrCd;
	private	String	l3EquipId;
	private	String	l2EquipId;
	private	String	ccellNum;
	private	String	eqpMdlCd;
	private	long	inetSvcMgmtNum;
	private	String	wifiHndovrRsltVal;
	private	int	wifi2p4gChnlUseVal;
	private	int	wifi5gChnlUseVal;
	private	int	outsWifi2p4gGoodGrCnt;
	private	int	outsWifi2p4gNormGrCnt;
	private	int	outsWifi2p4gBadGrCnt;
	private	int	outsWifi5gGoodGrCnt;
	private	int	outsWifi5gNormGrCnt;
	private	int	outsWifi5gBadGrCnt;
	private	int	wlessEnvQltyScor;
	private	int	wanLinkFlapCnt;
	private	int	lan1LinkFlapCnt;
	private	int	lan2LinkFlapCnt;
	private	int	lan3LinkFlapCnt;
	private	int	lan4LinkFlapCnt;
	private	long	wanCrcOccrCnt;
	private	long	lan1CrcOccrCnt;
	private	long	lan2CrcOccrCnt;
	private	long	lan3CrcOccrCnt;
	private	long	lan4CrcOccrCnt;
	private	int	wanLpOccrCnt;
	private	int	lan1LpOccrCnt;
	private	int	lan2LpOccrCnt;
	private	int	lan3LpOccrCnt;
	private	int	lan4LpOccrCnt;
	private	String	wanPortDplxSetCd;
	private	String	lan1PortDplxSetCd;
	private	String	lan2PortDplxSetCd;
	private	String	lan3PortDplxSetCd;
	private	String	lan4PortDplxSetCd;
	private	String	wanBandwStVal;
	private	double	wanTrfcUseRt;
	private	int	wireEnvQltyScor;
	private	double	wifi2p4gRssiBadKeepTmsRt;
	private	double	wifi5gRssiBadKeepTmsRt;
	private	int	wifi2p4gNormGrCpeCnt;
	private	int	wifi2p4gBadGrCpeCnt;
	private	int	wifi5gNormGrCpeCnt;
	private	int	wifi5gBadGrCpeCnt;
	private	int	cpeQltyScor;
	private	int	ovrlQltyScor;
	private	int	vocCnt;
	private	int	wifi2p4gGoodGrCpeCnt;
	private	int	wifi5gGoodGrCpeCnt;
	private	int	wifiHndovrOccrCnt;
	private	String	rssiBadYn;
	private	String	wanTrfcOvrYn;
	private	int	sesnOvrOccrCnt;
	private	int	wifi2p4gRssiMaxVal;
	private	int	wifi5gRssiMaxVal;
	private	int	wifi2p4gRssiBadCnt;
	private	int	wifi5gRssiBadCnt;
	private	int	clctCnt;
	private	String	recntCrcOccrDtm;
	private	long	wanTrfcTxVal;
	private	long	wanTrfcRxVal;
	private	long	lanTrfcTxVal;
	private	long	lanTrfcRxVal;
	private	long	wifi2p4gTrfcTxVal;
	private	long	wifi2p4gTrfcRxVal;
	private	long	wifi5gTrfcTxVal;
	private	long	wifi5gTrfcRxVal;
	private	long	wifi5gIptvTrfcTxVal;
	private	long	wifi5gIptvTrfcRxVal;
	private	String	eqpVerInfo;
	private	int	wifi2p4gRssiBadKeepDtCnt;
	private	int	wifi5gRssiBadKeepDayCnt;
	private	int	outsWifi2p4gRssiMaxVal;
	private	int	outsWifi5gRssiMaxVal;
	private	int	d7VocCnt;
	private	int	d30VocCnt;
	private	int	d90VocCnt;
	private	int	wanLinkFlapKeepDayCnt;
	private	int	lanLinkFlapKeepDayCnt;
	private	int	wanCrcOccrKeepDayCnt;
	private	int	lanCrcOccrKeepDayCnt;
	
	public String getMntrDt() {
		return mntrDt;
	}
	public void setMntrDt(String mntrDt) {
		this.mntrDt = mntrDt;
	}
	public String getApMacAddr() {
		return apMacAddr;
	}
	public void setApMacAddr(String apMacAddr) {
		this.apMacAddr = apMacAddr;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getNetClCd() {
		return netClCd;
	}
	public void setNetClCd(String netClCd) {
		this.netClCd = netClCd;
	}
	public String getInfoCntrCd() {
		return infoCntrCd;
	}
	public void setInfoCntrCd(String infoCntrCd) {
		this.infoCntrCd = infoCntrCd;
	}
	public String getDistbCntrCd() {
		return distbCntrCd;
	}
	public void setDistbCntrCd(String distbCntrCd) {
		this.distbCntrCd = distbCntrCd;
	}
	public String getHomeCntrCd() {
		return homeCntrCd;
	}
	public void setHomeCntrCd(String homeCntrCd) {
		this.homeCntrCd = homeCntrCd;
	}
	public String getL3EquipId() {
		return l3EquipId;
	}
	public void setL3EquipId(String l3EquipId) {
		this.l3EquipId = l3EquipId;
	}
	public String getL2EquipId() {
		return l2EquipId;
	}
	public void setL2EquipId(String l2EquipId) {
		this.l2EquipId = l2EquipId;
	}
	public String getCcellNum() {
		return ccellNum;
	}
	public void setCcellNum(String ccellNum) {
		this.ccellNum = ccellNum;
	}
	public String getEqpMdlCd() {
		return eqpMdlCd;
	}
	public void setEqpMdlCd(String eqpMdlCd) {
		this.eqpMdlCd = eqpMdlCd;
	}
	public long getInetSvcMgmtNum() {
		return inetSvcMgmtNum;
	}
	public void setInetSvcMgmtNum(long inetSvcMgmtNum) {
		this.inetSvcMgmtNum = inetSvcMgmtNum;
	}
	public String getWifiHndovrRsltVal() {
		return wifiHndovrRsltVal;
	}
	public void setWifiHndovrRsltVal(String wifiHndovrRsltVal) {
		this.wifiHndovrRsltVal = wifiHndovrRsltVal;
	}
	public int getWifi2p4gChnlUseVal() {
		return wifi2p4gChnlUseVal;
	}
	public void setWifi2p4gChnlUseVal(int wifi2p4gChnlUseVal) {
		this.wifi2p4gChnlUseVal = wifi2p4gChnlUseVal;
	}
	public int getWifi5gChnlUseVal() {
		return wifi5gChnlUseVal;
	}
	public void setWifi5gChnlUseVal(int wifi5gChnlUseVal) {
		this.wifi5gChnlUseVal = wifi5gChnlUseVal;
	}
	public int getOutsWifi2p4gGoodGrCnt() {
		return outsWifi2p4gGoodGrCnt;
	}
	public void setOutsWifi2p4gGoodGrCnt(int outsWifi2p4gGoodGrCnt) {
		this.outsWifi2p4gGoodGrCnt = outsWifi2p4gGoodGrCnt;
	}
	public int getOutsWifi2p4gNormGrCnt() {
		return outsWifi2p4gNormGrCnt;
	}
	public void setOutsWifi2p4gNormGrCnt(int outsWifi2p4gNormGrCnt) {
		this.outsWifi2p4gNormGrCnt = outsWifi2p4gNormGrCnt;
	}
	public int getOutsWifi2p4gBadGrCnt() {
		return outsWifi2p4gBadGrCnt;
	}
	public void setOutsWifi2p4gBadGrCnt(int outsWifi2p4gBadGrCnt) {
		this.outsWifi2p4gBadGrCnt = outsWifi2p4gBadGrCnt;
	}
	public int getOutsWifi5gGoodGrCnt() {
		return outsWifi5gGoodGrCnt;
	}
	public void setOutsWifi5gGoodGrCnt(int outsWifi5gGoodGrCnt) {
		this.outsWifi5gGoodGrCnt = outsWifi5gGoodGrCnt;
	}
	public int getOutsWifi5gNormGrCnt() {
		return outsWifi5gNormGrCnt;
	}
	public void setOutsWifi5gNormGrCnt(int outsWifi5gNormGrCnt) {
		this.outsWifi5gNormGrCnt = outsWifi5gNormGrCnt;
	}
	public int getOutsWifi5gBadGrCnt() {
		return outsWifi5gBadGrCnt;
	}
	public void setOutsWifi5gBadGrCnt(int outsWifi5gBadGrCnt) {
		this.outsWifi5gBadGrCnt = outsWifi5gBadGrCnt;
	}
	public int getWlessEnvQltyScor() {
		return wlessEnvQltyScor;
	}
	public void setWlessEnvQltyScor(int wlessEnvQltyScor) {
		this.wlessEnvQltyScor = wlessEnvQltyScor;
	}
	public int getWanLinkFlapCnt() {
		return wanLinkFlapCnt;
	}
	public void setWanLinkFlapCnt(int wanLinkFlapCnt) {
		this.wanLinkFlapCnt = wanLinkFlapCnt;
	}
	public int getLan1LinkFlapCnt() {
		return lan1LinkFlapCnt;
	}
	public void setLan1LinkFlapCnt(int lan1LinkFlapCnt) {
		this.lan1LinkFlapCnt = lan1LinkFlapCnt;
	}
	public int getLan2LinkFlapCnt() {
		return lan2LinkFlapCnt;
	}
	public void setLan2LinkFlapCnt(int lan2LinkFlapCnt) {
		this.lan2LinkFlapCnt = lan2LinkFlapCnt;
	}
	public int getLan3LinkFlapCnt() {
		return lan3LinkFlapCnt;
	}
	public void setLan3LinkFlapCnt(int lan3LinkFlapCnt) {
		this.lan3LinkFlapCnt = lan3LinkFlapCnt;
	}
	public int getLan4LinkFlapCnt() {
		return lan4LinkFlapCnt;
	}
	public void setLan4LinkFlapCnt(int lan4LinkFlapCnt) {
		this.lan4LinkFlapCnt = lan4LinkFlapCnt;
	}

	public long getWanCrcOccrCnt() {
		return wanCrcOccrCnt;
	}
	public void setWanCrcOccrCnt(long wanCrcOccrCnt) {
		this.wanCrcOccrCnt = wanCrcOccrCnt;
	}
	public long getLan1CrcOccrCnt() {
		return lan1CrcOccrCnt;
	}
	public void setLan1CrcOccrCnt(long lan1CrcOccrCnt) {
		this.lan1CrcOccrCnt = lan1CrcOccrCnt;
	}
	public long getLan2CrcOccrCnt() {
		return lan2CrcOccrCnt;
	}
	public void setLan2CrcOccrCnt(long lan2CrcOccrCnt) {
		this.lan2CrcOccrCnt = lan2CrcOccrCnt;
	}
	public long getLan3CrcOccrCnt() {
		return lan3CrcOccrCnt;
	}
	public void setLan3CrcOccrCnt(long lan3CrcOccrCnt) {
		this.lan3CrcOccrCnt = lan3CrcOccrCnt;
	}
	public long getLan4CrcOccrCnt() {
		return lan4CrcOccrCnt;
	}
	public void setLan4CrcOccrCnt(long lan4CrcOccrCnt) {
		this.lan4CrcOccrCnt = lan4CrcOccrCnt;
	}
	public int getWanLpOccrCnt() {
		return wanLpOccrCnt;
	}
	public void setWanLpOccrCnt(int wanLpOccrCnt) {
		this.wanLpOccrCnt = wanLpOccrCnt;
	}
	public int getLan1LpOccrCnt() {
		return lan1LpOccrCnt;
	}
	public void setLan1LpOccrCnt(int lan1LpOccrCnt) {
		this.lan1LpOccrCnt = lan1LpOccrCnt;
	}
	public int getLan2LpOccrCnt() {
		return lan2LpOccrCnt;
	}
	public void setLan2LpOccrCnt(int lan2LpOccrCnt) {
		this.lan2LpOccrCnt = lan2LpOccrCnt;
	}
	public int getLan3LpOccrCnt() {
		return lan3LpOccrCnt;
	}
	public void setLan3LpOccrCnt(int lan3LpOccrCnt) {
		this.lan3LpOccrCnt = lan3LpOccrCnt;
	}
	public int getLan4LpOccrCnt() {
		return lan4LpOccrCnt;
	}
	public void setLan4LpOccrCnt(int lan4LpOccrCnt) {
		this.lan4LpOccrCnt = lan4LpOccrCnt;
	}
	public String getWanPortDplxSetCd() {
		return wanPortDplxSetCd;
	}
	public void setWanPortDplxSetCd(String wanPortDplxSetCd) {
		this.wanPortDplxSetCd = wanPortDplxSetCd;
	}
	public String getLan1PortDplxSetCd() {
		return lan1PortDplxSetCd;
	}
	public void setLan1PortDplxSetCd(String lan1PortDplxSetCd) {
		this.lan1PortDplxSetCd = lan1PortDplxSetCd;
	}
	public String getLan2PortDplxSetCd() {
		return lan2PortDplxSetCd;
	}
	public void setLan2PortDplxSetCd(String lan2PortDplxSetCd) {
		this.lan2PortDplxSetCd = lan2PortDplxSetCd;
	}
	public String getLan3PortDplxSetCd() {
		return lan3PortDplxSetCd;
	}
	public void setLan3PortDplxSetCd(String lan3PortDplxSetCd) {
		this.lan3PortDplxSetCd = lan3PortDplxSetCd;
	}
	public String getLan4PortDplxSetCd() {
		return lan4PortDplxSetCd;
	}
	public void setLan4PortDplxSetCd(String lan4PortDplxSetCd) {
		this.lan4PortDplxSetCd = lan4PortDplxSetCd;
	}
	public String getWanBandwStVal() {
		return wanBandwStVal;
	}
	public void setWanBandwStVal(String wanBandwStVal) {
		this.wanBandwStVal = wanBandwStVal;
	}
	public double getWanTrfcUseRt() {
		return wanTrfcUseRt;
	}
	public void setWanTrfcUseRt(double wanTrfcUseRt) {
		this.wanTrfcUseRt = wanTrfcUseRt;
	}
	public int getWireEnvQltyScor() {
		return wireEnvQltyScor;
	}
	public void setWireEnvQltyScor(int wireEnvQltyScor) {
		this.wireEnvQltyScor = wireEnvQltyScor;
	}
	public double getWifi2p4gRssiBadKeepTmsRt() {
		return wifi2p4gRssiBadKeepTmsRt;
	}
	public void setWifi2p4gRssiBadKeepTmsRt(double wifi2p4gRssiBadKeepTmsRt) {
		this.wifi2p4gRssiBadKeepTmsRt = wifi2p4gRssiBadKeepTmsRt;
	}
	public double getWifi5gRssiBadKeepTmsRt() {
		return wifi5gRssiBadKeepTmsRt;
	}
	public void setWifi5gRssiBadKeepTmsRt(double wifi5gRssiBadKeepTmsRt) {
		this.wifi5gRssiBadKeepTmsRt = wifi5gRssiBadKeepTmsRt;
	}
	public int getWifi2p4gNormGrCpeCnt() {
		return wifi2p4gNormGrCpeCnt;
	}
	public void setWifi2p4gNormGrCpeCnt(int wifi2p4gNormGrCpeCnt) {
		this.wifi2p4gNormGrCpeCnt = wifi2p4gNormGrCpeCnt;
	}
	public int getWifi2p4gBadGrCpeCnt() {
		return wifi2p4gBadGrCpeCnt;
	}
	public void setWifi2p4gBadGrCpeCnt(int wifi2p4gBadGrCpeCnt) {
		this.wifi2p4gBadGrCpeCnt = wifi2p4gBadGrCpeCnt;
	}
	public int getWifi5gNormGrCpeCnt() {
		return wifi5gNormGrCpeCnt;
	}
	public void setWifi5gNormGrCpeCnt(int wifi5gNormGrCpeCnt) {
		this.wifi5gNormGrCpeCnt = wifi5gNormGrCpeCnt;
	}
	public int getWifi5gBadGrCpeCnt() {
		return wifi5gBadGrCpeCnt;
	}
	public void setWifi5gBadGrCpeCnt(int wifi5gBadGrCpeCnt) {
		this.wifi5gBadGrCpeCnt = wifi5gBadGrCpeCnt;
	}
	public int getCpeQltyScor() {
		return cpeQltyScor;
	}
	public void setCpeQltyScor(int cpeQltyScor) {
		this.cpeQltyScor = cpeQltyScor;
	}
	public int getOvrlQltyScor() {
		return ovrlQltyScor;
	}
	public void setOvrlQltyScor(int ovrlQltyScor) {
		this.ovrlQltyScor = ovrlQltyScor;
	}
	public int getVocCnt() {
		return vocCnt;
	}
	public void setVocCnt(int vocCnt) {
		this.vocCnt = vocCnt;
	}
	public int getWifi2p4gGoodGrCpeCnt() {
		return wifi2p4gGoodGrCpeCnt;
	}
	public void setWifi2p4gGoodGrCpeCnt(int wifi2p4gGoodGrCpeCnt) {
		this.wifi2p4gGoodGrCpeCnt = wifi2p4gGoodGrCpeCnt;
	}
	public int getWifi5gGoodGrCpeCnt() {
		return wifi5gGoodGrCpeCnt;
	}
	public void setWifi5gGoodGrCpeCnt(int wifi5gGoodGrCpeCnt) {
		this.wifi5gGoodGrCpeCnt = wifi5gGoodGrCpeCnt;
	}
	public int getWifiHndovrOccrCnt() {
		return wifiHndovrOccrCnt;
	}
	public void setWifiHndovrOccrCnt(int wifiHndovrOccrCnt) {
		this.wifiHndovrOccrCnt = wifiHndovrOccrCnt;
	}
	public String getRssiBadYn() {
		return rssiBadYn;
	}
	public void setRssiBadYn(String rssiBadYn) {
		this.rssiBadYn = rssiBadYn;
	}
	public String getWanTrfcOvrYn() {
		return wanTrfcOvrYn;
	}
	public void setWanTrfcOvrYn(String wanTrfcOvrYn) {
		this.wanTrfcOvrYn = wanTrfcOvrYn;
	}
	public int getSesnOvrOccrCnt() {
		return sesnOvrOccrCnt;
	}
	public void setSesnOvrOccrCnt(int sesnOvrOccrCnt) {
		this.sesnOvrOccrCnt = sesnOvrOccrCnt;
	}
	public int getWifi2p4gRssiMaxVal() {
		return wifi2p4gRssiMaxVal;
	}
	public void setWifi2p4gRssiMaxVal(int wifi2p4gRssiMaxVal) {
		this.wifi2p4gRssiMaxVal = wifi2p4gRssiMaxVal;
	}
	public int getWifi5gRssiMaxVal() {
		return wifi5gRssiMaxVal;
	}
	public void setWifi5gRssiMaxVal(int wifi5gRssiMaxVal) {
		this.wifi5gRssiMaxVal = wifi5gRssiMaxVal;
	}
	public int getWifi2p4gRssiBadCnt() {
		return wifi2p4gRssiBadCnt;
	}
	public void setWifi2p4gRssiBadCnt(int wifi2p4gRssiBadCnt) {
		this.wifi2p4gRssiBadCnt = wifi2p4gRssiBadCnt;
	}
	public int getWifi5gRssiBadCnt() {
		return wifi5gRssiBadCnt;
	}
	public void setWifi5gRssiBadCnt(int wifi5gRssiBadCnt) {
		this.wifi5gRssiBadCnt = wifi5gRssiBadCnt;
	}
	public int getClctCnt() {
		return clctCnt;
	}
	public void setClctCnt(int clctCnt) {
		this.clctCnt = clctCnt;
	}
	public String getRecntCrcOccrDtm() {
		return recntCrcOccrDtm;
	}
	public void setRecntCrcOccrDtm(String recntCrcOccrDtm) {
		this.recntCrcOccrDtm = recntCrcOccrDtm;
	}
	public long getWanTrfcTxVal() {
		return wanTrfcTxVal;
	}
	public void setWanTrfcTxVal(long wanTrfcTxVal) {
		this.wanTrfcTxVal = wanTrfcTxVal;
	}
	public long getWanTrfcRxVal() {
		return wanTrfcRxVal;
	}
	public void setWanTrfcRxVal(long wanTrfcRxVal) {
		this.wanTrfcRxVal = wanTrfcRxVal;
	}
	public long getLanTrfcTxVal() {
		return lanTrfcTxVal;
	}
	public void setLanTrfcTxVal(long lanTrfcTxVal) {
		this.lanTrfcTxVal = lanTrfcTxVal;
	}
	public long getLanTrfcRxVal() {
		return lanTrfcRxVal;
	}
	public void setLanTrfcRxVal(long lanTrfcRxVal) {
		this.lanTrfcRxVal = lanTrfcRxVal;
	}
	public long getWifi2p4gTrfcTxVal() {
		return wifi2p4gTrfcTxVal;
	}
	public void setWifi2p4gTrfcTxVal(long wifi2p4gTrfcTxVal) {
		this.wifi2p4gTrfcTxVal = wifi2p4gTrfcTxVal;
	}
	public long getWifi2p4gTrfcRxVal() {
		return wifi2p4gTrfcRxVal;
	}
	public void setWifi2p4gTrfcRxVal(long wifi2p4gTrfcRxVal) {
		this.wifi2p4gTrfcRxVal = wifi2p4gTrfcRxVal;
	}
	public long getWifi5gTrfcTxVal() {
		return wifi5gTrfcTxVal;
	}
	public void setWifi5gTrfcTxVal(long wifi5gTrfcTxVal) {
		this.wifi5gTrfcTxVal = wifi5gTrfcTxVal;
	}
	public long getWifi5gTrfcRxVal() {
		return wifi5gTrfcRxVal;
	}
	public void setWifi5gTrfcRxVal(long wifi5gTrfcRxVal) {
		this.wifi5gTrfcRxVal = wifi5gTrfcRxVal;
	}
	public long getWifi5gIptvTrfcTxVal() {
		return wifi5gIptvTrfcTxVal;
	}
	public void setWifi5gIptvTrfcTxVal(long wifi5gIptvTrfcTxVal) {
		this.wifi5gIptvTrfcTxVal = wifi5gIptvTrfcTxVal;
	}
	public long getWifi5gIptvTrfcRxVal() {
		return wifi5gIptvTrfcRxVal;
	}
	public void setWifi5gIptvTrfcRxVal(long wifi5gIptvTrfcRxVal) {
		this.wifi5gIptvTrfcRxVal = wifi5gIptvTrfcRxVal;
	}
	public String getEqpVerInfo() {
		return eqpVerInfo;
	}
	public void setEqpVerInfo(String eqpVerInfo) {
		this.eqpVerInfo = eqpVerInfo;
	}
	public int getWifi2p4gRssiBadKeepDtCnt() {
		return wifi2p4gRssiBadKeepDtCnt;
	}
	public void setWifi2p4gRssiBadKeepDtCnt(int wifi2p4gRssiBadKeepDtCnt) {
		this.wifi2p4gRssiBadKeepDtCnt = wifi2p4gRssiBadKeepDtCnt;
	}
	public int getWifi5gRssiBadKeepDayCnt() {
		return wifi5gRssiBadKeepDayCnt;
	}
	public void setWifi5gRssiBadKeepDayCnt(int wifi5gRssiBadKeepDayCnt) {
		this.wifi5gRssiBadKeepDayCnt = wifi5gRssiBadKeepDayCnt;
	}
	public int getOutsWifi2p4gRssiMaxVal() {
		return outsWifi2p4gRssiMaxVal;
	}
	public void setOutsWifi2p4gRssiMaxVal(int outsWifi2p4gRssiMaxVal) {
		this.outsWifi2p4gRssiMaxVal = outsWifi2p4gRssiMaxVal;
	}
	public int getOutsWifi5gRssiMaxVal() {
		return outsWifi5gRssiMaxVal;
	}
	public void setOutsWifi5gRssiMaxVal(int outsWifi5gRssiMaxVal) {
		this.outsWifi5gRssiMaxVal = outsWifi5gRssiMaxVal;
	}
	public int getD7VocCnt() {
		return d7VocCnt;
	}
	public void setD7VocCnt(int d7VocCnt) {
		this.d7VocCnt = d7VocCnt;
	}
	public int getD30VocCnt() {
		return d30VocCnt;
	}
	public void setD30VocCnt(int d30VocCnt) {
		this.d30VocCnt = d30VocCnt;
	}
	public int getD90VocCnt() {
		return d90VocCnt;
	}
	public void setD90VocCnt(int d90VocCnt) {
		this.d90VocCnt = d90VocCnt;
	}
	public int getWanLinkFlapKeepDayCnt() {
		return wanLinkFlapKeepDayCnt;
	}
	public void setWanLinkFlapKeepDayCnt(int wanLinkFlapKeepDayCnt) {
		this.wanLinkFlapKeepDayCnt = wanLinkFlapKeepDayCnt;
	}
	public int getLanLinkFlapKeepDayCnt() {
		return lanLinkFlapKeepDayCnt;
	}
	public void setLanLinkFlapKeepDayCnt(int lanLinkFlapKeepDayCnt) {
		this.lanLinkFlapKeepDayCnt = lanLinkFlapKeepDayCnt;
	}
	public int getWanCrcOccrKeepDayCnt() {
		return wanCrcOccrKeepDayCnt;
	}
	public void setWanCrcOccrKeepDayCnt(int wanCrcOccrKeepDayCnt) {
		this.wanCrcOccrKeepDayCnt = wanCrcOccrKeepDayCnt;
	}
	public int getLanCrcOccrKeepDayCnt() {
		return lanCrcOccrKeepDayCnt;
	}
	public void setLanCrcOccrKeepDayCnt(int lanCrcOccrKeepDayCnt) {
		this.lanCrcOccrKeepDayCnt = lanCrcOccrKeepDayCnt;
	}
}
