package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV10300 extends CopyVO {
	private	String	tpoCd;
	private	String	auditId;
	private	String	auditDtm;
	private	String	tpoNm;
	private	String	tpoTypCd;
	private	String	tpoCntcNum;
	private	String	addrId;
	private	String	tpoDsrctAreaClCd;
	private	String	mgmtTpoCd;
	private	String	jurisInfoCntrClNum;
	private	String	nmsId;
	private	String	exlineChrgrPhonNum;
	private	String	exlineChrgrNm;
	private	String	ktOperGrpCd;
	private	String	ktTpoCd;
	private	String	forgnAddr;
	private	String	forgnCntcNum;
	private	String	operGrpId;
	private	String	rentTpoYn;
	private	String	tpoUseYn;
	private	String	swingCreYn;
	private	String	offcTypCd;
	
	private	String	rangeTpoCd;
	
	public String getTpoCd() {
		return tpoCd;
	}
	public void setTpoCd(String tpoCd) {
		this.tpoCd = tpoCd;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getTpoNm() {
		return tpoNm;
	}
	public void setTpoNm(String tpoNm) {
		this.tpoNm = tpoNm;
	}
	public String getTpoTypCd() {
		return tpoTypCd;
	}
	public void setTpoTypCd(String tpoTypCd) {
		this.tpoTypCd = tpoTypCd;
	}
	public String getTpoCntcNum() {
		return tpoCntcNum;
	}
	public void setTpoCntcNum(String tpoCntcNum) {
		this.tpoCntcNum = tpoCntcNum;
	}
	public String getAddrId() {
		return addrId;
	}
	public void setAddrId(String addrId) {
		this.addrId = addrId;
	}
	public String getTpoDsrctAreaClCd() {
		return tpoDsrctAreaClCd;
	}
	public void setTpoDsrctAreaClCd(String tpoDsrctAreaClCd) {
		this.tpoDsrctAreaClCd = tpoDsrctAreaClCd;
	}
	public String getMgmtTpoCd() {
		return mgmtTpoCd;
	}
	public void setMgmtTpoCd(String mgmtTpoCd) {
		this.mgmtTpoCd = mgmtTpoCd;
	}
	public String getJurisInfoCntrClNum() {
		return jurisInfoCntrClNum;
	}
	public void setJurisInfoCntrClNum(String jurisInfoCntrClNum) {
		this.jurisInfoCntrClNum = jurisInfoCntrClNum;
	}
	public String getNmsId() {
		return nmsId;
	}
	public void setNmsId(String nmsId) {
		this.nmsId = nmsId;
	}
	public String getExlineChrgrPhonNum() {
		return exlineChrgrPhonNum;
	}
	public void setExlineChrgrPhonNum(String exlineChrgrPhonNum) {
		this.exlineChrgrPhonNum = exlineChrgrPhonNum;
	}
	public String getExlineChrgrNm() {
		return exlineChrgrNm;
	}
	public void setExlineChrgrNm(String exlineChrgrNm) {
		this.exlineChrgrNm = exlineChrgrNm;
	}
	public String getKtOperGrpCd() {
		return ktOperGrpCd;
	}
	public void setKtOperGrpCd(String ktOperGrpCd) {
		this.ktOperGrpCd = ktOperGrpCd;
	}
	public String getKtTpoCd() {
		return ktTpoCd;
	}
	public void setKtTpoCd(String ktTpoCd) {
		this.ktTpoCd = ktTpoCd;
	}
	public String getForgnAddr() {
		return forgnAddr;
	}
	public void setForgnAddr(String forgnAddr) {
		this.forgnAddr = forgnAddr;
	}
	public String getForgnCntcNum() {
		return forgnCntcNum;
	}
	public void setForgnCntcNum(String forgnCntcNum) {
		this.forgnCntcNum = forgnCntcNum;
	}
	public String getOperGrpId() {
		return operGrpId;
	}
	public void setOperGrpId(String operGrpId) {
		this.operGrpId = operGrpId;
	}
	public String getRentTpoYn() {
		return rentTpoYn;
	}
	public void setRentTpoYn(String rentTpoYn) {
		this.rentTpoYn = rentTpoYn;
	}
	public String getTpoUseYn() {
		return tpoUseYn;
	}
	public void setTpoUseYn(String tpoUseYn) {
		this.tpoUseYn = tpoUseYn;
	}
	public String getSwingCreYn() {
		return swingCreYn;
	}
	public void setSwingCreYn(String swingCreYn) {
		this.swingCreYn = swingCreYn;
	}
	public String getOffcTypCd() {
		return offcTypCd;
	}
	public void setOffcTypCd(String offcTypCd) {
		this.offcTypCd = offcTypCd;
	}
	@Override
	public void setKey() {
		this.key = this.tpoCd;
	}
	@Override
	public boolean equals(CopyVO obj) {
		OIV10300 dest = (OIV10300) obj;
		if (false == StringUtils.equals(this.tpoCd, dest.tpoCd)) return false;
		if (false == StringUtils.equals(this.tpoNm, dest.tpoNm)) return false;
		if (false == StringUtils.equals(this.tpoTypCd, dest.tpoTypCd)) return false;
		if (false == StringUtils.equals(this.tpoCntcNum, dest.tpoCntcNum)) return false;
		if (false == StringUtils.equals(this.addrId, dest.addrId)) return false;
		if (false == StringUtils.equals(this.tpoDsrctAreaClCd, dest.tpoDsrctAreaClCd)) return false;
		if (false == StringUtils.equals(this.mgmtTpoCd, dest.mgmtTpoCd)) return false;
		if (false == StringUtils.equals(this.jurisInfoCntrClNum, dest.jurisInfoCntrClNum)) return false;
		if (false == StringUtils.equals(this.nmsId, dest.nmsId)) return false;
		if (false == StringUtils.equals(this.exlineChrgrPhonNum, dest.exlineChrgrPhonNum)) return false;
		if (false == StringUtils.equals(this.exlineChrgrNm, dest.exlineChrgrNm)) return false;
		if (false == StringUtils.equals(this.ktOperGrpCd, dest.ktOperGrpCd)) return false;
		if (false == StringUtils.equals(this.ktTpoCd, dest.ktTpoCd)) return false;
		if (false == StringUtils.equals(this.forgnAddr, dest.forgnAddr)) return false;
		if (false == StringUtils.equals(this.forgnCntcNum, dest.forgnCntcNum)) return false;
		if (false == StringUtils.equals(this.operGrpId, dest.operGrpId)) return false;
		if (false == StringUtils.equals(this.rentTpoYn, dest.rentTpoYn)) return false;
		if (false == StringUtils.equals(this.tpoUseYn, dest.tpoUseYn)) return false;
		if (false == StringUtils.equals(this.swingCreYn, dest.swingCreYn)) return false;
		if (false == StringUtils.equals(this.offcTypCd, dest.offcTypCd)) return false;
		return true;
	}
	@Override
	public void setRange(CopyVO obj) {
		OIV10300 src = (OIV10300) obj;
		this.rangeTpoCd = src.getTpoCd();
	}
	public String getRangeTpoCd() {
		return rangeTpoCd;
	}
	public void setRangeTpoCd(String rangeTpoCd) {
		this.rangeTpoCd = rangeTpoCd;
	}
}
