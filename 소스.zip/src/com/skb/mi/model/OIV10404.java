package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV10404 extends CopyVO {
	private	String	linkId;
	private	int	thruSerNum;
	private	long	svcMgmtNum;
	private	String	auditId;
	private	String	auditDtm;

	private	String	rangeLinkId;
	private	int	rangeThruSerNum;
	private	long	rangeSvcMgmtNum;

	public String getLinkId() {
		return linkId;
	}
	public void setLinkId(String linkId) {
		this.linkId = linkId;
	}
	public int getThruSerNum() {
		return thruSerNum;
	}
	public void setThruSerNum(int thruSerNum) {
		this.thruSerNum = thruSerNum;
	}
	public long getSvcMgmtNum() {
		return svcMgmtNum;
	}
	public void setSvcMgmtNum(long svcMgmtNum) {
		this.svcMgmtNum = svcMgmtNum;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	@Override
	public void setKey() {
		this.key = this.linkId + "|" + this.thruSerNum + "|" + this.svcMgmtNum;
	}
	@Override
	public boolean equals(CopyVO obj) {
		OIV10404 dest = (OIV10404) obj;
		if (false == StringUtils.equals(this.linkId, dest.linkId)) return false;
		if (this.thruSerNum != dest.thruSerNum) return false;
		if (this.svcMgmtNum != dest.svcMgmtNum) return false;
		return true;
	}
	@Override
	public void setRange(CopyVO obj) {
		OIV10404 src = (OIV10404) obj;
		this.rangeLinkId = src.getLinkId();
		this.rangeThruSerNum = src.getThruSerNum();
		this.rangeSvcMgmtNum = src.getSvcMgmtNum();
	}
	public String getRangeLinkId() {
		return rangeLinkId;
	}
	public void setRangeLinkId(String rangeLinkId) {
		this.rangeLinkId = rangeLinkId;
	}
	public int getRangeThruSerNum() {
		return rangeThruSerNum;
	}
	public void setRangeThruSerNum(int rangeThruSerNum) {
		this.rangeThruSerNum = rangeThruSerNum;
	}
	public long getRangeSvcMgmtNum() {
		return rangeSvcMgmtNum;
	}
	public void setRangeSvcMgmtNum(long rangeSvcMgmtNum) {
		this.rangeSvcMgmtNum = rangeSvcMgmtNum;
	}
}
