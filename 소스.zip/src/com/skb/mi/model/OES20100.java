package com.skb.mi.model;

public class OES20100 {
	private	String	orgId;
	private	String	auditId;
	private	String	auditDtm;
	private	String	orgNm;
	private	String	orgAbbrNm;
	private	String	orgCd;
	private	String	subOrgCd;
	private	String	hrOrgCd;
	private	String	orgPrtSeqVal;
	private	String	supOrgId;
	private	String	supOrgCd;
	private	String	supSubOrgCd;
	private	String	supOrgNm;
	private	String	cntrOrgId;
	private	String	cntrOrgCd;
	private	String	cntrOrgNm;
	private	String	mktDivOrgId;
	private	String	mktDivOrgCd;
	private	String	mktDivSubOrgCd;
	private	String	mktDivOrgNm;
	private	String	orgClCd;
	private	String	orgTypCd;
	private	String	wareaCd;
	private	String	areaCd;
	private	String	aplyStaDt;
	private	String	aplyEndDt;
	private	String	virtualOrgTypCd;
	private	String	asCntrTypCd;
	private	String	bizNum;
	private	String	delYn;
	private	String	actvnYn;
	private	String	currWorkPlcId;
	private	String	phonNum;
	private	String	faxNum;
	private	String	spclMtrInfo;
	private	String	coClCd;
	private	String	refOrgId;
	private	String	addrId;
	private	String	bldblkNum;
	private	String	blduntNum;
	private	String	assistAddr;
	private	String	newAddrYn;
	
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getOrgNm() {
		return orgNm;
	}
	public void setOrgNm(String orgNm) {
		this.orgNm = orgNm;
	}
	public String getOrgAbbrNm() {
		return orgAbbrNm;
	}
	public void setOrgAbbrNm(String orgAbbrNm) {
		this.orgAbbrNm = orgAbbrNm;
	}
	public String getOrgCd() {
		return orgCd;
	}
	public void setOrgCd(String orgCd) {
		this.orgCd = orgCd;
	}
	public String getSubOrgCd() {
		return subOrgCd;
	}
	public void setSubOrgCd(String subOrgCd) {
		this.subOrgCd = subOrgCd;
	}
	public String getHrOrgCd() {
		return hrOrgCd;
	}
	public void setHrOrgCd(String hrOrgCd) {
		this.hrOrgCd = hrOrgCd;
	}
	public String getOrgPrtSeqVal() {
		return orgPrtSeqVal;
	}
	public void setOrgPrtSeqVal(String orgPrtSeqVal) {
		this.orgPrtSeqVal = orgPrtSeqVal;
	}
	public String getSupOrgId() {
		return supOrgId;
	}
	public void setSupOrgId(String supOrgId) {
		this.supOrgId = supOrgId;
	}
	public String getSupOrgCd() {
		return supOrgCd;
	}
	public void setSupOrgCd(String supOrgCd) {
		this.supOrgCd = supOrgCd;
	}
	public String getSupSubOrgCd() {
		return supSubOrgCd;
	}
	public void setSupSubOrgCd(String supSubOrgCd) {
		this.supSubOrgCd = supSubOrgCd;
	}
	public String getSupOrgNm() {
		return supOrgNm;
	}
	public void setSupOrgNm(String supOrgNm) {
		this.supOrgNm = supOrgNm;
	}
	public String getCntrOrgId() {
		return cntrOrgId;
	}
	public void setCntrOrgId(String cntrOrgId) {
		this.cntrOrgId = cntrOrgId;
	}
	public String getCntrOrgCd() {
		return cntrOrgCd;
	}
	public void setCntrOrgCd(String cntrOrgCd) {
		this.cntrOrgCd = cntrOrgCd;
	}
	public String getCntrOrgNm() {
		return cntrOrgNm;
	}
	public void setCntrOrgNm(String cntrOrgNm) {
		this.cntrOrgNm = cntrOrgNm;
	}
	public String getMktDivOrgId() {
		return mktDivOrgId;
	}
	public void setMktDivOrgId(String mktDivOrgId) {
		this.mktDivOrgId = mktDivOrgId;
	}
	public String getMktDivOrgCd() {
		return mktDivOrgCd;
	}
	public void setMktDivOrgCd(String mktDivOrgCd) {
		this.mktDivOrgCd = mktDivOrgCd;
	}
	public String getMktDivSubOrgCd() {
		return mktDivSubOrgCd;
	}
	public void setMktDivSubOrgCd(String mktDivSubOrgCd) {
		this.mktDivSubOrgCd = mktDivSubOrgCd;
	}
	public String getMktDivOrgNm() {
		return mktDivOrgNm;
	}
	public void setMktDivOrgNm(String mktDivOrgNm) {
		this.mktDivOrgNm = mktDivOrgNm;
	}
	public String getOrgClCd() {
		return orgClCd;
	}
	public void setOrgClCd(String orgClCd) {
		this.orgClCd = orgClCd;
	}
	public String getOrgTypCd() {
		return orgTypCd;
	}
	public void setOrgTypCd(String orgTypCd) {
		this.orgTypCd = orgTypCd;
	}
	public String getWareaCd() {
		return wareaCd;
	}
	public void setWareaCd(String wareaCd) {
		this.wareaCd = wareaCd;
	}
	public String getAreaCd() {
		return areaCd;
	}
	public void setAreaCd(String areaCd) {
		this.areaCd = areaCd;
	}
	public String getAplyStaDt() {
		return aplyStaDt;
	}
	public void setAplyStaDt(String aplyStaDt) {
		this.aplyStaDt = aplyStaDt;
	}
	public String getAplyEndDt() {
		return aplyEndDt;
	}
	public void setAplyEndDt(String aplyEndDt) {
		this.aplyEndDt = aplyEndDt;
	}
	public String getVirtualOrgTypCd() {
		return virtualOrgTypCd;
	}
	public void setVirtualOrgTypCd(String virtualOrgTypCd) {
		this.virtualOrgTypCd = virtualOrgTypCd;
	}
	public String getAsCntrTypCd() {
		return asCntrTypCd;
	}
	public void setAsCntrTypCd(String asCntrTypCd) {
		this.asCntrTypCd = asCntrTypCd;
	}
	public String getBizNum() {
		return bizNum;
	}
	public void setBizNum(String bizNum) {
		this.bizNum = bizNum;
	}
	public String getDelYn() {
		return delYn;
	}
	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}
	public String getActvnYn() {
		return actvnYn;
	}
	public void setActvnYn(String actvnYn) {
		this.actvnYn = actvnYn;
	}
	public String getCurrWorkPlcId() {
		return currWorkPlcId;
	}
	public void setCurrWorkPlcId(String currWorkPlcId) {
		this.currWorkPlcId = currWorkPlcId;
	}
	public String getPhonNum() {
		return phonNum;
	}
	public void setPhonNum(String phonNum) {
		this.phonNum = phonNum;
	}
	public String getFaxNum() {
		return faxNum;
	}
	public void setFaxNum(String faxNum) {
		this.faxNum = faxNum;
	}
	public String getSpclMtrInfo() {
		return spclMtrInfo;
	}
	public void setSpclMtrInfo(String spclMtrInfo) {
		this.spclMtrInfo = spclMtrInfo;
	}
	public String getCoClCd() {
		return coClCd;
	}
	public void setCoClCd(String coClCd) {
		this.coClCd = coClCd;
	}
	public String getRefOrgId() {
		return refOrgId;
	}
	public void setRefOrgId(String refOrgId) {
		this.refOrgId = refOrgId;
	}
	public String getAddrId() {
		return addrId;
	}
	public void setAddrId(String addrId) {
		this.addrId = addrId;
	}
	public String getBldblkNum() {
		return bldblkNum;
	}
	public void setBldblkNum(String bldblkNum) {
		this.bldblkNum = bldblkNum;
	}
	public String getBlduntNum() {
		return blduntNum;
	}
	public void setBlduntNum(String blduntNum) {
		this.blduntNum = blduntNum;
	}
	public String getAssistAddr() {
		return assistAddr;
	}
	public void setAssistAddr(String assistAddr) {
		this.assistAddr = assistAddr;
	}
	public String getNewAddrYn() {
		return newAddrYn;
	}
	public void setNewAddrYn(String newAddrYn) {
		this.newAddrYn = newAddrYn;
	}
}
