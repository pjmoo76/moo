package com.skb.mi.model;

public class BCO30340 {
	private	String	operStaDtm;
	private	String	clctNmsClCd;
	private	String	clctTblNm;
	private	String	auditId;
	private	String	auditDtm;
	private	String	operFnshDtm;
	private	int	dataAddCnt;
	private	int	dataDelCnt;
	private	int	dataUpdCnt;
	private	int	dataAllCnt;
	private	String	clctTblDesc;
	private	String	clctAplyObjTblNm;
	private	String	lnkgErrCtt;
	private	String	clctYn;
	private	int	dataErrCnt;
	private boolean isWorkSuccess;
	
	public String getOperStaDtm() {
		return operStaDtm;
	}
	public void setOperStaDtm(String operStaDtm) {
		this.operStaDtm = operStaDtm;
	}
	public String getClctNmsClCd() {
		return clctNmsClCd;
	}
	public void setClctNmsClCd(String clctNmsClCd) {
		this.clctNmsClCd = clctNmsClCd;
	}
	public String getClctTblNm() {
		return clctTblNm;
	}
	public void setClctTblNm(String clctTblNm) {
		this.clctTblNm = clctTblNm;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getOperFnshDtm() {
		return operFnshDtm;
	}
	public void setOperFnshDtm(String operFnshDtm) {
		this.operFnshDtm = operFnshDtm;
	}
	public int getDataAddCnt() {
		return dataAddCnt;
	}
	public void setDataAddCnt(int dataAddCnt) {
		this.dataAddCnt = dataAddCnt;
	}
	public int getDataDelCnt() {
		return dataDelCnt;
	}
	public void setDataDelCnt(int dataDelCnt) {
		this.dataDelCnt = dataDelCnt;
	}
	public int getDataUpdCnt() {
		return dataUpdCnt;
	}
	public void setDataUpdCnt(int dataUpdCnt) {
		this.dataUpdCnt = dataUpdCnt;
	}
	public int getDataAllCnt() {
		return dataAllCnt;
	}
	public void setDataAllCnt(int dataAllCnt) {
		this.dataAllCnt = dataAllCnt;
	}
	public String getClctTblDesc() {
		return clctTblDesc;
	}
	public void setClctTblDesc(String clctTblDesc) {
		this.clctTblDesc = clctTblDesc;
	}
	public String getClctAplyObjTblNm() {
		return clctAplyObjTblNm;
	}
	public void setClctAplyObjTblNm(String clctAplyObjTblNm) {
		this.clctAplyObjTblNm = clctAplyObjTblNm;
	}
	public String getLnkgErrCtt() {
		return lnkgErrCtt;
	}
	public void setLnkgErrCtt(String lnkgErrCtt) {
		this.lnkgErrCtt = lnkgErrCtt;
	}
	public String getClctYn() {
		return clctYn;
	}
	public void setClctYn(String clctYn) {
		this.clctYn = clctYn;
	}
	public int getDataErrCnt() {
		return dataErrCnt;
	}
	public void setDataErrCnt(int dataErrCnt) {
		this.dataErrCnt = dataErrCnt;
	}
	public boolean isWorkSuccess() {
		return isWorkSuccess;
	}
	public void setWorkSuccess(boolean isWorkSuccess) {
		this.isWorkSuccess = isWorkSuccess;
	}
	
}
