package com.skb.mi.model;

public class OIV10861 {
	private	String	sumOperId;
	private	String	sumExecProcNm;
	private	String	sumOperTypNm;
	private	String	sumOperPgmClasNm;
	private	String	srcDbNm;
	private	String	trgtDbNm;
	private	String	fdrNm;
	private	String	tblNm;
	private	String	sumDataNm;
	private	String	sumDataFormVal;
	private	int		sumExecCycl;
	private	int		manlSumExecCycl;
	private	String	logUseYn;
	private	String	failRetryYn;
	private	String	failAllRetryYn;
	private	String	sumOperPgmAddInfo;

	public String getSumOperId() {
		return sumOperId;
	}
	public void setSumOperId(String sumOperId) {
		this.sumOperId = sumOperId;
	}
	public String getSumExecProcNm() {
		return sumExecProcNm;
	}
	public void setSumExecProcNm(String sumExecProcNm) {
		this.sumExecProcNm = sumExecProcNm;
	}
	public String getSumOperTypNm() {
		return sumOperTypNm;
	}
	public void setSumOperTypNm(String sumOperTypNm) {
		this.sumOperTypNm = sumOperTypNm;
	}
	public String getSumOperPgmClasNm() {
		return sumOperPgmClasNm;
	}
	public void setSumOperPgmClasNm(String sumOperPgmClasNm) {
		this.sumOperPgmClasNm = sumOperPgmClasNm;
	}
	public String getSrcDbNm() {
		return srcDbNm;
	}
	public void setSrcDbNm(String srcDbNm) {
		this.srcDbNm = srcDbNm;
	}
	public String getTrgtDbNm() {
		return trgtDbNm;
	}
	public void setTrgtDbNm(String trgtDbNm) {
		this.trgtDbNm = trgtDbNm;
	}
	public String getFdrNm() {
		return fdrNm;
	}
	public void setFdrNm(String fdrNm) {
		this.fdrNm = fdrNm;
	}
	public String getTblNm() {
		return tblNm;
	}
	public void setTblNm(String tblNm) {
		this.tblNm = tblNm;
	}
	public String getSumDataNm() {
		return sumDataNm;
	}
	public void setSumDataNm(String sumDataNm) {
		this.sumDataNm = sumDataNm;
	}
	public String getSumDataFormVal() {
		return sumDataFormVal;
	}
	public void setSumDataFormVal(String sumDataFormVal) {
		this.sumDataFormVal = sumDataFormVal;
	}
	public int getSumExecCycl() {
		return sumExecCycl;
	}
	public void setSumExecCycl(int sumExecCycl) {
		this.sumExecCycl = sumExecCycl;
	}
	public int getManlSumExecCycl() {
		return manlSumExecCycl;
	}
	public void setManlSumExecCycl(int manlSumExecCycl) {
		this.manlSumExecCycl = manlSumExecCycl;
	}
	public String getLogUseYn() {
		return logUseYn;
	}
	public void setLogUseYn(String logUseYn) {
		this.logUseYn = logUseYn;
	}
	public String getFailRetryYn() {
		return failRetryYn;
	}
	public void setFailRetryYn(String failRetryYn) {
		this.failRetryYn = failRetryYn;
	}
	public String getFailAllRetryYn() {
		return failAllRetryYn;
	}
	public void setFailAllRetryYn(String failAllRetryYn) {
		this.failAllRetryYn = failAllRetryYn;
	}
	public String getSumOperPgmAddInfo() {
		return sumOperPgmAddInfo;
	}
	public void setSumOperPgmAddInfo(String sumOperPgmAddInfo) {
		this.sumOperPgmAddInfo = sumOperPgmAddInfo;
	}
}
