package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV10100 extends CopyVO {
	private	String	equipId;
	private	String	auditId;
	private	String	auditDtm;
	private	String	equipMgmtNum;
	private	String	tpoCd;
	private	String	mgmtTpoCd;
	private	String	exchgTpoCd;
	private	String	jurisTpoCd;
	private	String	equipMdlCd;
	private	String	equipSysSetDt;
	private	String	equipUsgCd;
	private	String	equipTypClCd;
	private	String	swVerInfo;
	private	String	equipSysNm;
	private	String	equipTidVal;
	private	String	equipNm;
	private	String	equipOwnYn;
	private	String	equipSetLocDesc;
	private	String	equipIpAddr;
	private	String	linkEquipId;
	private	String	memo;
	private	String	delYn;
	private	String	pollingMObjYn;
	private	String	pingMObjYn;
	private	String	mObjYn;
	private	String	nmsEquipCd;
	private	String	chrgrNm;
	private	String	chrgrCntcNum;
	private	String	subChrgrNm;
	private	String	subChrgrCntcNum;
	private	String	dhcpEquipId;
	private	String	massCoClCd;
	
	private	String	rangeEquipId;
	
	public String getEquipId() {
		return equipId;
	}
	public void setEquipId(String equipId) {
		this.equipId = equipId;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getEquipMgmtNum() {
		return equipMgmtNum;
	}
	public void setEquipMgmtNum(String equipMgmtNum) {
		this.equipMgmtNum = equipMgmtNum;
	}
	public String getTpoCd() {
		return tpoCd;
	}
	public void setTpoCd(String tpoCd) {
		this.tpoCd = tpoCd;
	}
	public String getMgmtTpoCd() {
		return mgmtTpoCd;
	}
	public void setMgmtTpoCd(String mgmtTpoCd) {
		this.mgmtTpoCd = mgmtTpoCd;
	}
	public String getExchgTpoCd() {
		return exchgTpoCd;
	}
	public void setExchgTpoCd(String exchgTpoCd) {
		this.exchgTpoCd = exchgTpoCd;
	}
	public String getJurisTpoCd() {
		return jurisTpoCd;
	}
	public void setJurisTpoCd(String jurisTpoCd) {
		this.jurisTpoCd = jurisTpoCd;
	}
	public String getEquipMdlCd() {
		return equipMdlCd;
	}
	public void setEquipMdlCd(String equipMdlCd) {
		this.equipMdlCd = equipMdlCd;
	}
	public String getEquipSysSetDt() {
		return equipSysSetDt;
	}
	public void setEquipSysSetDt(String equipSysSetDt) {
		this.equipSysSetDt = equipSysSetDt;
	}
	public String getEquipUsgCd() {
		return equipUsgCd;
	}
	public void setEquipUsgCd(String equipUsgCd) {
		this.equipUsgCd = equipUsgCd;
	}
	public String getEquipTypClCd() {
		return equipTypClCd;
	}
	public void setEquipTypClCd(String equipTypClCd) {
		this.equipTypClCd = equipTypClCd;
	}
	public String getSwVerInfo() {
		return swVerInfo;
	}
	public void setSwVerInfo(String swVerInfo) {
		this.swVerInfo = swVerInfo;
	}
	public String getEquipSysNm() {
		return equipSysNm;
	}
	public void setEquipSysNm(String equipSysNm) {
		this.equipSysNm = equipSysNm;
	}
	public String getEquipTidVal() {
		return equipTidVal;
	}
	public void setEquipTidVal(String equipTidVal) {
		this.equipTidVal = equipTidVal;
	}
	public String getEquipNm() {
		return equipNm;
	}
	public void setEquipNm(String equipNm) {
		this.equipNm = equipNm;
	}
	public String getEquipOwnYn() {
		return equipOwnYn;
	}
	public void setEquipOwnYn(String equipOwnYn) {
		this.equipOwnYn = equipOwnYn;
	}
	public String getEquipSetLocDesc() {
		return equipSetLocDesc;
	}
	public void setEquipSetLocDesc(String equipSetLocDesc) {
		this.equipSetLocDesc = equipSetLocDesc;
	}
	public String getEquipIpAddr() {
		return equipIpAddr;
	}
	public void setEquipIpAddr(String equipIpAddr) {
		this.equipIpAddr = equipIpAddr;
	}
	public String getLinkEquipId() {
		return linkEquipId;
	}
	public void setLinkEquipId(String linkEquipId) {
		this.linkEquipId = linkEquipId;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public String getDelYn() {
		return delYn;
	}
	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}
	public String getPollingMObjYn() {
		return pollingMObjYn;
	}
	public void setPollingMObjYn(String pollingMObjYn) {
		this.pollingMObjYn = pollingMObjYn;
	}
	public String getPingMObjYn() {
		return pingMObjYn;
	}
	public void setPingMObjYn(String pingMObjYn) {
		this.pingMObjYn = pingMObjYn;
	}
	public String getmObjYn() {
		return mObjYn;
	}
	public void setmObjYn(String mObjYn) {
		this.mObjYn = mObjYn;
	}
	public String getNmsEquipCd() {
		return nmsEquipCd;
	}
	public void setNmsEquipCd(String nmsEquipCd) {
		this.nmsEquipCd = nmsEquipCd;
	}
	public String getChrgrNm() {
		return chrgrNm;
	}
	public void setChrgrNm(String chrgrNm) {
		this.chrgrNm = chrgrNm;
	}
	public String getChrgrCntcNum() {
		return chrgrCntcNum;
	}
	public void setChrgrCntcNum(String chrgrCntcNum) {
		this.chrgrCntcNum = chrgrCntcNum;
	}
	public String getSubChrgrNm() {
		return subChrgrNm;
	}
	public void setSubChrgrNm(String subChrgrNm) {
		this.subChrgrNm = subChrgrNm;
	}
	public String getSubChrgrCntcNum() {
		return subChrgrCntcNum;
	}
	public void setSubChrgrCntcNum(String subChrgrCntcNum) {
		this.subChrgrCntcNum = subChrgrCntcNum;
	}
	public String getDhcpEquipId() {
		return dhcpEquipId;
	}
	public void setDhcpEquipId(String dhcpEquipId) {
		this.dhcpEquipId = dhcpEquipId;
	}
	public String getMassCoClCd() {
		return massCoClCd;
	}
	public void setMassCoClCd(String massCoClCd) {
		this.massCoClCd = massCoClCd;
	}
	
	@Override
	public boolean equals(CopyVO obj) {
		OIV10100 dest = (OIV10100) obj;
		if (false == StringUtils.equals(this.equipId, dest.equipId)) return false;
		if (false == StringUtils.equals(this.equipMgmtNum, dest.equipMgmtNum)) return false;
		if (false == StringUtils.equals(this.tpoCd, dest.tpoCd)) return false;
		if (false == StringUtils.equals(this.mgmtTpoCd, dest.mgmtTpoCd)) return false;
		if (false == StringUtils.equals(this.exchgTpoCd, dest.exchgTpoCd)) return false;
		if (false == StringUtils.equals(this.jurisTpoCd, dest.jurisTpoCd)) return false;
		if (false == StringUtils.equals(this.equipMdlCd, dest.equipMdlCd)) return false;
		if (false == StringUtils.equals(this.equipSysSetDt, dest.equipSysSetDt)) return false;
		if (false == StringUtils.equals(this.equipUsgCd, dest.equipUsgCd)) return false;
		if (false == StringUtils.equals(this.equipTypClCd, dest.equipTypClCd)) return false;
		if (false == StringUtils.equals(this.swVerInfo, dest.swVerInfo)) return false;
		if (false == StringUtils.equals(this.equipSysNm, dest.equipSysNm)) return false;
		if (false == StringUtils.equals(this.equipTidVal, dest.equipTidVal)) return false;
		if (false == StringUtils.equals(this.equipNm, dest.equipNm)) return false;
		if (false == StringUtils.equals(this.equipOwnYn, dest.equipOwnYn)) return false;
		if (false == StringUtils.equals(this.equipSetLocDesc, dest.equipSetLocDesc)) return false;
		if (false == StringUtils.equals(this.equipIpAddr, dest.equipIpAddr)) return false;
		if (false == StringUtils.equals(this.linkEquipId, dest.linkEquipId)) return false;
		if (false == StringUtils.equals(this.memo, dest.memo)) return false;
		if (false == StringUtils.equals(this.delYn, dest.delYn)) return false;
		if (false == StringUtils.equals(this.pollingMObjYn, dest.pollingMObjYn)) return false;
		if (false == StringUtils.equals(this.pingMObjYn, dest.pingMObjYn)) return false;
		if (false == StringUtils.equals(this.mObjYn, dest.mObjYn)) return false;
		if (false == StringUtils.equals(this.nmsEquipCd, dest.nmsEquipCd)) return false;
		if (false == StringUtils.equals(this.chrgrNm, dest.chrgrNm)) return false;
		if (false == StringUtils.equals(this.chrgrCntcNum, dest.chrgrCntcNum)) return false;
		if (false == StringUtils.equals(this.subChrgrNm, dest.subChrgrNm)) return false;
		if (false == StringUtils.equals(this.subChrgrCntcNum, dest.subChrgrCntcNum)) return false;
		if (false == StringUtils.equals(this.dhcpEquipId, dest.dhcpEquipId)) return false;
		if (false == StringUtils.equals(this.massCoClCd, dest.massCoClCd)) return false;
		return true;
	}
	@Override
	public void setKey() {
		this.key = this.equipId;
	}
	
	public String getRangeEquipId() {
		return rangeEquipId;
	}
	public void setRangeEquipId(String rangeEquipId) {
		this.rangeEquipId = rangeEquipId;
	}

	@Override
	public void setRange(CopyVO obj) {
		OIV10100 src = (OIV10100) obj;
		this.rangeEquipId = src.equipId;
	}
}
