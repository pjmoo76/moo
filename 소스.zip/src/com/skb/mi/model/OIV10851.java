package com.skb.mi.model;

import com.skb.mi.common.StringUtils;

public class OIV10851 extends CopyVO {

	private String macAddrVal;
	private String auditId;
	private String auditDtm;
	private String clctDtm;
	private String ipAddr;
	private String stbMacAddrVal;
	private String stbEqpMdlCd;
	private long custNum;
	private String svcTechMthdCd;
	private long inetSvcMgmtNum;
	private String inetSvcNm;
	private long inetSvcNum;
	private long iptvSvcMgmtNum;
	private String iptvSvcNm;
	private long iptvSvcNum;
	private long phonSvcMgmtNum;
	private String phonSvcNm;
	private String phonSvcNum;
	private String teamOrgId;
	private String infoCntrCd;
	private String distbCntrCd;
	private String homeCntrCd;
	private String netClCd;
	private String l3EquipId;
	private String l2EquipId;
	private String l2CellNum;
	private String mfactNm;
	private String ontSerNum;
	private String ccellNum;
	private String l3EquipMgmtNum;
	private String l2EquipMgmtNum;
	
	private	String	rangeMacAddrVal;
	
	public String getMacAddrVal() {
		return macAddrVal;
	}

	public void setMacAddrVal(String macAddrVal) {
		this.macAddrVal = macAddrVal;
	}

	public String getAuditId() {
		return auditId;
	}

	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	public String getAuditDtm() {
		return auditDtm;
	}

	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}

	public String getClctDtm() {
		return clctDtm;
	}

	public void setClctDtm(String clctDtm) {
		this.clctDtm = clctDtm;
	}

	public String getIpAddr() {
		return ipAddr;
	}

	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}

	public String getStbMacAddrVal() {
		return stbMacAddrVal;
	}

	public void setStbMacAddrVal(String stbMacAddrVal) {
		this.stbMacAddrVal = stbMacAddrVal;
	}

	public String getStbEqpMdlCd() {
		return stbEqpMdlCd;
	}

	public void setStbEqpMdlCd(String stbEqpMdlCd) {
		this.stbEqpMdlCd = stbEqpMdlCd;
	}

	public long getCustNum() {
		return custNum;
	}

	public void setCustNum(long custNum) {
		this.custNum = custNum;
	}

	public String getSvcTechMthdCd() {
		return svcTechMthdCd;
	}

	public void setSvcTechMthdCd(String svcTechMthdCd) {
		this.svcTechMthdCd = svcTechMthdCd;
	}

	public long getInetSvcMgmtNum() {
		return inetSvcMgmtNum;
	}

	public void setInetSvcMgmtNum(long inetSvcMgmtNum) {
		this.inetSvcMgmtNum = inetSvcMgmtNum;
	}

	public String getInetSvcNm() {
		return inetSvcNm;
	}

	public void setInetSvcNm(String inetSvcNm) {
		this.inetSvcNm = inetSvcNm;
	}

	public long getInetSvcNum() {
		return inetSvcNum;
	}

	public void setInetSvcNum(long inetSvcNum) {
		this.inetSvcNum = inetSvcNum;
	}

	public long getIptvSvcMgmtNum() {
		return iptvSvcMgmtNum;
	}

	public void setIptvSvcMgmtNum(long iptvSvcMgmtNum) {
		this.iptvSvcMgmtNum = iptvSvcMgmtNum;
	}

	public String getIptvSvcNm() {
		return iptvSvcNm;
	}

	public void setIptvSvcNm(String iptvSvcNm) {
		this.iptvSvcNm = iptvSvcNm;
	}

	public long getIptvSvcNum() {
		return iptvSvcNum;
	}

	public void setIptvSvcNum(long iptvSvcNum) {
		this.iptvSvcNum = iptvSvcNum;
	}

	public long getPhonSvcMgmtNum() {
		return phonSvcMgmtNum;
	}

	public void setPhonSvcMgmtNum(long phonSvcMgmtNum) {
		this.phonSvcMgmtNum = phonSvcMgmtNum;
	}

	public String getPhonSvcNm() {
		return phonSvcNm;
	}

	public void setPhonSvcNm(String phonSvcNm) {
		this.phonSvcNm = phonSvcNm;
	}

	public String getPhonSvcNum() {
		return phonSvcNum;
	}

	public void setPhonSvcNum(String phonSvcNum) {
		this.phonSvcNum = phonSvcNum;
	}

	public String getTeamOrgId() {
		return teamOrgId;
	}

	public void setTeamOrgId(String teamOrgId) {
		this.teamOrgId = teamOrgId;
	}

	public String getInfoCntrCd() {
		return infoCntrCd;
	}

	public void setInfoCntrCd(String infoCntrCd) {
		this.infoCntrCd = infoCntrCd;
	}

	public String getDistbCntrCd() {
		return distbCntrCd;
	}

	public void setDistbCntrCd(String distbCntrCd) {
		this.distbCntrCd = distbCntrCd;
	}

	public String getHomeCntrCd() {
		return homeCntrCd;
	}

	public void setHomeCntrCd(String homeCntrCd) {
		this.homeCntrCd = homeCntrCd;
	}

	public String getNetClCd() {
		return netClCd;
	}

	public void setNetClCd(String netClCd) {
		this.netClCd = netClCd;
	}

	public String getL3EquipId() {
		return l3EquipId;
	}

	public void setL3EquipId(String l3EquipId) {
		this.l3EquipId = l3EquipId;
	}

	public String getL2EquipId() {
		return l2EquipId;
	}

	public void setL2EquipId(String l2EquipId) {
		this.l2EquipId = l2EquipId;
	}

	public String getL2CellNum() {
		return l2CellNum;
	}

	public void setL2CellNum(String l2CellNum) {
		this.l2CellNum = l2CellNum;
	}

	public String getMfactNm() {
		return mfactNm;
	}

	public void setMfactNm(String mfactNm) {
		this.mfactNm = mfactNm;
	}

	public String getOntSerNum() {
		return ontSerNum;
	}

	public void setOntSerNum(String ontSerNum) {
		this.ontSerNum = ontSerNum;
	}

	public String getCcellNum() {
		return ccellNum;
	}

	public void setCcellNum(String ccellNum) {
		this.ccellNum = ccellNum;
	}

	public String getL3EquipMgmtNum() {
		return l3EquipMgmtNum;
	}

	public void setL3EquipMgmtNum(String l3EquipMgmtNum) {
		this.l3EquipMgmtNum = l3EquipMgmtNum;
	}

	public String getL2EquipMgmtNum() {
		return l2EquipMgmtNum;
	}

	public void setL2EquipMgmtNum(String l2EquipMgmtNum) {
		this.l2EquipMgmtNum = l2EquipMgmtNum;
	}

	public String getRangeMacAddrVal() {
		return rangeMacAddrVal;
	}

	public void setRangeMacAddrVal(String rangeMacAddrVal) {
		this.rangeMacAddrVal = rangeMacAddrVal;
	}

	@Override
	public void setKey() {
		this.key = this.macAddrVal;
		
	}

	@Override
	public boolean equals(CopyVO obj) {
		OIV10851 dest = (OIV10851) obj;
		if (false == StringUtils.equals(this.macAddrVal, dest.macAddrVal)) return false;
		if (false == StringUtils.equals(this.auditId, dest.auditId)) return false;
		if (false == StringUtils.equals(this.auditDtm, dest.auditDtm)) return false;
		if (false == StringUtils.equals(this.clctDtm, dest.clctDtm)) return false;
		if (false == StringUtils.equals(this.ipAddr, dest.ipAddr)) return false;
		if (false == StringUtils.equals(this.stbMacAddrVal, dest.stbMacAddrVal)) return false;
		if (false == StringUtils.equals(this.stbEqpMdlCd, dest.stbEqpMdlCd)) return false;
		if (this.custNum != dest.custNum) return false;
		if (false == StringUtils.equals(this.svcTechMthdCd, dest.svcTechMthdCd)) return false;
		if (this.inetSvcMgmtNum != dest.inetSvcMgmtNum) return false;
		if (false == StringUtils.equals(this.inetSvcNm, dest.inetSvcNm)) return false;
		if (this.inetSvcNum != dest.inetSvcNum) return false;
		if (this.iptvSvcMgmtNum != dest.iptvSvcMgmtNum) return false;
		if (false == StringUtils.equals(this.iptvSvcNm, dest.iptvSvcNm)) return false;
		if (this.iptvSvcNum != dest.iptvSvcNum) return false;
		if (this.phonSvcMgmtNum != dest.phonSvcMgmtNum) return false;
		if (false == StringUtils.equals(this.phonSvcNm, dest.phonSvcNm)) return false;
		if (false == StringUtils.equals(this.phonSvcNum, dest.phonSvcNum)) return false;
		if (false == StringUtils.equals(this.teamOrgId, dest.teamOrgId)) return false;
		if (false == StringUtils.equals(this.infoCntrCd, dest.infoCntrCd)) return false;
		if (false == StringUtils.equals(this.distbCntrCd, dest.distbCntrCd)) return false;
		if (false == StringUtils.equals(this.homeCntrCd, dest.homeCntrCd)) return false;
		if (false == StringUtils.equals(this.netClCd, dest.netClCd)) return false;
		if (false == StringUtils.equals(this.l3EquipId, dest.l3EquipId)) return false;
		if (false == StringUtils.equals(this.l2EquipId, dest.l2EquipId)) return false;
		if (false == StringUtils.equals(this.l2CellNum, dest.l2CellNum)) return false;
		if (false == StringUtils.equals(this.mfactNm, dest.mfactNm)) return false;
		if (false == StringUtils.equals(this.ontSerNum, dest.ontSerNum)) return false;
		if (false == StringUtils.equals(this.ccellNum, dest.ccellNum)) return false;
		if (false == StringUtils.equals(this.l3EquipMgmtNum, dest.l3EquipMgmtNum)) return false;
		if (false == StringUtils.equals(this.l2EquipMgmtNum, dest.l2EquipMgmtNum)) return false;
		return true;
	}

	@Override
	public void setRange(CopyVO obj) {
		OIV10851 src = (OIV10851) obj;
		this.rangeMacAddrVal = src.macAddrVal;		
	}

}
