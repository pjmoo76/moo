package com.skb.mi.itms.stat;

import java.io.File;
import java.sql.SQLException;
import java.sql.SQLRecoverableException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.math.BigDecimal;

import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.common.PerThreadDailyRollingFileAppender;
import com.skb.mi.itms.model.BCO30223;
import com.skb.mi.itms.model.BCO30224;
import com.skb.mi.itms.model.BCO30321;

public class ItmsWorkManager {
	final private String	ServiceName = "ItmsWorkManager"; 
	private Logger		logger;
	private	SqlSession	sqlSession;
	private	int			sleepSec;
	private	int			retryMaxNo = 2;
	private	String		dbName;
	private	String		processName;
	
	public ItmsWorkManager(String[] args) {
		processName = EnvManager.env.getOptionValue("PROCESS");
		PerThreadDailyRollingFileAppender.LOG_POSTFIX = processName;
		logger = LogManager.getLogger(this.getClass().getName());
		logger.info("start");
		loadConfig();
	}

	private void loadConfig() {
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		dbName = configManager.getConfig(this.ServiceName, "dbName");
		sleepSec = Integer.parseInt(configManager.getConfig(this.ServiceName, "sleepSec"));
		try {
			retryMaxNo = Integer.parseInt(configManager.getConfig(this.ServiceName, "retryMaxNo"));
		} catch (Exception e) {
			logger.error("exception", e);
		}
		logger.info(String.format("(dbName=%s)", dbName));
		logger.info(String.format("(sleepSec=%d)", sleepSec));
		logger.info(String.format("(retryMaxNo=%d)", retryMaxNo));
	}

	public void run() throws Exception {
		if (processName == null) {
			logger.error("processName is null");
			return;
		}
		sqlSession = IbatisSessionFactory.openSession(dbName);
		HashMap<String,DbBatchNode> batchMap = new HashMap<String,DbBatchNode>();
		HashMap<String,String> paramMap = new HashMap<String,String>();
		paramMap.put("processName", processName);
		List<BCO30321> workOperList = sqlSession.selectList("sql_itms_work_order.SELECT_BCO30321", paramMap);
		for (BCO30321 operVo : workOperList) {
			DbBatchNode batchNode = batchMap.get(operVo.getSumOperId());
			if (batchNode == null) {
				batchNode = new DbBatchNode(operVo.getSumOperId(), operVo.getDbNm(), retryMaxNo);
				batchMap.put(operVo.getSumOperId(), batchNode);
			}
			logger.info(String.format("(sumOperId=%s),(operSeq=%d),(operSqlId=%s)", operVo.getSumOperId(), operVo.getOperSeq(), operVo.getOperSqlId()));
			batchNode.add(operVo);
		}
		for (Map.Entry me : batchMap.entrySet()) {
			DbBatchNode batchNode = (DbBatchNode) me.getValue();
			batchNode.run();
		}
		while (true) {
			try {
				if (sqlSession == null) {
					sqlSession = IbatisSessionFactory.openSession(dbName);
				}
				List<BCO30223> workOrderList = sqlSession.selectList("sql_itms_work_order.SELECT_BCO30223", paramMap);
				if (workOrderList != null) {
					for (BCO30223 orderVo : workOrderList) {
						DbBatchNode node = batchMap.get(orderVo.getSumOperId());
						if (node == null) {
							// need re-check
							logger.error(String.format("failed to find in map (sumOperId=%s)",orderVo.getSumOperId()));
							paramMap.put("sumOperId", orderVo.getSumOperId());
							BCO30321 operVo = sqlSession.selectOne("sql_itms_work_order.SELECT_BCO30321_BY_SUMOPERID", paramMap);
							if (operVo == null) {
								logger.error(String.format("failed to find in db (sumOperId=%s)",orderVo.getSumOperId()));
								continue;
							}
							node = new DbBatchNode(operVo.getSumOperId(), operVo.getDbNm(), retryMaxNo);
							batchMap.put(operVo.getSumOperId(), node);
							node.run();
						}
						orderVo.setOperExecYn("R");
						sqlSession.update("sql_itms_work_order.UPDATE_BCO30223_R", orderVo);
						sqlSession.commit();
						node.add(orderVo);
					}
				}
				Thread.sleep(sleepSec*1000);
				sqlSession.clearCache();
			} catch (PersistenceException pe) {
				logger.error("PersistenceException", pe);
				sqlSession.close();
				sqlSession = null;
			} catch (SQLRecoverableException sre) {
				logger.error("SQLRecoverableException", sre);
				sqlSession.close();
				sqlSession = null;
			} catch (SQLException se) {
				logger.error("SQLException", se);
				sqlSession.close();
				sqlSession = null;
			} catch (Exception e) {
				logger.error("Exception", e);
			}
		}
	}
	
	class DbBatchNode {
		String			operId;
		String			dbNm;
		List<String>	sqlIdList;
		Thread			worker;
		BlockingQueue<BCO30223>	blockingQueue;
		int				retryMaxNo;
		
		public DbBatchNode(String operId, String dbNm, int retryMaxNo) {
			this.operId = operId;
			this.dbNm = dbNm;
			this.retryMaxNo = retryMaxNo;
			sqlIdList = new LinkedList<String>();
			blockingQueue = new LinkedBlockingQueue();
		}

		public void add(BCO30321 operVo) {
			sqlIdList.add(operVo.getOperSqlId());
		}

		public void run() {
			worker = new Thread(new Runner(this));
			worker.start();
		}
		
		public void add(BCO30223 orderVo) {
			this.blockingQueue.add(orderVo);
		}

	}

	class Runner implements Runnable {
		DbBatchNode node;
		private	SqlSession	sqlSession;

		public Runner(DbBatchNode node) {
			this.node = node;
		}

		@Override
		public void run() {
			logger.info(String.format("[%s] running", node.operId));
			BCO30223 orderVo = null;
			boolean execResult = true;
			int execNo = 0;
			boolean retry = false;
			while (true) {
				try {
					if (execResult == true) {
						execNo = 0;
						orderVo = node.blockingQueue.take();
						retry = false;
					} else {
						if (sqlSession == null) {
							logger.info("re-connect db");
							sqlSession = IbatisSessionFactory.openSession(node.dbNm);
						}						
						if (orderVo.getFailRetryYn().equals("Y") && execNo < node.retryMaxNo) {
							// re-exec
							orderVo.setOperExecYn("R");
							sqlSession.update("sql_itms_work_order.UPDATE_BCO30223", orderVo);
							sqlSession.commit();
							retry = true;
						} else {
							execResult = true;
							continue;							
						}
					}
					if (sqlSession != null) {
						// health-check
						try {
							String operStaDtm = sqlSession.selectOne("sql_itms_work_order.SELECT_CURR_DTM");
						} catch (Exception e) {
							sqlSession.close();
							sqlSession = null;
						}
					}
					if (sqlSession == null) {
						sqlSession = IbatisSessionFactory.openSession(node.dbNm);
					}
					logger.info(String.format("[%s] (sumOperId=%s),(mntrDthm=%s)", node.operId, orderVo.getSumOperId(), orderVo.getMntrDthm()));
					execNo ++;
					execResult = false;
					doIt(orderVo, retry);
					orderVo.setOperExecYn("Y");
					sqlSession.update("sql_itms_work_order.UPDATE_BCO30223", orderVo);
					sqlSession.commit();
					execResult = true;
				} catch (PersistenceException pe) {
					logger.error(String.format("[%s] PersistenceException", node.operId), pe);
					sqlSession.close();
					sqlSession = null;
				} catch (SQLRecoverableException sre) {
					logger.error(String.format("[%s] SQLRecoverableException", node.operId), sre);
					sqlSession.close();
					sqlSession = null;
				} catch (SQLException se) {
					logger.error(String.format("[%s] SQLException", node.operId), se);
					logger.error("rollback...");
					sqlSession.rollback();
					try {
						orderVo.setOperExecYn("E");
						String errMsg = se.getMessage();
						if (errMsg.length() > 3000) {
							errMsg = errMsg.substring(0, 3000);
						}
						orderVo.setErrMsg(errMsg);
						sqlSession.update("sql_itms_work_order.UPDATE_BCO30223", orderVo);
						sqlSession.commit();
					} catch (Exception se2) {
						sqlSession.close();
						sqlSession = null;
					}
				} catch (Exception e) {
					logger.error(String.format("[%s] Exception", node.operId), e);
					logger.error("rollback...");
					sqlSession.rollback();
					orderVo.setOperExecYn("E");
					try {
						sqlSession.update("sql_itms_work_order.UPDATE_BCO30223", orderVo);
						sqlSession.commit();
					} catch (Exception se2) {
						sqlSession.close();
						sqlSession = null;
					}
					
				}
			}
		}
		
		private void doIt(BCO30223 orderVo, boolean retry) throws Exception {
			HashMap<String,String> paramMap = new HashMap<String,String>();
			paramMap.put("mntrDthm", orderVo.getMntrDthm());
			int maxInsertNo = 0;
			String operStaDtm = sqlSession.selectOne("sql_itms_work_order.SELECT_CURR_DTM");
			if (retry) {
				orderVo.setRetryOperStaDtm(operStaDtm);
			} else {
				orderVo.setOperStaDtm(operStaDtm);
			}
			StringBuilder sb = new StringBuilder();
			for (String sqlId : node.sqlIdList) {
				long before = System.currentTimeMillis();
				int insertNo = sqlSession.insert(sqlId, paramMap);
				long after = System.currentTimeMillis();
				long elapsedTimeMilles = after - before;
				logger.info(String.format("[%s] executed %s (elapsed-time: %d)", node.operId, sqlId, elapsedTimeMilles));

				if (maxInsertNo < insertNo) maxInsertNo = insertNo;
				if (sb.length() > 0) {
					sb.append(", ");
				}
				sb.append(String.format("(%s : inserted %d, elapsed-time = %d ms)", sqlId, insertNo, elapsedTimeMilles));
			}
			String operFnshDtm = sqlSession.selectOne("sql_itms_work_order.SELECT_CURR_DTM");
			if (retry) {
				orderVo.setRetryOperFnshDtm(operFnshDtm);
			} else {
				orderVo.setOperFnshDtm(operFnshDtm);
			}
			BCO30224 orderLogVo = new BCO30224();
			orderLogVo.setTblNm(orderVo.getTblNm());
			orderLogVo.setMntrDthm(orderVo.getMntrDthm());
			orderLogVo.setAuditId("workOrder");
			orderLogVo.setDataAllCnt(maxInsertNo);
			orderLogVo.setLogUseFnshYn("N");
			orderLogVo.setOperStaDtm(operStaDtm);
			orderLogVo.setOperFnshDtm(operFnshDtm);
			String operRsltCtt = sb.toString();
			if (operRsltCtt.length() > 200) {
				operRsltCtt = operRsltCtt.substring(0, 199);
			}
			orderLogVo.setOperRsltCtt(operRsltCtt);
			sqlSession.insert("sql_itms_work_order.INSERT_BCO30224", orderLogVo);
			sqlSession.commit();
		}
	}
	
	public static void main(String[] args) {
		Options options = new Options();
		Option optProcess = Option.builder().optionalArg(false).longOpt("PROCESS")
				.desc("PROCESS01/PROCESS02/...").hasArg().argName("PROCESS").build();
		options.addOption(optProcess);
		EnvManager envManager = new EnvManager(args, options);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("ItmsWorkOrder", envManager.getOptions());
    		System.exit(0);
    	}
    	ItmsWorkManager workMgr = new ItmsWorkManager(args);
    	try {
			workMgr.run();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
