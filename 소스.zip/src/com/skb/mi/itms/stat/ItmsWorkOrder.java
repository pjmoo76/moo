package com.skb.mi.itms.stat;

import java.io.File;
import java.sql.SQLException;
import java.sql.SQLRecoverableException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.cli.HelpFormatter;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Cron;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.common.StringUtils;

public class ItmsWorkOrder {
	final private String	ServiceName = "ItmsWorkOrder";
	private Logger		logger;
	private	SqlSession	sqlSession;
	private	int			sleepSec;
	private	String		dbName;
	private	List<String>	qidList;
	ArrayList<DelayInfo>	delayInfoList;

	public ItmsWorkOrder(String[] args) {
		logger = LogManager.getLogger(this.getClass().getName());
		logger.info("start");
		loadConfig();
	}
	
	private void loadConfig() {
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		dbName = configManager.getConfig(this.ServiceName, "dbName");
		sleepSec = Integer.parseInt(configManager.getConfig(this.ServiceName, "sleepSec"));
		String[] tokens = configManager.getConfig(this.ServiceName, "qidList").split("\\,");
		qidList = new ArrayList<String>();
		for (int i = 0; i < tokens.length; i ++) {
			qidList.add(tokens[i].trim());
		}
		
		delayInfoList = new ArrayList<DelayInfo>();
		String delay = configManager.getConfig(this.ServiceName, "delay");
		JSONParser jsonParser = new JSONParser();
		try {
			JSONObject jsonObject = (JSONObject) jsonParser.parse(delay);
			Iterator iterator = jsonObject.keySet().iterator();
			while (iterator.hasNext()) {
				String key = (String) iterator.next();
				JSONArray jsonArray = (JSONArray) jsonObject.get(key);
				for (int i = 0; i < jsonArray.size(); i ++) {
					DelayInfo delayInfo = new DelayInfo(jsonArray.get(i).toString());
					delayInfoList.add(delayInfo);
				}
			}
		} catch (Exception e) {
			logger.error("exception", e);;
		}

		logger.info(String.format("(dbName=%s)", dbName));
		for (int i = 0; i < qidList.size(); i ++) {
			logger.info(String.format("(qidList[%d]=%s)", i, qidList.get(i)));			
		}
		logger.info(String.format("(sleepSec=%d)", sleepSec));
		logger.info(String.format("(delay=%s)", delay));
		for (int i = 0; i < delayInfoList.size(); i ++) {
			DelayInfo delayInfo = delayInfoList.get(i);
			logger.info(String.format("[%d] (delayStartTimeCron=%s),(delayEndTimeCron=%s),(delayMin=%d)"
					, i
					, delayInfo.delayStartTimeCron.getCronString()
					, delayInfo.delayEndTimeCron.getCronString()
					, delayInfo.delayMin
					));
		}
	}
	
	class DelayInfo {
		Cron	delayStartTimeCron;
		Cron	delayEndTimeCron;
		int		delayMin;
		
		public DelayInfo(String delayInfoStr) {
			JSONParser jsonParser = new JSONParser();
			try {
				JSONObject jsonObject = (JSONObject) jsonParser.parse(delayInfoStr);
				Iterator iterator = jsonObject.keySet().iterator();
				while (iterator.hasNext()) {
					String key = (String) iterator.next();
					String val = (String) jsonObject.get(key);
					logger.info(String.format("(%s),(%s)", key, val));
					// {"delayStartTime":"0 20 * * 0","delayEndTime":"59 23 * * 0","delayMin":"10"}
					if ("delayStartTime".equalsIgnoreCase(key)) {
						delayStartTimeCron = new Cron();
						delayStartTimeCron.setCron(val);
					} else if ("delayEndTime".equalsIgnoreCase(key)) {
						delayEndTimeCron = new Cron();
						delayEndTimeCron.setCron(val);
					} else if ("delayMin".equalsIgnoreCase(key)) {
						if (val == null || val.isEmpty()) {
							delayMin = 0;
						} else {
							delayMin = Integer.parseInt(val);
						}
					}
				}
			} catch (Exception e) {
				logger.error("exception", e);
			}
		}
		
		boolean inDelay(long mstime) {
			if (delayStartTimeCron == null || delayEndTimeCron == null || delayMin == 0) return false;
			return Cron.in(delayStartTimeCron, delayEndTimeCron, mstime);
		}
	}
	
	public void run() throws Exception {
		logger.info("run");
		/*
		 * 0 : delay 전
		 * 1 : delay 구간
		 * 2 : delay 구간에서 막 빠져 나온 상태
		 */
		int delayStatus = 0;
		int oldDelayMin = 0;
		while (true) {
			try {
				Thread.sleep(sleepSec*1000);
				
				if (sqlSession == null) {
					sqlSession = IbatisSessionFactory.openSession(dbName);
				}
				
				int delayMin = getDelayMin();
				if (delayMin > 0) {
					delayStatus = 1;
					oldDelayMin = delayMin;
				} else {
					if (delayStatus == 1) {
						delayStatus = 2;
					} else {
						delayStatus = 0;
					}
				}
				logger.info(String.format("(delayStatus=%d),(delayMin=%d)", delayStatus, delayMin));
				
				HashMap<String,String> paramMap = new HashMap<String,String>();
				if (delayStatus == 2) { /* delay 해제 되어 정상 시점에 생성하게 될 때 빠진 구간을 생성. 5분 단위 */
					while (oldDelayMin > 0) {
						logger.info(String.format("inserting missed-period by delay mechanism (delayStatus=%d),(delayMin=%d)", delayStatus, oldDelayMin));
						paramMap.put("delayMin", ""+oldDelayMin);
						for (String qid : qidList) {
							sqlSession.insert(qid, paramMap);
						}
						oldDelayMin -= 5;
					}
				}
				
				paramMap.put("delayMin", ""+delayMin);
				for (String qid : qidList) {
					sqlSession.insert(qid, paramMap);
				}
				sqlSession.commit();
			} catch (PersistenceException pe) {
				logger.error("Exception", pe);
				sqlSession.close();
				sqlSession = null;
			} catch (SQLRecoverableException sre) {
				logger.error("Exception", sre);
				sqlSession.close();
				sqlSession = null;
			} catch (SQLException se) {
				logger.error("Exception", se);
				sqlSession.close();
				sqlSession = null;
			} catch (Exception e) {
				logger.error("Exception", e);
			}
		}
	}
	
	private int getDelayMin() {
		long mstime = System.currentTimeMillis();
		for (int i = 0; i < delayInfoList.size(); i ++) {
			DelayInfo delayInfo = delayInfoList.get(i);
			if (delayInfo.inDelay(mstime)) {
				return delayInfo.delayMin;
			}
		}
		return 0;
	}
	
	public static void main(String[] args) {
		EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("ItmsWorkOrder", envManager.getOptions());
    		System.exit(0);
    	}
		ItmsWorkOrder workOrder = new ItmsWorkOrder(args);
		try {
			workOrder.run();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
