package com.skb.mi.itms.report;

import java.io.File;
import java.sql.SQLException;
import java.sql.SQLRecoverableException;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.apache.commons.cli.HelpFormatter;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.itms.model.BCO30401;

public class ItmsUserReportManager {
	private	String		serviceName;
	private Logger		logger;
	private	SqlSession	sqlSession;
	private	String		dbName;
	private	int			sleepSec;
	private	String		rootDir;
	
	private	HashMap<String, ItmUserReportTasker> ItmUserReportTaskerMap;
	
	public ItmsUserReportManager(String[] args) {
		serviceName = "ItmsUserReportManager";
		logger = LogManager.getLogger(serviceName);
		logger.info("start");
		ItmUserReportTaskerMap = new HashMap<String, ItmUserReportTasker>();
		loadConfig();
	}

	private void loadConfig() {
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		dbName = configManager.getConfig(this.serviceName, "dbName");
		sleepSec = Integer.parseInt(configManager.getConfig(this.serviceName, "sleepSec"));
		rootDir = configManager.getConfig(this.serviceName, "rootDir");
		
		logger.info(String.format("(dbName=%s)", dbName));
		logger.info(String.format("(sleepSec=%d)", sleepSec));
		logger.info(String.format("(rootDir=%s)", rootDir));
	}

	public void run() throws Exception {
		logger.info("run");
		while (true) {
			try {
				logger.info("...");
				Thread.sleep(sleepSec*1000);
				if (sqlSession == null) {
					sqlSession = IbatisSessionFactory.openSession(dbName);
				}
				sqlSession.clearCache();
				List<BCO30401> bco30401List = sqlSession.selectList("sql_itms_user_report.SELECT_BCO30401", null);
				if (bco30401List != null) {
					for (BCO30401 node : bco30401List) {
						ItmUserReportTasker task = ItmUserReportTaskerMap.get(node.getItmRptTypCd());
						if (task == null) {
							task = new ItmUserReportTasker(rootDir, node.getItmRptTypCd());
							ItmUserReportTaskerMap.put(node.getItmRptTypCd(), task);
							task.run();
						}
						task.add(node);
					}
				}
			} catch (PersistenceException pe) {
				logger.error("Exception", pe);
				sqlSession.close();
				sqlSession = null;
			} catch (SQLRecoverableException sre) {
				logger.error("Exception", sre);
				sqlSession.close();
				sqlSession = null;
			} catch (SQLException se) {
				logger.error("Exception", se);
				sqlSession.close();
				sqlSession = null;
			} catch (Exception e) {
				logger.error("Exception", e);
			}
		}
	}
	
	class ItmUserReportTasker {
		String			rootDir;
		String			itmRptTypCd;
		Thread			worker;
		BlockingQueue<BCO30401> blockingQueue;
		
		public ItmUserReportTasker(String rootDir, String itmRptTypCd) {
			this.rootDir = rootDir;
			this.itmRptTypCd = itmRptTypCd;
			blockingQueue = new LinkedBlockingQueue();
		}

		public void run() {
			worker = new Thread(new Runner(this));
			worker.start();
		}
		
		public void add(BCO30401 userReport) {
			logger.info(String.format("added [%s] (itmRptTypCd=%s),(rptReqDtm=%s),(reqrId=%s)", itmRptTypCd, userReport.getItmRptTypCd(), userReport.getRptReqDtm(), userReport.getReqrId()));
			this.blockingQueue.add(userReport);
		}
	}
	
	class Runner implements Runnable {
		ItmUserReportTasker task;
		private	SqlSession	sqlSession;

		public Runner(ItmUserReportTasker task) {
			this.task = task;
		}

		@Override
		public void run() {
			logger.info(String.format("[%s] running", task.itmRptTypCd));
			BCO30401 userReport = null;
			while (true) {
				try {
					userReport = task.blockingQueue.take();
					if (sqlSession != null) {
						// health-check
						try {
							String currDtm = sqlSession.selectOne("sql_itms_user_report.SELECT_CURR_DTM");
						} catch (Exception e) {
							sqlSession.close();
							sqlSession = null;
						}
					}
					if (sqlSession == null) {
						sqlSession = IbatisSessionFactory.openSession(dbName);
					}
					logger.info(String.format("[%s] (rptReqDtm=%s),(reqrId=%s)", task.itmRptTypCd, userReport.getRptReqDtm(), userReport.getReqrId()));
					sqlSession.update("sql_itms_user_report.UPDATE_BCO30401_START", userReport);
					sqlSession.commit();

					doIt(userReport);

					sqlSession.update("sql_itms_user_report.UPDATE_BCO30401_SUCC", userReport);
					sqlSession.commit();
				} catch (SQLRecoverableException sre) {
					logger.error("exception", sre);
					logger.error(String.format("[%s] Exception (rptReqDtm=%s),(reqrId=%s)", task.itmRptTypCd, userReport.getRptReqDtm(), userReport.getReqrId()));
					sqlSession.close();
					sqlSession = null;
				} catch (SQLException se) {
					logger.error("exception", se);
					logger.error("rollback...");
					sqlSession.rollback();
					logger.error(String.format("[%s] Exception (rptReqDtm=%s),(reqrId=%s)", task.itmRptTypCd, userReport.getRptReqDtm(), userReport.getReqrId()));
					try {
						sqlSession.update("sql_itms_user_report.UPDATE_BCO30401_FAIL", userReport);
						sqlSession.commit();
					} catch (Exception se2) {
						sqlSession.close();
						sqlSession = null;
					}
				} catch (Exception e) {
					logger.error("exception", e);
					logger.error("rollback...");
					sqlSession.rollback();
					logger.error(String.format("[%s] Exception (rptReqDtm=%s),(reqrId=%s)", task.itmRptTypCd, userReport.getRptReqDtm(), userReport.getReqrId()));
					sqlSession.update("sql_itms_user_report.UPDATE_BCO30401_FAIL", userReport);
					sqlSession.commit();
				}
			}
		}
		
		private void doIt(BCO30401 userReport) throws Exception {
			ItmsUserReportMaker userReportMaker = new ItmsUserReportMaker();
			userReportMaker.doIt(task.rootDir, sqlSession, userReport);
		}
	}
	

	public static void main(String[] args) {
		EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("ItmsUserReportManager", envManager.getOptions());
    		System.exit(0);
    	}
    	ItmsUserReportManager userReportMgr = new ItmsUserReportManager(args);
    	try {
    		userReportMgr.run();
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
	}

}
