package com.skb.mi.itms.report;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.ibatis.session.ResultContext;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.skb.mi.itms.model.BCO30401;

public class ItmsUserReportMaker implements ResultHandler {
	private Logger		logger;
	private	SqlSession	sqlSession;
	private	BCO30401	userReport;
	private	FileOutputStream	fw;
	private	long				recNo;
	
	public ItmsUserReportMaker() {
		logger = LogManager.getLogger(this.getClass().getName());
	}
	
	public boolean doIt(String rootDir, SqlSession sqlSession, BCO30401 userReport) throws Exception {
		this.sqlSession = sqlSession;
		this.userReport = userReport;
		
		String qid = "sql_itms_user_report.SELECT_USER_REPORT_" + userReport.getItmRptTypCd();
		HashMap<String,String> paramMap = getParamMap(userReport);

		// directory : /ndata/ITMS/user_report/{YYYYMMDD}/{RPT_REQ_DTM}-{ITM_RPT_TYP_CD}-{REQR_ID}.csv
		String dirName = String.format("%s/%s", rootDir, userReport.getRptReqDtm().substring(0, 8));
		File theDir = new File(dirName);
		if (!theDir.exists()) {
			theDir.mkdir();
		}
		String fileName = String.format("%s-%s-%s.csv"
				, userReport.getRptReqDtm()
				, userReport.getItmRptTypCd()
				, userReport.getReqrId());
		String fullPath = dirName + "/" + fileName;
		fw = new FileOutputStream(fullPath);
		recNo = 0;
		
		logger.info(String.format("starting (itmRptTypCd=%s),(rptReqDtm=%s),(reqrId=%s)", userReport.getItmRptTypCd(), userReport.getRptReqDtm(), userReport.getReqrId()));

		sqlSession.select(qid, paramMap, this);
		
		fw.close();
		
		logger.info(String.format("completed. (itmRptTypCd=%s),(rptReqDtm=%s),(reqrId=%s),(recNo=%d)", userReport.getItmRptTypCd(), userReport.getRptReqDtm(), userReport.getReqrId(), recNo));
		
		userReport.setRptCreUrl(dirName + "/");
		userReport.setFileNm(fileName);
		File file = new File(fullPath);
		userReport.setFileSize(file.length());

		return true;
	}
	
	private HashMap<String,String> getParamMap(BCO30401 userReport) {
		HashMap<String,String> paramMap = null;
		if ("34".equals(userReport.getItmRptTypCd())) {
			paramMap = new HashMap<String,String>();
			paramMap.put("strdDtm", userReport.getStrdDtm());
			paramMap.put("teamOrgId", userReport.getTeamOrgId());
			String infoCntrCd = userReport.getInfoCntrCd(); 
			if (infoCntrCd != null && !infoCntrCd.isEmpty()) {
				paramMap.put("infoCntrCd", infoCntrCd);
			}
		}
		return paramMap;
	}

	@Override
	public void handleResult(ResultContext context) {
		LinkedHashMap<String,Object> record = (LinkedHashMap<String,Object>) context.getResultObject();
		recNo ++;
		try {
			if ("34".equals(userReport.getItmRptTypCd())) {
				write32(record);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void write32(LinkedHashMap<String,Object> record) throws IOException {
		Iterator it = record.entrySet().iterator();
		boolean flag = false;
		while (it.hasNext()) {
			if (flag) {
				fw.write(',');
			} else {
				flag = true;
			}
			Map.Entry pair = (Map.Entry)it.next();
			String val = "\"" + (String) pair.getValue() + "\"";
			fw.write(val.getBytes(Charset.forName("eucKR")));
		}
		fw.write('\n');
	}

}
