package com.skb.mi.itms.cm;

import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.EnvManager;

/*
 * ADAMS 에서 ADAMSBS 로 연동된 테이블에 대한 sync 처리
 * - WAS 에서 ADAMSBS 의 OIV/OMN 테이블들에 대한 insert/update/delete 권한이 없음
 * - UI 에서 해당 모델에 대한 변경을 하고자 하는 경우, ADAMS DB로 한 후 sync 요청을 해야 함
 * 
 * adamsitmsts02 서버에서 운영
 * - 설정정보는 mi-itms-service-prd.xml 파일에 있음. default로 20090 port 로 listen함
 */

public class CmInfoSyncker {	
	final private String	ServiceName = "CmInfoSyncker"; 
	private Logger	logger;
	private HashMap<String,CmInfoSyncHandler>	syncHandlerMap;
	private	int		listenPortNo;
	private	String	sourceDbName;
	private	String	destDbName;

	public CmInfoSyncker(String[] args) {
		logger = LogManager.getLogger(this.getClass().getName());
		logger.info("start");
		syncHandlerMap = new HashMap<String,CmInfoSyncHandler>();
		
		loadConfig();
		
		ServerSocket serverSocket = null;
		try {
			logger.info("listen " + listenPortNo);
			serverSocket = new ServerSocket(listenPortNo);
		} catch (IOException e) {
			logger.error("failed to open server-socket", e);
			System.exit(0);
		}
		while (true) {
			try {
				Socket sock = serverSocket.accept();
				CmInfoSyncTasker task = new CmInfoSyncTasker(this, sock);
				task.start();
			} catch (IOException e) {
				logger.error("failed to accept socket", e);
				break;
			}
		}
	}

	private void loadConfig() {
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		listenPortNo = Integer.parseInt(configManager.getConfig(this.ServiceName, "listenPortNo"));
		sourceDbName = configManager.getConfig(this.ServiceName, "sourceDbName");
		destDbName = configManager.getConfig(this.ServiceName, "destDbName");
		logger.info(String.format("(listenPortNo=%d)", listenPortNo));
		logger.info(String.format("(sourceDbName=%s)", sourceDbName));
		logger.info(String.format("(destDbName=%s)", destDbName));
	}

	public String getSourceDbName() {
		return sourceDbName;
	}

	public String getDestDbName() {
		return destDbName;
	}

	public synchronized CmInfoSyncHandler getSyncHandler(String tableName) {
		tableName = tableName.trim().toUpperCase();
		if (false == isValid(tableName)) return null; 
		CmInfoSyncHandler syncHandler = syncHandlerMap.get(tableName);
		if (syncHandler == null) {
			syncHandler = new CmInfoSyncHandler(this, tableName);
			syncHandlerMap.put(tableName, syncHandler);
		}
		return syncHandler;
	}
	
	private boolean isValid(String tableName) {
		if ("OIV25610".equals(tableName)) {
			return true;
		} else if ("OIV25620".equals(tableName)) {
			return true;
		} else if ("OMN10233".equals(tableName)) {
			return true;
		} else if ("OMN10427".equals(tableName)) {
			return true;
		} else if ("OMN20515".equals(tableName)) {
			return true;
		} else {
			logger.error("(" + tableName + ") is not supported");
			return false;
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("CmInfoSyncker", envManager.getOptions());
    		System.exit(0);
    	}
    	new CmInfoSyncker(args);
	}
}
