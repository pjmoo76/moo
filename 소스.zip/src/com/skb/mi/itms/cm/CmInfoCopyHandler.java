package com.skb.mi.itms.cm;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.Cron;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.common.MiscUtils;
import com.skb.mi.common.PerThreadDailyRollingFileAppender;
import com.skb.mi.itms.cm.copy.CmCopier;
import com.skb.mi.model.BCO30340;

public class CmInfoCopyHandler {
	final private String	ServiceName = "CmInfoCopyHandler"; 
	private Logger	logger;
	private	String	sourceDbName;
	private	String	destDbName;
	private	String	logDbName;
	private	int		maxReadSize;
	private List<InfoNode> infoNodeList;
	private	String	processName;
	private	Cron	cron = null;
	private	boolean	isThread = false;
	
	public CmInfoCopyHandler(String[] args) {
		processName = EnvManager.env.getOptionValue("PROCESS");
		String tableName = EnvManager.env.getOptionValue(Constants.TABLE);
		String runningMode = EnvManager.env.getOptionValue("RUNNING_MODE");

		if (processName != null) {
			PerThreadDailyRollingFileAppender.LOG_POSTFIX = processName;
		} else if (tableName != null) {
			PerThreadDailyRollingFileAppender.LOG_POSTFIX = tableName;
		} else if (runningMode != null) {
			PerThreadDailyRollingFileAppender.LOG_POSTFIX = runningMode;			
		}
		logger = LogManager.getLogger(this.getClass().getName());

		InfoNode infoNode = null;
		try {
			loadConfig();
			if (tableName != null) {
				for (int i = 0; i < infoNodeList.size(); i ++) {
					InfoNode node = infoNodeList.get(i);
					if (node.tableName.equalsIgnoreCase(tableName)) {
						node.doIt(false);
					}
				}
				return;
			}
			if ("BATCH".equals(runningMode)) {
				for (int i = 0; i < infoNodeList.size(); i ++) {
					InfoNode node = infoNodeList.get(i);
					logger.info(String.format("start copying %s", node.tableName));
					node.doIt(false);
				}
			} else if (processName != null && !processName.isEmpty()) {
				run();
			} else if ("DAEMON".equals(runningMode)) {
				run();
			}
		} catch (Exception e) {
			logger.error("Exception", e);
			if (infoNode != null) {
				String errCtt = e.getMessage();
				if (errCtt.length() > 3000) {
					errCtt = errCtt.substring(0,3000);
				}
				infoNode.copier.getBco30340().setLnkgErrCtt(errCtt);
				logDb(infoNode.copier.getBco30340());
			}
			return;
		}
	}
	
	private void loadConfig() throws Exception {
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		String targetService = null;
		if (processName != null && !processName.isEmpty()) {
			targetService = processName;
		} else {
			targetService = this.ServiceName;
		}
		ConfigManager configManager = new ConfigManager(cfgFile);
		sourceDbName = configManager.getConfig(targetService, "sourceDbName");
		destDbName = configManager.getConfig(targetService, "destDbName");
		logDbName = configManager.getConfig(targetService, "logDbName");
		maxReadSize = Integer.parseInt(configManager.getConfig(targetService, "maxReadSize"));
		String cronStr = configManager.getConfig(targetService, "cron");
		String parallel = configManager.getConfig(targetService, "parallel");

		logger.info(String.format("(sourceDbName=%s)", sourceDbName));
		logger.info(String.format("(destDbName=%s)", destDbName));
		logger.info(String.format("(logDbName=%s)", logDbName));
		logger.info(String.format("(maxReadSize=%d)", maxReadSize));
		logger.info(String.format("(cron=%s)", cronStr));
		logger.info(String.format("(parallel=%s)", parallel));
		
		if ("true".equalsIgnoreCase(parallel)) {
			isThread = true;
		} else {
			isThread = false;
		}

		String target[] = configManager.getConfig(targetService, "target").split(",");
		String configVal = configManager.getConfig(targetService, "preDelete");
		HashMap<String,String> preDeleteMap = new HashMap<String,String>();
		if (configVal != null) {
			String tokens[] = configVal.split(",");
			for (int i = 0; i < tokens.length; i ++) {
				String val = tokens[i].trim();
				preDeleteMap.put(val, val);
			}
		}
		infoNodeList = new ArrayList<InfoNode>();
		cron = new Cron();
		if (cronStr != null) {
			cron.setCron(cronStr);
		}
		for (int i = 0; i < target.length; i ++) {
			InfoNode node = new InfoNode();
			node.caller = this;
			node.tableName = target[i].trim();
			node.copier = getCmCopier(node.tableName);
			//
			String val = preDeleteMap.get(node.tableName);
			if (val != null) {
				node.copier.setPreDelete(true);
			}
			
			infoNodeList.add(node);
			logger.info(String.format("[%d](%s)", i+1, node.tableName));
		}
	}
	
	private void run() {
		while (true) {
			MiscUtils.sleep(MiscUtils.getNextMinuteMills());
			long mstime = System.currentTimeMillis();
			if (cron.isOnTime(mstime)) {
				for (int i = 0; i < infoNodeList.size(); i ++) {
					InfoNode node = infoNodeList.get(i);
					logger.info(String.format("start copying %s", node.tableName));
					node.doIt(isThread);
				}
			}
		}
	}
	
	synchronized private void logDb(BCO30340 bco30340) {
		SqlSession logSqlSession;
		try {
			logSqlSession = IbatisSessionFactory.openSession(logDbName);
			logSqlSession.insert("sql_itms_cm_info_copier.MERGE_BCO30340", bco30340);
			logSqlSession.commit();
			
			// E2E copy 후 STB 구성정보 생성 프로세스 수행하기위해  STB 배치 이력 테이블에 insert. (2023.05.31)
			String currTableName = bco30340.getClctTblNm();
			if("OIV10671".equals(currTableName) || "OIV10672".equals(currTableName) || "OIV10673".equals(currTableName)
					) {
				
				if(bco30340.isWorkSuccess()) {
					
					logSqlSession.insert("sql_itms_cm_info_copier.INSERT_BCO30224_FOR_WORKORDER", bco30340);
					logSqlSession.commit();	
					logger.info(String.format("work success - logging BCO30224 (STB workOrder) %s", currTableName));
					
				} else {
					logger.info(String.format("work fail - skip logging BCO30224 (STB workOrder) %s", currTableName));
				}
				
			} else {
				logger.info(String.format("not target STB workOrder - skip logging BCO30224 (STB workOrder) %s", currTableName));
			}
			
			logSqlSession.close();
			
		} catch (Exception e) {
			logger.error("Exception", e);
		}
	}

	private CmCopier getCmCopier(String tableName) {
		tableName = tableName.toUpperCase();
		CmCopier copier = new CmCopier();
		copier.setTableName(tableName);
		copier.setSourceDb(sourceDbName);
		copier.setDestDb(destDbName);
		copier.setMaxReadSize(maxReadSize);
		copier.setSelectQid("sql_itms_cm_info_copier.SELECT_" + tableName);
		
		// OIV10671 : org-Qid, dest-Qid 분리 Song (2023-02-20)
		copier.setSelectDestQid("sql_itms_cm_info_copier.SELECT_DEST_" + tableName);
		
		copier.setInsertQid("sql_itms_cm_info_copier.INSERT_" + tableName);
		copier.setUpdateQid("sql_itms_cm_info_copier.UPDATE_" + tableName);
		copier.setDeleteQid("sql_itms_cm_info_copier.DELETE_" + tableName);
		copier.setDeleteAllQid("sql_itms_cm_info_copier.DELETE_ALL_" + tableName);
		return copier;
	}
	
	class InfoNode {
		String		tableName;
		Thread		worker;
		CmCopier	copier;
		CmInfoCopyHandler	caller;

		public void doIt(boolean isThread) {
			if (isThread) {
				run();
			} else {
				work();
			}
		}

		public void run() {
			worker = new Thread(new Runner(this));
			worker.start();
		}
		
		public void work() {
			logger.info(String.format("work(%s)", tableName));
			try {
				if(copier.doIt()){
					copier.getBco30340().setWorkSuccess(true);
					caller.logDb(copier.getBco30340());
					logger.info(String.format("did work(%s)", tableName));
				}else{
					logger.info(String.format("cancel work(%s)", tableName));
				}
				
			} catch (Exception e) {
				logger.error("Exception", e);
				String errCtt = e.getMessage();
				if (errCtt.length() > 3000) {
					errCtt = errCtt.substring(0,3000);
				}
				copier.getBco30340().setWorkSuccess(false);
				copier.getBco30340().setLnkgErrCtt(errCtt);
				caller.logDb(copier.getBco30340());
				copier.clearSession();
			}
			

		}
	}
	
	class Runner implements Runnable {
		InfoNode infoNode;

		public Runner(InfoNode infoNode) {
			this.infoNode = infoNode;
		}
		@Override
		public void run() {
			logger.info(String.format("thread: work(%s)", infoNode.tableName));
			infoNode.work();
		}		
	}
	
	public static void main(String[] args) {
		Options options = new Options();
		Option optProcess = Option.builder().optionalArg(true).longOpt("PROCESS")
				.desc("CmInfoCopyHandler01/CmInfoCopyHandler02/...").hasArg().argName("PROCESS").build();
		options.addOption(optProcess);
		Option optTablName = Option.builder().optionalArg(true).longOpt(Constants.TABLE)
				.desc(Constants.TABLE).hasArg().argName(Constants.TABLE).build();
		options.addOption(optTablName);
		Option optRunningMode = Option.builder().optionalArg(true).longOpt("RUNNING_MODE")
				.desc("BATCH/DAEMON").hasArg().argName("RUNNING_MODE").build();
		options.addOption(optRunningMode);
		EnvManager envManager = new EnvManager(args, options);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("CmInfoCopyHandler", envManager.getOptions());
    		System.exit(0);
    	}
    	new CmInfoCopyHandler(args);
	}
}
