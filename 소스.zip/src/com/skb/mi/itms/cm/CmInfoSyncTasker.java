package com.skb.mi.itms.cm;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class CmInfoSyncTasker extends Thread {
	private Logger		logger;
	private	CmInfoSyncker	parent;
	private	Socket		sock;
	public CmInfoSyncTasker(CmInfoSyncker parent, Socket sock) {
		logger = LogManager.getLogger(CmInfoSyncTasker.class.getName());
		this.parent = parent;
		this.sock = sock;
	}
	
	public void run() {
		logger.debug("run");
		InputStream is = null;
		OutputStream os = null;
		try {
			is = sock.getInputStream();
			os = sock.getOutputStream();
			byte[] buf = new byte[1024];
			int len = is.read(buf);
			if (len == -1) {
				return;
			}
			String msg = new String(buf, 0, len);
			logger.info("msg:" + msg);
			
			JSONParser jsonParser = new JSONParser();
			JSONObject jsonObject = (JSONObject) jsonParser.parse(msg);
			
			String tableName = (String) jsonObject.get("tableName");
			String syncType = (String) jsonObject.get("syncType");
			
			logger.info(String.format("(tableName=%s)", tableName));
			logger.info(String.format("(syncType=%s)", syncType));
			
			boolean ret = true;
			if (tableName == null || syncType == null) {
				ret = false;
			} else {
				CmInfoSyncHandler syncHandler = parent.getSyncHandler(tableName);
				if (syncHandler == null) { 
					logger.info("syncHandler is null");
					ret = false;
				} else {
					ret = syncHandler.doIt(syncType, jsonObject);
				}
			}
			jsonObject = new JSONObject();
			if (ret) {
				jsonObject.put("result", "succ");
			} else {
				jsonObject.put("result", "fail");
			}
			logger.info(jsonObject.toJSONString());
			os.write(jsonObject.toJSONString().getBytes());
			os.write('\n');
			os.flush();
		} catch (Exception e) {
			logger.error("Exception", e);
		}
		try {
			is.close();
		} catch (IOException e) {
		}
		try {
			os.close();
		} catch (IOException e1) {
		}
		try {
			sock.close();
		} catch (IOException e) {
		}
	}
}
