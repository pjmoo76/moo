package com.skb.mi.itms.cm.copy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.ResultContext;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.common.MiscUtils;
import com.skb.mi.model.BCO30340;
import com.skb.mi.model.CopyVO;

public class CmCopier implements ResultHandler {
	private Logger		logger;	
	private	Map<String, CopyVO>	sourceMap;
	protected	SqlSession	sourceSqlSession;
	protected	SqlSession	destSqlSession;
	
	private	String	tableName;
	private	String	sourceDb;
	private	String	destDb;
	private	String	selectQid;
	
	// OIV10671 : org-Qid, dest-Qid 분리 Song (2023-02-20)
	private	String	selectDestQid;
	private	String	insertQid;
	private	String	updateQid;
	private	String	deleteQid;
	private	String	deleteAllQid;
	
	private	boolean	preDelete = false;
	// UK 중복 체크용 (2022-10-20 by KMY)
	private	boolean	dubCheck = false;
	
	private int	readNo = 0;
	private	boolean	cycle = true; 
	private	CopyVO rangeObj;
	private	List<CopyVO>	insertErrObjList;
	private	List<CopyVO>	updateErrObjList;

	private int	insertedNo = 0;
	private int	updatedNo = 0;
	private	int	deletedNo = 0;

	private	int	maxReadSize = 1000000;
	
	static int LOG_DATA_SIZE	= 50000;

	private BCO30340 bco30340;
	
	public CmCopier() {
		logger = LogManager.getLogger(this.getClass().getName());
	}

	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getSourceDb() {
		return sourceDb;
	}
	public void setSourceDb(String soruceDb) {
		this.sourceDb = soruceDb;
	}
	public String getDestDb() {
		return destDb;
	}
	public void setDestDb(String destDb) {
		this.destDb = destDb;
	}
	public String getSelectDestQid() {
		return selectDestQid;
	}
	public void setSelectDestQid(String selectDestQid) {
		this.selectDestQid = selectDestQid;
	}
	public String getSelectQid() {
		return selectQid;
	}
	public void setSelectQid(String selectQid) {
		this.selectQid = selectQid;
	}
	public String getInsertQid() {
		return insertQid;
	}
	public void setInsertQid(String insertQid) {
		this.insertQid = insertQid;
	}
	public String getUpdateQid() {
		return updateQid;
	}
	public void setUpdateQid(String updateQid) {
		this.updateQid = updateQid;
	}
	public String getDeleteQid() {
		return deleteQid;
	}
	public void setDeleteQid(String deleteQid) {
		this.deleteQid = deleteQid;
	}
	public String getDeleteAllQid() {
		return deleteAllQid;
	}
	public void setDeleteAllQid(String deleteAllQid) {
		this.deleteAllQid = deleteAllQid;
	}
	public boolean getPreDelete() {
		return this.preDelete;
	}
	public void setPreDelete(boolean preDelete) {
		this.preDelete = preDelete;
	}
	
	public void setMaxReadSize(int maxReadSize) {
		this.maxReadSize = maxReadSize;
	}

	public int getReadNo() {
		return readNo;
	}
	public int getInsertedNo() {
		return insertedNo;
	}
	public int getUpdatedNo() {
		return updatedNo;
	}
	public int getDeletedNo() {
		return deletedNo;
	}
	public BCO30340 getBco30340() {
		return bco30340;
	}

	public boolean doIt() throws Exception {
		logger.info(String.format("doIt(%s)", this.tableName));
		
		sourceSqlSession = IbatisSessionFactory.openSession(sourceDb);
		destSqlSession = IbatisSessionFactory.openSession(destDb);
		
		bco30340 = new BCO30340();
		bco30340.setOperStaDtm(MiscUtils.getDateTime2());
		bco30340.setClctNmsClCd("-");
		bco30340.setClctTblNm(tableName);
		bco30340.setClctAplyObjTblNm(tableName);
		bco30340.setClctYn("N");
		
		if("OIV10671".equals(this.tableName) || "OIV10672".equals(this.tableName)|| "OIV10673".equals(this.tableName))
		{
			logger.info("E2E 완료 체크 시작");
			String e2eEndFlag = sourceSqlSession.selectOne("SELECT_OIV10660");
			
			if(!"1".equals(e2eEndFlag) )
			{
				logger.info("E2E 미완료");
				return false;
			}
			
			String copyStartFlag = destSqlSession.selectOne("SELECT_BCO30340",this.tableName);
			logger.info("금일 복사 여부 체크 시작");
			if("1".equals(copyStartFlag) )
			{
				logger.info("금일 복사 Y");
				return false;
			}		
		}

		readNo = 0;
		cycle = true;

		long startTime = System.currentTimeMillis();
			
		/* 시작 기록 */
		destSqlSession.insert("sql_itms_cm_info_copier.MERGE_BCO30340", bco30340);
		destSqlSession.commit();
		
		if (getPreDelete()) {
			destSqlSession.delete(deleteAllQid);
		}

		sourceMap = new HashMap<String, CopyVO>();
		insertErrObjList = new ArrayList<CopyVO>();
		updateErrObjList = new ArrayList<CopyVO>();

		
		sourceSqlSession.select(selectQid, null, this);

		processDest();
		// UK 중복 체크용 (2022-10-20 by KMY)
		logger.info(String.format("[%s] set dubCheck (dubCheck=%s)", tableName, dubCheck));
		if (dubCheck) {
			retryErrDataDubChk();
		}
		retryErrData();

		sourceSqlSession.close();
		destSqlSession.close();
		
		bco30340.setOperFnshDtm(MiscUtils.getDateTime2());
		bco30340.setDataAddCnt(insertedNo);
		bco30340.setDataDelCnt(deletedNo);
		bco30340.setDataUpdCnt(updatedNo);
		bco30340.setDataAllCnt(readNo);
		bco30340.setClctYn("Y");
		bco30340.setDataErrCnt(insertErrObjList.size()+updateErrObjList.size());
		
		logger.info(String.format("[%s] readNo - %d", tableName, readNo));
		logger.info(String.format("[%s] inserted - %d", tableName, insertedNo));
		logger.info(String.format("[%s] updated - %d", tableName, updatedNo));
		logger.info(String.format("[%s] deleted - %d", tableName, deletedNo));
		logger.info(String.format("[%s] insert-error - %d", tableName, insertErrObjList.size()));
		logger.info(String.format("[%s] update-error - %d", tableName, updateErrObjList.size()));

		long endTime = System.currentTimeMillis();
		logger.info(String.format("[%s] elapsed time = %d (ms)", tableName, endTime-startTime));

		sourceMap.clear();
		insertErrObjList.clear();
		updateErrObjList.clear();
		System.gc();
		sourceMap = null;
		insertErrObjList = null;
		updateErrObjList = null;
		System.gc();

		return true;
	}
	
	public void clearSession() {
		if (sourceSqlSession != null) sourceSqlSession.close();
		if (destSqlSession != null) destSqlSession.close();
	}

	@Override
	public void handleResult(ResultContext context) {
		CopyVO obj = (CopyVO) context.getResultObject();
		obj.setKey();
		sourceMap.put(obj.getKey(), obj);
		if (cycle) {
			rangeObj = obj;
			logger.info(String.format("[%s] set range-start (key=%s)", tableName, rangeObj.getKey()));
			cycle = false;
			// UK 중복 체크용 (2022-10-20 by KMY)
			dubCheck = obj.getDubChecked();
			logger.info(String.format("[%s] set dubCheck (key=%s)", tableName, dubCheck));
		}
		readNo ++;
		if (readNo % LOG_DATA_SIZE == 0) {
			logger.info(String.format("[%s] read - %d", tableName, readNo));
		}
		if (readNo % maxReadSize == 0) {
			rangeObj.setRange(obj);
			logger.info(String.format("[%s] set range-end (key=%s)", tableName, obj.getKey()));
			processDest();
			cycle = true;
			sourceMap.clear();
		}
	}
	
	private void processDest() {
		logger.info("processDest");
		List<CopyVO> newList = new ArrayList<CopyVO>();
		List<CopyVO> updateList = new ArrayList<CopyVO>();
		List<CopyVO> deleteList = new ArrayList<CopyVO>();
		try {
			this.checkSqlSession(destSqlSession, destDb);
		} catch (Exception e) {
			logger.error("exception", e);
		}
		
		/*
		 * OIV10671 : org-Qid, dest-Qid 분리 Song (2023-02-20)
		 */
		String selectQidTmp = "";
		
		if ("OIV10671".equals(tableName)) {
			selectQidTmp = selectDestQid;
		} else {
			selectQidTmp = selectQid;
		}
		//destSqlSession.select(selectQid, rangeObj, new ResultHandler() {
		destSqlSession.select(selectQidTmp, rangeObj, new ResultHandler() {
			int i = 0;
			@Override
			public void handleResult(ResultContext context) {
				CopyVO obj = (CopyVO) context.getResultObject();
				obj.setKey();
				CopyVO srcObj = sourceMap.get(obj.getKey());
				//logger.info(String.format("[key=%s] (srcObj=%s)", obj.getKey(), srcObj));
				if (srcObj == null) {
					deleteList.add(obj);
					//logger.info(String.format("deleteList [key=%s]", obj.getKey()));
				} else {
					srcObj.checked(true);
					if (false == obj.equals(srcObj)) {
						updateList.add(srcObj);
					}
					//logger.info(String.format("[key=%s] (equals=%s)", obj.getKey(), obj.equals(srcObj)));
				}
				i ++;
				if (i % LOG_DATA_SIZE == 0) {
					logger.info(String.format("[%s] destMap - %d", tableName, i));
				}
			}
		});
		for (Map.Entry<String, CopyVO> entry : sourceMap.entrySet()) {
			CopyVO srcObj = entry.getValue();
			if (false == srcObj.checked()) {
				newList.add(srcObj);
				//logger.info(String.format("newList [key=%s]", srcObj.getKey()));
			}
		}
				
		for (int i = 0; i < newList.size(); i ++) {
			try {
				destSqlSession.insert(insertQid, newList.get(i));
				insertedNo ++;
			} catch (PersistenceException e) {
				logger.error("insert error", e);
				insertErrObjList.add(newList.get(i));
				String errCtt = e.getMessage();
				if (errCtt.length() > 3000) {
					errCtt = errCtt.substring(0,3000);
				}
				bco30340.setLnkgErrCtt(errCtt);
			}
			if (i > 0 && i % LOG_DATA_SIZE == 0) {
				logger.info(String.format("[%s] inserted %d", tableName, i));
			}
		}
		destSqlSession.commit();

		for (int i = 0; i < updateList.size(); i ++) {
			try {
				destSqlSession.update(updateQid, updateList.get(i));
				updatedNo ++;
			} catch (PersistenceException e) {
				logger.error("update error", e);
				updateErrObjList.add(updateList.get(i));
				String errCtt = e.getMessage();
				if (errCtt.length() > 3000) {
					errCtt = errCtt.substring(0,3000);
				}
				bco30340.setLnkgErrCtt(errCtt);
			}
			if (i > 0 && i % LOG_DATA_SIZE == 0) {
				logger.info(String.format("[%s] updated %d", tableName, i));
			}
		}
		destSqlSession.commit();
		
		for (int i = 0; i < deleteList.size(); i ++) {
			destSqlSession.delete(deleteQid, deleteList.get(i));
			deletedNo ++;
			if (i > 0 && i % LOG_DATA_SIZE == 0) {
				logger.info(String.format("[%s] deleted %d", tableName, i));
			}
		}
		destSqlSession.commit();

		logger.info(String.format("[%s] new - %d", tableName, newList.size()));
		logger.info(String.format("[%s] update - %d", tableName, updateList.size()));
		logger.info(String.format("[%s] delete - %d", tableName, deleteList.size()));
		logger.info(String.format("[%s] insert-error(accum) - %d", tableName, insertErrObjList.size()));
		logger.info(String.format("[%s] update-error(accum) - %d", tableName, updateErrObjList.size()));
	}

	// UK 중복 체크용 (2022-10-20 by KMY)
	private void retryErrDataDubChk() {
		logger.info("retryErrData");
		int updateErrCnt = updateErrObjList.size();
		Iterator<CopyVO> itr = updateErrObjList.iterator();
		HashMap<String, Object> hmap = new HashMap<String,Object>();
		//List<CopyVO>	updateDupObjList;
		//updateDupObjList = new ArrayList<CopyVO>();
		List<HashMap<String, Object>> dataList = new ArrayList<HashMap<String, Object>>();


		while (itr.hasNext()) {
			CopyVO obj = itr.next();
			try {
				if (true == obj.getDubChecked()) {
					obj.setKey();
					hmap = destSqlSession.selectOne(selectQid+"_DUP", obj);
					logger.info(hmap);
					if (hmap != null) {
						String dubYn = (String) hmap.get("DUP_YN");
						logger.info(String.format("[%s] select dup (key=%s, dubYn=%s)", tableName, obj.getKey(), dubYn));
						if (dubYn.equals("Y")) {
							logger.info(String.format("[%s] update dup (key=%s, dubYn=%s)", tableName, obj.getKey(), dubYn));
							dataList.add(hmap);
							//destSqlSession.update(updateQid+"_DUB", obj);
							//itr.remove();
						}
					} else {
						logger.info(String.format("hmap is null!! (key=%s)", obj.getKey()));
					}
				}
			} catch (PersistenceException e) {
				logger.error("update error", e);
				String errCtt = e.getMessage();
				if (errCtt.length() > 3000) {
					errCtt = errCtt.substring(0,3000);
				}
				//bco30340.setLnkgErrCtt(errCtt);
			}
		}
		// DUP check에 해당하는 경우 재처리
		// OIV10800 : 동일한 mac정보가 다른 장비 번호이면 mac정보를 임시로 변경
		for (int i = 0; i < dataList.size(); i ++) {
			try {
				destSqlSession.update(updateQid+"_DUP", dataList.get(i));
				//destSqlSession.update(updateQid+"_DUB", obj);
			} catch (PersistenceException e) {
				logger.error("update error", e);
				String errCtt = e.getMessage();
				if (errCtt.length() > 3000) {
					errCtt = errCtt.substring(0,3000);
				}
				//bco30340.setLnkgErrCtt(errCtt);
			}
		}
		destSqlSession.commit();
		logger.info(String.format("update-error : %d / %d", updateErrObjList.size(), updateErrCnt));
	}
	
	private void retryErrData() {
		logger.info("retryErrData");
		int updateErrCnt = updateErrObjList.size();
		Iterator<CopyVO> itr = updateErrObjList.iterator();
		while (itr.hasNext()) {
			CopyVO obj = itr.next();
			try {
				destSqlSession.update(updateQid, obj);
				itr.remove();
			} catch (PersistenceException e) {
				logger.error("update error", e);
				String errCtt = e.getMessage();
				if (errCtt.length() > 3000) {
					errCtt = errCtt.substring(0,3000);
				}
				bco30340.setLnkgErrCtt(errCtt);
			}
		}
		destSqlSession.commit();
		logger.info(String.format("update-error : %d / %d", updateErrObjList.size(), updateErrCnt));
		
		int insertErrCnt = insertErrObjList.size();
		itr = insertErrObjList.iterator(); 
		while (itr.hasNext()) {
			CopyVO obj = itr.next();
			try {
				destSqlSession.insert(insertQid, obj);
				itr.remove();
			} catch (PersistenceException e) {
				logger.error("insert error", e);
				String errCtt = e.getMessage();
				if (errCtt.length() > 3000) {
					errCtt = errCtt.substring(0,3000);
				}
				bco30340.setLnkgErrCtt(errCtt);
			}
		}
		destSqlSession.commit();
		logger.info(String.format("insert-error : %d / %d", insertErrObjList.size(), insertErrCnt));
		updateErrCnt = updateErrObjList.size();
		insertErrCnt = insertErrObjList.size();
		//SMS 전송 
		if(insertErrCnt+updateErrCnt > 0)
		{
			HashMap<String, String> smsMap = new HashMap<String, String>();
			smsMap.put("insertErrCnt", insertErrCnt+"");
			smsMap.put("updateErrCnt", updateErrCnt+"");
			smsMap.put("tableName", tableName);
			
			try {
				
				SqlSession sourceSqlSession = IbatisSessionFactory.openSession(sourceDb);
				sourceSqlSession.insert("sql_itms_cm_info_copier.MERGE_TBL_SUBMIT_QUEUE", smsMap);
				sourceSqlSession.commit();
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				logger.error("sms error", e);
			}
		}
	}

	private void checkSqlSession(SqlSession sqlSession, String dbName) throws Exception {
		if (sqlSession != null) {
			try {
				sqlSession.clearCache();
				String operStaDtm = sqlSession.selectOne("sql_itms_cm_info_copier.SELECT_CURR_DTM");
				return;
			} catch (Exception e) {
				sqlSession.close();
				sqlSession = null;
			}
		}
		if (sqlSession == null) {
			reconnectDb(sqlSession, dbName);
		}
	}
	
	private boolean reconnectDb(SqlSession sqlSession, String dbName) {
		if (sqlSession != null) {
			sqlSession.close();
			sqlSession = null;
		}
		try {
			sqlSession = IbatisSessionFactory.openSession(dbName);
			logger.info("reconnected " + dbName);
		} catch (Exception e) {
			logger.error("failed to reconnect DB", e);
			return false;
		}
		return true;
	}
}
