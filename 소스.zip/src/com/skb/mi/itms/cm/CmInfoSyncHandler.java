package com.skb.mi.itms.cm;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.itms.model.BCO30321;
import com.skb.mi.model.OIV25610;
import com.skb.mi.model.OIV25620;
import com.skb.mi.model.OMN10233;
import com.skb.mi.model.OMN10427;
import com.skb.mi.model.OMN20515;

public class CmInfoSyncHandler {
	private Logger		logger;
	private String		tableName;
	private	SqlSession	sourceSqlSession;
	private	SqlSession	destSqlSession;
	private	CmInfoSyncker	parent;

	public CmInfoSyncHandler(CmInfoSyncker parent, String tableName) {
		logger = LogManager.getLogger(CmInfoSyncHandler.class.getName());
		this.parent = parent;
		this.tableName = tableName;
	}
	
	public synchronized boolean doIt(String syncType, JSONObject jsonObject) throws Exception {
		logger.debug(this.tableName);
		/*
		 * tableName :
		 * syncType : delete/insert/update
		 * {pk column...}
		 */

		sourceSqlSession = IbatisSessionFactory.openSession(parent.getSourceDbName());
		destSqlSession = IbatisSessionFactory.openSession(parent.getDestDbName());

		syncType = syncType.toUpperCase();
		try {
			if ("OIV25610".equals(tableName)) {
				return doOIV25610(syncType, jsonObject);
			} else if ("OIV25620".equals(tableName)) {
				return doOIV25620(syncType, jsonObject);
			} else if ("OMN10233".equals(tableName)) {
				return doOMN10233(syncType, jsonObject);
			} else if ("OMN10427".equals(tableName)) {
				return doOMN10427(syncType, jsonObject);
			} else if ("OMN20515".equals(tableName)) {
				return doOMN20515(syncType, jsonObject);
			} else {
				logger.error("unsupported table(" + tableName + ")");
				return false;
			}
		} catch (Exception e) {
			logger.error("exception", e);
			return false;
		} finally {
			if (sourceSqlSession != null) {
				sourceSqlSession.close();
			}
			if (destSqlSession != null) {
				destSqlSession.close();
			}
		}
	}
	
	/*--------------------------------------------------------------------------------------------------*/
	
	private boolean doOIV25610(String syncType, JSONObject jsonObject) {
		String iptvChnlSvrMappId = (String) jsonObject.get("iptvChnlSvrMappId");
		if (iptvChnlSvrMappId == null) {
			logger.error("iptvChnlSvrMappId is null");
			return false;
		}
		logger.info("syncType=" + syncType + "," + "iptvChnlSvrMappId=" + iptvChnlSvrMappId);
		if ("DELETE".equals(syncType)) {
			return deleteOIV25610(iptvChnlSvrMappId);
		} else if ("INSERT".equals(syncType)) {
			return insertOIV25610(iptvChnlSvrMappId);
		} else if ("UPDATE".equals(syncType)) {
			return updateOIV25610(iptvChnlSvrMappId);
		} else {
			logger.error("invalid syncType : " + syncType);
			return false;
		}
	}
	
	private OIV25610 getOIV25610(HashMap<String, Object> hmap) {
		return sourceSqlSession.selectOne("sql_itms_cm_info_syncker.SELECT_OIV25610", hmap);
	}
	
	private boolean deleteOIV25610(String iptvChnlSvrMappId) {
		logger.debug("deleteOIV25610");
		HashMap<String, Object> hmap = new HashMap<String, Object>();
		hmap.put("iptvChnlSvrMappId", iptvChnlSvrMappId);
		OIV25610 oiv25610 = getOIV25610(hmap);
		if (oiv25610 == null) {
			destSqlSession.delete("sql_itms_cm_info_syncker.DELETE_OIV25610", hmap);
			destSqlSession.commit();
			return true;
		} else {
			logger.debug(oiv25610.toString());
			logger.error("still exist (iptvChnlSvrMappId=" + iptvChnlSvrMappId + ")");
			return false;
		}
	}

	private boolean insertOIV25610(String iptvChnlSvrMappId) {
		logger.debug("insertOIV25610");
		HashMap<String, Object> hmap = new HashMap<String, Object>();
		hmap.put("iptvChnlSvrMappId", iptvChnlSvrMappId);
		OIV25610 oiv25610 = getOIV25610(hmap);
		if (oiv25610 == null) {
			logger.error("failed to select (iptvChnlSvrMappId=" + iptvChnlSvrMappId + ")");
			return false;
		}
		logger.debug(oiv25610.toString());
		destSqlSession.insert("sql_itms_cm_info_syncker.INSERT_OIV25610", oiv25610);
		destSqlSession.commit();
		return true;
	}

	private boolean updateOIV25610(String iptvChnlSvrMappId) {
		logger.debug("updateOIV25610");
		HashMap<String, Object> hmap = new HashMap<String, Object>();
		hmap.put("iptvChnlSvrMappId", iptvChnlSvrMappId);
		OIV25610 oiv25610 = getOIV25610(hmap);
		if (oiv25610 == null) {
			logger.error("failed to select (iptvChnlSvrMappId=" + iptvChnlSvrMappId + ")");
			return false;
		}
		logger.debug(oiv25610.toString());
		destSqlSession.update("sql_itms_cm_info_syncker.UPDATE_OIV25610", oiv25610);
		destSqlSession.commit();
		return true;
	}

	/*--------------------------------------------------------------------------------------------------*/

	private boolean doOIV25620(String syncType, JSONObject jsonObject) {
		String iptvChnlSvrMappId = (String) jsonObject.get("iptvChnlSvrMappId");
		if (iptvChnlSvrMappId == null) {
			logger.error("iptvChnlSvrMappId is null");
			return false;
		}
		logger.info("syncType=" + syncType + "," + "iptvChnlSvrMappId=" + iptvChnlSvrMappId);
		if ("DELETE".equals(syncType)) {
			return deleteOIV25620(iptvChnlSvrMappId);
		} else if ("INSERT".equals(syncType)) {
			return insertOIV25620(iptvChnlSvrMappId);
		} else if ("UPDATE".equals(syncType)) {
			return updateOIV25620(iptvChnlSvrMappId);
		} else {
			logger.error("invalid syncType : " + syncType);
			return false;
		}
	}
	
	private OIV25620 getOIV25620(HashMap<String, Object> hmap) {
		return sourceSqlSession.selectOne("sql_itms_cm_info_syncker.SELECT_OIV25620", hmap);
	}

	private boolean deleteOIV25620(String iptvChnlSvrMappId) {
		logger.debug("deleteOIV25620");
		HashMap<String, Object> hmap = new HashMap<String, Object>();
		hmap.put("iptvChnlSvrMappId", iptvChnlSvrMappId);
		OIV25620 oiv25620 = getOIV25620(hmap);
		if (oiv25620 == null) {
			destSqlSession.delete("sql_itms_cm_info_syncker.DELETE_OIV25620", hmap);
			destSqlSession.commit();
			return true;
		} else {
			logger.debug(oiv25620.toString());
			logger.error("still exist (iptvChnlSvrMappId=" + iptvChnlSvrMappId + ")");
			return false;
		}
	}

	private boolean insertOIV25620(String iptvChnlSvrMappId) {
		logger.debug("insertOIV25620");
		HashMap<String, Object> hmap = new HashMap<String, Object>();
		hmap.put("iptvChnlSvrMappId", iptvChnlSvrMappId);
		OIV25620 oiv25620 = getOIV25620(hmap);
		if (oiv25620 == null) {
			logger.error("failed to select (iptvChnlSvrMappId=" + iptvChnlSvrMappId + ")");
			return false;
		}
		logger.debug(oiv25620.toString());
		destSqlSession.insert("sql_itms_cm_info_syncker.INSERT_OIV25620", oiv25620);
		destSqlSession.commit();
		return true;
	}

	private boolean updateOIV25620(String iptvChnlSvrMappId) {
		logger.debug("updateOIV25620");
		HashMap<String, Object> hmap = new HashMap<String, Object>();
		hmap.put("iptvChnlSvrMappId", iptvChnlSvrMappId);
		OIV25620 oiv25620 = getOIV25620(hmap);
		if (oiv25620 == null) {
			logger.error("failed to select (iptvChnlSvrMappId=" + iptvChnlSvrMappId + ")");
			return false;
		}
		logger.debug(oiv25620.toString());
		destSqlSession.update("sql_itms_cm_info_syncker.UPDATE_OIV25620", oiv25620);
		destSqlSession.commit();
		return true;
	}
	
	/*--------------------------------------------------------------------------------------------------*/

	private boolean doOMN10233(String syncType, JSONObject jsonObject) {
		String iptvThrsCd = (String) jsonObject.get("iptvThrsCd");
		if (iptvThrsCd == null) {
			logger.error("iptvThrsCd is null");
			return false;
		}
		logger.info("syncType=" + syncType + "," + "iptvThrsCd=" + iptvThrsCd);
		if ("UPDATE".equals(syncType)) {
			return updateOMN10233(iptvThrsCd);
		} else {
			logger.error("not supported syncType : " + syncType);
			return false;
		}
	}

	private OMN10233 getOMN10233(HashMap<String, Object> hmap) {
		return sourceSqlSession.selectOne("sql_itms_cm_info_syncker.SELECT_OMN10233", hmap);
	}

	private boolean updateOMN10233(String iptvThrsCd) {
		logger.debug("updateOMN10233");
		HashMap<String, Object> hmap = new HashMap<String, Object>();
		hmap.put("iptvThrsCd", iptvThrsCd);
		OMN10233 omn10233 = getOMN10233(hmap);
		if (omn10233 == null) {
			logger.error("failed to select (iptvThrsCd=" + iptvThrsCd + ")");
			return false;
		}
		logger.debug(omn10233.toString());
		destSqlSession.update("sql_itms_cm_info_syncker.UPDATE_OMN10233", omn10233);
		destSqlSession.commit();
		return true;
	}

	/*--------------------------------------------------------------------------------------------------*/

	private boolean doOMN10427(String syncType, JSONObject jsonObject) {
		OMN10427 omn10427 = new OMN10427();
		omn10427.setUserId((String) jsonObject.get("userId"));
		/*
		omn10427.setScrnId((String) jsonObject.get("scrnId"));
		omn10427.setIptvAlmTypCd((String) jsonObject.get("iptvAlmTypCd"));
		omn10427.setIptvAlmClCd((String) jsonObject.get("iptvAlmClCd"));
		omn10427.setInfoCntrCd((String) jsonObject.get("infoCntrCd"));

		if (omn10427.isValidKey() == false) {
			logger.info("invalid key");
			return false;
		}
		logger.info("syncType=" + syncType);
		logger.info(omn10427.toString());
		if ("DELETE".equals(syncType)) {
			return deleteOMN10427(omn10427);
		} else if ("INSERT".equals(syncType)) {
			return insertOMN10427(omn10427);
		} else if ("UPDATE".equals(syncType)) {
			return updateOMN10427(omn10427);
		} else {
			logger.error("invalid syncType : " + syncType);
			return false;
		}
		*/
		// userId 단위로 delete 후 전체 insert 처리
		if (omn10427.getUserId().isEmpty()) {
			logger.info("invalid key");
			return false;
		}
		return syncOMN10427forUser(omn10427);
	}
	
	private OMN10427 getOMN10427(OMN10427 omn10427) {
		return sourceSqlSession.selectOne("sql_itms_cm_info_syncker.SELECT_OMN10427", omn10427);
	}

	private boolean deleteOMN10427(OMN10427 omn10427) {
		logger.debug("deleteOMN10427");
		omn10427 = getOMN10427(omn10427);
		if (omn10427 == null) {
			destSqlSession.delete("sql_itms_cm_info_syncker.DELETE_OIV25620", omn10427);
			destSqlSession.commit();
			return true;
		} else {
			logger.debug(omn10427.toString());
			logger.error("still exist");
			return false;
		}
	}

	private boolean insertOMN10427(OMN10427 omn10427) {
		logger.debug("insertOMN10427");
		omn10427 = getOMN10427(omn10427);
		if (omn10427 == null) {
			logger.error("failed to select");
			return false;
		}
		logger.debug(omn10427.toString());
		destSqlSession.insert("sql_itms_cm_info_syncker.INSERT_OMN10427", omn10427);
		destSqlSession.commit();
		return true;
	}

	private boolean updateOMN10427(OMN10427 omn10427) {
		logger.debug("updateOMN10427");
		omn10427 = getOMN10427(omn10427);
		if (omn10427 == null) {
			logger.error("failed to select");
			return false;
		}
		logger.debug(omn10427.toString());
		destSqlSession.update("sql_itms_cm_info_syncker.UPDATE_OMN10427", omn10427);
		destSqlSession.commit();
		return true;
	}
	
	private boolean syncOMN10427forUser(OMN10427 omn10427) {
		logger.debug("syncOMN10427forUser");
		
		List<OMN10427> omn10427List = sourceSqlSession.selectList("sql_itms_cm_info_syncker.SELECT_OMN10427_FOR_USER", omn10427);
		destSqlSession.delete("sql_itms_cm_info_syncker.DELETE_OMN10427_FOR_USER", omn10427);
		for (OMN10427 obj : omn10427List) {
			destSqlSession.insert("sql_itms_cm_info_syncker.INSERT_OMN10427", obj);
		}
		destSqlSession.commit();
		return true;
	}

	/*--------------------------------------------------------------------------------------------------*/

	private boolean doOMN20515(String syncType, JSONObject jsonObject) {
		String vipCustSerNum = (String) jsonObject.get("vipCustSerNum");
		if (vipCustSerNum == null) {
			logger.error("vipCustSerNum is null");
			return false;
		}
		logger.info("syncType=" + syncType + "," + "vipCustSerNum=" + vipCustSerNum);
		if ("DELETE".equals(syncType)) {
			return deleteOMN20515(vipCustSerNum);
		} else if ("INSERT".equals(syncType)) {
			return insertOMN20515(vipCustSerNum);
		} else if ("UPDATE".equals(syncType)) {
			return updateOMN20515(vipCustSerNum);
		} else {
			logger.error("invalid syncType : " + syncType);
			return false;
		}
	}
	
	private OMN20515 getOMN20515(HashMap<String, Object> hmap) {
		return sourceSqlSession.selectOne("sql_itms_cm_info_syncker.SELECT_OMN20515", hmap);
	}

	private boolean deleteOMN20515(String vipCustSerNum) {
		logger.debug("deleteOMN20515");
		HashMap<String, Object> hmap = new HashMap<String, Object>();
		hmap.put("vipCustSerNum", vipCustSerNum);
		OMN20515 omn20515 = getOMN20515(hmap);
		if (omn20515 == null) {
			destSqlSession.delete("sql_itms_cm_info_syncker.DELETE_OMN20515", hmap);
			destSqlSession.commit();
			return true;
		} else {
			logger.debug(omn20515.toString());
			logger.error("still exist (vipCustSerNum=" + vipCustSerNum + ")");
			return false;
		}
	}

	private boolean insertOMN20515(String vipCustSerNum) {
		logger.debug("insertOMN20515");
		HashMap<String, Object> hmap = new HashMap<String, Object>();
		hmap.put("vipCustSerNum", vipCustSerNum);
		OMN20515 omn20515 = getOMN20515(hmap);
		if (omn20515 == null) {
			logger.error("failed to select (vipCustSerNum=" + vipCustSerNum + ")");
			return false;
		}
		logger.debug(omn20515.toString());
		destSqlSession.insert("sql_itms_cm_info_syncker.INSERT_OMN20515", omn20515);
		destSqlSession.commit();
		return true;
	}

	private boolean updateOMN20515(String vipCustSerNum) {
		logger.debug("updateOIV25620");
		HashMap<String, Object> hmap = new HashMap<String, Object>();
		hmap.put("vipCustSerNum", vipCustSerNum);
		OMN20515 omn20515 = getOMN20515(hmap);
		if (omn20515 == null) {
			logger.error("failed to select (vipCustSerNum=" + vipCustSerNum + ")");
			return false;
		}
		logger.debug(omn20515.toString());
		destSqlSession.update("sql_itms_cm_info_syncker.UPDATE_OMN20515", omn20515);
		destSqlSession.commit();
		return true;
	}
}
