package com.skb.mi.itms.cm;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.json.simple.JSONObject;

import com.skb.mi.common.Constants;
import com.skb.mi.common.EnvManager;

/* test method
[miuser@adamsitmsts02 adams]$ ./run_cmsyncclient.sh  127.0.0.1 20090
tableName=OMN10427
syncType=INSERT
userId=SKBAdams_333
end
-- resutl...
*/

public class CmInfoSyncClient {
	private	String	ipAddress;
	private	int		portNo;
	public CmInfoSyncClient(String[] args) {
		ipAddress = EnvManager.env.getOptionValue(Constants.IP_ADDRESS);
		portNo = Integer.parseInt(EnvManager.env.getOptionValue(Constants.PORT_NO));

		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		String data = null;
		JSONObject jsonObject = new JSONObject();
		while (true) {
			data = new String();
			while (data.length() < 1) {
				try {
					data = reader.readLine();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if ("exit".equals(data)) break;
			if ("end".equals(data)) {
				send(jsonObject);
				jsonObject = new JSONObject();
			} else {
				String[] items = data.split("=");
				if (items.length == 2) {
					jsonObject.put(items[0], items[1]);
				} else {
					System.out.println("invalid data");
				}
			}
		}
	}
	
	private void send(JSONObject jsonObject) {
		try {
			Socket sock = new Socket (ipAddress, portNo);
			OutputStream os = sock.getOutputStream();
			InputStream is = sock.getInputStream();
			os.write(jsonObject.toJSONString().getBytes());
			os.flush();
			byte[] buf = new byte[1024];
			int len = is.read(buf);
			if (len != -1) {
				String ret = new String(buf);
				System.out.println("ret:" + ret);
				System.out.println("");
			}
			is.close();
			os.close();
			sock.close();				
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Options options = new Options();
		Option optIpAddr = Option.builder().longOpt(Constants.IP_ADDRESS)
				.desc(Constants.IP_ADDRESS).hasArg().argName(Constants.IP_ADDRESS).build();
		Option optPortNo = Option.builder().longOpt(Constants.PORT_NO)
				.desc(Constants.PORT_NO).hasArg().argName(Constants.PORT_NO).build();
		options.addOption(optIpAddr);
		options.addOption(optPortNo);

		EnvManager envManager = new EnvManager(args, options);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("CmInfoCyncClient", envManager.getOptions());
    		System.exit(0);
    	}
    	new CmInfoSyncClient(args);
	}

}
