package com.skb.mi.itms.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.cli.HelpFormatter;
import org.apache.ibatis.session.ResultContext;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;

public class TasQiFileMaker implements ResultHandler {
	final private String	ServiceName = "TasQiFileMaker";
	private Logger	logger;
	private	String	dbName;
	private	String	targetDir;
	private	String[]	targetDateList; /* YYYYMMDDHH24 */
	private	String	selectDateQid;
	private	String	selectTasQiQid;
	private	SqlSession	sqlSession;
	private	FileOutputStream	fw = null;
	private	long recNo = 0;

	public TasQiFileMaker(String[] args) {
		logger = LogManager.getLogger(ServiceName);
		try {
			loadConfig();
			doIt();
		} catch (Exception e) {
			logger.error("exception...", e);
		}
	}

	private void loadConfig() throws Exception {
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		dbName = configManager.getConfig(ServiceName, "dbName");
		targetDir = configManager.getConfig(ServiceName, "targetDir");
		String val = configManager.getConfig(ServiceName, "targetDate");

		String[] vals = val.split(";");
		targetDateList = new String[vals.length];
		for (int i = 0; i < targetDateList.length; i ++) {
			targetDateList[i] = vals[i].trim();
		}

		selectDateQid = configManager.getConfig(ServiceName, "selectDateQid");
		selectTasQiQid = configManager.getConfig(ServiceName, "selectTasQiQid");

		logger.info(String.format("(dbName=%s)", dbName));
		logger.info(String.format("(targetDir=%s)", targetDir));
		logger.info(String.format("(targetDate=%s)", targetDateList));
		logger.info(String.format("(selectDateQid=%s)", selectDateQid));
		logger.info(String.format("(selectTasQiQid=%s)", selectTasQiQid));
	}
	
	private void doIt() throws Exception {
		sqlSession = IbatisSessionFactory.openSession(dbName);
		for (String targetDate : targetDateList) {
			HashMap<String,String> param = new HashMap<String,String>();
			param.put("TARGET_DTHR", targetDate);
			List<String> mntrDthmList = sqlSession.selectList(selectDateQid, param);
			
			fw = new FileOutputStream(targetDir + "/" + targetDate);
			recNo = 0;
			for (String mntrDthm : mntrDthmList) {
				param = new HashMap<String,String>();
				param.put("MNTR_DTHM", mntrDthm);
				sqlSession.select(selectTasQiQid, param, this);
			}
			fw.close();
		}
	}

	@Override
	public void handleResult(ResultContext context) {
		TasQiVO obj = (TasQiVO) context.getResultObject();
		obj.setAtime(convertDateToUnixtime(obj.getAtime()));
		obj.setChanStartTs(convertDateToUnixtime(obj.getChanStartTs()));
		String data = String.format("l2_tid=%s,tv_svcmgmt_num=%s,inet_svcmgmt_num=%s,msg_ts=%s,measure_ts=%s,inet_service_num=%s,epg=%s,l3_tid=%s,bad_jt=%s,atime=%s,bad_overall=%s,area1=%s,area2=%s,chan_start_ts=%s,chan_ip_port=%s,stb_id=%s",
				obj.getL2Tid(), obj.getTvSvcmgmtNum(), obj.getInetSvcmgmtNum(), obj.getMsgTs(), obj.getMeasureTs(), obj.getInetServiceNum(),
				obj.getEpg(), obj.getL3Tid(), obj.getBadJt(), obj.getAtime(), obj.getBadOverall(), obj.getArea1(), obj.getArea2(),
				obj.getChanStartTs(), obj.getChanIpPort(), obj.getStbId());
		recNo ++;
		try {
			//fw.write(data.getBytes(Charset.forName("utf8")));
			fw.write(data.getBytes(Charset.forName("eucKR")));
			fw.write('\n');
		} catch (IOException e) {
			logger.error("writing...", e);
		}
		if (recNo % 10000 == 0) {
			logger.info("read " + recNo);
		}
	}

	private String convertDateToUnixtime(String dateStr) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			Date dt = sdf.parse(dateStr);
			long epoch = dt.getTime();
			return "" + epoch/1000;
		} catch (java.text.ParseException e) {
			return "";
		}
	}

	public static void main(String[] args) {
		EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("TasQiFileMaker", envManager.getOptions());
    		System.exit(0);
    	}
    	new TasQiFileMaker(args);

	}
}
