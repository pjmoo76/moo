package com.skb.mi.itms.util;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.apache.commons.cli.HelpFormatter;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.common.StringUtils;
import com.skb.mi.model.WeqpRelVO;

public class WeqpArranger {
	final private String	ServiceName = "WeqpArranger"; 
	public final static String	AP		= "10";
	public final static String	STB		= "20";
	public final static String	CM		= "30";
	public final static String	ONT		= "40";
	public final static String	VDSL	= "50";
	public final static String	ETC		= "00";
	public final static String	END_MSG	= "__END__";

	private Logger		logger;
	private	String		dbName;
	private	int			threadCnt;

	private	SqlSession	sqlSession;
	private	List<WorkNode>	workNodeList;
	
	public WeqpArranger(String[] args) {
		logger = LogManager.getLogger(this.getClass().getName());
		try {
			loadConfig();
			run();
		} catch (Exception e) {
			logger.error("Exception", e);
		}
	}
	
	private void loadConfig() throws Exception {
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		dbName = configManager.getConfig(this.ServiceName, "dbName");
		threadCnt = Integer.parseInt(configManager.getConfig(this.ServiceName, "threadCnt"));
	}

	
	public void run()throws Exception {
		workNodeList = new ArrayList<WorkNode>();
		for (int i = 0; i < threadCnt; i ++) {
			WorkNode workNode = new WorkNode();
			workNode.idx = i;
			workNode.run();
			workNodeList.add(workNode);
		}
		
		sqlSession = IbatisSessionFactory.openSession(dbName);
		List<String> equipIdList = sqlSession.selectList("sql_itms_weqp_arrange.SELECT_ADRC_EQUIP_ID");
		logger.debug("size=" + equipIdList.size());
		int idx = 0;
		for (String equipId : equipIdList) {
			workNodeList.get(idx).add(equipId);
			idx ++;
			if (idx == threadCnt) idx = 0;
		}
		sqlSession.close();
		for (String equipId : equipIdList) {
			workNodeList.get(idx).add(END_MSG);			
		}
		logger.info("completed...");
	}
	
	class WorkNode {
		int			idx;
		Thread		worker;
		BlockingQueue<String>	equipIdQueue;
		public void run() {
			equipIdQueue = new LinkedBlockingQueue();
			worker = new Thread(new Runner(this));
			worker.start();
		}
		public void add(String equipId) {
			this.equipIdQueue.add(equipId);
		}
	}
	
	class Runner implements Runnable {
		WorkNode caller;
		private	SqlSession	sqlSession;

		public Runner(WorkNode caller) {
			this.caller = caller;
		}

		@Override
		public void run() {
			try {
				sqlSession = IbatisSessionFactory.openSession(dbName);
				HashMap paramMap = new HashMap<String,String>();
				while (true) {
					String equipId = caller.equipIdQueue.take();
					if (END_MSG.equals(equipId)) {
						break;
					}
					paramMap.put("equipId", equipId);
					List<WeqpRelVO> weqpRelVOList = sqlSession.selectList("sql_itms_weqp_arrange.SELECT_LINK_ID_CUST_NUM", paramMap);
					logger.debug(String.format("[%d] size=%d", caller.idx, weqpRelVOList.size()));
					for (int i = 0; i < weqpRelVOList.size(); i ++) {
						WeqpRelVO weqpRelVO = weqpRelVOList.get(i);
						//logger.debug(weqpRelVO.debugMessage());
						doIt(weqpRelVO);
						if (i % 100 == 0) {
							logger.info(String.format("[%d] %d processing...", caller.idx, i));
							sqlSession.commit();
						}
					}
				}
				sqlSession.commit();
				logger.info(String.format("[%d] completed...", caller.idx));
			} catch (Exception e) {
				logger.error(String.format("[%d] Exception", caller.idx), e);
			}
		}
		
		private void doIt(WeqpRelVO weqpRelVO) throws Exception {
			List<WeqpRelVO> weqpRelVOList = sqlSession.selectList("sql_itms_weqp_arrange.SELECT_WEQP_REL", weqpRelVO);
			if (weqpRelVOList == null || weqpRelVOList.size() == 0) {
				return;
			}
			arrangeWeqp(weqpRelVOList);
			
			for (int i = 0; i < weqpRelVOList.size(); i ++) {
				WeqpRelVO weqp = weqpRelVOList.get(i);
				if (StringUtils.equals(weqp.getSupWeqpMgmtNum(), weqp.getNewSupWeqpMgmtNum()) == false) {
					logger.debug(weqp.debugMessage());
					sqlSession.update("sql_itms_weqp_arrange.UPDATE_OIV10402_SUP_WEQP_MGMT_NUM", weqp);
				}
			}
		}

		protected void arrangeWeqp(List<WeqpRelVO> weqpRelVOList) {
			List<WeqpRelVO> teList = new ArrayList<WeqpRelVO>();
			List<WeqpRelVO> apList = new ArrayList<WeqpRelVO>(); 
			List<WeqpRelVO> stbList = new ArrayList<WeqpRelVO>();

			for (int i = 0; i < weqpRelVOList.size(); i ++) {
				WeqpRelVO weqpRelVO = weqpRelVOList.get(i); 
				if (ONT.equals(weqpRelVO.getWeqpMdlTypCd())) {
					teList.add(weqpRelVO);
				} else if (VDSL.equals(weqpRelVO.getWeqpMdlTypCd())) {
					teList.add(weqpRelVO);
				} else if (CM.equals(weqpRelVO.getWeqpMdlTypCd())) {
					teList.add(weqpRelVO);
				} else if (AP.equals(weqpRelVO.getWeqpMdlTypCd())) {
					apList.add(weqpRelVO);
				} else if (STB.equals(weqpRelVO.getWeqpMdlTypCd())) {
					stbList.add(weqpRelVO);
				}			
			}
			if (teList.size() > 1) { 
				logger.info("linkId=" + teList.get(0).getLinkId() + ",custNum=" + teList.get(0).getCustNum() + ",teList.size=" + teList.size() + " ... proces...");
			}
			for (int i = 0; i < weqpRelVOList.size(); i ++) {
				WeqpRelVO weqpRelVO = weqpRelVOList.get(i);
				if (AP.equals(weqpRelVO.getWeqpMdlTypCd())) {
					WeqpRelVO pWeqp = findWeqp(teList, weqpRelVO);
					if (pWeqp != null) {
						weqpRelVO.setNewSupWeqpMgmtNum(pWeqp.getWeqpMgmtNum());
					}
				} else if (STB.equals(weqpRelVO.getWeqpMdlTypCd()) || ETC.equals(weqpRelVO.getWeqpMdlTypCd())) {
					// AP 에서 동일한 서비스관리번호 찾기
					WeqpRelVO pWeqp = findWeqp(apList, weqpRelVO);
					if (pWeqp != null) {
						weqpRelVO.setNewSupWeqpMgmtNum(pWeqp.getWeqpMgmtNum());
					} else {
						// AP 에서 찾지 못했다면, TE 에서 서비스관리번호 찾기
						pWeqp = findWeqp(teList, weqpRelVO);
						if (pWeqp != null) {
							weqpRelVO.setNewSupWeqpMgmtNum(pWeqp.getWeqpMgmtNum());
						} else {
							// TE 에서도 못 찾았다면, 첫번째 AP 와 연결
							if (apList.size() > 0) {
								weqpRelVO.setNewSupWeqpMgmtNum(apList.get(0).getWeqpMgmtNum());
							} else {
								// AP 가 없다면 TE 로 연결
								if (teList.size() > 0) {
									weqpRelVO.setNewSupWeqpMgmtNum(teList.get(0).getWeqpMgmtNum());
								}
							}
						}
					}
				}
			}
		}

		private WeqpRelVO findWeqp(List<WeqpRelVO> weqpList, WeqpRelVO weqpVO) {
			String inetSvcMgmtNum = weqpVO.getInetSvcMgmtNum();
			for (int i = 0; i < weqpList.size(); i ++) {
				if (inetSvcMgmtNum == null || inetSvcMgmtNum.isEmpty()) break;
				if (inetSvcMgmtNum.equals(weqpList.get(i).getInetSvcMgmtNum())) {
					return weqpList.get(i);
				}
			}
			String iptvSvcMgmtNum = weqpVO.getIptvSvcMgmtNum();
			for (int i = 0; i < weqpList.size(); i ++) {
				if (iptvSvcMgmtNum == null || iptvSvcMgmtNum.isEmpty()) break;
				if (iptvSvcMgmtNum.equals(weqpList.get(i).getIptvSvcMgmtNum())) {
					return weqpList.get(i);
				}
			}
			String phonSvcMgmtNum = weqpVO.getPhonSvcMgmtNum();
			for (int i = 0; i < weqpList.size(); i ++) {
				if (phonSvcMgmtNum == null || phonSvcMgmtNum.isEmpty()) break;
				if (phonSvcMgmtNum.equals(weqpList.get(i).getPhonSvcMgmtNum())) {
					return weqpList.get(i);
				}
			}
			String repSvcMgmtNum = weqpVO.getRepSvcMgmtNum();
			for (int i = 0; i < weqpList.size(); i ++) {
				if (repSvcMgmtNum == null || repSvcMgmtNum.isEmpty()) break;
				if (repSvcMgmtNum.equals(weqpList.get(i).getRepSvcMgmtNum())) {
					return weqpList.get(i);
				}
			}
			return null;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("WeqpArranger", envManager.getOptions());
    		System.exit(0);
    	}
		try {
			new WeqpArranger(args);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
