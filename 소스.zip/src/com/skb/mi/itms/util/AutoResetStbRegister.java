package com.skb.mi.itms.util;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.cli.HelpFormatter;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.skb.adams.itms.util.send.HttpRequestHelper;
import com.skb.adams.itms.util.send.HttpResponse;
import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Cron;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.common.MiscUtils;
import com.skb.mi.itms.model.BIV20851;

public class AutoResetStbRegister {
	final private String	ServiceName = "AutoResetStbRegister"; 
	private Logger		logger;
	private	String		dbName;
	private	String		restCallUrl;

	private	SqlSession	sqlSession;

	public AutoResetStbRegister(String[] args) {
		logger = LogManager.getLogger(this.getClass().getName());
	}
	
	private void loadConfig() throws Exception {
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		dbName = configManager.getConfig(this.ServiceName, "dbName");
		restCallUrl = configManager.getConfig(this.ServiceName, "restCallUrl");
		
		logger.info(String.format("(dbName=%s)", dbName));
		logger.info(String.format("(restCallUrl=%s)", restCallUrl));
	}

	public void run() throws Exception {
		while (true) {
			MiscUtils.sleep(MiscUtils.getNextMinuteMills());
			try {
				checkSqlSession();
				sqlSession = IbatisSessionFactory.openSession(dbName);			
				BIV20851 biv20851 = (BIV20851) sqlSession.selectOne("sql_itms_auto_reset_stb_register.SELECT_BIV20851");
				if (biv20851 != null) {
					doIt(biv20851);
				}
			} catch (Exception e) {
				logger.error("error", e);				
			}
		}
	}
	
	private void  doIt(BIV20851 biv20851) throws Exception {
		String cronStr = String.format("0 %s * * %s", biv20851.getAutoExtrtTmsVal(), biv20851.getSchdCyclInfo().replace('|', ','));
		logger.debug(String.format("(schdCyclInfo=%s),(autoExtrtTmsVal=%s)->(%s)", biv20851.getAutoResetExtrtSerNum(), biv20851.getSchdCyclInfo(), cronStr));
		// 0,1,2,3,4,5,6 (일 ~ 토)
		Cron cron = new Cron();
		cron.setCron(cronStr);
		
		long mstime = System.currentTimeMillis();
		if (cron.isOnTime2(mstime) == false) return;

		String sqlSelectResetStbCnt = "";
		String sqlInsertAutoResetStb = "";

		Calendar cal = Calendar.getInstance();
		if (cal.get(Calendar.HOUR_OF_DAY) < 12) {
			sqlSelectResetStbCnt = "sql_itms_auto_reset_stb_register.SELECT_AUTO_RESET_STB_CNT_AM";
			sqlInsertAutoResetStb = "sql_itms_auto_reset_stb_register.INSERT_AUTO_RESET_STB_AM";
		} else {
			sqlSelectResetStbCnt = "sql_itms_auto_reset_stb_register.SELECT_AUTO_RESET_STB_CNT";
			sqlInsertAutoResetStb = "sql_itms_auto_reset_stb_register.INSERT_AUTO_RESET_STB";			
		}

		logger.info("getting auto-reset-stb");
		Object stbCntObj = (Object) sqlSession.selectOne(sqlSelectResetStbCnt);
		int stbCnt = ((Integer) stbCntObj).intValue();
		logger.info(String.format("auto-reset-stb : " + stbCnt));
		if (stbCnt == 0) return;

		HashMap<String,Object> resultMap = (HashMap<String,Object>) sqlSession.selectOne("sql_itms_auto_reset_stb_register.SELECT_OPER_DT");
		String currDt = (String) resultMap.get("CURR_DT");
		String nextDt = (String) resultMap.get("NEXT_DT");
		
		String operStaDtm = null;
		String operFnshDtm = null;
		String itmCopyOperExecVal = null;
		if (biv20851.getOperStaDtm().compareTo(biv20851.getAutoExtrtTmsVal()) < 0) {
			operStaDtm = nextDt + biv20851.getOperStaDtm() + "0000";
			operFnshDtm = nextDt + biv20851.getOperFnshDtm() + "0000";
			String month = operStaDtm.substring(4, 6);
			String day = operStaDtm.substring(6, 8);
			String hour = operStaDtm.substring(8, 10);
			itmCopyOperExecVal = String.format("0 0 %s %s %s ?", hour, day, month);
		} else {
			operStaDtm = currDt + biv20851.getOperStaDtm() + "0000";
			operFnshDtm = currDt + biv20851.getOperFnshDtm() + "0000";			
			String month = operStaDtm.substring(4, 6);
			String day = operStaDtm.substring(6, 8);
			String hour = operStaDtm.substring(8, 10);
			itmCopyOperExecVal = String.format("0 0 %s %s %s ?", hour, day, month);
		}

		resultMap = (HashMap<String,Object>) sqlSession.selectOne("sql_itms_auto_reset_stb_register.SELECT_OPER_SER_NUM");
		String operRgstDtm = (String) resultMap.get("OPER_RGST_DTM");
		int operSerNum = ((BigDecimal) resultMap.get("OPER_SER_NUM")).intValue();
		
		HashMap<String,String> paramMap = new HashMap<String,String>();
		paramMap.put("operRgstDtm", operRgstDtm);
		paramMap.put("operSerNum", ""+operSerNum);
		paramMap.put("operRsvDtm", operStaDtm);
		paramMap.put("itmCopyOperExecVal", itmCopyOperExecVal);
		paramMap.put("operStaDtm", operStaDtm);
		paramMap.put("operFnshDtm", operFnshDtm);
		paramMap.put("stbSvcOfrModeVal", biv20851.getStbSvcOfrModeVal());
		paramMap.put("stbSvcOfrModeDayCnt", ""+biv20851.getStbSvcOfrModeDayCnt());
		paramMap.put("resetStrdUptimeDayCnt", ""+biv20851.getResetStrdUptimeDayCnt());
		sqlSession.insert("sql_itms_auto_reset_stb_register.INSERT_AUTO_RESET_JOB", paramMap);
		sqlSession.insert(sqlInsertAutoResetStb, paramMap);
		sqlSession.commit();
		
		// call rest-api
		callRestApi(operRgstDtm, operSerNum);
	}
	
	private void callRestApi(String operRgstDtm, int operSerNum) {
		logger.info(String.format("(operRgstDtm=%s),(operSerNum=%d)", operRgstDtm, operSerNum));

		HttpRequestHelper httpRequestHelper  = null;
		HttpResponse httpResponse = null;
		String reqContents = "";

		Gson gson = new Gson();

		/*
		Map<String, Object> argsMap = new HashMap<String, Object>();
		argsMap.put("OPER_DTL_SEQ", "1");
		argsMap.put("OPER_SER_NUM", "1");
		argsMap.put("OPER_RGST_DTM", "20201212002322");
		*/

		Map<String, Object> cmdReqMap = new HashMap<String, Object>();
		
		String cmdStr = String.format("{\"cmd\":\"J01\",\"args\":{\"OPER_DTL_SEQ\":\"1\",\"OPER_SER_NUM\":\"%d\",\"OPER_RGST_DTM\":\"%s\"},\"mac\":\"FFFFFF\",\"report\":\"COMMON,STATUS_ALL\",\"sequence\":\"I-%d-%s\"}",
				operSerNum, operRgstDtm, operSerNum, operRgstDtm);
		/*
		cmdReqMap.put("cmd", "J01");	// add scheduler
		//cmdReqMap.put("args", gson.toJson(argsMap));
		String args = String.format("{\"OPER_DTL_SEQ\":\"%s\",\"OPER_SER_NUM\":\"%d\",\"OPER_RGST_DTM\":\"%s\"}", "1", operSerNum, operRgstDtm);
		logger.info(String.format(">>> args : %s", args));
		cmdReqMap.put("args", args);
		*/

		Map<String, Object> paramMap = new HashMap<String, Object>();
		
		//paramMap.put("commandReqMessage", gson.toJson(cmdReqMap));
		paramMap.put("commandReqMessage", cmdStr);
		paramMap.put("requestId", getUUIDString());
		paramMap.put("requesterId", "autoReg");
		
		Map<String, Object> shellMap = new HashMap<>();
		shellMap.put("params", paramMap);

		reqContents = gson.toJson(shellMap);
		logger.info(">> Req Json : " + reqContents);

		try {
			// "http://127.0.0.1:43480/opScheduler"
			httpRequestHelper = new HttpRequestHelper.HttpRequestHelperBuilder()
					.setUrlString(restCallUrl)
					.setMethod("POST")
					.addHeader("User-Agent", "itms-rest-diagnostic")
					.addHeader("content-type", "application/json; charset=UTF-8")
					.setDataContents(reqContents)
					.build();

			httpResponse = httpRequestHelper.executeRequest();
			if(httpResponse != null ){
				if(httpResponse.getnCode() == 200){
					logger.info(String.format(">>> result : %s", httpResponse.toString()));
				}
			}

			shellMap.clear();
			paramMap.clear();
			
		} catch (IOException e) {
			logger.error(">> restful call exception", e);
		} finally{
		}
	}

	public String getUUIDString(){
		return UUID.randomUUID().toString().replaceAll("-","");
	}

	private void checkSqlSession() throws Exception {
		if (sqlSession != null) {
			try {
				sqlSession.clearCache();
				String operStaDtm = sqlSession.selectOne("sql_itms_auto_reset_stb_register.SELECT_CURR_DTM");
			} catch (Exception e) {
				sqlSession.close();
				sqlSession = null;
			}
		}
		if (sqlSession == null) {
			sqlSession = IbatisSessionFactory.openSession(dbName);
			logger.info("reconnected " + dbName);
		}
	}

	public static void main(String[] args) {
		EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("AutoResetStbRegister", envManager.getOptions());
    		System.exit(0);
    	}
    	try {
    		AutoResetStbRegister register = new AutoResetStbRegister(args);
    		register.loadConfig();
    		register.run();
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
		
	}

}
