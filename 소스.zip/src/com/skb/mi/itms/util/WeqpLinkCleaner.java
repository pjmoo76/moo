package com.skb.mi.itms.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashMap;

import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.skb.mi.common.Constants;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.common.StringUtils;
import com.skb.mi.model.OIV10402;
import com.skb.mi.model.OIV10805;

public class WeqpLinkCleaner {
	static private final int	TOKEN_NO	= 69;
	private Logger		logger;
	private	SqlSession	sqlSession;
	
	int lineCnt = 0;
	int	noEquipCnt = 0;

	public WeqpLinkCleaner() {
		logger = LogManager.getLogger(WeqpLinkCleaner.class.getName());
	}
	
	public void process(String fileName) throws Exception {
		if (sqlSession == null) {
//			sqlSession = IbatisSessionFactory.openSession("ADAMS_DEV");
			sqlSession = IbatisSessionFactory.openSession("ADAMSBS_R");
		}
		FileInputStream fr = new FileInputStream(fileName);
		InputStreamReader ir = new InputStreamReader(fr, "eucKR");
		BufferedReader br = new BufferedReader(ir);
		String strLine;
		while ((strLine = br.readLine()) != null) {
			lineCnt ++;
			OIV10805 oiv10805 = make(strLine);
			if (oiv10805 == null) continue;
			process(oiv10805);
			if (lineCnt % 10000 == 0) {
				sqlSession.commit();
				logger.info("fileName = " + fileName + ", lineCnt=" + lineCnt + ", noEquipCnt = " + noEquipCnt + " ------------------------------------------------");
			}
		}
		sqlSession.commit();
		br.close();
		ir.close();
		fr.close();
		logger.info("fileName = " + fileName + ", lineCnt=" + lineCnt + ", noEquipCnt = " + noEquipCnt + " ------------------------------------------------");
	}
	
	public void process(OIV10805 oiv10805) throws Exception {
		if (StringUtils.isEmpty(oiv10805.getMacAddr())) {
			return;
		}
		if (StringUtils.isEmpty(oiv10805.getL3EquipId())) {
			deleteMacWithoutEquip(oiv10805);
		}
		if (StringUtils.isEmpty(oiv10805.getL2EquipId())) {
			deleteMacWithoutEquip(oiv10805);
		}
	}
	
	protected void deleteMacWithoutEquip(OIV10805 oiv10805) throws Exception {
		logger.debug("L3_TID:" + oiv10805.getL3EquipId() + ",L2_TID:" + oiv10805.getL2EquipId() + ",MAC:" + oiv10805.getMacAddr());
		noEquipCnt ++;
		String weqpMgmtNum = (String) sqlSession.selectOne("sql_itms_weqp_arrange.SELECT_WEQP_MGMT_NUM__BY_MAC_ADDR_VAL", oiv10805.getMacAddr());
		if (StringUtils.isEmpty(weqpMgmtNum)) {
			return;
		}
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("custNum", "" + oiv10805.getCustNum());
		hmap.put("weqpMgmtNum", weqpMgmtNum);
		OIV10402 oiv10402 = (OIV10402) sqlSession.selectOne("sql_itms_weqp_arrange.SELECT_OIV10402", hmap);
		if (oiv10402 == null) {
			return;
		}
		// delete OIV10404, OIV10403, OIV10402
		hmap = new HashMap<String, String>();
		hmap.put("linkId", oiv10402.getLinkId());
		hmap.put("thruSerNum", "" + oiv10402.getThruSerNum());
		sqlSession.delete("sql_itms_weqp_arrange.DELETE_OIV10404__ALL_SVC", hmap);
		//sqlSession.delete("sql_itms_weqp_arrange.DELETE_OIV10403", hmap);
		sqlSession.delete("sql_itms_weqp_arrange.DELETE_OIV10402", hmap);
	}


	private OIV10805 make(String data) throws Exception {
		OIV10805 oiv10805 = new OIV10805();
		String[] tokens = data.split("\\|");
		if (tokens.length < TOKEN_NO) {
			//Logger.logger.error("invalid token no : " + tokens.length);
			return null;
		}
		/*
		for (int i = 0; i < tokens.length; i ++) {
			Logger.logger.debug(i + ":" + tokens[i]);
		}
		*/
		oiv10805.setWeqpGrpCd(tokens[0]);
		oiv10805.setMacAddr(tokens[1]);
		oiv10805.setInoutClCd(tokens[2]); /* 출고 : 1, 입고 : 2 */
		oiv10805.setMfactNm(tokens[3]);
		oiv10805.setEquipMdlNm(tokens[4]);
		if (tokens[5].trim().length() > 0) oiv10805.setCustNum(tokens[5]);
		if (tokens[6].trim().length() > 0) oiv10805.setAcntNum(tokens[6]);
		oiv10805.setEquipCd(tokens[7]);
		oiv10805.setCustNm(tokens[8]);
		oiv10805.setSvcTechMthdCd(tokens[9]);
		oiv10805.setCustAddr(tokens[10]);
		oiv10805.setCustPhonNum(tokens[11]);
		if (tokens[12].trim().length() > 0) oiv10805.setInetSvcNum(tokens[12]);
		if (tokens[13].trim().length() > 0) oiv10805.setInetSvcMgmtNum(tokens[13]);
		if (tokens[14].trim().length() > 0) oiv10805.setPhonSvcNum(tokens[14]);
		if (tokens[15].trim().length() > 0) oiv10805.setPhonSvcMgmtNum(tokens[15]);
		if (tokens[16].trim().length() > 0) oiv10805.setIptvSvcNum(tokens[16]);
		if (tokens[17].trim().length() > 0) oiv10805.setIptvSvcMgmtNum(tokens[17]);
		oiv10805.setInetSvcNm(tokens[18]);
		oiv10805.setPhonSvcNm(tokens[19]);
		oiv10805.setIptvSvcNm(tokens[20]);
		oiv10805.setRltmTvClCd(tokens[21]);
		oiv10805.setInetOrbkStCd(tokens[22]);
		oiv10805.setWphonOrbkStCd(tokens[23]);
		oiv10805.setIptvOrbkStCd(tokens[24]);
		if (tokens[25].trim().length() > 0) oiv10805.setIptvLineCnt(tokens[25]);
		oiv10805.setL3TidVal(tokens[26]);
		oiv10805.setL3EquipId(tokens[27]);
		oiv10805.setL3EquipNm(tokens[28]);
		oiv10805.setL3EquipMfactNm(tokens[29]);
		oiv10805.setL3IpAddr(tokens[30]);
		oiv10805.setInfoCntrCd(tokens[31]);
		oiv10805.setInfcNm(tokens[32]);
		oiv10805.setL3CellNum(tokens[33]);
		oiv10805.setL3RackNum(tokens[34]);
		oiv10805.setL3ShlfNum(tokens[35]);
		oiv10805.setL3CardNum(tokens[36]);
		oiv10805.setL3PortNum(tokens[37]);
		oiv10805.setL2TidVal(tokens[38]);
		oiv10805.setL2EquipId(tokens[39]);
		oiv10805.setL2EquipNm(tokens[40]);
		oiv10805.setL2EquipMfactNm(tokens[41]);
		oiv10805.setL2IpAddr(tokens[42]);
		oiv10805.setTpoCd(tokens[43]);
		oiv10805.setTpoNm(tokens[44]);
		oiv10805.setL2CellNum(tokens[45]);
		oiv10805.setL2RackNum(tokens[46]);
		oiv10805.setL2ShlfNum(tokens[47]);
		oiv10805.setL2CardNum(tokens[48]);
		oiv10805.setL2PortNum(tokens[49]);
		if (tokens[50].length() <= 12) {
			oiv10805.setOnuEquipId(tokens[50]);
		} else {
			oiv10805.setOnuEquipId(tokens[50].substring(0,12));
		}
		oiv10805.setRnTapNum(tokens[51]);
		oiv10805.setTelpolNum(tokens[52]);
		oiv10805.setLdongCd(tokens[53]);
		oiv10805.setAddrId(tokens[54]);
		if (tokens[55].trim().length() > 0) oiv10805.setBldblkNum(tokens[55]);
		if (tokens[56].trim().length() > 0) oiv10805.setBlduntNum(tokens[56]);
		oiv10805.setAssistAddr(tokens[57]);
		oiv10805.setZip(tokens[58]);
		oiv10805.setBasAddr(tokens[59]);
		oiv10805.setDtlAddr(tokens[60]);
		oiv10805.setDsnetId(tokens[61]);
		oiv10805.setDsnetNm(tokens[62]);
		oiv10805.setFstScrbOrgId(tokens[63]);
		oiv10805.setFstScrbOrgNm(tokens[64]);
		oiv10805.setTeamOrgNm(tokens[65]);
		oiv10805.setSvcLinkNum(tokens[66]);
		oiv10805.setSetBldAttrInfo(tokens[67]);
		oiv10805.setAssistMacAddrSerNum(tokens[68]);
		
		return oiv10805;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WeqpLinkCleaner cleaner = new WeqpLinkCleaner();
		File folder = new File(args[0]);
		File[] files = folder.listFiles();
		for (File file : files) {
			String fileName = file.getAbsolutePath();
			System.out.println(fileName);
			try {
				cleaner.process(fileName);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
