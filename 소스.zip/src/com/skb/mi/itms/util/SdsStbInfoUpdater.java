package com.skb.mi.itms.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.skb.mi.common.IbatisSessionFactory;

public class SdsStbInfoUpdater {
	private Logger		logger;
	private	SqlSession	sqlSession;
	private	String		fileName;
	
	public SdsStbInfoUpdater() {
		logger = LogManager.getLogger(SdsStbInfoUpdater.class.getName());
	}
	
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	public void doIt() throws Exception {
		//sqlSession = IbatisSessionFactory.openSession("ADAMSBS_B");
		FileInputStream		fr = null;
		BufferedReader		br = null;
		fr =  new FileInputStream(fileName);
		InputStreamReader ir = new InputStreamReader(fr);
		br = new BufferedReader(ir);
		String strLine;
		while ((strLine = br.readLine()) != null) {
			// STB_MAC|SVC_MGMT_NUM|VERSION|ST_VERSION|UPTIME|STB_LOCAL_IP|STB_REAL_IP|SDS_PATCH_GROUP|STB_LAST_UTIME
			// 80:8c:97:8e:d2:64|7280942584|10.512.12-0001|10.512.12-0001|2019.10.16 05:23|39.125.14.196|39.125.14.196|[상용]STB_업그레이드|2019.12.12 05:31
			System.out.println(strLine);
			
			break;
		}
		br.close();
		fr.close();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SdsStbInfoUpdater updater = new SdsStbInfoUpdater();
		updater.setFileName(args[0]);
		try {
			updater.doIt();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
