package com.skb.mi.itms.util;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.DateUtils;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.common.MiscUtils;
import com.skb.mi.common.StringUtils;
import com.skb.mi.itms.model.BQA21693;

public class ApiLogUpdater {
	final private String	ServiceName = "ApiLogUpdater";

	private Logger		logger;
	private	String		dbName;
	private	int			sleepSec;
	private	String		selectApiLogQid;
	private	String		selectApiLogAsyncResultQid;
	private	String		updateApiLogQid;
	private	SqlSession	sqlSession;
	private	JSONParser	jsonParser;
	
	private	String		paramStartTime;
	private	String		paramEndTime;

	public ApiLogUpdater(String[] args) {
		logger = LogManager.getLogger(this.getClass().getName());

		paramStartTime = EnvManager.env.getOptionValue("START_TIME");
		paramEndTime = EnvManager.env.getOptionValue("END_TIME");
		
		if (paramStartTime != null) {
			logger.info(String.format("(paramStartTime=%s)", paramStartTime));
			logger.info(String.format("(paramEndTime=%s)", paramEndTime));			
		}

		try {
			loadConfig();
		} catch (Exception e) {
			logger.error("error", e);
			return;
		}
		jsonParser = new JSONParser();
	}

	private void loadConfig() throws Exception {
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		dbName = configManager.getConfig(this.ServiceName, "dbName");
		sleepSec = Integer.parseInt(configManager.getConfig(this.ServiceName, "sleepSec"));
		selectApiLogQid = configManager.getConfig(this.ServiceName, "selectApiLogQid");
		selectApiLogAsyncResultQid = configManager.getConfig(this.ServiceName, "selectApiLogAsyncResultQid");
		updateApiLogQid = configManager.getConfig(this.ServiceName, "updateApiLogQid");
		
		logger.info(String.format("(dbName=%s)", dbName));
		logger.info(String.format("(sleepSec=%d)", sleepSec));
		logger.info(String.format("(selectApiLogQid=%s)", selectApiLogQid));
		logger.info(String.format("(selectApiLogAsyncResultQid=%s)", selectApiLogAsyncResultQid));
		logger.info(String.format("(updateApiLogQid=%s)", updateApiLogQid));
	}

	public void run() {
		if (StringUtils.isEmpty(paramStartTime)) {
			doLoop();
		} else {
			doBatch();
		}
	}
	
	public void doLoop() {
		while (true) {
			try {
				Map<String,String> paramMap = new HashMap<String,String>();
				String startTime = DateUtils.getAddedTime("yyyyMMddHHmm", (60*10)*-1) + "00";
				String endTime = DateUtils.getAddedTime("yyyyMMddHHmm", (60*5)*-1) + "00";
				paramMap.put("START_DTM", startTime);
				paramMap.put("END_DTM", endTime);
				doIt(paramMap);
			} catch (Exception e) {
				logger.error("error", e);
			}
			MiscUtils.sleep(sleepSec*1000);
		}
	}
	
	public void doBatch() {
		boolean loopFlag = true;
		String startTime = this.paramStartTime;
		String endTime = null;
		while (loopFlag) {
			try {
				endTime = DateUtils.getAddedTime("yyyyMMddHHmm", startTime, (60*60)); // add 1 hour
				if (endTime.compareTo(paramEndTime) >= 0) {
					endTime = this.paramEndTime;
					loopFlag = false;
				}
				Map<String,String> paramMap = new HashMap<String,String>();
				paramMap.put("START_DTM", startTime + "00");
				paramMap.put("END_DTM", endTime + "00");
				doIt(paramMap);
				startTime = endTime;
			} catch (Exception e) {
				logger.error("error", e);
				loopFlag = false;
			}
		}
	}
	
	private void doIt(Map<String,String> paramMap) throws Exception {
		logger.info(String.format(">>> paramMap=[%s]", paramMap.toString()));
		SqlSession sqlSession = IbatisSessionFactory.openSession(dbName);
		List<BQA21693> apiLogList = sqlSession.selectList(selectApiLogQid, paramMap);
		logger.info(String.format("apiLog %d count", apiLogList.size()));
		if (apiLogList.size() > 0) {
			JSONObject jsonObj = null;
			for (BQA21693 apiLog : apiLogList) {
				try {
					logger.info(String.format("(dgnsReqDtm=%s),(dgnsIfId=%s),(dgnsReqId=%s)", apiLog.getDgnsReqDtm(), apiLog.getDgnsIfId(), apiLog.getDgnsReqId()));
					if ("getKaProcessSystem".equals(apiLog.getDgnsIfId())) {
						logger.info(apiLog.getDgnsIfId() + " is skip");
						continue;
					}
					if (isAysncApi(apiLog.getDgnsIfId())
							|| "stbPushReset".equals(apiLog.getDgnsIfId())
							|| "getApResetResult".equals(apiLog.getDgnsIfId())
							|| "setApHandle".equals(apiLog.getDgnsIfId())) {
						paramMap.put("DGNS_REQ_ID", apiLog.getDgnsReqId());
						//BQA21693 apiLogAsyncResult = sqlSession.selectOne(selectApiLogAsyncResultQid, paramMap);
						// apAsyncReset2 + getApResetResult + setApHandle 케이스의 경우, setApHandle 결과값을 처리해야 함
						List<BQA21693> apiLogAsyncResultList = sqlSession.selectList(selectApiLogAsyncResultQid, paramMap);
						BQA21693 apiLogAsyncResult = null;
						String rsltDtlCtt = null;
						boolean skipFlag = true;
						for (BQA21693 apiLogAsyncResult2 : apiLogAsyncResultList) {
							rsltDtlCtt = apiLogAsyncResult2.getRsltDtlCtt();
							if (rsltDtlCtt == null || rsltDtlCtt.isEmpty() || "null".equals(rsltDtlCtt)) {
								continue;
							}
							apiLogAsyncResult = apiLogAsyncResult2;
							skipFlag = false;
							break;
						}
						if (skipFlag) continue;
						logger.info(String.format("(dgnsReqDtm=%s),(dgnsIfId=%s),(dgnsReqId=%s),(rsltDtlCtt=%s)",
								apiLogAsyncResult.getDgnsReqDtm(), apiLogAsyncResult.getDgnsIfId(), apiLogAsyncResult.getDgnsReqId(), rsltDtlCtt));
						// getOntResetResult : {"resetCd":1.0,"contents":"***","beginUptime":1.633707653531E12,"description":"ont-reset success..(r\u003d1)","resetStatus":"SUCCESS","endUptime":1.633707661914E12}
						// getCmResetResult  : {"resetCd":1.0,"contents":"***","beginUptime":1.633765835919E12,"description":"reset success!!","resetStatus":"SUCCESS","endUptime":1.633765837379E12}
						// getStbResetResult : {"resetCd":0.0,"contents":"{\"contents\":{\"output\":{\"destIp\":\"175.122.253.24\",\"destPort\":30814,\"contents\":\"RESULT\u003d1\"}},\"additionalText\":null,\"retDescription\":\"SUCCESS\",\"retCd\":\"E00\"}","beginUptime":1.633705523993E12,"description":"stb reset fail..","resetStatus":"FAIL","endUptime":1.633705523993E12}

						// getApResetResult  : {"resetCd":1.0,"contents":"{\"contents\":{\"output\":{\"time-diff\":12,\"perf-el\":3.104247808456421,\"last\":{\"KA-DATA:VERSION\":\"1.15.10\",\"KA-DATA:NEED_ACK\":\"0\",\"KA-DATA:SYSNAME\":\"DVW-2200N\",\"KA-DATA:IP\":\"211.58.134.188\",\"PORT-DATA-LAST\":\"2021-10-08 23:56:15\",\"KA-DATA:T\":\"KEEP-ALIVE\",\"IP-PORT\":\"211.58.134.188:25353\",\"KA-SEQ\":\"1\",\"KA-DATA:MAC_WIFI\":\"0008523e49d1\",\"KA-LAST\":\"2021-10-09 00:00:18\",\"_MAC\":\"0008523e49d0\",\"KA-DATA:MAC_WAN\":\"0008523e49d0\",\"IGMP-DATA-LAST\":\"2021-10-08 23:20:29\",\"KA-DATA:SEQ\":\"1\"},\"utime\":\"2021-10-09 00:00:18\",\"col-ip\":\"175.122.253.89\",\"mac\":\"0008523e49d0\",\"uptime\":60,\"found\":[\"175.122.253.89\"],\"remote-ip\":\"211.58.134.188\",\"recv-cnt\":4,\"seq\":\"1\",\"sent-cnt\":5,\"uptime-s\":\"1m\"}},\"additionalText\":null,\"retDescription\":\"SUCCESS\",\"retCd\":\"E00\"}","beginUptime":1.75554E7,"description":"","resetStatus":"SUCCESS","endUptime":60.0}
						// getApResetResult  : {"resetCd":0.0,"contents":"{\"contents\":{\"cmdResult\":{\"opResultCd\":\"O99\",\"opType\":\"SNMP\",\"opContents\":{},\"opResultTxt\":\"org.apache.commons.exec.ExecuteException: Process exited with an error: 1 (Exit value: 1)\"}},\"additionalText\":null,\"retDescription\":\"SUCCESS\",\"retCd\":\"E00\",\"requesterId\":\"ITMS\",\"requestId\":\"f04e846606b148c58b337d1d0287df77\"}","beginUptime":0.0,"description":"reset fail (apreset fail retVal: null)!!!","resetStatus":"FAIL","endUptime":0.0}
						// getApResetResult  : {"resetCd":1.0,"contents":"{\"contents\":{\"cmdResult\":{\"resetResultCd\":\"O00\",\"resetResultTxt\":\"reset success.......\",\"resetContents\":\"snmp reset.....\"}},\"additionalText\":null,\"retDescription\":\"SUCCESS\",\"retCd\":\"E00\",\"requesterId\":\"ITMS\",\"requestId\":\"3d3e3cebe3d447f0a7504212b174d417\"}","beginUptime":0.0,"description":"","resetStatus":"SUCCESS","endUptime":0.0}
						// setApHandle       : {"cmdResult":{"resetResultCd":"O00","resetResultTxt":"reset success.......","resetContents":"snmp reset....."}}


						//rsltDtlCtt = rsltDtlCtt.replace("\\", "");
						JSONObject jsonObj2 = (JSONObject) jsonParser.parse(rsltDtlCtt);
						if (jsonObj2 == null) continue;
						if ("getStbPushResetResult".equals(apiLogAsyncResult.getDgnsIfId())) {
							Object obj = jsonObj2.get("eventState");
							if (obj != null) {
								String eventState = obj.toString();
								apiLog.setResetSussYn("Y");
								/*
								if ("DONE".equals(eventState)) {
									apiLog.setResetSussYn("Y");
								} else {
									apiLog.setResetSussYn("N");
								}*/
								// resetOperEndDtm
								apiLog.setResetOperEndDtm(apiLog.getDgnsReqDtm());
								apiLog.setCmdExecMthdCtt("Push");
							}
						} else {
							if ("stbPushReset".equals(apiLogAsyncResult.getDgnsIfId())) {
								apiLog.setCmdExecMthdCtt("Push");
							}
							Object obj = jsonObj2.get("resetCd");
							if (obj != null) {
								String resetCd = obj.toString();
								if (resetCd != null) {
									if (resetCd.startsWith("1")) {
										apiLog.setResetSussYn("Y");
									} else {
										apiLog.setResetSussYn("N");
									}
									apiLog.setResetOperEndDtm(apiLogAsyncResult.getRsltTrmsDtm());
								}
							}
						}
						
						try {
							if ("getStbPushResetResult".equals(apiLogAsyncResult.getDgnsIfId()) == false) {
								if (parseContents(jsonObj2, apiLogAsyncResult, apiLog) == false) {
									parseCmdResult(jsonObj2, apiLogAsyncResult, apiLog);
								}
							}
						} catch (Exception e) {
							logger.error(String.format("(DGNS_REQ_ID=%s) %s", apiLog.getDgnsReqId(), rsltDtlCtt));
							logger.error("skip error", e);
						}
					}
					jsonObj = (JSONObject) jsonParser.parse(apiLog.getParamVal());
					String mac = (String) jsonObj.get("mac");
					if (mac != null) {
						mac = mac.replaceAll(":", "").toUpperCase();
						if (mac.length() > 15) {
							logger.error(String.format("invalid mac(%s", mac));
							continue;
						}
						apiLog.setMacAddrVal(mac);
					} else {
						Object obj = jsonObj.get("key");
						if (obj != null) {
							List<Object> objList = (List<Object>) obj;
							apiLog.setMacAddrVal((String) objList.get(0)); 
						}
					}
					String inetSvcMgmtNum = (String) jsonObj.get("INET_SVC_MGMT_NUM");
					if (inetSvcMgmtNum != null) {
						apiLog.setInetSvcMgmtNum(Long.parseLong(inetSvcMgmtNum));
					}
					String iptvSvcMgmtNum = (String) jsonObj.get("IPTV_SVC_MGMT_NUM");
					if (iptvSvcMgmtNum != null) {
						apiLog.setIptvSvcMgmtNum(Long.parseLong(iptvSvcMgmtNum));
					}
					if ("executeCmd".equals(apiLog.getDgnsIfId())) {
						String commandReqMessage = (String) jsonObj.get("commandReqMessage");
						commandReqMessage = commandReqMessage.replace("\\", "");
						JSONObject jsonObj2 = (JSONObject) jsonParser.parse(commandReqMessage);
						apiLog.setCmdCd((String) jsonObj2.get("cmd"));
					}
				} catch (Exception e) {
					if ("executeCmd".equals(apiLog.getDgnsIfId()) || "executeCmdWithResult".equals(apiLog.getDgnsIfId())) {
						String cmdCd = getCmdValue(apiLog.getParamVal());
						if (cmdCd != null) {
							try {
								apiLog.setCmdCd(cmdCd);
								apiLog.setMacAddrVal(getMacValue(apiLog.getParamVal()));
							} catch (Exception e1) {
								logger.error(String.format("error (dgnsReqDtm=%s),(dgnsReqrId=%s),(dgnsIfId=%s),(dgnsReqId=%s)",
										apiLog.getDgnsReqDtm(), apiLog.getDgnsReqrId(), apiLog.getDgnsIfId(), apiLog.getDgnsReqId()), e);
								continue;
							}
						}
					} else {
						logger.error(String.format("error (dgnsReqDtm=%s),(dgnsReqrId=%s),(dgnsIfId=%s),(dgnsReqId=%s)",
								apiLog.getDgnsReqDtm(), apiLog.getDgnsReqrId(), apiLog.getDgnsIfId(), apiLog.getDgnsReqId()), e);
						continue;
					}
				}
				sqlSession.update(updateApiLogQid, apiLog);
			}
			sqlSession.commit();
			logger.info("committed");
		}
		sqlSession.close();
	}
	
	private boolean parseContents(JSONObject jsonObj, BQA21693 apiLogAsyncResult, BQA21693 apiLog) throws Exception {
		Object obj = jsonObj.get("contents");
		if (obj != null) {
			String contents = obj.toString();
			if (StringUtils.isEmpty(contents) == false) {
				JSONObject jsonObjContents = (JSONObject) jsonParser.parse(contents);
				Object obj2 = jsonObjContents.get("contents");
				if (obj2 != null) {
				String contents2 = obj2.toString();
					if (StringUtils.isEmpty(contents2) == false) {
						JSONObject jsonObjContents2 = (JSONObject) jsonParser.parse(contents2);
						return parseCmdResult(jsonObjContents2, apiLogAsyncResult, apiLog);
					}
				} else {
					return false;
				}
			}
			return true;
		} else {
			return false;
		}
	}
	
	private boolean parseCmdResult(JSONObject jsonObj, BQA21693 apiLogAsyncResult, BQA21693 apiLog) throws Exception {
		// {"resetCd":1.0,"contents":"{\"contents\":
		//       {\"cmdResult\":{\"resetResultCd\":\"O00\",\"resetResultTxt\":\"reset success.......\",\"resetContents\":\"snmp reset.....\"}},\"additionalText\":null,\"retDescription\":\"SUCCESS\",\"retCd\":\"E00\",\"requesterId\":\"ITMS\",\"requestId\":\"3d3e3cebe3d447f0a7504212b174d417\"
		// }","beginUptime":0.0,"description":"","resetStatus":"SUCCESS","endUptime":0.0}
		// {"cmdResult":{"resetResultCd":"O00","resetResultTxt":"reset success.......","resetContents":"snmp reset....."}}
		// {"cmdResult":{"opResultCd":"O99","opType":"SNMP","opContents":{},"opResultTxt":"org.apache.commons.exec.ExecuteException: Process exited with an error: 1 (Exit value: 1)"}}
		Object obj = jsonObj.get("cmdResult");
		if (obj != null) {
			String cmdResult = obj.toString();
			if (StringUtils.isEmpty(cmdResult) == false) {
				JSONObject jsonObjCmdResult = (JSONObject) jsonParser.parse(cmdResult);
				obj = jsonObjCmdResult.get("opType");
				if (obj != null) {
					apiLog.setCmdExecMthdCtt(obj.toString());
				}
				obj = jsonObjCmdResult.get("resetResultCd");
				if (obj != null) {
					String resetResultCd = obj.toString();
					if ("O00".equals(resetResultCd)) {
						apiLog.setResetSussYn("Y");
					} else {
						apiLog.setResetSussYn("N");
					}
					apiLog.setResetOperEndDtm(apiLogAsyncResult.getRsltTrmsDtm());
				}
				if (StringUtils.isEmpty(apiLog.getCmdExecMthdCtt())) {
					obj = jsonObjCmdResult.get("resetContents");
					if (obj != null) {
						String resetContents = obj.toString();
						if (resetContents != null) {
							if (resetContents.startsWith("snmp")) {
								apiLog.setCmdExecMthdCtt("SNMP");
							} else {
								apiLog.setCmdExecMthdCtt("HP");
							}
						}
					}					
				}
				if (StringUtils.isEmpty(apiLog.getResetSussYn())) {
					obj = jsonObjCmdResult.get("opResultCd");
					if (obj != null) {
						String opResultCd = obj.toString();
						if ("O00".equals(opResultCd)) {
							apiLog.setResetSussYn("Y");
						} else {
							apiLog.setResetSussYn("N");
						}
						apiLog.setResetOperEndDtm(apiLogAsyncResult.getRsltTrmsDtm());
					}
				}
				logger.info(String.format("(resetSussYn=%s),(resetOperEndDtm=%s),(cmdExecMthdCtt=%s) <= (dgnsReqDtm=%s),(dgnsIfId=%s),(dgnsReqId=%s),(cmdResult=%s)",
						apiLog.getResetSussYn(), apiLog.getResetOperEndDtm(), apiLog.getCmdExecMthdCtt(),
						apiLogAsyncResult.getDgnsReqDtm(), apiLogAsyncResult.getDgnsIfId(), apiLogAsyncResult.getDgnsReqId(),
						cmdResult));
			}
			return true;
		} else {
			return false;
		}
		
	}

	private String getCmdValue(String paramStr) {
		int pos = paramStr.indexOf("\\\"cmd\\\"");
		if (pos != -1) {
			return paramStr.substring(pos+10,pos+13);
		}
		return null;
	}

	private String getMacValue(String paramStr) {
		int pos = paramStr.indexOf("\\\"mac\\\"");
		if (pos != -1) {
			return paramStr.substring(pos+10,pos+22);
		}
		return null;
	}
	
	private boolean isAysncApi(String dnsIfId) {
		if (dnsIfId.indexOf("Async") == -1) return false;
		return true;
	}

	public static void main(String[] args) {
		Options options = new Options();
		Option startTimeOption = Option.builder().longOpt("START_TIME")
				.desc("START_TIME(YYYYMMDDHHMI)").hasArg().argName("START_TIME").required(false).build();
		options.addOption(startTimeOption);
		Option endTimeOption = Option.builder().longOpt("END_TIME")
				.desc("END_TIME(YYYYMMDDHHMI)").hasArg().argName("END_TIME").required(false).build();
		options.addOption(endTimeOption);
		EnvManager envManager = new EnvManager(args, options);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("ApiLogUpdater", envManager.getOptions());
    		System.exit(0);
    	}
    	try {
    		ApiLogUpdater apiLogUpader = new ApiLogUpdater(args);
    		apiLogUpader.run();
    	} catch (Exception e) {
    		e.printStackTrace();
    	}		
	}

}
