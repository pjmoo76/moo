package com.skb.mi.itms.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.cli.HelpFormatter;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.simple.parser.ParseException;


import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.skb.mi.common.Constants;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.common.OutputLog;


public class EdmpFileToDb {

	//final public String FILE_PATH = "C:/Users/Administrator/Desktop/es2oracle";
	//final public String FILE_NAME = "edmp_20241014_TEST.txt";
	public final static Logger logger = LogManager.getLogger(EdmpFileToDb.class.getName());
	HashMap<String, Object> dataMap = new HashMap<String, Object>();
	
	String regex = "(\\d{4})(0[1-9]|1[0-2])(0[1-9]|[12][0-9]|3[01])";
	SqlSession adamsbsSession;
	OutputLog outputLog;
	
	public EdmpFileToDb(String[] args) {
		
		String FILE_PATH = args[2];
		String FILE_NAME = args[3];
		
		File dir = new File(FILE_PATH);

		logger.debug("file_path : " + FILE_PATH);
		logger.debug("file_name : " + FILE_NAME);
		
		if (dir.isDirectory() && dir.exists()) {
			File[] files = dir.listFiles();
	
			if (files != null) {
				try {
					logger.debug("DB Connection....");
					adamsbsSession = IbatisSessionFactory.openSession(Constants.ADAMSBS_DB);
				} catch (Exception e1) {
					logger.debug("DB Connection Error : " + e1);
					System.exit(0); 
				}
				if (dir.isDirectory() && files != null) {
					try {
						FileReader fileReader = new FileReader(FILE_PATH + "/" + FILE_NAME);
						BufferedReader bufferedReader = new BufferedReader(fileReader);
						String rowData = null;
						int sucessCount = 0;
						int line = 0;
						while (true) {
							rowData = bufferedReader.readLine();
							if (rowData == null) {
								break;
							}
							try {
								processData(rowData, FILE_NAME);

								// rowData가 있을 경우 insert
								if (!dataMap.isEmpty()) {
									logger.debug("row data : " + dataMap);
									int result = adamsbsSession.insert("edmpFileToDb.INSERT_BIV20901", dataMap);
									
									if(result == 1) {
										sucessCount++;
									}		
								}
							} catch (Exception e) {
								logger.debug("data insert error : " + e);
							}
							line++;
						}
						logger.info(FILE_NAME + " file line count : " + line);
						logger.info("insert data count " + sucessCount);
						adamsbsSession.commit();
					} catch (Exception e) {
						logger.debug("file error.... " + e);
					} finally {
						logger.debug("finish....");
						adamsbsSession.close();
					}
				}
			}
		}
	}

	public HashMap<String, Object> processData(String rowData, String fileName) {
		
		if (rowData != null) { 
			try {					
					//FILE의 날짜 추출 정규식
					Pattern pattern = Pattern.compile(regex);
					Matcher matcher = pattern.matcher(fileName);
					String mntrdt = null;
					
					while(matcher.find()){
						mntrdt = matcher.group();
					}
					String splitData[] = rowData.split("\\|", -1);
					
					// setStbMacAddr
					String setStbMacAddr = splitData[0].replace(":", "").toUpperCase();
					
					// setIptvSvcMgmtNum
					long setIptvSvcMgmtNum = Long.parseLong(splitData[1]);
					
					// setUqpUptimeTmsInfo
					String setUqpUptimeTmsInfo = splitData[4].replace(":","").replace(".","").replace(" ", "");
					
					//setlastUpdTmsInfo
					String setlastUpdTmsInfo = splitData[8].replace(":","").replace(".","").replace(" ", "");
									
					//적재데이터 put
					dataMap.put("mntrdt", mntrdt);
					dataMap.put("stbMacAddr", setStbMacAddr); // STBMAC주소
					dataMap.put("iptvSvcMgmtNum", setIptvSvcMgmtNum); // 서비스 번호
					dataMap.put("stbVerInfo", splitData[2]); // STB설치버전
					dataMap.put("stbVerCtt", splitData[3]); // STB계획버전
					dataMap.put("eqpUptimeTmsInfo", setUqpUptimeTmsInfo); // 업타임 일시
					dataMap.put("stbPrvIpAddr", splitData[5]); // STB 내부IP
					dataMap.put("stbOrcgnIpAddr", splitData[6]); // STB 외부IP
					dataMap.put("patchGrpCtt", splitData[7]); // 계획버전 계획서명
					dataMap.put("lastUpdTmsInfo", setlastUpdTmsInfo); // 최종 업데이트 일자		

			} catch (Exception e) {
				logger.debug("data process error: " + e);
			}
		}
		return dataMap;
	}

	public static void main(String[] args) {
		
		 EnvManager envManager = new EnvManager(args);
		 
		 if (envManager.isValid() == false) { 
			 HelpFormatter formatter = new HelpFormatter(); 
			 formatter.printHelp("EdmpFileToDb", envManager.getOptions());
			 System.exit(0); 
			 }
		 
			new EdmpFileToDb(args);	
	}
}
