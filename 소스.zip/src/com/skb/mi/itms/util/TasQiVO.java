package com.skb.mi.itms.util;

public class TasQiVO {
	private	String	l2Tid = "";
	private	String	tvSvcmgmtNum = "";
	private	String	inetSvcmgmtNum = "";
	private	String	msgTs = "";
	private	String	measureTs = "";
	private	String	inetServiceNum = "";
	private	String	epg = "";
	private	String	l3Tid = "";
	private	String	badJt = "";
	private	String	atime = "";
	private	String	badOverall = "";
	private	String	area1 = "";
	private	String	area2 = "";
	private	String	chanStartTs = "";
	private	String	chanIpPort = "";
	private	String	stbId = "";

	public String getL2Tid() {
		return l2Tid;
	}
	public void setL2Tid(String l2Tid) {
		this.l2Tid = l2Tid;
	}
	public String getTvSvcmgmtNum() {
		return tvSvcmgmtNum;
	}
	public void setTvSvcmgmtNum(String tvSvcmgmtNum) {
		this.tvSvcmgmtNum = tvSvcmgmtNum;
	}
	public String getInetSvcmgmtNum() {
		return inetSvcmgmtNum;
	}
	public void setInetSvcmgmtNum(String inetSvcmgmtNum) {
		this.inetSvcmgmtNum = inetSvcmgmtNum;
	}
	public String getMsgTs() {
		return msgTs;
	}
	public void setMsgTs(String msgTs) {
		this.msgTs = msgTs;
	}
	public String getMeasureTs() {
		return measureTs;
	}
	public void setMeasureTs(String measureTs) {
		this.measureTs = measureTs;
	}
	public String getInetServiceNum() {
		return inetServiceNum;
	}
	public void setInetServiceNum(String inetServiceNum) {
		this.inetServiceNum = inetServiceNum;
	}
	public String getEpg() {
		return epg;
	}
	public void setEpg(String epg) {
		this.epg = epg;
	}
	public String getL3Tid() {
		return l3Tid;
	}
	public void setL3Tid(String l3Tid) {
		this.l3Tid = l3Tid;
	}
	public String getBadJt() {
		return badJt;
	}
	public void setBadJt(String badJt) {
		this.badJt = badJt;
	}
	public String getAtime() {
		return atime;
	}
	public void setAtime(String atime) {
		this.atime = atime;
	}
	public String getBadOverall() {
		return badOverall;
	}
	public void setBadOverall(String badOverall) {
		this.badOverall = badOverall;
	}
	public String getArea1() {
		return area1;
	}
	public void setArea1(String area1) {
		this.area1 = area1;
	}
	public String getArea2() {
		return area2;
	}
	public void setArea2(String area2) {
		this.area2 = area2;
	}
	public String getChanStartTs() {
		return chanStartTs;
	}
	public void setChanStartTs(String chanStartTs) {
		this.chanStartTs = chanStartTs;
	}
	public String getChanIpPort() {
		return chanIpPort;
	}
	public void setChanIpPort(String chanIpPort) {
		this.chanIpPort = chanIpPort;
	}
	public String getStbId() {
		return stbId;
	}
	public void setStbId(String stbId) {
		this.stbId = stbId;
	}

}
