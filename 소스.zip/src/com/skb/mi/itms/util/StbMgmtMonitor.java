package com.skb.mi.itms.util;

import java.io.File;
import java.math.BigDecimal;
import java.util.HashMap;

import org.apache.commons.cli.HelpFormatter;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.common.MiscUtils;
import com.skb.mi.model.TblSubmitQueue;

public class StbMgmtMonitor {
	final private String	ServiceName = "StbMgmtMonitor"; 
	private Logger	logger;
	private	String	monDbName;
	private	String	smsDbName;
	private	int		sleepSec	= 300;	// 5min
	
	private	SqlSession	monSession;
	private	SqlSession	smsSession;
	

	public StbMgmtMonitor() {
		logger = LogManager.getLogger(this.getClass().getName());
		loadConfig();
	}

	private void loadConfig() {
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		monDbName = configManager.getConfig(ServiceName, "monDbName");
		smsDbName = configManager.getConfig(ServiceName, "smsDbName");
		try {
			sleepSec = Integer.parseInt(configManager.getConfig(ServiceName, "sleepSec"));
		} catch (Exception e) {
		}
		logger.info(String.format("(monDbName=%s)", monDbName));
		logger.info(String.format("(smsDbName=%s)", smsDbName));
		logger.info(String.format("(sleepSec=%d)", sleepSec));
	}

	public void run() {
		while (true) {
			try {
				monSession = IbatisSessionFactory.openSession(monDbName);
				HashMap<String,Object> resultMap = (HashMap<String,Object>) monSession.selectOne("sql_stb_mgmt_monitor.SELECT_LAST_QI_STAT");
				if (resultMap != null) {
					String mntrDthm = (String) resultMap.get("MNTR_DTHM");
					int diffMin = ((BigDecimal) resultMap.get("DIFF_MIN")).intValue();
					if (diffMin <= 60) {
						if (smsSession == null) {
							smsSession = IbatisSessionFactory.openSession(smsDbName);
						}
						TblSubmitQueue sms = new TblSubmitQueue();
						sms.setRcvPhnId("01042878572");
						sms.setMsgTitle("ADAMS STB");
						sms.setSndMsg(String.format("LAST QI STAT (mntrDthm=%s),(diff=%d)", mntrDthm, diffMin));
						smsSession.insert("sql_stb_mgmt_monitor.SEND_SMS", sms);
						smsSession.commit();
					}
				}
			} catch (PersistenceException pe) {
				logger.error("PersistenceException", pe);
			} catch (Exception e) {
				logger.error("Exception", e);
			} finally {
				if (monSession != null) {
					monSession.close();
					monSession = null;
				}
				if (smsSession != null) {
					smsSession.close();
					smsSession = null;
				}
			}
			MiscUtils.sleep(sleepSec * 1000);
		}
	}

	public static void main(String[] args) {
		EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("StbMgmtMonitor", envManager.getOptions());
    		System.exit(0);
    	}
    	StbMgmtMonitor monitor = new StbMgmtMonitor();
    	monitor.run();
	}

}
