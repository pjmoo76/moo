package com.skb.mi.itms.util;

import java.io.File;
import java.util.List;

import org.apache.commons.cli.HelpFormatter;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.common.MiscUtils;
import com.skb.mi.common.StringUtils;
import com.skb.mi.itms.model.BQA21691;
import com.skb.mi.model.OIV10867;

public class ApResetUpdater {
	final private String	ServiceName = "ApResetUpdater";
	private Logger		logger;
	private	String		apUptimeDbName;
	private	String		apResetDbName;
	private	String		selectApResetFailureQid;
	private	String		selectApUptimeQid;
	private	String		updateApResetResultQid;
	
	public ApResetUpdater(String[] args) {
		logger = Logger.getLogger(this.getClass());
	}
	
	private void loadConfig() throws Exception {
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		apUptimeDbName = configManager.getConfig(this.ServiceName, "apUptimeDbName");
		apResetDbName = configManager.getConfig(this.ServiceName, "apResetDbName");
		selectApResetFailureQid = configManager.getConfig(this.ServiceName, "selectApResetFailureQid");
		selectApUptimeQid = configManager.getConfig(this.ServiceName, "selectApUptimeQid");
		updateApResetResultQid = configManager.getConfig(this.ServiceName, "updateApResetResultQid");
		
		logger.info(String.format("(apUptimeDbName=%s),(apResetDbName=%s),(selectApResetFailureQid=%s),(selectApUptimeQid=%s),(updateApResetResultQid=%s)",
				apUptimeDbName, apResetDbName, selectApResetFailureQid, selectApUptimeQid, updateApResetResultQid));
	}
	
	public void run() {
		SqlSession	apUptimeSqlSession = null;
		SqlSession	apResetSqlSession = null;
		while (true) {
			try {
				apResetSqlSession = IbatisSessionFactory.openSession(apResetDbName);
				List<BQA21691> apResetFailList = apResetSqlSession.selectList(this.selectApResetFailureQid);
				if (apResetFailList != null && apResetFailList.size() > 0) {
					apUptimeSqlSession = IbatisSessionFactory.openSession(apUptimeDbName);
					List<OIV10867> apUptimeList = apUptimeSqlSession.selectList(this.selectApUptimeQid, apResetFailList);
					if (apUptimeList != null && apUptimeList.size() > 0) {
						for (OIV10867 apUptime : apUptimeList) {
							BQA21691 apResetFail = find(apResetFailList, apUptime);
							if (apResetFail != null) {
								logger.info(String.format("get uptime(%s) for (resetSussYn=%s),(useDtm=%s),(integDgnsSerNum=%d),(resetOperStaDtm=%s),(resetAddrVal=%s),(rsltCtCtt=%s)",
										apUptime.getEqpUptimeTmsInfo(),
										apResetFail.getResetSussYn(), apResetFail.getUseDtm(), apResetFail.getIntegDgnsSerNum(),
										apResetFail.getResetOperStaDtm(), apResetFail.getResetAddrVal(), apResetFail.getRsltCdCtt() ));
								boolean updateFlag = false;
								if ("Y".equals(apResetFail.getResetSussYn())) {
									if (StringUtils.isEmpty(apResetFail.getEqpUptimeTmsInfo())) {
										apResetFail.setEqpUptimeTmsInfo(apUptime.getEqpUptimeTmsInfo());
										updateFlag = true;
									} else if (apResetFail.getResetOperStaDtm().compareTo(apUptime.getEqpUptimeTmsInfo())  <= 0) {
										apResetFail.setEqpUptimeTmsInfo(apUptime.getEqpUptimeTmsInfo());
										updateFlag = true;										
									}
								} else {
									if (isInitFailure(apResetFail)) {
										if (StringUtils.isEmpty(apResetFail.getEqpUptimeTmsInfo())) {
											apResetFail.setEqpUptimeTmsInfo(apUptime.getEqpUptimeTmsInfo());
											updateFlag = true;
										}										
									} else {
										if (apResetFail.getResetOperStaDtm().compareTo(apUptime.getEqpUptimeTmsInfo())  <= 0) {
											apResetFail.setResetOperEndDtm(apUptime.getEqpUptimeTmsInfo());
											apResetFail.setEqpUptimeTmsInfo(apUptime.getEqpUptimeTmsInfo());
											apResetFail.setResetSussYn("Y");
											updateFlag = true;
										} else {
											if (StringUtils.isEmpty(apResetFail.getEqpUptimeTmsInfo())) {
												apResetFail.setEqpUptimeTmsInfo(apUptime.getEqpUptimeTmsInfo());
												updateFlag = true;
											}
										}
									}
								}
								if (updateFlag) {
									logger.info(String.format("set (resetSussYn=%s),(useDtm=%s),(integDgnsSerNum=%d),(resetOperStaDtm=%s),(resetAddrVal=%s) : (eqpUptimeTmsInfo=%s)",
											apResetFail.getResetSussYn(), apResetFail.getUseDtm(), apResetFail.getIntegDgnsSerNum(),
											apResetFail.getResetOperStaDtm(), apResetFail.getResetAddrVal(),
											apUptime.getEqpUptimeTmsInfo()));
									apResetSqlSession.update(this.updateApResetResultQid, apResetFail);
								}
							}
						}
					}
					apResetSqlSession.commit();
				}
			} catch (Exception e) {
				logger.error("error", e);
			} finally {
				if (apResetSqlSession != null) {
					apResetSqlSession.close();;
					apResetSqlSession = null;
				}
				if (apUptimeSqlSession != null) {
					apUptimeSqlSession.close();
					apUptimeSqlSession = null;
				}
			}
			MiscUtils.sleep(60*5*1000); // sleep 5 minutes
		}
	}
	
	private BQA21691 find(List<BQA21691> apResetFailList, OIV10867 apUptime) {
		for (BQA21691 obj : apResetFailList) {
			if (apUptime.getApMacAddr().equals(obj.getResetAddrVal())) {
				return obj;
			}
		}
		return null;
	}
	
	private boolean isInitFailure(BQA21691 apResetFail) {
		if ("O30".equals(apResetFail.getRsltCdCtt())) {
			return true;
		} else if ("O31".equals(apResetFail.getRsltCdCtt())) {
			return true;
		} else if ("O99".equals(apResetFail.getRsltCdCtt())) {
			return true;
		}
		return false;
	}

	public static void main(String[] args) {
		EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("ApResetUpdater", envManager.getOptions());
    		System.exit(0);
    	}

		ApResetUpdater updater = new ApResetUpdater(args);
		try {
			updater.loadConfig();
			updater.run();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
