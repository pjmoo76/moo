package com.skb.mi.itms.util;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.DateUtils;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.common.MiscUtils;
import com.skb.mi.itms.model.BQA22902;
import com.skb.mi.itms.model.QiStbviewer;

public class QiStbviewerUpdater {
	final private String	ServiceName = "QiStbviewerUpdater"; 
	private Logger		logger;
	private	SqlSession	sourceSqlSession;
	private	SqlSession	destSqlSession;
	
	private	String	sourceDbName;
	private	String	destDbName;
	private	String	periodVal;
	private	String	gapVal;
	
	private	HashMap<String,String> teamMap;
	
	public QiStbviewerUpdater(String[] args) {
		logger = Logger.getLogger(this.getClass());
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		sourceDbName = configManager.getConfig(ServiceName, "sourceDb");
		destDbName = configManager.getConfig(ServiceName, "destDb");
		periodVal = EnvManager.env.getOptionValue("PERIOD");
		if (periodVal == null || periodVal.isEmpty()) {
			periodVal = configManager.getConfig(ServiceName, "period");
		}
		gapVal = EnvManager.env.getOptionValue("GAP");
		if (gapVal == null || gapVal.isEmpty()) {
			gapVal = configManager.getConfig(ServiceName, "gap");
		}
		
		logger.info(String.format("(sourceDb=%s)", sourceDbName));
		logger.info(String.format("(destDb=%s)", destDbName));
		logger.info(String.format("(period=%s)", periodVal));
		logger.info(String.format("(gap=%s)", gapVal));
		
		init();
	}
	
	public void init() {
		teamMap = new HashMap<String,String>();
		/*
		NB00590000	강남운용팀	T102
		NB00620000	강북운용팀	T105
		1430503656	경남운용팀	T109
		1430503652	고양운용팀	T106
		NB00690000	대구운용팀	T110
		NB00580000	동작운용팀	T101
		1000139564	부산운용팀	T108
		1430503646	성남운용팀	T104
		NB00610000	수원운용팀	T104
		1000162704	인천운용팀	T126
		NB00720000	전남운용팀	T111
		NB00730000	전북운용팀	T112
		NB00770000	충강운용팀	T114
		1430503662	충남운용팀	T113
		 */
		teamMap.put("NB00590000", "T102");
		teamMap.put("NB00620000", "T105");
		teamMap.put("1430503656", "T109");
		teamMap.put("1430503652", "T106");
		teamMap.put("NB00690000", "T110");
		teamMap.put("NB00580000", "T101");
		teamMap.put("1000139564", "T108");
		teamMap.put("1430503646", "T104");
		teamMap.put("NB00610000", "T104");
		teamMap.put("1000162704", "T126");
		teamMap.put("NB00720000", "T111");
		teamMap.put("NB00730000", "T112");
		teamMap.put("NB00770000", "T114");
		teamMap.put("1430503662", "T113");
	}
	
	public void run() throws Exception {
		sourceSqlSession = IbatisSessionFactory.openSession(sourceDbName);
		destSqlSession = IbatisSessionFactory.openSession(destDbName);
		boolean isFirst = true;
		String	lastMntrDthm = null;
		String	lastAuditDtm = null;

		while (true) {
			//MiscUtils.sleep(MiscUtils.getNextMinuteMills()); // sleep to next minute
			HashMap<String, Object> hmap = null;
			List<BQA22902> qiList = null;
			try {
				if (isFirst) {
					hmap = new HashMap<String, Object>();
					hmap.put("PERIOD", periodVal);
					hmap.put("GAP", gapVal);
					logger.info(String.format(">>> first-search (periodVal=%s),(gapVal=%s)", periodVal, gapVal));
					qiList = sourceSqlSession.selectList("qi_stbviewer_update.FIRST_SELECT_BQA22902", hmap);
					if (qiList != null && qiList.size() > 0) {
						isFirst = false;
					}
				} else {
					hmap = new HashMap<String, Object>();
					hmap.put("MNTR_DTHM", lastMntrDthm);
					hmap.put("AUDIT_DTM", lastAuditDtm);
					hmap.put("GAP", gapVal);
					logger.info(String.format(">>> loop-search (lastMntrDthm=%s),(lastAuditDtm=%s),(gapVal=%s)", lastMntrDthm, lastAuditDtm, gapVal));
					qiList = sourceSqlSession.selectList("qi_stbviewer_update.SELECT_BQA22902", hmap);					
				}
				if (qiList != null && qiList.size() > 0) {
					logger.info(String.format("get %d qi", qiList.size()));
				} else {
					logger.info("get 0 qi");
				}
			} catch (PersistenceException pe) {
				logger.error("PersistenceException", pe);
				try {
					sourceSqlSession.close();
					sourceSqlSession = IbatisSessionFactory.openSession(sourceDbName);
					continue;
				} catch (Exception e) {
					logger.error(e);
				}				
			} catch (Exception e) {
				logger.error("Exception", e);
				continue;
			}
			try {
				if (qiList != null && qiList.size() > 0) {
					for (BQA22902 qi : qiList) {
						if (lastAuditDtm == null) {
							lastAuditDtm = qi.getAuditDtm();
							lastMntrDthm = qi.getMntrDthm();
						} else {
							if (lastAuditDtm.compareTo(qi.getAuditDtm()) < 0) {
								lastAuditDtm = qi.getAuditDtm();
							}
							if (lastMntrDthm.compareTo(qi.getMntrDthm()) < 0) {
								lastMntrDthm = qi.getMntrDthm();
							}
						}
						QiStbviewer destObj = convert(qi);
						QiStbviewer searchObj = destSqlSession.selectOne("qi_stbviewer_update.SEARCH_QI_STBVIEWER", destObj);
						if (searchObj == null || searchObj.getId() == 0) {
							logger.info(String.format("insert (mntrDthm=%s),(stbMacAddr=%s),(uuidVal=%s) => (atime=%d)", qi.getMntrDthm(), qi.getStbMacAddr(), qi.getUuidVal(), destObj.getAtime()));
							destSqlSession.insert("qi_stbviewer_update.INSERT_QI_STBVIEWER", destObj);							
						} else {
							logger.info(String.format("already exists (mntrDthm=%s),(stbMacAddr=%s),(uuidVal=%s),(auditDtm=%s)", qi.getMntrDthm(), qi.getStbMacAddr(), qi.getUuidVal(), qi.getAuditDtm()));
						}
					}
					destSqlSession.commit();
				}
			} catch (PersistenceException pe) {
				logger.error("PersistenceException", pe);
				try {
					destSqlSession.close();
					destSqlSession = IbatisSessionFactory.openSession(destDbName);
					continue;
				} catch (Exception e) {
					logger.error(e);
				}
			} catch (Exception e) {
				logger.error("Exception", e);
				logger.error(e);
			}
			sourceSqlSession.clearCache();
			destSqlSession.clearCache();
			
			MiscUtils.sleep(1000*60);
		}
	}
	
	private QiStbviewer convert(BQA22902 qi) {
		QiStbviewer obj = new QiStbviewer();
		obj.setAtime(DateUtils.getUnixTimeStamp("yyyyMMddHHmmss",qi.getEvtRcvDtm())/1000);
		obj.setStbId(qi.getStbMacAddr().toLowerCase());
		obj.setSrcIp(qi.getSrcIpAddr());
		if ("04".equals(qi.getNetClCd())) {
			obj.setNet("hfc");
		} else if ("03".equals(qi.getNetClCd())) {
			obj.setNet("fttx");
		} else {
			obj.setNet("etc");
		}
		obj.setArea1(qi.getInfoCntrCd());
		obj.setArea2(qi.getTpoCd());
		obj.setL3Id(qi.getL3EquipMgmtNum());
		obj.setL2Id(qi.getL2EquipMgmtNum());
		obj.setSeq(0);
		obj.setMeasureTs(qi.getMsrtTms());
		try {
			long msgTs = Long.parseLong(qi.getEvtMsgDtm());
			obj.setMsgTs(msgTs);
		} catch (Exception e) {
		}
		obj.setChanIpPort(qi.getChnlSvrIpAddr()+":"+qi.getChnlSvrPortNum());
		obj.setChanBitrate(qi.getChnlBpsVal());
		//obj.setChanStartTs(chanStartTs);
		obj.setChanJoinTs(qi.getChnlJoinTms());
		obj.setJitter(qi.getJitrVal());
		obj.setMls(qi.getMlsVal());
		obj.setTsLoss(qi.getTsLossVal());
		obj.setTsTot(qi.getTsTotCnt());
		obj.setEpg(qi.getEpgBpsVal());
		obj.setJfCnt(qi.getJoinFailCnt());
		obj.setBadJitter(Integer.parseInt(qi.getJitrStbQltyGrCd()));
		obj.setBadMls(Integer.parseInt(qi.getMlsStbQltyGrCd()));
		obj.setBadLoss(Integer.parseInt(qi.getTsLossStbQltyGrCd()));
		obj.setBadJt(Integer.parseInt(qi.getJoinTmsStbQltyGrCd()));
		obj.setBadEpg(Integer.parseInt(qi.getEpgStbQltyGrCd()));
		obj.setBadJf(Integer.parseInt(qi.getJoinFailStbQltyGrCd()));
		obj.setBadOverall(Integer.parseInt(qi.getStbQltyGrCd()));
		obj.setTeam(getTeam(qi.getTeamOrgId()));
		obj.setStbModel(qi.getStbMdlNm());
		obj.setStbVersion(qi.getStbVerCtt());
		obj.setL3Model(qi.getL3EquipMdlNm());
		obj.setL2Model(qi.getL2EquipMdlNm());
		obj.setTvServiceNum(""+qi.getIptvSvcNum());
		obj.setTvSvcmgmtNum(""+qi.getIptvSvcMgmtNum());
		obj.setInetServiceNum(""+qi.getInetSvcNum());
		obj.setInetSvcmgmtNum(""+qi.getInetSvcMgmtNum());
		obj.setL3Tid(qi.getL3EquipTidVal());
		obj.setL2Tid(qi.getL2EquipTidVal());
		obj.setpHour(DateUtils.getUnixTimeStamp("yyyyMMddHH", qi.getMntrDthm().substring(0,10))/1000);
		obj.setP5min(DateUtils.getUnixTimeStamp("yyyyMMddHHmm", qi.getMntrDthm().substring(0,12))/1000);
		obj.setpDate(DateUtils.getUnixTimeStamp("yyyyMMdd", qi.getMntrDthm().substring(0,8))/1000);
		obj.setPacketRecvTs(DateUtils.getUnixTimeStamp("yyyyMMddHHmmss", qi.getEvtRcvDtm())/1000);
		obj.setColSvr("99");
		
		return obj;
	}
	
	private String getTeam(String teamOrgId) {
		return teamMap.get(teamOrgId);
	}
	
	public static void main(String[] args) {
		Options options = new Options();
		Option periodOption = Option.builder().longOpt("PERIOD")
				.desc("Period(min)").hasArg().argName("PERIOD").required(false).build();
		options.addOption(periodOption);
		Option gapOption = Option.builder().longOpt("GAP")
				.desc("Gap(min)").hasArg().argName("GAP").required(false).build();
		options.addOption(gapOption);
    	EnvManager envManager = new EnvManager(args, options);

    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("StbS106QiCopier", envManager.getOptions());
    		System.exit(0);
    	}
    	QiStbviewerUpdater updater = new QiStbviewerUpdater(args);
		try {
			updater.run();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
