package com.skb.mi.itms.voc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQQueue;
import com.ibm.mq.constants.MQConstants;
import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.Constants;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.common.MiscUtils;
import com.skb.mi.common.StringUtils;
import com.skb.mi.model.OMN50201;
import com.skb.mi.model.OMN50202;
import com.skb.mi.swing.mq.MQConnection;
import com.skb.mi.thread.SendJsonThread;

/*
 *	UK2.ADAMS.REQ
 */
public class ItmsVocMgr {
	final	private	byte		ETX 	  = 0x03;

	int[] itemsSize = {10, 8, 6, 3, 7, 2, 2, 15, 15, 200
					 , 10, 1, 1, 10, 40, 15,5};
	
	int[] detailItemSize = {1 ,20 ,10 ,10 ,2};
	
	MQConnection 				mqconn = null;
	MQQueue 					queue = null;
	MQGetMessageOptions			gmo = null;

	String						queueManager;
	String						queueName;
	String						channelName;
	int							ccsId;
	String						swingIpAddress;
	int							swingPort;

    private Logger		logger;
	private	SqlSession	adamsSession;
	private	SqlSession	adamsbsSession;
	private	String		charsetName = "MS949";

	private	int		lineNo = 0;
	private	boolean batchFlag = false;
	private	String	tableName;
	private	int		batchIdx = 0;
	
	/* voc 장애*/
	final private String		NMS_CD 				= "000";	// OCO20101 테이블에 있음.
	final private String		NMS_NM 				= "SWING";

	final private String		NET_CL_CD 			= "99"; // 2091001 99에서 화면에 출력하기 위해 임시로 변경	
	final private String		NET_CL_NM 			= "ETC";

    final private String        GENERATE_EVENT      = "GEN";
    final private String        CLEAR_EVENT         = "CLR";
    final private String        GENERATE_VOC        = "GENVOC";

    final private String        GENERATED_FAULT_CD  = "01";
    final private String        CLEARED_FAULT_CD    = "03";

    final private String        GENERATED_FAULT_NM  = "장애접수";
    final private String        CLEARED_FAULT_NM    = "장애복구완료";

	final private String		TRANS_FAULT				= "04";
    final private String        TRANS_DABL_LCL_NM   	= "회선장애";
    
    final private String		DABL_GR_CD				= "11";
    final private String		DABL_MCL_CD				= "11";
    final private String		DABL_MCL_NM				= "신고접수";
    
	private	int		readLineNo = 0;
	/* voc 장애*/
	
	public ItmsVocMgr (String[] args) {
		logger = LogManager.getLogger(ItmsVocMgr.class.getName());
		logger.info("start");

		try {
			loadConfig();
			connectSwing();
			run();
			//vocGetTest();
		} catch (MQException ex) {
			if (ex.reasonCode == 2033) { // 더 이상 읽을 메시지가 없는 경우 발생하는 Exception 코드 2033
				logger.info("There is no message on the queue"); // 읽어낼 메시지가 없습니다
//				mqconn.commit(); // 트랜잭션 commit
			} else {
				try {
					queue = mqconn.reGetConnection(ex, 60000); // 네트워크 장애로 인한 커넥션이 단절되었을 경우 60초 지연 후 재연결 요청
				} catch (Exception er) {
					logger.error(er);
				}
			}
		} catch (Exception e) {
			logger.error(e);
		} finally {
			mqconn.rollback(); // 트랜잭션 rollback
			// Close the the Request Queue
			mqconn.close();
		}
	}
	
	public void loadConfig() {
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		swingIpAddress = configManager.getConfig(Constants.SWING_MQ, Constants.IP_ADDRESS);
		swingPort = Integer.parseInt(configManager.getConfig(Constants.SWING_MQ, Constants.PORT_NO));
		queueManager = configManager.getConfig(Constants.SWING_MQ, Constants.QUEUE_MANAGER);

		queueName = configManager.getConfig(Constants.ITMS_VOC_MGR, Constants.QUEUE_NAME);
		channelName = configManager.getConfig(Constants.ITMS_VOC_MGR, Constants.CHANNEL_NAME);
		ccsId = Integer.parseInt(configManager.getConfig(Constants.ITMS_VOC_MGR, Constants.CCS_ID));

		logger.info("swingIpAddress : " + swingIpAddress);
		logger.info("swingPort : " + swingPort);
		logger.info("queueManager : " + queueManager);
		logger.info("queueName : " + queueName);
		logger.info("channelName : " + channelName);
		logger.info("ccsId : " + ccsId);
	}

	public void connectSwing () throws Exception {
		mqconn = new MQConnection(); 
		mqconn.setqManager(queueManager);
		mqconn.setRequestQueue(queueName);
		mqconn.setHostName(swingIpAddress);
		mqconn.setPort(swingPort);
		mqconn.setChannel(channelName);
		mqconn.setCcsid(ccsId);

		queue = mqconn.getConnection(); // MQGET 커넥션 연결

		// Specify default get message options
		gmo = new MQGetMessageOptions();

		gmo.options = gmo.options | MQConstants.MQGMO_SYNCPOINT;
	}

	public void run() {
		int				count = 0;
		boolean			dbCheck = false;

		batchFlag = false;
		int errorContCnt = 0;
		while (true) {
			try {
				MQMessage message = new MQMessage();

				logger.debug("reading queue");
				queue.get(message, gmo);

				if (!dbCheck) {
					adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
					adamsbsSession = IbatisSessionFactory.openSession(Constants.ADAMSBS_DB);
                    dbCheck = true;
				}
				int strLen = message.getMessageLength();
				byte[] strData = new byte[strLen];
				message.readFully(strData);
				String msgText = new String(strData, charsetName); // MQ에서 읽은 메시지. 읽은 메시지를 후 처리 하시면 됩니다
				logger.info("MQ_VOC:" + msgText);

				process(strData);
				count = 0;
				mqconn.commit();
				errorContCnt = 0;
			} catch (MQException ex) {
				if (ex.reasonCode == 2033) { // 더 이상 읽을 메시지가 없는 경우 발생하는 Exception 코드 2033
					logger.info("Run:There is no message on the queue"); // 읽어낼 메시지가 없습니다
					if (count == 0) {
						mqconn.commit ();
						//readVocInfo ();
						if (dbCheck) {
                            adamsSession.close();
                            adamsSession = null;
                            dbCheck = false;
						}
					} else if (count == 60) {			// 10분 주기로 KeepAlive
//						keepAliveDB ();
						count = 0;					
					}
					++ count;
					// vocGetTest(); // 파일테스트일때만 활성화, 아니라면 비활성화 20191030
					MiscUtils.sleep(10000);				// 10초
				} else {
					try {
						queue = mqconn.reGetConnection(ex, 60000); // 네트워크 장애로 인한 커넥션이 단절되었을 경우 60초 지연 후 재연결 요청
					} catch (Exception er) {
						logger.error("Run:Retry connection", ex);
					}
				}
			} catch (SQLException se) {
				logger.error("SQLException", se);
				if (adamsSession != null) {
					adamsSession.close();
					adamsSession = null;
				}
				if (adamsbsSession != null) {
					adamsbsSession.close();
					adamsbsSession = null;
				}
				dbCheck = false;
			} catch (PersistenceException pe) {
				logger.error("PersistenceException", pe);
				if (adamsSession != null) {
					adamsSession.close();
					adamsSession = null;
				}
				if (adamsbsSession != null) {
					adamsbsSession.close();
					adamsbsSession = null;
				}
				dbCheck = false;
			} catch (Exception e) {
				logger.error("run", e);
				errorContCnt ++;
				if (errorContCnt == 3) {
					errorContCnt = 0;
					if (adamsSession != null) {
						adamsSession.close();
						adamsSession = null;
					}
					if (adamsbsSession != null) {
						adamsbsSession.close();
						adamsbsSession = null;
					}
					dbCheck = false;
				}
			}
		}
	}
	
	public void process(byte[] data) throws Exception {
		OMN50201 omn50201 = make(data);
		process(omn50201);
	}
	public void process(OMN50201 omn50201) throws Exception {
		logger.debug(omn50201.getMqDebugString());
		adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
		adamsbsSession = IbatisSessionFactory.openSession(Constants.ADAMSBS_DB);
		OMN50201 weqpRelInfo = adamsSession.selectOne("ItmsVocMgr.selectWeqpRelInfo", omn50201);
		if (weqpRelInfo != null) {
			omn50201.setSvcTechMthdCd(weqpRelInfo.getSvcTechMthdCd());
			omn50201.setApMdlNm(weqpRelInfo.getApMdlNm());
			omn50201.setApMacAddr(weqpRelInfo.getApMacAddr());
			omn50201.setApVerCtt(weqpRelInfo.getApVerCtt());
			omn50201.setStbMdlNm(weqpRelInfo.getStbMdlNm());
			omn50201.setStbMacAddr(weqpRelInfo.getStbMacAddr());
			omn50201.setStbVerCtt(weqpRelInfo.getStbVerCtt());
			omn50201.setInfoCntrCd(weqpRelInfo.getInfoCntrCd());
			omn50201.setDistbCntrCd(weqpRelInfo.getDistbCntrCd());
			omn50201.setL2EquipId(weqpRelInfo.getL2EquipId());
			omn50201.setL3EquipId(weqpRelInfo.getL3EquipId());
			if (omn50201.getL2EquipId() != null &&  "-".equals(omn50201.getL2EquipId()) == false) {
				omn50201.setEquipId(omn50201.getL2EquipId());
			} else {
				omn50201.setEquipId(omn50201.getL3EquipId());
			}
			omn50201.setSvcTechMthdNm(weqpRelInfo.getSvcTechMthdNm());
			omn50201.setCcellNum(weqpRelInfo.getCcellNum());
			omn50201.setApWeqpMgmtNum(weqpRelInfo.getApWeqpMgmtNum());
			omn50201.setApEqpMdlCd(weqpRelInfo.getApEqpMdlCd());
			omn50201.setStbWeqpMgmtNum(weqpRelInfo.getStbWeqpMgmtNum());
			omn50201.setStbEqpMdlCd(weqpRelInfo.getStbEqpMdlCd());
			omn50201.setShspdWeqpMgmtNum(weqpRelInfo.getShspdWeqpMgmtNum());
			omn50201.setShspdEqpMdlCd(weqpRelInfo.getShspdEqpMdlCd());
			omn50201.setShspdEqpMdlNm(weqpRelInfo.getShspdEqpMdlNm());
			omn50201.setShspdEqpMacAddr(weqpRelInfo.getShspdEqpMacAddr());
			omn50201.setShspdEqpVerCtt(weqpRelInfo.getShspdEqpVerCtt());
			omn50201.setShspdEqpMfactSerNum(weqpRelInfo.getShspdEqpMfactSerNum());
			omn50201.setIptvSvcMgmtNum(weqpRelInfo.getIptvSvcMgmtNum());
			omn50201.setInetSvcMgmtNum(weqpRelInfo.getInetSvcMgmtNum());
			omn50201.setPhonSvcMgmtNum(weqpRelInfo.getPhonSvcMgmtNum());
			logger.debug(String.format("(iptvSvcMgmtNum=%s),(inetSvcMgmtNum=%s),(phonSvcMgmtNum=%s)", weqpRelInfo.getIptvSvcMgmtNum(), weqpRelInfo.getInetSvcMgmtNum(), weqpRelInfo.getPhonSvcMgmtNum()));
		} else {
			HashMap<String, Object> hmap = adamsSession.selectOne("ItmsVocMgr.selectInfoCntrCd", omn50201);
			if (hmap != null) {
				logger.debug(String.format("(INFO_CNTR_CD=%s),(DISTB_CNTR_CD=%s)", (String) hmap.get("INFO_CNTR_CD"), (String) hmap.get("DISTB_CNTR_CD")));
				omn50201.setInfoCntrCd((String) hmap.get("INFO_CNTR_CD")); 
				omn50201.setDistbCntrCd((String) hmap.get("DISTB_CNTR_CD")); 
			}
		}
		List<HashMap<String, Object>> hmapList = adamsSession.selectList("ItmsVocMgr.selectNetClCd", omn50201);
		if (hmapList != null && hmapList.size() > 0) {
			logger.debug(String.format("(NET_CL_CD=%s)", (String) hmapList.get(0).get("NET_CL_CD")));
			omn50201.setNetClCd((String) hmapList.get(0).get("NET_CL_CD")); 
		}
		if (StringUtils.isEmpty(omn50201.getSvcTechMthdCd())
				|| StringUtils.isEmpty(omn50201.getNetClCd())
				|| ("03".equals(omn50201.getNetClCd()) == false && "04".equals(omn50201.getNetClCd()) == false)) {
			HashMap<String, Object> hmap = adamsSession.selectOne("ItmsVocMgr.selectSvcTechMthdCd", omn50201);
			if (hmap != null) {
				logger.debug(String.format("(SVC_TECH_MTHD_CD=%s),)(SVC_TECH_MTHD_NM=%s),(NET_CL_CD=%s)", (String) hmap.get("SVC_TECH_MTHD_CD"), (String) hmap.get("SVC_TECH_MTHD_NM"), (String) hmap.get("NET_CL_CD")));
				omn50201.setSvcTechMthdCd((String) hmap.get("SVC_TECH_MTHD_CD"));
				omn50201.setSvcTechMthdNm((String) hmap.get("SVC_TECH_MTHD_NM"));
				String netClCd = (String) hmap.get("NET_CL_CD");
				if (StringUtils.isEmpty(netClCd) == false) {
					omn50201.setNetClCd(netClCd);
				}
			}
		}
		//모든 CnslContClcd에 대해 insert 처리
		boolean insertFlag = true;
		//if ("I".equals(omn50201.getCnslContClCd())) {
		//	insertFlag = true;
			/*
			if ("2".equals(omn50201.getLinCallClCd())) { // 기업
				HashMap<String, Object> hmap = adamsSession.selectOne("ItmsVocMgr.selectSvcDtlClCdCnt", omn50201);
				if (hmap != null) {
					int cnt = ((BigDecimal) hmap.get("CNT")).intValue();
					if (cnt > 0) {
						insertFlag = true;
					}
				}				
			} else {
				insertFlag = true;
			}*/
		//}
		
		//sendJsonV2(omn50201); // 20190927 테스트중 insert 하지 않기위해 주석
		
		if (insertFlag) {
			HashMap<String, Object> hmap = adamsSession.selectOne("ItmsVocMgr.selectSswSbcNm", omn50201);
			if (hmap != null) {
				omn50201.setSswNm((String)hmap.get("SSW_NM"));
				omn50201.setSbcNm((String)hmap.get("SBC_NM"));
			}				
			if (batchFlag) {
				batchIdx ++;
				omn50201.setCnslSerNum(""+batchIdx);
				adamsbsSession.insert("ItmsVocMgr.insertBMN50201_batch", omn50201);
				adamsbsSession.commit();
				
			} else {
				logger.debug(String.format("(iptvSvcMgmtNum=%s),(inetSvcMgmtNum=%s),(phonSvcMgmtNum=%s)", omn50201.getIptvSvcMgmtNum(), omn50201.getInetSvcMgmtNum(), omn50201.getPhonSvcMgmtNum()));
				adamsbsSession.insert("ItmsVocMgr.insertBMN50201", omn50201);
				
				ArrayList<OMN50202> dtlList = omn50201.getDtlList();
				int dtlSize = dtlList.size();
				String cnslSerNum = omn50201.getCnslSerNum();

				for(int i=0;i<dtlSize;i++){
					OMN50202 omn50202 = dtlList.get(i);
					omn50202.setCnslSerNum(cnslSerNum);
					adamsbsSession.insert("ItmsVocMgr.insertBMN50202", omn50202);					
				}				
				
				adamsbsSession.commit();
				logger.debug("inserted");				
			}
		}
	}
	
	private OMN50201 make(byte[] data) throws Exception {
		/*
		 * idx  Field명            Column              Length
		 * -----------------------------------------------
			0	상담원ID			CSR_ID				10
			1	상담일자			CNSL_DT				8
			2	상담시각			CNSL_TM				6
			3	인입콜구분코드		LIN_CALL_CL_CD		3
			4	VOC유형분류코드		VOC_TYP_CL_CD		7
			5	상담처리상태코드	CNSL_OP_ST_CD		2
			6	장애처리상태코드	DABL_OP_ST_CD		2
			7	망장애식별번호		NET_DABL_IDNT_NUM	15
			8	주소ID				ADDR_ID				15
			9	전체주소			ALL_ADDR			200
			10	법정동코드			LDONG_CD			10
			11	불만구분코드		DSAT_CL_CD			1
			12	상담접촉구분코드	CNSL_CONT_CL_CD		1
			13	고객번호			CUST_NUM			10
			14	고객명				CUST_NM				    40
			15	장애접수번호		DABL_RCV_NUM		15
			16	처리건수			PROC_CNT				5
			17	서비스기술방식코드	SVC_TECH_MTHD_CD	1
			18	서비스번호			SVC_NUM				20
			19	서비스관리번호		SVC_MGMT_NUM		10
			20	요금상품ID			FEE_PROD_ID			10
			21	서비스상세구분코드	SVC_DTL_CL_CD		2
			22	상담메모			CNSL_MEMO			2000
			
		    ,2000
		 */
		
		ArrayList<String> items = StringUtils.getItems(data, this.itemsSize, charsetName);
		
		int nDetailSize = Integer.parseInt(items.get(16));
		int nItemSize = this.itemsSize.length;
		int nDetailItemSize = this.detailItemSize.length;
		int nRealItemSize = nItemSize + (nDetailSize * nDetailItemSize) + 1;
		
		int[] realItemsSize = new int[nRealItemSize];
		
		int realItemsIndex = 0;
		//앞부분 만들기		
		for(;realItemsIndex<nItemSize;realItemsIndex++)
		{		
			realItemsSize[realItemsIndex] = this.itemsSize[realItemsIndex];
		}	
		//뒷부분 만들기
		for(int i=0;i<nDetailSize;i++)
		{
			for(int j=0;j<nDetailItemSize;j++)
			{
				realItemsSize[realItemsIndex++] = this.detailItemSize[j];
			}
		}
		//MEMO 만들기
		realItemsSize[realItemsIndex++] = 2000;
		
		items = StringUtils.getItems(data, realItemsSize, charsetName);
		
		OMN50201 omn50201 = new OMN50201();
		omn50201.setCsrId(items.get(0));
		omn50201.setCnslDt(items.get(1));
		omn50201.setCnslTm(items.get(2));
		if ("MAS".equals(items.get(3))) { // 개인
			omn50201.setLinCallClCd("1");
		} else if ("CMP".equals(items.get(3))) { // 기업
			omn50201.setLinCallClCd("2");
		} else { // IPTV
			omn50201.setLinCallClCd("3");
		}
		omn50201.setVocTypClCd(items.get(4));
		omn50201.setCnslOpStCd(items.get(5));
		omn50201.setDablOpStCd(items.get(6));
		omn50201.setNetDablIdntNum(items.get(7));
		omn50201.setAddrId(items.get(8));
		omn50201.setAllAddr(items.get(9));
		omn50201.setLdongCd(items.get(10));
		omn50201.setDsatClCd(items.get(11));
		omn50201.setCnslContClCd(items.get(12));
		omn50201.setCustNum(items.get(13));
		omn50201.setCustNm(StringUtils.maskString(items.get(14)));
		omn50201.setDablRcvNum(items.get(15));
		int procCnt = Integer.parseInt(items.get(16));
		
		omn50201.setProcCnt(procCnt);
		
		if(procCnt == 0)
		{
			items.get(17).replace('{', '[');
			items.get(17).replace('}', ']');
			omn50201.setCnslMemo(items.get(17));
			
		}else{			
		
			//아래쪽은 새로 파싱
			omn50201.setSvcCd(items.get(17));
			omn50201.setSvcNum(items.get(18));
			omn50201.setSvcMgmtNum(items.get(19));
			omn50201.setFeeProdId(items.get(20));
			omn50201.setSvcDtlClCd(items.get(21));		
			int itemIndex = 17;
			ArrayList<OMN50202> dtlList =  new ArrayList<OMN50202> ();
			for(int i=0;i<nDetailSize;i++)
			{
				OMN50202 omn50202 = new OMN50202();
				omn50202.setCnslDt(items.get(1));			
				omn50202.setDtlSeq(i+1+"");
				omn50202.setLinCallClCd(omn50201.getLinCallClCd());
				omn50202.setSvcCd(items.get(itemIndex++));
				omn50202.setSvcNum(items.get(itemIndex++));
				omn50202.setSvcMgmtNum(items.get(itemIndex++));
				omn50202.setFeeProdId(items.get(itemIndex++));
				omn50202.setSvcDtlClCd(items.get(itemIndex++));
				dtlList.add(omn50202);
			}
		
		
			omn50201.setDtlList(dtlList);
			// 23. CNSL_MEMO
			items.get(itemIndex).replace('{', '[');
			items.get(itemIndex).replace('}', ']');
			omn50201.setCnslMemo(items.get(itemIndex));
		}
		
		
		omn50201.setVocRcvId(omn50201.getVocTypClCd());
		omn50201.setCnslDtm(omn50201.getCnslDt() + omn50201.getCnslTm());

		return omn50201;
	}

	public String changeDate (String date, String time) {
		String time1 = time.substring (0, 2) + ":" + time.substring (2, 4) + ":" + time.substring (4, 6);
		String date1 = date.substring (0, 4) + "/" + date.substring (4, 6) + "/" + date.substring (6, 8);
		return time1 + " " +date1;
	}

	public ItmsVocMgr() {
		logger = LogManager.getLogger(ItmsVocMgr.class.getName());
		this.loadConfig();
	}

	public void test() {
		batchFlag = true;
		tableName = "BMN50201";
		try {
			String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
			ConfigManager configManager = new ConfigManager(cfgFile);
			adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
			adamsbsSession = IbatisSessionFactory.openSession(Constants.ADAMSBS_DB);
			
			String data = null;
			
			data = "300110615020181025153645CMP350318703  0              100000000519272서울 영등포구 의사당대로 147, 18층 (여의도동,알리안츠타워) 알리안츠투신운용                                                                                                                             11560110001I9770002519                              (주)코스콤0              1    B          01218690127121779264NJ00000023B1[작업TM]식별번호 : 10137862" + System.getProperty("line.separator")
				+ "작업명 : 분당 호스트웨이 3층 FLC-PLUS 전원분리작업" + System.getProperty("line.separator")
				+ "작업일정 : 2018년 10월 26일 02:00~06:00" + System.getProperty("line.separator")
				+ "서비스영향 : 작업시간 내 영향없음" + System.getProperty("line.separator")
				+ "작업자 : 수원품질솔루션팀 서동연 010-4981-5413" + System.getProperty("line.separator")
				+ "10.11 김명희m 고객사 양석,이현국 외부메일 공문 발송 / 자세한 사항은 [전용회선작업tm조회]참고.";
			process(data.getBytes("MS949"));
			data = "100096822920181102000024MAS220070403  0                                                                                                                                                                                                                                               1N8654908261                                  이현석0              0    1. 불만내용" + System.getProperty("line.separator")
				+ "2. 케어내용" + System.getProperty("line.separator")
				+ "3. 요구사항";
			process(data.getBytes("MS949"));
		} catch (Exception e) {
			logger.error("batch", e);
		}
	}
	
	public void test2() {
		batchFlag = true;
		tableName = "BMN50201";
		
		try {
			String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
			ConfigManager configManager = new ConfigManager(cfgFile);
			adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
			
			batchIdx = 8;

			OMN50201 omn50201 = new OMN50201();
			omn50201.setCsrId("3002111710");
			omn50201.setCnslDt("20181025");
			omn50201.setCnslTm("130634");
			omn50201.setLinCallClCd("1");
			omn50201.setVocTypClCd("3001678");
			omn50201.setCnslOpStCd("03");
			omn50201.setDablOpStCd("10");
			omn50201.setNetDablIdntNum("0");
			omn50201.setAddrId("100000000143686");
			omn50201.setAllAddr("남 김해시 진영읍 김해대로 462, 101동 803호(진영휴먼시아아파트)");
			omn50201.setLdongCd("4825025027");
			omn50201.setDsatClCd("1");
			omn50201.setCnslContClCd("I");
			omn50201.setCustNum("9337343900");
			omn50201.setCustNm("최*희");
			omn50201.setDablRcvNum("99481288");
			omn50201.setSvcCd("1");
			omn50201.setSvcTechMthdCd(null);
			omn50201.setSvcNum("7290918006");
			omn50201.setSvcMgmtNum("7290918006");
			omn50201.setFeeProdId("NI00000282");
			omn50201.setSvcDtlClCd("I1");
			StringBuilder sb = new StringBuilder();
			sb.append("1. 고객요청: [인터넷 랜선 작업변경요청']\n");
			sb.append("2. 증상/조치결과:  꼼꼼하고 친절하게 바랍니다.\n");
			sb.append("3. 진단툴확인:");
			omn50201.setCnslMemo(sb.toString());
			omn50201.setVocRcvId(omn50201.getVocTypClCd());
			omn50201.setCnslDtm(omn50201.getCnslDt() + omn50201.getCnslTm());
			process(omn50201);
		} catch (Exception e) {
			logger.error("batch2", e);
		}
	}
	
	public void loadLogFile(String logFile) {
		if (logFile == null) return;
		batchFlag = true;
		tableName = "BMN50201_TMP";

		// [2018-11-20 08:59:04] INFO  VocGet:172 - MQ_VOC:100090841820181120085743MAS351080303300...
		// ...
		
		FileInputStream		fr = null;
		BufferedReader		br = null;
		try {
			adamsSession = IbatisSessionFactory.openSession(Constants.ADAMS_DB);
			adamsbsSession = IbatisSessionFactory.openSession(Constants.ADAMSBS_DB);
			fr = new FileInputStream(logFile);
			InputStreamReader ir = new InputStreamReader(fr, "euc-kr");
			br = new BufferedReader(ir);
			String strLine = null;
			String vocData = null;
			boolean flag = false;
			while ((strLine = br.readLine()) != null) {
				if (isFirstLine(strLine)) {
					if (vocData != null) {
						lineNo ++;
						process(vocData.getBytes("MS949"));
						vocData = null;
					}
					vocData = StringUtils.getRemainString(strLine, "MQ_VOC:");
					if (vocData == null) {
						flag = false;
					} else {
						logger.debug(strLine);
						flag = true;
					}
				} else {
					if (flag) {
						logger.debug(strLine);
						vocData = vocData + System.getProperty("line.separator") + strLine;
					}
				}
			}
			if (vocData != null) {
				process(vocData.getBytes());
			}
		} catch (Exception e) {
			logger.error(e);;
		}
	}
	
	private boolean isFirstLine(String data) {
		//           1         2
		// 012345678901234567890
		// [2018-11-20 08:59:04]
		if (data.charAt(0) == '[' && data.charAt(5) == '-' && data.charAt(8) == '-' && data.charAt(20) == ']') {
			return true;
		} else {
			return false;
		}
	}

	public static void main(String args[]) throws Exception {
		Options options = new Options();
		Option execModeOption = Option.builder().longOpt(Constants.EXEC_MODE).optionalArg(false)
				.desc("Exec Mode : TEST, LOG_RECOVERY").hasArg().argName(Constants.EXEC_MODE).build();
		Option batchOption = Option.builder().longOpt(Constants.FILE_NAME).optionalArg(false)
				.desc("File Name").hasArg().argName(Constants.FILE_NAME).build();
		options.addOption(execModeOption);
		options.addOption(batchOption);

		EnvManager envManager = new EnvManager(args, options);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("ItmsVocMgr", envManager.getOptions());
    		System.exit(0);
    	}
    	String execMode = EnvManager.env.getOptionValue(Constants.EXEC_MODE);
    	if ("TEST".equals(execMode)) {
    		
        	ItmsVocMgr vocMgr = new ItmsVocMgr();
        	String data = "100097699120190930075727CMP350281603  0              100000000738052인천 서구 봉수대로162번길 11 (가좌동,우리기업공장) 주식회사 광휘                                                                                                                                        28260112001I8024367656                           주식회사 광휘0              1    B          72560957687256095768NJ00000241B27256095768 / PC 1대 인터넷 불가 / ONT Active, 사설공유기 핑 정상, PC 네트워크 연결상태 정상, 로컬영역연결 사용안함-사용 후 정상복구";
        	vocMgr.process(data.getBytes("MS949"));
    	} else if ("LOG_RECOVERY".equals(execMode)) {
    		String logFile = EnvManager.env.getOptionValue(Constants.FILE_NAME);
    		ItmsVocMgr vocMgr = new ItmsVocMgr();
    		vocMgr.loadLogFile(logFile);    		
    	} else {
    		new ItmsVocMgr (args);    		
    	}
    	
    	//while(true) {
    		// 20190927 연결이 끊어지지 않게 while 문 생성, 프로세스 없애려면 restart(그냥 실행하면 죽이고 다시 살림) 혹은 kill 해야함
    	//}
	}
	
	/**************************************************
	 * 
	 **************************************************/
	public void vocGetTest() {
		batchFlag = false;
		try {
			logger.info("itmsVocMgrTest start");
			//String data = "100084023920190917024653CMP350284703  10326642       100000001431215광주 남구 서문대로 408 (송하동,광주일보사) 조선일보사                                                                                                                                                   29155112001I9440000319                          (주)조선일보사0              1    B          72587809407258780940NJ00000023B17258780940/ 작업 취소여부 확인요청/ 일련번호: 10326642 장애본복구작업, 취소이력없으며 06시까지 진행안내";
			//String data = "100100469020190917095230CMP350281503100              100000020016100울산 울주군 온산읍 강양리 719-4번지 유화산업                                                                                                                                                            31710250271I9790158319                            (주)유화산업102323003      1    B          72513981197251398119NJ00000249B27251398119/전체 인터넷 접속불가/ONT 상태 Active , 공유기 1.253.140.37 핑 불가, 공유기 리셋시 동일/빠른 일정 선통화후 방문 부탁드립니다";

			String data = vocReadTxtFile();
			
			readLineNo++;
			
        	process(data.getBytes("MS949"));
		
		} catch (Exception e) {
			logger.error("vocGetTest error", e);
		}
	}
	
	public String vocReadTxtFile() {
		String strLine = "";
		try{
			if(readLineNo >= 8000) readLineNo = 0;

			File file = new File("/home/miuser/adams/logs/VocGet.txt");
			FileReader filereader = new FileReader(file);
			BufferedReader bufReader = new BufferedReader(filereader);
			
			int iLine = 0;
			while((strLine = bufReader.readLine()) != null){

				if(readLineNo == iLine) {
					System.out.println(strLine);
					logger.info("strLine:"+strLine);
					
					break;
				}
				iLine++;				
			}
			
			bufReader.close();
			
		} catch (FileNotFoundException e) {
			logger.error("FileNotFoundException error", e);
		} catch (IOException e) {
			logger.error("IOException error", e);
		}
		return strLine;
	}

}
