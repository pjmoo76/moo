package com.skb.mi.itms.model;

public class BQA21693 {
	private	String	dgnsReqDtm;
	private	String	dgnsReqrId;
	private	String	dgnsIfId;
	private	String	dgnsReqId;
	private	String	auditId;
	private	String	auditDtm;
	private	String	paramVal;
	private	String	sussYn;
	private	String	rsltTrmsDtm;
	private	String	rsltDtlCtt;
	private	long	inetSvcMgmtNum;
	private	long	iptvSvcMgmtNum;
	private	String	weqpMdlTypCd;
	private	String	macAddrVal;
	private	String	cmdCd;
	private	String	resetSussYn;
	private	String	resetOperEndDtm;
	private String	cmdExecMthdCtt;

	public String getDgnsReqDtm() {
		return dgnsReqDtm;
	}
	public void setDgnsReqDtm(String dgnsReqDtm) {
		this.dgnsReqDtm = dgnsReqDtm;
	}
	public String getDgnsReqrId() {
		return dgnsReqrId;
	}
	public void setDgnsReqrId(String dgnsReqrId) {
		this.dgnsReqrId = dgnsReqrId;
	}
	public String getDgnsIfId() {
		return dgnsIfId;
	}
	public void setDgnsIfId(String dgnsIfId) {
		this.dgnsIfId = dgnsIfId;
	}
	public String getDgnsReqId() {
		return dgnsReqId;
	}
	public void setDgnsReqId(String dgnsReqId) {
		this.dgnsReqId = dgnsReqId;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getParamVal() {
		return paramVal;
	}
	public void setParamVal(String paramVal) {
		this.paramVal = paramVal;
	}
	public String getSussYn() {
		return sussYn;
	}
	public void setSussYn(String sussYn) {
		this.sussYn = sussYn;
	}
	public String getRsltTrmsDtm() {
		return rsltTrmsDtm;
	}
	public void setRsltTrmsDtm(String rsltTrmsDtm) {
		this.rsltTrmsDtm = rsltTrmsDtm;
	}
	public String getRsltDtlCtt() {
		return rsltDtlCtt;
	}
	public void setRsltDtlCtt(String rsltDtlCtt) {
		this.rsltDtlCtt = rsltDtlCtt;
	}
	public long getInetSvcMgmtNum() {
		return inetSvcMgmtNum;
	}
	public void setInetSvcMgmtNum(long inetSvcMgmtNum) {
		this.inetSvcMgmtNum = inetSvcMgmtNum;
	}
	public long getIptvSvcMgmtNum() {
		return iptvSvcMgmtNum;
	}
	public void setIptvSvcMgmtNum(long iptvSvcMgmtNum) {
		this.iptvSvcMgmtNum = iptvSvcMgmtNum;
	}
	public String getWeqpMdlTypCd() {
		return weqpMdlTypCd;
	}
	public void setWeqpMdlTypCd(String weqpMdlTypCd) {
		this.weqpMdlTypCd = weqpMdlTypCd;
	}
	public String getMacAddrVal() {
		return macAddrVal;
	}
	public void setMacAddrVal(String macAddrVal) {
		this.macAddrVal = macAddrVal;
	}
	public String getCmdCd() {
		return cmdCd;
	}
	public void setCmdCd(String cmdCd) {
		this.cmdCd = cmdCd;
	}
	public String getResetSussYn() {
		return resetSussYn;
	}
	public void setResetSussYn(String resetSussYn) {
		this.resetSussYn = resetSussYn;
	}
	public String getResetOperEndDtm() {
		return resetOperEndDtm;
	}
	public void setResetOperEndDtm(String resetOperEndDtm) {
		this.resetOperEndDtm = resetOperEndDtm;
	}
	public String getCmdExecMthdCtt() {
		return cmdExecMthdCtt;
	}
	public void setCmdExecMthdCtt(String cmdExecMthdCtt) {
		this.cmdExecMthdCtt = cmdExecMthdCtt;
	}
}
