package com.skb.mi.itms.model;

public class QiStbviewer {
	private	long	id;
	private	long	atime;
	private	String	stbId;
	private	String	srcIp;
	private	String	net;
	private	String	area1;
	private	String	area2;
	private	String	l3Id;
	private	String	l2Id;
	private	int		seq;
	private	long	measureTs;
	private	long	msgTs;
	private	String	chanIpPort;
	private	long	chanVbr;
	private	long	chanAbr;
	private	long	chanBitrate;
	private	long	chanStartTs;
	private	long	chanJoinTs;
	private	long	jitter;
	private	long	mls;
	private	long	tsLoss;
	private	long	tsTot;
	private	long	epg;
	private	long	jfCnt;
	private	int		badJitter;
	private	int		badMls;
	private	int		badLoss;
	private	int		badJt;
	private	int		badEpg;
	private	int		badJf;
	private	int		badOverall;
	private	String	team;
	private	String	servnum;
	private	String	stbModel;
	private	String	stbVersion;
	private	String	l3Model;
	private	String	l2Model;
	private	String	tvServiceNum;
	private	String	tvSvcmgmtNum;
	private	String	inetServiceNum;
	private	String	inetSvcmgmtNum;
	private	String	l3Tid;
	private	String	l2Tid;
	private	String	colSvr;
	private	long	pHour;
	private	long	p5min;
	private	long	pDate;
	private	long	packetRecvTs;

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getAtime() {
		return atime;
	}
	public void setAtime(long atime) {
		this.atime = atime;
	}
	public String getStbId() {
		return stbId;
	}
	public void setStbId(String stbId) {
		this.stbId = stbId;
	}
	public String getSrcIp() {
		return srcIp;
	}
	public void setSrcIp(String srcIp) {
		this.srcIp = srcIp;
	}
	public String getNet() {
		return net;
	}
	public void setNet(String net) {
		this.net = net;
	}
	public String getArea1() {
		return area1;
	}
	public void setArea1(String area1) {
		this.area1 = area1;
	}
	public String getArea2() {
		return area2;
	}
	public void setArea2(String area2) {
		this.area2 = area2;
	}
	public String getL3Id() {
		return l3Id;
	}
	public void setL3Id(String l3Id) {
		this.l3Id = l3Id;
	}
	public String getL2Id() {
		return l2Id;
	}
	public void setL2Id(String l2Id) {
		this.l2Id = l2Id;
	}
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public long getMeasureTs() {
		return measureTs;
	}
	public void setMeasureTs(long measureTs) {
		this.measureTs = measureTs;
	}
	public long getMsgTs() {
		return msgTs;
	}
	public void setMsgTs(long msgTs) {
		this.msgTs = msgTs;
	}
	public String getChanIpPort() {
		return chanIpPort;
	}
	public void setChanIpPort(String chanIpPort) {
		this.chanIpPort = chanIpPort;
	}
	public long getChanVbr() {
		return chanVbr;
	}
	public void setChanVbr(long chanVbr) {
		this.chanVbr = chanVbr;
	}
	public long getChanAbr() {
		return chanAbr;
	}
	public void setChanAbr(long chanAbr) {
		this.chanAbr = chanAbr;
	}
	public long getChanBitrate() {
		return chanBitrate;
	}
	public void setChanBitrate(long chanBitrate) {
		this.chanBitrate = chanBitrate;
	}
	public long getChanStartTs() {
		return chanStartTs;
	}
	public void setChanStartTs(long chanStartTs) {
		this.chanStartTs = chanStartTs;
	}
	public long getChanJoinTs() {
		return chanJoinTs;
	}
	public void setChanJoinTs(long chanJoinTs) {
		this.chanJoinTs = chanJoinTs;
	}
	public long getJitter() {
		return jitter;
	}
	public void setJitter(long jitter) {
		this.jitter = jitter;
	}
	public long getMls() {
		return mls;
	}
	public void setMls(long mls) {
		this.mls = mls;
	}
	public long getTsLoss() {
		return tsLoss;
	}
	public void setTsLoss(long tsLoss) {
		this.tsLoss = tsLoss;
	}
	public long getTsTot() {
		return tsTot;
	}
	public void setTsTot(long tsTot) {
		this.tsTot = tsTot;
	}
	public long getEpg() {
		return epg;
	}
	public void setEpg(long epg) {
		this.epg = epg;
	}
	public long getJfCnt() {
		return jfCnt;
	}
	public void setJfCnt(long jfCnt) {
		this.jfCnt = jfCnt;
	}
	public int getBadJitter() {
		return badJitter;
	}
	public void setBadJitter(int badJitter) {
		this.badJitter = badJitter;
	}
	public int getBadMls() {
		return badMls;
	}
	public void setBadMls(int badMls) {
		this.badMls = badMls;
	}
	public int getBadLoss() {
		return badLoss;
	}
	public void setBadLoss(int badLoss) {
		this.badLoss = badLoss;
	}
	public int getBadJt() {
		return badJt;
	}
	public void setBadJt(int badJt) {
		this.badJt = badJt;
	}
	public int getBadEpg() {
		return badEpg;
	}
	public void setBadEpg(int badEpg) {
		this.badEpg = badEpg;
	}
	public int getBadJf() {
		return badJf;
	}
	public void setBadJf(int badJf) {
		this.badJf = badJf;
	}
	public int getBadOverall() {
		return badOverall;
	}
	public void setBadOverall(int badOverall) {
		this.badOverall = badOverall;
	}
	public String getTeam() {
		return team;
	}
	public void setTeam(String team) {
		this.team = team;
	}
	public String getServnum() {
		return servnum;
	}
	public void setServnum(String servnum) {
		this.servnum = servnum;
	}
	public String getStbModel() {
		return stbModel;
	}
	public void setStbModel(String stbModel) {
		this.stbModel = stbModel;
	}
	public String getStbVersion() {
		return stbVersion;
	}
	public void setStbVersion(String stbVersion) {
		this.stbVersion = stbVersion;
	}
	public String getL3Model() {
		return l3Model;
	}
	public void setL3Model(String l3Model) {
		this.l3Model = l3Model;
	}
	public String getL2Model() {
		return l2Model;
	}
	public void setL2Model(String l2Model) {
		this.l2Model = l2Model;
	}
	public String getTvServiceNum() {
		return tvServiceNum;
	}
	public void setTvServiceNum(String tvServiceNum) {
		this.tvServiceNum = tvServiceNum;
	}
	public String getTvSvcmgmtNum() {
		return tvSvcmgmtNum;
	}
	public void setTvSvcmgmtNum(String tvSvcmgmtNum) {
		this.tvSvcmgmtNum = tvSvcmgmtNum;
	}
	public String getInetServiceNum() {
		return inetServiceNum;
	}
	public void setInetServiceNum(String inetServiceNum) {
		this.inetServiceNum = inetServiceNum;
	}
	public String getInetSvcmgmtNum() {
		return inetSvcmgmtNum;
	}
	public void setInetSvcmgmtNum(String inetSvcmgmtNum) {
		this.inetSvcmgmtNum = inetSvcmgmtNum;
	}
	public String getL3Tid() {
		return l3Tid;
	}
	public void setL3Tid(String l3Tid) {
		this.l3Tid = l3Tid;
	}
	public String getL2Tid() {
		return l2Tid;
	}
	public void setL2Tid(String l2Tid) {
		this.l2Tid = l2Tid;
	}
	public String getColSvr() {
		return colSvr;
	}
	public void setColSvr(String colSvr) {
		this.colSvr = colSvr;
	}
	public long getpHour() {
		return pHour;
	}
	public void setpHour(long pHour) {
		this.pHour = pHour;
	}
	public long getP5min() {
		return p5min;
	}
	public void setP5min(long p5min) {
		this.p5min = p5min;
	}
	public long getpDate() {
		return pDate;
	}
	public void setpDate(long pDate) {
		this.pDate = pDate;
	}
	public long getPacketRecvTs() {
		return packetRecvTs;
	}
	public void setPacketRecvTs(long packetRecvTs) {
		this.packetRecvTs = packetRecvTs;
	}
}
