package com.skb.mi.itms.model;

public class BQA30210 {
	private	String	mntrDthm;
	private	String	netClCd;
	private	String	infoCntrCd;
	private	String	tpoCd;
	private	String	orgEquipHrchyCd;
	private	String	l3EquipId;
	private	String	l2EquipId;
	private	String	ccellNum;
	private	String	auditId;
	private	String	auditDtm;
	private	String	mktDivOrgId;
	private	String	teamOrgId;
	private	String	tpoNm;
	private	String	l3EquipTidVal;
	private	String	l2EquipTidVal;
	private	int		dablCnt;
	private	String	mainBadIdxNm;
	private	double	mainBadRt;
	private	String	stbQltyGrCd;
	private	int		goodgCnt;
	private	int		warngCnt;
	private	int		crtgCnt;
	private	String	jitrStbQltyGrCd;
	private	double	jitrBadRt;
	private	int		jitrGoodgCnt;
	private	int		jitrWarngCnt;
	private	int		jitrCrtgCnt;
	private	String	joinTmsStbQltyGrCd;
	private	double	joinTmsBadRt;
	private	int		joinTmsGoodgCnt;
	private	int		joinTmsWarngCnt;
	private	int		joinTmsCrtgCnt;
	private	String	joinFailStbQltyGrCd;
	private	double	joinFailBadRt;
	private	int		joinFailGoodgCnt;
	private	int		joinFailWarngCnt;
	private	int		joinFailCrtgCnt;
	private	String	mlsStbQltyGrCd;
	private	double	mlsBadRt;
	private	int		mlsGoodgCnt;
	private	int		mlsWarngCnt;
	private	int		mlsCrtgCnt;
	private	String	epgStbQltyGrCd;
	private	double	epgBadRt;
	private	int		epgGoodgCnt;
	private	int		epgWarngCnt;
	private	int		epgCrtgCnt;
	private	String	lossStbQltyGrCd;
	private	double	lossBadRt;
	private	int		lossGoodgCnt;
	private	int		lossWarngCnt;
	private	int		lossCrtgCnt;
	private	String	frmeStbQltyGrCd;
	private	double	frmeBadRt;
	private	int		frmeGoodgCnt;
	private	int		frmeWarngCnt;
	private	int		frmeCrtgCnt;
	private	String	zbTmsStbQltyGrCd;
	private	double	zbTmsBadRt;
	private	int		zbTmsGoodgCnt;
	private	int		zbTmsWarngCnt;
	private	int		zbTmsCrtgCnt;
	private	String	jitrErrTmsStbQltyGrCd;
	private	double	jitrErrTmsBadRt;
	private	int		jitrErrTmsGoodgCnt;
	private	int		jitrErrTmsWarngCnt;
	private	int		jitrErrTmsCrtgCnt;
	private	String	mlsMaxStbQltyGrCd;
	private	double	mlsMaxBadRt;
	private	int		mlsMaxGoodgCnt;
	private	int		mlsMaxWarngCnt;
	private	int		mlsMaxCrtgCnt;
	private	String	frmeLossStbQltyGrCd;
	private	double	frmeLossBadRt;
	private	int		frmeLossGoodgCnt;
	private	int		frmeLossWarngCnt;
	private	int		frmeLossCrtgCnt;
	private	String	reJoinCntStbQltyGrCd;
	private	double	reJoinCntBadRt;
	private	int		reJoinCntGoodgCnt;
	private	int		reJoinCntWarngCnt;
	private	int		reJoinCntCrtgCnt;
	private	double	lossRtBadRt;
	private	int		lossRtGoodgCnt;
	private	int		lossRtWarngCnt;
	private	int		lossRtCrtgCnt;
	private	int		jitrTotVal;
	private	int		joinTmsTotVal;
	private	int		joinFailTotCnt;
	private	int		mlsTotVal;
	private	int		epgBpsTotVal;
	private	int		lossTotVal;
	private	int		tsTotTotCnt;
	private	int		zbTmsTotVal;
	private	int		reJoinCntTotCnt;
	private	int		dcOccrCnt;
	private	int		tdayOccrAccumCnt;
	private	String	dablRlseYn;
	private	String	dablRlseRsnCtt;
	
	// additional
	private	String	equipMgmtNum;

	public String getMntrDthm() {
		return mntrDthm;
	}
	public void setMntrDthm(String mntrDthm) {
		this.mntrDthm = mntrDthm;
	}
	public String getNetClCd() {
		return netClCd;
	}
	public void setNetClCd(String netClCd) {
		this.netClCd = netClCd;
	}
	public String getInfoCntrCd() {
		return infoCntrCd;
	}
	public void setInfoCntrCd(String infoCntrCd) {
		this.infoCntrCd = infoCntrCd;
	}
	public String getTpoCd() {
		return tpoCd;
	}
	public void setTpoCd(String tpoCd) {
		this.tpoCd = tpoCd;
	}
	public String getOrgEquipHrchyCd() {
		return orgEquipHrchyCd;
	}
	public void setOrgEquipHrchyCd(String orgEquipHrchyCd) {
		this.orgEquipHrchyCd = orgEquipHrchyCd;
	}
	public String getL3EquipId() {
		return l3EquipId;
	}
	public void setL3EquipId(String l3EquipId) {
		this.l3EquipId = l3EquipId;
	}
	public String getL2EquipId() {
		return l2EquipId;
	}
	public void setL2EquipId(String l2EquipId) {
		this.l2EquipId = l2EquipId;
	}
	public String getCcellNum() {
		return ccellNum;
	}
	public void setCcellNum(String ccellNum) {
		this.ccellNum = ccellNum;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getMktDivOrgId() {
		return mktDivOrgId;
	}
	public void setMktDivOrgId(String mktDivOrgId) {
		this.mktDivOrgId = mktDivOrgId;
	}
	public String getTeamOrgId() {
		return teamOrgId;
	}
	public void setTeamOrgId(String teamOrgId) {
		this.teamOrgId = teamOrgId;
	}
	public String getTpoNm() {
		return tpoNm;
	}
	public void setTpoNm(String tpoNm) {
		this.tpoNm = tpoNm;
	}
	public String getL3EquipTidVal() {
		return l3EquipTidVal;
	}
	public void setL3EquipTidVal(String l3EquipTidVal) {
		this.l3EquipTidVal = l3EquipTidVal;
	}
	public String getL2EquipTidVal() {
		return l2EquipTidVal;
	}
	public void setL2EquipTidVal(String l2EquipTidVal) {
		this.l2EquipTidVal = l2EquipTidVal;
	}
	public int getDablCnt() {
		return dablCnt;
	}
	public void setDablCnt(int dablCnt) {
		this.dablCnt = dablCnt;
	}
	public String getMainBadIdxNm() {
		return mainBadIdxNm;
	}
	public void setMainBadIdxNm(String mainBadIdxNm) {
		this.mainBadIdxNm = mainBadIdxNm;
	}
	public double getMainBadRt() {
		return mainBadRt;
	}
	public void setMainBadRt(double mainBadRt) {
		this.mainBadRt = mainBadRt;
	}
	public String getStbQltyGrCd() {
		return stbQltyGrCd;
	}
	public void setStbQltyGrCd(String stbQltyGrCd) {
		this.stbQltyGrCd = stbQltyGrCd;
	}
	public int getGoodgCnt() {
		return goodgCnt;
	}
	public void setGoodgCnt(int goodgCnt) {
		this.goodgCnt = goodgCnt;
	}
	public int getWarngCnt() {
		return warngCnt;
	}
	public void setWarngCnt(int warngCnt) {
		this.warngCnt = warngCnt;
	}
	public int getCrtgCnt() {
		return crtgCnt;
	}
	public void setCrtgCnt(int crtgCnt) {
		this.crtgCnt = crtgCnt;
	}
	public String getJitrStbQltyGrCd() {
		return jitrStbQltyGrCd;
	}
	public void setJitrStbQltyGrCd(String jitrStbQltyGrCd) {
		this.jitrStbQltyGrCd = jitrStbQltyGrCd;
	}
	public double getJitrBadRt() {
		return jitrBadRt;
	}
	public void setJitrBadRt(double jitrBadRt) {
		this.jitrBadRt = jitrBadRt;
	}
	public int getJitrGoodgCnt() {
		return jitrGoodgCnt;
	}
	public void setJitrGoodgCnt(int jitrGoodgCnt) {
		this.jitrGoodgCnt = jitrGoodgCnt;
	}
	public int getJitrWarngCnt() {
		return jitrWarngCnt;
	}
	public void setJitrWarngCnt(int jitrWarngCnt) {
		this.jitrWarngCnt = jitrWarngCnt;
	}
	public int getJitrCrtgCnt() {
		return jitrCrtgCnt;
	}
	public void setJitrCrtgCnt(int jitrCrtgCnt) {
		this.jitrCrtgCnt = jitrCrtgCnt;
	}
	public String getJoinTmsStbQltyGrCd() {
		return joinTmsStbQltyGrCd;
	}
	public void setJoinTmsStbQltyGrCd(String joinTmsStbQltyGrCd) {
		this.joinTmsStbQltyGrCd = joinTmsStbQltyGrCd;
	}
	public double getJoinTmsBadRt() {
		return joinTmsBadRt;
	}
	public void setJoinTmsBadRt(double joinTmsBadRt) {
		this.joinTmsBadRt = joinTmsBadRt;
	}
	public int getJoinTmsGoodgCnt() {
		return joinTmsGoodgCnt;
	}
	public void setJoinTmsGoodgCnt(int joinTmsGoodgCnt) {
		this.joinTmsGoodgCnt = joinTmsGoodgCnt;
	}
	public int getJoinTmsWarngCnt() {
		return joinTmsWarngCnt;
	}
	public void setJoinTmsWarngCnt(int joinTmsWarngCnt) {
		this.joinTmsWarngCnt = joinTmsWarngCnt;
	}
	public int getJoinTmsCrtgCnt() {
		return joinTmsCrtgCnt;
	}
	public void setJoinTmsCrtgCnt(int joinTmsCrtgCnt) {
		this.joinTmsCrtgCnt = joinTmsCrtgCnt;
	}
	public String getJoinFailStbQltyGrCd() {
		return joinFailStbQltyGrCd;
	}
	public void setJoinFailStbQltyGrCd(String joinFailStbQltyGrCd) {
		this.joinFailStbQltyGrCd = joinFailStbQltyGrCd;
	}
	public double getJoinFailBadRt() {
		return joinFailBadRt;
	}
	public void setJoinFailBadRt(double joinFailBadRt) {
		this.joinFailBadRt = joinFailBadRt;
	}
	public int getJoinFailGoodgCnt() {
		return joinFailGoodgCnt;
	}
	public void setJoinFailGoodgCnt(int joinFailGoodgCnt) {
		this.joinFailGoodgCnt = joinFailGoodgCnt;
	}
	public int getJoinFailWarngCnt() {
		return joinFailWarngCnt;
	}
	public void setJoinFailWarngCnt(int joinFailWarngCnt) {
		this.joinFailWarngCnt = joinFailWarngCnt;
	}
	public int getJoinFailCrtgCnt() {
		return joinFailCrtgCnt;
	}
	public void setJoinFailCrtgCnt(int joinFailCrtgCnt) {
		this.joinFailCrtgCnt = joinFailCrtgCnt;
	}
	public String getMlsStbQltyGrCd() {
		return mlsStbQltyGrCd;
	}
	public void setMlsStbQltyGrCd(String mlsStbQltyGrCd) {
		this.mlsStbQltyGrCd = mlsStbQltyGrCd;
	}
	public double getMlsBadRt() {
		return mlsBadRt;
	}
	public void setMlsBadRt(double mlsBadRt) {
		this.mlsBadRt = mlsBadRt;
	}
	public int getMlsGoodgCnt() {
		return mlsGoodgCnt;
	}
	public void setMlsGoodgCnt(int mlsGoodgCnt) {
		this.mlsGoodgCnt = mlsGoodgCnt;
	}
	public int getMlsWarngCnt() {
		return mlsWarngCnt;
	}
	public void setMlsWarngCnt(int mlsWarngCnt) {
		this.mlsWarngCnt = mlsWarngCnt;
	}
	public int getMlsCrtgCnt() {
		return mlsCrtgCnt;
	}
	public void setMlsCrtgCnt(int mlsCrtgCnt) {
		this.mlsCrtgCnt = mlsCrtgCnt;
	}
	public String getEpgStbQltyGrCd() {
		return epgStbQltyGrCd;
	}
	public void setEpgStbQltyGrCd(String epgStbQltyGrCd) {
		this.epgStbQltyGrCd = epgStbQltyGrCd;
	}
	public double getEpgBadRt() {
		return epgBadRt;
	}
	public void setEpgBadRt(double epgBadRt) {
		this.epgBadRt = epgBadRt;
	}
	public int getEpgGoodgCnt() {
		return epgGoodgCnt;
	}
	public void setEpgGoodgCnt(int epgGoodgCnt) {
		this.epgGoodgCnt = epgGoodgCnt;
	}
	public int getEpgWarngCnt() {
		return epgWarngCnt;
	}
	public void setEpgWarngCnt(int epgWarngCnt) {
		this.epgWarngCnt = epgWarngCnt;
	}
	public int getEpgCrtgCnt() {
		return epgCrtgCnt;
	}
	public void setEpgCrtgCnt(int epgCrtgCnt) {
		this.epgCrtgCnt = epgCrtgCnt;
	}
	public String getLossStbQltyGrCd() {
		return lossStbQltyGrCd;
	}
	public void setLossStbQltyGrCd(String lossStbQltyGrCd) {
		this.lossStbQltyGrCd = lossStbQltyGrCd;
	}
	public double getLossBadRt() {
		return lossBadRt;
	}
	public void setLossBadRt(double lossBadRt) {
		this.lossBadRt = lossBadRt;
	}
	public int getLossGoodgCnt() {
		return lossGoodgCnt;
	}
	public void setLossGoodgCnt(int lossGoodgCnt) {
		this.lossGoodgCnt = lossGoodgCnt;
	}
	public int getLossWarngCnt() {
		return lossWarngCnt;
	}
	public void setLossWarngCnt(int lossWarngCnt) {
		this.lossWarngCnt = lossWarngCnt;
	}
	public int getLossCrtgCnt() {
		return lossCrtgCnt;
	}
	public void setLossCrtgCnt(int lossCrtgCnt) {
		this.lossCrtgCnt = lossCrtgCnt;
	}
	public String getFrmeStbQltyGrCd() {
		return frmeStbQltyGrCd;
	}
	public void setFrmeStbQltyGrCd(String frmeStbQltyGrCd) {
		this.frmeStbQltyGrCd = frmeStbQltyGrCd;
	}
	public double getFrmeBadRt() {
		return frmeBadRt;
	}
	public void setFrmeBadRt(double frmeBadRt) {
		this.frmeBadRt = frmeBadRt;
	}
	public int getFrmeGoodgCnt() {
		return frmeGoodgCnt;
	}
	public void setFrmeGoodgCnt(int frmeGoodgCnt) {
		this.frmeGoodgCnt = frmeGoodgCnt;
	}
	public int getFrmeWarngCnt() {
		return frmeWarngCnt;
	}
	public void setFrmeWarngCnt(int frmeWarngCnt) {
		this.frmeWarngCnt = frmeWarngCnt;
	}
	public int getFrmeCrtgCnt() {
		return frmeCrtgCnt;
	}
	public void setFrmeCrtgCnt(int frmeCrtgCnt) {
		this.frmeCrtgCnt = frmeCrtgCnt;
	}
	public String getZbTmsStbQltyGrCd() {
		return zbTmsStbQltyGrCd;
	}
	public void setZbTmsStbQltyGrCd(String zbTmsStbQltyGrCd) {
		this.zbTmsStbQltyGrCd = zbTmsStbQltyGrCd;
	}
	public double getZbTmsBadRt() {
		return zbTmsBadRt;
	}
	public void setZbTmsBadRt(double zbTmsBadRt) {
		this.zbTmsBadRt = zbTmsBadRt;
	}
	public int getZbTmsGoodgCnt() {
		return zbTmsGoodgCnt;
	}
	public void setZbTmsGoodgCnt(int zbTmsGoodgCnt) {
		this.zbTmsGoodgCnt = zbTmsGoodgCnt;
	}
	public int getZbTmsWarngCnt() {
		return zbTmsWarngCnt;
	}
	public void setZbTmsWarngCnt(int zbTmsWarngCnt) {
		this.zbTmsWarngCnt = zbTmsWarngCnt;
	}
	public int getZbTmsCrtgCnt() {
		return zbTmsCrtgCnt;
	}
	public void setZbTmsCrtgCnt(int zbTmsCrtgCnt) {
		this.zbTmsCrtgCnt = zbTmsCrtgCnt;
	}
	public String getJitrErrTmsStbQltyGrCd() {
		return jitrErrTmsStbQltyGrCd;
	}
	public void setJitrErrTmsStbQltyGrCd(String jitrErrTmsStbQltyGrCd) {
		this.jitrErrTmsStbQltyGrCd = jitrErrTmsStbQltyGrCd;
	}
	public double getJitrErrTmsBadRt() {
		return jitrErrTmsBadRt;
	}
	public void setJitrErrTmsBadRt(double jitrErrTmsBadRt) {
		this.jitrErrTmsBadRt = jitrErrTmsBadRt;
	}
	public int getJitrErrTmsGoodgCnt() {
		return jitrErrTmsGoodgCnt;
	}
	public void setJitrErrTmsGoodgCnt(int jitrErrTmsGoodgCnt) {
		this.jitrErrTmsGoodgCnt = jitrErrTmsGoodgCnt;
	}
	public int getJitrErrTmsWarngCnt() {
		return jitrErrTmsWarngCnt;
	}
	public void setJitrErrTmsWarngCnt(int jitrErrTmsWarngCnt) {
		this.jitrErrTmsWarngCnt = jitrErrTmsWarngCnt;
	}
	public int getJitrErrTmsCrtgCnt() {
		return jitrErrTmsCrtgCnt;
	}
	public void setJitrErrTmsCrtgCnt(int jitrErrTmsCrtgCnt) {
		this.jitrErrTmsCrtgCnt = jitrErrTmsCrtgCnt;
	}
	public String getMlsMaxStbQltyGrCd() {
		return mlsMaxStbQltyGrCd;
	}
	public void setMlsMaxStbQltyGrCd(String mlsMaxStbQltyGrCd) {
		this.mlsMaxStbQltyGrCd = mlsMaxStbQltyGrCd;
	}
	public double getMlsMaxBadRt() {
		return mlsMaxBadRt;
	}
	public void setMlsMaxBadRt(double mlsMaxBadRt) {
		this.mlsMaxBadRt = mlsMaxBadRt;
	}
	public int getMlsMaxGoodgCnt() {
		return mlsMaxGoodgCnt;
	}
	public void setMlsMaxGoodgCnt(int mlsMaxGoodgCnt) {
		this.mlsMaxGoodgCnt = mlsMaxGoodgCnt;
	}
	public int getMlsMaxWarngCnt() {
		return mlsMaxWarngCnt;
	}
	public void setMlsMaxWarngCnt(int mlsMaxWarngCnt) {
		this.mlsMaxWarngCnt = mlsMaxWarngCnt;
	}
	public int getMlsMaxCrtgCnt() {
		return mlsMaxCrtgCnt;
	}
	public void setMlsMaxCrtgCnt(int mlsMaxCrtgCnt) {
		this.mlsMaxCrtgCnt = mlsMaxCrtgCnt;
	}
	public String getFrmeLossStbQltyGrCd() {
		return frmeLossStbQltyGrCd;
	}
	public void setFrmeLossStbQltyGrCd(String frmeLossStbQltyGrCd) {
		this.frmeLossStbQltyGrCd = frmeLossStbQltyGrCd;
	}
	public double getFrmeLossBadRt() {
		return frmeLossBadRt;
	}
	public void setFrmeLossBadRt(double frmeLossBadRt) {
		this.frmeLossBadRt = frmeLossBadRt;
	}
	public int getFrmeLossGoodgCnt() {
		return frmeLossGoodgCnt;
	}
	public void setFrmeLossGoodgCnt(int frmeLossGoodgCnt) {
		this.frmeLossGoodgCnt = frmeLossGoodgCnt;
	}
	public int getFrmeLossWarngCnt() {
		return frmeLossWarngCnt;
	}
	public void setFrmeLossWarngCnt(int frmeLossWarngCnt) {
		this.frmeLossWarngCnt = frmeLossWarngCnt;
	}
	public int getFrmeLossCrtgCnt() {
		return frmeLossCrtgCnt;
	}
	public void setFrmeLossCrtgCnt(int frmeLossCrtgCnt) {
		this.frmeLossCrtgCnt = frmeLossCrtgCnt;
	}
	public String getReJoinCntStbQltyGrCd() {
		return reJoinCntStbQltyGrCd;
	}
	public void setReJoinCntStbQltyGrCd(String reJoinCntStbQltyGrCd) {
		this.reJoinCntStbQltyGrCd = reJoinCntStbQltyGrCd;
	}
	public double getReJoinCntBadRt() {
		return reJoinCntBadRt;
	}
	public void setReJoinCntBadRt(double reJoinCntBadRt) {
		this.reJoinCntBadRt = reJoinCntBadRt;
	}
	public int getReJoinCntGoodgCnt() {
		return reJoinCntGoodgCnt;
	}
	public void setReJoinCntGoodgCnt(int reJoinCntGoodgCnt) {
		this.reJoinCntGoodgCnt = reJoinCntGoodgCnt;
	}
	public int getReJoinCntWarngCnt() {
		return reJoinCntWarngCnt;
	}
	public void setReJoinCntWarngCnt(int reJoinCntWarngCnt) {
		this.reJoinCntWarngCnt = reJoinCntWarngCnt;
	}
	public int getReJoinCntCrtgCnt() {
		return reJoinCntCrtgCnt;
	}
	public void setReJoinCntCrtgCnt(int reJoinCntCrtgCnt) {
		this.reJoinCntCrtgCnt = reJoinCntCrtgCnt;
	}
	public double getLossRtBadRt() {
		return lossRtBadRt;
	}
	public void setLossRtBadRt(double lossRtBadRt) {
		this.lossRtBadRt = lossRtBadRt;
	}
	public int getLossRtGoodgCnt() {
		return lossRtGoodgCnt;
	}
	public void setLossRtGoodgCnt(int lossRtGoodgCnt) {
		this.lossRtGoodgCnt = lossRtGoodgCnt;
	}
	public int getLossRtWarngCnt() {
		return lossRtWarngCnt;
	}
	public void setLossRtWarngCnt(int lossRtWarngCnt) {
		this.lossRtWarngCnt = lossRtWarngCnt;
	}
	public int getLossRtCrtgCnt() {
		return lossRtCrtgCnt;
	}
	public void setLossRtCrtgCnt(int lossRtCrtgCnt) {
		this.lossRtCrtgCnt = lossRtCrtgCnt;
	}
	public int getJitrTotVal() {
		return jitrTotVal;
	}
	public void setJitrTotVal(int jitrTotVal) {
		this.jitrTotVal = jitrTotVal;
	}
	public int getJoinTmsTotVal() {
		return joinTmsTotVal;
	}
	public void setJoinTmsTotVal(int joinTmsTotVal) {
		this.joinTmsTotVal = joinTmsTotVal;
	}
	public int getJoinFailTotCnt() {
		return joinFailTotCnt;
	}
	public void setJoinFailTotCnt(int joinFailTotCnt) {
		this.joinFailTotCnt = joinFailTotCnt;
	}
	public int getMlsTotVal() {
		return mlsTotVal;
	}
	public void setMlsTotVal(int mlsTotVal) {
		this.mlsTotVal = mlsTotVal;
	}
	public int getEpgBpsTotVal() {
		return epgBpsTotVal;
	}
	public void setEpgBpsTotVal(int epgBpsTotVal) {
		this.epgBpsTotVal = epgBpsTotVal;
	}
	public int getLossTotVal() {
		return lossTotVal;
	}
	public void setLossTotVal(int lossTotVal) {
		this.lossTotVal = lossTotVal;
	}
	public int getTsTotTotCnt() {
		return tsTotTotCnt;
	}
	public void setTsTotTotCnt(int tsTotTotCnt) {
		this.tsTotTotCnt = tsTotTotCnt;
	}
	public int getZbTmsTotVal() {
		return zbTmsTotVal;
	}
	public void setZbTmsTotVal(int zbTmsTotVal) {
		this.zbTmsTotVal = zbTmsTotVal;
	}
	public int getReJoinCntTotCnt() {
		return reJoinCntTotCnt;
	}
	public void setReJoinCntTotCnt(int reJoinCntTotCnt) {
		this.reJoinCntTotCnt = reJoinCntTotCnt;
	}
	public int getDcOccrCnt() {
		return dcOccrCnt;
	}
	public void setDcOccrCnt(int dcOccrCnt) {
		this.dcOccrCnt = dcOccrCnt;
	}
	public int getTdayOccrAccumCnt() {
		return tdayOccrAccumCnt;
	}
	public void setTdayOccrAccumCnt(int tdayOccrAccumCnt) {
		this.tdayOccrAccumCnt = tdayOccrAccumCnt;
	}
	public String getDablRlseYn() {
		return dablRlseYn;
	}
	public void setDablRlseYn(String dablRlseYn) {
		this.dablRlseYn = dablRlseYn;
	}
	public String getDablRlseRsnCtt() {
		return dablRlseRsnCtt;
	}
	public void setDablRlseRsnCtt(String dablRlseRsnCtt) {
		this.dablRlseRsnCtt = dablRlseRsnCtt;
	}
	public String getEquipMgmtNum() {
		return equipMgmtNum;
	}
	public void setEquipMgmtNum(String equipMgmtNum) {
		this.equipMgmtNum = equipMgmtNum;
	}
}
