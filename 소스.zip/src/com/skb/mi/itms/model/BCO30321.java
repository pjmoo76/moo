package com.skb.mi.itms.model;

public class BCO30321 {
	private	String	dbNm;
	private	String	sumOperId;
	private	int		operSeq;
	private	String	operSqlId;

	public String getDbNm() {
		return dbNm;
	}
	public void setDbNm(String dbNm) {
		this.dbNm = dbNm;
	}
	public String getSumOperId() {
		return sumOperId;
	}
	public void setSumOperId(String sumOperId) {
		this.sumOperId = sumOperId;
	}
	public int getOperSeq() {
		return operSeq;
	}
	public void setOperSeq(int operSeq) {
		this.operSeq = operSeq;
	}
	public String getOperSqlId() {
		return operSqlId;
	}
	public void setOperSqlId(String operSqlId) {
		this.operSqlId = operSqlId;
	}
}
