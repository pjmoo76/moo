package com.skb.mi.itms.model;

public class BCO30401 {
	private	String	rptReqDtm;
	private	String	itmRptTypCd;
	private	String	reqrId;
	private	String	auditId;
	private	String	auditDtm;
	private	String	strdDtm;
	private	String	teamOrgId;
	private	String	infoCntrCd;
	private	String	rptParamVal;
	private	String	itmOperStCd;
	private	String	fileNm;
	private	String	rptCreUrl;
	private	long	fileSize;
	private	String	staDtm;
	private	String	endDtm;

	public String getRptReqDtm() {
		return rptReqDtm;
	}
	public void setRptReqDtm(String rptReqDtm) {
		this.rptReqDtm = rptReqDtm;
	}
	public String getItmRptTypCd() {
		return itmRptTypCd;
	}
	public void setItmRptTypCd(String itmRptTypCd) {
		this.itmRptTypCd = itmRptTypCd;
	}
	public String getReqrId() {
		return reqrId;
	}
	public void setReqrId(String reqrId) {
		this.reqrId = reqrId;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getStrdDtm() {
		return strdDtm;
	}
	public void setStrdDtm(String strdDtm) {
		this.strdDtm = strdDtm;
	}
	public String getTeamOrgId() {
		return teamOrgId;
	}
	public void setTeamOrgId(String teamOrgId) {
		this.teamOrgId = teamOrgId;
	}
	public String getInfoCntrCd() {
		return infoCntrCd;
	}
	public void setInfoCntrCd(String infoCntrCd) {
		this.infoCntrCd = infoCntrCd;
	}
	public String getRptParamVal() {
		return rptParamVal;
	}
	public void setRptParamVal(String rptParamVal) {
		this.rptParamVal = rptParamVal;
	}
	public String getItmOperStCd() {
		return itmOperStCd;
	}
	public void setItmOperStCd(String itmOperStCd) {
		this.itmOperStCd = itmOperStCd;
	}
	public String getFileNm() {
		return fileNm;
	}
	public void setFileNm(String fileNm) {
		this.fileNm = fileNm;
	}
	public String getRptCreUrl() {
		return rptCreUrl;
	}
	public void setRptCreUrl(String rptCreUrl) {
		this.rptCreUrl = rptCreUrl;
	}
	public long getFileSize() {
		return fileSize;
	}
	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}
	public String getStaDtm() {
		return staDtm;
	}
	public void setStaDtm(String staDtm) {
		this.staDtm = staDtm;
	}
	public String getEndDtm() {
		return endDtm;
	}
	public void setEndDtm(String endDtm) {
		this.endDtm = endDtm;
	}
}
