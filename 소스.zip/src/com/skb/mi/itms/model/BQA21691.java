package com.skb.mi.itms.model;

public class BQA21691 {
	private	String	useDtm;
	private	long	integDgnsSerNum;
	private	String	resetOperStaDtm;
	private	String	resetAddrVal;
	private	String	auditId;
	private	String	auditDtm;
	private	String	resetObjTypCd;
	private	String	resetSussYn;
	private	String	dgnsReqId;
	private	String	resetOperEndDtm;
	private	long	inetSvcMgmtNum;
	private	long	iptvSvcMgmtNum;
	private	String	cmdExecMthdCtt;
	private	String	eqpMdlCd;
	private	String	eqpUptimeTmsInfo;
	private	String	rsltCdCtt;
	private	String	operFailCtt;

	public String getUseDtm() {
		return useDtm;
	}
	public void setUseDtm(String useDtm) {
		this.useDtm = useDtm;
	}
	public long getIntegDgnsSerNum() {
		return integDgnsSerNum;
	}
	public void setIntegDgnsSerNum(long integDgnsSerNum) {
		this.integDgnsSerNum = integDgnsSerNum;
	}
	public String getResetOperStaDtm() {
		return resetOperStaDtm;
	}
	public void setResetOperStaDtm(String resetOperStaDtm) {
		this.resetOperStaDtm = resetOperStaDtm;
	}
	public String getResetAddrVal() {
		return resetAddrVal;
	}
	public void setResetAddrVal(String resetAddrVal) {
		this.resetAddrVal = resetAddrVal;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public String getResetObjTypCd() {
		return resetObjTypCd;
	}
	public void setResetObjTypCd(String resetObjTypCd) {
		this.resetObjTypCd = resetObjTypCd;
	}
	public String getResetSussYn() {
		return resetSussYn;
	}
	public void setResetSussYn(String resetSussYn) {
		this.resetSussYn = resetSussYn;
	}
	public String getDgnsReqId() {
		return dgnsReqId;
	}
	public void setDgnsReqId(String dgnsReqId) {
		this.dgnsReqId = dgnsReqId;
	}
	public String getResetOperEndDtm() {
		return resetOperEndDtm;
	}
	public void setResetOperEndDtm(String resetOperEndDtm) {
		this.resetOperEndDtm = resetOperEndDtm;
	}
	public long getInetSvcMgmtNum() {
		return inetSvcMgmtNum;
	}
	public void setInetSvcMgmtNum(long inetSvcMgmtNum) {
		this.inetSvcMgmtNum = inetSvcMgmtNum;
	}
	public long getIptvSvcMgmtNum() {
		return iptvSvcMgmtNum;
	}
	public void setIptvSvcMgmtNum(long iptvSvcMgmtNum) {
		this.iptvSvcMgmtNum = iptvSvcMgmtNum;
	}
	public String getCmdExecMthdCtt() {
		return cmdExecMthdCtt;
	}
	public void setCmdExecMthdCtt(String cmdExecMthdCtt) {
		this.cmdExecMthdCtt = cmdExecMthdCtt;
	}
	public String getEqpMdlCd() {
		return eqpMdlCd;
	}
	public void setEqpMdlCd(String eqpMdlCd) {
		this.eqpMdlCd = eqpMdlCd;
	}
	public String getEqpUptimeTmsInfo() {
		return eqpUptimeTmsInfo;
	}
	public void setEqpUptimeTmsInfo(String eqpUptimeTmsInfo) {
		this.eqpUptimeTmsInfo = eqpUptimeTmsInfo;
	}
	public String getRsltCdCtt() {
		return rsltCdCtt;
	}
	public void setRsltCdCtt(String rsltCdCtt) {
		this.rsltCdCtt = rsltCdCtt;
	}
	public String getOperFailCtt() {
		return operFailCtt;
	}
	public void setOperFailCtt(String operFailCtt) {
		this.operFailCtt = operFailCtt;
	}
}
