package com.skb.mi.itms.model;

public class BIV20851 {
	private	int		autoResetExtrtSerNum;
	private	String	rgstrId;
	private	String	rgstDtm;
	private	int		cpuLdCnt;
	private	int		mmrExcsPossCnt;
	private	int		uptimeDayCnt;
	private	String	mlsExcsYn;
	private	int		qltyBadCnstDayCnt;
	private	int		lineCeiVal;
	private	String	operStaDtm;
	private	String	operFnshDtm;
	private	String	stbSvcOfrModeVal;
	private	int		stbSvcOfrModeDayCnt;
	private	String	schdCyclInfo;
	private	String	autoExtrtTmsVal;
	private	int		resetStrdUptimeDayCnt;
	private	String	useYn;
	private	String	lineCeiBadYn;

	public int getAutoResetExtrtSerNum() {
		return autoResetExtrtSerNum;
	}
	public void setAutoResetExtrtSerNum(int autoResetExtrtSerNum) {
		this.autoResetExtrtSerNum = autoResetExtrtSerNum;
	}
	public String getRgstrId() {
		return rgstrId;
	}
	public void setRgstrId(String rgstrId) {
		this.rgstrId = rgstrId;
	}
	public String getRgstDtm() {
		return rgstDtm;
	}
	public void setRgstDtm(String rgstDtm) {
		this.rgstDtm = rgstDtm;
	}
	public int getCpuLdCnt() {
		return cpuLdCnt;
	}
	public void setCpuLdCnt(int cpuLdCnt) {
		this.cpuLdCnt = cpuLdCnt;
	}
	public int getMmrExcsPossCnt() {
		return mmrExcsPossCnt;
	}
	public void setMmrExcsPossCnt(int mmrExcsPossCnt) {
		this.mmrExcsPossCnt = mmrExcsPossCnt;
	}
	public int getUptimeDayCnt() {
		return uptimeDayCnt;
	}
	public void setUptimeDayCnt(int uptimeDayCnt) {
		this.uptimeDayCnt = uptimeDayCnt;
	}
	public String getMlsExcsYn() {
		return mlsExcsYn;
	}
	public void setMlsExcsYn(String mlsExcsYn) {
		this.mlsExcsYn = mlsExcsYn;
	}
	public int getQltyBadCnstDayCnt() {
		return qltyBadCnstDayCnt;
	}
	public void setQltyBadCnstDayCnt(int qltyBadCnstDayCnt) {
		this.qltyBadCnstDayCnt = qltyBadCnstDayCnt;
	}
	public int getLineCeiVal() {
		return lineCeiVal;
	}
	public void setLineCeiVal(int lineCeiVal) {
		this.lineCeiVal = lineCeiVal;
	}
	public String getOperStaDtm() {
		return operStaDtm;
	}
	public void setOperStaDtm(String operStaDtm) {
		this.operStaDtm = operStaDtm;
	}
	public String getOperFnshDtm() {
		return operFnshDtm;
	}
	public void setOperFnshDtm(String operFnshDtm) {
		this.operFnshDtm = operFnshDtm;
	}
	public String getStbSvcOfrModeVal() {
		return stbSvcOfrModeVal;
	}
	public void setStbSvcOfrModeVal(String stbSvcOfrModeVal) {
		this.stbSvcOfrModeVal = stbSvcOfrModeVal;
	}
	public int getStbSvcOfrModeDayCnt() {
		return stbSvcOfrModeDayCnt;
	}
	public void setStbSvcOfrModeDayCnt(int stbSvcOfrModeDayCnt) {
		this.stbSvcOfrModeDayCnt = stbSvcOfrModeDayCnt;
	}
	public String getSchdCyclInfo() {
		return schdCyclInfo;
	}
	public void setSchdCyclInfo(String schdCyclInfo) {
		this.schdCyclInfo = schdCyclInfo;
	}
	public String getAutoExtrtTmsVal() {
		return autoExtrtTmsVal;
	}
	public void setAutoExtrtTmsVal(String autoExtrtTmsVal) {
		this.autoExtrtTmsVal = autoExtrtTmsVal;
	}
	public int getResetStrdUptimeDayCnt() {
		return resetStrdUptimeDayCnt;
	}
	public void setResetStrdUptimeDayCnt(int resetStrdUptimeDayCnt) {
		this.resetStrdUptimeDayCnt = resetStrdUptimeDayCnt;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	public String getLineCeiBadYn() {
		return lineCeiBadYn;
	}
	public void setLineCeiBadYn(String lineCeiBadYn) {
		this.lineCeiBadYn = lineCeiBadYn;
	}
}
