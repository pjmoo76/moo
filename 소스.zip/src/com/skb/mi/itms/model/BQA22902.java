package com.skb.mi.itms.model;

public class BQA22902 {
	private	String	mntrDthm;
	private	String	stbMacAddr;
	private	String	uuidVal;
	private	String	auditId;
	private	String	auditDtm;
	private	int		clctSvrNum;
	private	String	evtRcvDtm;
	private	String	srcIpAddr;
	private	String	weqpMgmtNum;
	private	String	stbEqpMdlCd;
	private	String	patchGrpCtt;
	private	String	eqpUptimeTmsInfo;
	private	String	stbQltyGrCd;
	private	String	infoCntrCd;
	private	String	tpoCd;
	private	String	hpyCntrOrgId;
	private	String	netClCd;
	private	String	l3EquipId;
	private	String	l3EquipTidVal;
	private	String	l3EquipMdlCd;
	private	String	l2EquipId;
	private	String	ccellNum;
	private	String	l2EquipTidVal;
	private	String	l2EquipMdlCd;
	private	long	iptvSvcMgmtNum;
	private	long	iptvSvcNum;
	private	String	stbEvtVerInfo;
	private	int		stbEvtSerNum;
	private	String	stbVerCtt;
	private	String	stbMdlNm;
	private	String	stbEvtTypCd;
	private	String	evtMsgDtm;
	private	String	chnlSvrIpAddr;
	private	String	chnlSvrPortNum;
	private	String	chnlStaDtm;
	private	long	chnlJoinTms;
	private	String	joinTmsStbQltyGrCd;
	private	long	chnlBpsVal;
	private	long	chnlBpsMaxVal;
	private	long	chnlBpsMinVal;
	private	double	pcktLossRt;
	private	long	msrtTms;
	private	long	jitrVal;
	private	String	jitrStbQltyGrCd;
	private	long	tsLossVal;
	private	String	tsLossStbQltyGrCd;
	private	long	mlsVal;
	private	String	mlsStbQltyGrCd;
	private	long	tsTotCnt;
	private	long	joinFailCnt;
	private	String	joinFailStbQltyGrCd;
	private	long	epgBpsVal;
	private	String	epgStbQltyGrCd;
	private	long	epgBpsMinVal;
	private	long	epgBpsMaxVal;
	private	double	tsMinRt;
	private	double	tsMaxRt;
	private	long	fpsVal;
	private	String	fpsStbQltyGrCd;
	private	long	fpsMaxVal;
	private	long	fpsMinVal;
	private	long	zbTmsMaxVal;
	private	long	zbTms;
	private	String	zbTmsStbQltyGrCd;
	private	long	jitrErrTms;
	private	String	jitrErrTmsStbQltyGrCd;
	private	long	mlsMaxTms;
	private	String	mlsMaxTmsStbQltyGrCd;
	private	String	frmeLossVal;
	private	String	frmeLossStbQltyGrCd;
	private	long	frmeLossTotVal;
	private	long	maxMlsPcrTms;
	private	long	reJoinCnt;
	private	String	reJoinCntStbQltyGrCd;
	private	long	outgProfVal;
	private	long	lossProfVal;
	private	long	chnlChgCnt;
	private	long	netAtckTms;
	private	String	mlrStaSyncCd;
	private	String	mlrVerCtt;
	private	String	mlrDtm;
	private	long	mlrChnlCnt;
	private	long	mlrTsMaxCnt;
	private	long	mlrTsMinCnt;
	private	long	mlrTsTotCnt;
	private	long	mlrMlsVal;
	private	long	mlrMlcVal;
	private	long	mlrJitrMaxVal;
	private	long	mlrJitrMinVal;
	private	long	mlrTms;
	private	long	mlrKeepMlsCnt;
	private	long	mlrRecvrySize;
	private	long	mlrReqSendSussCnt;
	private	long	mlrReqFailLmtOvrCnt;
	private	long	mlrReqFailEtcCnt;
	private	long	mlrRpsSussCnt;
	private	long	mlrRpsFailReqSizeOvrCnt;
	private	long	mlrRpsFailSec1SizeOvrCnt;
	private	long	mlrRpsFailNchngCnt;
	private	long	mlrRpsFailSvrEtcCnt;
	private	long	mlrRpsFailNyRcvCnt;
	private	long	mlrRpsFailEtcCnt;
	private	long	mlrRecvryTms;
	private	long	mlrOvrWriteSize;
	//
	private	long	inetSvcMgmtNum;
	private	long	inetSvcNum;
	private	String	l3EquipMdlNm;
	private	String	l2EquipMdlNm;
	private	String	teamOrgId;
	private	String	l3EquipMgmtNum;
	private	String	l2EquipMgmtNum;

	public String getMntrDthm() {
		return mntrDthm;
	}
	public void setMntrDthm(String mntrDthm) {
		this.mntrDthm = mntrDthm;
	}
	public String getStbMacAddr() {
		return stbMacAddr;
	}
	public void setStbMacAddr(String stbMacAddr) {
		this.stbMacAddr = stbMacAddr;
	}
	public String getUuidVal() {
		return uuidVal;
	}
	public void setUuidVal(String uuidVal) {
		this.uuidVal = uuidVal;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditDtm() {
		return auditDtm;
	}
	public void setAuditDtm(String auditDtm) {
		this.auditDtm = auditDtm;
	}
	public int getClctSvrNum() {
		return clctSvrNum;
	}
	public void setClctSvrNum(int clctSvrNum) {
		this.clctSvrNum = clctSvrNum;
	}
	public String getEvtRcvDtm() {
		return evtRcvDtm;
	}
	public void setEvtRcvDtm(String evtRcvDtm) {
		this.evtRcvDtm = evtRcvDtm;
	}
	public String getSrcIpAddr() {
		return srcIpAddr;
	}
	public void setSrcIpAddr(String srcIpAddr) {
		this.srcIpAddr = srcIpAddr;
	}
	public String getWeqpMgmtNum() {
		return weqpMgmtNum;
	}
	public void setWeqpMgmtNum(String weqpMgmtNum) {
		this.weqpMgmtNum = weqpMgmtNum;
	}
	public String getStbEqpMdlCd() {
		return stbEqpMdlCd;
	}
	public void setStbEqpMdlCd(String stbEqpMdlCd) {
		this.stbEqpMdlCd = stbEqpMdlCd;
	}
	public String getPatchGrpCtt() {
		return patchGrpCtt;
	}
	public void setPatchGrpCtt(String patchGrpCtt) {
		this.patchGrpCtt = patchGrpCtt;
	}
	public String getEqpUptimeTmsInfo() {
		return eqpUptimeTmsInfo;
	}
	public void setEqpUptimeTmsInfo(String eqpUptimeTmsInfo) {
		this.eqpUptimeTmsInfo = eqpUptimeTmsInfo;
	}
	public String getStbQltyGrCd() {
		return stbQltyGrCd;
	}
	public void setStbQltyGrCd(String stbQltyGrCd) {
		this.stbQltyGrCd = stbQltyGrCd;
	}
	public String getInfoCntrCd() {
		return infoCntrCd;
	}
	public void setInfoCntrCd(String infoCntrCd) {
		this.infoCntrCd = infoCntrCd;
	}
	public String getTpoCd() {
		return tpoCd;
	}
	public void setTpoCd(String tpoCd) {
		this.tpoCd = tpoCd;
	}
	public String getHpyCntrOrgId() {
		return hpyCntrOrgId;
	}
	public void setHpyCntrOrgId(String hpyCntrOrgId) {
		this.hpyCntrOrgId = hpyCntrOrgId;
	}
	public String getNetClCd() {
		return netClCd;
	}
	public void setNetClCd(String netClCd) {
		this.netClCd = netClCd;
	}
	public String getL3EquipId() {
		return l3EquipId;
	}
	public void setL3EquipId(String l3EquipId) {
		this.l3EquipId = l3EquipId;
	}
	public String getL3EquipTidVal() {
		return l3EquipTidVal;
	}
	public void setL3EquipTidVal(String l3EquipTidVal) {
		this.l3EquipTidVal = l3EquipTidVal;
	}
	public String getL3EquipMdlCd() {
		return l3EquipMdlCd;
	}
	public void setL3EquipMdlCd(String l3EquipMdlCd) {
		this.l3EquipMdlCd = l3EquipMdlCd;
	}
	public String getL2EquipId() {
		return l2EquipId;
	}
	public void setL2EquipId(String l2EquipId) {
		this.l2EquipId = l2EquipId;
	}
	public String getCcellNum() {
		return ccellNum;
	}
	public void setCcellNum(String ccellNum) {
		this.ccellNum = ccellNum;
	}
	public String getL2EquipTidVal() {
		return l2EquipTidVal;
	}
	public void setL2EquipTidVal(String l2EquipTidVal) {
		this.l2EquipTidVal = l2EquipTidVal;
	}
	public String getL2EquipMdlCd() {
		return l2EquipMdlCd;
	}
	public void setL2EquipMdlCd(String l2EquipMdlCd) {
		this.l2EquipMdlCd = l2EquipMdlCd;
	}
	public long getIptvSvcMgmtNum() {
		return iptvSvcMgmtNum;
	}
	public void setIptvSvcMgmtNum(long iptvSvcMgmtNum) {
		this.iptvSvcMgmtNum = iptvSvcMgmtNum;
	}
	public long getIptvSvcNum() {
		return iptvSvcNum;
	}
	public void setIptvSvcNum(long iptvSvcNum) {
		this.iptvSvcNum = iptvSvcNum;
	}
	public String getStbEvtVerInfo() {
		return stbEvtVerInfo;
	}
	public void setStbEvtVerInfo(String stbEvtVerInfo) {
		this.stbEvtVerInfo = stbEvtVerInfo;
	}
	public int getStbEvtSerNum() {
		return stbEvtSerNum;
	}
	public void setStbEvtSerNum(int stbEvtSerNum) {
		this.stbEvtSerNum = stbEvtSerNum;
	}
	public String getStbVerCtt() {
		return stbVerCtt;
	}
	public void setStbVerCtt(String stbVerCtt) {
		this.stbVerCtt = stbVerCtt;
	}
	public String getStbMdlNm() {
		return stbMdlNm;
	}
	public void setStbMdlNm(String stbMdlNm) {
		this.stbMdlNm = stbMdlNm;
	}
	public String getStbEvtTypCd() {
		return stbEvtTypCd;
	}
	public void setStbEvtTypCd(String stbEvtTypCd) {
		this.stbEvtTypCd = stbEvtTypCd;
	}
	public String getEvtMsgDtm() {
		return evtMsgDtm;
	}
	public void setEvtMsgDtm(String evtMsgDtm) {
		this.evtMsgDtm = evtMsgDtm;
	}
	public String getChnlSvrIpAddr() {
		return chnlSvrIpAddr;
	}
	public void setChnlSvrIpAddr(String chnlSvrIpAddr) {
		this.chnlSvrIpAddr = chnlSvrIpAddr;
	}
	public String getChnlSvrPortNum() {
		return chnlSvrPortNum;
	}
	public void setChnlSvrPortNum(String chnlSvrPortNum) {
		this.chnlSvrPortNum = chnlSvrPortNum;
	}
	public String getChnlStaDtm() {
		return chnlStaDtm;
	}
	public void setChnlStaDtm(String chnlStaDtm) {
		this.chnlStaDtm = chnlStaDtm;
	}
	public long getChnlJoinTms() {
		return chnlJoinTms;
	}
	public void setChnlJoinTms(long chnlJoinTms) {
		this.chnlJoinTms = chnlJoinTms;
	}
	public String getJoinTmsStbQltyGrCd() {
		return joinTmsStbQltyGrCd;
	}
	public void setJoinTmsStbQltyGrCd(String joinTmsStbQltyGrCd) {
		this.joinTmsStbQltyGrCd = joinTmsStbQltyGrCd;
	}
	public long getChnlBpsVal() {
		return chnlBpsVal;
	}
	public void setChnlBpsVal(long chnlBpsVal) {
		this.chnlBpsVal = chnlBpsVal;
	}
	public long getChnlBpsMaxVal() {
		return chnlBpsMaxVal;
	}
	public void setChnlBpsMaxVal(long chnlBpsMaxVal) {
		this.chnlBpsMaxVal = chnlBpsMaxVal;
	}
	public long getChnlBpsMinVal() {
		return chnlBpsMinVal;
	}
	public void setChnlBpsMinVal(long chnlBpsMinVal) {
		this.chnlBpsMinVal = chnlBpsMinVal;
	}
	public double getPcktLossRt() {
		return pcktLossRt;
	}
	public void setPcktLossRt(double pcktLossRt) {
		this.pcktLossRt = pcktLossRt;
	}
	public long getMsrtTms() {
		return msrtTms;
	}
	public void setMsrtTms(long msrtTms) {
		this.msrtTms = msrtTms;
	}
	public long getJitrVal() {
		return jitrVal;
	}
	public void setJitrVal(long jitrVal) {
		this.jitrVal = jitrVal;
	}
	public String getJitrStbQltyGrCd() {
		return jitrStbQltyGrCd;
	}
	public void setJitrStbQltyGrCd(String jitrStbQltyGrCd) {
		this.jitrStbQltyGrCd = jitrStbQltyGrCd;
	}
	public long getTsLossVal() {
		return tsLossVal;
	}
	public void setTsLossVal(long tsLossVal) {
		this.tsLossVal = tsLossVal;
	}
	public String getTsLossStbQltyGrCd() {
		return tsLossStbQltyGrCd;
	}
	public void setTsLossStbQltyGrCd(String tsLossStbQltyGrCd) {
		this.tsLossStbQltyGrCd = tsLossStbQltyGrCd;
	}
	public long getMlsVal() {
		return mlsVal;
	}
	public void setMlsVal(long mlsVal) {
		this.mlsVal = mlsVal;
	}
	public String getMlsStbQltyGrCd() {
		return mlsStbQltyGrCd;
	}
	public void setMlsStbQltyGrCd(String mlsStbQltyGrCd) {
		this.mlsStbQltyGrCd = mlsStbQltyGrCd;
	}
	public long getTsTotCnt() {
		return tsTotCnt;
	}
	public void setTsTotCnt(long tsTotCnt) {
		this.tsTotCnt = tsTotCnt;
	}
	public long getJoinFailCnt() {
		return joinFailCnt;
	}
	public void setJoinFailCnt(long joinFailCnt) {
		this.joinFailCnt = joinFailCnt;
	}
	public String getJoinFailStbQltyGrCd() {
		return joinFailStbQltyGrCd;
	}
	public void setJoinFailStbQltyGrCd(String joinFailStbQltyGrCd) {
		this.joinFailStbQltyGrCd = joinFailStbQltyGrCd;
	}
	public long getEpgBpsVal() {
		return epgBpsVal;
	}
	public void setEpgBpsVal(long epgBpsVal) {
		this.epgBpsVal = epgBpsVal;
	}
	public String getEpgStbQltyGrCd() {
		return epgStbQltyGrCd;
	}
	public void setEpgStbQltyGrCd(String epgStbQltyGrCd) {
		this.epgStbQltyGrCd = epgStbQltyGrCd;
	}
	public long getEpgBpsMinVal() {
		return epgBpsMinVal;
	}
	public void setEpgBpsMinVal(long epgBpsMinVal) {
		this.epgBpsMinVal = epgBpsMinVal;
	}
	public long getEpgBpsMaxVal() {
		return epgBpsMaxVal;
	}
	public void setEpgBpsMaxVal(long epgBpsMaxVal) {
		this.epgBpsMaxVal = epgBpsMaxVal;
	}
	public double getTsMinRt() {
		return tsMinRt;
	}
	public void setTsMinRt(double tsMinRt) {
		this.tsMinRt = tsMinRt;
	}
	public double getTsMaxRt() {
		return tsMaxRt;
	}
	public void setTsMaxRt(double tsMaxRt) {
		this.tsMaxRt = tsMaxRt;
	}
	public long getFpsVal() {
		return fpsVal;
	}
	public void setFpsVal(long fpsVal) {
		this.fpsVal = fpsVal;
	}
	public String getFpsStbQltyGrCd() {
		return fpsStbQltyGrCd;
	}
	public void setFpsStbQltyGrCd(String fpsStbQltyGrCd) {
		this.fpsStbQltyGrCd = fpsStbQltyGrCd;
	}
	public long getFpsMaxVal() {
		return fpsMaxVal;
	}
	public void setFpsMaxVal(long fpsMaxVal) {
		this.fpsMaxVal = fpsMaxVal;
	}
	public long getFpsMinVal() {
		return fpsMinVal;
	}
	public void setFpsMinVal(long fpsMinVal) {
		this.fpsMinVal = fpsMinVal;
	}
	public long getZbTmsMaxVal() {
		return zbTmsMaxVal;
	}
	public void setZbTmsMaxVal(long zbTmsMaxVal) {
		this.zbTmsMaxVal = zbTmsMaxVal;
	}
	public long getZbTms() {
		return zbTms;
	}
	public void setZbTms(long zbTms) {
		this.zbTms = zbTms;
	}
	public String getZbTmsStbQltyGrCd() {
		return zbTmsStbQltyGrCd;
	}
	public void setZbTmsStbQltyGrCd(String zbTmsStbQltyGrCd) {
		this.zbTmsStbQltyGrCd = zbTmsStbQltyGrCd;
	}
	public long getJitrErrTms() {
		return jitrErrTms;
	}
	public void setJitrErrTms(long jitrErrTms) {
		this.jitrErrTms = jitrErrTms;
	}
	public String getJitrErrTmsStbQltyGrCd() {
		return jitrErrTmsStbQltyGrCd;
	}
	public void setJitrErrTmsStbQltyGrCd(String jitrErrTmsStbQltyGrCd) {
		this.jitrErrTmsStbQltyGrCd = jitrErrTmsStbQltyGrCd;
	}
	public long getMlsMaxTms() {
		return mlsMaxTms;
	}
	public void setMlsMaxTms(long mlsMaxTms) {
		this.mlsMaxTms = mlsMaxTms;
	}
	public String getMlsMaxTmsStbQltyGrCd() {
		return mlsMaxTmsStbQltyGrCd;
	}
	public void setMlsMaxTmsStbQltyGrCd(String mlsMaxTmsStbQltyGrCd) {
		this.mlsMaxTmsStbQltyGrCd = mlsMaxTmsStbQltyGrCd;
	}
	public String getFrmeLossVal() {
		return frmeLossVal;
	}
	public void setFrmeLossVal(String frmeLossVal) {
		this.frmeLossVal = frmeLossVal;
	}
	public String getFrmeLossStbQltyGrCd() {
		return frmeLossStbQltyGrCd;
	}
	public void setFrmeLossStbQltyGrCd(String frmeLossStbQltyGrCd) {
		this.frmeLossStbQltyGrCd = frmeLossStbQltyGrCd;
	}
	public long getFrmeLossTotVal() {
		return frmeLossTotVal;
	}
	public void setFrmeLossTotVal(long frmeLossTotVal) {
		this.frmeLossTotVal = frmeLossTotVal;
	}
	public long getMaxMlsPcrTms() {
		return maxMlsPcrTms;
	}
	public void setMaxMlsPcrTms(long maxMlsPcrTms) {
		this.maxMlsPcrTms = maxMlsPcrTms;
	}
	public long getReJoinCnt() {
		return reJoinCnt;
	}
	public void setReJoinCnt(long reJoinCnt) {
		this.reJoinCnt = reJoinCnt;
	}
	public String getReJoinCntStbQltyGrCd() {
		return reJoinCntStbQltyGrCd;
	}
	public void setReJoinCntStbQltyGrCd(String reJoinCntStbQltyGrCd) {
		this.reJoinCntStbQltyGrCd = reJoinCntStbQltyGrCd;
	}
	public long getOutgProfVal() {
		return outgProfVal;
	}
	public void setOutgProfVal(long outgProfVal) {
		this.outgProfVal = outgProfVal;
	}
	public long getLossProfVal() {
		return lossProfVal;
	}
	public void setLossProfVal(long lossProfVal) {
		this.lossProfVal = lossProfVal;
	}
	public long getChnlChgCnt() {
		return chnlChgCnt;
	}
	public void setChnlChgCnt(long chnlChgCnt) {
		this.chnlChgCnt = chnlChgCnt;
	}
	public long getNetAtckTms() {
		return netAtckTms;
	}
	public void setNetAtckTms(long netAtckTms) {
		this.netAtckTms = netAtckTms;
	}
	public String getMlrStaSyncCd() {
		return mlrStaSyncCd;
	}
	public void setMlrStaSyncCd(String mlrStaSyncCd) {
		this.mlrStaSyncCd = mlrStaSyncCd;
	}
	public String getMlrVerCtt() {
		return mlrVerCtt;
	}
	public void setMlrVerCtt(String mlrVerCtt) {
		this.mlrVerCtt = mlrVerCtt;
	}
	public String getMlrDtm() {
		return mlrDtm;
	}
	public void setMlrDtm(String mlrDtm) {
		this.mlrDtm = mlrDtm;
	}
	public long getMlrChnlCnt() {
		return mlrChnlCnt;
	}
	public void setMlrChnlCnt(long mlrChnlCnt) {
		this.mlrChnlCnt = mlrChnlCnt;
	}
	public long getMlrTsMaxCnt() {
		return mlrTsMaxCnt;
	}
	public void setMlrTsMaxCnt(long mlrTsMaxCnt) {
		this.mlrTsMaxCnt = mlrTsMaxCnt;
	}
	public long getMlrTsMinCnt() {
		return mlrTsMinCnt;
	}
	public void setMlrTsMinCnt(long mlrTsMinCnt) {
		this.mlrTsMinCnt = mlrTsMinCnt;
	}
	public long getMlrTsTotCnt() {
		return mlrTsTotCnt;
	}
	public void setMlrTsTotCnt(long mlrTsTotCnt) {
		this.mlrTsTotCnt = mlrTsTotCnt;
	}
	public long getMlrMlsVal() {
		return mlrMlsVal;
	}
	public void setMlrMlsVal(long mlrMlsVal) {
		this.mlrMlsVal = mlrMlsVal;
	}
	public long getMlrMlcVal() {
		return mlrMlcVal;
	}
	public void setMlrMlcVal(long mlrMlcVal) {
		this.mlrMlcVal = mlrMlcVal;
	}
	public long getMlrJitrMaxVal() {
		return mlrJitrMaxVal;
	}
	public void setMlrJitrMaxVal(long mlrJitrMaxVal) {
		this.mlrJitrMaxVal = mlrJitrMaxVal;
	}
	public long getMlrJitrMinVal() {
		return mlrJitrMinVal;
	}
	public void setMlrJitrMinVal(long mlrJitrMinVal) {
		this.mlrJitrMinVal = mlrJitrMinVal;
	}
	public long getMlrTms() {
		return mlrTms;
	}
	public void setMlrTms(long mlrTms) {
		this.mlrTms = mlrTms;
	}
	public long getMlrKeepMlsCnt() {
		return mlrKeepMlsCnt;
	}
	public void setMlrKeepMlsCnt(long mlrKeepMlsCnt) {
		this.mlrKeepMlsCnt = mlrKeepMlsCnt;
	}
	public long getMlrRecvrySize() {
		return mlrRecvrySize;
	}
	public void setMlrRecvrySize(long mlrRecvrySize) {
		this.mlrRecvrySize = mlrRecvrySize;
	}
	public long getMlrReqSendSussCnt() {
		return mlrReqSendSussCnt;
	}
	public void setMlrReqSendSussCnt(long mlrReqSendSussCnt) {
		this.mlrReqSendSussCnt = mlrReqSendSussCnt;
	}
	public long getMlrReqFailLmtOvrCnt() {
		return mlrReqFailLmtOvrCnt;
	}
	public void setMlrReqFailLmtOvrCnt(long mlrReqFailLmtOvrCnt) {
		this.mlrReqFailLmtOvrCnt = mlrReqFailLmtOvrCnt;
	}
	public long getMlrReqFailEtcCnt() {
		return mlrReqFailEtcCnt;
	}
	public void setMlrReqFailEtcCnt(long mlrReqFailEtcCnt) {
		this.mlrReqFailEtcCnt = mlrReqFailEtcCnt;
	}
	public long getMlrRpsSussCnt() {
		return mlrRpsSussCnt;
	}
	public void setMlrRpsSussCnt(long mlrRpsSussCnt) {
		this.mlrRpsSussCnt = mlrRpsSussCnt;
	}
	public long getMlrRpsFailReqSizeOvrCnt() {
		return mlrRpsFailReqSizeOvrCnt;
	}
	public void setMlrRpsFailReqSizeOvrCnt(long mlrRpsFailReqSizeOvrCnt) {
		this.mlrRpsFailReqSizeOvrCnt = mlrRpsFailReqSizeOvrCnt;
	}
	public long getMlrRpsFailSec1SizeOvrCnt() {
		return mlrRpsFailSec1SizeOvrCnt;
	}
	public void setMlrRpsFailSec1SizeOvrCnt(long mlrRpsFailSec1SizeOvrCnt) {
		this.mlrRpsFailSec1SizeOvrCnt = mlrRpsFailSec1SizeOvrCnt;
	}
	public long getMlrRpsFailNchngCnt() {
		return mlrRpsFailNchngCnt;
	}
	public void setMlrRpsFailNchngCnt(long mlrRpsFailNchngCnt) {
		this.mlrRpsFailNchngCnt = mlrRpsFailNchngCnt;
	}
	public long getMlrRpsFailSvrEtcCnt() {
		return mlrRpsFailSvrEtcCnt;
	}
	public void setMlrRpsFailSvrEtcCnt(long mlrRpsFailSvrEtcCnt) {
		this.mlrRpsFailSvrEtcCnt = mlrRpsFailSvrEtcCnt;
	}
	public long getMlrRpsFailNyRcvCnt() {
		return mlrRpsFailNyRcvCnt;
	}
	public void setMlrRpsFailNyRcvCnt(long mlrRpsFailNyRcvCnt) {
		this.mlrRpsFailNyRcvCnt = mlrRpsFailNyRcvCnt;
	}
	public long getMlrRpsFailEtcCnt() {
		return mlrRpsFailEtcCnt;
	}
	public void setMlrRpsFailEtcCnt(long mlrRpsFailEtcCnt) {
		this.mlrRpsFailEtcCnt = mlrRpsFailEtcCnt;
	}
	public long getMlrRecvryTms() {
		return mlrRecvryTms;
	}
	public void setMlrRecvryTms(long mlrRecvryTms) {
		this.mlrRecvryTms = mlrRecvryTms;
	}
	public long getMlrOvrWriteSize() {
		return mlrOvrWriteSize;
	}
	public void setMlrOvrWriteSize(long mlrOvrWriteSize) {
		this.mlrOvrWriteSize = mlrOvrWriteSize;
	}

	public long getInetSvcMgmtNum() {
		return inetSvcMgmtNum;
	}
	public void setInetSvcMgmtNum(long inetSvcMgmtNum) {
		this.inetSvcMgmtNum = inetSvcMgmtNum;
	}
	public long getInetSvcNum() {
		return inetSvcNum;
	}
	public void setInetSvcNum(long inetSvcNum) {
		this.inetSvcNum = inetSvcNum;
	}
	public String getL3EquipMdlNm() {
		return l3EquipMdlNm;
	}
	public void setL3EquipMdlNm(String l3EquipMdlNm) {
		this.l3EquipMdlNm = l3EquipMdlNm;
	}
	public String getL2EquipMdlNm() {
		return l2EquipMdlNm;
	}
	public void setL2EquipMdlNm(String l2EquipMdlNm) {
		this.l2EquipMdlNm = l2EquipMdlNm;
	}
	public String getTeamOrgId() {
		return teamOrgId;
	}
	public void setTeamOrgId(String teamOrgId) {
		this.teamOrgId = teamOrgId;
	}
	public String getL3EquipMgmtNum() {
		return l3EquipMgmtNum;
	}
	public void setL3EquipMgmtNum(String l3EquipMgmtNum) {
		this.l3EquipMgmtNum = l3EquipMgmtNum;
	}
	public String getL2EquipMgmtNum() {
		return l2EquipMgmtNum;
	}
	public void setL2EquipMgmtNum(String l2EquipMgmtNum) {
		this.l2EquipMgmtNum = l2EquipMgmtNum;
	}
}