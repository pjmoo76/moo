package com.skb.mi.itms.alarm;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;

import org.apache.commons.cli.HelpFormatter;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.StringUtils;

public class RMSListenSimulator {
	private String	ServiceName = "RMSListenSimulator";
	private int 	BUFFER_SIZE = 256;
	private Logger	logger;
	private int		portNo;

	public RMSListenSimulator() {
		logger = LogManager.getLogger(this.getClass().getName());
	}
	
	private void loadConfig() {
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		portNo = Integer.parseInt(configManager.getConfig(this.ServiceName, "portNo"));

		logger.info(String.format("(portNo=%d)", portNo));
	}
	
	public void run() {
		ServerSocket serverSocket = null;
		try {
			serverSocket = new ServerSocket(portNo);
		} catch (IOException e) {
			logger.error(e);
		}
		while (true) {
			try {
				Socket socket = serverSocket.accept();
				logger.info("accepted...");
				Listener listener = new Listener(socket);
				listener.run();
			} catch (IOException e) {
				logger.error(e);
			}
		}
	}
	
	class Listener {
		Thread	worker;
		Socket	socket;
		public Listener(Socket socket) {
			this.socket = socket;
		}
		public void run() {
			worker = new Thread(new Runner(this));
			worker.start();
		}
	}
	
	class Runner implements Runnable {
		Listener parent;
		public Runner(Listener parent) {
			this.parent = parent;
		}

		@Override
		public void run() {
			logger.info("run...");
			try {
				InputStream inputStream = parent.socket.getInputStream ();
				byte[] buf = new byte[BUFFER_SIZE];
				while (true) {
					int count = inputStream.read(buf);
					logger.info(String.format("read %d bytes", count));
					if (count == -1) {
						break;
					}
					logger.info(StringUtils.toHexString2(buf, count));
					logger.info(StringUtils.toReadableString(buf, count));
				}
				inputStream.close();
				parent.socket.close();
			} catch (IOException e) {
				logger.error(e);
			}
		}
	}

	public static void main(String[] args) {
		EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("RMSClient", envManager.getOptions());
    		System.exit(0);
    	}
    	RMSListenSimulator simulator = new RMSListenSimulator();
    	simulator.loadConfig();
    	simulator.run();
	}

}
