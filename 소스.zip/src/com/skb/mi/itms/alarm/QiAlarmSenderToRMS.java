package com.skb.mi.itms.alarm;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.cli.HelpFormatter;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.skb.mi.common.ConfigManager;
import com.skb.mi.common.DateUtils;
import com.skb.mi.common.EnvManager;
import com.skb.mi.common.IbatisSessionFactory;
import com.skb.mi.common.MiscUtils;
import com.skb.mi.common.StringUtils;
import com.skb.mi.itms.model.BQA30210;

public class QiAlarmSenderToRMS {
	private String	ServiceName = "QiAlarmSenderToRMS";
	private Logger	logger;
	private	String	dbName;
	private	int		sleepSec;
	private String[]	rmsIpAddr;
	private int		portNo;
	private	String	selectMntrDthmQid;
	private	String	selectQiAlarmQid;
	
	private	Socket socket;
	private OutputStream os;
	
	public static final char	ESC			= 0x1B;
	public static final char	STX			= 0x02;
	public static final char	ETX			= 0x03;
	public static final char	PAIR		= 0x1E;
	public static final char	DELIMITER	= 0x1F;
	public static final char	SLASH		= 0x2F;
	public static final char	BACKSLASH	= 0x5C;
	public static final String	HEADER		= String.format("%c%c", ESC, STX);
	public static final String	FOOTER		= String.format("%c%c", ESC, ETX);
	
	public QiAlarmSenderToRMS() {
		logger = LogManager.getLogger(this.getClass().getName());
	}
	
	private void loadConfig() {
		String cfgFile = EnvManager.env.getConf() + File.separator + EnvManager.env.getCfgFile();
		ConfigManager configManager = new ConfigManager(cfgFile);
		dbName = configManager.getConfig(this.ServiceName, "dbName");
		sleepSec = Integer.parseInt(configManager.getConfig(this.ServiceName, "sleepSec"));
		rmsIpAddr = new String[2];
		rmsIpAddr[0] = configManager.getConfig(this.ServiceName, "primaryIpAddr");
		rmsIpAddr[1] = configManager.getConfig(this.ServiceName, "secondaryIpAddr");
		portNo = Integer.parseInt(configManager.getConfig(this.ServiceName, "portNo"));
		selectMntrDthmQid = configManager.getConfig(this.ServiceName, "selectMntrDthmQid");
		selectQiAlarmQid = configManager.getConfig(this.ServiceName, "selectQiAlarmQid");

		logger.info(String.format("(dbName=%s)", dbName));
		logger.info(String.format("(sleepSec=%d)", sleepSec));
		logger.info(String.format("(primaryIpAddr=%s)", rmsIpAddr[0]));
		logger.info(String.format("(secondaryIpAddr=%s)", rmsIpAddr[1]));
		logger.info(String.format("(portNo=%d)", portNo));
		logger.info(String.format("(selectMntrDthmQid=%s)", selectMntrDthmQid));
		logger.info(String.format("(selectQiAlarmQid=%s)", selectQiAlarmQid));
	}
	
	private void run() {
		String mntrDthm = DateUtils.getAddedTime("yyyyMMddHHmm", (60*30)*-1);
		while (true) {
			try {
				mntrDthm = doIt(mntrDthm);
			} catch (Exception e) {
				logger.error(e);
			}
			MiscUtils.sleep(sleepSec*1000);
		}
	}
	
	private String doIt(String mntrDthm) throws Exception {
		logger.info(String.format("doIt(%s)", mntrDthm));
		SqlSession sqlSession = IbatisSessionFactory.openSession(dbName);
		HashMap<String, String> params = new HashMap<String,String>();
		params.put("mntrDthm", mntrDthm);
		params.put("sumOperId", "0030");
		String nextMntrDthm = sqlSession.selectOne(selectMntrDthmQid, params);
		if (nextMntrDthm != null) {
			logger.info("nextMntrDthm=" + nextMntrDthm);
			params.put("mntrDthm", nextMntrDthm);
			List<BQA30210> alarmList = sqlSession.selectList(selectQiAlarmQid, params);
			if (alarmList != null && alarmList.size() > 0) {
				sendAlarm(alarmList);
			}
			return nextMntrDthm;
		} else {
			return mntrDthm;
		}
	}
	
	private void sendAlarm(List<BQA30210> alarmList) {
		connectRMS();
		logger.info(String.format("alarm-size=%d", alarmList.size()));
		int i = 0;
		while (i < alarmList.size()) {
			BQA30210 alarm = alarmList.get(i);
			/*
			 header : 2 byte
			 	0x1B (0)
			 	0x02 (1)
			 body : (delimiter 0x1F) 
			 	01. EVENT_TYPE		: 100
			 	02. EVENT_TIME		: {YYYYMMDDHHMI}00
			 	03. DATA_TYPE		: QI
			 	04. CMTS_TID		: char[8]
			 	05. CELL_NO			: char[34]
			 	06. MAIN_QI_FAULT	: char[3]
			 	07. MAIN_QI_DATA	: char[16]
			 	08. QI_MLS			: char[16]
			 	09. QI_LOSS			: char[16]
			 	10. QI_JITTER		: char[16]
			 	11. QI_JF			: char[10]
			 	12. QI_EPG			: char[10]
			 tail : 2 byte
			 	0x1B (162)
			 	0x03 (163)
			 */
			String qiMls = alarm.getMlsGoodgCnt() + "," + alarm.getMlsWarngCnt() + "," + alarm.getMlsCrtgCnt();
			String qiLoss = alarm.getLossGoodgCnt() + "," + alarm.getLossWarngCnt() + "," + alarm.getLossCrtgCnt();
			String qiJitter = alarm.getJitrGoodgCnt() + "," + alarm.getJitrWarngCnt() + "," + alarm.getJitrCrtgCnt();
			String qiJf = alarm.getJoinFailGoodgCnt() + "," + alarm.getJoinFailWarngCnt() + "," + alarm.getJoinFailCrtgCnt();
			String qiEpg= alarm.getEpgGoodgCnt() + "," + alarm.getEpgWarngCnt() + "," + alarm.getEpgCrtgCnt();

			String mainQiFault = "MLS";
			String mainQiData = qiMls;
			int warngCrtgCnt = alarm.getMlsWarngCnt() + alarm.getMlsCrtgCnt();
			if (warngCrtgCnt < alarm.getLossWarngCnt() + alarm.getLossCrtgCnt()) {
				mainQiFault = "LOS";
				mainQiData = qiLoss;
				warngCrtgCnt = alarm.getLossWarngCnt() + alarm.getLossCrtgCnt();
			}
			if (warngCrtgCnt < alarm.getJitrWarngCnt() + alarm.getJitrCrtgCnt()) {
				mainQiFault = "JIT";
				mainQiData = qiJitter;
				warngCrtgCnt = alarm.getJitrWarngCnt() + alarm.getJitrCrtgCnt();
			}
			if (warngCrtgCnt < alarm.getJoinFailWarngCnt() + alarm.getJoinFailCrtgCnt()) {
				mainQiFault = "JF";
				mainQiData = qiJf;
				warngCrtgCnt = alarm.getJoinFailWarngCnt() + alarm.getJoinFailCrtgCnt();
			}
			if (warngCrtgCnt < alarm.getEpgWarngCnt() + alarm.getEpgCrtgCnt()) {
				mainQiFault = "EPG";
				mainQiData = qiEpg;
				warngCrtgCnt = alarm.getEpgWarngCnt() + alarm.getEpgCrtgCnt();
			}
			
			StringBuffer buf = new StringBuffer();
			buf.append(HEADER);
			buf.append("100").append(DELIMITER);
			buf.append(alarm.getMntrDthm()).append(DELIMITER);
			buf.append("QI").append(DELIMITER);
			buf.append(alarm.getEquipMgmtNum()).append(DELIMITER);
			buf.append(alarm.getCcellNum()).append(DELIMITER);
			buf.append(mainQiFault).append(DELIMITER);
			buf.append(mainQiData).append(DELIMITER);
			buf.append(qiMls).append(DELIMITER);
			buf.append(qiLoss).append(DELIMITER);
			buf.append(qiJitter).append(DELIMITER);
			buf.append(qiJf).append(DELIMITER);
			buf.append(qiEpg).append(DELIMITER);
			buf.append(FOOTER);
			
			String alarmMsg = buf.toString();

			logger.info(StringUtils.toHexString(alarmMsg.getBytes()));
			logger.info(StringUtils.toReadableString(alarmMsg.getBytes()));
			
			//i ++;
			try {
				logger.info(String.format("sending %d bytes", alarmMsg.getBytes().length));
				os.write(alarmMsg.getBytes());
				os.flush();
				logger.info(String.format("sent [%d] (%s,%s,%s)", i, alarm.getMntrDthm(), alarm.getEquipMgmtNum(), alarm.getCcellNum()));
				i ++;
			} catch (Exception e) {
				logger.error(e);
				connectRMS();
			}
		}
		disconnectRMS();
	}
	
	private void connectRMS() {
		while (true) {
			for (int i = 0; i < rmsIpAddr.length; i ++) {
				try {
					logger.info(String.format("try to connect %s %d", rmsIpAddr[i], portNo));
					socket = new Socket(rmsIpAddr[i], portNo);
					os = socket.getOutputStream();
					logger.info(String.format("connected %s %d", rmsIpAddr[i], portNo));
					return;
				} catch (Exception e) {
					logger.error(e);
					disconnectRMS();
				}
				MiscUtils.sleep(sleepSec*1000);
			}
		}
	}
	
	private void disconnectRMS() {
		try {
			if (os != null) os.close();
		} catch (IOException e) {
		}
		try {
			if (socket != null) socket.close();
		} catch (Exception e) {
		}
	}

	public static void main(String[] args) {
		EnvManager envManager = new EnvManager(args);
    	if (envManager.isValid() == false) {
    		HelpFormatter formatter = new HelpFormatter();
    		formatter.printHelp("QiAlarmSenderToRMS", envManager.getOptions());
    		System.exit(0);
    	}
    	
    	QiAlarmSenderToRMS sender = new QiAlarmSenderToRMS();
    	sender.loadConfig();
    	sender.run();
	}

}
