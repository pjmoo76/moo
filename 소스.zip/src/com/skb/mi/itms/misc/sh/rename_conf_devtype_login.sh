#!/bin/bash

YMD=`date +%Y%m%d`

if [ -f /eai/INT/foms/CM-0010/conf_devtype_login_${YMD}.unl.#FIN ];then
	mv  /eai/INT/foms/CM-0010/conf_devtype_login_${YMD}.unl.#FIN /eai/INT/foms/CM-0010/FOM_CONF_DEVTYPE_LOGIN_${YMD}.unl.#FIN
else
	exit 1
fi
