#!/bin/bash

HOST_NAME=`hostname | sed 's/\./\ /g' | awk '{print $1}'`

if [ "$HOST_NAME" == "adamsitmsts02" ]; then

	/home/miuser/adams/run_adams_itms.sh CmInfoCopyHandler -PROCESS=CmInfoCopyHandler01
	sleep 1
	/home/miuser/adams/run_adams_itms.sh CmInfoCopyHandler -PROCESS=CmInfoCopyHandler02
	sleep 1
	/home/miuser/adams/run_adams_itms.sh CmInfoCopyHandler -PROCESS=CmInfoCopyHandler03

elif [ "$HOST_NAME" == "adamsitmsts03" ]; then


fi