#!/bin/bash

HOST_NAME=`hostname | sed 's/\./\ /g' | awk '{print $1}'`
YMD=`date +%Y%m%d`
USER_HOME_DIR=`eval echo ~${USER}`
LOG_FILE=${USER_HOME_DIR}/adams/logs/${HOST_NAME}.mon_adams_itms.${YMD}

if [ ! -f ${USER_HOME_DIR}/adams/logs ]; then
	mkdir -p ${USER_HOME_DIR}/adams/logs
fi

if [ ! -f $LOG_FILE ]; then
	touch $LOG_FILE
fi

echo "" >> $LOG_FILE
echo "-----------------------------------------" >> $LOG_FILE
date >> $LOG_FILE
echo "" >> $LOG_FILE

if [ "$HOST_NAME" == "adamsitmsts02" ]; then

	daemonName='scheduler-agent'
	pid=`ps -ef | grep ${daemonName} | grep -v grep | grep -v tail | grep -v mon_adams_daemon.sh | awk '{print $2}'`
	if [ -n "$pid" ]; then
		echo $daemonName $pid >> $LOG_FILE
	else
		echo $daemonName is down >> $LOG_FILE
		/app/nexcore/scheduler-agent/startup.sh
		pid=`ps -ef | grep ${daemonName} | grep -v grep | grep -v tail | grep -v mon_adams_daemon.sh | awk '{print $2}'`
		echo $daemonName $pid >> $LOG_FILE
	fi

	daemonName='VocGet'
	pid=`ps -ef | grep ${daemonName} | grep -v grep | grep -v tail | grep -v mon_adams_daemon.sh | awk '{print $2}'`
	if [ -n "$pid" ]; then
		echo $daemonName $pid >> $LOG_FILE
	else
		echo $daemonName is down >> $LOG_FILE
		/home/miuser/adams/run_adams_mi.sh ${daemonName}
		pid=`ps -ef | grep ${daemonName} | grep -v grep | grep -v tail | grep -v mon_adams_daemon.sh | awk '{print $2}'`
		echo $daemonName $pid >> $LOG_FILE
	fi

	daemonName='Fault2Get'
	pid=`ps -ef | grep ${daemonName} | grep -v grep | grep -v tail | grep -v mon_adams_daemon.sh | awk '{print $2}'`
	if [ -n "$pid" ]; then
		echo $daemonName $pid >> $LOG_FILE
	else
		echo $daemonName is down >> $LOG_FILE
		/home/miuser/adams/run_adams_mi.sh ${daemonName}
		pid=`ps -ef | grep ${daemonName} | grep -v grep | grep -v tail | grep -v mon_adams_daemon.sh | awk '{print $2}'`
		echo $daemonName $pid >> $LOG_FILE
	fi

	daemonName='TossGet'
	pid=`ps -ef | grep ${daemonName} | grep -v grep | grep -v tail | grep -v mon_adams_daemon.sh | awk '{print $2}'`
	if [ -n "$pid" ]; then
		echo $daemonName $pid >> $LOG_FILE
	else
		echo $daemonName is down >> $LOG_FILE
		/home/miuser/adams/run_adams_mi.sh ${daemonName}
		pid=`ps -ef | grep ${daemonName} | grep -v grep | grep -v tail | grep -v mon_adams_daemon.sh | awk '{print $2}'`
		echo $daemonName $pid >> $LOG_FILE
	fi

	daemonName='CCAGet'
	pid=`ps -ef | grep ${daemonName} | grep -v grep | grep -v tail | grep -v mon_adams_daemon.sh | awk '{print $2}'`
	if [ -n "$pid" ]; then
		echo $daemonName $pid >> $LOG_FILE
	else
		echo $daemonName is down >> $LOG_FILE
		/home/miuser/adams/run_adams_mi.sh ${daemonName}
		pid=`ps -ef | grep ${daemonName} | grep -v grep | grep -v tail | grep -v mon_adams_daemon.sh | awk '{print $2}'`
		echo $daemonName $pid >> $LOG_FILE
	fi

	daemonName='SwingRealApGetService'
	pid=`ps -ef | grep ${daemonName} | grep -v grep | grep -v tail | grep -v mon_adams_daemon.sh | awk '{print $2}'`
	if [ -n "$pid" ]; then
		echo $daemonName $pid >> $LOG_FILE
	else
		echo $daemonName is down >> $LOG_FILE
		/home/miuser/cm-service/bin/swg-real-ap.sh
		pid=`ps -ef | grep ${daemonName} | grep -v grep | grep -v tail | grep -v mon_adams_daemon.sh | awk '{print $2}'`
		echo $daemonName $pid >> $LOG_FILE
	fi

	daemonName='SwingRealTerminalGetService'
	pid=`ps -ef | grep ${daemonName} | grep -v grep | grep -v tail | grep -v mon_adams_daemon.sh | awk '{print $2}'`
	if [ -n "$pid" ]; then
		echo $daemonName $pid >> $LOG_FILE
	else
		echo $daemonName is down >> $LOG_FILE
		/home/miuser/cm-service/bin/swg-real-terminal.sh
		pid=`ps -ef | grep ${daemonName} | grep -v grep | grep -v tail | grep -v mon_adams_daemon.sh | awk '{print $2}'`
		echo $daemonName $pid >> $LOG_FILE
	fi

	daemonName='CmServiceImpl'
	pid=`ps -ef | grep ${daemonName} | grep -v grep | grep -v tail | grep -v mon_adams_daemon.sh | awk '{print $2}'`
	if [ -n "$pid" ]; then
		echo $daemonName $pid >> $LOG_FILE
	else
		echo $daemonName is down >> $LOG_FILE
		/home/miuser/cm-batch/bin/cmbt-restart.sh
		pid=`ps -ef | grep ${daemonName} | grep -v grep | grep -v tail | grep -v mon_adams_daemon.sh | awk '{print $2}'`
		echo $daemonName $pid >> $LOG_FILE
	fi

elif [ "$HOST_NAME" == "adamsitmsts03" ]; then


fi