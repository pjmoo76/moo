#!/bin/bash

YMD=`date +%Y%m%d`

if [ -f /data/foms/conf_device_${YMD}.unl ];then
	mv  /data/foms/conf_device_${YMD}.unl /data/foms/FOM_CONF_DEVICE_${YMD}.unl
else
	exit 1
fi
