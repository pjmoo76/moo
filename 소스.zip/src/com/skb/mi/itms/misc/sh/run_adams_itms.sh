#!/bin/bash

if [ $# -eq 0 ]; then
	echo $0 [class]
	echo "	ItmsWorkOrder          : ItmsWorkOrder"
	echo "	ItmsWorkManager        : ItmsWorkManager"
	echo "	CmInfoSyncker          : CmInfoSyncker"
	echo "	CmInfoCopyHandler      : CmInfoCopyHandler"
	echo "	ItmsUserReportManager  : ItmsUserReportManager"
	echo ""
	exit
fi

className=$1

if [ "$className" == "ItmsWorkManager" ]; then
	pid=`ps -ef | grep ${className} | grep -v grep | grep -v tail | grep -v $0 | grep $2 | awk '{print $2}'`
elif [ "$className" == "CmInfoCopyHandler" ]; then
	execOption=${2:1}
	pid=`ps -ef | grep ${className} | grep -v grep | grep -v tail | grep -v $0 | grep ${execOption} | awk '{print $2}'`
else
	pid=`ps -ef | grep ${className} | grep -v grep | grep -v tail | grep -v $0 | awk '{print $2}'`
fi

if [ -n "$pid" ]; then
	echo "kill -9 $pid"
	kill -9 $pid
fi

classExecOption=""
classExecMode="bg"
memOption=""

if [ "$className" == "ItmsWorkOrder" ]; then
	adamsClassPath="com.skb.mi.itms.stat"
elif [ "$className" == "ItmsWorkManager" ]; then
	adamsClassPath="com.skb.mi.itms.stat"
	classExecOption="-PROCESS=$2"
elif [ "$className" == "CmInfoSyncker" ]; then
	adamsClassPath="com.skb.mi.itms.cm"
elif [ "$className" == "CmInfoCopyHandler" ]; then
	adamsClassPath="com.skb.mi.itms.cm"
	classExecOption=$2
	memOption="-Xms4096m -Xmx8192m"
elif [ "$className" == "ItmsUserReportManager" ]; then
	adamsClassPath="com.skb.mi.itms.report"
	classExecOption=$2
	memOption="-Xms4096m -Xmx8192m"
else
	echo "unsupported program : ${className}"
	exit
fi


export LANG="ko_KR.UTF-8"
SKB_MI_HOME="/home/miuser/adams"
CFG_FILE="mi-itms-service-prd.xml"

for i in `ls ${SKB_MI_HOME}/lib/*.jar`
do
	if [ -z ${JAVA_LIBS} ]; then
		JAVA_LIBS=$i
	else
		JAVA_LIBS=${JAVA_LIBS}:$i
	fi
done

if [ "$classExecMode" == "fg" ]; then
	java -Djava.security.egd=file:///dev/urandom -cp ${JAVA_LIBS}:${SKB_MI_HOME}/conf ${memOption} ${adamsClassPath}.${className} -SKB_MI_HOME=${SKB_MI_HOME} -CFG_FILE=${CFG_FILE} ${classExecOption}
else
	java -Djava.security.egd=file:///dev/urandom -cp ${JAVA_LIBS}:${SKB_MI_HOME}/conf ${memOption} ${adamsClassPath}.${className} -SKB_MI_HOME=${SKB_MI_HOME} -CFG_FILE=${CFG_FILE} ${classExecOption}  >& /dev/null &
fi
