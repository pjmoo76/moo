package com.skb.adams.core.batch.common.utils.excel;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.skb.adams.core.constant.FileConstants;
import com.skb.adams.core.constant.LineConstants;

/**
 * <ul>
 * <li>업무 그룹명 : adams-core-framework-batch</li>
 * <li>서브 업무명 : com.skb.adams.core.batch.common.utils.excel</li>
 * <li>설  명 : ExcelFactory.java</li>
 * <li>작성일 : 2018. 7. 7.</li>
 * <li>작성자 : Ko Kyoung Hak (AA)</li>
 * </ul>
 */
public class ExcelFactory<E, T> {
    /**
     * LOGGER
     */
    protected static final Logger LOGGER = LoggerFactory.getLogger(ExcelFactory.class);

    /**
     * ExcelFactory
     */
    private ExcelFactory() {

    }

    /**
     * makeExcel
     *
     * @param fileFullPath
     * @param excelDao
     * @param excelVO
     * @param baseMethod
     * @param header
     * @param bodyOrder
     * @throws FileNotFoundException
     * @throws IOException void
     */
    public void makeExcel(String fileFullPath, E excelDao, T excelVO, String baseMethod, String[] header, String[] bodyOrder) throws FileNotFoundException, IOException {
        makeExcel(fileFullPath, excelDao, excelVO, baseMethod, header, bodyOrder, 1000);
    }

    /**
     * makeExcel
     *
     * @param fileFullPath
     * @param excelDao
     * @param excelVO
     * @param baseMethod
     * @param header
     * @param bodyOrder
     * @param maxQueryCount
     * @throws FileNotFoundException
     * @throws IOException void
     */
    public void makeExcel(String fileFullPath, E excelDao, T excelVO, String baseMethod, String[] header, String[] bodyOrder, long maxQueryCount) throws FileNotFoundException, IOException {

        fileFullPath = fileFullPath.replace(LineConstants.DOUBLE_BACKSLASH, LineConstants.SLASH);

        String lowerFileFullPath = fileFullPath.toLowerCase();
        BaseExcelHandler<E, T> excel = null;

        if (lowerFileFullPath.endsWith(FileConstants.XLSX)) {  // Excel2007~
            excel = new ExcelExHandler<E, T>();
        } else if (lowerFileFullPath.endsWith(FileConstants.XLS)) {   // Excel2003
            excel = new ExcelExHandler<E, T>();
        } else if (lowerFileFullPath.endsWith(FileConstants.CSV)) {
            excel = new ExcelExHandler<E, T>();
        } else {
            throw new FileNotFoundException();
        }

        excel.setMaxQueryCount(maxQueryCount);
        excel.makeExcel(excelDao, excelVO, baseMethod, header, bodyOrder);
        excel.closeExcel();
    }

    /**
     * getExcel2007
     *
     * @return BaseExcelHandler<E,T>
     */
    public static <E, T> BaseExcelHandler<E, T> getExcel2007() {
        return new ExcelExHandler<E, T>();
    }
}
