/*
 * Copyright (c) 2018 SK Broadband.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with SK Broadband.
 */
package com.skb.adams.core.batch;

import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.text.WordUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;

import com.skb.adams.core.batch.common.constants.BatchConstants;
import com.skb.adams.core.batch.common.constants.BatchConstants.BATCH_EXCEPTION;
import com.skb.adams.core.batch.common.utils.NexcoreSupport;
import com.skb.adams.core.batch.config.BatchConfig;
import com.skb.adams.core.batch.exception.BatchException;
import com.skb.adams.core.batch.jobs.BaseJob;
import com.skb.adams.core.batch.model.JobExecutionResult;
import com.skb.adams.core.utils.CoreErrorUtils;

/**
 * <ul>
 * <li>업무 그룹명 : adams-core-framework-batch</li>
 * <li>서브 업무명 : com.skb.adams.core.batch</li>
 * <li>설  명 : BaseBatchMain.java</li>
 * <li>작성일 : 2018. 7. 7.</li>
 * <li>작성자 : Ko Kyoung Hak (AA)</li>
 * </ul>
 */
public abstract class BaseBatchMain {
	/**
	 * LOGGER
	 */
	protected static Logger LOGGER = LoggerFactory.getLogger(BaseBatchMain.class);

	/**
	 * context
	 */
	protected static ApplicationContext context = null;

	/**
	 *
	 * runBatchJob : Remote Server 환경 수행
	 *
	 * @return
	 * @throws Exception JobExecutionResult
	 */
	public static JobExecutionResult runBatchJob(ApplicationContext context) throws Exception	{
		BaseBatchMain.context = context;
		BatchConfig batchConfig = null;

		try {
			batchConfig = (BatchConfig) context.getBean("batchConfig");
			batchConfig.loadConfig();

			LOGGER.debug("[CORE-BATCH] batchConfig                      : {}", batchConfig);
			LOGGER.debug("[CORE-BATCH] batchConfig.isAgentLocal()       : {}", batchConfig.isAgentLocal());
			LOGGER.debug("[CORE-BATCH] batchConfig.getAgentInputFile()  : {}", batchConfig.getAgentInputFile());
			LOGGER.debug("[CORE-BATCH] batchConfig.getAgentOutputFile() : {}", batchConfig.getAgentOutputFile());

			// NBS 파라미터 설정 및 Batch Job 수행
			return runBatchJob(NexcoreSupport.readExecutionJob(batchConfig));

		} catch (BeansException | IOException e) {
		    LOGGER.error(CoreErrorUtils.getStackTrace(e));
            createErrorOutFile(e);
		} catch (BatchException e) {
		    // BatchException의 경우, AspectConfig에서 out 파일을 생성하므로 파일 생성 로직은 불필요
          throw e;
		} catch(Exception e) {
		    createErrorOutFile(e);
		}
		return null;
	}

	/**
	 *
	 * runBatchJob : Local 환경 수행
	 *
	 * @param context
	 * @param jobName
	 * @param inFilePath
	 * @param outFilePath
	 * @return
	 * @throws Exception JobExecutionResult
	 */
	public static JobExecutionResult runBatchJob(ApplicationContext context, String jobName, boolean chgJobParams, String inFilePath, String outFilePath) throws Exception {
		BaseBatchMain.context = context;
		BatchConfig batchConfig = null;

		try {
			batchConfig = (BatchConfig) context.getBean("batchConfig");
			batchConfig.loadConfig();

			// NBS 입력 및 출력 파라미터 파일 설정
			batchConfig.setAgentInputFile (inFilePath);
			batchConfig.setAgentOutputFile(outFilePath);

			// NBS Job 설정
			batchConfig.setRunTaskJobName(jobName);

			// NBS 파라미터 동적 변경여부 설정
			batchConfig.setChgJobParams(chgJobParams);

			LOGGER.debug("[CORE-BATCH] batchConfig                      : {}", batchConfig);
			LOGGER.debug("[CORE-BATCH] batchConfig.isAgentLocal()       : {}", batchConfig.isAgentLocal());
			LOGGER.debug("[CORE-BATCH] batchConfig.getAgentInputFile()  : {}", batchConfig.getAgentInputFile());
			LOGGER.debug("[CORE-BATCH] batchConfig.getAgentOutputFile() : {}", batchConfig.getAgentOutputFile());

			// Batch Job 수행
			return runBatchJob(jobName);

		} catch (BeansException e) {
			LOGGER.error(CoreErrorUtils.getStackTrace(e));
			throw new Exception(e);
		}
	}

	/**
	 *
	 * runBatchJob : Spring Bean 조회 및 doProcess() 수행
	 *
	 * @param jobName
	 * @return
	 * @throws Exception JobExecutionResult
	 */
	private static JobExecutionResult runBatchJob(String jobName) throws Exception {

        LOGGER.info("[CORE-BATCH] jobName : {}", jobName);

		BaseJob batchJobInstance = null;
		try {
		    // Spring Bean 조회 및 실행 : 첫글자를 소문자료 변경하여 Spring Bean 조회
			batchJobInstance = (BaseJob) context.getBean(WordUtils.uncapitalize(jobName));
			return batchJobInstance.doProcess(jobName);
		} catch (BeansException | IOException | BatchException | NullPointerException e) {
		    LOGGER.error(CoreErrorUtils.getStackTrace(e));
			throw e;
		}
	}

	/**
	 * createErrorOutFile
	 *
	 * @param e
	 * @throws IOException
	 * @throws BatchException
	 * @return void
	 */
	private static void createErrorOutFile(Exception e) throws Exception {
        BatchConfig batchConfig = null;
        ConcurrentHashMap<String, String> sourceMap = null;

        LOGGER.error("[CORE-BATCH] runBatchJob() 실행중, 예외가 발생하였습니다. !");
        LOGGER.error(CoreErrorUtils.getStackTrace(e));

        batchConfig = (BatchConfig) context.getBean("batchConfig");
        batchConfig.loadConfig();

        sourceMap = NexcoreSupport.readJobArguments(batchConfig);

        JobExecutionResult jobExecutionResult = new JobExecutionResult();

        jobExecutionResult.setReturnCode(String.valueOf(BATCH_EXCEPTION.RUNTIME_EXCEPTION.getExceptionCode()));
        jobExecutionResult.setReturnMessage(e.getMessage());
        jobExecutionResult.setCause(e.toString());
        jobExecutionResult.setExecutedJob(sourceMap.get(BatchConstants.BATCH_PARAM_EXEC_JOB_NAME));

        try {
            NexcoreSupport.writeJobResult(batchConfig.getAgentOutputFile(), jobExecutionResult);
        } catch(IOException ioe){
            LOGGER.error(CoreErrorUtils.getStackTrace(e));
            throw e;
        }
        // Batch Exception을 정확하게 파악하기 위해 Throw 처리
        throw e;
	}
}
