package com.skb.adams.core.batch.system;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <ul>
 * <li>업무 그룹명 : adams-core-framework-batch</li>
 * <li>서브 업무명 : com.skb.adams.core.batch.system</li>
 * <li>설  명 : AdamsRuntime.java</li>
 * <li>작성일 : 2018. 2. 15.</li>
 * <li>작성자 : Ko Kyoung Hak (AA)</li>
 * </ul>
 */
public class AdamsRuntime {
    /**
     * LOGGER
     */
    protected static final Logger LOGGER = LoggerFactory.getLogger(AdamsRuntime.class);

    /**
     * run
     *
     * @return Process
     * @throws IOException
     */
    public static synchronized Process exec(List<String> command) throws IOException {
        ProcessBuilder processBuilder = new ProcessBuilder(command);
//        processBuilder.directory();
        return processBuilder.start();
    }

    /**
     * run
     *
     * @param command
     * @return
     * @throws IOException Process
     */
    public static synchronized Process exec(String... command) throws IOException {
        LOGGER.debug("command.length : {}", command.length);

        List<String> listCommand = new ArrayList<String>();
        if (command.length > 0) {
            for(String item : command) {
                LOGGER.debug("command : {}", item);
                listCommand.add(item);
            }
        }
        return AdamsRuntime.exec(listCommand);
    }

    /**
     * run
     *
     * @param command
     * @return
     * @throws IOException Process
     */
//    public static Process run(String command) throws IOException
//    {
//        return Runtime.getRuntime().exec(command);
//    }
}
