/**
 * Copyright (c) 2018 SK Broadband.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with SK Broadband.
 */
package com.skb.adams.core.batch.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

/**
 * <ul>
 * <li>업무 그룹명 : adams-core-framework-batch</li>
 * <li>서브 업무명 : com.skb.adams.core.batch.dao</li>
 * <li>설  명 : BaseDao.java</li>
 * <li>작성일 : 2018. 2. 15.</li>
 * <li>작성자 : Ko Kyoung Hak (AA)</li>
 * </ul>
 */
@Transactional(rollbackFor=Exception.class)
public abstract class BaseDao {
    /**
     * LOGGER
     */
    protected static final Logger LOGGER = LoggerFactory.getLogger(BaseDao.class);

    /**
     * sqlSessionTemplate
     */
    @Autowired
    protected SqlSessionTemplate sqlSessionTemplate = null;

}
