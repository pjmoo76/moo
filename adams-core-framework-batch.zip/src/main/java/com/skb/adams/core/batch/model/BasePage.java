/**
 * Copyright (c) 2018 SK Broadband. All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with SK
 * Telecom.
 */
package com.skb.adams.core.batch.model;

import com.skb.adams.core.model.BaseObject;

/**
 * <ul>
 * <li>업무 그룹명 : adams-core-framework-batch</li>
 * <li>서브 업무명 : com.skb.adams.core.batch.model</li>
 * <li>설 명 : 페이지 정보를 포함하는 Model은 본 클래스를 상속받아서 생성한다.</li>
 * <li>작성일 : 2018. 2. 15.</li>
 * <li>작성자 : Ko Kyoung Hak (AA)</li>
 * </ul>
 */
@SuppressWarnings("serial")
public abstract class BasePage extends BaseObject {

    /** 총 조회건수 */
    protected int totalCnt = 0;

    /** 페이지 NO 1 부터 시작 */
    protected int pageNo = 0;

    /** 한 페이지당 조회 건수 */
    protected int rowPerPage = 0;

    /** 화면에 보여질 페이지 개수 */
    protected int pageSize = 0;

    /** 총 페이지 수 , int totalPage= (int)Math.ceil(totalCnt/vo.getPageSize()) ; */
    protected int totalPage = 0;

    /** 한 화면에 보여줄 첫번째 Row */
    protected int firstRowIndex = 0;

    /** 한 화면에 보여줄 마지막 Row */
    protected int lastRowIndex = 0;

    /** 한 화면의 시작 페이지 번호 */
    protected int startPageNo = 0;

    /** 한 화면의 끝 페이지 번호 */
    protected int endPageNo = 0;

    /**
     *
     * getTotalCnt
     *
     * @return int
     */
    public int getTotalCnt() {
        return totalCnt;
    }

    /**
     *
     * setTotalCnt
     *
     * @param totalCnt
     *            void
     */
    public void setTotalCnt(int totalCnt) {
        this.totalCnt = totalCnt;
    }

    /**
     *
     * getPageNo
     *
     * @return int
     */
    public int getPageNo() {
        return pageNo;
    }

    /**
     *
     * setPageNo
     *
     * @param pageNo
     *            void
     */
    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    /**
     *
     * getRowPerPage
     *
     * @return int
     */
    public int getRowPerPage() {
        return rowPerPage;
    }

    /**
     *
     * setRowPerPage
     *
     * @param rowPerPage
     *            void
     */
    public void setRowPerPage(int rowPerPage) {
        this.rowPerPage = rowPerPage;
    }

    /**
     *
     * getPageSize
     *
     * @return int
     */
    public int getPageSize() {
        return pageSize;
    }

    /**
     *
     * setPageSize
     *
     * @param pageSize
     *            void
     */
    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    /**
     *
     * getTotalPage
     *
     * @return int
     */
    public int getTotalPage() {
        return totalPage;
    }

    /**
     *
     * setTotalPage
     *
     * @param totalPage
     *            void
     */
    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    /**
     *
     * getFirstRowIndex
     *
     * @return int
     */
    public int getFirstRowIndex() {
        return firstRowIndex;
    }

    /**
     *
     * setFirstRowIndex
     *
     * @param firstRowIndex
     *            void
     */
    public void setFirstRowIndex(int firstRowIndex) {
        this.firstRowIndex = firstRowIndex;
    }

    /**
     *
     * getLastRowIndex
     *
     * @return int
     */
    public int getLastRowIndex() {
        return lastRowIndex;
    }

    /**
     *
     * setLastRowIndex
     *
     * @param lastRowIndex
     *            void
     */
    public void setLastRowIndex(int lastRowIndex) {
        this.lastRowIndex = lastRowIndex;
    }

    /**
     *
     * getStartPageNo
     *
     * @return int
     */
    public int getStartPageNo() {
        return startPageNo;
    }

    /**
     *
     * setStartPageNo
     *
     * @param startPageNo
     *            void
     */
    public void setStartPageNo(int startPageNo) {
        this.startPageNo = startPageNo;
    }

    /**
     *
     * getEndPageNo
     *
     * @return int
     */
    public int getEndPageNo() {
        return endPageNo;
    }

    /**
     *
     * setEndPageNo
     *
     * @param endPageNo
     *            void
     */
    public void setEndPageNo(int endPageNo) {
        this.endPageNo = endPageNo;
    }
}
