package com.skb.adams.core.batch.common.utils.reflect;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.skb.adams.core.utils.CoreErrorUtils;

/**
 * <ul>
 * <li>업무 그룹명 : adams-core-framework-batch</li>
 * <li>서브 업무명 : com.skb.adams.core.batch.util.reflect</li>
 * <li>설  명 : ReflectUtil.java</li>
 * <li>작성일 : 2018. 2. 15.</li>
 * <li>작성자 : Ko Kyoung Hak (AA)</li>
 * </ul>
 */
public class ReflectUtil {
	/**
     * LOGGER
     */
    protected static final Logger LOGGER = LoggerFactory.getLogger(ReflectUtil.class);

    /**
     * callMethod
     *
     * @param object
     * @param methodName
     * @param args
     * @return Object
     */
    public static Object callMethod(Object object, String methodName, Object... args) {
        try {
            Class<?>[] parameterTypes = null;
            if (args.length > 0) {
                parameterTypes = new Class[args.length];
                for (int i = 0; i < args.length; i++) {
                    if("setFirstRowIndex".equals(methodName) || "setLastRowIndex".equals(methodName)) {
                        parameterTypes[i] = int.class;
                    } else {
                        parameterTypes[i] = args[i].getClass();
                    }
                }
            }

            Method method = null;
            Class clazz = object.getClass();

            while (true) {
                try {
                    method = clazz.getDeclaredMethod(methodName, parameterTypes);
                    break;
                } catch (NoSuchMethodException e) {
                    LOGGER.debug("no error : NoSuchMethodException : " + CoreErrorUtils.getStackTrace(e));
                } catch (SecurityException e) {
                    LOGGER.debug("no error : SecurityException : " + CoreErrorUtils.getStackTrace(e));
                }
                clazz = clazz.getSuperclass();
                if (clazz == null) {
                    break;
                }
            }

            if (method == null) {
                return null;
            }

            return method.invoke(object, args);
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
            LOGGER.error("IllegalAccessException : " + CoreErrorUtils.getStackTrace(e));
        }
        return null;
    }
}
