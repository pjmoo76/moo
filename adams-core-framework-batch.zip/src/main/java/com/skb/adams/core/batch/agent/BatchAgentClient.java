/*
 * Copyright (c) 2018 SK Broadband.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with SK Broadband.
 */
package com.skb.adams.core.batch.agent;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.skb.adams.core.batch.common.constants.BatchConstants;
import com.skb.adams.core.constant.LineConstants;
import com.skb.adams.core.utils.CoreErrorUtils;

/**
 * <ul>
 * <li>업무 그룹명 : adams-core-framework-batch</li>
 * <li>서브 업무명 : com.skb.adams.core.batch.agent</li>
 * <li>설  명 : BatchAgentClient.java</li>
 * <li>작성일 : 2018. 2. 14.</li>
 * <li>작성자 : Ko Kyoung Hak (AA)</li>
 * </ul>
 */
public class BatchAgentClient {
	/**
	 * LOGGER
	 */
	protected static final Logger LOGGER = LoggerFactory.getLogger(BatchAgentClient.class);

	/**
	 * DatagramSocket
	 */
	private DatagramSocket socket = null;

	/**
	 * 	Batch Agent IP 주소 : Batch 모듈이 실행되는 서버 환경에는 반드시 존재하므로 항상 localhost
	 */
	private String agentIp = "";
	/**
	 * Batch Agent Port
	 */
	private int agentPort = 8888;

	/**
	 * Send buffer
	 */
	private byte[] sendBuffer = new byte[100];
	/**
	 * Clear Buffer
	 */
	private byte[] clearBuffer = new byte[100];

	/**
	 * BatchAgentClient
	 */
	public BatchAgentClient(String agentIp, int agentPort) {
		this.agentIp = agentIp;
		this.agentPort = agentPort;
	}

	/**
	 * connectAgentClient
	 *   void
	 */
	public void connectAgentClient() {
		try {
			connectSocket();
		} catch (SocketException e) {
			LOGGER.error(CoreErrorUtils.getStackTrace(e));
			throw new RuntimeException(e);
		}
	}

	/**
	 * disconnectAgentClient
	 *   void
	 */
	public void disconnectAgentClient() {
		if (socket != null) {
			try {
			} catch (Exception e) {
	            LOGGER.error(CoreErrorUtils.getStackTrace(e));
			} finally {
				if (socket != null) {
					try {
						socket.close();
					} catch(Exception e) {
					    LOGGER.error(CoreErrorUtils.getStackTrace(e));
					}
				}
				socket = null;
			}
		}
	}

	/**
	 *
	 * connectSocket
	 *
	 * @throws SocketException void
	 */
	private void connectSocket() throws SocketException	{
		disconnectAgentClient();

		socket = new DatagramSocket();
		socket.connect(new InetSocketAddress(agentIp, agentPort));
	}

	/**
	* .<br>
	*
	* char(10) : "PROGRESS" <br>
	* char(50) : job execution id <br>
	* char(20) : progress total <br>
	* char(20) : progress current <br>
	*
	* @param jobexeId
	* @param progressTotal progress total
	* @param progressCurrent progress current
	* @throws IOException
	*/
	public void sendBatchStatus(String jobexeId, long progressTotal, long progressCurrent) throws IOException {

		// Send Buffer Clear
		System.arraycopy(clearBuffer, 0, sendBuffer, 0, clearBuffer.length);

		int offset = 0;

		// Command
		offset += putFieldToSendBuffer(BatchConstants.BATCH_AGENT_COMMAND_PROGRESS, offset, 10);

		// Data
		offset += putFieldToSendBuffer(jobexeId ,                             offset, 50);
		offset += putFieldToSendBuffer(progressTotal   + LineConstants.EMPTY, offset, 20);
		offset += putFieldToSendBuffer(progressCurrent + LineConstants.EMPTY, offset, 20);

		LOGGER.info("SEND BATCH STATUS >>" + new String(sendBuffer));

		DatagramPacket packet = new DatagramPacket(sendBuffer, 0, offset);
		socket.send(packet);
	}

	/**
	* send text copy.
	* @param text
	* @param offset
	* @param maxLength text maxLength maxLength copy .
	* @return maxLength
	*/
	private int putFieldToSendBuffer(String text, int offset, int	maxLength) {
		byte[] textBytes = text.getBytes();

		System.arraycopy(textBytes, 0, sendBuffer, offset, Math.min(textBytes.length, maxLength));

		return maxLength;
	}

}
