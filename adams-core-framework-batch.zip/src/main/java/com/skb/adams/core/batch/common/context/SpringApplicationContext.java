/**
 * Copyright (c) 2018 SK Broadband. All right reserved.
 *
 * This software is the confidential and proprietary information of SK
 * Broadband. You shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement you entered
 * into with SK Broadband.
 */
package com.skb.adams.core.batch.common.context;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 * <ul>
 * <li>업무 그룹명 : adams-core-framework-batch</li>
 * <li>서브 업무명 : com.skb.adams.core.batch.common.context</li>
 * <li>설  명 : SpringApplicationContext.java</li>
 * <li>작성일 : 2018. 8. 2.</li>
 * <li>작성자 : Ko Kyoung Hak (AA)</li>
 * </ul>
 */
public class SpringApplicationContext implements ApplicationContextAware {
	private static final Logger LOGGER = LoggerFactory.getLogger(SpringApplicationContext.class);

	private static ApplicationContext CONTEXT;

	public SpringApplicationContext() {
		LOGGER.info("■ SpringApplicationContext is Initialized !");
	}

	public static ApplicationContext getApplicationContext() {
        return CONTEXT;
    }

	public void setApplicationContext(ApplicationContext context) throws BeansException {
		CONTEXT = context;
	}
}
