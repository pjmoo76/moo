package com.skb.adams.core.batch.common.utils.excel;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.CellStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.skb.adams.core.batch.common.utils.reflect.ReflectUtil;
import com.skb.adams.core.constant.LineConstants;

/**
 * <ul>
 * <li>업무 그룹명 : adams-core-framework-batch</li>
 * <li>서브 업무명 : com.skb.adams.core.batch.util.excel</li>
 * <li>설  명 : BaseExcelHandler.java</li>
 * <li>작성일 : 2018. 2. 15.</li>
 * <li>작성자 : Ko Kyoung Hak (AA)</li>
 * </ul>
 */
public abstract class BaseExcelHandler<E, T> {
    /**
     * LOGGER
     */
    protected static final Logger LOGGER = LoggerFactory.getLogger(BaseExcelHandler.class);

    /**
     * MAX_ROW_COUNT
     *
     * XSLX 의 Max Row : Excel2003 : 65,536 = 2^16
     * XSLX 의 Max Row : Excel2007 : 1,048,576 = 2^20
     *
     */
    /**
     * MAX_ROW_COUNT_EXCEL2003
     */
    public static final long MAX_ROW_COUNT_EXCEL = 60000;
    /**
     * MAX_ROW_COUNT_EXCEL2007
     */
    public static final long MAX_ROW_COUNT_EXCEL_EX = 1000000;

    /**
     * maxSheetCount
     */
    protected long maxRowPerSheetCount = 0;
    /**
     * totalRowCount
     */
    protected long totalRowCount = 0;

    /**
     * maxQueryCount
     */
    protected long maxQueryCount = 1000;

    /**
     * setHeaderMerge
     *
     * @param arryInt : Int[] = {시작index, 종료index}
     */
    public abstract void setHeaderMerge(int[]... arrInt) ;

   /**
    *
    * setHeaderStyle
    *
    * @param style : org.apache.poi.ss.usermodel.CellStyle
    * @param index - 0부터 시작
    */
    public abstract void setHeaderStyle(CellStyle style, int... index) ;

    /**
     *
     * setHeaderStyle
     *
     * @param style : org.apache.poi.ss.usermodel.CellStyle
     * @param index - {0,1} {1,7} 과 같은 int 배열
     */
     public abstract void setHeaderStyle(CellStyle style, int[]... index) ;

    /**
     *
     * setHeaderBgColor
     *
     * @param color - String -  - HSSFColor.[color].index
     *                AQUA : 49
     *                BLACK : 8
     *                BLUE : 12
     *                BLUE_GREY : 54
     *                BRIGHT_GREEN : 11
     *                BROWN : 60
     *                CORAL : 29
     *                CORNFLOWER_BLUE : 24
     *                DARK_BLUE : 18
     *                DARK_GREEN : 58
     *                DARK_RED : 16
     *                DARK_TEAL : 56
     *                DARK_YELLOW : 19
     *                GOLD : 51
     *                GREEN : 17
     *                GREY_25_PERCENT : 22
     *                GREY_40_PERCENT : 55
     *                GREY_50_PERCENT : 23
     *                GREY_80_PERCENT : 63
     *                INDIGO : 62
     *                LAVENDER : 46
     *                LEMON_CHIFFON : 26
     *                LIGHT_BLUE : 48
     *                LIGHT_CORNFLOWER_BLUE : 31
     *                LIGHT_GREEN : 42
     *                LIGHT_ORANGE : 52
     *                LIGHT_TURQUOISE : 41
     *                LIGHT_YELLOW : 43
     *                LIME : 50
     *                MAROON : 25
     *                OLIVE_GREEN : 59
     *                ORANGE : 53
     *                ORCHID : 28
     *                PALE_BLUE : 44
     *                PINK : 14
     *                PLUM : 61
     *                RED : 10
     *                ROSE : 45
     *                ROYAL_BLUE : 30
     *                SEA_GREEN : 57
     *                SKY_BLUE : 40
     *                TAN : 47
     *                TEAL : 21
     *                TURQUOISE : 15
     *                VIOLET : 20
     *                WHITE : 9
     *                YELLOW : 13
     * @param index
     */
    public abstract void setHeaderBgColor(String color, int... index)  ;

    /**
     *
     * setHeaderBgColor
     *
     * @param color - String -  - HSSFColor.[color].index
     *                AQUA : 49
     *                BLACK : 8
     *                BLUE : 12
     *                BLUE_GREY : 54
     *                BRIGHT_GREEN : 11
     *                BROWN : 60
     *                CORAL : 29
     *                CORNFLOWER_BLUE : 24
     *                DARK_BLUE : 18
     *                DARK_GREEN : 58
     *                DARK_RED : 16
     *                DARK_TEAL : 56
     *                DARK_YELLOW : 19
     *                GOLD : 51
     *                GREEN : 17
     *                GREY_25_PERCENT : 22
     *                GREY_40_PERCENT : 55
     *                GREY_50_PERCENT : 23
     *                GREY_80_PERCENT : 63
     *                INDIGO : 62
     *                LAVENDER : 46
     *                LEMON_CHIFFON : 26
     *                LIGHT_BLUE : 48
     *                LIGHT_CORNFLOWER_BLUE : 31
     *                LIGHT_GREEN : 42
     *                LIGHT_ORANGE : 52
     *                LIGHT_TURQUOISE : 41
     *                LIGHT_YELLOW : 43
     *                LIME : 50
     *                MAROON : 25
     *                OLIVE_GREEN : 59
     *                ORANGE : 53
     *                ORCHID : 28
     *                PALE_BLUE : 44
     *                PINK : 14
     *                PLUM : 61
     *                RED : 10
     *                ROSE : 45
     *                ROYAL_BLUE : 30
     *                SEA_GREEN : 57
     *                SKY_BLUE : 40
     *                TAN : 47
     *                TEAL : 21
     *                TURQUOISE : 15
     *                VIOLET : 20
     *                WHITE : 9
     *                YELLOW : 13
     * @param index
     */
    public abstract void setHeaderBgColor(String color, int[]... index)  ;

    /**
     *
     * setHeaderBgColor
     *
     * @param color - short - HSSFColor.[color].index
     *                AQUA : 49
     *                BLACK : 8
     *                BLUE : 12
     *                BLUE_GREY : 54
     *                BRIGHT_GREEN : 11
     *                BROWN : 60
     *                CORAL : 29
     *                CORNFLOWER_BLUE : 24
     *                DARK_BLUE : 18
     *                DARK_GREEN : 58
     *                DARK_RED : 16
     *                DARK_TEAL : 56
     *                DARK_YELLOW : 19
     *                GOLD : 51
     *                GREEN : 17
     *                GREY_25_PERCENT : 22
     *                GREY_40_PERCENT : 55
     *                GREY_50_PERCENT : 23
     *                GREY_80_PERCENT : 63
     *                INDIGO : 62
     *                LAVENDER : 46
     *                LEMON_CHIFFON : 26
     *                LIGHT_BLUE : 48
     *                LIGHT_CORNFLOWER_BLUE : 31
     *                LIGHT_GREEN : 42
     *                LIGHT_ORANGE : 52
     *                LIGHT_TURQUOISE : 41
     *                LIGHT_YELLOW : 43
     *                LIME : 50
     *                MAROON : 25
     *                OLIVE_GREEN : 59
     *                ORANGE : 53
     *                ORCHID : 28
     *                PALE_BLUE : 44
     *                PINK : 14
     *                PLUM : 61
     *                RED : 10
     *                ROSE : 45
     *                ROYAL_BLUE : 30
     *                SEA_GREEN : 57
     *                SKY_BLUE : 40
     *                TAN : 47
     *                TEAL : 21
     *                TURQUOISE : 15
     *                VIOLET : 20
     *                WHITE : 9
     *                YELLOW : 13
     * @param index
     */
    public abstract void setHeaderBgColor(short color, int... index) ;

    /**
     *
     * setHeaderBgColor
     *
     * @param color - short - HSSFColor.[color].index
     *                AQUA : 49
     *                BLACK : 8
     *                BLUE : 12
     *                BLUE_GREY : 54
     *                BRIGHT_GREEN : 11
     *                BROWN : 60
     *                CORAL : 29
     *                CORNFLOWER_BLUE : 24
     *                DARK_BLUE : 18
     *                DARK_GREEN : 58
     *                DARK_RED : 16
     *                DARK_TEAL : 56
     *                DARK_YELLOW : 19
     *                GOLD : 51
     *                GREEN : 17
     *                GREY_25_PERCENT : 22
     *                GREY_40_PERCENT : 55
     *                GREY_50_PERCENT : 23
     *                GREY_80_PERCENT : 63
     *                INDIGO : 62
     *                LAVENDER : 46
     *                LEMON_CHIFFON : 26
     *                LIGHT_BLUE : 48
     *                LIGHT_CORNFLOWER_BLUE : 31
     *                LIGHT_GREEN : 42
     *                LIGHT_ORANGE : 52
     *                LIGHT_TURQUOISE : 41
     *                LIGHT_YELLOW : 43
     *                LIME : 50
     *                MAROON : 25
     *                OLIVE_GREEN : 59
     *                ORANGE : 53
     *                ORCHID : 28
     *                PALE_BLUE : 44
     *                PINK : 14
     *                PLUM : 61
     *                RED : 10
     *                ROSE : 45
     *                ROYAL_BLUE : 30
     *                SEA_GREEN : 57
     *                SKY_BLUE : 40
     *                TAN : 47
     *                TEAL : 21
     *                TURQUOISE : 15
     *                VIOLET : 20
     *                WHITE : 9
     *                YELLOW : 13
     * @param index
     */
    public abstract void setHeaderBgColor(short color, int[]... index) ;

    /**
     * getTotalCount
     *
     * @param excelDao
     * @param excelVO
     * @param baseMethod
     * @return long
     */
    public long getTotalCount(E excelDao, T excelVO, String baseMethod) {
        /**
         * totalRowCount를 구한다.
         */
        Object objTotalCount = ReflectUtil.callMethod(excelDao, baseMethod + "TotalCount", excelVO);
        totalRowCount = Long.parseLong(objTotalCount.toString());

        return totalRowCount;
    }

    /**
     * createExcel
     *
     * @param fileFullPath : 저장할 Excel의 절대 경로
     * @param excelDao : Data를 조회할 DAO
     * @param excelVO : 조회조건을 담을 model
     * @param baseMethod : excelDao 를 호출한 Base Method Name :  baseMethod + "TotalCount(excelVO)", baseMethod + "List(excelVO)" method가  존재 해야 한다.
     * @param headers : Excel Header
     * @param bodyOrders : Excel Body (excelVO에 bodyOrder[i] method를 호출 하여 Excel Cell Value를 채움)
     * @throws FileNotFoundException
     * @throws IOException void
     */
    public abstract void createExcel(String fileFullPath, E excelDao, T excelVO, String baseMethod, String[] headers, String[] bodyOrders) throws FileNotFoundException, IOException;

    /**
     * createExcel
     *
     * @param fileFullPath : 저장할 Excel의 절대 경로
     * @param excelDao : Data를 조회할 DAO
     * @param excelVO : 조회조건을 담을 model
     * @param baseMethod : excelDao 를 호출한 Base Method Name :  baseMethod + "TotalCount(excelVO)", baseMethod + "List(excelVO)" method가  존재 해야 한다.
     * @param headers : Excel Multi Header
     * @param bodyOrders : Excel Body (excelVO에 bodyOrder[i] method를 호출 하여 Excel Cell Value를 채움)
     * @throws FileNotFoundException
     * @throws IOException void
     */
    public abstract void createExcel(String fileFullPath, E excelDao, T excelVO, String baseMethod, String[][] headers, String[] bodyOrders) throws FileNotFoundException, IOException;


    /**
     * createExcel
     *
     * @param fileFullPath : 저장할 Excel의 절대 경로
     * @param excelDao : Data를 조회할 DAO
     * @param excelVO : 조회조건을 담을 model
     * @param baseMethod : excelDao 를 호출한 Base Method Name :  baseMethod + "TotalCount(excelVO)", baseMethod + "List(excelVO)" method가  존재 해야 한다.
     * @param headers : Excel Header (ex : header1,header2,header3)
     * @param bodyOrders : (ex : body1,body2,body3)
     * @throws FileNotFoundException
     * @throws IOException void
     */
    public void createExcel(String fileFullPath, E excelDao, T excelVO, String baseMethod, String headers, String bodyOrders) throws FileNotFoundException, IOException {
        String[] arrHeaders = headers.split("\\|\\|");
        String[][] multiHeaders = new String[arrHeaders.length][] ;

        for (int i = 0; i < arrHeaders.length; i++) {
        	multiHeaders[i] = arrHeaders[i].split(LineConstants.COMMA) ;
        }

        if (arrHeaders.length == 1) {
        	createExcel(fileFullPath, excelDao, excelVO, baseMethod, headers.split(LineConstants.COMMA), bodyOrders.split(LineConstants.COMMA));
        } else {
        	createExcel(fileFullPath, excelDao, excelVO, baseMethod, multiHeaders, bodyOrders.split(LineConstants.COMMA));
        }
    }

    /**
     * makeExcel
     *
     * @param excelDao : Data를 조회할 DAO
     * @param excelVO : 조회조건을 담을 model
     * @param baseMethod : excelDao 를 호출한 Base Method Name :  baseMethod + "TotalCount(excelVO)", baseMethod + "List(excelVO)" method가  존재 해야 한다.
     * @param headers : Excel Header
     * @param bodyOrders : Excel Body (excelVO에 bodyOrder[i] method를 호출 하여 Excel Cell Value를 채움)
     * @throws FileNotFoundException
     * @throws IOException void
     */
    public abstract void makeExcel(E excelDao, T excelVO, String baseMethod, String[] headers, String[] bodyOrders) throws FileNotFoundException, IOException;

    /**
     * makeExcel
     *
     * @param excelDao : Data를 조회할 DAO
     * @param excelVO : 조회조건을 담을 model
     * @param baseMethod : excelDao 를 호출한 Base Method Name :  baseMethod + "TotalCount(excelVO)", baseMethod + "List(excelVO)" method가  존재 해야 한다.
     * @param headers : Excel Multi Header
     * @param bodyOrders : Excel Body (excelVO에 bodyOrder[i] method를 호출 하여 Excel Cell Value를 채움)
     * @throws FileNotFoundException
     * @throws IOException void
     */
    public abstract void makeExcel(E excelDao, T excelVO, String baseMethod, String[][] headers, String[] bodyOrders) throws FileNotFoundException, IOException;

    /**
     * makeExcel
     *
     * @param excelDao : Data를 조회할 DAO
     * @param excelVO : 조회조건을 담을 model
     * @param baseMethod : excelDao 를 호출한 Base Method Name :  baseMethod + "TotalCount(excelVO)", baseMethod + "List(excelVO)" method가  존재 해야 한다.
     * @param headers : Excel Header (ex : header1,header2,header3)
     * @param bodyOrders : (ex : body1,body2,body3)
     * @throws FileNotFoundException
     * @throws IOException void
     */
    public void makeExcel(E excelDao, T excelVO, String baseMethod, String headers, String bodyOrders) throws FileNotFoundException, IOException {

    	String[] arrHeaders = headers.split("\\|\\|");
        String[][] multiHeaders = new String[arrHeaders.length][] ;

        for (int i = 0; i < arrHeaders.length; i++) {
        	multiHeaders[i] = arrHeaders[i].split(LineConstants.COMMA) ;
        }

        if (arrHeaders.length == 1) {
        	makeExcel(excelDao, excelVO, baseMethod, headers.split(LineConstants.COMMA), bodyOrders.split(LineConstants.COMMA));
        } else {
        	makeExcel(excelDao, excelVO, baseMethod, multiHeaders, bodyOrders.split(LineConstants.COMMA));
        }
    }

    /**
     * write
     *
     * @param fileFullPath : 저장할 Excel의 절대 경로
     * @throws FileNotFoundException
     * @throws IOException void
     */
    public abstract void write(String fileFullPath) throws FileNotFoundException, IOException;

    /**
     * closeExcel
     *
     * @throws IOException void
     */
    public abstract void closeExcel() throws IOException;

    /**
     * getter method for maxRowPerSheetCount
     * @return the maxRowPerSheetCount
     */
    public long getMaxRowPerSheetCount() {
        return maxRowPerSheetCount;
    }

    /**
     * setter method for maxRowPerSheetCount
     * @param maxRowPerSheetCount the maxRowPerSheetCount to set
     */
    public void setMaxRowPerSheetCount(long maxRowPerSheetCount) {
        this.maxRowPerSheetCount = maxRowPerSheetCount;
    }

    /**
     * getter method for totalRowCount
     * @return the totalRowCount
     */
    public long getTotalRowCount() {
        return totalRowCount;
    }

    /**
     * setter method for totalRowCount
     * @param totalRowCount the totalRowCount to set
     */
    public void setTotalRowCount(long totalRowCount) {
        this.totalRowCount = totalRowCount;
    }

    /**
     * getter method for maxQueryCount
     * @return the maxQueryCount
     */
    public long getMaxQueryCount() {
        return maxQueryCount;
    }

    /**
     * setter method for maxQueryCount
     * @param maxQueryCount the maxQueryCount to set
     */
    public void setMaxQueryCount(long maxQueryCount) {
        this.maxQueryCount = maxQueryCount;
    }
}
