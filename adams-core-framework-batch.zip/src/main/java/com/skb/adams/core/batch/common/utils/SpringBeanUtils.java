/**
 * Copyright (c) 2018 SK Broadband. All right reserved.
 *
 * This software is the confidential and proprietary information of SK
 * Broadband. You shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement you entered
 * into with SK Broadband.
 */

package com.skb.adams.core.batch.common.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

import com.skb.adams.core.batch.common.context.SpringApplicationContext;

/**
 * <ul>
 * <li>업무 그룹명 : adams-core-framework-batch</li>
 * <li>서브 업무명 : com.skb.adams.core.batch.common.utilss</li>
 * <li>설  명 : SpringBeanUtils.java</li>
 * <li>작성일 : 2018. 8. 2.</li>
 * <li>작성자 : Ko Kyoung Hak (AA)</li>
 * </ul>
 */
public class SpringBeanUtils {

	private static final Logger LOGGER = LoggerFactory.getLogger(SpringBeanUtils.class);

	public static <T> T getBean(String beanName, Class<T> requiredType) {
        ApplicationContext context = SpringApplicationContext.getApplicationContext();
        if (context == null ) {
            throw new NullPointerException("■ [Spring Container] ApplicationContext 초기화 작업이 정상적으로 수행되지 않아, Bean 객체를 획득할 수 없습니다.");
        }
		return context.getBean(beanName, requiredType);
	}

    public static Object getBean(String beanName) {
        ApplicationContext context = SpringApplicationContext.getApplicationContext();
        if (context == null ) {
        	throw new NullPointerException("■ [Spring Container] ApplicationContext 초기화 작업이 정상적으로 수행되지 않아, Bean 객체를 획득할 수 없습니다.");
        }

//        String[] names = context.getBeanDefinitionNames();
//        for (int i=0; i < names.length; i++) {
//            LOGGER.debug("■ Spring bean nams : {}", names[i]);
//        }

        return context.getBean(beanName);
    }
}
