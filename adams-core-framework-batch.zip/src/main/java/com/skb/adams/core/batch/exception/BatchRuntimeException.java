/**
 * Copyright (c) 2018 SK Broadband.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with SK Broadband.
 */
package com.skb.adams.core.batch.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.skb.adams.core.batch.common.constants.BatchConstants.BATCH_EXCEPTION;

/**
 * <ul>
 * <li>업무 그룹명 : adams-core-framework-batch</li>
 * <li>서브 업무명 : com.skb.adams.core.batch.exception</li>
 * <li>설  명 : BatchRuntimeException.java</li>
 * <li>작성일 : 2018. 2. 15.</li>
 * <li>작성자 : Ko Kyoung Hak (AA)</li>
 * </ul>
 */
public abstract class BatchRuntimeException extends RuntimeException {
	/**
	 * serialVersionUID
	 */
    private static final long serialVersionUID = 5795085604842749869L;

    /**
     * LOGGER
     */
    protected final Logger LOGGER = LoggerFactory.getLogger("UNCHECKED_EXCEPTION");

	/**
	 * module
	 */
	private String module = "";

	/**
	 * exceptionCode
	 */
	private int exceptionCode = 0;

	/**
	 *
	 * BatchRuntimeException
	 * @param cause
	 */
	public BatchRuntimeException(Throwable cause) {
		super(cause);
		this.exceptionCode = BATCH_EXCEPTION.RUNTIME_EXCEPTION.getExceptionCode();
	}

	/**
	 *
	 * BatchRuntimeException
	 * @param message
	 */
	public BatchRuntimeException(String message) {
	    super(message);
	}

	/**
	 *
	 * BatchRuntimeException
	 * @param cause
	 * @param message
	 */
    public BatchRuntimeException(Throwable cause, String message) {
        super(message, cause);
    }

    /**
     *
     * BatchRuntimeException
     * @param module
     * @param cause
     */
    public BatchRuntimeException(String module, Throwable cause) {
        super(cause);
        this.module = module;
    }

    /**
     *
     * BatchRuntimeException
     * @param module
     * @param message
     * @param cause
     */
    public BatchRuntimeException(String module, String message, Throwable cause) {
        super(message, cause);
        this.module = module;
    }

    /**
     *
     * getModule
     *
     * @return String
     */
    public String getModule() {
        return module;
    }

    /**
     *
     * getExceptionCode
     *
     * @return int
     */
    public int getExceptionCode() {
        return exceptionCode;
    }
}