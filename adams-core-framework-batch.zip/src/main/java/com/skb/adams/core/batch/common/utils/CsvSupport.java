/*
 * Copyright (c) 2018 SK Broadband.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with SK Broadband.
 */
package com.skb.adams.core.batch.common.utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.skb.adams.core.utils.CoreErrorUtils;

/**
 * <ul>
 * <li>업무 그룹명 : adams-core-framework-batch</li>
 * <li>서브 업무명 : com.skb.adams.core.batch.common.utils</li>
 * <li>설  명 : CsvSupport.java</li>
 * <li>작성일 : 2018. 7. 7.</li>
 * <li>작성자 : Ko Kyoung Hak (AA)</li>
 * </ul>
 */
public class CsvSupport {
	/**
	 * LOGGER
	 */
	protected static Logger LOGGER = LoggerFactory.getLogger(CsvSupport.class);

	/**
	 *
	 * getCsvLineCount
	 *
	 * @param csvFile
	 * @return
	 * @throws IOException int
	 */
    public static int getCsvLineCount(String csvFile) throws IOException {
        int lineCount = 0;

        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(csvFile))) {
            while (bufferedReader.readLine() != null) {
            	lineCount++;
            }
        } catch(Exception e) {
    		LOGGER.error(CoreErrorUtils.getStackTrace(e));
        }
        return lineCount;
    }

    /**
     *
     * getCsvAsList
     *
     * @param csvFile
     * @return
     * @throws IOException List<String>
     */
    public static List<String> getCsvAsList(String csvFile) throws IOException
    {
        List<String> csvList = new ArrayList<String>();
        String lineString = null;

        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(csvFile))) {
            while((lineString = bufferedReader.readLine()) != null) {
                csvList.add(lineString);
            }
        } catch(Exception e) {
    		LOGGER.error(CoreErrorUtils.getStackTrace(e));
        }
        return csvList;
    }

    /**
     *
     * getCsvAsList
     *
     * @param csvFile
     * @param from
     * @param to
     * @return
     * @throws IOException List<String>
     */
    public static List<String> getCsvAsList(String csvFile, int from, int to) throws IOException {
        List<String> csvList = new ArrayList<String>();

        String lineString = null;
        int currentIndex = 0;

        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(csvFile))) {
            while((lineString = bufferedReader.readLine()) != null) {
                if(currentIndex == to) {
                    break;
                }
                if(currentIndex >= from) {
                    csvList.add(lineString);
                }
                currentIndex++;
            }
        } catch(Exception e) {
    		LOGGER.error(CoreErrorUtils.getStackTrace(e));
        }
        return csvList;
    }
}
