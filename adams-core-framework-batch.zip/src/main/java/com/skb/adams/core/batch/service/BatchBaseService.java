/**
 * Copyright (c) 2018 SK Broadband. All right reserved.
 *
 * This software is the confidential and proprietary information of SK
 * Broadband. You shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement you entered
 * into with SK Broadband.
 */
package com.skb.adams.core.batch.service;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;

/**
 * <ul>
 * <li>업무 그룹명 : adams-core-framework-batch</li>
 * <li>서브 업무명 : com.skb.adams.core.batch.service</li>
 * <li>설  명 : BatchBaseService.java</li>
 * <li>작성일 : 2018. 7. 7.</li>
 * <li>작성자 : Ko Kyoung Hak (AA)</li>
 * </ul>
 */
public abstract class BatchBaseService extends BaseService {

    /**
     * messageSource 선언
     */
    @Autowired
    protected MessageSource messageSource = null;

   /**
     * 리소스번들에서 메시지 값 조회
     *
     * @param messageCode 리소스번들의 코드값
     * @param messageParameters array of arguments that will be filled in for
     *            params within the message (params look like "{0}", "{1,date}",
     *            "{2,time}" within a message)
     * @param defaultMessage 리소스번들 조회 실패시 기본 제공 메시지
     * @return 코드값에 해당하는 리소스 값
     */
    public String getMessage(String messageCode, Object[] messageParameters, String defaultMessage) {
        Locale locale  = Locale.getDefault();
        String message = this.messageSource.getMessage(messageCode, messageParameters, defaultMessage, locale);
        return message;
    }

    /**
     * 리소스번들에서 메시지 값 조회
     *
     * @param messageCode 리소스번들의 코드값
     * @param messageParameters array of arguments that will be filled in for
     *            params within the message (params look like "{0}", "{1,date}",
     *            "{2,time}" within a message)
     * @param defaultMessage 리소스번들 조회 실패시 기본 제공 메시지
     * @param locale 로케일
     * @return 코드값에 해당하는 리소스 값
     */
    public String getMessage(String messageCode, Object[] messageParameters, String defaultMessage, Locale locale) {
        String message = this.messageSource.getMessage(messageCode, messageParameters, defaultMessage, locale);
        return message;
    }
}
