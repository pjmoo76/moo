/*
 * Copyright (c) 2018 SK Broadband.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with SK Broadband.
 */
package com.skb.adams.core.batch.common.constants;

import java.util.List;

import com.skb.adams.core.constant.FileConstants;
import com.skb.adams.core.constant.LineConstants;

/**
 * <ul>
 * <li>업무 그룹명 : adams-core-framework-batch</li>
 * <li>서브 업무명 : com.skb.adams.core.batch.common.constants</li>
 * <li>설  명 : BatchConstants.java</li>
 * <li>작성일 : 2018. 8. 2.</li>
 * <li>작성자 : Ko Kyoung Hak (AA)</li>
 * </ul>
 */
public class BatchConstants extends LineConstants {

    public static final String LOCAL= "LOCAL";

    public static final String YES = "Y";
    public static final String NO = "N";

    public static final String STARTED   = "STARTED";      /* 시작 */
    public static final String EXECUTING = "EXECUTING";    /* 실행중 */
    public static final String COMPLETED = "COMPLETED";    /* 완료 */
    public static final String FAILED    = "FAILED";       /* 실패 */

    public static final String SELECT    = "S";
    public static final String INSERT    = "I";
    public static final String UPDATE    = "U";
    public static final String DELETE    = "D";

    public static final String TRACE = "T";
    public static final String DEBUG = "D";
    public static final String WARN  = "W";
    public static final String FATAL = "F";
    public static final String ERROR = "E";

    public static final int DEFAULT_COMMIT_SIZE = 50000;

    public static final String BATCH_AGENT_COMMAND_PROGRESS = "PROGRESS";

    public static final String BATCH_PARAM_JOB_ID           = "JOB_ID";
    public static final String BATCH_PARAM_JOB_DESC         = "JOB_DESC";
    public static final String BATCH_PARAM_JOB_INSTANCE_ID  = "JOB_INS_ID";
    public static final String BATCH_PARAM_JOB_EXECUTION_ID = "JOB_EXE_ID";
    public static final String BATCH_PARAM_EXEC_JOB_NAME    = "EXEC_JOB_NAME";

    /**
     * 환경변수 : NBS 파라미터 Input File 경로
     */
    public static final String BATCH_PARAM_FILE_PATH_IN = "NBS_PIN_FILE";

    /**
     * 환경변수 : NBS Job 수행 결과 Output File 경로
     */
    public static final String BATCH_PARAM_FILE_PATH_OUT = "NBS_POUT_FILE";

    // public static final String NEXCORE_TESTFILE_IN  = "src/main/resources/nexcore/mock/nexcore.in";
    // public static final String NEXCORE_TESTFILE_OUT = "src/main/resources/nexcore/mock/nexcore.out";

    public static final List<String> DENY_EXT = FileConstants.DENY_EXT;

    // Nexcore Batch Scheduler Return Codes
    public static final ReturnEnum NBS_RETURN_CODE_INIT  = ReturnEnum.NBS_RETURN_CODE_INIT;
    public static final ReturnEnum NBS_RETURN_CODE_OK    = ReturnEnum.NBS_RETURN_CODE_OK;
    public static final ReturnEnum NBS_RETURN_CODE_ERROR = ReturnEnum.NBS_RETURN_CODE_ERROR;

    // Application Return Codes
    public static final int SERVICE_SUCCESS = ResultEnum.MSG_SERVICE_SUCCESS.getKey();
    public static final int SERVICE_FAIL    = ResultEnum.MSG_SERVICE_FAIL   .getKey();

    public static final String SERVICE_SUCCESS_MSG = ResultEnum.MSG_SERVICE_SUCCESS.getValue();
    public static final String SERVICE_FAIL_MSG    = ResultEnum.MSG_SERVICE_FAIL   .getValue();

    public static final ReturnEnum RETURN_CODE_INIT  = ReturnEnum.RETURN_CODE_INIT;
    public static final ReturnEnum RETURN_CODE_OK    = ReturnEnum.RETURN_CODE_OK;
    public static final ReturnEnum RETURN_CODE_ERROR = ReturnEnum.RETURN_CODE_ERROR;

    public static enum BATCH_EXCEPTION {
        CLASSIFIED_EXCEPTION  (1, "Checked business exception"),
        UNCLASSIFIED_EXCEPTION(8, "Checked exception"),
        RUNTIME_EXCEPTION     (9, "Unchecked exception")
        ;

        /**
         * exceptionCode
         */
        private int exceptionCode = 0;
        /**
         * exceptionMessage
         */
        private String exceptionMessage = "";

        /**
         * BATCH_EXCEPTION
         *
         * @param exceptionCode
         * @param exceptionMessage
         */
        private BATCH_EXCEPTION(int exceptionCode, String exceptionMessage) {
            this.exceptionCode = exceptionCode;
            this.exceptionMessage = exceptionMessage;
        }

        /**
         *
         * getExceptionCode
         *
         * @return int
         */
        public int getExceptionCode() {
            return exceptionCode;
        }

        /**
         *
         * getExceptionMessage
         *
         * @return String
         */
        public String getExceptionMessage() {
            return exceptionMessage;
        }
    }

    public enum ReturnEnum {

        // Nexcore Batch Scheduler Return Codes
        NBS_RETURN_CODE_INIT (  -1, "INIT"),         // 초기화
        NBS_RETURN_CODE_OK   (   0, "SUCCESS"),      // 성공
        NBS_RETURN_CODE_ERROR(   1, "ERROR"),        // 실패

        // Application Return Codes
        RETURN_CODE_INIT     (   0, "INIT"),         // 초기화
        RETURN_CODE_OK       (   1, "SUCCESS"),      // 정상
        RETURN_CODE_ERROR    (  -1, "ERROR");        // 오류

        /**
         * key
         */
        private int key = -1;

        /**
         * value
         */
        private String value = "INIT";

        /**
         * Constructor
         * @param key
         * @param value
         */
        ReturnEnum(int key, String value) {
            this.key   = key;
            this.value = value;
        }

        /**
         * getter method for key
         * @return the key
         */
        public int getKey() {
            return key;
        }

        /**
         * getter method for value
         * @return the value
         */
        public String getValue() {
            return value;
        }
    }

    public enum ResultEnum {
        MSG_SERVICE_SUCCESS              (  1, "message.service.success"),                  // 서비스 호출 정상
        MSG_SERVICE_FAIL                 ( -1, "message.service.fail"),                     // 서비스 호출 오류
        MSG_SERVICE_SUCCESS_NOTEXIST     (  0, "message.service.success.notexist")          // 서비스 호출 정상 but no data
        ;

        /**
         * key
         */
        private int key = -1;

        /**
         * value
         */
        private String value = "message.service.fail";

        /**
         * Constructor
         * @param key
         * @param value
         */
        ResultEnum(int key, String value) {
            this.key   = key;
            this.value = value;
        }

        /**
         * getter method for key
         * @return the key
         */
        public int getKey() {
            return key;
        }

        /**
         * getter method for value
         * @return the value
         */
        public String getValue() {
            return value;
        }
    }
}
