package com.skb.adams.core.batch.common.utils.excel;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import com.skb.adams.core.batch.common.utils.reflect.ReflectUtil;
import com.skb.adams.core.utils.CoreErrorUtils;

/**
 * <ul>
 * <li>업무 그룹명 : adams-core-framework-batch</li>
 * <li>서브 업무명 : com.skb.adams.core.batch.common.utils.excel</li>
 * <li>설  명 : ExcelExHandler.java</li>
 * <li>작성일 : 2018. 7. 7.</li>
 * <li>작성자 : Ko Kyoung Hak (AA)</li>
 * </ul>
 */
public class ExcelExHandler<E, T> extends BaseExcelHandler<E, T> {
    /**
     * workbook
     */
    private SXSSFWorkbook workbook = null;

    /**
     * sheet
     */
    private Sheet sheet = null;

    /**
     * styleHeader
     */
    private CellStyle styleHeader = null;
    /**
     * styleBody
     */
    private CellStyle styleBody = null;
    /**
     * headerColor
     */
    protected short headerColor = HSSFColor.GREY_25_PERCENT.index;
    /**
     * columnWidth
     */
    protected short columnWidth = 4000;

    /**
     * mergeList - 머지할 대상 list
     */
    private List<int[]> mergeList = new ArrayList<int[]>(); //new ArrayList<int[]>();

    /**
     * cellsList : styleList과 같은 index를 갖는 list
     *            여러 스타일 적용이 필요하므로 list로 선언한다.
     *            각 Set 에는 같은 style 적용이 필요한 Header cell index가 포함된다.
     *            Set의 원소들은 중복될수 없다.(Set 객체 특성)
     */
    private List<int[]> cellList = new ArrayList<int[]>();


    /**
     * styleList : cellList와 같은 index를 갖는 list
     *            여러 스타일 적용이 필요하므로 list로 선언한다.
     */
    private List<CellStyle> styleList = new ArrayList<CellStyle>();

    private int headerRowCount = 1;

    /**
     * ExcelUtil
     * @param fetchSize
     */
    public ExcelExHandler() {
        /**
         * fetchSize
         * poi가 excel 정보를 쪼개서 넣는건수(1000건이상이면 파일로저장)
         */
        workbook = new SXSSFWorkbook(1000);

        /**
         * XSLX 의 Max Row : Excel2007 : 1,048,576 = 2^20
         *          *
         * Row 는 1,048,576개가 최대임. Row는 0부터 시작하므로, getRowNum에서는 1,048,575까지 인자로 받는다.
         * POI throws java.lang.IllegalArgumentException, if rowNum < 0 or greater than 1,048,575
         * - http://poi.apache.org/apidoc/org/apache/poi/xssf/usermodel/XSSFRow.html#getRowNum()
         *
         * Column은 2^14 = 16,384 개가 Max 임.
         *
         */
        maxRowPerSheetCount = BaseExcelHandler.MAX_ROW_COUNT_EXCEL_EX;

        /**
         * create style...
         */
        styleHeader = createStyle(true,  CellStyle.ALIGN_CENTER, CellStyle.BORDER_THIN);
        styleBody   = createStyle(false, CellStyle.ALIGN_LEFT,   CellStyle.BORDER_THIN);
    }

    /**
     * createStyle
     *
     * @param style
     * @param align
     * @param border void
     */
    public CellStyle createStyle(boolean isHeader, short align, short border) {
        CellStyle style = workbook.createCellStyle();

        /**
         * Align
         */
        style.setAlignment(align);
        /**
         * Border
         */
        style.setBorderTop(border);
        style.setBorderBottom(border);
        style.setBorderLeft(border);
        style.setBorderRight(border);

        /**
         * header setting
         */
        if (isHeader) {
            /**
             * Font : Bold
             */
            Font font = workbook.createFont();

            font.setBoldweight((short)700);
            style.setFont(font);

            /**
             * Color
             */
            style.setFillForegroundColor(headerColor);
            style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        }

        return style;
    }

    /**
     * @see com.skb.adams.core.batch.util.excel.BaseExcelHandler#setHeaderMerge(int[][])
     */
    @Override
	public void setHeaderMerge(int[]... arrInt) {
    	for (int i = 0; i < arrInt.length; i++) {
    		mergeList.add(arrInt[i]);
    	}
	}

    /**
     *
     * exeHeaderMerge
     *   void
     */
    public void exeHeaderMerge() {
    	for (int i = 0; i < mergeList.size(); i++) {
    		if (mergeList.get(i).length == 2) {
    			sheet.addMergedRegion(new CellRangeAddress(0,0,mergeList.get(i)[0],mergeList.get(i)[1]));
    		} else if (mergeList.get(i).length == 4) {
    			sheet.addMergedRegion(new CellRangeAddress(mergeList.get(i)[0],mergeList.get(i)[1],mergeList.get(i)[2],mergeList.get(i)[3]));
    		} else {
    			new Exception("Merge Region Error!!");
    		}
    	}
    }

    /**
     * @see com.skb.adams.core.batch.util.excel.BaseExcelHandler#setHeaderStyle(org.apache.poi.ss.usermodel.CellStyle, int[])
     */
	@Override
	public void setHeaderStyle(CellStyle style, int... index) {
		for (int i = 0; i < index.length; i++) {
			int idx[] = {0, index[i]};
			cellList.add(idx);
			styleList.add(style);
		}
	}

	 /**
     * @see com.skb.adams.core.batch.util.excel.BaseExcelHandler#setHeaderStyle(org.apache.poi.ss.usermodel.CellStyle, int[][])
     */
	@Override
	public void setHeaderStyle(CellStyle style, int[]... index) {
		for (int i = 0; i < index.length; i++) {
			cellList.add(index[i]);
			styleList.add(style);
		}
	}


	/**
	 * @see com.skb.adams.core.batch.util.excel.BaseExcelHandler#setHeaderBgColor(java.lang.String, int[])
	 */
	@Override
	public void setHeaderBgColor(String color, int... index) {
		int idx[][] = new int[index.length][];

		for (int i = 0; i < index.length; i++) {
			idx[i] = new int[] {0, index[i]};
		}

		setHeaderBgColor(color ,idx);
	}


	/**
	 * @see com.skb.adams.core.batch.util.excel.BaseExcelHandler#setHeaderBgColor(java.lang.String, int[][])
	 */
	@Override
	public void setHeaderBgColor(String color, int[]... index) {
		short num = 0;

		switch(color) {
			case "AQUA"                  : num = 49; break;
			case "BLACK"                 : num = 8;  break;
			case "BLUE"                  : num = 12; break;
			case "BLUE_GREY"             : num = 54; break;
			case "BRIGHT_GREEN"          : num = 11; break;
			case "BROWN"                 : num = 60; break;
			case "CORAL"                 : num = 29; break;
			case "CORNFLOWER_BLUE"       : num = 24; break;
			case "DARK_BLUE"             : num = 18; break;
			case "DARK_GREEN"            : num = 58; break;
			case "DARK_RED"              : num = 16; break;
			case "DARK_TEAL"             : num = 56; break;
			case "DARK_YELLOW"           : num = 19; break;
			case "GOLD"                  : num = 51; break;
			case "GREEN"                 : num = 17; break;
			case "GREY_25_PERCENT"       : num = 22; break;
			case "GREY_40_PERCENT"       : num = 55; break;
			case "GREY_50_PERCENT"       : num = 23; break;
			case "GREY_80_PERCENT"       : num = 63; break;
			case "INDIGO"                : num = 62; break;
			case "LAVENDER"              : num = 46; break;
			case "LEMON_CHIFFON"         : num = 26; break;
			case "LIGHT_BLUE"            : num = 48; break;
			case "LIGHT_CORNFLOWER_BLUE" : num = 31; break;
			case "LIGHT_GREEN"           : num = 42; break;
			case "LIGHT_ORANGE"          : num = 52; break;
			case "LIGHT_TURQUOISE"       : num = 41; break;
			case "LIGHT_YELLOW"          : num = 43; break;
			case "LIME"                  : num = 50; break;
			case "MAROON"                : num = 25; break;
			case "OLIVE_GREEN"           : num = 59; break;
			case "ORANGE"                : num = 53; break;
			case "ORCHID"                : num = 28; break;
			case "PALE_BLUE"             : num = 44; break;
			case "PINK"                  : num = 14; break;
			case "PLUM"                  : num = 61; break;
			case "RED"                   : num = 10; break;
			case "ROSE"                  : num = 45; break;
			case "ROYAL_BLUE"            : num = 30; break;
			case "SEA_GREEN"             : num = 57; break;
			case "SKY_BLUE"              : num = 40; break;
			case "TAN"                   : num = 47; break;
			case "TEAL"                  : num = 21; break;
			case "TURQUOISE"             : num = 15; break;
			case "VIOLET"                : num = 20; break;
			case "WHITE"                 : num = 9;  break;
			case "YELLOW"                : num = 13; break;
			default                      : num = 22; break;
		}
		setHeaderBgColor(num ,index);
	}

	/**
	 * @see com.skb.adams.core.batch.util.excel.BaseExcelHandler#setHeaderBgColor(java.lang.String, int[])
	 */
	@Override
	public void setHeaderBgColor(short color, int... index) {
		CellStyle style = workbook.createCellStyle();

        // Align
        style.setAlignment        (CellStyle.ALIGN_CENTER);
        style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
        // Border
        style.setBorderTop   (CellStyle.BORDER_THIN);
        style.setBorderBottom(CellStyle.BORDER_THIN);
        style.setBorderLeft  (CellStyle.BORDER_THIN);
        style.setBorderRight (CellStyle.BORDER_THIN);

        // Font : Bold
        Font font = workbook.createFont();
        font.setBoldweight((short)700);
        style.setFont(font);

        // Color
        style.setFillForegroundColor(color);
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);

		setHeaderStyle(style, index);
	}

	/**
	 * @see com.skb.adams.core.batch.util.excel.BaseExcelHandler#setHeaderBgColor(java.lang.String, int[])
	 */
	@Override
	public void setHeaderBgColor(short color, int[]... index) {
		CellStyle style = workbook.createCellStyle();

        // Align
        style.setAlignment        (CellStyle.ALIGN_CENTER);
        style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
        // Border
        style.setBorderTop   (CellStyle.BORDER_THIN);
        style.setBorderBottom(CellStyle.BORDER_THIN);
        style.setBorderLeft  (CellStyle.BORDER_THIN);
        style.setBorderRight (CellStyle.BORDER_THIN);

        // Font : Bold
        Font font = workbook.createFont();
        font.setBoldweight((short)700);
        style.setFont(font);

        // Color
        style.setFillForegroundColor(color);
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);

		setHeaderStyle(style, index);
	}

    /**
	 *
	 * getHeaderStyle
	 *
	 * @param index
	 * @param style
	 * @return CellStyle
	 */
    private CellStyle getHeaderStyle(int index[], CellStyle style) {
    	CellStyle retStyle = style;

    	for (int i = 0; cellList != null && i < cellList.size(); i++) {
    		if (index[0] == cellList.get(i)[0] && index[1] == cellList.get(i)[1]) {
    			retStyle = styleList.get(i);
    		}
    	}
    	return retStyle;
    }


    /**
     * @see com.skb.adams.core.batch.util.excel.BaseExcelHandler#createExcel(java.lang.Object, java.lang.Object, java.lang.String, java.lang.String[], java.lang.String[])
     */
    @Override
    public void createExcel(String fileFullPath, E excelDao, T excelVO, String baseMethod, String[] headers, String[] bodyOrders) throws FileNotFoundException, IOException {
        try {
            /**
             * Excel 만들기
             *
             * excelDao에는 반드시 "get" + baseMethod + "TotalCount", "get" + baseMethod + "List" method가  존재 해야 한다.
             * excelVO는 반드시 com.skb.adams.core.batch.model.BasePage를 상속 받아야 한다.
             *
             *
             * makeExcel
             *
             * @param excelDao : Data를 조회할 DAO
             * @param excelVO : 조회조건을 담을 model
             * @param baseMethod : excelDao 를 호출한 Base Method Name :  baseMethod + "TotalCount(excelVO)", baseMethod + "List(excelVO)" method가  존재 해야 한다.
             * @param headers : Excel Header
             * @param bodyOrders : Excel Body (excelVO에 bodyOrder[i] method를 호출 하여 Excel Cell Value를 채움)
             * @throws FileNotFoundException
             * @throws IOException void
             */
            makeExcel(excelDao, excelVO, baseMethod, headers, bodyOrders);

            /**
             * File Write
             *
             * write
             *
             * @param fileFullPath : 저장할 Excel의 절대 경로
             * @throws FileNotFoundException
             * @throws IOException void
             */
            write(fileFullPath);
            /**
             * Close Excel
             */
        } finally {
            closeExcel();
        }
    }

    /**
     * @see com.skb.adams.core.batch.util.excel.BaseExcelHandler#createExcel(java.lang.Object, java.lang.Object, java.lang.String, java.lang.String[][], java.lang.String[])
     */
    @Override
    public void createExcel(String fileFullPath, E excelDao, T excelVO, String baseMethod, String[][] headers, String[] bodyOrders) throws FileNotFoundException, IOException {
    	headerRowCount = headers.length;

        try {
            /**
             * Excel 만들기
             *
             * excelDao에는 반드시 "get" + baseMethod + "TotalCount", "get" + baseMethod + "List" method가  존재 해야 한다.
             * excelVO는 반드시 com.skb.adams.core.batch.model.BasePage를 상속 받아야 한다.
             *
             *
             * makeExcel
             *
             * @param excelDao : Data를 조회할 DAO
             * @param excelVO : 조회조건을 담을 model
             * @param baseMethod : excelDao 를 호출한 Base Method Name :  baseMethod + "TotalCount(excelVO)", baseMethod + "List(excelVO)" method가  존재 해야 한다.
             * @param headers : Excel Header
             * @param bodyOrders : Excel Body (excelVO에 bodyOrder[i] method를 호출 하여 Excel Cell Value를 채움)
             * @throws FileNotFoundException
             * @throws IOException void
             */
            makeExcel(excelDao, excelVO, baseMethod, headers, bodyOrders);

            /**
             * File Write
             *
             * write
             *
             * @param fileFullPath : 저장할 Excel의 절대 경로
             * @throws FileNotFoundException
             * @throws IOException void
             */
            write(fileFullPath);
            /**
             * Close Excel
             */
        } finally {
            closeExcel();
        }
    }

    /**
     * @throws IOException
     * @throws FileNotFoundException
     * @see com.skb.adams.core.batch.util.excel.BaseExcelHandler#makeExcel(java.lang.String, java.lang.Object, java.lang.Object, java.lang.String, java.lang.String[], java.lang.String[])
     */
    @Override
    public void makeExcel(E excelDao, T excelVO, String baseMethod, String[] headers, String[] bodyOrders) throws FileNotFoundException, IOException {
    	String[][] multiHeaders = new String[1][];
    	multiHeaders[0] = headers;
    	makeExcel(excelDao, excelVO, baseMethod, multiHeaders, bodyOrders);
    }

    /**
     * @throws IOException
     * @throws FileNotFoundException
     * @see com.skb.adams.core.batch.util.excel.BaseExcelHandler#makeExcel(java.lang.String, java.lang.Object, java.lang.Object, java.lang.String, java.lang.String[], java.lang.String[])
     */
    @Override
    public void makeExcel(E excelDao, T excelVO, String baseMethod, String[][] headers, String[] bodyOrders) throws FileNotFoundException, IOException {
    	headerRowCount = headers.length;

        /**
         * XSLX 의 Max Row : Excel2007 : 1,048,576 = 2^20
         */
        if (maxRowPerSheetCount <= 0 || maxRowPerSheetCount > BaseExcelHandler.MAX_ROW_COUNT_EXCEL_EX) {
            maxRowPerSheetCount = BaseExcelHandler.MAX_ROW_COUNT_EXCEL_EX;
        }

        /**
         * getTotalCount을 호출 하지 않았다면...
         */
        if (totalRowCount <= 0) {
            totalRowCount = getTotalCount(excelDao, excelVO, baseMethod);
            LOGGER.debug("전체 엑셀 Row (totalRowCount) = {}", totalRowCount);
        }

        /**
         * local variable
         */
        // 지금까지 작업한 count
        int curTotalRow = 0;

        // 현재 Sheet에서 작업한 count
        int curSheetRow = 0;

        // Sheet명을 만들때 사용할 index
        int sheetIndex = 1;

        while (curTotalRow < totalRowCount) {
            /**
             * Set : Start / End Row
             */
            ReflectUtil.callMethod(excelVO, "setFirstRowIndex", (int)curTotalRow + 1);
            ReflectUtil.callMethod(excelVO, "setLastRowIndex",  (int)(curTotalRow + maxQueryCount));

            /**
             * Call List Query
             */
            @SuppressWarnings("unchecked")
            List<T> excelVOList = (List<T>)ReflectUtil.callMethod(excelDao, baseMethod + "List", excelVO);

            /**
             * Query Not Found
             */
            if (excelVOList == null || excelVOList.size() == 0) {
                break;
            }

            /**
             * Query한 Item으로 Excel Row을 만든다.
             */
            for (T item : excelVOList) {
                /**
                 * 최초 작업이거나, maxRowPerSheetCount 까지 작업을 하였다면 새로운 Sheet를 만든다.
                 */
                if (sheet == null || curSheetRow > maxRowPerSheetCount) {
                    /**
                     * Init Sheet Row
                     */
                    curSheetRow = 0;
                    /**
                     * Create Sheet
                     */
                    createSheet("SHEET_" + sheetIndex++);

                    /**
                     * merge를 구역을 설정한다.
                     */
                    exeHeaderMerge();

                    /**
                     * Create Header
                     */
                    for (int i = 0; i < headers.length; i++) {
                    	makeRow(curSheetRow++, headers[i], styleHeader);
                    }
                }

                /**
                 * Data Row 생성
                 */
                curTotalRow++;
                appendRow(curSheetRow++, item, bodyOrders, styleBody);
            }
            excelVOList.clear();
        }
    }

    /**
     * appendRow
     *
     * @param rowIndex
     * @param excelVO
     * @param bodyOrder void
     */
    public void appendRow(int rowIndex, T excelVO, String[] bodyOrder, CellStyle style) {
        String[] dataList = null;
        if (bodyOrder != null) {
            dataList = new String[bodyOrder.length];

            /**
             * bodyOrder순서에 따라 값을 읽어 data List를 만들어 낸다.
             */
            Object value = null;
            for(int idx = 0; idx < bodyOrder.length; idx++) {
                value = ReflectUtil.callMethod(excelVO, bodyOrder[idx]);
                if (value != null) {
                    dataList[idx] = value.toString();
                } else {
                    dataList[idx] = "";
                }
//                LOGGER.debug("value : " + dataList[idx]);
            }
        }

        /**
         * Row 생성
         */
        makeRow(rowIndex, dataList, style);
    }

    /**
     * createSheet
     *
     * @param name
     * @return Sheet
     */
    public Sheet createSheet(String name) {
        sheet = workbook.createSheet(name);
        return sheet;
    }

    /**
     * makeRow
     *
     * @param sheet
     * @param rowIndex
     * @param arrayData
     * @return Row
     */
    public Row makeRow(Sheet sheet, int rowIndex, String[] arrayData, CellStyle style) {
        this.sheet = sheet;
        return makeRow(rowIndex, arrayData, style);
    }

    /**
     * makeRow
     *
     * @param sheetName
     * @param rowIndex
     * @param arrayData
     * @return Row
     */
    public Row makeRow(String sheetName, int rowIndex, String[] arrayData, CellStyle style) {
        sheet = workbook.getSheet(sheetName);
        return makeRow(rowIndex, arrayData, style);
    }

    /**
     * makeRow
     *
     * @param sheetIndex
     * @param rowIndex
     * @param arrayData
     * @return Row
     */
    public Row makeRow(int sheetIndex, int rowIndex, String[] arrayData, CellStyle style) {
        sheet = workbook.getSheetAt(sheetIndex);
        return makeRow(rowIndex, arrayData, style);
    }

    /**
     * makeRow
     *
     * @param rowIndex
     * @param arrayData
     * @return
     * @throws TangoBizException Row
     */
    public Row makeRow(int rowIndex, String[] arrayData, CellStyle style) {
        /**
         * check sheet
         */
        if (sheet == null) {
            LOGGER.error("Sheet is null !!!");
            throw new NullPointerException();
        }

        /**
         * create Row
         */
        Row row = sheet.createRow(rowIndex);

        /**
         * Data가 없다면 row만 만들고 return 한다.
         */
        if (arrayData == null) {
            return row;
        }

        /**
         * 첫번째 Row라면...
         */
        if (rowIndex == 0) {
            for(int i = 0; i < arrayData.length; i++) {
                LOGGER.debug("columnWidth : " + columnWidth);
                sheet.setColumnWidth((short)i, columnWidth);
            }
        }

        /**
         * Data를 가지고 Cell 생성
         */
        for (int idx = 0; idx < arrayData.length; idx++) {
            Cell cell = row.createCell(idx);
            cell.setCellValue(arrayData[idx]);

            // header bgColor 설정
        	if(rowIndex < headerRowCount) cell.setCellStyle(getHeaderStyle(new int[] {rowIndex,idx}, style));
            else                          cell.setCellStyle(style);
        }

        return row;
    }

    /**
     * write
     *
     * @param fileFullPath void
     * @throws IOException
     */
    @Override
    public void write(String fileFullPath) throws FileNotFoundException, IOException {
        try (FileOutputStream fileOutputStream = new FileOutputStream(fileFullPath)) {
            workbook.write(fileOutputStream);
        } catch (FileNotFoundException e) {
            LOGGER.error(CoreErrorUtils.getStackTrace(e));
            throw new FileNotFoundException();
        } catch (IOException e) {
            LOGGER.error(CoreErrorUtils.getStackTrace(e));
            throw new IOException(e);
        }
    }

    /**
     * closeExcel
     *   void
     * @throws IOException
     */
    @Override
    public void closeExcel() throws IOException {
        if (workbook != null) {
            try {
            } catch (Exception e) {
                LOGGER.debug("ExcelExHandler.closeExcel() : dummy");
            } finally {
                try {
                    //workbook.close();
                	boolean bol = false;
                	int i = 0;
                	while (!bol && i < 3) {
                		bol = workbook.dispose();
                		i++;
                	}
                } catch (Exception e) {
                    LOGGER.error(CoreErrorUtils.getStackTrace(e));
                    throw new IOException(e);
                }
            }
        }
    }

    /**
     * getter method for workbook
     * @return the workbook
     */
    public SXSSFWorkbook getWorkbook() {
        return workbook;
    }

    /**
     * setter method for workbook
     * @param workbook the workbook to set
     */
    public void setWorkbook(SXSSFWorkbook workbook) {
        this.workbook = workbook;
    }

    /**
     * getter method for sheet
     * @return the sheet
     */
    public Sheet getSheet() {
        return sheet;
    }

    /**
     * setter method for sheet
     * @param sheet the sheet to set
     */
    public void setSheet(Sheet sheet) {
        this.sheet = sheet;
    }

    /**
     * getter method for styleHeader
     * @return the styleHeader
     */
    public CellStyle getStyleHeader() {
        return styleHeader;
    }

    /**
     * setter method for styleHeader
     * @param styleHeader the styleHeader to set
     */
    public void setStyleHeader(CellStyle styleHeader) {
        this.styleHeader = styleHeader;
    }

    /**
     * getter method for styleBody
     * @return the styleBody
     */
    public CellStyle getStyleBody() {
        return styleBody;
    }

    /**
     * setter method for styleBody
     * @param styleBody the styleBody to set
     */
    public void setStyleBody(CellStyle styleBody) {
        this.styleBody = styleBody;
    }

    /**
     * getter method for headerColor
     * @return the headerColor
     */
    public short getHeaderColor() {
        return headerColor;
    }

    /**
     * setter method for headerColor
     * @param headerColor the headerColor to set
     */
    public void setHeaderColor(short headerColor) {
        this.headerColor = headerColor;
    }

    /**
     * getter method for columnWidth
     * @return the columnWidth
     */
    public short getColumnWidth() {
        return columnWidth;
    }

    /**
     * setter method for columnWidth
     * @param columnWidth the columnWidth to set
     */
    public void setColumnWidth(short columnWidth) {
        this.columnWidth = columnWidth;
    }
}