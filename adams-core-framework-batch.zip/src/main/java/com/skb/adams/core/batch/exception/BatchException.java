/**
 * Copyright (c) 2018 SK Broadband.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with SK Broadband.
 */
package com.skb.adams.core.batch.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.skb.adams.core.batch.common.constants.BatchConstants.BATCH_EXCEPTION;

/**
 * <ul>
 * <li>업무 그룹명 : adams-core-framework-batch</li>
 * <li>서브 업무명 : com.skb.adams.core.batch.exception</li>
 * <li>설  명 : BatchException.java</li>
 * <li>작성일 : 2018. 2. 15.</li>
 * <li>작성자 : Ko Kyoung Hak (AA)</li>
 * </ul>
 */
public class BatchException extends Exception {
	/**
	 * serialVersionUID
	 */
    private static final long serialVersionUID = 5824480207141404073L;

    /**
     * LOGGER
     */
    protected static final Logger LOGGER = LoggerFactory.getLogger(BatchException.class);

    /**
     * module
     */
	private String module = "";
    /**
     * exceptionCode
     */
    private int exceptionCode = 0;
    /**
     * exceptionMessage
     */
    private String exceptionMessage = "";

    /**
     *
     * BatchException
     * @param cause
     */
	public BatchException(Throwable cause) {
		super(cause);
		setValues(null, BATCH_EXCEPTION.UNCLASSIFIED_EXCEPTION);
	}

	/**
	 *
	 * BatchException
	 * @param message
	 */
	public BatchException(String message) {
	    super(message);
        setValues(null, BATCH_EXCEPTION.UNCLASSIFIED_EXCEPTION.getExceptionCode(), message);
	}

	/**
	 *
	 * BatchException
	 * @param cause
	 * @param message
	 */
    public BatchException(Throwable cause, String message) {
        super(message, cause);
        setValues(null, BATCH_EXCEPTION.UNCLASSIFIED_EXCEPTION.getExceptionCode(), message);
    }

    /**
     *
     * BatchException
     * @param module
     * @param cause
     */
    public BatchException(String module, Throwable cause) {
        super(cause);
        setValues(module, BATCH_EXCEPTION.CLASSIFIED_EXCEPTION);
    }

    /**
     *
     * BatchException
     * @param module
     * @param code
     * @param cause
     */
    public BatchException(String module, int code, Throwable cause) {
        super(cause);
        setValues(module, code, null);
    }

    /**
     *
     * BatchException
     * @param module
     * @param code
     * @param message
     * @param cause
     */
    public BatchException(String module, int code, String message, Throwable cause) {
        super(message, cause);
        setValues(module, code, message);
    }

    /**
     *
     * setValues
     *
     * @param module
     * @param batchException void
     */
    private void setValues(String module, BATCH_EXCEPTION batchException) {
        setValues(module, batchException.getExceptionCode(), batchException.getExceptionMessage());
    }

    /**
     *
     * setValues
     *
     * @param module
     * @param code
     * @param message void
     */
    private void setValues(String module, int code, String message) {
        this.module           = module;
        this.exceptionCode    = code;
        this.exceptionMessage = message;

        LOGGER.error(String.format("\nModule: %s\nExceptionCode : %d\nExceptionMessage : %s", this.module,
                                                                                              this.exceptionCode,
                                                                                              this.exceptionMessage), super.getCause());
    }

    /**
     *
     * getModule
     *
     * @return String
     */
    public String getModule() {
        return module;
    }

    /**
     *
     * getExceptionCode
     *
     * @return int
     */
    public int getExceptionCode() {
        return exceptionCode;
    }

    /**
     *
     * getExceptionMessage
     *
     * @return String
     */
    public String getExceptionMessage() {
        return exceptionMessage;
    }
}