/*
 * Copyright (c) 2018 SK Broadband.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with SK Broadband.
 */
package com.skb.adams.core.batch.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.skb.adams.core.batch.common.constants.BatchConstants;
import com.skb.adams.core.batch.config.BaseBatchConfig;

/**
 * <ul>
 * <li>업무 그룹명 : adams-core-framework-batch</li>
 * <li>서브 업무명 : com.skb.adams.core.batch.config</li>
 * <li>설 명 : BatchConfig.java</li>
 * <li>작성일 : 2018. 2. 14.</li>
 * <li>작성자 : Ko Kyoung Hak (AA)</li>
 * </ul>
 */
@Configuration
public class BatchConfig extends BaseBatchConfig {

    /**
     * runTaskJobName : 현재 실행중인 Batch Job Task명 설정
     */
    protected String runTaskJobName = "";

    protected boolean chgJobParams = false;

	/**
	 * Batch Scheduler IP
	 */
	@Value("${batch.agent.udp.ip}")
	private String agentUdpIp = "";

	/**
	 * Batch Scheduler Port
	 */
	@Value("${batch.agent.udp.port}")
	private int agentUdpPort = 8888;

	/**
	 * agentInputFile
	 */
	// @Value("${batch.agent.local.input}")
	private String agentInputFile = "";
	/**
	 * agentOutputFile
	 */
	// @Value("${batch.agent.local.output}")
	private String agentOutputFile = "";

	/**
	 * loadConfig
	 *   void
	 */
	public void loadConfig() {
		/**
		 * 환경변수에서 Parmaeter 정보 추출
		 * Local에서 실행할 경우, nexcore.properties에서 값을 읽어 이미 설정된 상태임
		 */
		if (agentLocal) {
			// agentInputFile  = new File(agentInputFile ).getAbsolutePath();
			// agentOutputFile = new File(agentOutputFile).getAbsolutePath();
		} else {
			agentInputFile  = System.getenv(BatchConstants.BATCH_PARAM_FILE_PATH_IN);
			agentOutputFile = System.getenv(BatchConstants.BATCH_PARAM_FILE_PATH_OUT);
		}
	}

	/**
	 * getter method for agentUdpIp
	 *
	 * @return the agentUdpIp
	 */
	public String getAgentUdpIp() {
		return agentUdpIp;
	}

	/**
	 * setter method for agentUdpIp
	 *
	 * @param agentUdpIp
	 *            the agentUdpIp to set
	 */
	public void setAgentUdpIp(String agentUdpIp) {
		this.agentUdpIp = agentUdpIp;
	}

	/**
	 * getter method for agentUdpPort
	 *
	 * @return the agentUdpPort
	 */
	public int getAgentUdpPort() {
		return agentUdpPort;
	}

	/**
	 * setter method for agentUdpPort
	 *
	 * @param agentUdpPort
	 *            the agentUdpPort to set
	 */
	public void setAgentUdpPort(int agentUdpPort) {
		this.agentUdpPort = agentUdpPort;
	}

	/**
	 * getter method for agentInputFile
	 *
	 * @return the agentInputFile
	 */
	public String getAgentInputFile() {
		return agentInputFile;
	}

	/**
	 * setter method for agentInputFile
	 *
	 * @param agentInputFile
	 *            the agentInputFile to set
	 */
	public void setAgentInputFile(String agentInputFile) {
		this.agentInputFile = agentInputFile;
	}

	/**
	 * getter method for agentOutputFile
	 *
	 * @return the agentOutputFile
	 */
	public String getAgentOutputFile() {
		return agentOutputFile;
	}

	/**
	 * setter method for agentOutputFile
	 *
	 * @param agentOutputFile
	 *            the agentOutputFile to set
	 */
	public void setAgentOutputFile(String agentOutputFile) {
		this.agentOutputFile = agentOutputFile;
	}

    /**
     * getter method for runTaskJobName
     * @return the runTaskJobName
     */
    public String getRunTaskJobName() {
        return runTaskJobName;
    }

    /**
     * setter method for runTaskJobName
     * @param runTaskJobName the runTaskJobName to set
     */
    public void setRunTaskJobName(String runTaskJobName) {
        this.runTaskJobName = runTaskJobName;
    }

    /**
     * getter method for chgJobParams
     * @return the chgJobParams
     */
    public boolean isChgJobParams() {
        return chgJobParams;
    }

    /**
     * setter method for chgJobParams
     * @param chgJobParams the chgJobParams to set
     */
    public void setChgJobParams(boolean chgJobParams) {
        this.chgJobParams = chgJobParams;
    }

}
