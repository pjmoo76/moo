/**
 * Copyright (c) 2018 SK Broadband.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with SK Broadband.
 */
package com.skb.adams.core.batch.common.utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

import org.codehaus.plexus.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.skb.adams.core.batch.common.constants.BatchConstants;
import com.skb.adams.core.batch.config.BatchConfig;
import com.skb.adams.core.batch.exception.BatchException;
import com.skb.adams.core.batch.model.JobExecutionResult;
import com.skb.adams.core.constant.LineConstants;
import com.skb.adams.core.utils.CoreErrorUtils;
import com.skb.adams.core.utils.CoreTimeUtils;

/**
 * <ul>
 * <li>업무 그룹명 : adams-core-framework-batch</li>
 * <li>서브 업무명 : com.skb.adams.core.batch.common.utils</li>
 * <li>설  명 : NexcoreSupport.java</li>
 * <li>작성일 : 2018. 7. 7.</li>
 * <li>작성자 : Ko Kyoung Hak (AA)</li>
 * </ul>
 */
public class NexcoreSupport {
	/**
	 * LOGGER
	 */
	protected static final Logger LOGGER = LoggerFactory.getLogger(NexcoreSupport.class);

	/**
	 *
	 * readExecutionJob
	 *
	 * @param inFileLocation
	 * @return
	 * @throws IOException
	 * @throws BatchException String
	 */
    public static String readExecutionJob(BatchConfig batchConfig) throws IOException, BatchException {

        // NBS 입력 파라미터 설정
        ConcurrentHashMap<String, String> argsMap = readJobArguments(batchConfig);

        return argsMap.get(BatchConstants.BATCH_PARAM_EXEC_JOB_NAME);
    }

    /**
     *
     * readJobArguments
     *
     * @param inFileLocation
     * @return
     * @throws IOException
     * @throws BatchException ConcurrentHashMap<String,String>
     */
    public static ConcurrentHashMap<String, String> readJobArguments(BatchConfig batchConfig) throws IOException, BatchException {

        ConcurrentHashMap<String, String> argsMap = new ConcurrentHashMap<String, String>();

        String lineString = null;
        String inFileLocation = batchConfig.getAgentInputFile();

        if (StringUtils.isNotEmpty(inFileLocation)) {
        	inFileLocation = inFileLocation.replace(LineConstants.DOUBLE_BACKSLASH, LineConstants.SLASH);
        }

        // NBS 배치 파라미터 보관
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(inFileLocation))) {

            // Local 실행 및 NBS 파라미터 동적 변경시, JOB_ID, JOB_INS_ID, JOB_EXE_ID 항목 변경
            if (batchConfig.isAgentLocal() && batchConfig.isChgJobParams()) {

                // 현재 Batch Job 정보
                String jobId    = batchConfig.getRunTaskJobName();
                String jobInsId = jobId    + LineConstants.HYPHEN + CoreTimeUtils.getDateTime("yyyyMMddHHmmss.SSS" + "-0001");
                String jobExeId = jobInsId + "-000001";

                while ((lineString = bufferedReader.readLine()) != null) {

                    String[] argArray = lineString.split(LineConstants.EQUAL);

                    if (argArray.length == 2) {
                        switch (argArray[0]) {
                          case BatchConstants.BATCH_PARAM_JOB_ID           : argsMap.put(argArray[0], jobId);      break;
                          case BatchConstants.BATCH_PARAM_JOB_INSTANCE_ID  : argsMap.put(argArray[0], jobInsId);   break;
                          case BatchConstants.BATCH_PARAM_JOB_EXECUTION_ID : argsMap.put(argArray[0], jobExeId);   break;
                       default : argsMap.put(argArray[0], argArray[1]); break;
                        }
                    }
                }
            } else {
                while ((lineString = bufferedReader.readLine()) != null) {
                    String[] argArray = lineString.split(LineConstants.EQUAL);
                    if (argArray.length == 2) {
                        argsMap.put(argArray[0], argArray[1]);
                    }
                }
            }
        } catch(Exception e) {
    		LOGGER.error(CoreErrorUtils.getStackTrace(e));
        }
        return argsMap;
    }

    /**
     *
     * writeJobResult
     *
     * @param outFileLocation
     * @param nexcoreResult
     * @throws IOException
     * @throws BatchException void
     */
    public static void writeJobResult(String outFileLocation, JobExecutionResult nexcoreResult) throws IOException, BatchException {

        if (StringUtils.isNotEmpty(outFileLocation)) {
        	outFileLocation = outFileLocation.replace(LineConstants.DOUBLE_BACKSLASH, LineConstants.SLASH);
        }

        try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(outFileLocation))) {
        	String strFormat = nexcoreResult.formatResult();

        	// 외부 입력 값을 다시 출력할 때 위험 문자열을 제거한 후 사용
        	strFormat = strFormat.replace("oldChar===============================", "newChar===============================");
            bufferedWriter.write(strFormat);
        } catch(Exception e) {
    		LOGGER.error(CoreErrorUtils.getStackTrace(e));
        }
    }
}
