/*
 * Copyright (c) 2018 SK Broadband.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with SK Broadband.
 */
package com.skb.adams.core.batch.model;

import com.skb.adams.core.constant.LineConstants;
import com.skb.adams.core.model.BaseObject;
import com.skb.adams.core.utils.CoreCommUtils;

/**
 * <ul>
 * <li>업무 그룹명 : adams-core-framework-batch</li>
 * <li>서브 업무명 : com.skb.adams.core.batch.model</li>
 * <li>설  명 : JobExecutionResult.java</li>
 * <li>작성일 : 2018. 2. 15.</li>
 * <li>작성자 : Ko Kyoung Hak (AA)</li>
 * </ul>
 */
public class JobExecutionResult extends BaseObject {

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 2221331699808466123L;

    /**
     * returnCode
     */
    private String returnCode = LineConstants.EMPTY;

    /**
     * progressTotal
     */
    private int progressTotal = 0;

    /**
     * progressCurrent
     */
    private int progressCurrent = 0;

    /**
     * returnMessage
     */
    private String returnMessage = LineConstants.EMPTY;

    /**
     * module
     */
    private String module = LineConstants.EMPTY;

    /**
     * executedJob
     */
    private String executedJob = LineConstants.EMPTY;

    /**
     * cause
     */
    private String cause = LineConstants.EMPTY;

    /**
     * returnVal : 후행 Job 파라미터 설정에서 사용할 선행 Job의 Return value 변수
     *             후행 Job 파라미터 설정 : ${!GETRETVAL ETL_OCO20100_TO_FILE RETURN_VAL}
     */
    private String returnVal = LineConstants.EMPTY;

    /**
     *
     * formatResult
     *
     * @return String
     */
    public String formatResult() {
    	StringBuffer formatBuffer = new StringBuffer();

    	// 후행 Job 파라미터 설정시, ${!GETRETVAL 선행JOB-ID KeyName}을 사용하여 선행 Job 실행결과 추출 가능 항목
        formatBuffer.append(CoreCommUtils.formatKeyValue("EXECUTED_JOB",     executedJob    )).append("\n");
        formatBuffer.append(CoreCommUtils.formatKeyValue("MODULE",           module         )).append("\n");
        formatBuffer.append(CoreCommUtils.formatKeyValue("CAUSE",            cause          )).append("\n");
        formatBuffer.append(CoreCommUtils.formatKeyValue("RETURN_VAL",       returnVal      )).append("\n");

        // 후행 Job 파라미터 설정시, ${!GETRETVAL 선행JOB-ID KeyName}을 사용하여 선행 Job 실행결과 추출 불가 항목
    	formatBuffer.append(CoreCommUtils.formatKeyValue("RETURN_CODE",      returnCode     )).append("\n");
    	formatBuffer.append(CoreCommUtils.formatKeyValue("RETURN_MESSAGE",   returnMessage  )).append("\n");
        formatBuffer.append(CoreCommUtils.formatKeyValue("PROGRESS_TOTAL",   progressTotal  )).append("\n");
        formatBuffer.append(CoreCommUtils.formatKeyValue("PROGRESS_CURRENT", progressCurrent)).append("\n");

    	return formatBuffer.toString();
    }

	/**
	 * getter method for returnCode
	 * @return the returnCode
	 */
	public String getReturnCode() {
		return returnCode;
	}

	/**
	 * setter method for returnCode
	 * @param returnCode the returnCode to set
	 */
	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	/**
	 * getter method for progressTotal
	 * @return the progressTotal
	 */
	public int getProgressTotal() {
		return progressTotal;
	}

	/**
	 * setter method for progressTotal
	 * @param progressTotal the progressTotal to set
	 */
	public void setProgressTotal(int progressTotal) {
		this.progressTotal = progressTotal;
	}

	/**
	 * getter method for progressCurrent
	 * @return the progressCurrent
	 */
	public int getProgressCurrent() {
		return progressCurrent;
	}

	/**
	 * setter method for progressCurrent
	 * @param progressCurrent the progressCurrent to set
	 */
	public void setProgressCurrent(int progressCurrent) {
		this.progressCurrent = progressCurrent;
	}

	/**
	 * getter method for returnMessage
	 * @return the returnMessage
	 */
	public String getReturnMessage() {
		return returnMessage;
	}

	/**
	 * setter method for returnMessage
	 * @param returnMessage the returnMessage to set
	 */
	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}

	/**
	 * getter method for module
	 * @return the module
	 */
	public String getModule() {
		return module;
	}

	/**
	 * setter method for module
	 * @param module the module to set
	 */
	public void setModule(String module) {
		this.module = module;
	}

	/**
	 * getter method for executedJob
	 * @return the executedJob
	 */
	public String getExecutedJob() {
		return executedJob;
	}

	/**
	 * setter method for executedJob
	 * @param executedJob the executedJob to set
	 */
	public void setExecutedJob(String executedJob) {
		this.executedJob = executedJob;
	}

	/**
	 * getter method for cause
	 * @return the cause
	 */
	public String getCause() {
		return cause;
	}

	/**
	 * setter method for cause
	 * @param cause the cause to set
	 */
	public void setCause(String cause) {
		this.cause = cause;
	}

    /**
     * getter method for returnVal
     * @return the returnVal
     */
    public String getReturnVal() {
        return returnVal;
    }

    /**
     * setter method for returnVal
     * @param returnVal the returnVal to set
     */
    public void setReturnVal(String returnVal) {
        this.returnVal = returnVal;
    }

}
