/*
 * Copyright (c) 2018 SK Broadband.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with SK Broadband.
 */
package com.skb.adams.core.batch.config;

import java.io.IOException;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import com.skb.adams.core.batch.common.constants.BatchConstants;
import com.skb.adams.core.batch.common.utils.NexcoreSupport;
import com.skb.adams.core.batch.exception.BatchException;
import com.skb.adams.core.batch.jobs.BaseJob;
import com.skb.adams.core.batch.model.JobExecutionResult;

/**
 * <ul>
 * <li>업무 그룹명 : adams-core-framework-batch</li>
 * <li>서브 업무명 : com.skb.adams.core.batch.config</li>
 * <li>설  명 : AspectConfig.java</li>
 * <li>작성일 : 2018. 2. 14.</li>
 * <li>작성자 : Ko Kyoung Hak (AA)</li>
 * </ul>
 */
@Aspect
@EnableAspectJAutoProxy
//@ImportResource("classpath:spring/config/TxAdviceNotUsed.xml")
public class AspectConfig {
	/**
	 * LOGGER
	 */
	protected static final Logger LOGGER = LoggerFactory.getLogger(AspectConfig.class);

	/**
	 * doProcess() 수행시, NBS가 설정하는 파라미터 Argument를 읽어 Service Class가 사용 할 수 있도록 설정
	 *
	 * @param jp void
	 * @throws BatchException
	 */
	@Before("execution(public * doProcess(..))")
	public void beforeExecution(JoinPoint jp) throws BatchException	{

		BaseJob baseJob = null;
		if (jp.getTarget() instanceof BaseJob) {
			baseJob = ((BaseJob)jp.getTarget());
		}

        // 시스템 환경변수 출력
//        for (Iterator<Entry<String, String>> iterator = System.getenv().entrySet().iterator(); iterator.hasNext();) {
//            Entry<String, String> entry = iterator.next();
//            LOGGER.debug(entry.getKey() + "=" + entry.getValue());
//        }

	    ConcurrentHashMap<String, String> sourceMap = null;
        try {
            // NBS 입력 파라미터 설정
            sourceMap = NexcoreSupport.readJobArguments(baseJob.getBatchConfig());
        } catch (IOException e) {
            throw new BatchException(e.getCause());
        }

        // 사전처리 : Parameter File로부터 읽은 Arguments를 Service Class에 설정 및 Batch Agent 초기화
        baseJob.preProcess(Collections.unmodifiableMap(sourceMap));
        baseJob.beforeProcess();

		StringBuilder stringBuilder = new StringBuilder(String.format("\n[CORE-BATCH] Arguments loading for job[%s]\n", jp.getTarget().getClass().getSimpleName()));

		Iterator<String> argumentIterator = sourceMap.keySet().iterator();
		while (argumentIterator.hasNext()) {
			String key = argumentIterator.next();
			stringBuilder.append(String.format("NBS Parameter[%s] = [%s]\n", key, sourceMap.get(key)));
		}
		stringBuilder.append(String.format("[CORE-BATCH] %s:%s will start !", baseJob.getClass().getSimpleName(), jp.getSignature().getName()));

		LOGGER.debug(stringBuilder.toString());
	}

	/**
	 * doProcess() 실행후, 실행 결과를 Scheduler가 확인할 수 있도록 File에 저장
	 *
	 * @param jp
	 * @param result void
	 * @throws BatchException
	 */
	@AfterReturning(pointcut = "execution(public * doProcess(..))", returning = "result")
	public void afterReturningExecution(JoinPoint jp, Object result) throws BatchException {
		BaseJob baseJob = null;
	    try {
	    	JobExecutionResult jobExecutionResult = null;
	    	if (result instanceof JobExecutionResult) {
	    		jobExecutionResult = (JobExecutionResult)result;
	    	}

			if(jp.getTarget() instanceof BaseJob) {
				baseJob = ((BaseJob)jp.getTarget());
			}

			// Batch 수행결과를 Output File에 출력
            NexcoreSupport.writeJobResult(baseJob.getBatchConfig().getAgentOutputFile(), jobExecutionResult);

            // 사후처리 : Disconnect Batch Agent Client
            baseJob.postProcess();
        } catch (IOException e) {
            throw new BatchException(e.getCause());
        }

		StringBuilder stringBuilder = new StringBuilder(String.format(String.format("\n[CORE-BATCH] %s:%s finished !\n", jp.getTarget().getClass().getSimpleName(), jp.getSignature().getName())));
		stringBuilder.append(String.format("[CORE-BATCH-RESULT]\n%s\n", result));
		stringBuilder.append(String.format("[CORE-BATCH] %s Ended(Elasped Time: %dms)", baseJob.getClass().getSimpleName(), new Date().getTime() - baseJob.getStartTime()));

		LOGGER.debug(stringBuilder.toString());
	}

	/**
	 * doProcess() 실행중, 오류 처리
	 *
	 * @param jp
	 * @param ex void
	 * @throws BatchException
	 */
	@AfterThrowing(pointcut = "execution(public * doProcess(..))", throwing = "ex")
	public void afterThrowingExecution(JoinPoint jp, BatchException ex) throws BatchException {

	    // 오류 발생시, Result File에 결과 기록
	    JobExecutionResult jobExecutionResult = new JobExecutionResult();

	    jobExecutionResult.setReturnCode(String.valueOf(ex.getExceptionCode()));
	    jobExecutionResult.setReturnMessage(ex.getExceptionMessage());
	    jobExecutionResult.setModule(ex.getModule());

		BaseJob baseJob = null;
		try {
    		if(jp.getTarget() instanceof BaseJob) {
    			baseJob = ((BaseJob)jp.getTarget());
    		}

    		// 오류 처리 : Disconnect Batch Agent Client
            baseJob.onError();

            // Error정보를 Output 파일에 Write 처리
            NexcoreSupport.writeJobResult(baseJob.getBatchConfig().getAgentOutputFile(), jobExecutionResult);

            StringBuilder stringBuilder = new StringBuilder(String.format(String.format("\n[CORE-BATCH] %s:%s occur exception !\n", jp.getTarget().getClass().getSimpleName(), jp.getSignature().getName())));
            stringBuilder.append(String.format("Exception is [%s]\n", ex.getMessage()));
            stringBuilder.append(String.format("[CORE-BATCH] %s Ended(Elasped Time: %dms)", baseJob.getClass().getSimpleName(), new Date().getTime() - baseJob.getStartTime()));

            LOGGER.debug(stringBuilder.toString());
        } catch (IOException e) {
            //LOGGER.error(String.format("\nNexcore result writhing failed.\nFile name: [%s]\nJob Result: [%s]", AdamsBatchConstants.NEXCORE_TESTFILE_OUT, jobExecutionResult), e.getCause());
            LOGGER.error(String.format("\n[CORE-BATCH] Nexcore result writhing failed. !\nFile name : [%s]\nJob Result : [%s]", System.getenv(BatchConstants.BATCH_PARAM_FILE_PATH_OUT), jobExecutionResult), e.getCause());
        }
	}

	/**
	 * afterExecution
	 *
	 * @param jp void
	 */
//	@After("execution(public * doProcess(..))")
//		public void afterExecution(JoinPoint jp) {
//			LOGGER.debug("After method : {}. Class : {}", jp.getSignature().getName(), jp.getTarget().getClass().getSimpleName());
//	}

	/**
	 * aroundExecution
	 *
	 * @param jp
	 * @return
	 * @throws Exception Object
	 */
//	@Around("execution(public * doProcess(..))")
//	public Object aroundExecution(ProceedingJoinPoint jp) throws Exception {
//
//		LOGGER.debug("Around-Before method : {}. Class : {}", jp.getSignature().getName(), jp.getTarget().getClass().getSimpleName());
//
//		try {
//			Object result = jp.proceed();
//
//			LOGGER.debug("Around-Returning : {}", result);
//			return result;
//		} catch (Throwable e) {
//			LOGGER.error(CoreErrorUtils.getStackTrace(e));
//			throw new Exception("Error", e);
//		}
//	}
}
