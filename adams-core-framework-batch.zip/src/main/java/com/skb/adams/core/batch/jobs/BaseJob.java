/*
 * Copyright (c) 2018 SK Broadband.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of SK Broadband.
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with SK Broadband.
 */
package com.skb.adams.core.batch.jobs;

import java.io.IOException;
import java.util.Date;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.skb.adams.core.batch.agent.BatchAgentClient;
import com.skb.adams.core.batch.common.constants.BatchConstants;
import com.skb.adams.core.batch.config.BatchConfig;
import com.skb.adams.core.batch.model.JobExecutionResult;
import com.skb.adams.core.constant.LineConstants;
import com.skb.adams.core.utils.CoreErrorUtils;

/**
 * <ul>
 * <li>업무 그룹명 : adams-core-framework-batch</li>
 * <li>서브 업무명 : com.skb.adams.core.batch.jobs</li>
 * <li>설  명 : BaseJob.java</li>
 * <li>작성일 : 2018. 7. 7.</li>
 * <li>작성자 : Ko Kyoung Hak (AA)</li>
 * </ul>
 */
public abstract class BaseJob {

    protected static final Logger LOGGER = LoggerFactory.getLogger(BaseJob.class);

	/**
	 * startTime 소요 시간 연산을 위해 설정
	 */
	private final long startTime = new Date().getTime();

	/**
	 * Module Name
	 */
    @Value("${project.module}")
    protected String moduleName = "";

	/**
	 * Batch Config
	 */
	@Autowired
	protected BatchConfig batchConfig = null;

	/**
	 * Batch Agent Instance
	 */
    protected BatchAgentClient batchAgentClient = null;

    /**
     * Job Result
     */
    protected JobExecutionResult jobExecutionResult = null;

	/**
	 * progressTotal
	 */
    private int progressTotal = 0;

    /**
     * progressCurrent
     */
    private int progressCurrent = 0;

    /**
     * jobId
     */
    protected String jobId = "";

    /**
     * jobInstanceId
     */
    protected String jobInstanceId = "";

    /**
     * jobExecutionId
     */
    protected String jobExecutionId = "";

    /**
     * JobProgressReport
     */
//    @Autowired
//    protected JobProgressReport jobProgressReport = null;

	/**
	 * argumentMap : NBS가 설정하는 Batch Job 실행 파라미터
	 */
	protected Map<String, String> nbsArgumentMap = null;

	/**
	 * preProcess
	 *
	 * @param sourceMap void
	 */
	public void preProcess(Map<String, String> sourceMap) {

		// NBS 호출 파라미터 Map 설정
	    nbsArgumentMap = sourceMap;

		// NBS 파라미터 일부 항목 조회 및 설정
		this.jobId          = sourceMap.get(BatchConstants.BATCH_PARAM_JOB_ID);
		this.jobInstanceId  = sourceMap.get(BatchConstants.BATCH_PARAM_JOB_INSTANCE_ID);
		this.jobExecutionId = sourceMap.get(BatchConstants.BATCH_PARAM_JOB_EXECUTION_ID);

        // NBS Agent Information
		LOGGER.debug("[CORE-BATCH] ====================================================================================");
		LOGGER.debug("[CORE-BATCH] preProcess() - Start");
		LOGGER.debug("[CORE-BATCH] ====================================================================================");
		LOGGER.debug("[CORE-BATCH] batchConfig.isAgentLocal()          : {}", batchConfig.isAgentLocal());
        LOGGER.debug("[CORE-BATCH] batchConfig.getSchedulerIp()        : {}", batchConfig.getSchedulerIp());
        LOGGER.debug("[CORE-BATCH] batchConfig.getSchedulerPort(()     : {}", batchConfig.getSchedulerPort() + LineConstants.EMPTY);
        LOGGER.debug("[CORE-BATCH] batchConfig.getSchedulerIpBack()    : {}", batchConfig.getSchedulerIpBack());
        LOGGER.debug("[CORE-BATCH] batchConfig.getSchedulerPortBack(() : {}", batchConfig.getSchedulerPortBack() + LineConstants.EMPTY);
        LOGGER.debug("[CORE-BATCH] batchConfig.getAgentUdpIp()         : {}", batchConfig.getAgentUdpIp());
        LOGGER.debug("[CORE-BATCH] batchConfig.getAgentUdpPort(()      : {}", batchConfig.getAgentUdpPort() + LineConstants.EMPTY);

        LOGGER.debug("[CORE-BATCH] jobId          : {}", this.jobId);
        LOGGER.debug("[CORE-BATCH] jobInstanceId  : {}", this.jobInstanceId);
        LOGGER.debug("[CORE-BATCH] jobExecutionId : {}", this.jobExecutionId);

    	LOGGER.debug("[CORE-BATCH] batchConfig.getAgentInputFile()  : {}", batchConfig.getAgentInputFile());
    	LOGGER.debug("[CORE-BATCH] batchConfig.getAgentOutputFile() : {}", batchConfig.getAgentOutputFile());
		LOGGER.debug("====================================================================================");

		// Batch Agent Client 생성 및 연결
		batchAgentClient = new BatchAgentClient(batchConfig.getAgentUdpIp(), batchConfig.getAgentUdpPort());
		batchAgentClient.connectAgentClient();

        LOGGER.debug("[CORE-BATCH] preProcess() - End");
		LOGGER.debug("[CORE-BATCH] ====================================================================================");
	}

	/**
	 * beforeProcess
	 *   void
	 */
	public void beforeProcess()	{
		LOGGER.debug("[CORE-BATCH] ====================================================================================");
		LOGGER.debug("[CORE-BATCH] beforeProcess() - Start");
		LOGGER.debug("[CORE-BATCH] ====================================================================================");

		if (jobExecutionResult == null) {
			jobExecutionResult = new JobExecutionResult();
		}

		LOGGER.debug("[CORE-BATCH] beforeProcess() - End");
		LOGGER.debug("[CORE-BATCH] ====================================================================================");
	}

	/**
	 * postProcess
	 *   void
	 */
	public void postProcess() {
		LOGGER.debug("[CORE-BATCH] ====================================================================================");
		LOGGER.debug("[CORE-BATCH] postPorcess() - Start");
		LOGGER.debug("[CORE-BATCH] ====================================================================================");

		batchAgentClient.disconnectAgentClient();

		LOGGER.debug("[CORE-BATCH] postPorcess() - End");
		LOGGER.debug("[CORE-BATCH] ====================================================================================");
	}

	/**
	 * onError : 오류처리
	 *   void
	 */
	public void onError() {
		LOGGER.debug("[CORE-BATCH] ====================================================================================");
		LOGGER.debug("[CORE-BATCH] onError() - Start");
		LOGGER.debug("[CORE-BATCH] ====================================================================================");

		this.postProcess();

		LOGGER.debug("[CORE-BATCH] onError() - End");
		LOGGER.debug("[CORE-BATCH] ====================================================================================");
	}

	/**
	 *
	 * setSuccessMessage
	 *
	 * @param resultCode
	 * @param resultMessage void
	 */
	public void setSuccessMessage(String resultCode, String resultMessage) {
        // Batch 공통 설정
        jobExecutionResult.setModule(moduleName);

        jobExecutionResult.setReturnCode   (resultCode);
        jobExecutionResult.setReturnMessage(resultMessage);

        jobExecutionResult.setExecutedJob(getClass().getSimpleName());
	}

	/**
	 *
	 * sendBatchStatus : Batch 처리상태 전송
	 *
	 * @param progressCurrent void
	 */
	public void sendBatchStatus(int progressCurrent) {
		LOGGER.debug("[CORE-BATCH] ====================================================================================");
		LOGGER.debug("[CORE-BATCH] sendBatchStatus() - Start");
		LOGGER.debug("[CORE-BATCH] ====================================================================================");

		setProgressCurrent(progressCurrent);
		jobExecutionResult.setProgressCurrent(progressCurrent);

		LOGGER.debug("[CORE-BATCH] progressTotal   : {}", this.progressTotal);
		LOGGER.debug("[CORE-BATCH] progressCurrent : {}", this.progressCurrent);

		LOGGER.debug("[CORE-BATCH] ====================================================================================");

		try {
		    // Server 환경 수행시, Batch 처리상태 전송
			if (!batchConfig.isAgentLocal()) {
			    String jobExecutionId = this.jobExecutionId == null? LineConstants.EMPTY : this.jobExecutionId;

				batchAgentClient.sendBatchStatus(jobExecutionId, progressTotal, progressCurrent);
				LOGGER.info("[CORE-BATCH] sendBatchStatus is completed ! [progressTotal : {}][progressCurrent : {}]", progressTotal, progressCurrent);
			}
		} catch (IOException e) {
			LOGGER.error(CoreErrorUtils.getStackTrace(e));
		}

		LOGGER.debug("===============[CORE-BATCH] jobExecutionId()		"+jobExecutionId);
		LOGGER.debug("[CORE-BATCH] sendBatchStatus() - End");
		LOGGER.debug("[CORE-BATCH] ====================================================================================");
	}

	/**
	 *
	 * sendBatchStatus
	 *
	 * @param progressTotal
	 * @param progressCurrent void
	 */
	public void sendBatchStatus(int progressTotal, int progressCurrent)	{
		setProgressTotal(progressTotal);
		jobExecutionResult.setProgressTotal(progressTotal);

		// Batch 처리상태 전송
		sendBatchStatus(progressCurrent);
	}

	/**
	 *
	 * getStartTime
	 *
	 * @return long
	 */
	public long getStartTime() {
		return this.startTime;
	}

	/**
	 * doProcess : 실제 업무처리 Batch Java Class가 반드시 구현해야 하는 Super Method
     *             사전에 설정된 Aspect를 이용하여 실행 Argument를 삽입하고, 결과를 저장하는 기능과 연결됨
	 * @param jobName
	 * @return
	 * @throws Exception JobExecutionResult
	 */
	public abstract JobExecutionResult doProcess(String jobName) throws Exception;

	/**
	 * getter method for progressTotal
	 * @return the progressTotal
	 */
	public int getProgressTotal() {
		return progressTotal;
	}

	/**
	 * setter method for progressTotal
	 * @param progressTotal the progressTotal to set
	 */
	public void setProgressTotal(int progressTotal)
	{
		this.progressTotal = progressTotal;
	}

	/**
	 * getter method for progressCurrent
	 * @return the progressCurrent
	 */
	public int getProgressCurrent() {
		return progressCurrent;
	}

	/**
	 * setter method for progressCurrent
	 * @param progressCurrent the progressCurrent to set
	 */
	public void setProgressCurrent(int progressCurrent)
	{
		this.progressCurrent = progressCurrent;
	}

	/**
	 * getter method for jobExecutionResult
	 * @return the jobExecutionResult
	 */
	public JobExecutionResult getJobExecutionResult() {
		return jobExecutionResult;
	}

	/**
	 * setter method for jobExecutionResult
	 * @param jobExecutionResult the jobExecutionResult to set
	 */
	public void setJobExecutionResult(JobExecutionResult jobExecutionResult) {
		this.jobExecutionResult = jobExecutionResult;
	}

	/**
     * getter method for nbsArgumentMap
     * @return the nbsArgumentMap
     */
    public Map<String, String> getNbsArgumentMap() {
        return nbsArgumentMap;
    }

    /**
     * setter method for nbsArgumentMap
     * @param nbsArgumentMap the nbsArgumentMap to set
     */
    public void setNbsArgumentMap(Map<String, String> nbsArgumentMap) {
        this.nbsArgumentMap = nbsArgumentMap;
    }

    /**
	 * getter method for batchConfig
	 * @return the batchConfig
	 */
	public BatchConfig getBatchConfig() {
		return batchConfig;
	}

	/**
	 * getter method for jobId
	 * @return the jobId
	 */
	public String getJobId() {
		return jobId;
	}

	/**
	 * getter method for jobInstanceId
	 * @return the jobInstanceId
	 */
	public String getJobInstanceId() {
		return jobInstanceId;
	}

	/**
	 * getter method for jobExecutionId
	 * @return the jobExecutionId
	 */
	public String getJobExecutionId() {
		return jobExecutionId;
	}

    /**
     * getModuleName
     *
     * @return String
     */
    public String getModuleName() {
        return moduleName;
    }

}
